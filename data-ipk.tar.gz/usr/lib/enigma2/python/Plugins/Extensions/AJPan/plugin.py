import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVGsPD   = "v8.0.0"
VV3UCr    = "01-12-2022"
EASY_MODE    = 0
VVaGxk   = 0
VV9uZD   = 0
VVUsb0  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVBqIe  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVsoKC    = "/media/usb/"
VV0fZ9    = "/usr/share/enigma2/picon/"
VVU92K = "/etc/enigma2/blacklist"
VVxlEW   = "/etc/enigma2/"
VVq9zD   = "AJPan"
VVAg8j  = "AUTO FIND"
VV2g07  = "Custom"
VV8Cu8    = ""
VV3WSx = "Regular"
VVskLY = "Fixed"
VVi29r  = "AJP_Main"
VVPKSk = "AJP_Terminal"
VVgCrF = "AJP_System"
VVRQSa  = VV3WSx
VVT41S      = "-" * 80
VVdKVg    = ("-" * 100, )
VVpQe7    = ""
VVpXho   = " && echo 'Successful' || echo 'Failed!'"
VVtrg1    = []
VVngly  = "Cannot continue (No Enough Memory) !"
VVhvL2  = False
VVgkK0  = False
VVonST     = 0
VV8dFn    = 1
VVy6jt    = 2
VVJ2KD   = 3
VVO4Rs    = 4
VVaujM    = 5
VVvoh9 = 6
VVxJQK = 7
VVS7k0  = 8
VVg8qH   = 9
VV5ACW  = 10
VVnO5X  = 11
VV0WDO = 12
VViEfp    = 13
VVmB4e   = 14
VVn5nb   = 15
VVJN8J    = 16
VVD6Qj    = 17
VVJKGg  = 18
VVB9B6    = 19
VVKes2   = 0
VVW8Aw   = 1
VVdsv6   = 2
def FFD9VD():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVRQSa
  if VVi29r in lst and CFG.fontPathMain.getValue(): VVRQSa = VVi29r
  else               : VVRQSa = VV3WSx
  return lst
 else:
  return [VV3WSx]
def FFuEOA(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit File Manage")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVAg8j, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VV0fZ9, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVsoKC, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVRQSa, choices=[(x,  x) for x in FFD9VD()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFHtpx():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVDB70  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVZNaw = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVDB70  : return 0
  elif VVZNaw : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFHtpx()
VVpLjr = VVe79W = VVL1qM = VV8tcv = VVqskC = VVityU = VVQZ69 = VVacyG = VVvsR7 = VVkC8X = VVy4op = VVKiZJ = VV0HRz = VVq8cV = VVRgTn = VVH2yZ = ""
def FFyPr0()  : FFbrml(FFFO7t())
def FFJzDM()  : FFbrml(FFT4eR())
def FFuhwj(tDict): FFbrml(iDumps(tDict, indent=4, sort_keys=True))
def FFeUrI(*args): FFN9t0(True, True, *args)
def FFbrml(*args) : FFN9t0(True , False , *args)
def FFdPCW(*args): FFN9t0(False, False, *args)
def FFN9t0(addSep=True, isArray=True, *args):
 if VVaGxk:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFkw7M(fnc):
 def VVs998(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFbrml(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVs998
def FFu4DP(*args):
 if VVaGxk:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFdPCW("Added to : %s" % path)
def FFI4kT(txt, isAppend=True, ignoreErr=False):
 if VVaGxk:
  tm = FFHA4M()
  err = ""
  if not ignoreErr:
   err = FFT4eR()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFbrml(err)
  FFbrml("Output Log File : %s" % fileName)
def FFT4eR():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFHA4M()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFFO7t():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVMSht = 0
def FFEeqe():
 global VVMSht
 VVMSht = iTime()
def FF0pO7(txt=""):
 FFbrml(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVMSht)).rstrip("0"), txt))
VVtrg1 = []
def FFCpOu(win):
 global VVtrg1
 if not win in VVtrg1:
  VVtrg1.append(win)
def FF1fb7(*args):
 global VVtrg1
 for win in VVtrg1:
  try:
   win.close()
  except:
   pass
 VVtrg1 = []
def FF7JQ0():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV7k54 = FF7JQ0()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFKBWk()    : return PluginDescriptor(fnc=FFSuPI, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFm4Mg()      : return getDescriptor(FFRspN , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FF8fV1()     : return getDescriptor(FFXbO8  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFdOS9()  : return getDescriptor(FFgnZc, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFpj9z() : return getDescriptor(FFatJO , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFc87c()  : return getDescriptor(FF44qz , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFZU9P()  : return getDescriptor(FF1NHT  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFZoCO()    : return getDescriptor(FFjXKn, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF8fV1() , FFm4Mg() , FFKBWk() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFdOS9())
  result.append(FFpj9z())
  result.append(FFc87c())
  result.append(FFZU9P())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFZoCO())
 return result
def FFSuPI(reason, **kwargs):
 if reason == 0:
  FFGQjT()
  if "session" in kwargs:
   session = kwargs["session"]
   FFXYB4(session)
   CCKrcC(session)
def FFRspN(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFXbO8, PLUGIN_NAME, 45)]
 else:
  return []
def FFXbO8(session, **kwargs):
 session.open(Main_Menu)
def FFgnZc(session, **kwargs):
 session.open(CCOjzn)
def FFatJO(session, **kwargs):
 session.open(CCCGrE)
def FF44qz(session, **kwargs):
 CCSeoi.VVLNOL(session, isFromExternal=True)
def FF1NHT(session, **kwargs):
 FF7oMJ(session, reopen=True)
def FFjXKn(session, **kwargs):
 session.open(CCWhEO, fncMode=CCWhEO.VV9IGI)
def FFfuTq():
 FFtTe0(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFdOS9(), FFpj9z(), FFc87c(), FFZU9P() ])
 FFtTe0(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFZoCO() ])
def FFtTe0(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVQ6Rc = None
def FFGQjT():
 try:
  global VVQ6Rc
  if VVQ6Rc is None:
   VVQ6Rc    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFdp7z
  ChannelContextMenu.FFgsfL = FFgsfL
 except:
  pass
def FFdp7z(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVQ6Rc(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFgsfL, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFgsfL, title1, csel, isFind=True))))
def FFgsfL(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFv14i(refCode)
 except:
  pass
 self.session.open(BF(CCuxcD, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFXYB4(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FF9It6, session, "lok")
 hk.actions["longCancel"]= BF(FF9It6, session, "lesc")
 hk.actions["longRed"] = BF(FF9It6, session, "lred")
 for k in (CCtNnf.VVFNkC, CCtNnf.VVQREE, CCtNnf.VVNecu):
  hk.actions[k] = BF(CCtNnf.VVXHQ6, session, k)
def FF9It6(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCrLDb.VVBQtj:
    CCrLDb.VVBQtj.close()
   if not CCSeoi.VVN5AL:
    CCSeoi.VVLNOL(session, isFromExternal=True)
  except:
   pass
def FFcghP(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFDBTO(SELF, title="", addLabel=False, addScrollLabel=False, VVv6X1=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFs7ER()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCKwgM(SELF)
 if VVv6X1:
  SELF["myMenu"] = MenuList(VVv6X1)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVsJp0 ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFOeBX(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFALoB, SELF, "0"),
  "1" : BF(FFALoB, SELF, "1"),
  "2" : BF(FFALoB, SELF, "2"),
  "3" : BF(FFALoB, SELF, "3"),
  "4" : BF(FFALoB, SELF, "4"),
  "5" : BF(FFALoB, SELF, "5"),
  "6" : BF(FFALoB, SELF, "6"),
  "7" : BF(FFALoB, SELF, "7"),
  "8" : BF(FFALoB, SELF, "8"),
  "9" : BF(FFALoB, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FF40oC, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFALoB(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVH2yZ:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVH2yZ + SELF.keyPressed + VVe79W)
    txt = VVe79W + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFfad8(SELF, txt)
def FF40oC(SELF, tableObj, colNum, isMenu):
 FFfad8(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFtomh(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVsnMy(i)
     else  : SELF.VVG9tX(i)
     break
 except:
  pass
def FFs7ER():
 return ("  %s" % VVpQe7)
def FFjeeE(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFtomh(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFKd79(color):
 return parseColor(color).argb()
def FFqst5(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF2A0B(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFJbsx(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFy8kX(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVH2yZ)
 else:
  return ""
def FFaNdy(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVT41S, word, VVT41S, VVH2yZ)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVT41S, word, VVT41S)
def FFf1xo(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVH2yZ
def FF743i(color):
 if color: return "echo -e '%s' %s;" % (VVT41S, FFy8kX(VVT41S, VVy4op))
 else : return "echo -e '%s';" % VVT41S
def FFb8P2(title, color):
 title = "%s\n%s\n%s\n" % (VVT41S, title, VVT41S)
 return FFf1xo(title, color)
def FFIpXz(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFW4LM(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFFO8C(callBackFunction):
 tCons = CCo0hB()
 tCons.ePopen("echo", BF(FFC77l, callBackFunction))
def FFC77l(callBackFunction, result, retval):
 callBackFunction()
def FF0rXP(SELF, fnc, title="Processing ...", clearMsg=True):
 FFfad8(SELF, title)
 tCons = CCo0hB()
 tCons.ePopen("echo", BF(FFfl2N, SELF, fnc, clearMsg))
def FFfl2N(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFfad8(SELF)
def FFrvKF(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVngly
  else       : return ""
def FFqfZV(cmd):
 txt = FFrvKF(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFTbYu(cmd):
 lines = FFqfZV(cmd)
 if lines: return lines[0]
 else : return ""
def FFcnSO(SELF, cmd):
 lines = FFqfZV(cmd)
 VV4Gbf = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV4Gbf.append((key, val))
  elif line:
   VV4Gbf.append((line, ""))
 if VV4Gbf:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFl3hs(SELF, None, header=header, VVouKi=VV4Gbf, VVw7oP=widths, VVcK4p=28)
 else:
  FFYYbP(SELF, cmd)
def FFYYbP(    SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VVp6aH=True, VVKhCn=VVW8Aw, **kwargs)
def FFepZj(  SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, **kwargs)
def FFXvUZ(   SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VV6cmr=True, VVESIo=True, VVKhCn=VVW8Aw, **kwargs)
def FFHuBX(  SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VV6cmr=True, VVESIo=True, VVKhCn=VVdsv6, **kwargs)
def FF8ZtC(  SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VVKVlv=True , **kwargs)
def FFJQIf(  session, cmd, **kwargs):      session.open(CCFteI, VVdEBn=cmd, VVKVlv=True , **kwargs)
def FF1t4W( SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VVZ5tc=True   , **kwargs)
def FFnBvt( SELF, cmd, **kwargs): SELF.session.open(CCFteI, VVdEBn=cmd, VVh2ED=True  , **kwargs)
def FFWqNF(cmd):
 return cmd + " > /dev/null 2>&1"
def FFRsJX(cmd):
 return cmd + " 2> /dev/null"
def FFzrh0():
 return " > /dev/null 2>&1"
def FFN0sR(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFpy4F(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF6lF9():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFTbYu(cmd)
VVi3Ri     = 0
VVe6Xo      = 1
VVmMeS   = 2
VV9TTi      = 3
VVXRXE      = 4
VVeiVb     = 5
VViQjU     = 6
VVaj7G = 7
VVTIdG = 8
VVQVWS = 9
VVlNe9  = 10
VVdipQ     = 11
VV4yPs  = 12
VVnbOp  = 13
def FFrxPD(parmNum, grepTxt):
 if   parmNum == VVi3Ri  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVe6Xo   : param = ["list"   , "apt list" ]
 elif parmNum == VVmMeS: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF6lF9()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFohUm(parmNum, package):
 if   parmNum == VV9TTi      : param = ["info"      , "apt show"         ]
 elif parmNum == VVXRXE      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVeiVb     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VViQjU     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVaj7G : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVTIdG : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVQVWS : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVlNe9  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVdipQ     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV4yPs  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVnbOp  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF6lF9()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFwHJG():
 result = FFTbYu("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFohUm(VViQjU , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFWqNF("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFWqNF("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFy8kX(failed1, VVy4op))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFy8kX(failed2, VVy4op))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFy8kX(failed3, VVL1qM))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF3uXq(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFohUm(VViQjU , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFWqNF("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFy8kX(failed1, VVy4op))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFy8kX(failed2, VVL1qM))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFGXQq(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFWqNF('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFWqNF("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFUKzq(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCzVQo.VVpKTi()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFRtPk(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFUKzq(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFKFmx(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFDH0v(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFUKzq(path, maxSize=maxSize, encLst=encLst)
  if lines: FFipfq(SELF, lines, title=title, VVKhCn=VVW8Aw, width=1600, height=1000, titleFontSize=30)
  else : FFr7wg(SELF, path, title=title)
 else:
  FFZBzs(SELF, path, title)
def FFAqgP(SELF, fName, title):
 path = VVCsc2 + fName
 if fileExists(path):
  txt = FFUKzq(path)
  txt = txt.replace("#W#", VVH2yZ)
  txt = txt.replace("#Y#", VVKiZJ)
  txt = txt.replace("#G#", VVe79W)
  txt = txt.replace("#C#", VV0HRz)
  txt = txt.replace("#P#", VVqskC)
  FFipfq(SELF, txt, title=title)
 else:
  FFZBzs(SELF, path, title)
def FFYR05(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFEP6Z(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFiSR4(parent)
 else    : return FFvuYj(parent)
def FFj5JI(path):
 return os.path.basename(os.path.normpath(path))
def FFDH0v(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFsF1P(path):
 try:
  os.remove(path)
 except:
  pass
def FFiSR4(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFvuYj(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFQjAP():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVUsb0)
 paths.append(VVUsb0.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFYR05(ba)
 for p in list:
  p = ba + p + VVUsb0
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVq9zD, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVUsb0, VVq9zD , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVe3YE, VVCsc2 = FFQjAP()
def FFI9nQ():
 def VV0TDE(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVz2Aj   = VV0TDE(CFG.backupPath, CCLmoH.VV6bvJ())
 VVDP3q   = VV0TDE(CFG.downloadedPackagesPath, t)
 VVq7hU  = VV0TDE(CFG.exportedTablesPath, t)
 VVMnsM  = VV0TDE(CFG.exportedPIconsPath, t)
 VVB2Be   = VV0TDE(CFG.packageOutputPath, t)
 global VVsoKC
 VVsoKC = FFiSR4(CFG.backupPath.getValue())
 if VVz2Aj or VVB2Be or VVDP3q or VVq7hU or VVMnsM or oldMovieDownloadPath:
  configfile.save()
 return VVz2Aj, VVB2Be, VVDP3q, VVq7hU, VVMnsM, oldMovieDownloadPath
def FFT7fV(path):
 path = FFvuYj(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFJy30(SELF, pathList, tarFileName, addTimeStamp=True):
 VVouKi = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVouKi.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVouKi.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVouKi.append(path)
 if not VVouKi:
  FFRGBb(SELF, "Files not found!")
 elif not pathExists(VVsoKC):
  FFRGBb(SELF, "Path not found!\n\n%s" % VVsoKC)
 else:
  VVpBdT = FFiSR4(VVsoKC)
  tarFileName = "%s%s" % (VVpBdT, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFWWBu())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVouKi:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVT41S
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFy8kX(tarFileName, VVvsR7))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFy8kX(failed, VVvsR7))
  cmd += "fi;"
  cmd +=  sep
  FFepZj(SELF, cmd)
def FFK8YM(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFcuek(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFcuek(SELF["keyInfo"], "info")
def FFcuek(barObj, fName):
 path = "%s%s%s" % (VVCsc2, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFs1xj(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFUgik(satNum)
  return satName
def FFUgik(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFlSfT(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFs1xj(val)
  else  : sat = FFUgik(val)
 return sat
def FFvyCa(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFs1xj(num)
 except:
  pass
 return sat
def FFcPTk(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFaQmC(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFL4y8(info, iServiceInformation.sServiceref)
   prov = FFL4y8(info, iServiceInformation.sProvider)
   state = str(FFL4y8(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFW8kf(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFQOHf(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFL4y8(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFvNg9(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFv14i(refCode):
 info = FFoe96(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFopyC(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFDeJg(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFoe96(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV1zoa = eServiceCenter.getInstance()
  if VV1zoa:
   info = VV1zoa.info(service)
 return info
def FFTztI(SELF, refCode, VVLjiH=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFj6M9(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVLjiH:
   FFLVE8(SELF, isFromSession)
 try:
  VVY2Pt = InfoBar.instance
  if VVY2Pt:
   VVpvWi = VVY2Pt.servicelist
   if VVpvWi:
    servRef = eServiceReference(refCode)
    VVpvWi.saveChannel(servRef)
 except:
  pass
def FFj6M9(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCN3wh()
    if pr.VVcORG(refCode, chName, decodedUrl, iptvRef):
     pr.VVw5aC(SELF, isFromSession)
def FFW8kf(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFUUIm(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF35eK(url): return FFrq1B(url) or FFTyfy(url)
def FFrq1B(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFTyfy(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFQOHf(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFT8KE(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFT8KE(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFAPsb(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFuqs7(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF3JrN(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFpmLf(txt):
 try:
  return FFuqs7(FF3JrN(txt)) == txt
 except:
  return False
def FF37hM(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFiSR4(newPath), patt))
def FFLVE8(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCSeoi.VVLNOL(session, isFromExternal=isFromSession)
 else      : FF7oMJ(session, reopen=True)
def FF7oMJ(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF7oMJ, session), CCrLDb)
  except:
   try:
    FFONpl(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFkFSJ(refCode):
 tp = CCg4Ht()
 if tp.VVfnUn(refCode) : return True
 else        : return False
def FF8S9j(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFVJ21(True)
     return True
 return False
def FFVJ21(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFfExt()
def FFfExt():
 VVY2Pt = InfoBar.instance
 if VVY2Pt:
  VVpvWi = VVY2Pt.servicelist
  if VVpvWi:
   VVpvWi.setMode()
def FFWeXA(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV1zoa = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV1zoa.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FF9RbH():
 VVWyfL = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVZ2TC = list(VVWyfL)
 return VVZ2TC, VVWyfL
def FFuDkg():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFYhkG(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFQFpj(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFGSTP():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFWWBu():
 return FFGSTP().replace(" ", "_").replace("-", "").replace(":", "")
def FFD88e(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFHA4M():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFn4Tu(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCCGrE.VVs0VG(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCCGrE.VVyead(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFWqNF("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFwmlV(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FF2vwS(num):
 return "s" if num > 1 else ""
def FF0CSz(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFF1Ee(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFMKzN(a, b):
 return (a > b) - (a < b)
def FFvJTl(a, b):
 def VVX4EJ(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVX4EJ(a)
 b = VVX4EJ(b)
 return (a > b) - (a < b)
def FFo3Is(mycmp):
 class CCU5eB(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCU5eB
def FFrNpu(SELF, message, title="", VVkuAk=None):
 SELF.session.openWithCallback(VVkuAk, CC2vEc, title=title, message=message, VVjYPr=True)
def FFipfq(SELF, message, title="", VVKhCn=VVW8Aw, VVkuAk=None, **kwargs):
 SELF.session.openWithCallback(VVkuAk, CC2vEc, title=title, message=message, VVKhCn=VVKhCn, **kwargs)
def FFRGBb(SELF, message, title="")  : FFONpl(SELF.session, message, title)
def FFZBzs(SELF, path, title="") : FFONpl(SELF.session, "File not found !\n\n%s" % path, title)
def FFr7wg(SELF, path, title="") : FFONpl(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF2yhz(SELF, title="")  : FFONpl(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFONpl(session, message, title="") : session.open(BF(CCHSKa, title=title, message=message))
def FFufG1(SELF, VVkuAk, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVkuAk, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVkuAk, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFRGBb(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFWkqs(SELF, callBack_Yes, VVfTYp, callBack_No=None, title="", VVaQmw=False, VVxoh5=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FF4Hqa, callBack_Yes, callBack_No)
         , BF(CCUwZ9, title=title, VVfTYp=VVfTYp, VVxoh5=VVxoh5, VVaQmw=VVaQmw))
def FF4Hqa(callBack_Yes, callBack_No, FFWkqsed):
 if FFWkqsed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFfad8(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FF2A0B(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFv9ss(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFCEoK(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVh6CI = eTimer()
def FFv9ss(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFEJcR, SELF))
 fnc = BF(FFEJcR, SELF)
 try:
  t = VVh6CI.timeout.connect(fnc)
 except:
  VVh6CI.callback.append(fnc)
 VVh6CI.start(milliSeconds, 1)
def FFEJcR(SELF):
 VVh6CI.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFl3hs(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCJhfe, **kwargs))
  else   : win = SELF.session.open(BF(CCJhfe, **kwargs))
  FFCpOu(win)
  return win
 except:
  return None
def FFLwVh(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CC6eSf, **kwargs))
 FFCpOu(win)
 return win
def FF9558(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFwYti(SELF, **kwargs):
 SELF.session.open(CCWhEO, **kwargs)
def FFjMgg(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFfZuu(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFWRKG(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVRQSa, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFhukk(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFWRKG(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFrVM8(SELF, winSize.width(), winSize.height())
def FFrVM8(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFEnkn():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFjaaN(VVcK4p):
 screenSize  = FFEnkn()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVcK4p)
 return bodyFontSize
def FFewIR(VVcK4p, extraSpace):
 font = gFont(VVRQSa, VVcK4p)
 VVv9gC = fontRenderClass.getInstance().getLineHeight(font) or (VVcK4p * 1.25)
 return int(VVv9gC + VVv9gC * extraSpace)
def FFUxcO(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0):
 screenSize = FFEnkn()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVRQSa, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFewIR(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVRQSa, titleFontSize, alignLeftCenter)
 if winType in (VVonST, VV8dFn):
  if winType == VV8dFn : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVJKGg:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVD6Qj:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVRQSa, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VViEfp:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFrNpuL = b2Left2 + timeW + marginLeft
  FFrNpuW = b2Left3 - marginLeft - FFrNpuL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFrNpuL , b2Top, FFrNpuW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVmB4e:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVO4Rs:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVy6jt:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVJ2KD:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVRQSa, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVRQSa, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV5ACW:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVRQSa, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVn5nb:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVRQSa, fontH, alignCenter)
 elif winType in (VVnO5X, VV0WDO):
  if winType == VVnO5X: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int((width - vSliderW)  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVnO5X:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVRQSa, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVRQSa, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVRQSa, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVRQSa, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVRQSa, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVRQSa, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  extraPar = (boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVRQSa, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVJN8J:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVaujM:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVxJQK : align = alignLeftCenter
  elif winType == VVvoh9 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVg8qH:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVRQSa
  if usefixedFont and winType == VVvoh9:
   fLst = FFD9VD()
   if   VVPKSk in fLst and CFG.fontPathTerm.getValue(): fontName = VVPKSk
   elif VVskLY in fLst         : fontName = VVskLY
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVcK4p = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVRQSa, VVcK4p, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVOSNp = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVRQSa, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVOSNp[i], VVRQSa, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVvoh9:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVOSNp = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVOSNp[i], VVRQSa, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VV6Tki = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVGsPD)
  VVv6X1 = []
  if VV9uZD:
   VVv6X1.append(("-- MY TEST --"  , "myTest" ))
  VVv6X1.append(("File Manager"    , "fMan" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("IPTV"      , "iptv" ))
  VVv6X1.append(("Movies Browser"   , "movie" ))
  VVv6X1.append(("Services/Channels"  , "chan" ))
  VVv6X1.append(("PIcons"     , "picon" ))
  VVv6X1.append(("EPG"      , "epg"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Terminal"     , "term" ))
  VVv6X1.append(("SoftCam"     , "soft" ))
  VVv6X1.append(("Plugins"     , "plug" ))
  VVv6X1.append(("Backup & Restore"   , "bakup" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Date/Time"    , "date" ))
  for ndx, item in enumerate(VVv6X1):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVv6X1[ndx] = tuple(item)
  FFDBTO(self, title=self.Title, VVv6X1=VVv6X1)
  FFjeeE(self["keyRed"] , "Exit")
  FFjeeE(self["keyGreen"] , "Settings")
  FFjeeE(self["keyYellow"], "Dev. Info.")
  FFjeeE(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : BF(self.session.open, CCLmoH) ,
   "yellow": BF(self.session.open, CC7qsf)  ,
   "blue" : self.VVjJvt     ,
   "info" : BF(FF0rXP, self, self.VVO9nD) ,
   "text" : self.VVqDPc      ,
   "menu" : self.VVayZa    ,
   "0"  : BF(self.VVlYqX, 0)   ,
   "1"  : BF(self.VVJnhV, "fMan")   ,
   "2"  : BF(self.VVJnhV, "iptv")   ,
   "3"  : BF(self.VVJnhV, "movie")   ,
   "4"  : BF(self.VVJnhV, "chan")   ,
   "5"  : BF(self.VVJnhV, "picon")   ,
   "6"  : BF(self.VVJnhV, "epg")   ,
   "7"  : BF(self.VVJnhV, "term")   ,
   "8"  : BF(self.VVJnhV, "soft")   ,
   "9"  : BF(self.VVJnhV, "plug")   ,
   "last" : BF(self.VVJnhV, "bakup")   ,
   "next" : BF(self.VVJnhV, "date")   ,
  })
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
  global VVhvL2, VVgkK0
  VVhvL2 = VVgkK0 = False
 def VVsJp0(self):
  self.VVJnhV(self["myMenu"].l.getCurrentSelection()[1])
 def VVJnhV(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVpQe7
   VVpQe7 = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVcUjd()
   elif item == "fMan"  : self.session.open(CCOjzn)
   elif item == "iptv"  : self.session.open(CCCGrE)
   elif item == "movie" : FF0rXP(self, BF(CCakoM.VV0mWC, self))
   elif item == "chan"  : self.session.open(CCnEIM)
   elif item == "picon" : self.VVIIwj()
   elif item == "epg"  : self.session.open(CC8oCo)
   elif item == "term"  : self.session.open(CCnmf5)
   elif item == "soft"  : self.session.open(CCixMT)
   elif item == "plug"  : self.session.open(CCgqIF)
   elif item == "bakup" : self.session.open(CCx11W)
   elif item == "date"  : self.session.open(CClAPU)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
  FFjMgg(self)
  FFK8YM(self)
  VVz2Aj, VVB2Be, VVDP3q, VVq7hU, VVMnsM, oldMovieDownloadPath = FFI9nQ()
  if VVz2Aj or VVB2Be or VVDP3q or VVq7hU or VVMnsM or oldMovieDownloadPath:
   VV8Lwm = lambda path, subj: "%s:\n%s\n\n" % (subj, FFf1xo(path, VV8tcv)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV8Lwm(VVz2Aj   , "Backup/Restore Path"    )
   txt += VV8Lwm(VVB2Be  , "Created Package Files (IPK/DEB)" )
   txt += VV8Lwm(VVDP3q  , "Download Packages (from feeds)" )
   txt += VV8Lwm(VVq7hU , "Exported Tables"     )
   txt += VV8Lwm(VVMnsM , "Exported PIcons"     )
   txt += VV8Lwm(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFipfq(self, txt, title="Settings Paths")
  self.VV5Uod()
  if (EASY_MODE or VVaGxk or VV9uZD):
   FF2A0B(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFfad8(self, "Welcome", 300)
  FFFO8C(self.VVorNe)
 def VVorNe(self):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCLmoH.VVY3Pv()
   if url:
    newWebVer = CCLmoH.VVIiuY(url)
    if newWebVer:
     self["myTitle"].setText("  %s (%s available)" % (self.Title, newWebVer))
 def onExit(self):
  os.system(FFWqNF("rm /tmp/ajpanel*"))
  global VVhvL2, VVgkK0
  VVhvL2 = VVgkK0 = False
 def VVlYqX(self, digit):
  self.VV6Tki += str(digit)
  ln = len(self.VV6Tki)
  global VVhvL2
  if ln == 4:
   if self.VV6Tki == "0" * ln:
    VVhvL2 = True
    FF2A0B(self["myTitle"], "#11805040")
   else:
    self.VV6Tki = "x"
 def VVqDPc(self):
  self.VV6Tki += "t"
  if self.VV6Tki == "0" * 4 + "t" * 2:
   global VVgkK0
   VVgkK0 = True
   FF2A0B(self["myTitle"], "#dd5588")
 def VVIIwj(self):
  found = False
  pPath = CCxA8L.VV76e0()
  if pathExists(pPath):
   for fName, fType in CCxA8L.VVkyO5(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCxA8L)
  else:
   VVv6X1 = []
   VVv6X1.append(("PIcons Tools" , "CCxA8L" ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(CCxA8L.VVFh5V())
   VVv6X1.append(VVdKVg)
   VVv6X1 += CCxA8L.VVIiVI()
   FFLwVh(self, self.VVXUJs, VVv6X1=VVv6X1)
 def VVXUJs(self, item=None):
  if item:
   if   item == "CCxA8L"   : self.session.open(CCxA8L)
   elif item == "VVFu6R"  : CCxA8L.VVFu6R(self)
   elif item == "VVZXpU"  : CCxA8L.VVZXpU(self)
   elif item == "findPiconBrokenSymLinks" : CCxA8L.VVv5nV(self, True)
   elif item == "FindAllBrokenSymLinks" : CCxA8L.VVv5nV(self, False)
 def VVO9nD(self):
  changeLogFile = VVCsc2 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFRtPk(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFf1xo("\n%s\n%s\n%s" % (VVT41S, line, VVT41S), VVy4op, VVH2yZ)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFf1xo(line, VVe79W, VVH2yZ)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFipfq(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVGsPD, PLUGIN_DESCRIPTION), VVcK4p=28, width=1600, height=1000)
 def VVayZa(self):
  VVv6X1 = []
  VVv6X1.append(("Check Internet Connection" , "intr"))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Keys Help"     , "hlp" ))
  FFLwVh(self, self.VVRGrX, VVv6X1=VVv6X1, width=650, title="Options")
 def VVRGrX(self, item=None):
  if item:
   if   item == "intr" : self.session.open(CC0vLz)
   elif item == "libr" : FF0rXP(self, BF(self.VVXyrV))
   elif item == "hlp" : FFAqgP(self, "_help_main", "Main Page (Keys Help)")
 def VVjJvt(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVkC8X, VV8tcv, VVKiZJ, VVityU
  VVv6X1 = []
  VVv6X1.append((c1 + "Change Title Colors"   , "title"  ))
  VVv6X1.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVv6X1.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVv6X1.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVv6X1.append((c2 + "Reset Colors"    , "resetColor" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVv6X1.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c4 + "Change System Font"    , "sysFont"  ))
  FFLwVh(self, BF(self.VV9E3c, title), VVv6X1=VVv6X1, width=600, title=title)
 def VV9E3c(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVEJsQ()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVNwaS, tDict, item), CCEdpz, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFWkqs(self, self.VV53nJ, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVR6II(VVi29r  )
   elif item == "termFont"  : self.VVR6II(VVPKSk)
   elif item == "sysFont"  : self.VVR6II(VVgCrF  )
 def VVXyrV(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VV4Gbf, pkgs = self.VVtk3L()
  VV6vKb = ("Install", BF(self.VVcywr, title, pkgs)  , [])
  VVxkVZ  = ("Update Sys. Packages", self.VV1o13 , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVK4mA = (LEFT  , CENTER , LEFT  )
  VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, width=1350, VV6vKb=VV6vKb, VVxkVZ=VVxkVZ, VV5fad="#00ffffaa", VVJevj=1)
 def VVcywr(self, Title, pkgs, VVYo8S, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVR5uo, VVYo8S)
   item = colList[0]
   if   item == "requests" : CCavOd.VVYiQx(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCtNnf.VVdCzy(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FF8ZtC(self, FFwHJG(), VVo3en=cbFnc)
   elif item in pkgs  : FF8ZtC(self, FF3uXq(item, item, item.capitalize()), VVo3en=cbFnc)
  else:
   FFfad8(VVYo8S, "Already installed.", 700, isGrn=True)
 def VV1o13(self, VVYo8S, title, txt, colList):
  CCgqIF.VVkC1M(self)
 def VVR5uo(self, VVYo8S):
  VV4Gbf, pkgs = self.VVtk3L()
  VVYo8S.VVfm3U(VV4Gbf[VVYo8S.VVjpse()])
 def VVtk3L(self):
  tDict = {}
  path = VVCsc2 + "_sup_lib"
  if fileExists(path):
   for line in FFRtPk(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VV8Lwm(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFf1xo("Installed", VVvsR7), txt)
   else : return (lib, FFf1xo("Not installed", VVL1qM), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VV4Gbf = []
  VV4Gbf.append(VV8Lwm("requests", CCavOd.VVYiQx(self, install=False)))
  VV4Gbf.append(VV8Lwm("Imaging" , CCtNnf.VVdCzy(self, "", False, install=False)))
  VV4Gbf.append(VV8Lwm("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VV4Gbf.append(VV8Lwm(item, FFN0sR(item)))
  VV4Gbf.sort(key=lambda x: x[0].lower())
  return VV4Gbf, pkgs
 def VVnBIm(self):
  return VVsoKC + "ajpanel_colors"
 def VVEJsQ(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVnBIm()
  if fileExists(p):
   txt = FFUKzq(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVNwaS(self, tDict, item, fg, bg):
  if fg:
   self.VVRygG(item, fg)
   self.VVZLRN(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV3mks(tDict)
 def VV3mks(self, tDict):
   p = self.VVnBIm()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVRygG(self, item, fg):
  if   item == "title" : FFqst5(self["myTitle"], fg)
  elif item == "body"  :
   FFqst5(self["myMenu"], fg)
   FFqst5(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFqst5(self[item], fg)
 def VVZLRN(self, item, bg):
  if   item == "title" : FF2A0B(self["myTitle"], bg)
  elif item == "body"  :
   FF2A0B(self["myMenu"], bg)
   FF2A0B(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF2A0B(self["myBar"], bg)
 def VV53nJ(self):
  os.system(FFWqNF("rm %s" % self.VVnBIm()))
  self.close()
 def VV5Uod(self):
  tDict = self.VVEJsQ()
  for item in ("title", "body", "cursor", "bar"):
   self.VV0jYE(tDict, item)
 def VV0jYE(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVRygG(name, fg)
  if bg: self.VVZLRN(name, bg)
 def VVR6II(self, which):
  if   which == VVi29r  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVPKSk : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVgCrF  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCMETn.VVajuG(self, "Change %s Font" % title, defFnt, rest, BF(self.VVkUqk, which))
 def VVkUqk(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVi29r  : FFcghP(CFG.fontPathMain, path)
   elif which == VVPKSk: FFcghP(CFG.fontPathTerm, path)
   elif which == VVgCrF  : FFcghP(CFG.fontPathSys , path)
   err = Main_Menu.VVGjJk(which)
   if err          : FFRGBb(self, err, title=title)
   elif which == VVi29r   : self.close()
   elif which == VVPKSk  : FFfad8(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVgCrF and path: FFfad8(self, "System font applied", 1500, isGrn=True)
   elif which == VVgCrF   : FFWkqs(self, BF(Main_Menu.VVZ5tc, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVZ5tc(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVGjJk(name):
  if   name == VVi29r : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVPKSk: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVgCrF : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFD9VD()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVgCrF:
   nameLst = []
   for nm in FFD9VD():
    if not nm in (VVi29r, VVPKSk):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFuEOA(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFD9VD()
  else    : return "Could not add font"
 def VVcUjd(self):
  CCSeoi.VVLNOL(self.session)
class CCtNnf():
 VVFNkC  = "all"
 VVQREE = "vid"
 VVNecu  = "osd"
 @staticmethod
 def VVXHQ6(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFN0sR("grab"):
    winShown = session.current_dialog.shown
    if k == CCtNnf.VVQREE and winShown: session.current_dialog.hide()
    FFFO8C(BF(CCtNnf.VVMVqq, title, session, k, winShown))
   else:
    FFONpl(session, "No Grab command !", title=title)
 @staticmethod
 def VVMVqq(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCtNnf.VVNecu:
   if not winShown:
    FFONpl(session, "No Window to capture !", title=title)
    return
   if not CCtNnf.VVdCzy(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCtNnf.VVhC3j(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFONpl(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFiSR4(CFG.exportedPIconsPath.getValue()), fTitle, FFWWBu(), ext)
  res = os.system(FFRsJX("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCtNnf.VVQREE and winShown:
   session.current_dialog.show()
  elif k == CCtNnf.VVNecu:
   ok = CCtNnf.VVI6KS(path, x, y, w, h)
   if not ok:
    FFsF1P(path)
    FFONpl(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCXjSu, title=path, VV8Zdd=path))
  else       : FFONpl(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVdCzy(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFWkqs(SELF, BF(CCtNnf.VVKcTs, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVKcTs(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFJQIf, VVo3en=cbFnc)
  else    : fnc = BF(FF8ZtC , VVo3en=cbFnc)
  fnc(SELF, FFohUm(VViQjU, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVhC3j(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVI6KS(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFEnkn()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFF1Ee(x , 0, scrW, 0, w)
     y  = FFF1Ee(y , 0, scrH, 0, h)
     x1 = FFF1Ee(x1, 0, scrW, 0, w)
     y1 = FFF1Ee(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVU2CH(path):
  size = FFDH0v(path)
  sizeTxt = CCOjzn.VV7GBO(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCMETn(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFUxcO(VVonST, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFf1xo(" (Requires GUI Restart)", VVityU) if withRestart else ""
  VVv6X1 = []
  for path in self.fontsList:
   VVv6X1.append((os.path.splitext(os.path.basename(path))[0], path))
  VVv6X1.sort(key=lambda x: x[0].lower())
  VVv6X1.insert(0, VVdKVg)
  VVv6X1.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVv6X1):
    if len(item) == 2 and item[1] == self.defFnt:
     VVv6X1[ndx] = (VVvsR7 + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVv6X1[curIndex] = (VVvsR7 + VVv6X1[curIndex][0], VVv6X1[curIndex][1])
  FFDBTO(self, VVv6X1=VVv6X1, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
  self["myMenu"].onSelectionChanged.append(self.VV5Cvo)
  self["myBar"].setText(self.VVhWNw())
  self["myBar"].instance.setHAlign(1)
  self.VV5Cvo()
 def VVsJp0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV5Cvo(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFuEOA(path, fnt, isRepl=1)
  else:
   fnt = VV3WSx
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVhWNw(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVajuG(SELF, title, defFnt, rest, VVkuAk):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FF37hM(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVkuAk, CCMETn, title, fontsList, defFnt, rest)
  else  : FFRGBb(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCD3IC(Screen):
 def __init__(self, session, path, VVv6X1, title):
  self.skin, self.skinParam = FFUxcO(VVonST, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFDBTO(self, VVv6X1=VVv6X1, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVsJp0   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVzSkC,
   "chanUp" : self.VVzSkC,
   "pageDown" : self.VVd7am ,
   "chanDown" : self.VVd7am ,
  }, -1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
  FF2A0B(self["myLabelFrm"], "#11110000")
  FF2A0B(self["myLabelTit"], "#11663322")
  FF2A0B(self["myLabelTxt"], "#11110000")
  self["myLabelTxt"].instance.setNoWrap(True)
  self["myMenu"].onSelectionChanged.append(self.VVh4Bw)
  self.VVh4Bw()
 def VVh4Bw(self):
  if fileExists(self.path): txt = FFUKzq(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVsJp0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVzSkC(self) : self["myMenu"].moveToIndex(0)
 def VVd7am(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCzVQo():
 @staticmethod
 def VVpKTi():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVR1m4(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFl3hs(SELF, None, VVouKi=lst, VVcK4p=30, VVJevj=1)
 @staticmethod
 def VVYxDX(path, SELF=None):
  for enc in CCzVQo.VVpKTi():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFRGBb(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVmOQL(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFfad8(SELF)
  lst = CCzVQo.VVujDQ(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVv6X1 = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFf1xo(txt, VVvsR7)
    VVv6X1.append((txt, enc))
   if onlyWorkingEnc: SELF.session.openWithCallback(cbFnc, CCD3IC, path, VVv6X1, title)
   else    : FFLwVh(SELF, cbFnc, title=title, VVv6X1=VVv6X1, width=900, VVyRL8="#22220000", VVmr0Y="#22220000")
  else:
   FFfad8(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVujDQ(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVCsc2 + "_sup_codecs"
  if fileExists(cPath):
   lines = FFRtPk(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCzVQo.VVpKTi())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CC7qsf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVv6X1 = []
  VVv6X1.append(("Settings File"        , "SettingsFile"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Box Info"          , "VVdZnD"    ))
  VVv6X1.append(("Tuners Info"         , "VVvVaS"   ))
  VVv6X1.append(("Python Version"        , "VVTkkO"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Screen Size"         , "ScreenSize"    ))
  VVv6X1.append(("Language/Locale"        , "Locale"     ))
  VVv6X1.append(("Processor"         , "Processor"    ))
  VVv6X1.append(("Operating System"        , "OperatingSystem"   ))
  VVv6X1.append(("Drivers"          , "drivers"     ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("System Users"         , "SystemUsers"    ))
  VVv6X1.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVv6X1.append(("Uptime"          , "Uptime"     ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Host Name"         , "HostName"    ))
  VVv6X1.append(("MAC Address"         , "MACAddress"    ))
  VVv6X1.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVv6X1.append(("Network Status"        , "NetworkStatus"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Disk Usage"         , "VV02e1"    ))
  VVv6X1.append(("Mount Points"         , "MountPoints"    ))
  VVv6X1.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVv6X1.append(("USB Devices"         , "USB_Devices"    ))
  VVv6X1.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVv6X1.append(("Directory Size"        , "DirectorySize"   ))
  VVv6X1.append(("Memory"          , "Memory"     ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVv6X1.append(("Running Processes"       , "RunningProcesses"  ))
  VVv6X1.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFDBTO(self, VVv6X1=VVv6X1, title="Device Information")
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCQOYj)
   elif item == "VVdZnD"    : self.VVdZnD()
   elif item == "VVvVaS"   : self.VVvVaS()
   elif item == "VVTkkO"   : self.VVTkkO()
   elif item == "ScreenSize"    : FFipfq(self, "Width\t: %s\nHeight\t: %s" % (FFEnkn()[0], FFEnkn()[1]))
   elif item == "Locale"     : CCzVQo.VVR1m4(self)
   elif item == "Processor"    : self.VVVs2s()
   elif item == "OperatingSystem"   : FFYYbP(self, "uname -a"        )
   elif item == "drivers"     : self.VVjgrA()
   elif item == "SystemUsers"    : FFYYbP(self, "id"          )
   elif item == "LoggedInUsers"   : FFYYbP(self, "who -a"         )
   elif item == "Uptime"     : FFYYbP(self, "uptime"         )
   elif item == "HostName"     : FFYYbP(self, "hostname"        )
   elif item == "MACAddress"    : self.VVxRjq()
   elif item == "NetworkConfiguration"  : FFYYbP(self, "ifconfig %s %s" % (FFy8kX("HWaddr", VVRgTn), FFy8kX("addr:", VVy4op)))
   elif item == "NetworkStatus"   : FFYYbP(self, "netstat -tulpn"       )
   elif item == "VV02e1"    : self.VV02e1()
   elif item == "MountPoints"    : FFYYbP(self, "mount %s" % (FFy8kX(" on ", VVy4op)))
   elif item == "FileSystemTable"   : FFYYbP(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFYYbP(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFYYbP(self, "blkid"         )
   elif item == "DirectorySize"   : FFYYbP(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVgfAq="Reading size ...")
   elif item == "Memory"     : FFYYbP(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVr81U()
   elif item == "RunningProcesses"   : FFYYbP(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFYYbP(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVgM13()
   else         : self.close()
 def VVxRjq(self):
  res = FFrvKF("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFipfq(self, txt)
  else:
   FFYYbP(self, "ip link")
 def VVLS7Q(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFqfZV(cmd)
  return lines
 def VVTvHi(self, lines, headerRepl, widths, VVK4mA):
  VV4Gbf = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV4Gbf.append(parts)
  if VV4Gbf and len(header) == len(widths):
   VV4Gbf.sort(key=lambda x: x[0].lower())
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VVJevj=1)
   return True
  else:
   return False
 def VV02e1(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFrvKF(cmd)
  if not "invalid option" in txt:
   lines  = self.VVLS7Q(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVK4mA = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVTvHi(lines, headerRepl, widths, VVK4mA)
  else:
   cmd = "df -h"
   lines  = self.VVLS7Q(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVK4mA = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVTvHi(lines, headerRepl, widths, VVK4mA)
  if not allOK:
   lines = FFqfZV(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFvuYj(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVvsR7:
     note = "\n%s" % FFf1xo("Green = Mounted Partitions", VVvsR7)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVy4op
     elif line.endswith(mountList) : color = VVvsR7
     else       : color = VVe79W
     txt += FFf1xo(line, color) + "\n"
    FFipfq(self, txt + note)
   else:
    FFRGBb(self, "Not data from system !")
 def VVr81U(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVLS7Q(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVK4mA = (LEFT , CENTER, LEFT )
  allOK = self.VVTvHi(lines, headerRepl, widths, VVK4mA)
  if not allOK:
   FFYYbP(self, cmd)
 def VVjgrA(self):
  cmd = FFrxPD(VVmMeS, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFYYbP(self, cmd)
  else : FF2yhz(self)
 def VVVs2s(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFYYbP(self, cmd)
 def VVgM13(self):
  cmd = FFrxPD(VVe6Xo, "| grep secondstage")
  if cmd : FFYYbP(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF2yhz(self)
 def VVdZnD(self):
  c = VVvsR7
  VVouKi = []
  VVouKi.append((FFf1xo("Box Type"  , c), FFf1xo(self.VVheol("boxtype").upper(), c)))
  VVouKi.append((FFf1xo("Board Version", c), FFf1xo(self.VVheol("board_revision") , c)))
  VVouKi.append((FFf1xo("Chipset"  , c), FFf1xo(self.VVheol("chipset")  , c)))
  VVouKi.append((FFf1xo("S/N"   , c), FFf1xo(self.VVheol("sn")    , c)))
  VVouKi.append((FFf1xo("Version"  , c), FFf1xo(self.VVheol("version")  , c)))
  VVCJR5   = []
  VVVHgX = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVVHgX = SystemInfo[key]
     else:
      VVCJR5.append((FFf1xo(str(key), VV0HRz), FFf1xo(str(SystemInfo[key]), VV0HRz)))
  except:
   pass
  if VVVHgX:
   VVtQm1 = self.VV6SAd(VVVHgX)
   if VVtQm1:
    VVtQm1.sort(key=lambda x: x[0].lower())
    VVouKi += VVtQm1
  if VVCJR5:
   VVCJR5.sort(key=lambda x: x[0].lower())
   VVouKi += VVCJR5
  if VVouKi:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFl3hs(self, None, header=header, VVouKi=VVouKi, VVw7oP=widths, VVcK4p=28, VVJevj=1)
  else:
   FFipfq(self, "Could not read info!")
 def VVheol(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFRtPk(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV6SAd(self, mbDict):
  try:
   mbList = list(mbDict)
   VVouKi = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVouKi.append((FFf1xo(subject, VVy4op), FFf1xo(value, VVy4op)))
  except:
   pass
  return VVouKi
 def VVvVaS(self):
  txt = self.VViGGa("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VViGGa("/proc/bus/nim_sockets")
  if not txt: txt = self.VVqvz4()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFipfq(self, txt)
 def VVqvz4(self):
  txt = ""
  VV8Lwm = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV8Lwm("Slot Name" , slot.getSlotName())
     txt += FFf1xo(slotName, VVy4op)
     txt += VV8Lwm("Description"  , slot.getFullDescription())
     txt += VV8Lwm("Frontend ID"  , slot.frontend_id)
     txt += VV8Lwm("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VViGGa(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFRtPk(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFf1xo(line, VVy4op)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVTkkO(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFipfq(self, txt)
 @staticmethod
 def VV9tvn():
  def VV8Lwm(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VV8Lwm(v,0), "/etc/issue.net": VV8Lwm(v,1), "/etc/image-version": VV8Lwm(v,2)}
  for p1, d in v.items():
   img = CC7qsf.VVXniR(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VV8Lwm(v,0), p + "Plugins/": VV8Lwm(v,1), VVBqIe: VV8Lwm(v,2), VVUsb0: VV8Lwm(v,3)}
  for p1, d in v.items():
   img = CC7qsf.VVbOPu(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVXniR(path, d):
  if fileExists(path):
   txt = FFUKzq(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVbOPu(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCQOYj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVv6X1 = []
  VVv6X1.append(("Settings (All)"   , "Settings_All"   ))
  VVv6X1.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVv6X1.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVv6X1.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVv6X1.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVv6X1.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVv6X1.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVgkK0:
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVv6X1.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVxlEW
   grep = " | grep "
   if   item == "Settings_All"    : FFYYbP(self, cmd                )
   elif item == "Settings_HotKeys"   : FFYYbP(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFYYbP(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFYYbP(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFYYbP(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFYYbP(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFYYbP(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFYYbP(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFYYbP(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCixMT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVbAn1, VVgY6G, VVk5ul, camCommand = CCixMT.VVBoVB()
  self.VVgY6G = VVgY6G
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVgY6G:
   c = VVkC8X if VVk5ul else VVq8cV
   if   "oscam" in VVgY6G : camName, oC = "OSCam", c
   elif "ncam"  in VVgY6G : camName, nC = "NCam" , c
  VVv6X1 = []
  VVv6X1.append(("OSCam Files" , "OSCamFiles"  ))
  VVv6X1.append(("NCam Files" , "NCamFiles"  ))
  VVv6X1.append(("CCcam Files" , "CCcamFiles"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((VVKiZJ + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVzEs2" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVv6X1.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVv6X1.append(VVdKVg)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVgY6G: VVv6X1.append((c + txt  , "camInfo" ))
  else  : VVv6X1.append((txt  ,    ))
  VVv6X1.append(VVdKVg)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVgY6G:
   for item in camLst: VVv6X1.append(item)
  else:
   for item in camLst: VVv6X1.append((item[0], ))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CC7OYT, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CC7OYT, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CC7OYT, "cccam"))
   elif item == "VVzEs2" : self.VVzEs2()
   elif item == "OSCamReaders"  : self.VVL41X("os")
   elif item == "NSCamReaders"  : self.VVL41X("n")
   elif item == "camInfo"   : FFcnSO(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCixMT.VVq8MO(self.session, CC9Pn4.VVgnZ2)
   elif item == "camLiveReaders" : CCixMT.VVq8MO(self.session, CC9Pn4.VVPfeL)
   elif item == "camLiveLog"  : CCixMT.VVq8MO(self.session, CC9Pn4.VVKOVV)
   else       : self.close()
 def VVzEs2(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVsoKC, FFWWBu())
  if fileExists(path):
   lines = FFRtPk("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VV8Lwm = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VV8Lwm("label"    , "CCcam-Line-%d" % ndx))
      f.write(VV8Lwm("description"  , "CCcam-Line-%d" % ndx))
      f.write(VV8Lwm("protocol"   , "cccam"))
      f.write(VV8Lwm("device"    , "%s,%s" % (host, port)))
      f.write(VV8Lwm("user"    , User))
      f.write(VV8Lwm("password"   , Pass))
      f.write(VV8Lwm("fallback"   , "1"))
      f.write(VV8Lwm("group"    , "64"))
      f.write(VV8Lwm("cccversion"   , "2.3.2"))
      f.write(VV8Lwm("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFrNpu(self, "Output = %d Reader%s in:\n\n%s" % (tot, FF2vwS(tot), outFile))
   else:
    FFfad8(self, "No valid CCcam lines", 1500)
  else:
   FFfad8(self, "%s not found" % path, 1500)
 def VVL41X(self, camPrefix):
  VV4Gbf = self.VVi3lo(camPrefix)
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: int(x[0]))
   if self.VVgY6G and self.VVgY6G.startswith(camPrefix):
    VV6vKb = ("Toggle State", self.VVyYAe, [camPrefix], "Changing State ...")
   else:
    VV6vKb = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVK4mA  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VV6vKb=VV6vKb, VVWKtq=True)
 def VVi3lo(self, camPrefix):
  readersFile = self.VVbAn1 + camPrefix + "cam.server"
  VV4Gbf = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFRtPk(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV4Gbf.append((str(len(VV4Gbf) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV4Gbf:
    FFRGBb(self, "No readers found !")
  else:
   FFZBzs(self, readersFile)
  return VV4Gbf
 def VVyYAe(self, VVYo8S, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVbAn1, camPrefix)
  readerState  = VVYo8S.VVN3DQ(1)
  readerLabel  = VVYo8S.VVN3DQ(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCixMT.VVPlyY(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVYo8S.VVxwMk()
    FFRGBb(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV4Gbf = self.VVi3lo(camPrefix)
   if VV4Gbf:
    VVYo8S.VVPCrn(VV4Gbf)
  else:
   VVYo8S.VVxwMk()
 @staticmethod
 def VVPlyY(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFRtPk(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFRGBb(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFRGBb(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFZBzs(SELF, confFile)
   return None
  if not iRequest:
   FFRGBb(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCixMT.VVPO1k(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFRGBb(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVPO1k(SELF):
  if iElem:
   return True
  else:
   FFRGBb(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVq8MO(session, VVF0sb):
  VVbAn1, VVgY6G, VVk5ul, camCommand = CCixMT.VVBoVB()
  if VVgY6G:
   runLog = False
   if   VVF0sb == CC9Pn4.VVgnZ2 : runLog = True
   elif VVF0sb == CC9Pn4.VVPfeL : runLog = True
   elif not VVk5ul          : FFONpl(session, message="SoftCam not started yet!")
   elif fileExists(VVk5ul)        : runLog = True
   else             : FFONpl(session, message="File not found !\n\n%s" % VVk5ul)
   if runLog:
    session.open(BF(CC9Pn4, VVbAn1=VVbAn1, VVgY6G=VVgY6G, VVk5ul=VVk5ul, VVF0sb=VVF0sb))
  else:
   FFONpl(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVBoVB():
  VVbAn1 = "/etc/tuxbox/config/"
  VVgY6G = None
  VVk5ul  = None
  camCommand = FFTbYu("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVgY6G = "oscam"
   elif camCmd.startswith("ncam") : VVgY6G = "ncam"
  if VVgY6G:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFUKzq(path), IGNORECASE)
     if span:
      VVbAn1 = FFiSR4(span.group(1))
      break
   else:
    path = FFTbYu(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFiSR4(path)
    if pathExists(path):
     VVbAn1 = path
   tFile = FFiSR4(VVbAn1) + VVgY6G + ".conf"
   tFile = FFTbYu("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVk5ul = tFile
  return VVbAn1, VVgY6G, VVk5ul, camCommand
class CC7OYT(Screen):
 def __init__(self, VVw4YI, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVbAn1, VVgY6G, VVk5ul, camCommand = CCixMT.VVBoVB()
  if   VVw4YI == "ncam" : self.prefix = "n"
  elif VVw4YI == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVv6X1 = []
  if self.prefix == "":
   VVv6X1.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVv6X1.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVv6X1.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVv6X1.append(("constant.cw"         , "x_constant_cw" ))
   VVv6X1.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVv6X1.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVv6X1.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVv6X1.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVv6X1.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVv6X1.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVv6X1.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVv6X1.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVv6X1.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVv6X1.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVv6X1.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFKFmx(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFKFmx(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFKFmx(self, self.VVbAn1 + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFKFmx(self, self.VVbAn1 + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVXKD7("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVXKD7("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVXKD7("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVXKD7("cam.provid"        )
   elif item == "x_cam_server"  : self.VVXKD7("cam.server"        )
   elif item == "x_cam_services" : self.VVXKD7("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVXKD7("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVXKD7("cam.user"        )
   elif item == "x_VVT41S"   : pass
   elif item == "x_SoftCam_Key" : self.VVIlQQ()
   elif item == "x_CCcam_cfg"  : FFKFmx(self, self.VVbAn1 + "CCcam.cfg"    )
   elif item == "x_VVT41S"   : pass
   elif item == "x_cam_log"  : FFKFmx(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFKFmx(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFKFmx(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVXKD7(self, fileName):
  FFKFmx(self, self.VVbAn1 + self.prefix + fileName)
 def VVIlQQ(self):
  path = self.VVbAn1 + "SoftCam.Key"
  if fileExists(path) : FFKFmx(self, path)
  else    : FFKFmx(self, path.replace(".Key", ".key"))
class CC9Pn4(Screen):
 VVgnZ2  = 0
 VVPfeL = 1
 VVKOVV = 2
 def __init__(self, session, VVbAn1="", VVgY6G="", VVk5ul="", VVF0sb=VVgnZ2):
  self.skin, self.skinParam = FFUxcO(VVvoh9, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVk5ul   = VVk5ul
  self.VVF0sb  = VVF0sb
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVbAn1 + VVgY6G + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVgY6G : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVbAn1, self.camPrefix)
  if self.VVF0sb == self.VVgnZ2:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVF0sb == self.VVPfeL:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFDBTO(self, self.Title, addScrollLabel=True)
  FFjeeE(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVbsTh
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self["myLabel"].VVUfQy(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFjMgg(self)
  self.VVbsTh()
 def onExit(self):
  self.timer.stop()
 def VVNBDG(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5xFY)
  except:
   self.timer.callback.append(self.VV5xFY)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFfad8(self, "Started", 1000)
 def VVPLsS(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV5xFY)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFfad8(self, "Stopped", 1000)
 def VVbsTh(self):
  if self.timerRunning:
   self.VVPLsS()
  else:
   self.VVNBDG()
   if self.VVF0sb == self.VVgnZ2 or self.VVF0sb == self.VVPfeL:
    if self.VVF0sb == self.VVgnZ2 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCixMT.VVPlyY(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFFO8C(self.VV3VBO)
    else:
     self.close()
   else:
    self.VVjYcq()
 def VV5xFY(self):
  if self.timerRunning:
   if   self.VVF0sb == self.VVgnZ2 : self.VVB4K2()
   elif self.VVF0sb == self.VVPfeL : self.VVB4K2()
   else            : self.VVjYcq()
 def VVjYcq(self):
  if fileExists(self.VVk5ul):
   fTime = FFQFpj(os.path.getmtime(self.VVk5ul))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVtbFb(), VVKhCn=VVdsv6)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVk5ul)
 def VV3VBO(self):
  self.VVB4K2()
 def VVB4K2(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFf1xo("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVqskC))
   self.camWebIfErrorFound = True
   self.VVPLsS()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVF0sb == self.VVgnZ2 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFf1xo("Error while parsing data elements !\n\nError = %s" % str(e), VVL1qM)
   self.camWebIfErrorFound = True
   self.VVPLsS()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVqttT(root)
  self["myLabel"].setText(txt, VVKhCn=VVdsv6)
  self["myBar"].setText("Last Update : %s" % FFGSTP())
 def VVqttT(self, rootElement):
  def VV8Lwm(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVF0sb == self.VVgnZ2:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFf1xo(status, VVvsR7)
    else          : status = FFf1xo(status, VVL1qM)
    txt += VVT41S + "\n"
    txt += VV8Lwm("Name"  , name)
    txt += VV8Lwm("Description" , desc)
    txt += VV8Lwm("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV8Lwm("Protocol" , protocol)
    txt += VV8Lwm("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFf1xo("Yes", VVvsR7)
    else    : enabTxt = FFf1xo("No", VVL1qM)
    txt += VVT41S + "\n"
    txt += VV8Lwm("Label"  , label)
    txt += VV8Lwm("Protocol" , protocol)
    txt += VV8Lwm("Enabled" , enabTxt)
  return txt
 def VVtbFb(self):
  lines = FFqfZV("tail -n %d %s" % (100, self.VVk5ul))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVityU + line[:19] + VVe79W + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVQZ69 + "WebIf" + VVe79W)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VV0HRz + h1 + h2 + VVe79W + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVvsR7 + span.group(2) + VVKiZJ + span.group(3) + VVe79W + span.group(4)
    line = self.VVSfiw(line, VVKiZJ, ("(webif)", ))
    line = self.VVSfiw(line, VVKiZJ, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVSfiw(line, VVvsR7, ("OSCam", "NCam", "log switched"))
    line = self.VVSfiw(line, VV8tcv, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVy4op + line[ndx + 3:] + VVe79W
   elif line.startswith("----") or ">>" in line:
    line = FFf1xo(line, VVH2yZ)
   txt += line + "\n"
  return txt
 def VVSfiw(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVe79W + t3
  return line
class CCx11W(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVv6X1 = []
  VVv6X1.append(("Backup Channels"    , "VVSqkt"   ))
  VVv6X1.append(("Restore Channels"    , "Restore_Channels"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Backup SoftCAM Files"   , "VVRDKx" ))
  VVv6X1.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVv6X1.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVv6X1.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Backup Network Settings"  , "VV532q"   ))
  VVv6X1.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVgkK0:
   VVv6X1.append(VVdKVg)
   VVv6X1.append((VVqskC + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVxUya"   ))
   VVv6X1.append((VVvsR7 + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV3UCr) , "createMyIpk"   ))
   VVv6X1.append((VVvsR7 + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV3UCr) , "createMyDeb"   ))
   VVv6X1.append((VV0HRz + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVv6X1.append((VV0HRz + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV9Itp" ))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVSqkt"    : self.VVSqkt()
   elif item == "Restore_Channels"    : self.VV9NMA("channels_backup*.tar.gz", self.VVjo4k, isChan=True)
   elif item == "VVRDKx"   : self.VVRDKx()
   elif item == "Restore_SoftCAM_Files"  : self.VV9NMA("softcam_backup*.tar.gz", self.VVWidh)
   elif item == "Backup_TunerDiSEqC"   : self.VVDHzO("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV9NMA("tuner_backup*.backup", BF(self.VVBgaF, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVDHzO("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV9NMA("hotkey_*backup*.backup", BF(self.VVBgaF, "misc"))
   elif item == "VV532q"    : self.VV532q()
   elif item == "Restore_Network"    : self.VV9NMA("network_backup*.tar.gz", self.VV9W2j)
   elif item == "VVxUya"     : FFWkqs(self, BF(FF0rXP, self, BF(CCx11W.VVxUya, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVqLbw(False)
   elif item == "createMyDeb"     : self.VVqLbw(True)
   elif item == "createMyTar"     : self.VVUPWw()
   elif item == "VV9Itp"   : self.VV9Itp()
 @staticmethod
 def VVxUya(SELF):
  OBF_Path = VVe3YE + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVe3YE, VVGsPD, VV3UCr)
   if err : FFRGBb(SELF, err)
   else : FFipfq(SELF, txt)
  else:
   FFZBzs(SELF, OBF_Path)
 def VVqLbw(self, VVQr59):
  OBF_Path = VVe3YE + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFRGBb(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVe3YE)
  os.system("mv -f %s %s" % (VVe3YE + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVe3YE + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVe3YE + "plugin.py"))
  self.session.openWithCallback(self.VVBZQ9, BF(CC5Nh4, path=VVe3YE, VVQr59=VVQr59))
 def VVBZQ9(self):
  os.system("mv -f %s %s" % (VVe3YE + "OBF/main.py"  , VVe3YE))
  os.system("mv -f %s %s" % (VVe3YE + "OBF/plugin.py" , VVe3YE))
 def VV9Itp(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFRGBb(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFRGBb(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVDcx6("%s*.list" % path)
  if err:
   FFZBzs(self, path + "*.list")
   return
  srcF, err = self.VVDcx6("%s*main_final.py" % path)
  if err:
   FFZBzs(self, path + "*.final.py")
   return
  VVouKi = []
  for f in files:
   f = os.path.basename(f)
   VVouKi.append((f, f))
  FFLwVh(self, BF(self.VVz0gj, path, codF, srcF), VVv6X1=VVouKi)
 def VVz0gj(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFZBzs(self, logF)
   else     : FF0rXP(self, BF(self.VVon4Y, logF, codF, srcF))
 def VVon4Y(self, logF, codF, srcF):
  lst  = []
  lines = FFRtPk(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFRGBb(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV0jSU(lst, logF, newLogF)
  totSrc  = self.VV0jSU(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFipfq(self, txt)
 def VVDcx6(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV0jSU(self, lst, f1, f2):
  txt = FFUKzq(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVUPWw(self):
  VVouKi = []
  VVouKi.append("%s%s" % (VVe3YE, "*.py"))
  VVouKi.append("%s%s" % (VVe3YE, "*.png"))
  VVouKi.append("%s%s" % (VVe3YE, "*.xml"))
  VVouKi.append("%s"  % (VVCsc2))
  FFJy30(self, VVouKi, "%s_%s" % (PLUGIN_NAME, VVGsPD), addTimeStamp=False)
 def VVSqkt(self):
  path1 = VVxlEW
  path2 = "/etc/tuxbox/"
  VVouKi = []
  VVouKi.append("%s%s" % (path1, "*.tv"))
  VVouKi.append("%s%s" % (path1, "*.radio"))
  VVouKi.append("%s%s" % (path1, "*list"))
  VVouKi.append("%s%s" % (path1, "lamedb*"))
  VVouKi.append("%s%s" % (path2, "*.xml"))
  FFJy30(self, VVouKi, self.VVxMRy("channels_backup"), addTimeStamp=True)
 def VVRDKx(self):
  VVouKi = []
  VVouKi.append("/etc/tuxbox/config/")
  VVouKi.append("/usr/keys/")
  VVouKi.append("/usr/scam/")
  VVouKi.append("/etc/CCcam.cfg")
  FFJy30(self, VVouKi, self.VVxMRy("softcam_backup"), addTimeStamp=True)
 def VV532q(self):
  VVouKi = []
  VVouKi.append("/etc/hostname")
  VVouKi.append("/etc/default_gw")
  VVouKi.append("/etc/resolv.conf")
  VVouKi.append("/etc/wpa_supplicant*.conf")
  VVouKi.append("/etc/network/interfaces")
  VVouKi.append("%snameserversdns.conf" % VVxlEW)
  FFJy30(self, VVouKi, self.VVxMRy("network_backup"), addTimeStamp=True)
 def VVxMRy(self, fName):
  img = CC7qsf.VV9tvn()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVjo4k(self, fileName=None):
  if fileName:
   FFWkqs(self, BF(FF0rXP, self, BF(self.VVr8bM, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVr8bM(self, fileName):
  path = "%s%s" % (VVsoKC, fileName)
  if fileExists(path):
   if CCOjzn.VVdIsR(path):
    VV8Ejs , VV4gYP = CCnEIM.VVxE6g()
    VVKWG2, VVOWAH = CCnEIM.VVsgOv()
    cmd  = FFWqNF("cd %s" % VVxlEW) + ";"
    cmd += FFWqNF("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VV4gYP, VVOWAH))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFVJ21()
    if res == 0 : FFrNpu(self, "Channels Restored.")
    else  : FFRGBb(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFRGBb(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFZBzs(self, path)
 def VVWidh(self, fileName=None):
  if fileName:
   FFWkqs(self, BF(self.VVgNtS, fileName), "Overwrite SoftCAM files ?")
 def VVgNtS(self, fileName):
  fileName = "%s%s" % (VVsoKC, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVT41S
   note = "You may need to restart your SoftCAM."
   FFHuBX(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFy8kX(note, VVy4op), sep))
  else:
   FFZBzs(self, fileName)
 def VV9W2j(self, fileName=None):
  if fileName:
   FFWkqs(self, BF(self.VVSZI2, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVSZI2(self, fileName):
  fileName = "%s%s" % (VVsoKC, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF8ZtC(self,  cmd)
  else:
   FFZBzs(self, fileName)
 def VV9NMA(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFs7ER()
  if pathExists(VVsoKC):
   myFiles = FF37hM(VVsoKC, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVouKi = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVouKi.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV3h4q = ("Sat. List", self.VVEijV)
    elif isChan and iTar: VV3h4q = ("Bouquets Importer", CCF1a6.VVJ8gc)
    else    : VV3h4q = None
    FFLwVh(self, callBackFunction, title=title, width=1200, VVv6X1=VVouKi, VV3h4q=VV3h4q, yellowBasePath=VVsoKC)
   else:
    FFRGBb(self, "No files found in:\n\n%s" % VVsoKC, title)
  else:
   FFRGBb(self, "Path not found:\n\n%s" % VVsoKC, title)
 def VVDHzO(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVxlEW
  tCons = CCo0hB()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVQwAL, filePrefix))
 def VVQwAL(self, filePrefix, result, retval):
  title = FFs7ER()
  if pathExists(VVsoKC):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFRGBb(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVsoKC, filePrefix, self.VVxMRy(""), FFWWBu())
    try:
     VVouKi = str(result.strip()).split()
     if VVouKi:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVouKi:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVT41S, FFf1xo(fName, VVy4op), VVT41S)
       FFipfq(self, txt, title=title, VVKhCn=VVdsv6)
      else:
       FFRGBb(self, "File creation failed!", title)
     else:
      FFRGBb(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFWqNF("rm %s" % fName))
     FFRGBb(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFWqNF("rm %s" % fName))
     FFRGBb(self, "Error while writing file.")
  else:
   FFRGBb(self, "Path not found:\n\n%s" % VVsoKC, title)
 def VVBgaF(self, mode, path=None):
  if path:
   path = "%s%s" % (VVsoKC, path)
   if fileExists(path):
    lines = FFRtPk(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFWkqs(self, BF(self.VVKxpq, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFr7wg(self, path, title=FFs7ER())
   else:
    FFZBzs(self, path)
 def VVKxpq(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  isVTi = pathExists(VVBqIe + "VTIPanel")
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    if isVTi and ".dvbs." in line: pass
    else       : finalList.append(line)
  VVdEBn = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajpanel_tmp"
  VVdEBn.append("echo -e 'Reading current settings ...'")
  VVdEBn.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVdEBn.append("echo -e 'Preparing new settings ...'")
  VVdEBn.append(settingsLines)
  VVdEBn.append("echo -e 'Applying new settings ...'")
  VVdEBn.append("mv -f %s %s" % (tFile, sFile))
  FFnBvt(self, VVdEBn)
 def VVEijV(self, VVLmuPObj, path):
  if not path:
   return
  path = VVsoKC + path
  if not fileExists(path):
   FFZBzs(self, path)
   return
  txt = FFUKzq(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFs1xj(item[1]))
   FFipfq(self, txt, title="Satellites List")
  else:
   FFRGBb(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCF1a6():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVJ8gc(SELF, fName):
  bi = CCF1a6(SELF)
  bi.instance = bi
  bi.VV2FLy(SELF, fName)
 @staticmethod
 def VVmD2X(SELF):
  bi = CCF1a6(SELF)
  bi.instance = bi
  bi.VVo4Y9()
 def VV2FLy(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVsoKC + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF0rXP(waitObg, self.VVrJ5u, title="Reading bouquets ...")
  else      : self.VV4dWV(self.filePath)
 def VVa2fj(self, txt) : FFRGBb(self.SELF, txt, title=self.Title)
 def VVy0Oi(self, txt)  : FFfad8(self, txt, 1500)
 def VV4dWV(self, path) : FFZBzs(self.SELF, path, title=self.Title)
 def VVo4Y9(self):
  if pathExists(VVsoKC):
   lst = FF37hM(VVsoKC, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVghN5())
   if len(lst) > 0:
    VVv6X1 = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFf1xo(item, VVKiZJ) if item.endswith(".zip") else item
     VVv6X1.append((txt, item))
    VVv6X1.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVfcYU
    FFLwVh(self.SELF, self.VVHjEm, minRows=3, title=self.Title, width=1200, VVv6X1=VVv6X1, OKBtnFnc=OKBtnFnc, yellowBasePath=VVsoKC, VVyRL8="#22111111", VVmr0Y="#22111111")
   else:
    self.VVa2fj("No valid backup files found in:\n\n%s" % VVsoKC)
  else:
   self.VVa2fj("Backup Directory not found:\n\n%s" % VVsoKC)
 def VVfcYU(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VV2FLy(menuInstance, fName)
 def VVHjEm(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVghN5(self):
  files = FF37hM(VVsoKC, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVrJ5u(self):
  lines, err = CCF1a6.VVZB9b(self.filePath, "bouquets.tv")
  if err:
   self.VVa2fj(err)
   return
  bTvSortLst  = self.VVgQE9(lines)
  lines, err = CCF1a6.VVZB9b(self.filePath, "bouquets.radio")
  if err:
   self.VVa2fj(err)
   return
  bRadSortLst = self.VVgQE9(lines)
  VV4Gbf = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVOvc1(f, mode, len(VV4Gbf), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VV4Gbf.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVOvc1(f, mode, len(VV4Gbf), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVOvc1(f, mode, len(VV4Gbf), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VV4Gbf.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVOvc1(f, mode, len(VV4Gbf), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VV4Gbf): VV4Gbf[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VV4Gbf):
     if key == os.path.basename(row[9]):
      VV4Gbf = VV4Gbf[:ndx+1] + lst + VV4Gbf[ndx+1:]
      break
   for ndx, item in enumerate(VV4Gbf): VV4Gbf[ndx][0] = str(ndx + 1)
   VVOSNp = "#11000600"
   VVXwx9  = ("Show Services" , self.VVQ9b2  , [], "Reading ..." )
   VVTMvN = (""    , self.VVWet1, [])
   VVPogp = ("Options"  , self.VV8MXY, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVK4mA  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFl3hs(self.SELF, None, title=self.Title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=24, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVPogp=VVPogp, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVyRL8=VVOSNp, VVmr0Y=VVOSNp, VVOSNp=VVOSNp, VV5fad="#11ffffff", VVuQjw="#00004455", VVVwZb="#0a282828")
  else:
   self.VVa2fj("No valid bouquets in:\n\n%s" % self.filePath)
 def VVgQE9(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVWet1(self, VVYo8S, title, txt, colList):
  FFipfq(self.SELF, FFtomh(txt), title=title)
 def VV8MXY(self, VVYo8S, title, txt, colList):
  mSel = CC3iyH(self.SELF, VVYo8S)
  if VVYo8S.VVRSSP:
   totSel = VVYo8S.VVTK0J()
   if totSel: VVv6X1 = [("Import %s Bouquet%s" % (FFf1xo(str(totSel), VVvsR7), FF2vwS(totSel)), "imp")]
   else  : VVv6X1 = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFf1xo(bName, VVvsR7)
   VVv6X1 = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF0rXP, VVYo8S, BF(CCF1a6.VVL5Lx, self.SELF, VVYo8S, self.filePath))}
  mSel.VVzccf(VVv6X1, cbFncDict)
 def VVQ9b2(self, VVYo8S, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCF1a6.VVZB9b(self.filePath, "lamedb")
   if err:
    self.VVa2fj(err)
    return
   dbServLst = CCnEIM.VVZXrm(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVYo8S.VVK0Ui()
   lines, err = CCF1a6.VVZB9b(self.filePath, os.path.basename(fName))
   if err:
    self.VVa2fj(err)
    return
   VV4Gbf = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VV4Gbf.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VV4Gbf.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VV4Gbf.append((span.group(1).strip() or "-", "Stream Relay" if FFUUIm(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VV4Gbf.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VV4Gbf.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCnEIM.VVgv6k(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VV4Gbf.append((name.strip() or "-", FFlSfT(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VV4Gbf):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCF1a6.VVZB9b(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VV4Gbf[ndx] = (bName, descr)
   if VV4Gbf:
    VVOSNp = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVK4mA = (LEFT  , CENTER)
    FFl3hs(self.SELF, None, title="Services in : %s" % bName, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VVyRL8=VVOSNp, VVmr0Y=VVOSNp, VVOSNp=VVOSNp, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFfad8(VVYo8S, err, 1500)
  else : VVYo8S.VVxwMk()
 def VVOvc1(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVa2fj("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFUUIm(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVko9g(var):
   return str(var) if var else VVpLjr + str(var)
  totItem = VVy4op + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVqskC   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVKiZJ, "Sub-B."
  else  : bColor, totBnb = ""      , VVko9g(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVko9g(totDVB), VVko9g(totIptv), VVko9g(totSRelay), VVko9g(totLoc), VVko9g(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVL5Lx(SELF, VVYo8S, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVxlEW + "bouquets.tv"
  radBouquetFile = VVxlEW + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFZBzs(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFZBzs(SELF, radBouquetFile, title=title)
   return
  isMulti = VVYo8S.VVRSSP
  if isMulti : rows = VVYo8S.VVEFwV()
  else  : rows = [VVYo8S.VVK0Ui()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFRGBb(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFtomh(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFtomh(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVxlEW + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVxlEW + newFile
    CCF1a6.VVuHRv(archPath, fName, VVxlEW, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCQii3.VVah43(tvBouquetFile)
   CCQii3.VVah43(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCF1a6.VVXPvr(SELF, archPath, bList)
   FFVJ21()
  txt  = FFf1xo("Added:\n", VVKiZJ)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFf1xo("Imported to lamedab:\n", VVKiZJ)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFf1xo("Missing from archived lamedb:\n", VVqskC)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFipfq(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVXPvr(SELF, archPath, bList):
  VV8Ejs, err = CCnEIM.VV3Wwr(SELF, VV1pA1=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCnEIM.VVr02f(VV8Ejs, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFRtPk(VVxlEW + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCnEIM.VVgv6k(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCnEIM.VVut0G(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCF1a6.VVqd5D(archPath, dbName)
   CCF1a6.VVuHRv(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCnEIM.VVr02f(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCnEIM.VVr02f(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCnEIM.VVr02f(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCnEIM.VVr02f(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFsF1P(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VV8Ejs + ".tmp"
   lines   = FFRtPk(VV8Ejs)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFWqNF("mv -f '%s' '%s'" % (tmpDbFile, VV8Ejs)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVX1zq(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVqd5D(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVuHRv(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVZB9b(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCgqIF(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVonST, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVv6X1 = []
  VVv6X1.append(("Plugins Browser List"       , "VVhRE6"   ))
  VVv6X1.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVv6X1.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVv6X1.append(("Remove Packages (show all)"     , "VVLySgsAll"   ))
  VVv6X1.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Update Packages List from Feed"    , "VVkC1M"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Packaging Tool"        , "VVMuxn"    ))
  VVv6X1.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVhRE6"   : self.VVhRE6()
   elif item == "pluginsMenus"     : self.VVjgbK(0)
   elif item == "pluginsStartup"    : self.VVjgbK(1)
   elif item == "pluginsDirList"    : self.VVOqhd()
   elif item == "downloadInstallPackages"  : FF0rXP(self, BF(self.VVccrQ, 0, ""))
   elif item == "VVLySgsAll"   : FF0rXP(self, BF(self.VVccrQ, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF0rXP(self, BF(self.VVccrQ, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVkC1M"   : CCgqIF.VVkC1M(self)
   elif item == "VVMuxn"    : self.VVMuxn()
   elif item == "packagesFeeds"    : self.VVRefn()
   else          : self.close()
 def VVOqhd(self):
  extDirs  = FFYR05(VVUsb0)
  sysDirs  = FFYR05(VVBqIe)
  VVouKi  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVouKi.append((item, VVUsb0 + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVouKi.append((item, VVBqIe + item))
  if VVouKi:
   VVouKi.sort(key=lambda x: x[0].lower())
   VVPogp = ("Package Info.", self.VVYeNn, [])
   VVxkVZ = ("Open in File Manager", BF(self.VVa9QZ, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFl3hs(self, None, header=header, VVouKi=VVouKi, VVw7oP=widths, VVcK4p=28, VVPogp=VVPogp, VVxkVZ=VVxkVZ)
  else:
   FFRGBb(self, "Nothing found!")
 def VVYeNn(self, VVYo8S, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVUsb0) : loc = "extensions"
  elif path.startswith(VVBqIe) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVqqqH(package)
  else:
   FFRGBb(self, "No info!")
 def VVRefn(self):
  pkg = FF6lF9()
  if pkg : FFYYbP(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF2yhz(self)
 def VVhRE6(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV8Lwm(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVT41S + "\n"
    txt += VV8Lwm("Number"   , str(c))
    txt += VV8Lwm("Name"   , FFf1xo(str(p.name), VVy4op))
    txt += VV8Lwm("Path"  , p.path  )
    txt += VV8Lwm("Description" , p.description )
    txt += VV8Lwm("Icon"  , p.iconstr  )
    txt += VV8Lwm("Wakeup Fnc" , p.wakeupfnc )
    txt += VV8Lwm("NeedsRestart", p.needsRestart)
    txt += VV8Lwm("Internal" , p.internal )
    txt += VV8Lwm("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFipfq(self, txt)
 def VVjgbK(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVouKi = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVouKi.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVouKi:
   VVouKi.sort(key=lambda x: x[0].lower())
   VVxkVZ = ("Open in File Manager", BF(self.VVa9QZ, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFl3hs(self, None, title=title, header=header, VVouKi=VVouKi, VVw7oP=widths, VVcK4p=26, VVxkVZ=VVxkVZ)
  else:
   FFRGBb(self, "Nothing Found", title=title)
 def VVa9QZ(self, pathColNum, VVYo8S, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCOjzn, mode=CCOjzn.VVKizH, VVOgpG=path)
  else    : FFfad8(VVYo8S, "Path not found !", 1500)
 @staticmethod
 def VVkC1M(SELF):
  cmd = FFrxPD(VVi3Ri, "")
  if cmd : FF8ZtC(SELF, cmd, checkNetAccess=True)
  else : FF2yhz(SELF)
 def VVMuxn(self):
  pkg = FF6lF9()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFrNpu(self, txt)
 def VVccrQ(self, mode, grep, VVYo8S=None, title=""):
  if   mode == 0: cmd = FFrxPD(VVe6Xo    , grep)
  elif mode == 1: cmd = FFrxPD(VVmMeS , grep)
  elif mode == 2: cmd = FFrxPD(VVmMeS , grep)
  if not cmd:
   FF2yhz(self)
   return
  VV4Gbf = FFqfZV(cmd)
  if not VV4Gbf:
   if VVYo8S: VVYo8S.VVxwMk()
   FFRGBb(self, "No packages found!")
   return
  elif len(VV4Gbf) == 1 and VV4Gbf[0] == VVngly:
   FFRGBb(self, VVngly)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVouKi  = []
  for item in VV4Gbf:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVouKi.append((name, package, version))
  if mode > 0:
   extensions = FFqfZV("ls %s -l | grep '^d' | awk '{print $9}'" % VVUsb0)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVouKi:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVouKi.append((name, VVUsb0 + item, "-"))
   systemPlugins = FFqfZV("ls %s -l | grep '^d' | awk '{print $9}'" % VVBqIe)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVouKi:
      if item.lower() == row[0].lower():
       break
     else:
      VVouKi.append((item, VVBqIe + item, "-"))
  if not VVouKi:
   FFRGBb(self, "No packages found!")
   return
  if VVYo8S:
   VVouKi.sort(key=lambda x: x[0].lower())
   VVYo8S.VVPCrn(VVouKi, title)
  else:
   widths = (20, 50, 30)
   VV6vKb = None
   VVxkVZ = None
   if mode == 0:
    VVtXvO = ("Install" , self.VV25wp   , [])
    VV6vKb = ("Download" , self.VVhX5n   , [])
    VVxkVZ = ("Filter"  , self.VVEuSt , [])
   elif mode == 1:
    VVtXvO = ("Uninstall", self.VVLySg, [])
   elif mode == 2:
    VVtXvO = ("Uninstall", self.VVLySg, [])
    widths= (18, 57, 25)
   VVouKi.sort(key=lambda x: x[0].lower())
   VVPogp = ("Package Info.", self.VVt6zF, [])
   header   = ("Name" ,"Package" , "Version" )
   FFl3hs(self, None, header=header, VVouKi=VVouKi, VVw7oP=widths, VVcK4p=28, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVUkBS=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVyRL8="#22110011", VVmr0Y="#22191111", VVOSNp="#22191111", VVuQjw="#00003030", VVVwZb="#00333333")
 def VVt6zF(self, VVYo8S, title, txt, colList):
  package = colList[1]
  self.VVqqqH(package)
 def VVEuSt(self, VVYo8S, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVv6X1 = []
  VVv6X1.append(("All Packages", "all"))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVv6X1.append(VVdKVg)
  for word in words:
   VVv6X1.append((word, word))
  FFLwVh(self, BF(self.VVyvLQ, VVYo8S), VVv6X1=VVv6X1, title="Select Filter")
 def VVyvLQ(self, VVYo8S, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF0rXP(VVYo8S, BF(self.VVccrQ, 0, grep, VVYo8S, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVLySg(self, VVYo8S, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVUsb0, VVBqIe)):
   FFWkqs(self, BF(self.VVEHiB, VVYo8S, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVv6X1 = []
   VVv6X1.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVv6X1.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVv6X1.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFLwVh(self, BF(self.VVxB1k, VVYo8S, package), VVv6X1=VVv6X1)
 def VVEHiB(self, VVYo8S, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVpXho)
  FF8ZtC(self, cmd, VVo3en=BF(self.VVVSBy, VVYo8S))
 def VVxB1k(self, VVYo8S, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVdipQ
   elif item == "remove_ForceRemove"  : cmdOpt = VV4yPs
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVnbOp
   FFWkqs(self, BF(self.VVGXgd, VVYo8S, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVGXgd(self, VVYo8S, package, cmdOpt):
  self.lastSelectedRow = VVYo8S.VVjpse()
  cmd = FFohUm(cmdOpt, package)
  if cmd : FF8ZtC(self, cmd, VVo3en=BF(self.VVVSBy, VVYo8S))
  else : FF2yhz(self)
 def VVVSBy(self, VVYo8S):
  VVYo8S.cancel()
  FFuDkg()
 def VV25wp(self, VVYo8S, title, txt, colList):
  package  = colList[1]
  VVv6X1 = []
  VVv6X1.append(("Install Package"         , "install_CheckVersion" ))
  VVv6X1.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVv6X1.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVv6X1.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVv6X1.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFLwVh(self, BF(self.VVwCPk, package), VVv6X1=VVv6X1)
 def VVwCPk(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VViQjU
   elif item == "install_ForceReinstall" : cmdOpt = VVaj7G
   elif item == "install_ForceOverwrite" : cmdOpt = VVTIdG
   elif item == "install_ForceDowngrade" : cmdOpt = VVQVWS
   elif item == "install_IgnoreDepends" : cmdOpt = VVlNe9
   FFWkqs(self, BF(self.VVQP06, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVQP06(self, package, cmdOpt):
  cmd = FFohUm(cmdOpt, package)
  if cmd : FF8ZtC(self, cmd, VVo3en=FFuDkg, checkNetAccess=True)
  else : FF2yhz(self)
 def VVhX5n(self, VVYo8S, title, txt, colList):
  package  = colList[1]
  FFWkqs(self, BF(self.VVP5dN, package), "Download Package ?\n\n%s" % package)
 def VVP5dN(self, package):
  if FFGXQq():
   cmd = FFohUm(VVeiVb, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFy8kX(success, VVvsR7))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFy8kX(fail, VVL1qM))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF8ZtC(self, cmd, VVaAze=[VVL1qM, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF2yhz(self)
  else:
   FFRGBb(self, "No internet connection !")
 def VVqqqH(self, package):
  infoCmd  = FFohUm(VV9TTi, package)
  filesCmd = FFohUm(VVXRXE, package)
  listInstCmd = FFrxPD(VVmMeS, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF743i(VVy4op)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFy8kX(notInst, VVqskC))
   cmd += "else "
   cmd +=   FFaNdy("System Info", VVy4op)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFaNdy("Related Files", VVy4op)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFXvUZ(self, cmd)
  else:
   FF2yhz(self)
class CCwXmk():
 def VV6g85(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VV2QH2()
 def VV2QH2(self):
  files = FF37hM(VVsoKC, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVv6X1 = []
   for fil in files:
    VVv6X1.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVyRL8, VVmr0Y = "#22221133", "#22221133"
   else    : VVyRL8, VVmr0Y = "#22003344", "#22002233"
   VV3h4q  = ("Add new File", self.VV5Aov)
   FFLwVh(self, self.VVSK8s, VVv6X1=VVv6X1, width=1100, VV3h4q=VV3h4q, yellowBasePath="", minRows=4, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y)
  else:
   FFWkqs(self, self.VVnwNI, "No files found.\n\nCreate a new file ?")
 def VVnwNI(self):
  path = self.VVkauh()
  if fileExists(path) : self.VV2QH2()
  else    : FFfad8(self, "Cannot create file", 1500)
 def VV5Aov(self, menuInstance, path):
  path = self.VVkauh()
  menuInstance.VVDk4Z((os.path.basename(path), path), isSort=True)
 def VVkauh(self):
  path = "%s%s%s.xml" % (VVsoKC, self.shareFilePrefix, FFWWBu())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVSK8s(self, path=None):
  if path:
   FF0rXP(self, BF(self.VVp5IO, path))
 def VVp5IO(self, path):
  if not fileExists(path):
   FFZBzs(self, path)
   return
  elif not CCOjzn.VVAreK(self, path, FFs7ER()):
   return
  else:
   self.shareFilePath = path
  if not CCixMT.VVPO1k(self):
   return
  tree = CCnEIM.VVm3pv(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCQii3.VVmVK4()
  def VV8Lwm(refCode):
   if   FFkFSJ(refCode): return FFf1xo("DVB", VVkC8X)
   elif refCode in refLst     : return FFf1xo("IPTV", VVkC8X)
   else         : return ""
  VV4Gbf= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVHNLV(ch)
   if ok:
    srcTxt = VV8Lwm(srcRef)
    dstTxt = VV8Lwm(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VV4Gbf:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VV4Gbf.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VV4Gbf:
   if self.shareIsRef : VVyRL8, VVmr0Y, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVyRL8, VVmr0Y, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVxKfW = (""    , BF(self.VVa5Ni, dupl), [])
   VVTMvN = (""    , self.VVxxjG    , [])
   VVtXvO = ("Delete Entry" , self.VV3DSJ   , [])
   VV6vKb = ("Add Entry"  , self.VVhvIB   , [])
   VVPogp = (optTxt   , self.VV6T1H  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVK4mA = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVYo8S = FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=24, VVxKfW=VVxKfW, VVTMvN=VVTMvN, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVWKtq=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVmr0Y, VV5fad="#00ffffaa", VVuQjw="#0a000000")
  else:
   FFRGBb(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVa5Ni(self, dupl, VVYo8S, title, txt, colList):
  if dupl:
   VVYo8S.VVu9dh("Skipped %d duplicate%s" % (dupl, FF2vwS(dupl)), 2000)
 def VVxxjG(self, VVYo8S, title, txt, colList):
  def VV8Lwm(key, val): return "%s\t: %s\n" % (key, val or FFf1xo("?", VV8tcv))
  Keys = VVYo8S.VVe3lP()
  Vals = VVYo8S.VVK0Ui()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VV8Lwm(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVvsR7, VV8tcv
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFipfq(self, txt + txt1, title=title)
 def VVHNLV(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VV3DSJ(self, VVYo8S, title, txt, colList):
  if VVYo8S.VVjpse() == 0 and VVYo8S.VVDPuF() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFWkqs(self, BF(self.VVn5dp, isLast, VVYo8S), ques)
 def VVn5dp(self, isLast, VVYo8S):
  if isLast:
   FFsF1P(self.shareFilePath)
   VVYo8S.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVYo8S.VVK0Ui()
   if self.VVP7Tk(srcName, srcRef, dstName, dstRef):
    VVYo8S.VVtGy5()
    VVYo8S.VVUlfa()
    FFfad8(VVYo8S, "Deleted", 500, isGrn=True)
   else:
    FFfad8(VVYo8S, "Cannot delete from file", 2000)
 def VVhvIB(self, VVYo8S, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VV0Acm(VVYo8S, isDvb=True)
  else    : self.VVsraA(VVYo8S, "Source Channel", "#22003344", "#22002233")
 def VVsraA(self, mainTableInst, title, VVyRL8, VVmr0Y):
  FFLwVh(self, BF(self.VVq8c5, mainTableInst, title), VVv6X1=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y)
 def VVq8c5(self, mainTableInst, title, item=None):
  if item:
   FF0rXP(mainTableInst, BF(self.VVrXQS, mainTableInst, title, item), clearMsg=False)
 def VVrXQS(self, mainTableInst, title, item):
  FFfad8(mainTableInst)
  if item == "DVB": self.VV0Acm(mainTableInst, isDvb=True)
  else   : self.VV0Acm(mainTableInst, isDvb=False)
 def VVgO64(self, mainTableInst, chType, VVYo8S, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVYo8S.VVjpse()
  if   chType == "DVB" : FFcghP(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFcghP(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVl6T3()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFRGBb(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV04V3(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVrN9N((str(mainTableInst.VVDPuF() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFfad8(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFfad8(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFfad8(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VV0Acm(mainTableInst, isDvb=False)
   else    : FFFO8C(BF(self.VVsraA, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVYo8S.cancel()
 def VVDVA6(self, item, VVYo8S, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVYo8S.VVG9tX(ndx)
 def VV0Acm(self, VVYo8S, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVgO64, VVYo8S, typ)
  doneFnc = BF(self.VVDVA6, typ)
  if isDvb: CCwXmk.VVIJk5(VVYo8S , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCwXmk.VV3IIJ(VVYo8S, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVIJk5(SELF, title, okFnc, doneFnc=None):
  FF0rXP(SELF, BF(CCwXmk.VVaOYu, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVaOYu(SELF, title, okFnc, doneFnc=None):
  VV4Gbf, err = CCnEIM.VVxj6i(SELF, CCnEIM.VVzMku)
  if VV4Gbf:
   color = "#0a000022"
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVXwx9 = ("Select" , okFnc, [])
   VVxKfW= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVK4mA = (LEFT  , LEFT  , CENTER, LEFT    )
   FFl3hs(SELF, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVyRL8=color, VVmr0Y=color, VVOSNp=color, VVXwx9=VVXwx9, VVxKfW=VVxKfW, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFRGBb(SELF, "No DVB Services !")
 @staticmethod
 def VV3IIJ(SELF, title, okFnc, doneFnc=None):
  FF0rXP(SELF, BF(CCwXmk.VVxZsy, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVxZsy(SELF, title, okFnc, doneFnc=None):
  VV4Gbf = CCwXmk.VVa4T9()
  if VV4Gbf:
   color = "#0a112211"
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVXwx9 = ("Select" , okFnc, [])
   VVxKfW= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFl3hs(SELF, None, title=title, header=header, VVouKi=VV4Gbf, VVw7oP=widths, VVcK4p=26, VVyRL8=color, VVmr0Y=color, VVOSNp=color, VVXwx9=VVXwx9, VVxKfW=VVxKfW, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFRGBb(SELF, "No IPTV Services !")
 @staticmethod
 def VVa4T9():
  VV4Gbf = []
  files  = CCCGrE.VV2TEe()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFUKzq(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVwRnH = span.group(1)
    else : VVwRnH = ""
    VVwRnH_lCase = VVwRnH.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VV4Gbf.append((chName, VVwRnH, url, refCode))
  return VV4Gbf
 def VV04V3(self, srcName, srcRef, dstName, dstRef):
  tree = CCnEIM.VVm3pv(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVQqxE(tree, root)
  return True
 def VVP7Tk(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCnEIM.VVm3pv(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVHNLV(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVQqxE(tree, root)
  return found
 def VVQqxE(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCnEIM.VVxdL8(xmlTxt)
  parser = CCnEIM.CCcO82()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV6T1H(self, VVYo8S, title, txt, colList):
  if self.onlyEpg:
   self.VVZOdc(VVYo8S, "epg")
  else:
   if self.shareIsRef:
    FFWkqs(self, BF(FF0rXP, VVYo8S, BF(self.VVfg8X, VVYo8S)), "Copy all References from Source to Destination ?")
   else:
    VVv6X1 = []
    VVv6X1.append(("Copy EPG\t (All List)" , "epg"  ))
    VVv6X1.append(("Copy Picons\t (All List)" , "picon" ))
    FFLwVh(self, BF(self.VVZOdc, VVYo8S), VVv6X1=VVv6X1, width=1000)
 def VVZOdc(self, VVYo8S, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVERga  , "EPG"
   elif item == "picon": fnc, txt = self.VVieJx , "PIcons"
   title = "Copy %s" % txt
   tot   = VVYo8S.VVDPuF()
   FFWkqs(self, BF(FF0rXP, VVYo8S, BF(fnc, VVYo8S, title)), "Overwrite %s for %d Service%s ?" % (FFf1xo(txt, VVy4op), tot, FF2vwS(tot)), title=title)
 def VVfg8X(self, VVYo8S):
  files = CCCGrE.VV2TEe()
  totChange = 0
  if files:
   for path in files:
    txt = FFUKzq(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVYo8S.VVl6T3():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFVJ21()
  tot = VVYo8S.VVDPuF()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFipfq(self, txt)
 def VVieJx(self, VVYo8S, title):
  if not iCopyfile:
   FFRGBb(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCxA8L.VV76e0()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVYo8S.VVl6T3():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVYo8S.VVDPuF()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFipfq(self, txt, title=title)
 def VVERga(self, VVYo8S, title):
  txt, err = CC8oCo.VVnqd0(VVYo8S)
  if err : FFRGBb(self, err, title=title)
  else : FFipfq(self, txt, title=title)
 class CCcO82(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVm3pv(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCnEIM.CCcO82())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFf1xo("XML Parse Error in:", VV8tcv), path)
   txt += "%s\n%s\n\n" % (FFf1xo("Error:", VV8tcv), str(e))
   FFipfq(SELF, txt, VVOSNp="#11220000", title=title)
   return None
 @staticmethod
 def VVxdL8(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CC8oCo(Screen, CCwXmk):
 VVgS00  = "BDTSE"
 VV9Rvv   = "save"
 VV3Sxy   = "load"
 VVNv7q  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VVonST, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CC8oCo.VV85lO()
  qUrl, iptvRef = CCCGrE.VVp7NB(self)
  VVv6X1 = []
  VVv6X1.append((VVkC8X + "Cache File Info." , "inf"))
  VVv6X1.append(VVdKVg)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVv6X1.append((t1, self.VV9Rvv))
   VVv6X1.append((t2, self.VV3Sxy))
  else:
   VVv6X1.append((t1, ))
   VVv6X1.append((t2, ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((VVqskC + "Delete EPG (from RAM only)", self.VVNv7q))
  VVv6X1.append(VVdKVg)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVv6X1.append((txt, "refreshIptvEPG" ))
  else        : VVv6X1.append((txt,     ))
  VVv6X1.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Translate Current Channel EPG %s(Experimental)" % VVqskC, "VVSD1t"))
  FFDBTO(self, VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVpLSE()
   elif item in (self.VV9Rvv, self.VV3Sxy, self.VVNv7q):
    reset = item == self.VV3Sxy
    FFWkqs(self, BF(FF0rXP, self, BF(self.VVrOf5, item, reset)), VVfTYp="Continue ?")
   elif item == "refreshIptvEPG"  : CCCGrE.VV3khE(self)
   elif item == "VVSD1t" : self.VVSD1t()
   elif item == "copyEpg"    : self.VV6g85(False, onlyEpg=True)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVrOf5(self, act, reset=False):
  ok = CC8oCo.VVES7A(act)
  if ok:
   if reset:
    CC8oCo.VViJct(self)
   FFrNpu(self, "Done")
  else:
   FFrNpu(self, "Failed!")
 def VVpLSE(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CC8oCo.VV85lO()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFf1xo("File not found (check System EPG settings).", VVqskC))
   FFipfq(self, txt, title=title)
  else:
   FFRGBb(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVhEw8():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVSD1t(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVXwx9  = (""  , BF(self.VVaj8H, title, True) , [])
  VV6vKb = ("Start" , BF(self.VVaj8H, title, False), [])
  VVxkVZ = ("Change Language", self.VVuYGb      , [])
  widths  = (70 , 30)
  VVK4mA = (LEFT , CENTER)
  FFl3hs(self, None, title=title, VVouKi=self.VVnqq6(), VVK4mA=VVK4mA, VVw7oP=widths, width=1200, vMargin=20, VVcK4p=30, VVXwx9=VVXwx9, VV6vKb=VV6vKb, VVxkVZ=VVxkVZ, VVJevj=2
    , VVyRL8="#11201010", VVmr0Y=bg, VVOSNp=bg, VV5fad="#00ffffaa", VVuQjw="#00004455", VVVwZb=bg)
 def VVnqq6(self):
  Def, ch = "DISABLED", dict(CC8oCo.VVhEw8())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVouKi = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVouKi
 def VVuYGb(self, VVYo8S, title, txt, colList):
  ndx = VVYo8S.VVjpse()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCLmoH.VVgq2y(self, confItem, title, lst=CC8oCo.VVhEw8(), cbFnc=BF(self.VV2lQI, VVYo8S))
 def VV2lQI(self, VVYo8S):
  for ndx, row in enumerate(self.VVnqq6()):
   VVYo8S.VVLdUA(ndx, row)
 def VVaj8H(self, Title, isAsk, VVYo8S, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFfad8(VVYo8S, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
   refCode, evList, err = CC8oCo.VVZLWy(refCode)
   fnc = BF(self.VVoGiv, Title, refCode, evList, VVYo8S)
   if   err : FFRGBb(self, err, title=Title)
   elif isAsk : FFWkqs(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVoGiv(self, title, refCode, evList, VVYo8S):
  self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV0GG7, evList)
      , VVkuAk = BF(self.VVzKad, title, refCode))
  VVYo8S.cancel()
 def VV0GG7(self, evList, VVtdJ0):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVtdJ0.VVhRNu(totEv)
  VVtdJ0.VVwHZ6 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CC8oCo.VVrvmV(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1)
   VVtdJ0.VV5aV1(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVtdJ0.VVwHZ6 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVzKad(self, title, refCode, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVwHZ6
  if newLst: totEv, totOK = CC8oCo.VVflYv(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CC8oCo.VV7k3H()
   CC8oCo.VViJct(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFipfq(self, txt, title=title)
 @staticmethod
 def VVrvmV(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VV8Lwm(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CC8oCo.VVmeWx(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VV8Lwm, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVmeWx(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFAPsb(txt))
   txt, err = CCCGrE.VVcPPT(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFT8KE(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CC8oCo.VVZ2zo(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VV85lO():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFDH0v(path)
   szTxt = CCOjzn.VV7GBO(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VV0iNT():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VV7k3H(): CC8oCo.VVES7A(CC8oCo.VV9Rvv)
 @staticmethod
 def VVES7A(act):
  ec, inst = CC8oCo.VV0iNT()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VViJct(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVZLWy(refCode):
  ec, inst = CC8oCo.VV0iNT()
  if inst:
   try:
    evList = inst.lookupEvent([CC8oCo.VVgS00, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVflYv(refCode, events, longDescDays=0):
  ec, inst = CC8oCo.VV0iNT()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVles6(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CC8oCo.VV0iNT()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CC8oCo.VVof3n(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCWhEO.CC8oCo(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVof3n(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CC8oCo.VVx8cF(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVcHFq(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CC8oCo.VV0iNT()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CC8oCo.VVof3n(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFQFpj(evTime)
       evEndTxt  = FFQFpj(evEnd)
       evDurTxt  = FFD88e(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFD88e(evPos)
        evRem = evEnd - now
        evRemTxt = FFD88e(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFD88e(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVx8cF(event):
  genre = PR = ""
  try:
   genre  = CC8oCo.VVYSed(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CC8oCo.VVNGkx(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVNGkx(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVYSed(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CC8oCo.VVSRr8()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVSRr8():
  path = VVCsc2 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFUKzq(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFUKzq(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVnqd0(self, VVYo8S, title):
  ec, inst = CC8oCo.VV0iNT()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVYo8S.VVl6T3():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CC8oCo.VVgS00, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CC8oCo.VVflYv(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CC8oCo.VV7k3H()
  txt  = "Services\t: %d\n"  % VVYo8S.VVDPuF()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVTOJZ(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CC8oCo.VVitdn(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CC8oCo.VVitdn(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CC8oCo.VVitdn(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVitdn(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8oCo.VVof3n(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CC8oCo.VVrvmV(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFf1xo(evName, VVKiZJ)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFf1xo(evNameTransl, VVKiZJ))
    if evTime           : txt += "Start Time\t: %s\n" % FFQFpj(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFQFpj(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFD88e(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFD88e(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFD88e(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFf1xo(evShort, VVq8cV)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFf1xo(evDesc , VVq8cV)
    if txt:
     txt = FFf1xo("\n%s\n%s Event:\n%s\n" % (VVT41S, ("Current", "Next")[evNum], VVT41S), VVKiZJ) + txt
  return txt
 @staticmethod
 def VVZ2zo(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCnEIM(Screen, CCwXmk):
 VVAjcf  = 0
 VVoFun = 1
 VViulY  = 2
 VVl5J9  = 3
 VVkkKN = 4
 VVKXFu = 5
 VVmtt4 = 6
 VVzMku   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VVonST, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVvBc2 = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVv6X1 = self.VVVkCu()
  FFDBTO(self, VVv6X1=VVv6X1, title="Services/Channels")
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self["myMenu"].setList(self.VVVkCu())
  FFIpXz(self["myMenu"])
  FFhukk(self)
 def VVVkCu(self):
  VVv6X1 = []
  c = VVkC8X
  VVv6X1.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVv6X1.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVv6X1.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVv6X1.append(VVdKVg)
  c = VVKiZJ
  VVv6X1.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVv6X1.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVv6X1.append((VV8tcv + "More tables ..."     , "VVt0IT"    ))
  c = VVq8cV
  VVv6X1.append(VVdKVg)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVv6X1.append((c + txt          , "VVmD2X"  ))
  else : VVv6X1.append((txt           ,          ))
  VVv6X1.append((c + 'Export Services to "channels.xml"'    , "VVzslg"      ))
  VVv6X1.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVityU
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVv6X1.append((c + "Invalid Services Cleaner"       , "VV59Y4"    ))
  c = VVityU
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c + "Delete Channels with no names"     , "VVTqPr"    ))
  VVv6X1.append((c + "Delete Empty Bouquets"       , "VVSX0M"     ))
  VVv6X1.append(VVdKVg)
  VV8Ejs, VV4gYP = CCnEIM.VVxE6g()
  if fileExists(VV8Ejs):
   enab = fileExists(VV4gYP)
   if enab: VVv6X1.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVv6X1.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVv6X1.append(("Reset Parental Control Settings"      , "VVE7xi"    ))
  VVv6X1.append(("Reload Channels and Bouquets"       , "VVdmdC"      ))
  return VVv6X1
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCSeoi.VVLNOL(self.session)
   elif item == "openSignal"       : FF7oMJ(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFwYti(self, fncMode=CCWhEO.VV9IGI)
   elif item == "lameDB_allChannels_with_refCode"  : FF0rXP(self, self.VVqLGL)
   elif item == "lameDB_allChannels_with_tranaponder" : FF0rXP(self, self.VVIBl1)
   elif item == "VVt0IT"     : self.VVt0IT()
   elif item == "VVmD2X"  : CCF1a6.VVmD2X(self)
   elif item == "VVzslg"      : self.VVzslg()
   elif item == "copyEpgPicons"      : self.VV6g85(False)
   elif item == "SatellitesCleaner"     : FF0rXP(self, self.FF0rXP_SatellitesCleaner)
   elif item == "VV59Y4"    : FF0rXP(self, BF(self.VV59Y4))
   elif item == "VVTqPr"    : FF0rXP(self, self.VVTqPr)
   elif item == "VVSX0M"     : self.VVSX0M(self)
   elif item == "enableHiddenChannels"     : self.VVFdaK(True)
   elif item == "disableHiddenChannels"    : self.VVFdaK(False)
   elif item == "VVE7xi"    : FFWkqs(self, self.VVE7xi, "Reset and Restart ?")
   elif item == "VVdmdC"      : FF0rXP(self, BF(CCnEIM.VVdmdC, self))
 def VVt0IT(self):
  VVv6X1 = []
  VVv6X1.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVv6X1.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVv6X1.append(("Services with PIcons for the System"  , "VVB31O"     ))
  VVv6X1.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVv6X1.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFLwVh(self, self.VVCJDb, VVv6X1=VVv6X1, title="Service Information", VVrAw7=True)
 def VVCJDb(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF0rXP(self, BF(self.VVLM2C, title))
   elif ref == "parentalControlChannels"   : FF0rXP(self, BF(self.VVElIC, title))
   elif ref == "showHiddenChannels"    : FF0rXP(self, BF(self.VV0UAr, title))
   elif ref == "VVB31O"    : FF0rXP(self, BF(self.VVhnPB, title))
   elif ref == "servicesWithMissingPIcons"   : FF0rXP(self, BF(self.VVh8jP, title))
   elif ref == "TranspondersStats"     : FF0rXP(self, BF(self.VVuFXb, title))
   elif ref == "SatellitesXmlStats"    : FF0rXP(self, BF(self.VViNAZ, title))
 def VVzslg(self):
  VVv6X1 = []
  VVv6X1.append(("All DVB-S/C/T Services", "all"))
  VVv6X1.extend(CCQii3.VVkefo())
  FFLwVh(self, self.VVxNbp, VVv6X1=VVv6X1, title="", VVrAw7=True)
 def VVxNbp(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCnEIM.VVXeSW("1:7:")
   else   : lst = FFWeXA(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFlSfT(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFUUIm(r)  : sat = "Stream Relay"
       elif FFW8kf(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFiSR4(CFG.exportedTablesPath.getValue()), FFWWBu())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFrNpu(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFfad8(self, "No Services found !", 1500)
 @staticmethod
 def VVdmdC(SELF):
  FFVJ21()
  FFrNpu(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVqLGL(self):
  self.VVvBc2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCFC3v(self)
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVAjcf)
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVXwx9  = ("Zap"   , self.VVYNx9     , [])
   VVTMvN = (""    , self.VVdiVI   , [])
   VVPogp = ("Options"  , self.VVyhQm , [])
   VV6vKb = ("Current Service", self.VVMkYc , [])
   VVxkVZ = ("Filter"   , self.VVErve  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVK4mA  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindServices)
 def VVIBl1(self):
  self.VVvBc2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCFC3v(self)
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVoFun)
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVXwx9  = ("Zap"   , self.VVYNx9      , [])
   VVTMvN = (""    , self.VVdiVI    , [])
   VV6vKb = ("Current Service", self.VVMkYc  , [])
   VVPogp = ("Options"  , self.VV1SYJ , [])
   VVxkVZ = ("Filter"   , self.VVzLvT  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVK4mA  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindServices)
 def VVyhQm(self, VVYo8S, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC3iyH(self, VVYo8S)
  VVv6X1 = []
  isMulti = VVYo8S.VVRSSP
  if isMulti:
   refCodeList = VVYo8S.VVZ4YI(3)
   if refCodeList:
    VVv6X1.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVv6X1.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVv6X1.append(VVdKVg)
    VVv6X1.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVv6X1.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVv6X1.append(VVdKVg)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVv6X1.append((txt1, "parentalControl_add" ))
    VVv6X1.append((txt2,       ))
   else:
    VVv6X1.append((txt1,       ))
    VVv6X1.append((txt2, "parentalControl_remove"))
   VVv6X1.append(VVdKVg)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVv6X1.append((txt1, "hiddenServices_add" ))
    VVv6X1.append((txt2,       ))
   else:
    VVv6X1.append((txt1,       ))
    VVv6X1.append((txt2, "hiddenServices_remove" ))
   VVv6X1.append(VVdKVg)
  cbFncDict = { "parentalControl_add"   : BF(self.VVwIA7, VVYo8S, refCode, True)
     , "parentalControl_remove"  : BF(self.VVwIA7, VVYo8S, refCode, False)
     , "hiddenServices_add"   : BF(self.VV8V9q, VVYo8S, refCode, True)
     , "hiddenServices_remove"  : BF(self.VV8V9q, VVYo8S, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVJ2U7, VVYo8S, True)
     , "parentalControl_sel_remove" : BF(self.VVJ2U7, VVYo8S, False)
     , "hiddenServices_sel_add"  : BF(self.VVFzfS, VVYo8S, True)
     , "hiddenServices_sel_remove" : BF(self.VVFzfS, VVYo8S, False)
     }
  VVv6X11, cbFncDict1 = CCnEIM.VVpQIZ(self, VVYo8S, servName, 3)
  VVv6X1.extend(VVv6X11)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVzccf(VVv6X1, cbFncDict)
 def VV1SYJ(self, VVYo8S, title, txt, colList):
  servName = colList[0]
  mSel = CC3iyH(self, VVYo8S)
  VVv6X1, cbFncDict = CCnEIM.VVpQIZ(self, VVYo8S, servName, 3)
  mSel.VVzccf(VVv6X1, cbFncDict)
 @staticmethod
 def VVpQIZ(SELF, VVYo8S, servName, refCodeCol):
  tot = VVYo8S.VVTK0J()
  if tot > 0:
   sTxt = FFf1xo("%d Service%s" % (tot, FF2vwS(tot)), VVKiZJ)
   VVv6X1 = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFtomh(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFf1xo(servName, VVKiZJ)
   VVv6X1 = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCnEIM.VV3ezP, SELF, VVYo8S, refCodeCol, True)
     , "addToBouquet_one" : BF(CCnEIM.VV3ezP, SELF, VVYo8S, refCodeCol, False)
     }
  return VVv6X1, cbFncDict
 @staticmethod
 def VV3ezP(SELF, VVYo8S, refCodeCol, isMulti):
  picker = CCQii3(SELF, VVYo8S, "Add to Bouquet", BF(CCnEIM.VVjTJn, VVYo8S, refCodeCol, isMulti))
 @staticmethod
 def VVjTJn(VVYo8S, refCodeCol, isMulti):
  if isMulti : refCodeList = VVYo8S.VVZ4YI(refCodeCol)
  else  : refCodeList = [VVYo8S.VVK0Ui()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVwIA7(self, VVYo8S, refCode, isAddToBlackList):
  VVYo8S.VVhzMj("Processing ...")
  FFFO8C(BF(self.VV7PCa, VVYo8S, [refCode], isAddToBlackList))
 def VVJ2U7(self, VVYo8S, isAddToBlackList):
  refCodeList = VVYo8S.VVZ4YI(3)
  if not refCodeList:
   FFRGBb(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVYo8S.VVhzMj("Processing ...")
  FFFO8C(BF(self.VV7PCa, VVYo8S, refCodeList, isAddToBlackList))
 def VV7PCa(self, VVYo8S, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVU92K, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVU92K):
   lines = FFRtPk(VVU92K)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVU92K, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVYo8S.VVRSSP
   if isMulti:
    self.VVYs9z(VVYo8S, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVPrHj(VVYo8S, refCode)
    VVYo8S.VVxwMk()
  else:
   VVYo8S.VVu9dh("No changes")
 def VV8V9q(self, VVYo8S, refCode, isHide):
  title = "Change Hidden State"
  if FFkFSJ(refCode):
   VVYo8S.VVhzMj("Processing ...")
   ret = FF8S9j(refCode, isHide)
   if ret : FF0rXP(self, BF(self.VVPrHj, VVYo8S, refCode))
   else : FFRGBb(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFRGBb(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVPrHj(self, VVYo8S, refCode):
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVAjcf, VVZ9t7=[3, [refCode], False])
  done = False
  if VV4Gbf:
   data = VV4Gbf[0]
   if data[3] == refCode:
    done = VVYo8S.VVfm3U(data)
  if not done:
   self.VVciQs(VVYo8S, VVYo8S.VVjAQ8(), self.VVAjcf)
  VVYo8S.VVxwMk()
 def VVYs9z(self, VVYo8S, totRefCodes):
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVAjcf, VVZ9t7=self.VVvBc2)
  VVYo8S.VVPCrn(VV4Gbf)
  VVYo8S.VVw9l3(False)
  VVYo8S.VVu9dh("%d Processed" % totRefCodes)
 def VVFzfS(self, VVYo8S, isHide):
  refCodeList = VVYo8S.VVZ4YI(3)
  if not refCodeList:
   FFRGBb(self, "Nothing selected", title="Change Hidden State")
   return
  VVYo8S.VVhzMj("Processing ...")
  FFFO8C(BF(self.VVbCPQ, VVYo8S, refCodeList, isHide))
 def VVbCPQ(self, VVYo8S, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FF8S9j(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFVJ21(True)
   self.VVYs9z(VVYo8S, len(refCodeList))
  else:
   VVYo8S.VVu9dh("No changes")
 def VVErve(self, VVYo8S, title, txt, colList):
  inFilterFnc = BF(self.VV1tu3, VVYo8S) if self.VVvBc2 else None
  self.filterObj.VVz8kj(1, VVYo8S, 2, BF(self.VVIiRi, VVYo8S), inFilterFnc=inFilterFnc)
 def VVIiRi(self, VVYo8S, item):
  self.VVaoTS(VVYo8S, False, item, 2, self.VVAjcf)
 def VV1tu3(self, VVYo8S, menuInstance, item):
  self.VVaoTS(VVYo8S, True, item, 2, self.VVAjcf)
 def VVzLvT(self, VVYo8S, title, txt, colList):
  inFilterFnc = BF(self.VVt9jr, VVYo8S) if self.VVvBc2 else None
  self.filterObj.VVz8kj(2, VVYo8S, 4, BF(self.VVTlOA, VVYo8S), inFilterFnc=inFilterFnc)
 def VVTlOA(self, VVYo8S, item):
  self.VVaoTS(VVYo8S, False, item, 4, self.VVoFun)
 def VVt9jr(self, VVYo8S, menuInstance, item):
  self.VVaoTS(VVYo8S, True, item, 4, self.VVoFun)
 def VVGUEJ(self, VVYo8S, title, txt, colList):
  inFilterFnc = BF(self.VVxa6J, VVYo8S) if self.VVvBc2 else None
  self.filterObj.VVz8kj(0, VVYo8S, 4, BF(self.VVSpq3, VVYo8S), inFilterFnc=inFilterFnc)
 def VVSpq3(self, VVYo8S, item):
  self.VVaoTS(VVYo8S, False, item, 4, self.VViulY)
 def VVxa6J(self, VVYo8S, menuInstance, item):
  self.VVaoTS(VVYo8S, True, item, 4, self.VViulY)
 def VVaoTS(self, VVYo8S, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVYo8S.VVN3DQ(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVvBc2 = None
  else:
   words, asPrefix = CCFC3v.VVXFHp(words)
   self.VVvBc2 = [col, words, asPrefix]
  if words: FF0rXP(VVYo8S, BF(self.VVciQs, VVYo8S, title, mode), clearMsg=False)
  else : FFfad8(VVYo8S, "Incorrect filter", 2000)
 def VVciQs(self, VVYo8S, title, mode):
  VV4Gbf, err = CCnEIM.VVxj6i(self, mode, VVZ9t7=self.VVvBc2, VV1P1O=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVYo8S.VVl6T3():
    try:
     ndx = VV4Gbf.index(tuple(list(map(str.strip, row))))
     lst.append(VV4Gbf[ndx])
    except:
     pass
   VV4Gbf = lst
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVYo8S.VVPCrn(VV4Gbf, title)
  else:
   FFfad8(VVYo8S, "Not found!", 1500)
 def VVv0Hf(self, title, VVouKi, VVXwx9=None, VVTMvN=None, VVtXvO=None, VV6vKb=None, VVPogp=None, VVxkVZ=None):
  VV6vKb = ("Current Service", self.VVMkYc, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVK4mA = (LEFT  , LEFT  , CENTER, LEFT    )
  FFl3hs(self, None, title=title, header=header, VVouKi=VVouKi, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindServices)
 def VVMkYc(self, VVYo8S, title, txt, colList):
  self.VV8Jqq(VVYo8S)
 def VVbyNB(self, VVYo8S, title, txt, colList):
  self.VV8Jqq(VVYo8S, True)
 def VV8Jqq(self, VVYo8S, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVYo8S.VVawPk(colDict, VVy0Oi=True)
   else:
    VVYo8S.VVFzdA(3, refCode, True)
   return
  FFRGBb(self, "Cannot read current Reference Code !")
 def VVLM2C(self, title):
  self.VVvBc2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCFC3v(self)
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VViulY)
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVTMvN = (""    , self.VVOTj0 , []      )
   VV6vKb = ("Current Service", self.VVbyNB  , []      )
   VVxkVZ = ("Filter"   , self.VVGUEJ   , [], "Loading Filters ..." )
   VVXwx9  = ("Zap"   , self.VVaUql      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVK4mA  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VV6vKb=VV6vKb, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindServices)
 def VVOTj0(self, VVYo8S, title, txt, colList):
  refCode  = self.VV7xzi(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFwYti(self, fncMode=CCWhEO.VV8GQp, refCode=refCode, chName=chName, text=txt)
 def VVaUql(self, VVYo8S, title, txt, colList):
  refCode = self.VV7xzi(colList)
  FFTztI(self, refCode)
 def VVYNx9(self, VVYo8S, title, txt, colList):
  FFTztI(self, colList[3])
 def VV7xzi(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVr02f(VV8Ejs, mode=0):
  lines = FFRtPk(VV8Ejs, encLst=["UTF-8"])
  return CCnEIM.VVZXrm(lines, mode)
 @staticmethod
 def VVZXrm(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVxj6i(SELF, mode, VVZ9t7=None, VV1P1O=True, VV1pA1=True):
  VV8Ejs, err = CCnEIM.VV3Wwr(SELF, VV1pA1)
  if err:
   return None, err
  asPrefix = False
  if VVZ9t7:
   filterCol = VVZ9t7[0]
   filterWords = VVZ9t7[1]
   asPrefix = VVZ9t7[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCnEIM.VVAjcf:
   blackList = None
   if fileExists(VVU92K):
    blackList = FFRtPk(VVU92K)
    if blackList:
     blackList = set(blackList)
  elif mode == CCnEIM.VVoFun:
   tp = CCg4Ht()
  VVZ2TC, VVWyfL = FF9RbH()
  if mode in (CCnEIM.VVKXFu, CCnEIM.VVmtt4):
   VV4Gbf = {}
  else:
   VV4Gbf = []
  tagFound = False
  with ioOpen(VV8Ejs, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFUgik(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCnEIM.VViulY:
       if sTypeInt in VVZ2TC:
        STYPE = VVWyfL[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VV4Gbf.append(tRow)
        elif any(x in tmp for x in filterWords)    : VV4Gbf.append(tRow)
       else:
        VV4Gbf.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCnEIM.VVzMku:
        VV4Gbf.append((chName, chProv, sat, refCode))
       elif mode == CCnEIM.VVKXFu:
        VV4Gbf[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCnEIM.VVmtt4:
        VV4Gbf[chName] = refCode
       elif mode == CCnEIM.VVAjcf:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV4Gbf.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV4Gbf.append(tRow)
        else:
         VV4Gbf.append(tRow)
       elif mode == CCnEIM.VVoFun:
        if sTypeInt in VVZ2TC:
         STYPE = VVWyfL[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVw2sY(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV4Gbf.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV4Gbf.append(tRow)
        else:
         VV4Gbf.append(tRow)
       elif mode == CCnEIM.VVl5J9:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VV4Gbf.append((chName, chProv, sat, refCode))
       elif mode == CCnEIM.VVkkKN:
        VV4Gbf.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VV4Gbf and VV1P1O:
   FFRGBb(SELF, "No services found!")
  return VV4Gbf, ""
 def VVElIC(self, title):
  if fileExists(VVU92K):
   lines = FFRtPk(VVU92K)
   if lines:
    newRows = []
    VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVkkKN)
    if VV4Gbf:
     lines = set(lines)
     for item in VV4Gbf:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV4Gbf = newRows
      VV4Gbf.sort(key=lambda x: x[0].lower())
      VVTMvN = ("", self.VVdiVI, [])
      VVXwx9 = ("Zap", self.VVYNx9, [])
      self.VVv0Hf(title, VV4Gbf, VVXwx9=VVXwx9, VVTMvN=VVTMvN)
     else:
      FFipfq(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV4Gbf)))
   else:
    FFrNpu(self, "No active Parental Control services.", FFs7ER())
  else:
   FFZBzs(self, VVU92K)
 def VV0UAr(self, title):
  VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVl5J9)
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVTMvN = ("" , self.VVdiVI, [])
   VVXwx9  = ("Zap", self.VVYNx9, [])
   self.VVv0Hf(title, VV4Gbf, VVXwx9=VVXwx9, VVTMvN=VVTMvN)
  elif err:
   pass
  else:
   FFrNpu(self, "No hidden services.", FFs7ER())
 def VV59Y4(self):
  title = "Services unused in Tuner Configuration"
  VV8Ejs, err = CCnEIM.VV3Wwr(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCnEIM.VVJxkB()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVQBXF(str(item[0]))
    nsLst.add(ns)
  sysLst = CCnEIM.VVXeSW("1:7:")
  tpLst  = CCnEIM.VVr02f(VV8Ejs, mode=1)
  VV4Gbf = []
  for refCode, chName in sysLst:
   servID = CCnEIM.VVgv6k(refCode)
   tpID = CCnEIM.VVut0G(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VV4Gbf.append((chName, FFlSfT(refCode, False), refCode, servID))
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVPogp = ("Options"   , BF(self.VVT4JI, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVK4mA  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVPogp=VVPogp, VVyRL8="#0a001122", VVmr0Y="#0a001122", VVOSNp="#0a001122", VVuQjw="#00004455", VVVwZb="#0a333333", VVU8z2="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFrNpu(self, "No invalid service found !", title=title)
 def VVT4JI(self, Title, VVYo8S, title, txt, colList):
  mSel = CC3iyH(self, VVYo8S)
  isMulti = VVYo8S.VVRSSP
  if isMulti : txt = "Remove %s Services" % FFf1xo(str(VVYo8S.VVTK0J()), VV8tcv)
  else  : txt = "Remove : %s" % FFf1xo(VVYo8S.VVK0Ui()[0], VV8tcv)
  VVv6X1 = [(txt, "del")]
  cbFncDict = {"del": BF(FF0rXP, VVYo8S, BF(self.VVeAU2, VVYo8S, Title))}
  mSel.VVzccf(VVv6X1, cbFncDict)
 def VVeAU2(self, VVYo8S, title):
  VV8Ejs, err = CCnEIM.VV3Wwr(self, title=title)
  if err:
   return
  isMulti = VVYo8S.VVRSSP
  skipLst = []
  if isMulti : skipLst = VVYo8S.VVZ4YI(3)
  else  : skipLst = [VVYo8S.VVK0Ui()[3]]
  tpLst = CCnEIM.VVr02f(VV8Ejs, mode=0)
  servLst = CCnEIM.VVr02f(VV8Ejs, mode=10)
  tmpDbFile = VV8Ejs + ".tmp"
  lines   = FFRtPk(VV8Ejs)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFWqNF("mv -f '%s' '%s'" % (tmpDbFile, VV8Ejs)))
  VV4Gbf = []
  for row in VVYo8S.VVl6T3():
   if not row[3] in skipLst:
    VV4Gbf.append(row)
  FFVJ21()
  FFipfq(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VV4Gbf:
   VVYo8S.VVPCrn(VV4Gbf, title)
   VVYo8S.VVw9l3(False)
  else:
   VVYo8S.cancel()
 def VVuFXb(self, title):
  VV8Ejs, err = CCnEIM.VV3Wwr(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVoSYV(VV8Ejs)
  txt = FFf1xo("Total Transponders:\n\n", VV0HRz)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFf1xo("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV0HRz)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFcPTk(item), satList.count(item))
  FFipfq(self, txt, title)
 def VVoSYV(self, VV8Ejs):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VV8Ejs, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VViNAZ(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFZBzs(self, path, title=title)
   return
  elif not CCOjzn.VVAreK(self, path, title):
   return
  if not CCixMT.VVPO1k(self):
   return
  tree = CCnEIM.VVm3pv(self, path, title=title)
  if not tree:
   return
  VV4Gbf = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFUgik(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VV4Gbf.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VV4Gbf:
   VV4Gbf.sort(key=lambda x: int(x[1]))
   VV6vKb = ("Current Satellite", BF(self.VVTeO8, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVK4mA  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=25, VVPhoH=1, VV6vKb=VV6vKb, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFRGBb(self, "No data found !", title=title)
 def VVTeO8(self, satCol, VVYo8S, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  sat = FFlSfT(refCode, False)
  for ndx, row in enumerate(VVYo8S.VVl6T3()):
   if sat == row[satCol].strip():
    VVYo8S.VVG9tX(ndx)
    break
  else:
   FFfad8(VVYo8S, "No listed !", 1500)
 def FF0rXP_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFRGBb(self, "No Satellites found !")
   return
  usedSats = CCnEIM.VVJxkB()
  VV4Gbf = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VV4Gbf.append((sat[1], posTxt, FFUgik(sat[0]), tuners, str(posVal)))
  if VV4Gbf:
   VVOSNp = "#11222222"
   VV4Gbf.sort(key=lambda x: int(x[1]))
   VV6vKb = ("Current Satellite" , BF(self.VVTeO8, 2) , [])
   VVPogp = ("Options"   , self.VVe1ub  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVK4mA  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VV6vKb=VV6vKb, VVPogp=VVPogp, VVyRL8=VVOSNp, VVmr0Y=VVOSNp, VVOSNp=VVOSNp, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFRGBb(self, "No data found !")
 def VVe1ub(self, VVYo8S, title, txt, colList):
  mSel = CC3iyH(self, VVYo8S)
  isMulti = VVYo8S.VVRSSP
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFf1xo(str(VVYo8S.VVTK0J()), VV8tcv)
  else  : txt = "Remove ALL Services on : %s" % FFf1xo(VVYo8S.VVK0Ui()[0], VV8tcv)
  VVv6X1 = []
  VVv6X1.append((txt, "deleteSat"))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Delete Empty Bouquets", "VVSX0M"))
  cbFncDict = { "deleteSat"   : BF(FF0rXP, VVYo8S, BF(self.VVLO0P, VVYo8S))
     , "VVSX0M" : BF(self.VVSX0M, VVYo8S)
     }
  mSel.VVzccf(VVv6X1, cbFncDict)
 def VVLO0P(self, VVYo8S):
  posLst = []
  isMulti = VVYo8S.VVRSSP
  posLst = []
  if isMulti : posLst = VVYo8S.VVZ4YI(4)
  else  : posLst = [VVYo8S.VVK0Ui()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVQBXF(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVvCba(nsLst)
  FFVJ21(True)
  FFipfq(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVSX0M(self, winObj):
  title = "Delete Empty Bouquets"
  FFWkqs(self, BF(FF0rXP, winObj, BF(self.VVFrgm, title)), "Delete bouquets with no services ?", title=title)
 def VVFrgm(self, title):
  bList = CCQii3.VV1Zvo()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCQii3.VVPXhz(bRef)
    bPath = VVxlEW + bFile
    FFsF1P(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVxlEW + fil
     if fileExists(path):
      lines = FFRtPk(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFVJ21(True)
  if bNames: txt = "%s\n\n%s" % (FFf1xo("Deleted Bouquets:", VVKiZJ), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFipfq(self, txt, title=title)
 def VVQBXF(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVvCba(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVxlEW)
  for srcF in files:
   if fileExists(srcF):
    lines = FFRtPk(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFopyC(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVhnPB(self, title)   : self.VVB31O(title, True)
 def VVh8jP(self, title) : self.VVB31O(title, False)
 def VVB31O(self, title, isWithPIcons):
  piconsPath = CCxA8L.VV76e0()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCxA8L.VVkyO5(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV4Gbf, err = CCnEIM.VVxj6i(self, self.VVkkKN)
    if VV4Gbf:
     channels = []
     for (chName, chProv, sat, refCode) in VV4Gbf:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFDeJg(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV4Gbf)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV8Lwm(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV8Lwm("PIcons Path"  , piconsPath)
     txt += VV8Lwm("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV8Lwm("Total services" , totalServices)
     txt += VV8Lwm("With PIcons"  , totalWithPIcons)
     txt += VV8Lwm("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFipfq(self, txt)
     else:
      VVTMvN     = (""      , self.VVdiVI , [])
      if isWithPIcons : VVxkVZ = ("Export Current PIcon", self.VV7wLs  , [])
      else   : VVxkVZ = None
      VVPogp     = ("Statistics", FFipfq, [txt])
      VVXwx9      = ("Zap", self.VVYNx9, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVv0Hf(title, channels, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVPogp=VVPogp, VVxkVZ=VVxkVZ)
   else:
    FFRGBb(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFRGBb(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVdiVI(self, VVYo8S, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFwYti(self, fncMode=CCWhEO.VV8GQp, refCode=refCode, chName=chName, text=txt)
 def VV7wLs(self, VVYo8S, title, txt, colList):
  png, path = CCxA8L.VVMGvX(colList[3], colList[0])
  if path:
   CCxA8L.VV7cpC(self, png, path)
 @staticmethod
 def VVxE6g():
  VV8Ejs  = "%slamedb" % VVxlEW
  VV4gYP = "%slamedb.disabled" % VVxlEW
  return VV8Ejs, VV4gYP
 @staticmethod
 def VVsgOv():
  VVKWG2  = "%slamedb5" % VVxlEW
  VVOWAH = "%slamedb5.disabled" % VVxlEW
  return VVKWG2, VVOWAH
 def VVFdaK(self, isEnable):
  VV8Ejs, VV4gYP = CCnEIM.VVxE6g()
  if isEnable and not fileExists(VV4gYP):
   FFrNpu(self, "Aready enabled.")
  elif not isEnable and not fileExists(VV8Ejs):
   FFRGBb(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFWkqs(self, BF(self.VV0K98, isEnable), "%s Hidden Channels ?" % word)
 def VV0K98(self, isEnable):
  VV8Ejs , VV4gYP = CCnEIM.VVxE6g()
  VVKWG2, VVOWAH = CCnEIM.VVsgOv()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV4gYP, VV4gYP, VV8Ejs)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVOWAH, VVOWAH, VVKWG2)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VV8Ejs  , VV8Ejs , VV4gYP)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVKWG2 , VVKWG2, VVOWAH)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV4gYP, VV8Ejs )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVOWAH, VVKWG2)
  res = os.system(cmd)
  FFVJ21()
  if res == 0 : FFrNpu(self, "Hidden List %s" % word)
  else  : FFRGBb(self, "Error while restoring:\n\n%s" % fileName)
 def VVE7xi(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVxlEW
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVxlEW
  FFnBvt(self, cmd)
 def VVTqPr(self):
  VV8Ejs, err = CCnEIM.VV3Wwr(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FFsF1P(tmpFile)
  totChan = totRemoved = 0
  lines = FFRtPk(VV8Ejs, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFWkqs(self, BF(FF0rXP, self, BF(self.VVpWN6, tmpFile, VV8Ejs, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FF2vwS(totRemoved), totChan, FF2vwS(totChan))
      , callBack_No=BF(self.VVI4zB, tmpFile))
  else:
   FFipfq(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVpWN6(self, tmpFile, VV8Ejs, totRemoved, totChan):
  os.system(FFWqNF("mv -f '%s' '%s'" % (tmpFile, VV8Ejs)))
  FFVJ21()
  FFipfq(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVI4zB(self, tmpFile):
  FFsF1P(tmpFile)
 @staticmethod
 def VV3Wwr(SELF, VV1pA1=True, title=""):
  VV8Ejs, VV4gYP = CCnEIM.VVxE6g()
  if   not fileExists(VV8Ejs)       : err = "File not found !\n\n%s" % VV8Ejs
  elif not CCOjzn.VVAreK(SELF, VV8Ejs) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VV1pA1:
   FFRGBb(SELF, err, title=title)
  return VV8Ejs, err
 @staticmethod
 def VVut0G(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVgv6k(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVXeSW(servTypes):
  VV1zoa  = eServiceCenter.getInstance()
  VVQM8O   = '%s ORDER BY name' % servTypes
  VV7hj6   = eServiceReference(VVQM8O)
  VVh6m1 = VV1zoa.list(VV7hj6)
  if VVh6m1: return VVh6m1.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVJxkB():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCWhEO(Screen):
 VV9IGI  = 0
 VVCjHI   = 1
 VVeN1z   = 2
 VV8GQp    = 3
 VVRXS5    = 4
 VVFAWC   = 5
 VVhjVl   = 6
 VVPa5X    = 7
 VVdGzF   = 8
 VVirj9   = 9
 VVuMYr   = 10
 VVK5no   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFUxcO(VVvoh9, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV9IGI)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFf1xo("%s\n", VVpLjr) % VVT41S
  self.picViewer  = None
  FFDBTO(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVrcwz })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self["myLabel"].VVUfQy(outputFileToSave="chann_info")
  if   self.fncMode == self.VV9IGI : fnc = self.VVGMkM
  elif self.fncMode == self.VVCjHI  : fnc = self.VVGMkM
  elif self.fncMode == self.VVeN1z  : fnc = self.VVGMkM
  elif self.fncMode == self.VV8GQp  : fnc = self.VVEoER
  elif self.fncMode == self.VVRXS5  : fnc = self.VVPMeo
  elif self.fncMode == self.VVFAWC  : fnc = self.VVwvsX
  elif self.fncMode == self.VVhjVl  : fnc = self.VVWplr
  elif self.fncMode == self.VVPa5X  : fnc = self.VV6b0e
  elif self.fncMode == self.VVdGzF  : fnc = self.VVS9Bl
  elif self.fncMode == self.VVirj9 : fnc = self.VVkmFe
  elif self.fncMode == self.VVuMYr  : fnc = self.VVOm0A
  elif self.fncMode == self.VVK5no : fnc = self.VVOHvh
  self["myLabel"].setText("\n   Reading Info ...")
  FFFO8C(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVFeYy()
 def VV2FKR(self, err):
  self["myLabel"].setText(err)
  FF2A0B(self["myTitle"], "#22200000")
  FF2A0B(self["myBody"], "#22200000")
  self["myLabel"].VVndIx("#22200000")
  self["myLabel"].VVCO8f()
 def VVGMkM(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  self.refCode = refCode
  self.VVXL4x(chName)
 def VVEoER(self):
  self.VVXL4x(self.chName)
 def VVPMeo(self):
  self.VVXL4x(self.chName)
 def VVwvsX(self):
  self.VVXL4x(self.chName)
 def VVWplr(self):
  self.VVXL4x("Picon Info")
 def VV6b0e(self):
  self.VVXL4x(self.chName)
 def VVS9Bl(self):
  self.VVXL4x(self.chName)
 def VVkmFe(self):
  self.VVXL4x(self.chName)
 def VVOm0A(self):
  self.chUrl = self.refCode + self.callingSELF.VVTWoF(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVXL4x(self.chName)
 def VVOHvh(self):
  self.VVXL4x(self.chName)
 def VVXL4x(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFaQmC(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVDw83(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFf1xo(self.VVPJrC(tUrl), VVe79W)
  if not self.epg:
   epg = CC8oCo.VVTOJZ(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVAHw6(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCxA8L.VVMGvX(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVAHw6(path)
  self.VVcegG()
  self.VVCPtE()
  self["myLabel"].setText(self.text or "   No active service", VVKhCn=VVW8Aw)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVCO8f(minHeight=minH)
 def VVCPtE(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFW8kf(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVgaWH(FFT8KE(url))
  if epg:
   self.text += "\n" + FFb8P2("EPG:", VVKiZJ) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVcegG()
 def VVcegG(self):
  if not self.piconShown and self.picUrl:
   path, err = FFn4Tu(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVAHw6(path)
    if self.piconShown and self.refCode:
     self.VVbtlN(path, self.refCode)
 def VVbtlN(self, path, refCode):
  if path and fileExists(path) and os.system(FFWqNF("which ffmpeg")) == 0:
   pPath = CCxA8L.VV76e0()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCWhEO.VVZvOp(path)
    cmd += FFWqNF("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVAHw6(self, path):
  if path and fileExists(path):
   err, w, h = self.VVI0Vf(path)
   if not err:
    if h > w:
     self.VVJh2E(self["myPicF"], w, h, True)
     self.VVJh2E(self["myPicB"], w, h, False)
     self.VVJh2E(self["myPic"] , w, h, False)
   self.picViewer = CCe2gv.VVmA3G(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVJh2E(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVI0Vf(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFTbYu(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVDw83(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFf1xo(chName, VVKiZJ)
  txt += self.VV8Lwm(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFf1xo(state, VVqskC)
   txt += "State\t: %s\n" % state
  w = FFL4y8(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFL4y8(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVKWCf(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV8Lwm(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV8Lwm(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV8Lwm(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV1e1H()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVz0kH()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCWhEO.VVAZrJ(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFf1xo("Stream-Relay" if FFUUIm(decodedUrl) else "IPTV", VV0HRz)
   txt += self.VV5wjm(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVtARK(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCg4Ht()
    tpTxt, namespace = tp.VVKt7d(refCode)
    if tpTxt:
     txt += FFf1xo("Tuner:\n", VVKiZJ)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFf1xo("Codes:\n", VVKiZJ)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV8Lwm(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV8Lwm(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV8Lwm(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV8Lwm(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV8Lwm(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV8Lwm(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV8Lwm(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV8Lwm(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV8Lwm(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVKWCf(info):
  if info:
   aspect = FFL4y8(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV8Lwm(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFL4y8(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVAqlj(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVAqlj(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV1e1H(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVz0kH(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVtARK(self, refCode, iptvRef, chName):
  refCode = FFvNg9(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFUKzq(VVxlEW + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFUKzq(VVxlEW + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVouKi = []
  tmpRefCode = FFT8KE(refCode)
  for item in fList:
   path = VVxlEW + item
   if fileExists(path):
    txt = FFUKzq(path)
    if tmpRefCode in FFT8KE(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVouKi.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVouKi:
   if len(VVouKi) == 1:
    txt += "%s\t: %s%s\n" % (FFf1xo("Bouquet", VVKiZJ), VVouKi[0][0], " (%s)" % VVouKi[0][1] if VVhvL2 else "")
   else:
    txt += FFf1xo("Bouquets:\n", VVKiZJ)
    for ndx, item in enumerate(VVouKi):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVhvL2 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV5wjm(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFQOHf(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCWc1W()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFf1xo("URL:", VV0HRz) + "\n%s\n" % self.VVPJrC(decodedUrl)
  else:
   txt = "\n"
   txt += FFf1xo("Reference:", VV0HRz) + "\n%s\n" % refCode
  return txt
 def VVPJrC(self, url):
  if not FFUUIm(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVgkK0:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFT8KE(url)
 def VVgaWH(self, decodedUrl):
  if not FFGXQq():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCCGrE.VVcPPT(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVZufy(tDict)
   elif uType == "movie" : epg, picUrl = CCWhEO.VV1sNL(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVZufy(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCCGrE.VVMcOx(item, "title"    , is_base64=True )
     lang    = CCCGrE.VVMcOx(item, "lang"         ).upper()
     description   = CCCGrE.VVMcOx(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCCGrE.VVMcOx(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCCGrE.VVMcOx(item, "start_timestamp"      )
     stop_timestamp  = CCCGrE.VVMcOx(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCCGrE.VVMcOx(item, "stop_timestamp"       )
     now_playing   = CCCGrE.VVMcOx(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVH2yZ, ""
      else     : color, txt = VVqskC , "    (CURRENT EVENT)"
      epg += FFf1xo("_" * 32 + "\n", VVpLjr)
      epg += FFf1xo("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFf1xo(description, VVe79W)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CC8oCo.VVflYv(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VV1sNL(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCCGrE.VVMcOx(item, "movie_image" )
    genre  = CCCGrE.VVMcOx(item, "genre"   ) or "-"
    plot  = CCCGrE.VVMcOx(item, "plot"   ) or "-"
    cast  = CCCGrE.VVMcOx(item, "cast"   ) or "-"
    rating  = CCCGrE.VVMcOx(item, "rating"   ) or "-"
    director = CCCGrE.VVMcOx(item, "director"  ) or "-"
    releasedate = CCCGrE.VVMcOx(item, "releasedate" ) or "-"
    duration = CCCGrE.VVMcOx(item, "duration"  ) or "-"
    try:
     lang = CCCGrE.VVMcOx(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFf1xo(cast, VVe79W)
    epg += "Plot:\n%s"    % FFf1xo(plot, VVe79W)
   except:
    pass
  return epg, movie_image
 def VVrcwz(self):
  if VVgkK0:
   def VV8Lwm(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV8Lwm(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCWc1W()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV8Lwm(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVT41S, txt))
   FFfad8(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVKSMV(SELF):
  if not CCavOd.VVYiQx(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF)
  err = url =  fSize = resumable = ""
  if FF35eK(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCWc1W.VVOkTh(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCWc1W.VV9JCs(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFRGBb(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCOjzn.VV7GBO(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFf1xo(" (M3U/M3U8 File)", VVe79W)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCNUxQ.VVvWcp(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVko9g(subj, val):
   return "%s\n%s\n\n" % (FFf1xo("%s:" % subj, VVKiZJ), val)
  title = "File Size"
  txt  = VVko9g(title , fSize or "?")
  txt += VVko9g("Name" , chName)
  txt += VVko9g("URL" , url)
  if resumable: txt += VVko9g("Supports Download-Resume", resumable)
  if err  : txt += FFf1xo("Error:\n", VVqskC) + err
  FFipfq(SELF, txt, title=title)
 @staticmethod
 def VVAZrJ(SELF):
  fPath, fDir, fName = CCOjzn.VVb4Zf(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVZvOp(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VValRW(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCxA8L.VV76e0() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVJdzg(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFW8kf(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFopyC(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCWc1W():
 def __init__(self):
  self.VVXXml   = ""
  self.VVg2mm    = ""
  self.VV0Jta   = ""
  self.VVz6XO = ""
  self.VVSp1a  = ""
  self.VV6cY5 = 0
  self.VVLeWo    = ""
  self.VVbX5d   = "#f#11ffffaa#User"
  self.VVrwdk   = "#f#11aaffff#Server"
 def VVsVF1(self, url, mac, ph1="", VVy0Oi=True):
  self.VVXXml   = ""
  self.VVg2mm    = ""
  self.VV0Jta   = ""
  self.VVz6XO = ""
  self.VVSp1a  = ""
  self.VV6cY5 = 0
  self.VVLeWo    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVbHL9(url)
  if not host:
   if VVy0Oi:
    self.VVa2fj("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVtB61(mac)
  if not host:
   if VVy0Oi:
    self.VVa2fj("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVXXml = host
  self.VVg2mm  = mac
  return True
 def VVbHL9(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVtB61(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVRmAt(self):
  res, err = self.VVOAxN(self.VVhyxo())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVXXml:
   self.VVXXml = self.VVXXml.replace(urlPath, "")
   res, err = self.VVOAxN(self.VVhyxo())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCCGrE.VVMcOx(tDict["js"], "token")
    rand  = CCCGrE.VVMcOx(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVx5FX(self, VVy0Oi=True):
  if not self.VVLeWo:
   self.VVLeWo = self.VViBjx()
  err = blkMsg = FFrNpuTxt = ""
  try:
   token, rand, err = self.VVRmAt()
   if token:
    self.VV0Jta = token
    self.VVz6XO = rand
    if rand:
     self.VV6cY5 = 2
    prof, retTxt = self.VVVvjT(True)
    if prof:
     self.VVSp1a = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VV6cY5 = 3
      prof, retTxt = self.VVVvjT(False)
      if retTxt:
       self.VVSp1a = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFrNpuTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFrNpuTxt: tErr += "\n%s" % FFrNpuTxt
  if VVy0Oi:
   self.VVa2fj(tErr)
  return "", "", tErr
 def VViBjx(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVXXml, headers=CCWc1W.VV9JCs(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVVvjT(self, capMac):
  res, err = self.VVOAxN(self.VVNUWC(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCCGrE.VVMcOx(tDict["js"], "block_%s" % word)
    FFrNpuTxt = CCCGrE.VVMcOx(tDict["js"], word)
    return tDict, FFrNpuTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVNUWC(self, capMac):
  param = ""
  if self.VVSp1a or self.VVz6XO:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVg2mm.upper() if capMac else self.VVg2mm.lower(), self.VVz6XO))
  return self.VV7F9o() + "type=stb&action=get_profile" + param
 exec(FF3JrN("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VV3crA(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV6VJZ()
  if len(rows) < 10:
   rows = self.VVyMyt()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVXXml ))
   rows.append(("MAC (from URL)" , self.VVg2mm ))
   rows.append(("Token"   , self.VV0Jta ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVbX5d  , "MAC" , self.VVg2mm ))
   rows.append(("2", self.VVrwdk, "Host" , self.VVXXml ))
   rows.append(("2", self.VVrwdk, "Token" , self.VV0Jta ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVf4AQ(self, isPhp=True, VVy0Oi=False):
  token, profile, tErr = self.VVx5FX(VVy0Oi)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VV8Pcc()
  res, err = self.VVOAxN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCCGrE.VVMcOx(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFAPsb(span.group(2))
     pass1 = FFAPsb(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV6VJZ(self):
  m3u_Url, host, user1, pass1, err = self.VVf4AQ()
  rows = []
  if m3u_Url:
   res, err = self.VVOAxN(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFQFpj(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVbX5d, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFQFpj(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVrwdk, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVyMyt(self):
  token, profile, tErr = self.VVx5FX()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFpmLf(val): val = FF3JrN(val.decode("UTF-8"))
     else     : val = self.VVg2mm
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFQFpj(int(parts[1]))
      if parts[2] : ends = FFQFpj(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFQFpj(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVTWoF(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVx5FX(VVy0Oi=False)
  if not token:
   return ""
  crLinkUrl = self.VVSMJv(mode, chCm, epNum, epId)
  res, err = self.VVOAxN(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCCGrE.VVMcOx(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV7F9o(self):
  return self.VVXXml + (self.VVLeWo or "/server/load.php") + "?"
 def VVhyxo(self):
  return self.VV7F9o() + "type=stb&action=handshake&token=&mac=%s" % self.VVg2mm
 def VVW5Y7(self, mode):
  url = self.VV7F9o() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV1GYN(self, catID):
  return self.VV7F9o() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVmBHe(self, mode, catID, page):
  url = self.VV7F9o() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVEzOF(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV7F9o() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVVaDB(self, mode, catID):
  return self.VV7F9o() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVSMJv(self, mode, chCm, serCode, serId):
  url = self.VV7F9o() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV8Pcc(self):
  return self.VV7F9o() + "type=itv&action=create_link"
 def VVEjtU(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVhgAF(catID, stID, chNum)
  query = self.VVpNjg(mode, self.VVLeWo[1:2], FFuqs7(host), FFuqs7(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVpNjg(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV7dnN(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVpNjg(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF3JrN(host)
  mac   = FF3JrN(mac)
  valid = False
  if self.VVbHL9(playHost) and self.VVbHL9(host) and self.VVbHL9(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVOAxN(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCWc1W.VV9JCs()
   if self.VV0Jta:
    headers["Authorization"] = "Bearer %s" % self.VV0Jta
   if useCookies : cookies = {"mac": self.VVg2mm, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VV7euB(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCWc1W.VV9JCs(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VV9JCs():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVv69b(host, mac, tType, action, keysList=None):
  myPortal = CCWc1W()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVsVF1(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVx5FX(VVy0Oi=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVOAxN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVKM99(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVKM99(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVa2fj(self, err, title="Portal Browser"):
  FFRGBb(self, str(err), title=title)
 def VVB19C(self, mode):
  if   mode in ("itv"  , CCCGrE.VV1zOs , CCCGrE.VVUAey)  : return "Live"
  elif mode in ("vod"  , CCCGrE.VVRcC9 , CCCGrE.VVwImz)  : return "VOD"
  elif mode in ("series" , CCCGrE.VVUXD1 , CCCGrE.VVSAqH) : return "Series"
  else                          : return "IPTV"
 def VVgPq9(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVB19C(mode), FFf1xo(searchName, VVe79W))
 def VVcw0z(self, catchup=False):
  VVv6X1 = []
  VVv6X1.append(("Live"    , "live"  ))
  VVv6X1.append(("VOD"    , "vod"   ))
  VVv6X1.append(("Series"   , "series"  ))
  if catchup:
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Catch-up TV" , "catchup"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Account Info." , "accountInfo" ))
  return VVv6X1
 @staticmethod
 def VV3rxx(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCWc1W()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(decodedUrl)
  if valid:
   ok = p.VVsVF1(host, mac, ph1, VVy0Oi=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVf4AQ(isPhp=False, VVy0Oi=False)
    streamId = CCWc1W.VVhPRd(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVhPRd(decodedUrl):
  p = CCWc1W()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FF3JrN(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVOkTh(decodedUrl):
  p = CCWc1W()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(decodedUrl)
  if valid:
   if CCWc1W.VVKNXq(chCm):
    return FFT8KE(chCm)
   else:
    ok = p.VVsVF1(host, mac, ph1, VVy0Oi=False)
    if ok:
     try:
      chUrl = p.VVTWoF(mode, chCm, epNum, epId)
      return FFT8KE(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVKNXq(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCN3wh(CCWc1W):
 def __init__(self):
  CCWc1W.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVcORG(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV7dnN(decodedUrl)
  if valid:
   if self.VVsVF1(host, mac, ph1, VVy0Oi=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVw5aC(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVTWoF(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCWc1W.VVKNXq(self.chCm):
   chUrl = FFT8KE(self.chCm)
   chUrl = FFAPsb(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVFgNr(chUrl)
  bPath = CCQii3.VVZqkg()
  if newIptvRef:
   if passedSELF:
    FFTztI(passedSELF, newIptvRef, VVLjiH=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFTztI(self, newIptvRef, VVLjiH=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VV1yf4(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVFgNr(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV1yf4(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFRtPk(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFVJ21()
class CCKrcC(CCN3wh):
 def __init__(self, passedSession):
  CCN3wh.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVGjJk(VVi29r  )
  Main_Menu.VVGjJk(VVPKSk)
  Main_Menu.VVGjJk(VVgCrF  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVVfm1, iPlayableService.evEOF: self.VVueBt, iPlayableService.evEnd: self.VVxOy8})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVOhDS)
  except:
   self.timer2.callback.append(self.VVOhDS)
  self.timer2.start(3000, False)
  self.VVOhDS()
 def VVOhDS(self):
  if not CFG.downloadMonitor.getValue():
   self.VVWjy9()
   return
  lst = CCNUxQ.VVRN4z()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFDH0v(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCNUxQ.VV5GYi(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCKXTc, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFfZuu(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVWjy9()
 def VVWjy9(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVVfm1(self):
  self.startTime = iTime()
 def VVueBt(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self.passedSession, isFromSession=True)
    if iptvRef and not FF35eK(decodedUrl):
     self.isFromEOF = True
     CCIwVQ(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVxOy8(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVPHxI)
  except:
   self.timer1.callback.append(self.VVPHxI)
  self.timer1.start(100, True)
 def VVPHxI(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVcORG(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCSeoi.VVN5AL:
       self.isFromEOF = False
       self.VVw5aC(self.passedSession, isFromSession=True)
class CCcIbP():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVBVVp(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCCGrE.VV6gjy(name):
   return CCCGrE.VVlDia(name)
  name = self.VVlI9A(name)
  return name.strip() or name
 def VVlI9A(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVnw5I(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVlI9A(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVsWLT(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVkXPN(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVwn3a(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCavOd(CCWc1W):
 def __init__(self):
  CCWc1W.__init__(self)
 def VVA9W2(self):
  if CCavOd.VVYiQx(self):
   FF0rXP(self, BF(self.VViBNr, 2), title="Searching ...")
 def VVFuVC(self, winSession, url, mac):
  self.curUrl = url
  if CCavOd.VVYiQx(self):
   if self.VVsVF1(url, mac):
    FF0rXP(winSession, self.VVDygS, title="Checking Server ...")
   else:
    FFRGBb(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVdZGW(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCzVQo.VVYxDX(path, self)
   if enc == -1:
    return
   self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVcATb, path, enc)
       , VVkuAk = BF(self.VV9k2n, menuInstance, path))
 def VVcATb(self, path, enc, VVtdJ0):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVtdJ0.VVhRNu(totLines)
  VVtdJ0.VVwHZ6 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVtdJ0 or VVtdJ0.isCancelled:
     return
    VVtdJ0.VVcdeL(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVbHL9(url)
     mac  = self.VVtB61(mac)
     if host and mac and VVtdJ0:
      VVtdJ0.VVwHZ6.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVbHL9(url)
      mac  = self.VVtB61(mac)
      if host and mac and not mac.startswith("AC") and VVtdJ0:
       VVtdJ0.VVwHZ6.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VV9k2n(self, menuInstance, path, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVwHZ6:
   VVtXvO  = ("Home Menu"  , FF1fb7            , [])
   VVPogp = ("Edit File"  , BF(self.VVSkTY, path)       , [])
   VV6vKb = ("M3U Options" , self.VVGlv7         , [])
   VVxkVZ = ("Check & Filter" , BF(self.VVAVAI, menuInstance, path), [])
   VVXwx9  = ("Select"   , self.VV0SPt      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVK4mA  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VVwHZ6, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVyRL8="#0a001122", VVmr0Y="#0a001122", VVOSNp="#0a001122", VVuQjw="#00004455", VVVwZb="#0a333333", VVU8z2="#11331100", VVWKtq=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVzWxR:
    FFfad8(VVYo8S, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVzWxR:
    FFRGBb(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVGlv7(self, VVYo8S, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVv6X1 = []
  VVv6X1.append(("Browse as M3U"  , "browse"))
  VVv6X1.append(("Download M3U File" , "downld"))
  FFLwVh(self, BF(self.VVRTl3, VVYo8S, host, mac), title=title, VVv6X1=VVv6X1, width=600, VVrAw7=True)
 def VVRTl3(self, VVYo8S, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF0rXP(VVYo8S, BF(self.VVMyAs, VVYo8S, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFWkqs(self, BF(FF0rXP, VVYo8S, BF(self.VVMyAs, VVYo8S, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVMyAs(self, VVYo8S, title, host, mac, item):
  p = CCWc1W()
  m3u_Url = ""
  ok = p.VVsVF1(host, mac, VVy0Oi=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVf4AQ(VVy0Oi=False)
  if m3u_Url:
   if   item == "browse": self.VVMrNs(title, m3u_Url)
   elif item == "downld": self.VVyE76(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFRGBb(self, err or "No response from Server !", title=title)
 def VV0SPt(self, VVYo8S, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVFuVC(VVYo8S, url, mac)
 def VVSkTY(self, path, VVYo8S, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCyIuf(self, path, VVkuAk=BF(self.VVEbu0, VVYo8S), curRowNum=rowNum)
  else    : FFZBzs(self, path)
 def VVAVAI(self, menuInstance, path, VVYo8S, title, txt, colList):
  self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VV6G5y, VVYo8S)
      , VVkuAk = BF(self.VVfgUx, menuInstance, VVYo8S, path))
 def VV6G5y(self, VVYo8S, VVtdJ0):
  VVtdJ0.VVwHZ6 = []
  VVtdJ0.VVhRNu(VVYo8S.VVDPuF())
  for row in VVYo8S.VVl6T3():
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVsVF1(host, mac, VVy0Oi=False):
    token, profile, tErr = self.VVx5FX(VVy0Oi=False)
    if token and VVtdJ0 and not VVtdJ0.isCancelled:
     res, err = self.VVOAxN(self.VVW5Y7("itv"))
     if res and VVtdJ0 and not VVtdJ0.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVtdJ0.VVcdeL(0, showFound=True)
       VVtdJ0.VVwHZ6.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVtdJ0:
    return
 def VVfgUx(self, menuInstance, VVYo8S, path, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVwHZ6:
   VVYo8S.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFWWBu())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVwHZ6:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFf1xo(str(threadCounter), VVqskC)
    skipped = FFf1xo(str(threadTotal - threadCounter), VVqskC)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVwHZ6)
   txt += "%s\n\n%s"    %  (FFf1xo("Result File:", VVKiZJ), newPath)
   FFipfq(self, txt, title="Accessible Portals")
  elif VVzWxR:
   FFRGBb(self, "No portal access found !", title="Accessible Portals")
 def VV0Lza(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF3JrN(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVDygS(self):
  token, profile, tErr = self.VVx5FX()
  if token:
   dots = "." * self.VV6cY5
   dots += "+" if self.VVLeWo[1:2] == "p" else ""
   VVv6X1  = self.VVcw0z()
   OKBtnFnc = self.VVZ7eW
   infoBtnFnc = self.VVr0of
   VVrX4i = ("Home Menu", FF1fb7)
   VVqSIC= ("Add to Menu", BF(CCCGrE.VVtjkZ, self, True, self.VVXXml + "\t" + self.VVg2mm))
   VVxtuz = ("Bookmark Server", BF(CCCGrE.VVoOI2, self, True, self.VVXXml + "\t" + self.VVg2mm))
   FFLwVh(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVg2mm, dots), VVv6X1=VVv6X1, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVrX4i=VVrX4i, VVqSIC=VVqSIC, VVxtuz=VVxtuz)
 def VVZ7eW(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF0rXP(menuInstance, BF(self.VV4sZY, mode), title="Reading Categories ...")
   else : FF0rXP(menuInstance, BF(self.VVn3zC, menuInstance, title), title="Reading Account ...")
 def VVn3zC(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV3crA(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVg2mm)
  VVtXvO  = ("Home Menu" , FF1fb7         , [])
  VV6vKb  = None
  if VVgkK0:
   VV6vKb = ("Get JS"  , BF(self.VV54VB, self.VVXXml), [])
  if totCols == 2:
   VVxkVZ = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVxkVZ = ("More Info.", BF(self.VVb6t6, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFl3hs(self, None, title=title, width=1200, header=header, VVouKi=rows, VVw7oP=widths, VVcK4p=26, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVxkVZ=VVxkVZ, VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000", searchCol=searchCol)
 def VV54VB(self, url, VVYo8S, title, txt, colList):
  FF0rXP(VVYo8S, BF(self.VVGeTv, url), title="Getting JS ...")
 def VVGeTv(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VVCggd("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VVCggd("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FFipfq(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVCggd(self, url):
  res, err = self.VVOAxN(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVb6t6(self, menuInstance, VVYo8S, title, txt, colList):
  VVYo8S.cancel()
  FF0rXP(menuInstance, BF(self.VVn3zC, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV4sZY(self, mode):
  token, profile, tErr = self.VVx5FX()
  if not token:
   return
  res, err = self.VVOAxN(self.VVW5Y7(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VV30jT = CCcIbP()
     chList = tDict["js"]
     for item in chList:
      Id   = CCCGrE.VVMcOx(item, "id"       )
      Title  = CCCGrE.VVMcOx(item, "title"      )
      censored = CCCGrE.VVMcOx(item, "censored"     )
      Title = VV30jT.VVsWLT(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVhvL2:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVB19C(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR(mode)
   mName = self.VVB19C(mode)
   VVXwx9   = ("Show List"   , BF(self.VVVKtY, mode)   , [])
   VVtXvO  = ("Home Menu"   , FF1fb7        , [])
   if mode in ("vod", "series"):
    VVPogp = ("Find in %s" % mName , BF(self.VVoSsS, mode, False), [])
    VVxkVZ = ("Find in Selected" , BF(self.VVoSsS, mode, True) , [])
   else:
    VVPogp = None
    VVxkVZ = None
   header   = None
   widths   = (100   , 0  )
   FFl3hs(self, None, title=title, width=1200, header=header, VVouKi=list, VVw7oP=widths, VVcK4p=30, VVtXvO=VVtXvO, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVXwx9=VVXwx9, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VVuQjw=VVuQjw, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVSp1a:
     txt += "\n\n( %s )" % self.VVSp1a
   else:
    txt = "Could not get Categories from server!"
   FFRGBb(self, txt, title=title)
 def VVCa7K(self, mode, VVYo8S, title, txt, colList):
  FF0rXP(VVYo8S, BF(self.VVuq8z, mode, VVYo8S, title, txt, colList), title="Downloading ...")
 def VVuq8z(self, mode, VVYo8S, title, txt, colList):
  token, profile, tErr = self.VVx5FX()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVOAxN(self.VV1GYN(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCCGrE.VVMcOx(item, "id"    )
      actors   = CCCGrE.VVMcOx(item, "actors"   )
      added   = CCCGrE.VVMcOx(item, "added"   )
      age    = CCCGrE.VVMcOx(item, "age"   )
      category_id  = CCCGrE.VVMcOx(item, "category_id" )
      description  = CCCGrE.VVMcOx(item, "description" )
      director  = CCCGrE.VVMcOx(item, "director"  )
      genres_str  = CCCGrE.VVMcOx(item, "genres_str"  )
      name   = CCCGrE.VVMcOx(item, "name"   )
      path   = CCCGrE.VVMcOx(item, "path"   )
      screenshot_uri = CCCGrE.VVMcOx(item, "screenshot_uri" )
      series   = CCCGrE.VVMcOx(item, "series"   )
      cmd    = CCCGrE.VVMcOx(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVXwx9  = ("Play"    , BF(self.VVs1wr, mode)       , [])
   VVTMvN = (""     , BF(self.VVsQKY, mode)     , [])
   VVtXvO = ("Home Menu"   , FF1fb7            , [])
   VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, "sp", seriesName) , [])
   VVPogp = ("Options"   , BF(self.VVGfJO, "pEp", mode, seriesName) , [])
   VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVK4mA  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFl3hs(self, None, title=seriesName, width=1200, header=header, VVouKi=list, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindIptv, VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000")
  else:
   FFRGBb(self, "Could not get Episodes from server!", title=seriesName)
 def VVoSsS(self, mode, searchInCat, VVYo8S, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVv6X1 = []
  VVv6X1.append(("Keyboard"  , "manualEntry"))
  VVv6X1.append(("From Filter" , "fromFilter"))
  FFLwVh(self, BF(self.VVRuBA, VVYo8S, mode, searchCatId), title="Input Type", VVv6X1=VVv6X1, width=400)
 def VVRuBA(self, VVYo8S, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFufG1(self, BF(self.VVzpV3, VVYo8S, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCFC3v(self)
    filterObj.VVgJ0W(BF(self.VVzpV3, VVYo8S, mode, searchCatId))
 def VVzpV3(self, VVYo8S, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFcghP(CFG.lastFindIptv, searchName)
   title = self.VVgPq9(mode, searchName)
   if "," in searchName : FFRGBb(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFRGBb(self, "Enter at least 3 characters.", title=title)
   else     :
    VV30jT = CCcIbP()
    if CFG.hideIptvServerAdultWords.getValue() and VV30jT.VVkXPN([searchName]):
     FFRGBb(self, VV30jT.VVwn3a(), title=title)
    else:
     self.VVsC3i(mode, searchName, "", searchName, searchCatId)
 def VVVKtY(self, mode, VVYo8S, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVsC3i(mode, bName, catID, "", "")
 def VVsC3i(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVsEi1, mode, bName, catID, searchName, searchCatId)
      , VVkuAk = BF(self.VVHVTU, mode, bName, catID, searchName, searchCatId))
 def VVHVTU(self, mode, bName, catID, searchName, searchCatId, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVgPq9(mode, searchName)
  else   : title = "%s : %s" % (self.VVB19C(mode), bName)
  if VVwHZ6:
   VV6vKb = None
   VVPogp = None
   if mode == "series":
    VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR("series2")
    VVXwx9  = ("Episodes"   , BF(self.VVCa7K, mode)           , [])
   else:
    VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR("")
    VVXwx9  = ("Play"    , BF(self.VVs1wr, mode)           , [])
    VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, "vp" if mode == "vod" else "", "") , [])
    VVPogp = ("Options"   , BF(self.VVGfJO, "pCh", mode, bName)      , [])
   VVTMvN = (""      , BF(self.VV2DIX, mode)         , [])
   VVtXvO = ("Home Menu"    , FF1fb7                , [])
   VVxkVZ = ("Posters Mode"   , BF(self.VVRyCp, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVK4mA  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VVwHZ6, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindIptv, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VVuQjw=VVuQjw, VVWKtq=True, searchCol=1)
   if not VVzWxR:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVYo8S.VV7nKt(VVYo8S.VVjAQ8() + tot)
    if threadErr: FFfad8(VVYo8S, "Error while reading !", 2000)
    else  : FFfad8(VVYo8S, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFRGBb(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFRGBb(self, "Could not get list from server !", title=title)
 def VV2DIX(self, mode, VVYo8S, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFwYti(self, fncMode=CCWhEO.VVK5no, portalHost=self.VVXXml, portalMac=self.VVg2mm, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVlgkg(mode, VVYo8S, title, txt, colList)
 def VVsQKY(self, mode, VVYo8S, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFf1xo(colList[10], VVe79W)
  txt += "Description:\n%s" % FFf1xo(colList[11], VVe79W)
  self.VVlgkg(mode, VVYo8S, title, txt, colList)
 def VVlgkg(self, mode, VVYo8S, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, colList)
  refCode, chUrl = self.VVEjtU(self.VVXXml, self.VVg2mm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFwYti(self, fncMode=CCWhEO.VVuMYr, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVsEi1(self, mode, bName, catID, searchName, searchCatId, VVtdJ0):
  try:
   token, profile, tErr = self.VVx5FX()
   if not token:
    return
   if VVtdJ0.isCancelled:
    return
   VVtdJ0.VVwHZ6, total_items, max_page_items, err = self.VVkg6z(mode, catID, 1, 1, searchName, searchCatId)
   if VVtdJ0.isCancelled:
    return
   if VVtdJ0.VVwHZ6 and total_items > -1 and max_page_items > -1:
    VVtdJ0.VVhRNu(total_items)
    VVtdJ0.VVcdeL(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVtdJ0.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVkg6z(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVtdJ0.VVRnkp()
     if VVtdJ0.isCancelled:
      return
     if list:
      VVtdJ0.VVwHZ6 += list
      VVtdJ0.VVcdeL(len(list), True)
  except:
   pass
 def VVkg6z(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVEzOF(mode, searchName, searchCatId, page)
  else   : url = self.VVmBHe(mode, catID, page)
  res, err = self.VVOAxN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV6hIS(CCCGrE.VVMcOx(item, "total_items" ))
     max_page_items = self.VV6hIS(CCCGrE.VVMcOx(item, "max_page_items" ))
     VV30jT = CCcIbP()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCCGrE.VVMcOx(item, "id"    )
      name   = CCCGrE.VVMcOx(item, "name"   )
      o_name   = CCCGrE.VVMcOx(item, "o_name"   )
      tv_genre_id  = CCCGrE.VVMcOx(item, "tv_genre_id" )
      number   = CCCGrE.VVMcOx(item, "number"   ) or str(counter)
      logo   = CCCGrE.VVMcOx(item, "logo"   )
      screenshot_uri = CCCGrE.VVMcOx(item, "screenshot_uri" )
      cmd    = CCCGrE.VVMcOx(item, "cmd"   )
      censored  = CCCGrE.VVMcOx(item, "censored"  )
      genres_str  = CCCGrE.VVMcOx(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVXXml + picon).replace(sp * 2, sp)
      counter += 1
      name = VV30jT.VVBVVp(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV6hIS(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVs1wr(self, mode, VVYo8S, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, colList)
  refCode, chUrl = self.VVEjtU(self.VVXXml, self.VVg2mm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VV6gjy(chName):
   FFfad8(VVYo8S, "This is a marker!", 300)
  else:
   FF0rXP(VVYo8S, BF(self.VVAegk, mode, VVYo8S, chUrl), title="Playing ...")
 def VVAegk(self, mode, VVYo8S, chUrl):
  FFTztI(self, chUrl, VVLjiH=False)
  CCSeoi.VVLNOL(self.session, iptvTableParams=(self, VVYo8S, mode))
 def VVVP2J(self, mode, VVYo8S, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, colList)
  refCode, chUrl = self.VVEjtU(self.VVXXml, self.VVg2mm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV5Iil(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVYiQx(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVv6X1 = []
    VVv6X1.append((title        , "inst" ))
    VVv6X1.append(("Update Packages then %s" % title , "updInst" ))
    FFLwVh(SELF, BF(CCavOd.VVsVf2, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVv6X1=VVv6X1)
   return False
 @staticmethod
 def VVsVf2(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFrxPD(VVi3Ri, "")
   if cmdUpd:
    cmdInst = FFohUm(VViQjU, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF8ZtC(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVo3en=cbFnc)
   else:
    FF2yhz(SELF)
class CCCGrE(Screen, CCavOd, CCwXmk):
 VV0lA3    = 0
 VV891E    = 1
 VVlK74    = 2
 VVKmsG    = 3
 VVuzHf     = 4
 VVG2Js     = 5
 VVnOic     = 6
 VVJREL     = 7
 VVRk9D     = 8
 VVzdeS     = 9
 VVpgdX      = 10
 VVrJzD     = 11
 VVwmeo     = 12
 VVn8qi     = 13
 VVVVq1     = 14
 VVRdi3      = 15
 VVoU5v      = 16
 VVVUk1      = 17
 VVkZ6U      = 18
 VVrju7      = 19
 VVAzBQ    = 0
 VV1zOs   = 1
 VVRcC9   = 2
 VVUXD1   = 3
 VVO2Y0  = 4
 VVQ4D1  = 5
 VVUAey   = 6
 VVwImz   = 7
 VVSAqH  = 8
 VVopCR  = 9
 VVUvCm  = 10
 VVaOAt = 0
 VVgi4B = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFUxcO(VVonST, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVYo8S    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV0M80Data    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCCGrE.VV2TEe(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCavOd.__init__(self)
  VVv6X1 = self.VVVkCu()
  FFDBTO(self, title="IPTV", VVv6X1=VVv6X1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self["myMenu"].setList(self.VVVkCu())
  FFhukk(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFIpXz(self["myMenu"])
   FFCpOu(self)
   if self.m3uOrM3u8File:
    self.VVdynr(self.m3uOrM3u8File, (0, (), False, ""))
 def VVVkCu(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVityU
  VVv6X1 = []
  if isFav1: VVv6X1.append((c +  "Favourite Playlist Server"   , "VVkjzC" ))
  if isFav2: VVv6X1.append((c +  "Favourite Portal Server"    , "VVQfhiPortal" ))
  VVv6X1.append(("IPTV Server Browser (from Playlists)"     , "VV0M80_fromPlayList" ))
  VVv6X1.append(("IPTV Server Browser (from Portal List)"    , "VV0M80_fromMac"  ))
  VVv6X1.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV0M80_fromM3u"  ))
  qUrl, iptvRef = CCCGrE.VVp7NB(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVv6X1.append((item     , "VV0M80_fromCurrChan" ))
  else       : VVv6X1.append((item     ,       ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("M3U/M3U8 File Browser"        , "VViG9W"   ))
  if self.iptvFileAvailable:
   VVv6X1.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVv6X1.append(VVdKVg)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVv6X1.append((item1            , "refreshIptvEPG"   ))
   VVv6X1.append((item2            , "refreshIptvPicons"  ))
  else:
   VVv6X1.append((item1            ,       ))
   VVv6X1.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVv6X1.append(VVdKVg)
   c1, c2 = VVq8cV, VVKiZJ
   t1 = FFf1xo("auto-match names", VVityU)
   t2 = FFf1xo("from xml file"  , VVityU)
   VVv6X1.append((c1 + "Count Available IPTV Channels"    , "VVVdzZ"    ))
   VVv6X1.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVv6X1.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VV38DR" ))
   VVv6X1.append((VV8tcv + "More Reference Tools ..."  , "VVRW0m"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Reload Channels and Bouquets"       , "VVdmdC"   ))
  VVv6X1.append(VVdKVg)
  if not CCNUxQ.VVFz7u():
   VVv6X1.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVv6X1.append(("Download Manager ... No donwloads"    ,       ))
  return VVv6X1
 def VVJnhV(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VV0R0B"   : self.VV0R0B()
   elif item == "VVAk7n" : FFWkqs(self, self.VVAk7n, "Change Current List References to Unique Codes ?")
   elif item == "VViuGY_rows" : FFWkqs(self, BF(FF0rXP, self.VVYo8S, self.VViuGY), "Change Current List References to Identical Codes ?")
   elif item == "VVeiNf"   : self.VVeiNf(tTitle)
   elif item == "VV2ibx"   : self.VV2ibx(tTitle)
   elif item == "VVkjzC" : self.VVQfhi(False)
   elif item == "VVQfhiPortal" : self.VVQfhi(True)
   elif item == "VV0M80_fromPlayList" : FF0rXP(self, BF(self.VViBNr, 1), title=title)
   elif item == "VV0M80_fromM3u"  : FF0rXP(self, BF(self.VVPt9P, CCCGrE.VVaOAt), title=title)
   elif item == "VV0M80_fromMac"  : self.VVA9W2()
   elif item == "VV0M80_fromCurrChan" : self.VVysUn()
   elif item == "VViG9W"   : self.VViG9W()
   elif item == "iptvTable_all"   : FF0rXP(self, BF(self.VVEZmZ, self.VV0lA3), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCCGrE.VV3khE(self)
   elif item == "refreshIptvPicons"  : self.VVMUup()
   elif item == "VVVdzZ"    : FF0rXP(self, self.VVVdzZ)
   elif item == "copyEpgPicons"   : self.VV6g85(False)
   elif item == "renumIptvRef_fromFile" : self.VV6g85(True)
   elif item == "VV38DR" : FFWkqs(self, BF(FF0rXP, self, self.VV38DR), VVfTYp="Continue ?")
   elif item == "VVRW0m"    : self.VVRW0m()
   elif item == "VVdmdC"   : FF0rXP(self, BF(CCnEIM.VVdmdC, self))
   elif item == "dload_stat"    : CCNUxQ.VV4XQs(self)
 def VViG9W(self):
  if CCavOd.VVYiQx(self):
   FF0rXP(self, BF(self.VVPt9P, CCCGrE.VVgi4B), title="Searching ...")
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVJnhV(item)
 def VVEZmZ(self, mode):
  VV4Gbf = self.VVMCCd(mode)
  if VV4Gbf:
   VV6vKb = ("Current Service", self.VV5Pg5 , [])
   VVPogp = ("Options"  , self.VV21td   , [])
   VVxkVZ = ("Filter"   , self.VV9zh8   , [])
   VVXwx9  = ("Play"   , BF(self.VVE3aj)  , [])
   VVTMvN = (""    , self.VVu4oE    , [])
   VVxKfW = (""    , self.VVmnoU     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVK4mA  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFl3hs(self, None, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26
     , VVXwx9=VVXwx9, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVTMvN=VVTMvN, VVxKfW=VVxKfW
     , VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000", VVWKtq=True, searchCol=1)
  else:
   if mode == self.VVzdeS: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFRGBb(self, err)
 def VVmnoU(self, VVYo8S, title, txt, colList):
  self.VVYo8S = VVYo8S
 def VV21td(self, VVYo8S, title, txt, colList):
  VVv6X1 = []
  VVv6X1.append(("Add Current List to a New Bouquet"    , "VV0R0B"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Change Current List References to Unique Codes" , "VVAk7n"))
  VVv6X1.append(("Change Current List References to Identical Codes", "VViuGY_rows" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Share Reference with DVB Service (manual entry)" , "VVeiNf"   ))
  VVv6X1.append(("Share Reference with DVB Service (auto-find)"  , "VV2ibx"   ))
  FFLwVh(self, self.VVJnhV, title="IPTV Tools", VVv6X1=VVv6X1)
 def VV9zh8(self, VVYo8S, title, txt, colList):
  VVv6X1 = []
  VVv6X1.append(("All"         , "all"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Prefix of Selected Channel"   , "sameName" ))
  VVv6X1.append(("Suggest Words from Selected Channel" , "partName" ))
  VVv6X1.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVv6X1.append(("Duplicate References"     , "depRef"  ))
  VVv6X1.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVv6X1.append(("Stream Relay"       , "SRelay"  ))
  VVv6X1.append(FF9558("Category"))
  VVv6X1.append(("Live TV"        , "live"  ))
  VVv6X1.append(("VOD"         , "vod"   ))
  VVv6X1.append(("Series"        , "series"  ))
  VVv6X1.append(("Uncategorised"      , "uncat"  ))
  VVv6X1.append(FF9558("Media"))
  VVv6X1.append(("Video"        , "video"  ))
  VVv6X1.append(("Audio"        , "audio"  ))
  VVv6X1.append(FF9558("File Type"))
  VVv6X1.append(("MKV"         , "MKV"   ))
  VVv6X1.append(("MP4"         , "MP4"   ))
  VVv6X1.append(("MP3"         , "MP3"   ))
  VVv6X1.append(("AVI"         , "AVI"   ))
  VVv6X1.append(("FLV"         , "FLV"   ))
  VVv6X1.extend(CCQii3.VVkefo(prefix="__b__"))
  inFilterFnc = BF(self.VVuFNx, VVYo8S) if VVYo8S.VVjAQ8().startswith("IPTV Filter ") else None
  filterObj = CCFC3v(self)
  filterObj.VVTmbZ(VVv6X1, VVv6X1, BF(self.VVKvg0, VVYo8S, False), inFilterFnc=inFilterFnc)
 def VVuFNx(self, VVYo8S, menuInstance, item):
  self.VVKvg0(VVYo8S, True, item)
 def VVKvg0(self, VVYo8S, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVYo8S.VVN3DQ(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV0lA3 , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV891E , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVlK74 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVKmsG , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVnOic  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVJREL  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVRk9D  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVzdeS  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVpgdX   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVrJzD  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVwmeo  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVn8qi  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVVVq1  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVRdi3   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVoU5v   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVVUk1   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVkZ6U   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVrju7   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVuzHf  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVG2Js  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVlK74:
   VVv6X1 = []
   chName = VVYo8S.VVN3DQ(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVv6X1.append((item, item))
    if not VVv6X1 and chName:
     VVv6X1.append((chName, chName))
    FFLwVh(self, BF(self.VVSId6, title), title="Words from Current Selection", VVv6X1=VVv6X1)
   else:
    VVYo8S.VVu9dh("Invalid Channel Name")
  else:
   words, asPrefix = CCFC3v.VVXFHp(words)
   if not words and mode in (self.VVuzHf, self.VVG2Js):
    FFfad8(self.VVYo8S, "Incorrect filter", 2000)
   else:
    FF0rXP(self.VVYo8S, BF(self.VVz8iS, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVSId6(self, title, word=None):
  if word:
   words = [word.lower()]
   FF0rXP(self.VVYo8S, BF(self.VVz8iS, self.VVlK74, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVlDia(txt):
  return "#f#11ffff00#" + txt
 def VVz8iS(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VV4Gbf = self.VVZiJT(mode=mode, words=words, asPrefix=asPrefix)
  else       : VV4Gbf = self.VVMCCd(mode=mode, words=words, asPrefix=asPrefix)
  if VV4Gbf : self.VVYo8S.VVPCrn(VV4Gbf, title)
  else  : self.VVYo8S.VVu9dh("Not found")
 def VVZiJT(self, mode=0, words=None, asPrefix=False):
  VV4Gbf = []
  for row in self.VVYo8S.VVl6T3():
   row = list(map(str.strip, row))
   chNum, chName, VVwRnH, chType, refCode, url = row
   if self.VV7gJG(mode, refCode, FFT8KE(url).lower(), chName, words, VVwRnH.lower(), asPrefix):
    VV4Gbf.append(row)
  VV4Gbf = self.VVJ8HU(mode, VV4Gbf)
  return VV4Gbf
 def VVMCCd(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VV4Gbf = []
  files  = self.VVVL8t()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFUKzq(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVwRnH = span.group(1)
    else : VVwRnH = ""
    VVwRnH_lCase = VVwRnH.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV6gjy(chName): chNameMod = self.VVlDia(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVwRnH, chType + (" SRel" if FFUUIm(url) else ""), refCode, url)
     if self.VV7gJG(mode, refCode, FFT8KE(url).lower(), chName, words, VVwRnH_lCase, asPrefix):
      VV4Gbf.append(row)
      chNum += 1
  VV4Gbf = self.VVJ8HU(mode, VV4Gbf)
  return VV4Gbf
 def VVJ8HU(self, mode, VV4Gbf):
  newRows = []
  if VV4Gbf and mode == self.VVnOic:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VV4Gbf)
   for item in VV4Gbf:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VV4Gbf
 def VV7gJG(self, mode, refCode, tUrl, chName, words, VVwRnH_lCase, asPrefix):
  if   mode == self.VV0lA3 : return True
  elif mode == self.VVnOic : return True
  elif mode == self.VVJREL  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVRk9D : return FFUUIm(tUrl)
  elif mode == self.VVn8qi  : return CCCGrE.VVs0VG(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVVVq1  : return CCCGrE.VVs0VG(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVzdeS  : return CCCGrE.VVs0VG(tUrl, compareType="live")
  elif mode == self.VVpgdX  : return CCCGrE.VVs0VG(tUrl, compareType="movie")
  elif mode == self.VVrJzD : return CCCGrE.VVs0VG(tUrl, compareType="series")
  elif mode == self.VVwmeo  : return CCCGrE.VVs0VG(tUrl, compareType="")
  elif mode == self.VVRdi3  : return CCCGrE.VVs0VG(tUrl, compareExt="mkv")
  elif mode == self.VVoU5v  : return CCCGrE.VVs0VG(tUrl, compareExt="mp4")
  elif mode == self.VVVUk1  : return CCCGrE.VVs0VG(tUrl, compareExt="mp3")
  elif mode == self.VVkZ6U  : return CCCGrE.VVs0VG(tUrl, compareExt="avi")
  elif mode == self.VVrju7  : return CCCGrE.VVs0VG(tUrl, compareExt="flv")
  elif mode == self.VV891E: return chName.lower().startswith(words[0])
  elif mode == self.VVlK74: return words[0] in chName.lower()
  elif mode == self.VVKmsG: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVuzHf : return words[0] == VVwRnH_lCase
  elif mode == self.VVG2Js :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VV0R0B(self):
  picker = CCQii3(self, self.VVYo8S, "Add to Bouquet", self.VVZXsq)
 def VVZXsq(self):
  chUrlLst = []
  for row in self.VVYo8S.VVl6T3():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVRW0m(self):
  c1 = VVkC8X
  t1 = FFf1xo("Bouquet", VVityU)
  t2 = FFf1xo("ALL", VVityU)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVv6X1 = []
  VVv6X1.append((c1 + "Check System Acceptable Reference Types" , "VVaOGa"    ))
  if self.iptvFileAvailable:
   VVv6X1.append((c1 + "Check Reference Codes Format"  , "VVFgoh"    ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVDdCH" ))
  VVv6X1.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVJ31y_all"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Change %s References to Unique Codes" % t2 , "VVvqTH"  ))
  VVv6X1.append(("Change %s References to Identical Codes" % t2 , "VViuGY_all"  ))
  OKBtnFnc = self.VVv9Y1
  FFLwVh(self, None, width=1200, title="Reference Tools", VVv6X1=VVv6X1, OKBtnFnc=OKBtnFnc)
 def VVv9Y1(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVaOGa"    : FF0rXP(menuInstance, self.VVaOGa)
   elif item == "VVFgoh"     : FF0rXP(menuInstance, self.VVFgoh)
   elif item == "VVDdCH" : self.VVDdCH(menuInstance)
   elif item == "VVJ31y_all"  : self.VVogrJ(menuInstance, None, None)
   elif item == "VVvqTH"  : FFWkqs(self, BF(self.VVvqTH , menuInstance, txt), title=txt, VVfTYp=ques)
   elif item == "VViuGY_all"  : FFWkqs(self, BF(FF0rXP, menuInstance, self.VViuGY), title=txt, VVfTYp=ques)
 def VVogrJ(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVv6X1 = []
  VVv6X1.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVv6X1.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVv6X1.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVv6X1.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVv6X1.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))  #
  VVv6X1.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFLwVh(self, BF(self.VVAc2L, menuInstance, bName, bPath), VVv6X1=VVv6X1, width=750, title="Change Reference Types to:")
 def VVAc2L(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVd2A5(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVd2A5(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVd2A5(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVd2A5(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVd2A5(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVd2A5(menuInstance, bName, bPath, "8193")
 def VVDdCH(self, menuInstance):
  VVv6X1 = CCQii3.VVkefo()
  if VVv6X1:
   FFLwVh(self, BF(self.VVlW2M, menuInstance), VVv6X1=VVv6X1, title="IPTV Bouquets", VVrAw7=True)
  else:
   FFfad8(menuInstance, "No bouquets Found !", 1500)
 def VVlW2M(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVxlEW + span.group(1)
    if fileExists(bPath): self.VVogrJ(menuInstance, bName, bPath)
    else    : FFfad8(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFfad8(menuInstance, "Cannot process bouquet !", 2000)
 def VVd2A5(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFf1xo(bName, VVy4op)
  else : title = "Change for %s" % FFf1xo("All IPTV Services", VVy4op)
  FFWkqs(self, BF(FF0rXP, menuInstance, BF(self.VVYyjs, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFf1xo(rType, VVy4op), title=title)
 def VVYyjs(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVVL8t()
  if files:
   newRType = rType + ":"
   piconPath = CCxA8L.VV76e0()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCOjzn.VVAreK(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFRGBb(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFWqNF("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFWqNF(cmd))
  self.VVn9yT(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVVdzZ(self):
  totFiles = 0
  files  = self.VVVL8t()
  if files:
   totFiles = len(files)
  totChans = 0
  VV4Gbf = self.VVMCCd()
  if VV4Gbf:
   totChans = len(VV4Gbf)
  FFipfq(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVFgoh(self):
  files  = self.VVVL8t()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFUKzq(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVvsR7
   else    : color = VVqskC
   totInvalid = FFf1xo(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFf1xo("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFipfq(self, txt, title="Check IPTV References")
 def VVaOGa(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCQii3.VVGUOl(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVzrZo = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVzrZo:
   VVN915 = FFWeXA(VVzrZo)
   if VVN915:
    for service in VVN915:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVxlEW + userBName
  bFile = VVxlEW + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFWqNF("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFWqNF("rm -f '%s'" % path)
  os.system(cmd)
  FFVJ21()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVvsR7
    else     : res, color = "No" , VVqskC
    txt += "    %s\t: %s\n" % (item, FFf1xo(res, color))
   FFipfq(self, txt, title=title)
  else:
   txt = FFRGBb(self, "Could not complete the test on your system!", title=title)
 def VV38DR(self):
  VVMUsL, err = CCnEIM.VVxj6i(self, CCnEIM.VVmtt4)
  if VVMUsL:
   totChannels = 0
   totChange = 0
   for path in self.VVVL8t():
    toSave = False
    txt = FFUKzq(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVMUsL.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVn9yT(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFRGBb(self, 'No channels in "lamedb" !')
 def VVvqTH(self, menuInstance, title):
  bFiles = self.VVVL8t()
  if bFiles:
   self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVJ9cc, bFiles)
       , VVkuAk = BF(self.VVlMbD, title))
  else:
   FFfad8(menuInstance, "No bouquets files !", 1500)
 def VVJ9cc(self, bFiles, VVtdJ0):
  VVtdJ0.VVwHZ6 = ""
  VVtdJ0.VVyHD5("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFRtPk(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVtdJ0 or VVtdJ0.isCancelled:
   return
  elif not totLines:
   VVtdJ0.VVwHZ6 = "No IPTV Services !"
   return
  else:
   VVtdJ0.VVhRNu(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFRtPk(path)
    for ndx, line in enumerate(lines):
     if not VVtdJ0 or VVtdJ0.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVtdJ0:
       VVtdJ0.VVyHD5("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVtdJ0:
       VVtdJ0.VVcdeL(1)
      refCode, startId, startNS = CCQii3.VVUZsf(rType, CCQii3.VVy63F, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVtdJ0:
        VVtdJ0.VVwHZ6 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVlMbD(self, title, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVwHZ6:
   txt += "\n\n%s\n%s" % (FFf1xo("Ended with Error:", VVqskC), VVwHZ6)
  self.VVn9yT(True, title, txt)
 def VVAk7n(self):
  bFiles = self.VVVL8t()
  if not bFiles:
   FFfad8(self.VVYo8S, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVYo8S.VVl6T3():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFfad8(self.VVYo8S, "Cannot read list", 1500)
   return
  self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVXKB2, bFiles, tableRefList)
      , VVkuAk = BF(self.VVlMbD, "Change Current List References to Unique Codes"))
 def VVXKB2(self, bFiles, tableRefList, VVtdJ0):
  VVtdJ0.VVwHZ6 = ""
  VVtdJ0.VVyHD5("Reading System References ...")
  refLst = CCQii3.VV0Mk9(CCQii3.VVy63F, stripRType=True)
  if not VVtdJ0 or VVtdJ0.isCancelled:
   return
  VVtdJ0.VVhRNu(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFUKzq(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVtdJ0 or VVtdJ0.isCancelled:
     return
    VVtdJ0.VVyHD5("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVtdJ0 or VVtdJ0.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVtdJ0.VVcdeL(1)
      refCode, startId, startNS = CCQii3.VVUZsf(rType, CCQii3.VVy63F, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVtdJ0:
        VVtdJ0.VVwHZ6 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VViuGY(self):
  list = None
  if self.VVYo8S:
   list = []
   for row in self.VVYo8S.VVl6T3():
    list.append(row[4] + row[5])
  files  = self.VVVL8t()
  totChange = 0
  if files:
   for path in files:
    lines = FFRtPk(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVn9yT(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVn9yT(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFVJ21()
   if refreshTable and self.VVYo8S:
    VV4Gbf = self.VVMCCd()
    if VV4Gbf and self.VVYo8S:
     self.VVYo8S.VVPCrn(VV4Gbf, self.tableTitle)
     self.VVYo8S.VVu9dh(txt)
   FFipfq(self, txt, title=title)
  else:
   FFrNpu(self, "No changes.")
 def VVVL8t(self):
  return CCCGrE.VV2TEe()
 @staticmethod
 def VV2TEe(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVxlEW + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFUKzq(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVu4oE(self, VVYo8S, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFT8KE(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFwYti(self, fncMode=CCWhEO.VVPa5X, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVwW9m(self, VVYo8S, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVE3aj(self, VVYo8S, title, txt, colList):
  chName, chUrl = self.VVwW9m(VVYo8S, colList)
  self.VVTBtN(VVYo8S, chName, chUrl, "localIptv")
 def VVgwhf(self, mode, VVYo8S, colList):
  chName, chUrl, picUrl, refCode = self.VVggEa(mode, colList)
  return chName, chUrl
 def VVEfaI(self, mode, VVYo8S, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVggEa(mode, colList)
  self.VVTBtN(VVYo8S, chName, chUrl, mode)
 def VVTBtN(self, VVYo8S, chName, chUrl, playerFlag):
  chName = FFtomh(chName)
  if self.VV6gjy(chName):
   FFfad8(VVYo8S, "This is a marker!", 300)
  else:
   FF0rXP(VVYo8S, BF(self.VVQWxA, VVYo8S, chUrl, playerFlag), title="Playing ...")
 def VVQWxA(self, VVYo8S, chUrl, playerFlag):
  FFTztI(self, chUrl, VVLjiH=False)
  CCSeoi.VVLNOL(self.session, iptvTableParams=(self, VVYo8S, playerFlag))
 @staticmethod
 def VV6gjy(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VV5Pg5(self, VVYo8S, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  if refCode:
   url1 = FFT8KE(origUrl.strip())
   for ndx, row in enumerate(VVYo8S.VVl6T3()):
    if refCode in row[4]:
     tableRow = FFT8KE(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVYo8S.VVG9tX(ndx)
      break
   else:
    FFfad8(VVYo8S, "No found", 1000)
 def VVPt9P(self, m3uMode):
  lines = self.VVFYLC(3)
  if lines:
   lines.sort()
   VVv6X1 = []
   for line in lines:
    VVv6X1.append((line, line))
   if m3uMode == CCCGrE.VVaOAt:
    title = "Browse Server from M3U URLs"
    VVxtuz = ("All to Playlist", self.VV5uDB)
   else:
    title = "M3U/M3U8 File Browser"
    VVxtuz = None
   OKBtnFnc = BF(self.VVv5PM, m3uMode, title)
   infoBtnFnc = self.VVuA4J
   FFLwVh(self, None, title=title, VVv6X1=VVv6X1, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VVxtuz=VVxtuz, VVyRL8="#11221122", VVmr0Y="#11221122")
 def VVv5PM(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCCGrE.VVaOAt:
    FF0rXP(menuInstance, BF(self.VV0VfE, title, path))
   else:
    self.VVAYsx(menuInstance, path)
 def VVAYsx(self, menuInstance, path=None):
  if path:
   VVv6X1 = []
   VVv6X1.append(("All"         , "all"   ))
   VVv6X1.append(FF9558("Category"))
   VVv6X1.append(("Live TV"        , "live"  ))
   VVv6X1.append(("VOD"         , "vod"   ))
   VVv6X1.append(("Series"        , "series"  ))
   VVv6X1.append(("Uncategorised"      , "uncat"  ))
   VVv6X1.append(FF9558("Media"))
   VVv6X1.append(("Video"        , "video"  ))
   VVv6X1.append(("Audio"        , "audio"  ))
   VVv6X1.append(FF9558("File Type"))
   VVv6X1.append(("MKV"         , "MKV"   ))
   VVv6X1.append(("MP4"         , "MP4"   ))
   VVv6X1.append(("MP3"         , "MP3"   ))
   VVv6X1.append(("AVI"         , "AVI"   ))
   VVv6X1.append(("FLV"         , "FLV"   ))
   filterObj = CCFC3v(self, VVyRL8="#11552233", VVmr0Y="#11552233")
   filterObj.VVTmbZ(VVv6X1, [], BF(self.VVEGW6, menuInstance, path), inFilterFnc=None)
 def VVEGW6(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV0lA3 , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVzdeS  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVpgdX  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVrJzD  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVwmeo  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVn8qi  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVVVq1  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVRdi3  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVoU5v  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVVUk1  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVkZ6U  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVrju7  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVG2Js  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCFC3v.VVXFHp(words)
   if not mode == self.VV0lA3:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFf1xo(fTitle, VVe79W)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF0rXP(menuInstance, BF(self.VVdynr, path, m3uFilterParam))
 def VVdynr(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFUKzq(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VV30jT = CCcIbP()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVqIkf(propLine, "group-title") or "-"
   if not group == "-" and VV30jT.VVBVVp(group):
    groups.add(group)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VV4Gbf = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VV4Gbf.append((group, group))
   VV4Gbf.append(("ALL", ""))
   VV4Gbf.sort(key=lambda x: x[0].lower())
   VVgYq4 = self.VV1r8Z
   VVXwx9  = ("Select" , BF(self.VVMnPI, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVK4mA  = (LEFT  , LEFT)
   FFl3hs(self, None, title=title, width= 1000, header=None, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=30, VVXwx9=VVXwx9, VVgYq4=VVgYq4, lastFindConfigObj=CFG.lastFindIptv
     , VVyRL8="#11110022", VVmr0Y="#11110022", VVOSNp="#11110022", VVuQjw="#00444400")
  else:
   txt = FFUKzq(srcPath)
   self.VVTJkh(txt, "", m3uFilterParam)
 def VVMnPI(self, srcPath, m3uFilterParam, VVYo8S, title, txt, colList):
  group = colList[1]
  txt = FFUKzq(srcPath)
  self.VVTJkh(txt, group, m3uFilterParam)
 def VVTJkh(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VVhGkF, lst, filterGroup, m3uFilterParam)
       , VVkuAk = BF(self.VVIwra, title, bName))
  else:
   self.VVHPyC("Not valid lines found !", title)
 def VVhGkF(self, lst, filterGroup, m3uFilterParam, VVtdJ0):
  VVtdJ0.VVwHZ6 = []
  VVtdJ0.VVhRNu(len(lst))
  VV30jT = CCcIbP()
  num = 0
  for cols in lst:
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVqIkf(propLine, "tvg-logo")
   group = self.VVqIkf(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VV30jT.VVBVVp(group) : skip = True
    elif chName and not VV30jT.VVBVVp(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VV7gJG(mode, "", FFT8KE(url).lower(), chName, words, "", asPrefix)
    if not skip and VVtdJ0:
     num += 1
     VVtdJ0.VVwHZ6.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVtdJ0:
   VVtdJ0.VVPMCq("Loading %d Channels" % len(VVtdJ0.VVwHZ6))
 def VVIwra(self, title, bName, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVwHZ6:
   VVgYq4 = self.VV1r8Z
   VVXwx9  = ("Select"   , BF(self.VVZ0xt, title)   , [])
   VVTMvN = (""    , self.VVcFnK        , [])
   VV6vKb = ("Download PIcons", self.VVyG0h       , [])
   VVPogp = ("Options"  , BF(self.VVGfJO, "m3Ch", "", bName) , [])
   VVxkVZ = ("Posters Mode" , BF(self.VVRyCp, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVK4mA  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFl3hs(self, None, title=title, header=header, VVouKi=VVwHZ6, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VVXwx9=VVXwx9, VVgYq4=VVgYq4, VVTMvN=VVTMvN, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindIptv, VVWKtq=True, searchCol=1
     , VVyRL8="#0a00192B", VVmr0Y="#0a00192B", VVOSNp="#0a00192B", VVuQjw="#00000000")
  else:
   self.VVHPyC("Not found !", title)
 def VVyG0h(self, VVYo8S, title, txt, colList):
  self.VVF2Rs(VVYo8S, "m3u/m3u8")
 def VV9DSc(self, rowNum, url, chName):
  refCode = self.VVWYWs(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFAPsb(url), chName)
  return chUrl
 def VVWYWs(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVhgAF(catID, stID, chNum)
  return refCode
 def VVqIkf(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVZ0xt(self, Title, VVYo8S, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF0rXP(VVYo8S, BF(self.VVNUnD, Title, VVYo8S, colList), title="Checking Server ...")
  else:
   self.VVOZ7C(VVYo8S, url, chName)
 def VVNUnD(self, title, VVYo8S, colList):
  if not CCavOd.VVYiQx(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCWc1W.VV7euB(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVv6X1 = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCCGrE.VVrJAJ(url, fPath)
     VVv6X1.append((resol, fullUrl))
    if VVv6X1:
     if len(VVv6X1) > 1:
      FFLwVh(self, BF(self.VVFrl4, VVYo8S, chName), VVv6X1=VVv6X1, title="Resolution", VVrAw7=True, VV8k4Z=True)
     else:
      self.VVOZ7C(VVYo8S, VVv6X1[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVOZ7C(VVYo8S, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCCGrE.VVrJAJ(url, span.group(1))
       self.VVOZ7C(VVYo8S, fullUrl, chName)
      else:
       self.VVa2fj("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVTJkh(txt, filterGroup="")
      return
    self.VVOZ7C(VVYo8S, url, chName)
   else:
    self.VVHPyC("Cannot process this channel !", title)
  else:
   self.VVHPyC(err, title)
 def VVFrl4(self, VVYo8S, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVOZ7C(VVYo8S, resolUrl, chName)
 def VVOZ7C(self, VVYo8S, url, chName):
  FF0rXP(VVYo8S, BF(self.VVEdY6, VVYo8S, url, chName), title="Playing ...")
 def VVEdY6(self, VVYo8S, url, chName):
  chUrl = self.VV9DSc(VVYo8S.VVjpse(), url, chName)
  FFTztI(self, chUrl, VVLjiH=False)
  CCSeoi.VVLNOL(self.session, iptvTableParams=(self, VVYo8S, "m3u/m3u8"))
 def VV663c(self, VVYo8S, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV9DSc(VVYo8S.VVjpse(), url, chName)
  return chName, chUrl
 def VVcFnK(self, VVYo8S, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFwYti(self, fncMode=CCWhEO.VVPa5X, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVHPyC(self, err, title):
  FFRGBb(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV1r8Z(self, VVYo8S):
  if self.m3uOrM3u8File:
   self.close()
  VVYo8S.cancel()
 def VV5uDB(self, VVLmuPObj, item=None):
  FF0rXP(VVLmuPObj, BF(self.VVE0hw, VVLmuPObj, item))
 def VVE0hw(self, VVLmuPObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVLmuPObj.VVv6X1):
    path = item[1]
    if fileExists(path):
     enc = CCzVQo.VVYxDX(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCCGrE.VVoq2G(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCCGrE.VVlI30()
    pListF = "%sPlaylist_%s.txt" % (path, FFWWBu())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVLmuPObj.VVv6X1)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFipfq(self, txt, title=title)
   else:
    FFRGBb(self, "Could not obtain URLs from this file list !", title=title)
 def VViBNr(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVwhRY
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVdZGW
  lines = self.VVFYLC(mode)
  if lines:
   lines.sort()
   VVv6X1 = []
   for line in lines:
    VVv6X1.append((FFf1xo(line, VVKiZJ) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VVuA4J
   FFLwVh(self, None, title=title, VVv6X1=VVv6X1, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VVuA4J(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FFDH0v(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCOjzn.VV7GBO(sz)
  FFipfq(self, txt, title="File Path")
 def VVwhRY(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF0rXP(menuInstance, BF(self.VVi1u9, menuInstance, path), title="Processing File ...")
 def VVi1u9(self, VVKn1x, path):
  enc = CCzVQo.VVYxDX(path, self)
  if enc == -1:
   return
  VV4Gbf = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFiSR4(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCGrE.VVx0Im(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV4Gbf:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VV4Gbf.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV4Gbf:
   title = "Playlist File : %s" % os.path.basename(path)
   VVXwx9  = ("Start"    , BF(self.VVRMaB, "Playlist File")      , [])
   VVtXvO = ("Home Menu"   , FF1fb7             , [])
   VV6vKb = ("Download M3U File" , self.VVdN9q         , [])
   VVPogp = ("Edit File"   , BF(self.VV80VS, path)        , [])
   VVxkVZ = ("Check & Filter"  , BF(self.VV854R, VVKn1x, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVK4mA  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVtXvO=VVtXvO, VVxkVZ=VVxkVZ, VV6vKb=VV6vKb, VVPogp=VVPogp, VVyRL8="#11001116", VVmr0Y="#11001116", VVOSNp="#11001116", VVuQjw="#00003635", VVVwZb="#0a333333", VVU8z2="#11331100", VVWKtq=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFRGBb(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVdN9q(self, VVYo8S, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFWkqs(self, BF(FF0rXP, VVYo8S, BF(self.VVyE76, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVyE76(self, title, url):
  path, err = FFn4Tu(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFRGBb(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFUKzq(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFsF1P(path)
    FFRGBb(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFsF1P(path)
    FFRGBb(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCCGrE.VVlI30() + fName
    os.system(FFWqNF("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFrNpu(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFRGBb(self, "Could not download the M3U file!", title=errTitle)
 def VVRMaB(self, Title, VVYo8S, title, txt, colList):
  url = colList[6]
  FF0rXP(VVYo8S, BF(self.VVMrNs, Title, url), title="Checking Server ...")
 def VV80VS(self, path, VVYo8S, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCyIuf(self, path, VVkuAk=BF(self.VVEbu0, VVYo8S), curRowNum=rowNum)
  else    : FFZBzs(self, path)
 def VVEbu0(self, VVYo8S, fileChanged):
  if fileChanged:
   VVYo8S.cancel()
 def VVeiNf(self, title):
  curChName = self.VVYo8S.VVN3DQ(1)
  FFufG1(self, BF(self.VVUfcd, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVUfcd(self, title, name):
  if name:
   VVMUsL, err = CCnEIM.VVxj6i(self, CCnEIM.VVkkKN, VV1P1O=False, VV1pA1=False)
   list = []
   if VVMUsL:
    VV30jT = CCcIbP()
    name = VV30jT.VVnw5I(name)
    ratio = "1"
    for item in VVMUsL:
     if name in item[0].lower():
      list.append((item[0], FFvyCa(item[2]), item[3], ratio))
   if list : self.VVZOmL(list, title)
   else : FFRGBb(self, "Not found:\n\n%s" % name, title=title)
 def VV2ibx(self, title):
  curChName = self.VVYo8S.VVN3DQ(1)
  self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVrz3R
      , VVkuAk = BF(self.VVI4zp, title, curChName))
 def VVrz3R(self, VVtdJ0):
  curChName = self.VVYo8S.VVN3DQ(1)
  VVMUsL, err = CCnEIM.VVxj6i(self, CCnEIM.VVKXFu, VV1P1O=False, VV1pA1=False)
  if not VVMUsL or not VVtdJ0 or VVtdJ0.isCancelled:
   return
  VVtdJ0.VVwHZ6 = []
  VVtdJ0.VVhRNu(len(VVMUsL))
  VV30jT = CCcIbP()
  curCh = VV30jT.VVnw5I(curChName)
  for refCode in VVMUsL:
   chName, sat, inDB = VVMUsL.get(refCode, ("", "", 0))
   ratio = CCxA8L.VVX7Et(chName.lower(), curCh)
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1, True)
   if VVtdJ0 and ratio > 50:
    VVtdJ0.VVwHZ6.append((chName, FFvyCa(sat), refCode.replace("_", ":"), str(ratio)))
 def VVI4zp(self, title, curChName, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVwHZ6: self.VVZOmL(VVwHZ6, title)
  elif VVzWxR: FFRGBb(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVZOmL(self, VV4Gbf, title):
  curChName = self.VVYo8S.VVN3DQ(1)
  VVLcVM = self.VVYo8S.VVN3DQ(4)
  curUrl  = self.VVYo8S.VVN3DQ(5)
  VV4Gbf.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVXwx9  = ("Share Sat/C/T Ref.", BF(self.VVHi4r, title, curChName, VVLcVM, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVyRL8="#0a00112B", VVmr0Y="#0a001126", VVOSNp="#0a001126", VVuQjw="#00000000")
 def VVHi4r(self, newtitle, curChName, VVLcVM, curUrl, VVYo8S, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVLcVM, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFWkqs(self.VVYo8S, BF(FF0rXP, self.VVYo8S, BF(self.VVdb3I, VVYo8S, data)), ques, title=newtitle, VVaQmw=True)
 def VVdb3I(self, VVYo8S, data):
  VVYo8S.cancel()
  title, curChName, VVLcVM, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVLcVM = VVLcVM.strip()
  newRefCode = newRefCode.strip()
  if not VVLcVM.endswith(":") : VVLcVM += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVLcVM, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVLcVM + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVVL8t():
    txt = FFUKzq(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFVJ21()
    newRow = []
    for i in range(6):
     newRow.append(self.VVYo8S.VVN3DQ(i))
    newRow[4] = newRefCode
    done = self.VVYo8S.VVfm3U(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFFO8C(BF(FFrNpu , self, resTxt, title=title))
  elif resErr: FFFO8C(BF(FFRGBb, self, resErr, title=title))
 def VV854R(self, VVKn1x, path, VVYo8S, title, txt, colList):
  self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVasRO, VVYo8S)
      , VVkuAk = BF(self.VV3xC6, VVKn1x, path, VVYo8S))
 def VVasRO(self, VVYo8S, VVtdJ0):
  VVtdJ0.VVhRNu(VVYo8S.VVzMwz())
  VVtdJ0.VVwHZ6 = []
  for row in VVYo8S.VVl6T3():
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1, True)
   qUrl = self.VVcuNW(self.VVAzBQ, row[6])
   txt, err = self.VVcPPT(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVMcOx(item, "auth") == "0":
       VVtdJ0.VVwHZ6.append(qUrl)
    except:
     pass
 def VV3xC6(self, VVKn1x, path, VVYo8S, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVzWxR:
   list = VVwHZ6
   title = "Authorized Servers"
   if list:
    totChk = VVYo8S.VVzMwz()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFWWBu()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VViBNr(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFf1xo(str(totAuth), VVvsR7)
     txt += "%s\n\n%s"    %  (FFf1xo("Result File:", VVKiZJ), newPath)
     FFipfq(self, txt, title=title)
     VVYo8S.close()
     VVKn1x.close()
    else:
     FFrNpu(self, "All URLs are authorized.", title=title)
   else:
    FFRGBb(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVcPPT(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVx0Im(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVs0VG(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCh76K.VVH988()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVNn5z(decodedUrl):
  return CCCGrE.VVs0VG(decodedUrl, justRetDotExt=True)
 def VVcuNW(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVx0Im(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVAzBQ   : return "%s"            % url
  elif mode == self.VV1zOs   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVRcC9   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVUXD1  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVO2Y0  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVQ4D1 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVUAey   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVwImz    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVSAqH  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVUvCm : return "%s&action=get_live_streams"      % url
  elif mode == self.VVopCR  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVMcOx(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFQFpj(int(val))
    elif is_base64 : val = FF3JrN(val)
    elif isToHHMMSS : val = FFD88e(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV0VfE(self, title, path):
  if fileExists(path):
   enc = CCzVQo.VVYxDX(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCCGrE.VVoq2G(line)
     if qUrl:
      break
   if qUrl : self.VVMrNs(title, qUrl)
   else : FFRGBb(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFRGBb(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVysUn(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCCGrE.VVp7NB(self)
  if qUrl or "chCode" in iptvRef:
   p = CCWc1W()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV7dnN(iptvRef)
   if valid:
    self.VVFuVC(self, host, mac)
    return
   elif qUrl:
    FF0rXP(self, BF(self.VVMrNs, title, qUrl), title="Checking Server ...")
    return
  FFRGBb(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVp7NB(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF)
  qUrl = CCCGrE.VVoq2G(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVoq2G(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVMrNs(self, title, url):
  self.curUrl = url
  self.VV0M80Data = {}
  qUrl = self.VVcuNW(self.VVAzBQ, url)
  txt, err = self.VVcPPT(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV0M80Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV0M80Data["username"    ] = self.VVMcOx(item, "username"        )
    self.VV0M80Data["password"    ] = self.VVMcOx(item, "password"        )
    self.VV0M80Data["message"    ] = self.VVMcOx(item, "message"        )
    self.VV0M80Data["auth"     ] = self.VVMcOx(item, "auth"         )
    self.VV0M80Data["status"    ] = self.VVMcOx(item, "status"        )
    self.VV0M80Data["exp_date"    ] = self.VVMcOx(item, "exp_date"    , isDate=True )
    self.VV0M80Data["is_trial"    ] = self.VVMcOx(item, "is_trial"        )
    self.VV0M80Data["active_cons"   ] = self.VVMcOx(item, "active_cons"       )
    self.VV0M80Data["created_at"   ] = self.VVMcOx(item, "created_at"   , isDate=True )
    self.VV0M80Data["max_connections"  ] = self.VVMcOx(item, "max_connections"      )
    self.VV0M80Data["allowed_output_formats"] = self.VVMcOx(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV0M80Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV0M80Data["url"    ] = self.VVMcOx(item, "url"        )
    self.VV0M80Data["port"    ] = self.VVMcOx(item, "port"        )
    self.VV0M80Data["https_port"  ] = self.VVMcOx(item, "https_port"      )
    self.VV0M80Data["server_protocol" ] = self.VVMcOx(item, "server_protocol"     )
    self.VV0M80Data["rtmp_port"   ] = self.VVMcOx(item, "rtmp_port"       )
    self.VV0M80Data["timezone"   ] = self.VVMcOx(item, "timezone"       )
    self.VV0M80Data["timestamp_now"  ] = self.VVMcOx(item, "timestamp_now"  , isDate=True )
    self.VV0M80Data["time_now"   ] = self.VVMcOx(item, "time_now"       )
    VVv6X1  = self.VVcw0z(True)
    OKBtnFnc = self.VVdUlv
    infoBtnFnc = self.VVr0of
    VVrX4i = ("Home Menu", FF1fb7)
    VVqSIC= ("Add to Menu", BF(CCCGrE.VVtjkZ, self, False, self.VV0M80Data["playListURL"]))
    VVxtuz = ("Bookmark Server", BF(CCCGrE.VVoOI2, self, False, self.VV0M80Data["playListURL"]))
    FFLwVh(self, None, title="IPTV Server Resources", VVv6X1=VVv6X1, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVrX4i=VVrX4i, VVqSIC=VVqSIC, VVxtuz=VVxtuz)
   else:
    err = "Could not get data from server !"
  if err:
   FFRGBb(self, err, title=title)
  FFfad8(self)
 def VVdUlv(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF0rXP(menuInstance, BF(self.VVXV97, self.VV1zOs  , title=title), title=wTxt)
   elif ref == "vod"   : FF0rXP(menuInstance, BF(self.VVXV97, self.VVRcC9  , title=title), title=wTxt)
   elif ref == "series"  : FF0rXP(menuInstance, BF(self.VVXV97, self.VVUXD1 , title=title), title=wTxt)
   elif ref == "catchup"  : FF0rXP(menuInstance, BF(self.VVXV97, self.VVO2Y0 , title=title), title=wTxt)
   elif ref == "accountInfo" : FF0rXP(menuInstance, BF(self.VVXpDc           , title=title), title=wTxt)
 def VVr0of(self, menuInstance, txt, ref, ndx):
  FFipfq(self, self.curUrl + ("\n\n%s ... %s" % ({2:"Big", 3:"Sml"}.get(self.VV6cY5, ""), self.VVLeWo) if VVgkK0 else ""), title="Current Server URL")
 def VVXpDc(self, title):
  rows = []
  for key, val in self.VV0M80Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVrwdk
   else:
    num, part = "1", self.VVbX5d
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVtXvO  = ("Home Menu", FF1fb7, [])
  VV6vKb  = None
  if VVgkK0:
   VV6vKb = ("Get JS" , BF(self.VV54VB, "/".join(self.VV0M80Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFl3hs(self, None, title=title, width=1200, header=header, VVouKi=rows, VVw7oP=widths, VVcK4p=26, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000", searchCol=2)
 def VV685L(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VV30jT = CCcIbP()
    if mode in (self.VVUAey, self.VVopCR):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVMcOx(item, "num"         )
      name     = self.VVMcOx(item, "name"        )
      stream_id    = self.VVMcOx(item, "stream_id"       )
      stream_icon    = self.VVMcOx(item, "stream_icon"       )
      epg_channel_id   = self.VVMcOx(item, "epg_channel_id"      )
      added     = self.VVMcOx(item, "added"    , isDate=True )
      is_adult    = self.VVMcOx(item, "is_adult"       )
      category_id    = self.VVMcOx(item, "category_id"       )
      tv_archive    = self.VVMcOx(item, "tv_archive"       )
      direct_source   = self.VVMcOx(item, "direct_source"      )
      tv_archive_duration  = self.VVMcOx(item, "tv_archive_duration"     )
      name = VV30jT.VVBVVp(name, is_adult)
      if name:
       if mode == self.VVUAey or mode == self.VVopCR and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVwImz:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVMcOx(item, "num"         )
      name    = self.VVMcOx(item, "name"        )
      stream_id   = self.VVMcOx(item, "stream_id"       )
      stream_icon   = self.VVMcOx(item, "stream_icon"       )
      added    = self.VVMcOx(item, "added"    , isDate=True )
      is_adult   = self.VVMcOx(item, "is_adult"       )
      category_id   = self.VVMcOx(item, "category_id"       )
      container_extension = self.VVMcOx(item, "container_extension"     ) or "mp4"
      name = VV30jT.VVBVVp(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVSAqH:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVMcOx(item, "num"        )
      name    = self.VVMcOx(item, "name"       )
      series_id   = self.VVMcOx(item, "series_id"      )
      cover    = self.VVMcOx(item, "cover"       )
      genre    = self.VVMcOx(item, "genre"       )
      episode_run_time = self.VVMcOx(item, "episode_run_time"    )
      category_id   = self.VVMcOx(item, "category_id"      )
      container_extension = self.VVMcOx(item, "container_extension"    ) or "mp4"
      name = VV30jT.VVBVVp(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVXV97(self, mode, title):
  cList, err = self.VV9v4e(mode)
  if cList and mode == self.VVO2Y0:
   cList = self.VVXnWY(cList)
  if err:
   FFRGBb(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR(mode)
   mName = self.VVB19C(mode)
   if   mode == self.VV1zOs  : fMode = self.VVUAey
   elif mode == self.VVRcC9  : fMode = self.VVwImz
   elif mode == self.VVUXD1 : fMode = self.VVSAqH
   elif mode == self.VVO2Y0 : fMode = self.VVopCR
   if mode == self.VVO2Y0:
    VVPogp = None
    VVxkVZ = None
   else:
    VVPogp = ("Find in %s" % mName , BF(self.VViaAN, fMode, True) , [])
    VVxkVZ = ("Find in Selected" , BF(self.VViaAN, fMode, False) , [])
   VVXwx9   = ("Show List"   , BF(self.VVLwBd, mode)  , [])
   VVtXvO  = ("Home Menu"   , FF1fb7         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFl3hs(self, None, title=title, width=1200, header=header, VVouKi=cList, VVw7oP=widths, VVcK4p=30, VVtXvO=VVtXvO, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVXwx9=VVXwx9, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VVuQjw=VVuQjw, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFRGBb(self, "No list from server !", title=title)
  FFfad8(self)
 def VV9v4e(self, mode):
  qUrl  = self.VVcuNW(mode, self.VV0M80Data["playListURL"])
  txt, err = self.VVcPPT(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VV30jT = CCcIbP()
    for item in tDict:
     category_id  = self.VVMcOx(item, "category_id"  )
     category_name = self.VVMcOx(item, "category_name" )
     parent_id  = self.VVMcOx(item, "parent_id"  )
     category_name = VV30jT.VVsWLT(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVXnWY(self, catList):
  mode  = self.VVopCR
  qUrl  = self.VVcuNW(mode, self.VV0M80Data["playListURL"])
  txt, err = self.VVcPPT(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV685L(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVLwBd(self, mode, VVYo8S, title, txt, colList):
  title = colList[1]
  FF0rXP(VVYo8S, BF(self.VVcmmZ, mode, VVYo8S, title, txt, colList), title="Downloading ...")
 def VVcmmZ(self, mode, VVYo8S, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVB19C(mode) + " : "+ bName
  if   mode == self.VV1zOs  : mode = self.VVUAey
  elif mode == self.VVRcC9  : mode = self.VVwImz
  elif mode == self.VVUXD1 : mode = self.VVSAqH
  elif mode == self.VVO2Y0 : mode = self.VVopCR
  qUrl  = self.VVcuNW(mode, self.VV0M80Data["playListURL"], catID)
  txt, err = self.VVcPPT(qUrl)
  list  = []
  if not err and mode in (self.VVUAey, self.VVwImz, self.VVSAqH, self.VVopCR):
   list, err = self.VV685L(mode, txt)
  if err:
   FFRGBb(self, err, title=title)
  elif list:
   VVtXvO  = ("Home Menu"   , FF1fb7            , [])
   if mode in (self.VVUAey, self.VVopCR):
    VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR(mode)
    VVTMvN = (""     , BF(self.VVeuEf, mode)      , [])
    VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, "", "")   , [])
    VVPogp = ("Options"   , BF(self.VVGfJO, "lv", mode, bName)   , [])
    VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, False)     , [])
    if mode == self.VVUAey:
     VVXwx9 = ("Play"    , BF(self.VVEfaI, mode)       , [])
    else:
     VVXwx9 = ("Programs"   , BF(self.VVRSPK, mode, bName) , [])
   elif mode == self.VVwImz:
    VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR(mode)
    VVXwx9  = ("Play"    , BF(self.VVEfaI, mode)       , [])
    VVTMvN = (""     , BF(self.VVeuEf, mode)      , [])
    VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, "v", "")   , [])
    VVPogp = ("Options"   , BF(self.VVGfJO, "v", mode, bName)   , [])
    VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, False)     , [])
   elif mode == self.VVSAqH:
    VVyRL8, VVmr0Y, VVOSNp, VVuQjw = self.VVjBVR("series2")
    VVXwx9  = ("Show Seasons"  , BF(self.VVBixi, mode)       , [])
    VVTMvN = (""     , BF(self.VVKQX0, mode)     , [])
    VV6vKb = None
    VVPogp = None
    VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, True)      , [])
   header, widths, VVK4mA = self.VVL7UD(mode)
   FFl3hs(self, None, title=title, header=header, VVouKi=list, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindIptv, VVTMvN=VVTMvN, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VVuQjw=VVuQjw, VVWKtq=True, searchCol=1)
  else:
   FFRGBb(self, "No Channels found !", title=title)
  FFfad8(self)
 def VVL7UD(self, mode):
  if mode in (self.VVUAey, self.VVopCR):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVK4mA  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVwImz:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVK4mA  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVSAqH:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVK4mA  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVK4mA
 def VVRSPK(self, mode, bName, VVYo8S, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV0M80Data["playListURL"]
  ok_fnc  = BF(self.VVq9Po, hostUrl, chName, catId, streamId)
  FF0rXP(VVYo8S, BF(CCCGrE.VVjkog, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVq9Po(self, chUrl, chName, catId, streamId, VVYo8S, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCGrE.VVx0Im(chUrl)
   chNum = "333"
   refCode = CCCGrE.VVhgAF(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFTztI(self, chUrl, VVLjiH=False)
   CCSeoi.VVLNOL(self.session)
  else:
   FFRGBb(self, "Incorrect Timestamp", pTitle)
 def VVBixi(self, mode, VVYo8S, title, txt, colList):
  title = colList[1]
  FF0rXP(VVYo8S, BF(self.VVYK2g, mode, VVYo8S, title, txt, colList), title="Downloading ...")
 def VVYK2g(self, mode, VVYo8S, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVcuNW(self.VVQ4D1, self.VV0M80Data["playListURL"], series_id)
  txt, err = self.VVcPPT(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVMcOx(tDict["info"], "name"   )
      category_id = self.VVMcOx(tDict["info"], "category_id" )
      icon  = self.VVMcOx(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VV30jT = CCcIbP()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVMcOx(EP, "id"     )
        episode_num   = self.VVMcOx(EP, "episode_num"   )
        epTitle    = self.VVMcOx(EP, "title"     )
        container_extension = self.VVMcOx(EP, "container_extension" )
        seasonNum   = self.VVMcOx(EP, "season"    )
        epTitle = VV30jT.VVBVVp(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFRGBb(self, err, title=title)
  elif list:
   VVtXvO = ("Home Menu"   , FF1fb7          , [])
   VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, "s", title), [])
   VVPogp = ("Options"   , BF(self.VVGfJO, "s", mode, title) , [])
   VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, False)   , [])
   VVTMvN = (""     , BF(self.VVeuEf, mode)    , [])
   VVXwx9  = ("Play"    , BF(self.VVEfaI, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVK4mA  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFl3hs(self, None, title=title, header=header, VVouKi=list, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindIptv, VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000")
  else:
   FFRGBb(self, "No Channels found !", title=title)
  FFfad8(self)
 def VViaAN(self, mode, isAll, VVYo8S, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVv6X1 = []
  VVv6X1.append(("Keyboard"  , "manualEntry"))
  VVv6X1.append(("From Filter" , "fromFilter"))
  FFLwVh(self, BF(self.VVB4EZ, VVYo8S, mode, onlyCatID), title="Input Type", VVv6X1=VVv6X1, width=400)
 def VVB4EZ(self, VVYo8S, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFufG1(self, BF(self.VV5daf, VVYo8S, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCFC3v(self)
    filterObj.VVgJ0W(BF(self.VV5daf, VVYo8S, mode, onlyCatID))
 def VV5daf(self, VVYo8S, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFcghP(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCFC3v.VVXFHp(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFRGBb(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFRGBb(self, "All words must be at least 3 characters !", title=title)
        return
     VV30jT = CCcIbP()
     if CFG.hideIptvServerAdultWords.getValue() and VV30jT.VVkXPN(words):
      FFRGBb(self, VV30jT.VVwn3a(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVJhop, VVYo8S, mode, onlyCatID, title, words, toFind, asPrefix, VV30jT)
          , VVkuAk = BF(self.VVYokn, mode, toFind, title))
   if not words:
    FFfad8(VVYo8S, "Nothing to find !", 1500)
 def VVJhop(self, VVYo8S, mode, onlyCatID, title, words, toFind, asPrefix, VV30jT, VVtdJ0):
  VVtdJ0.VVhRNu(VVYo8S.VVDPuF() if onlyCatID is None else 1)
  VVtdJ0.VVwHZ6 = []
  for row in VVYo8S.VVl6T3():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVcdeL(1)
   VVtdJ0.VV4a50(catName)
   qUrl  = self.VVcuNW(mode, self.VV0M80Data["playListURL"], catID)
   txt, err = self.VVcPPT(qUrl)
   if not err:
    tList, err = self.VV685L(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VV30jT.VVBVVp(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVtdJ0.VVwHZ6.append(item)
 def VVYokn(self, mode, toFind, title, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVwHZ6:
   title = self.VVgPq9(mode, toFind)
   if mode == self.VVUAey or mode == self.VVwImz:
    if mode == self.VVwImz : typ = "v"
    else          : typ = ""
    bName   = CCCGrE.VVyead(toFind)
    VVXwx9  = ("Play"     , BF(self.VVEfaI, mode)     , [])
    VV6vKb = ("Download Options" , BF(self.VV4Hak, mode, typ, "") , [])
    VVPogp = ("Options"   , BF(self.VVGfJO, "fnd", mode, bName), [])
    VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, False)   , [])
    VVTMvN = (""     , BF(self.VVeuEf, mode)    , [])
   elif mode == self.VVSAqH:
    VVXwx9  = ("Show Seasons"  , BF(self.VVBixi, mode)     , [])
    VVPogp = None
    VV6vKb = None
    VVxkVZ = ("Posters Mode"  , BF(self.VVRyCp, mode, True)    , [])
    VVTMvN = (""     , BF(self.VVKQX0, mode)   , [])
   VVtXvO  = ("Home Menu"   , FF1fb7          , [])
   header, widths, VVK4mA = self.VVL7UD(mode)
   VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VVwHZ6, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVTMvN=VVTMvN, VVyRL8="#0a00292B", VVmr0Y="#0a002126", VVOSNp="#0a002126", VVuQjw="#00000000", VVWKtq=True, searchCol=1)
   if not VVzWxR:
    FFfad8(VVYo8S, "Stopped" , 1000)
  else:
   if VVzWxR:
    FFRGBb(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVggEa(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVUAey, self.VVopCR):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVwImz:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFtomh(chName)
  url = self.VV0M80Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVx0Im(url)
  refCode = self.VVhgAF(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVeuEf(self, mode, VVYo8S, title, txt, colList):
  FF0rXP(VVYo8S, BF(self.VVCQK3, mode, VVYo8S, title, txt, colList))
 def VVCQK3(self, mode, VVYo8S, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVggEa(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFwYti(self, fncMode=CCWhEO.VVdGzF, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVKQX0(self, mode, VVYo8S, title, txt, colList):
  FF0rXP(VVYo8S, BF(self.VV1NV8, mode, VVYo8S, title, txt, colList))
 def VV1NV8(self, mode, VVYo8S, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFwYti(self, fncMode=CCWhEO.VVirj9, chName=name, text=txt, picUrl=Cover)
 def VVRyCp(self, mode, isSerNames, VVYo8S, title, txt, colList):
  if   mode in ("itv"  , CCCGrE.VVUAey, CCCGrE.VVopCR): category = "live"
  elif mode in ("vod"  , CCCGrE.VVwImz )          : category = "vod"
  elif mode in ("series" , CCCGrE.VVSAqH)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVUAey : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVopCR : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVwImz  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVSAqH : picCol, descCol, descTxt = 5, 0, "Season"
  FF0rXP(VVYo8S, BF(self.session.open, CCDJ1X, VVYo8S, category, nameCol, picCol, descCol, descTxt))
 def VV4Hak(self, mode, typ, seriesName, VVYo8S, title, txt, colList):
  VVv6X1 = []
  isMulti = VVYo8S.VVRSSP
  tot  = VVYo8S.VVTK0J()
  if isMulti:
   if tot < 1:
    FFfad8(VVYo8S, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVv6X1.append(("Download %s PIcon%s" % (name, FF2vwS(tot)), "dnldPicons" ))
  if typ:
   VVv6X1.append(VVdKVg)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVv6X1.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVv6X1.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVv6X1.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCNUxQ.VVFz7u():
    VVv6X1.append(VVdKVg)
    VVv6X1.append(("Download Manager"      , "dload_stat" ))
  FFLwVh(self, BF(self.VV8FCg, VVYo8S, mode, typ, seriesName, colList), title="Download Options", VVv6X1=VVv6X1)
 def VV8FCg(self, VVYo8S, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVF2Rs(VVYo8S, mode)
   elif item == "dnldSel"  : self.VVnsSP(VVYo8S, mode, typ, colList, True)
   elif item == "addSel"  : self.VVnsSP(VVYo8S, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV2Mg4(VVYo8S, mode, typ, seriesName)
   elif item == "dload_stat" : CCNUxQ.VV4XQs(self)
 def VVnsSP(self, VVYo8S, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVQqAe(mode, typ, colList)
  if startDnld:
   CCNUxQ.VV9jjO(self, decodedUrl)
  else:
   self.VVJj3I(VVYo8S, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV2Mg4(self, VVYo8S, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVYo8S.VVl6T3():
   chName, decodedUrl = self.VVQqAe(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVJj3I(VVYo8S, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVJj3I(self, VVYo8S, title, chName, decodedUrl_list, startDnld):
  FFWkqs(self, BF(self.VVpSp0, VVYo8S, decodedUrl_list, startDnld), chName, title=title)
 def VVpSp0(self, VVYo8S, decodedUrl_list, startDnld):
  added, skipped = CCNUxQ.VV2whx(decodedUrl_list)
  FFfad8(VVYo8S, "Added", 1000)
 def VVQqAe(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVggEa(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, colList)
   refCode, chUrl = self.VVEjtU(self.VVXXml, self.VVg2mm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFQOHf(chUrl)
  return chName, decodedUrl
 def VVF2Rs(self, VVYo8S, mode):
  if os.system(FFWqNF("which ffmpeg")) == 0:
   self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVq6An, VVYo8S, mode)
       , VVkuAk = self.VVC9Md)
  else:
   FFWkqs(self, BF(CCCGrE.VV2FlJ, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVC9Md(self, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVwHZ6["proces"], VVwHZ6["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVwHZ6["ok"], VVwHZ6["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVwHZ6["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVwHZ6["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVwHZ6["badURL"]
  txt += "Download Failure\t: %d\n"   % VVwHZ6["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVwHZ6["path"]
  if not VVzWxR  : color = "#11402000"
  elif VVwHZ6["err"]: color = "#11201000"
  else     : color = None
  if VVwHZ6["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVwHZ6["err"], txt)
  title = "PIcons Download Result"
  if not VVzWxR:
   title += "  (cancelled)"
  FFipfq(self, txt, title=title, VVOSNp=color)
 def VVq6An(self, VVYo8S, mode, VVtdJ0):
  isMulti = VVYo8S.VVRSSP
  if isMulti : totRows = VVYo8S.VVTK0J()
  else  : totRows = VVYo8S.VVDPuF()
  VVtdJ0.VVhRNu(totRows)
  VVtdJ0.VVXoWi(0)
  counter     = VVtdJ0.counter
  maxValue    = VVtdJ0.maxValue
  pPath     = CCxA8L.VV76e0()
  VVtdJ0.VVwHZ6 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVYo8S.VVl6T3()):
    if VVtdJ0.isCancelled:
     break
    if not isMulti or VVYo8S.VV3b3Q(rowNum):
     VVtdJ0.VVwHZ6["proces"] += 1
     VVtdJ0.VVcdeL(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, row)
      refCode = CCCGrE.VVhgAF(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVWYWs(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVggEa(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVtdJ0.VVwHZ6["attempt"] += 1
       path, err = FFn4Tu(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVtdJ0:
         VVtdJ0.VVwHZ6["ok"] += 1
         VVtdJ0.VVXoWi(VVtdJ0.VVwHZ6["ok"])
        if FFDH0v(path) > 0:
         cmd = CCWhEO.VVZvOp(path)
         cmd += FFWqNF("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVtdJ0:
          VVtdJ0.VVwHZ6["size0"] += 1
         FFsF1P(path)
       elif err:
        if VVtdJ0:
         VVtdJ0.VVwHZ6["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVtdJ0:
          VVtdJ0.VVwHZ6["err"] = err.title()
         break
      else:
       if VVtdJ0:
        VVtdJ0.VVwHZ6["exist"] += 1
     else:
      if VVtdJ0:
       VVtdJ0.VVwHZ6["badURL"] += 1
  except:
   pass
 def VVMUup(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFWqNF("which ffmpeg")) == 0:
   self.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
       , titlePrefix = ""
       , fncToRun  = self.VV7brH
       , VVkuAk = BF(self.VVjPGr, title))
  else:
   FFWkqs(self, BF(CCCGrE.VV2FlJ, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VV7brH(self, VVtdJ0):
  bName = CCQii3.VVVZ1I()
  pPath = CCxA8L.VV76e0()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVtdJ0.VVwHZ6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCQii3.VVEToZ()
  if not VVtdJ0 or VVtdJ0.isCancelled:
   return
  if not services or len(services) == 0:
   VVtdJ0.VVwHZ6 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVtdJ0.VVhRNu(totCh)
  VVtdJ0.VVXoWi(0)
  for serv in services:
   if not VVtdJ0 or VVtdJ0.isCancelled:
    return
   VVtdJ0.VVwHZ6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVtdJ0.VVcdeL(1)
   VVtdJ0.VVXoWi(totPic)
   fullRef  = serv[0]
   if FFW8kf(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFQOHf(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCWc1W.VV3rxx(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCGrE.VVcPPT(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCWhEO.VV1sNL(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFn4Tu(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVtdJ0:
     VVtdJ0.VVXoWi(totPic)
    if FFDH0v(path) > 0:
     cmd = CCWhEO.VVZvOp(path)
     cmd += FFWqNF("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFsF1P(path)
  if VVtdJ0:
   VVtdJ0.VVwHZ6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVjPGr(self, title, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVwHZ6
  if err:
   FFRGBb(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFf1xo(str(totExist)  , VVqskC)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFf1xo(str(totNotIptv)  , VVqskC)
    if totServErr : txt += "Server Errors\t: %s\n" % FFf1xo(str(totServErr) + t1, VVqskC)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFf1xo(str(totParseErr) , VVqskC)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFf1xo(str(totInvServ)  , VVqskC)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFf1xo(str(totInvPicUrl) , VVqskC)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFf1xo(str(totSize0)  , VVqskC)
   if not VVzWxR:
    title += "  (stopped)"
   FFipfq(self, txt, title=title)
 @staticmethod
 def VV2FlJ(SELF):
  cmd = FFohUm(VViQjU, "ffmpeg")
  if cmd : FF8ZtC(SELF, cmd, title="Installing FFmpeg")
  else : FF2yhz(SELF)
 @staticmethod
 def VV3khE(SELF):
  SELF.session.open(CCF2c1, barTheme=CCF2c1.VVVDkX
      , titlePrefix = ""
      , fncToRun  = CCCGrE.VVoWMJ
      , VVkuAk = BF(CCCGrE.VVkN2E, SELF))
 @staticmethod
 def VVoWMJ(VVtdJ0):
  bName = CCQii3.VVVZ1I()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVtdJ0.VVwHZ6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCQii3.VVEToZ()
  if not VVtdJ0 or VVtdJ0.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVtdJ0.VVhRNu(totCh)
   for serv in services:
    if not VVtdJ0 or VVtdJ0.isCancelled:
     return
    VVtdJ0.VVcdeL(1)
    fullRef = serv[0]
    if FFW8kf(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFQOHf(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCWc1W.VV3rxx(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(m3u_Url)
     if VVtdJ0:
      VVtdJ0.VVt6fp(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCCGrE.VVJgZm(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CC8oCo.VVflYv(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVtdJ0:
     VVtdJ0.VVwHZ6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVtdJ0.VVwHZ6 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVkN2E(SELF, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVwHZ6
  title = "IPTV EPG Import"
  if err:
   FFRGBb(SELF, err, title=title)
  else:
   if VVzWxR and totEpgOK > 0:
    CC8oCo.VV7k3H()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFf1xo(str(totNotIptv), VVqskC)
    if totServErr : txt += "Server Errors\t: %s\n" % FFf1xo(str(totServErr) + t1, VVqskC)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFf1xo(str(totInv), VVqskC)
   if not VVzWxR:
    title += "  (stopped)"
   FFipfq(SELF, txt, title=title)
 @staticmethod
 def VVJgZm(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCGrE.VVx0Im(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCCGrE.VVcPPT(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCCGrE.VVMcOx(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCCGrE.VVMcOx(item, "lang"        ).upper()
    now_playing   = CCCGrE.VVMcOx(item, "now_playing"      )
    start    = CCCGrE.VVMcOx(item, "start"        )
    start_timestamp  = CCCGrE.VVMcOx(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCCGrE.VVMcOx(item, "start_timestamp"     )
    stop_timestamp  = CCCGrE.VVMcOx(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCCGrE.VVMcOx(item, "stop_timestamp"      )
    tTitle    = CCCGrE.VVMcOx(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVhgAF(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCCGrE.VViHas(catID, MAX_4b)
  TSID = CCCGrE.VViHas(chNum, MAX_4b)
  ONID = CCCGrE.VViHas(chNum, MAX_4b)
  NS  = CCCGrE.VViHas(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VViHas(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVyead(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVjBVR(mode):
  if   mode in ("itv"  , CCCGrE.VV1zOs)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCCGrE.VVRcC9)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCCGrE.VVUXD1) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCCGrE.VVO2Y0) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCCGrE.VVopCR    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVFYLC(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVAg8j:
   excl = FFpy4F(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFRGBb(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFqfZV('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFRGBb(self, err)
  elif len(files) == 1 and files[0] == VVngly:
   FFRGBb(self, VVngly)
  else:
   return files
 @staticmethod
 def VVlI30():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFiSR4(path)
  return "/"
 @staticmethod
 def VVjkog(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCCGrE.VVJgZm(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFRGBb(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVyRL8, VVmr0Y, VVOSNp, VVuQjw = CCCGrE.VVjBVR("")
   VVtXvO = ("Home Menu" , FF1fb7, [])
   VVXwx9  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVK4mA  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFl3hs(SELF, None, title="Programs for : " + chName, header=header, VVouKi=pList, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=24, VVXwx9=VVXwx9, VVtXvO=VVtXvO, VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VVuQjw=VVuQjw)
  else:
   FFRGBb(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVrJAJ(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVtjkZ(self, isPortal, line, VVLmuPObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFWkqs(self, BF(self.VV8ugR, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFcghP(confItem, line)
   FFrNpu(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV8ugR(self, title, confItem):
  FFcghP(confItem, "")
  FFrNpu(self, "Removed from IPTV Menu.", title=title)
 def VVQfhi(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVFuVC(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF0rXP(self, BF(self.VVMrNs, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFRGBb(self, "Incorrect server data !")
 @staticmethod
 def VVoOI2(SELF, isPortal, line, VVLmuPObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCCGrE.VVlI30()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFRGBb(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFrNpu(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFRGBb(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVGfJO(self, source, mode, curBName, VVYo8S, title, txt, colList):
  isMulti = VVYo8S.VVRSSP
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVYo8S.VVTK0J()
   totTxt = "%d Service%s" % (tot, FF2vwS(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFf1xo(totTxt, VVKiZJ)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CC3iyH(self, VVYo8S, addSep=False)
  thTxt = "Adding Services ..."
  VVv6X1, cbFncDict = [], None
  VVv6X1.append(VVdKVg)
  if itemsOK:
   VVv6X1.append(("Add %s to New Bouquet : %s"    % (totTxt, FFf1xo(curBName , VVvsR7)), "addToCur1"))
   if curBName2: VVv6X1.append(("Add %s to New Bouquet : %s" % (totTxt, FFf1xo(curBName2, VV0HRz)) , "addToCur2"))
   VVv6X1.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF0rXP, mSel.VVYo8S, BF(self.VVoRzY,source, mode, curBName , VVYo8S, title), title=thTxt)
      , "addToCur2": BF(FF0rXP, mSel.VVYo8S, BF(self.VVoRzY,source, mode, curBName2, VVYo8S, title), title=thTxt)
      , "addToNew" : BF(self.VVv1a4, source, mode, curBName, VVYo8S, title)
      }
  else:
   VVv6X1.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVzccf(VVv6X1, cbFncDict, width=1200)
 def VVoRzY(self, source, mode, curBName, VVYo8S, Title):
  chUrlLst = self.VVpx4e(source, mode, VVYo8S)
  CCQii3.VVGUOl(self, Title, curBName, "", chUrlLst)
 def VVv1a4(self, source, mode, curBName, VVYo8S, Title):
  picker = CCQii3(self, VVYo8S, Title, BF(self.VVpx4e, source, mode, VVYo8S), defBName=curBName)
 def VVpx4e(self, source, mode, VVYo8S):
  totChange = 0
  isMulti = VVYo8S.VVRSSP
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVYo8S.VVl6T3()):
   if not isMulti or VVYo8S.VV3b3Q(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV5Iil(mode, row)
     refCode, chUrl = self.VVEjtU(self.VVXXml, self.VVg2mm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VV9DSc(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVggEa(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCJyPt(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVkrwb(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FF2A0B(self.frm, frmColor)
  FF2A0B(self.bak, bakColor)
  FF2A0B(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVuhbb(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFF1Ee(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCwRkZ(CCJyPt):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCJyPt.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VVCsIb   ,
   "down" : self.VV3ZBv  ,
   "left" : self.VVJXQv  ,
   "right" : self.VV54hN  ,
   "next" : self.VVZjkk ,
   "last" : self.VVJZqu
  }, -1)
 def VVDrA1(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVkrwb(x, y, w, h)
  self.VV3yYZ()
 def VVULM3(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVCsIb(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVatGv()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVjtON()
 def VV3ZBv(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV228L()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVjtON()
 def VVJXQv(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVatGv()
  else:
   self.curCol -= 1
   self.VVjtON()
 def VV54hN(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV228L()
  else:
   self.curCol += 1
   self.VVjtON()
 def VVJZqu(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVjtON(True)
 def VVZjkk(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVjtON(True)
 def VV228L(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVjtON(True)
 def VVatGv(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVjtON(True)
 def VVjtON(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVC6hA = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVC6hA: self.curPage = VVC6hA
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VViLs8()
  self.VVuhbb(self.curPage + 1, self.totalPages)
  FFFO8C(BF(self.VVi55m, force or not oldPage == self.curPage, VVC6hA))
 def VVi55m(self, force, VVC6hA):
  if force:
   self.VVHKht()
  if self.curPage == VVC6hA:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VViLs8()
  boxT, boxW, boxH = self.skinParam["extraPar"]
  self["myPiconPtr"].instance.move(ePoint(int(boxW * self.curCol), int(boxT + boxH * self.curRow)))
  self["myPiconPtr"].show()
 def VVipMk(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVjtON(True)
  else:
   FFfad8(self, "Not found", 1000)
 def VV1vyD(self):
  self["myPiconPtr"].hide()
 def VVwoJu(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVV5lt(self):
  fg = bg = self.colorCfg.getValue()
  self.session.openWithCallback(self.VVCJ3S, CCEdpz, defFG=fg, defBG=bg, onlyBG=True)
 def VVCJ3S(self, fg, bg):
  if bg:
   FFcghP(self.colorCfg, bg)
   self.VV3yYZ()
 def VV3yYZ(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF2A0B(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
class CCDJ1X(Screen, CCwRkZ):
 def __init__(self, session, VVYo8S, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFUxcO(VV0WDO, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVYo8S  = VVYo8S
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVouKi    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFDBTO(self, self.Title)
  CCwRkZ.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVsoKC, subPath)
  if not pathExists(self.pPath):
   os.system(FFWqNF("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVsJp0   ,
   "cancel": self.close   ,
   "menu" : self.VVRJOf,
   "info" : self.VVTSj7
  })
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  FFjMgg(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVDrA1()
  self.VVbO7i()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVRJOf(self):
  chName, subj, desc, fName, picUrl = self.VVouKi[self.curIndex]
  VVv6X1 = []
  txt1 = "Show Poster/PIcon"
  txt2 = "Copy Poster/PIcon to Export-Directory"
  if fName:
   VVv6X1.append((txt1, "VVdbP0" ))
   VVv6X1.append((txt2, "VV1WSc"))
  else:
   VVv6X1.append((txt1, ))
   VVv6X1.append((txt2, ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Cache details"       , "VV3ld7"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Change Poster/Picon Transparency Color" , "VVV5lt" ))
  FFLwVh(self, self.VVZ7nb, title=self.Title, VVv6X1=VVv6X1)
 def VVZ7nb(self, item=None):
  if item is not None:
   if   item == "VV1WSc"   : self.VV1WSc()
   elif item == "VVdbP0"   : self.VVdbP0()
   elif item == "VV3ld7"  : FF0rXP(self, self.VV3ld7, title="Calculating ...")
   elif item == "VVV5lt" : self.VVV5lt()
 def VVsJp0(self):
  self.VVYo8S.VVG9tX(self.curIndex)
  self.VVYo8S.VVXEe0()
 def VVTSj7(self):
  self.VVYo8S.VVG9tX(self.curIndex)
  self.VVYo8S.VVgSL1()
 def VVbO7i(self):
  for colList in self.VVYo8S.VVl6T3():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVouKi.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVouKi)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVYo8S.VVjpse()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVjtON(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVs6cC)
  except:
   self.timer.callback.append(self.VVs6cC)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVLT0e)
  self.myThread.start()
 def VVLT0e(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVouKi):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFn4Tu(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFWqNF("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVouKi[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVs6cC(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVL1qM + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVouKi[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVouKi[ndx] = (chName, subj, desc, fName, "")
     try:
      CCakoM.VVhS4B(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVHKht(self):
  self.VVwoJu()
  f1, f2 = self.VVULM3()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVouKi[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVCsc2 + "iptv.png"
   try:
    CCakoM.VVhS4B(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VViLs8(self):
  chName, subj, desc, fName, picUrl = self.VVouKi[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVdbP0(self):
  chName, subj, desc, fName, picUrl = self.VVouKi[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCXjSu.VVTYNz(self, self.pPath + fName)
  else          : FFfad8(self, "File not found", 1500)
 def VV1WSc(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVouKi[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFWqNF("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FFrNpu(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFRGBb(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFRGBb(self, "No Poster/PIcon found", title=title)
 def VV3ld7(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVsoKC, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFTbYu("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCOjzn.VV7GBO(size)
   txt += "%s\n    %s\n\n" % (FFf1xo(path, VVKiZJ), size)
  mainPath = "%sPosters" % VVsoKC
  totFiles = FFTbYu("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FF2vwS(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFf1xo("Total space used by Posters/PIcons%s:" % totFTxt, VVy4op), CCOjzn.VV7GBO(totSize))
  mountPath = CCOjzn.VVcFRD(mainPath)
  if pathExists(mountPath):
   totSize  = CCOjzn.VV894G(mountPath)
   freeSize = CCOjzn.VVFSvh(mountPath)
   usedSize = CCOjzn.VV7GBO(totSize - freeSize)
   totSize  = CCOjzn.VV7GBO(totSize)
   freeSize = CCOjzn.VV7GBO(freeSize)
   txt += "%s\n" % VVT41S
   txt += FFf1xo("Media Space:\n", VVityU)
   txt += "    Media Path\t: %s\n" % FFf1xo(mountPath, VVq8cV)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFipfq(self, txt, title="Cache Used Size", height=1000)
class CCakoM(Screen, CCwRkZ):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFUxcO(VV0WDO, 1870, 1030, 50, 10, 10, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVouKi    = lst
  FFDBTO(self, self.Title)
  CCwRkZ.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVsJp0   ,
   "cancel": self.close   ,
   "menu" : self.VVaHQR,
   "info" : self.VVi8Fu
  })
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  FFjMgg(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVDrA1()
  self.totalItems = len(self.VVouKi)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVjtON(True)
 def VVHKht(self):
  self.VVwoJu()
  f1, f2 = self.VVULM3()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVouKi[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVCsc2 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(os.path.splitext(os.path.basename(path))[0])
   lbl.show()
   pic.show()
   try:
    self.VVhS4B(pic, poster)
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVvXWq(self):
  path, movie, poster = self.VVouKi[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VViLs8(self):
  path, poster = self.VVvXWq()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVaHQR(self):
  path, poster = self.VVvXWq()
  VVv6X1 = []
  VVv6X1.append(("Go to movie ..."     , "VVTXXk"))
  VVv6X1.append(VVdKVg)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVv6X1.append((txt1, "VVdbP0" ))
   VVv6X1.append((txt2, "VV1WSc"))
  else:
   VVv6X1.append((txt1, ))
   VVv6X1.append((txt2, ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Change Poster/Picon Transparency Color", "VVV5lt" ))
  FFLwVh(self, self.VVJWmW, title=self.Title, VVv6X1=VVv6X1)
 def VVJWmW(self, item=None):
  if item is not None:
   if   item == "VVTXXk"    : self.VVTXXk()
   elif item == "VV1WSc"    : self.VV1WSc()
   elif item == "VVdbP0"    : self.VVdbP0()
   elif item == "VVV5lt" : self.VVV5lt()
 def VVTXXk(self):
  VV4Gbf = []
  for ndx, item in enumerate(self.VVouKi):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VV4Gbf.append((os.path.splitext(movie)[0], path, str(ndx)))
  VV4Gbf.sort(key=lambda x: x[0].lower())
  VVXwx9 = ("Select" , self.VVmVYU, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFl3hs(self, None, title="Select Movie", width=1800, height=1000, header=header, VVouKi=VV4Gbf, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, lastFindConfigObj=CFG.lastFindMovie)
 def VVmVYU(self, VVYo8S, title, txt, colList):
  self.VVipMk(int(colList[2].strip()))
  VVYo8S.cancel()
 def VVsJp0(self):
  path, poster = self.VVvXWq()
  FF0rXP(self, BF(CCOjzn.VVaWiz, self, path), title="Playing Media ...")
 def VVi8Fu(self):
  path, poster = self.VVvXWq()
  txt = "%s:\n%s\n\n" % (FFf1xo("Path", VVKiZJ), path)
  size = FFDH0v(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFf1xo("File Size", VVKiZJ), CCOjzn.VV7GBO(size))
  if poster:
   txt += "%s:\n%s" % (FFf1xo("Poster", VVKiZJ), poster)
  FFipfq(self, txt, title="Movie Information")
 def VVdbP0(self):
  path, poster = self.VVvXWq()
  if fileExists(poster): CCXjSu.VVTYNz(self, poster)
  else     : FFfad8(self, "No Poster", 1500)
 def VV1WSc(self):
  title = "Copy Poster"
  path, poster = self.VVvXWq()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FFWqNF("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FFrNpu(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFRGBb(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFfad8(self, "No Poster", 1500)
 @staticmethod
 def VVhS4B(pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 @staticmethod
 def VV0mWC(SELF):
  eLst = CCh76K.VVH988()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCakoM, title, lst)
  else  : FFRGBb(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCuxcD(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFUxcO(VVonST, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVxgFa  = 0
  self.VVcTeq = 1
  self.VVqmNY  = 2
  VVv6X1 = []
  VVv6X1.append(("Find in All Service (from filter)" , "VVikoc" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Find in All (Manual Entry)"   , "VVC3mR"    ))
  VVv6X1.append(("Find in TV"       , "VVeALc"    ))
  VVv6X1.append(("Find in Radio"      , "VVoHuU"   ))
  if self.VVr1Cs():
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Hide Channel: %s" % self.servName , "VVXsLL"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Zap History"       , "VVH9LT"    ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("IPTV Tools"       , "iptv"      ))
  VVv6X1.append(("PIcons Tools"       , "PIconsTools"     ))
  VVv6X1.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVv6X1.append(("EPG Tools"       , "epgTools"     ))
  FFDBTO(self, VVv6X1=VVv6X1, title=title)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self)
  if self.isFindMode:
   self.VVypvR(self.VVfNrS())
 def VVsJp0(self):
  global VVpQe7
  VVpQe7 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVC3mR"    : self.VVC3mR()
   elif item == "VVikoc" : self.VVikoc()
   elif item == "VVeALc"    : self.VVeALc()
   elif item == "VVoHuU"   : self.VVoHuU()
   elif item == "VVXsLL"   : self.VVXsLL()
   elif item == "VVH9LT"    : self.VVH9LT()
   elif item == "iptv"       : self.session.open(CCCGrE)
   elif item == "PIconsTools"     : self.session.open(CCxA8L)
   elif item == "ChannelsTools"    : self.session.open(CCnEIM)
   elif item == "epgTools"      : self.session.open(CC8oCo)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVeALc(self) : self.VVypvR(self.VVxgFa)
 def VVoHuU(self) : self.VVypvR(self.VVcTeq)
 def VVC3mR(self) : self.VVypvR(self.VVqmNY)
 def VVypvR(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFufG1(self, BF(self.VVONOy, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVikoc(self):
  filterObj = CCFC3v(self)
  filterObj.VVgJ0W(self.VVNsvP)
 def VVNsvP(self, item):
  self.VVONOy(self.VVqmNY, item)
 def VVr1Cs(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFW8kf(self.refCode)        : return False
  return True
 def VVONOy(self, mode, VVrbwJ):
  FF0rXP(self, BF(self.VVItnn, mode, VVrbwJ), title="Searching ...")
 def VVItnn(self, mode, VVrbwJ):
  if VVrbwJ:
   VVrbwJ = VVrbwJ.strip()
  if VVrbwJ:
   self.findTxt = VVrbwJ
   CFG.lastFindContextFind.setValue(VVrbwJ)
   if   mode == self.VVxgFa  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVcTeq : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVrbwJ)
   if len(title) > 55:
    title = title[:55] + ".."
   VV4Gbf = self.VVVHmX(VVrbwJ, servTypes)
   if self.isFindMode or mode == self.VVqmNY:
    VV4Gbf += self.VVjzKu(VVrbwJ)
   if VV4Gbf:
    VV4Gbf.sort(key=lambda x: x[0].lower())
    VVgYq4 = self.VViLmY
    VVXwx9  = ("Zap"   , self.VVSAfG    , [])
    VV6vKb = ("Current Service", self.VVNJaW , [])
    VVPogp = ("Options"  , self.VVDezS , [])
    VVTMvN = (""    , self.VVea6X , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVK4mA  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVgYq4=VVgYq4, VV6vKb=VV6vKb, VVPogp=VVPogp, VVTMvN=VVTMvN, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVypvR(self.VVfNrS())
    FFrNpu(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVVHmX(self, VVrbwJ, servTypes):
  VVouKi = CCnEIM.VVXeSW(servTypes)
  VV4Gbf = []
  if VVouKi:
   VVZ2TC, VVWyfL = FF9RbH()
   tp = CCg4Ht()
   words, asPrefix = CCFC3v.VVXFHp(VVrbwJ)
   colorYellow  = CCZV4T.VVPzaV(VVy4op)
   colorWhite  = CCZV4T.VVPzaV(VVH2yZ)
   for s in VVouKi:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFlSfT(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVZ2TC:
        STYPE = VVWyfL[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVw2sY(refCode)
       if not "-S" in syst:
        sat = syst
       VV4Gbf.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV4Gbf
 def VVjzKu(self, VVrbwJ):
  VVrbwJ = VVrbwJ.lower()
  VV4Gbf = []
  colorYellow  = CCZV4T.VVPzaV(VVy4op)
  colorWhite  = CCZV4T.VVPzaV(VVH2yZ)
  for b in CCQii3.VVJfLd():
   VVwRnH  = b[0]
   VVY4GN  = b[1].toString()
   VVzrZo = eServiceReference(VVY4GN)
   VVN915 = FFWeXA(VVzrZo)
   for service in VVN915:
    refCode  = service[0]
    if FFW8kf(refCode):
     servName = service[1]
     if VVrbwJ in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVrbwJ), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VV4Gbf.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV4Gbf
 def VVfNrS(self):
  VVY2Pt = InfoBar.instance
  if VVY2Pt:
   VVpvWi = VVY2Pt.servicelist
   if VVpvWi:
    return VVpvWi.mode == 1
  return self.VVqmNY
 def VViLmY(self, VVYo8S):
  self.close()
  VVYo8S.cancel()
 def VVSAfG(self, VVYo8S, title, txt, colList):
  FFTztI(VVYo8S, colList[2], VVLjiH=False, checkParentalControl=True)
 def VVNJaW(self, VVYo8S, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(VVYo8S)
  if refCode:
   VVYo8S.VVFzdA(2, FFvNg9(refCode, iptvRef, chName), True)
 def VVDezS(self, VVYo8S, title, txt, colList):
  servName = colList[0]
  mSel = CC3iyH(self, VVYo8S)
  VVv6X1, cbFncDict = CCnEIM.VVpQIZ(self, VVYo8S, servName, 2)
  mSel.VVzccf(VVv6X1, cbFncDict)
 def VVea6X(self, VVYo8S, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFwYti(self, fncMode=CCWhEO.VVRXS5, refCode=refCode, chName=chName, text=txt)
 def VVXsLL(self):
  FFWkqs(self, self.VV2Y3j, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV2Y3j(self):
  ret = FF8S9j(self.refCode, True)
  if ret:
   self.VViSaj()
   self.close()
  else:
   FFfad8(self, "Cannot change state" , 1000)
 def VViSaj(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVYTUE()
  except:
   self.VVHIqQ()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFj6M9(self, serviceRef)
 def VVYTUE(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVY2Pt = InfoBar.instance
   if VVY2Pt:
    VVpvWi = VVY2Pt.servicelist
    if VVpvWi:
     hList = VVpvWi.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVpvWi.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVpvWi.history  = newList
       VVpvWi.history_pos = pos
 def VVHIqQ(self):
  VVY2Pt = InfoBar.instance
  if VVY2Pt:
   VVpvWi = VVY2Pt.servicelist
   if VVpvWi:
    VVpvWi.history  = []
    VVpvWi.history_pos = 0
 def VVH9LT(self):
  VVY2Pt = InfoBar.instance
  VV4Gbf = []
  if VVY2Pt:
   VVpvWi = VVY2Pt.servicelist
   if VVpvWi:
    VVZ2TC, VVWyfL = FF9RbH()
    for serv in VVpvWi.history:
     refCode = serv[-1].toString()
     chName = FFv14i(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFW8kf(refCode)
     isSRel = FFUUIm(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFlSfT(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVZ2TC:
       STYPE = VVWyfL[sTypeInt]
     VV4Gbf.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV4Gbf:
   VVXwx9  = ("Zap"   , self.VVYpJi   , [])
   VVPogp = ("Clear History" , self.VVVN4u   , [])
   VVTMvN = (""    , self.VVmMcq , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVK4mA  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VVXwx9=VVXwx9, VVPogp=VVPogp, VVTMvN=VVTMvN)
  else:
   FFrNpu(self, "Not found", title=title)
 def VVYpJi(self, VVYo8S, title, txt, colList):
  FFTztI(VVYo8S, colList[3], VVLjiH=False, checkParentalControl=True)
 def VVVN4u(self, VVYo8S, title, txt, colList):
  FFWkqs(self, BF(self.VVoyQM, VVYo8S), "Clear Zap History ?")
 def VVoyQM(self, VVYo8S):
  self.VVHIqQ()
  VVYo8S.cancel()
 def VVmMcq(self, VVYo8S, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFwYti(self, fncMode=CCWhEO.VVFAWC, refCode=refCode, chName=chName, text=txt)
class CCxA8L(Screen, CCwRkZ):
 VVOiq1   = 0
 VVbGCs  = 1
 VVMtZl  = 2
 VVGTcm  = 3
 VVeZu3  = 4
 VV1AyA  = 5
 VVzaMt  = 6
 VVBCfZ  = 7
 VVjduI = 8
 VVfC20 = 9
 VVi399 = 10
 VVyfxU = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VVnO5X, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCxA8L.VV76e0()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVouKi    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFDBTO(self, self.Title)
  FFjeeE(self["keyRed"] , "OK = Zap")
  FFjeeE(self["keyGreen"] , "Current Service")
  FFjeeE(self["keyYellow"], "Page Options")
  FFjeeE(self["keyBlue"] , "Filter")
  CCwRkZ.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VV1kZm     ,
   "green"  : self.VV3P6N    ,
   "yellow" : self.VVpusO     ,
   "blue"  : self.VVTFwe     ,
   "menu"  : self.VVwliW     ,
   "info"  : self.VVsGQ4    ,
   "pageUp" : BF(self.VVPv3N, True) ,
   "chanUp" : BF(self.VVPv3N, True) ,
   "pageDown" : BF(self.VVPv3N, False) ,
   "chanDown" : BF(self.VVPv3N, False) ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  FFjMgg(self)
  FF2A0B(self["keyRed"], "#0a333333")
  self.VVDrA1()
  self.VV1vyD()
  FF0rXP(self, BF(self.VVjwhy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVwliW(self):
  if not self.isBusy:
   VVv6X1 = []
   VVv6X1.append(("Statistics"           , "VVBzuH"    ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Suggest PIcons for Current Channel"     , "VVavy0"   ))
   VVv6X1.append(("Set to Current Channel (copy file)"     , "VVc4wz_file"  ))
   VVv6X1.append(("Set to Current Channel (as SymLink)"     , "VVc4wz_link"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Export Current File Names List"      , "VVP21r" ))
   VVv6X1.append(CCxA8L.VVFh5V())
   VVv6X1.append(VVdKVg)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VV8tcv
    VVv6X1.append((c + movTxt           , "VVZ537"  ))
    VVv6X1.append((c + delTxt           , "VVNidT" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVv6X1.append((movTxt + disTxt         ,       ))
    VVv6X1.append((delTxt + disTxt         ,       ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVvIHP"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1 += CCxA8L.VVIiVI()
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Change Poster/Picon Transparency Color"    , "VVV5lt" ))
   VVv6X1.append(("Keys Help"           , "VVh1Ss"    ))
   FFLwVh(self, self.VVJnhV, width=1100, height=1050, title=self.Title, VVv6X1=VVv6X1)
 def VVJnhV(self, item=None):
  if item is not None:
   if   item == "VVBzuH"     : self.VVBzuH()
   elif item == "VVavy0"    : self.VVavy0()
   elif item == "VVc4wz_file"   : self.VVc4wz(0)
   elif item == "VVc4wz_link"   : self.VVc4wz(1)
   elif item == "VVP21r"   : self.VVP21r()
   elif item == "VVFu6R"   : CCxA8L.VVFu6R(self)
   elif item == "VVZ537"    : self.VVZ537()
   elif item == "VVNidT"   : self.VVNidT()
   elif item == "VVvIHP"   : self.VVvIHP()
   elif item == "VVZXpU"   : CCxA8L.VVZXpU(self)
   elif item == "findPiconBrokenSymLinks"  : CCxA8L.VVv5nV(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCxA8L.VVv5nV(self, False)
   elif item == "VVV5lt"  : self.VVV5lt()
   elif item == "VVh1Ss"      : FFAqgP(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVpusO(self):
  if not self.isBusy:
   VVv6X1 = []
   VVv6X1.append(("Go to First PIcon"  , "VV228L"  ))
   VVv6X1.append(("Go to Last PIcon"   , "VVatGv"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Sort by Channel Name"     , "sortByChan" ))
   VVv6X1.append(("Sort by File Name"  , "sortByFile" ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Find from File List .." , "VVcZn7" ))
   FFLwVh(self, self.VVno5y, title=self.Title, VVv6X1=VVv6X1)
 def VVno5y(self, item=None):
  if item is not None:
   if   item == "VV228L"   : self.VV228L()
   elif item == "VVatGv"   : self.VVatGv()
   elif item == "sortByChan"  : self.VVTP9y(2)
   elif item == "sortByFile"  : self.VVTP9y(0)
   elif item == "VVcZn7"  : self.VVcZn7()
 def VVcZn7(self):
  VVv6X1 = []
  for item in self.VVouKi:
   VVv6X1.append((item[0], item[0]))
  FFLwVh(self, self.VVBJ3e, title='PIcons ".png" Files', VVv6X1=VVv6X1, VVrAw7=True)
 def VVBJ3e(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVipMk(ndx)
 def VV1kZm(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV8dkZ()
   if refCode:
    FFTztI(self, refCode)
    self.VVRAUn()
    self.VViLs8()
 def VVPv3N(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVRAUn()
   self.VViLs8()
  except:
   pass
 def VV3P6N(self):
  if self["keyGreen"].getVisible():
   self.VVipMk(self.curChanIndex)
 def VVTP9y(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF0rXP(self, BF(self.VVjwhy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVc4wz(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV8dkZ()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVv6X1 = []
     VVv6X1.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVv6X1.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFLwVh(self, BF(self.VVWxAP, mode, curChF, selPiconF), VVv6X1=VVv6X1, title="Current Channel PIcon (already exists)")
    else:
     self.VVWxAP(mode, curChF, selPiconF, "overwrite")
   else:
    FFRGBb(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFRGBb(self, "Could not read current channel info. !", title=title)
 def VVWxAP(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF0rXP(self, BF(self.VVjwhy, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVZ537(self):
  defDir = FFiSR4(CCxA8L.VV76e0() + "picons_backup")
  os.system(FFWqNF("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVs4ZG, defDir), BF(CCOjzn
         , mode=CCOjzn.VVmcgf, VVOgpG=CCxA8L.VV76e0()))
 def VVs4ZG(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCxA8L.VV76e0():
    FFRGBb(self, "Cannot move to same directory !", title=title)
   else:
    if not FFiSR4(path) == FFiSR4(defDir):
     self.VVX1ak(defDir)
    FFWkqs(self, BF(FF0rXP, self, BF(self.VVOog5, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVouKi), path), title=title)
  else:
   self.VVX1ak(defDir)
 def VVOog5(self, title, defDir, toPath):
  if not iMove:
   self.VVX1ak(defDir)
   FFRGBb(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFiSR4(toPath)
  pPath = CCxA8L.VV76e0()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVouKi:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVouKi)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFipfq(self, txt, title=title, VVOSNp="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVjlgf("all")
 def VVX1ak(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVNidT(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVouKi)
  FFWkqs(self, BF(FF0rXP, self, BF(self.VVMq3S, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FF2vwS(tot)), title=title)
 def VVMq3S(self, title):
  pPath = CCxA8L.VV76e0()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVouKi:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVouKi)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFf1xo(str(totErr), VVqskC)
  FFipfq(self, txt, title=title)
 def VVvIHP(self):
  lines = FFqfZV("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFWkqs(self, BF(self.VVFRZz, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FF2vwS(tot)), VVaQmw=True)
  else:
   FFrNpu(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVFRZz(self, fList):
  os.system(FFWqNF("find -L '%s' -type l -delete" % self.pPath))
  FFrNpu(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVsGQ4(self):
  FF0rXP(self, self.VV6RGT)
 def VV6RGT(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV8dkZ()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFf1xo("PIcon Directory:\n", VV0HRz)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFT7fV(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFT7fV(path)
   txt += FFf1xo("PIcon File:\n", VV0HRz)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFf1xo("Found %d SymLink%s to this file from:\n" % (tot, FF2vwS(tot)), VV0HRz)
     for fPath in slLst:
      txt += "  %s\n" % FFf1xo(fPath, VVe79W)
     txt += "\n"
   if chName:
    txt += FFf1xo("Channel:\n", VV0HRz)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFf1xo(chName, VVvsR7)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFf1xo("Remarks:\n", VV0HRz)
    txt += "  %s\n" % FFf1xo("Unused", VVqskC)
  else:
   txt = "No info found"
  FFwYti(self, fncMode=CCWhEO.VVhjVl, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV8dkZ(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVouKi[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFvyCa(sat)
  return fName, refCode, chName, sat, inDB
 def VVRAUn(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVouKi):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VViLs8(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV8dkZ()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFf1xo("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV0HRz))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV8dkZ()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFUUIm(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFf1xo(self.curChanName, VVy4op)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VV8dkZ()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVBzuH(self):
  VVZ2TC, VVWyfL = FF9RbH()
  sTypeNameDict = {}
  for key, val in VVWyfL.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVouKi:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVWyfL: sTypeDict[VVWyfL[stNum]] = sTypeDict.get(VVWyfL[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFTbYu("find -L '%s' -type l -print | wc -l" % self.pPath)
  VV4Gbf = []
  c = "#b#11003333#"
  VV4Gbf.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VV4Gbf.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VV4Gbf.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VV4Gbf.append((c + "In Database (lamedb)"  , str(totInDB)))
  VV4Gbf.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VV4Gbf.append((c + "Satellites"    , str(len(self.nsList))))
  VV4Gbf.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VV4Gbf.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VV4Gbf.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VV4Gbf.extend(sTypeRows)
  FFl3hs(self, None, title=self.Title, VVouKi=VV4Gbf, VVcK4p=28, VVuQjw="#00003333", VVVwZb="#00222222")
 def VVP21r(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFiSR4(CFG.exportedTablesPath.getValue()), txt, FFWWBu())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVouKi:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFrNpu(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVTFwe(self):
  if not self.isBusy:
   VVv6X1 = []
   VVv6X1.append(("All"         , "all"   ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Used by Channels"      , "used"  ))
   VVv6X1.append(("Unused PIcons"      , "unused"  ))
   VVv6X1.append(("IPTV PIcons"       , "iptv"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("PIcons Files"       , "pFiles"  ))
   VVv6X1.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVv6X1.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVv6X1.append(("By Files Date ..."     , "pDate"  ))
   VVv6X1.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVv6X1.append(FF9558("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFUgik(val)
      VVv6X1.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCFC3v(self)
   filterObj.VVTmbZ(VVv6X1, self.nsList, self.VVrolb)
 def VVrolb(self, item=None):
  if item is not None:
   self.VVjlgf(item)
 def VVjlgf(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVOiq1   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVbGCs   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVMtZl  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVzaMt   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVGTcm  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVeZu3  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV1AyA  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVi399 , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVyfxU , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVBCfZ   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVjduI , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV1AyA:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFqfZV("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFj5JI(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFfad8(self, "Not found", 1000)
     return
   elif mode == self.VVi399:
    self.VV5X2G(mode)
    return
   elif mode == self.VVyfxU:
    self.VVwQt4(mode)
    return
   elif mode == self.VVfC20:
    return
   else:
    words, asPrefix = CCFC3v.VVXFHp(words)
   if not words and mode in (self.VVBCfZ, self.VVjduI):
    FFfad8(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF0rXP(self, BF(self.VVjwhy, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV5X2G(self, mode):
  VVv6X1 = []
  VVv6X1.append(("Today"   , "today" ))
  VVv6X1.append(("Since Yesterday" , "yest" ))
  VVv6X1.append(("Since 7 days"  , "week" ))
  FFLwVh(self, BF(self.VVUefx, mode), VVv6X1=VVv6X1, title="Filter by Added/Modified Date")
 def VVUefx(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFYhkG(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFYhkG(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFYhkG(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF0rXP(self, BF(self.VVjwhy, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVwQt4(self, mode):
  VVZ2TC, VVWyfL = FF9RbH()
  lst = set()
  for key, val in VVWyfL.items():
   lst.add(val)
  VVv6X1 = []
  for item in lst:
   VVv6X1.append((item, item))
  VVv6X1.sort(key=lambda x: x[0])
  FFLwVh(self, BF(self.VVe2Oa, mode), VVv6X1=VVv6X1, title="Filter by Service Type")
 def VVe2Oa(self, mode, item=None):
  if item:
   VVZ2TC, VVWyfL = FF9RbH()
   sTypeList = []
   for key, val in VVWyfL.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF0rXP(self, BF(self.VVjwhy, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVavy0(self):
  self.session.open(CCF2c1, barTheme=CCF2c1.VVYiGp
      , titlePrefix = ""
      , fncToRun  = self.VVmbgU
      , VVkuAk = self.VVPvI8)
 def VVmbgU(self, VVtdJ0):
  VVMUsL, err = CCnEIM.VVxj6i(self, CCnEIM.VVKXFu, VV1P1O=False, VV1pA1=False)
  files = []
  words = []
  if not VVtdJ0 or VVtdJ0.isCancelled:
   return
  VVtdJ0.VVwHZ6 = []
  VVtdJ0.VVhRNu(len(VVMUsL))
  if VVMUsL:
   VV30jT = CCcIbP()
   curCh = VV30jT.VVnw5I(self.curChanName)
   for refCode in VVMUsL:
    if not VVtdJ0 or VVtdJ0.isCancelled:
     return
    VVtdJ0.VVcdeL(1, True)
    chName, sat, inDB = VVMUsL.get(refCode, ("", "", 0))
    ratio = CCxA8L.VVX7Et(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCxA8L.VVWQj1(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFj5JI(f)
       fil = f.replace(".png", "")
       if not fil in VVtdJ0.VVwHZ6:
        VVtdJ0.VVwHZ6.append(fil)
 def VVPvI8(self, VVzWxR, VVwHZ6, threadCounter, threadTotal, threadErr):
  if VVwHZ6 : FF0rXP(self, BF(self.VVjwhy, mode=self.VVfC20, words=VVwHZ6), title="Loading ...")
  else   : FFfad8(self, "Not found", 2000)
 def VVjwhy(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVOYUw(isFirstTime):
   return
  self.isBusy = True
  VV1pA1 = True if isFirstTime else False
  VVMUsL, err = CCnEIM.VVxj6i(self, CCnEIM.VVKXFu, VV1P1O=False, VV1pA1=VV1pA1)
  if err:
   self.close()
  iptvRefList = self.VVcagj()
  tList = []
  for fName, fType in CCxA8L.VVkyO5(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVMUsL:
    if fName in VVMUsL:
     chName, sat, inDB = VVMUsL.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVOiq1:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVbGCs  and chName         : isAdd = True
   elif mode == self.VVMtZl and not chName        : isAdd = True
   elif mode == self.VVGTcm  and fType == 0        : isAdd = True
   elif mode == self.VVeZu3  and fType == 1        : isAdd = True
   elif mode == self.VV1AyA  and fName in words       : isAdd = True
   elif mode == self.VVfC20 and fName in words       : isAdd = True
   elif mode == self.VVzaMt  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVBCfZ  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVjduI:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVi399:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVyfxU:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVouKi   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFfad8(self)
  else:
   self.isBusy = False
   FFfad8(self, "Not found", 1000)
   return
  self.VVouKi.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVRAUn()
  self.totalItems = len(self.VVouKi)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVjtON(True)
 def VVOYUw(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCxA8L.VVkyO5(self.pPath):
    if fName:
     return True
   if isFirstTime : FFRGBb(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFfad8(self, "Not found", 1000)
  else:
   FFRGBb(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVcagj(self):
  VV4Gbf = {}
  files  = CCCGrE.VV2TEe()
  if files:
   for path in files:
    txt = FFUKzq(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV4Gbf[refCode] = item[1]
  return VV4Gbf
 def VVHKht(self):
  self.VVwoJu()
  f1, f2 = self.VVULM3()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVouKi[ndx]
   fName = self.VVouKi[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFf1xo(chName, VVvsR7))
    else : lbl.setText("-")
   except:
    lbl.setText(FFf1xo(chName, VVRgTn))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVX7Et(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVFh5V():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVFu6R"   )
 @staticmethod
 def VVIiVI():
  VVv6X1 = []
  VVv6X1.append(("Find SymLinks (to PIcon Directory)"   , "VVZXpU"   ))
  VVv6X1.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVv6X1.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVv6X1
 @staticmethod
 def VVFu6R(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF)
  png, path = CCxA8L.VVMGvX(refCode)
  if path : CCxA8L.VV7cpC(SELF, png, path)
  else : FFRGBb(SELF, "No PIcon found for current channel in:\n\n%s" % CCxA8L.VV76e0())
 @staticmethod
 def VVZXpU(SELF):
  if VVy4op:
   sed1 = FFy8kX("->", VVy4op)
   sed2 = FFy8kX("picon", VVqskC)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVRgTn, VVH2yZ)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFXvUZ(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFpy4F(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVv5nV(SELF, isPIcon):
  sed1 = FFy8kX("->", VVRgTn)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFy8kX("picon", VVqskC)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFXvUZ(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFpy4F(), grep, sed1, sed2))
 @staticmethod
 def VVkyO5(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV76e0():
  path = CFG.PIconsPath.getValue()
  return FFiSR4(path)
 @staticmethod
 def VVMGvX(refCode, chName=None):
  if FFW8kf(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFQOHf(refCode)
  allPath, fName, refCodeFile, pList = CCxA8L.VVWQj1(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV7cpC(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFy8kX("%s%s" % (dest, png), VVvsR7))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFy8kX(errTxt, VVL1qM))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFYYbP(SELF, cmd)
 @staticmethod
 def VVWQj1(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCxA8L.VV76e0()
   pList = []
   lst = FF37hM(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFtomh(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFj5JI(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCqPhk():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVUCGi  = None
  self.VVjIaU = ""
  self.VVom5Z  = noService
  self.VVdTWd = 0
  self.VVZRqz  = noService
  self.VVVzev = 0
  self.VVC2h8  = "-"
  self.VVKvBp = 0
  self.VVrBo9  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVTPIO(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVUCGi = frontEndStatus
     self.VVL8zr()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVL8zr(self):
  if self.VVUCGi:
   val = self.VVUCGi.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVjIaU = "%3.02f dB" % (val / 100.0)
   else         : self.VVjIaU = ""
   val = self.VVUCGi.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVdTWd = int(val)
   self.VVom5Z  = "%d%%" % val
   val = self.VVUCGi.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVVzev = int(val)
   self.VVZRqz  = "%d%%" % val
   val = self.VVUCGi.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVC2h8  = "%d" % val
   val = int(val * 100 / 500)
   self.VVKvBp = min(500, val)
   val = self.VVUCGi.get("tuner_locked", 0)
   if val == 1 : self.VVrBo9 = "Locked"
   else  : self.VVrBo9 = "Not locked"
 def VVbeI1(self)   : return self.VVjIaU
 def VVJR1j(self)   : return self.VVom5Z
 def VV2MK3(self)  : return self.VVdTWd
 def VVZidI(self)   : return self.VVZRqz
 def VVRphM(self)  : return self.VVVzev
 def VVQ6n6(self)   : return self.VVC2h8
 def VV9LtE(self)  : return self.VVKvBp
 def VVwtm0(self)   : return self.VVrBo9
 def VV931q(self) : return self.serviceName
class CCg4Ht():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVBozx(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFopyC(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVX0We(self.ORPOS  , mod=1   )
      self.sat2  = self.VVX0We(self.ORPOS  , mod=2   )
      self.freq  = self.VVX0We(self.FREQ  , mod=3   )
      self.sr   = self.VVX0We(self.SR   , mod=4   )
      self.inv  = self.VVX0We(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVX0We(self.POL  , self.D_POL )
      self.fec  = self.VVX0We(self.FEC  , self.D_FEC )
      self.syst  = self.VVX0We(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVX0We("modulation" , self.D_MOD )
       self.rolof = self.VVX0We("rolloff"  , self.D_ROLOF )
       self.pil = self.VVX0We("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVX0We("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVX0We("pls_code"  )
       self.iStId = self.VVX0We("is_id"   )
       self.t2PlId = self.VVX0We("t2mi_plp_id" )
       self.t2PId = self.VVX0We("t2mi_pid"  )
 def VVX0We(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFUgik(val)
  elif mod == 2   : return FFs1xj(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVKt7d(self, refCode):
  txt = ""
  self.VVBozx(refCode)
  if self.data:
   def VV8Lwm(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV8Lwm("System"   , self.syst)
    txt += VV8Lwm("Satellite"  , self.sat2)
    txt += VV8Lwm("Frequency"  , self.freq)
    txt += VV8Lwm("Inversion"  , self.inv)
    txt += VV8Lwm("Symbol Rate"  , self.sr)
    txt += VV8Lwm("Polarization" , self.pol)
    txt += VV8Lwm("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV8Lwm("Modulation" , self.mod)
     txt += VV8Lwm("Roll-Off" , self.rolof)
     txt += VV8Lwm("Pilot"  , self.pil)
     txt += VV8Lwm("Input Stream", self.iStId)
     txt += VV8Lwm("T2MI PLP ID" , self.t2PlId)
     txt += VV8Lwm("T2MI PID" , self.t2PId)
     txt += VV8Lwm("PLS Mode" , self.plsMod)
     txt += VV8Lwm("PLS Code" , self.plsCod)
   else:
    txt += VV8Lwm("System"   , self.txMedia)
    txt += VV8Lwm("Frequency"  , self.freq)
  return txt, self.namespace
 def VVaPsv(self, refCode):
  txt = "Transpoder : ?"
  self.VVBozx(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVw2sY(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFopyC(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVX0We(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVX0We(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVX0We(self.SYST, self.D_SYS_S)
     freq = self.VVX0We(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVX0We(self.POL , self.D_POL)
      fec = self.VVX0We(self.FEC , self.D_FEC)
      sr = self.VVX0We(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVfnUn(self, refCode):
  self.data = None
  self.VVBozx(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCyIuf():
 def __init__(self, VVBmNm, path, VVkuAk=None, curRowNum=-1):
  self.VVBmNm  = VVBmNm
  self.origFile   = path
  self.Title    = "File Editor: " + FFj5JI(path)
  self.VVkuAk  = VVkuAk
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFWqNF("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVjnqF(curRowNum)
  else:
   FFRGBb(self.VVBmNm, "Error while preparing edit!")
 def VVjnqF(self, curRowNum):
  VV4Gbf = self.VVz15Q()
  VV6vKb = ("Save Changes" , self.VVOzkS   , [])
  VVXwx9  = ("Edit Line"  , self.VV0nic    , [])
  VVPogp = ("Go to Line Num" , self.VVWcrF   , [])
  VVxkVZ = ("Line Options" , self.VVQo3W   , [])
  VVxKfW = (""    , self.VVjgb3 , [])
  VVgYq4 = self.VVE2Z4
  VVCUH0  = self.VVNliz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVK4mA  = (CENTER  , LEFT  )
  VVYo8S = FFl3hs(self.VVBmNm, None, title=self.Title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VV6vKb=VV6vKb, VVXwx9=VVXwx9, VVPogp=VVPogp, VVxkVZ=VVxkVZ, VVgYq4=VVgYq4, VVCUH0=VVCUH0, VVxKfW=VVxKfW, VVWKtq=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVyRL8   = "#11001111"
    , VVmr0Y   = "#11001111"
    , VVOSNp   = "#11001111"
    , VVuQjw  = "#05333333"
    , VVVwZb  = "#00222222"
    , VVU8z2  = "#11331133"
    )
  VVYo8S.VVG9tX(curRowNum)
 def VVWcrF(self, VVYo8S, title, txt, colList):
  totRows = VVYo8S.VVDPuF()
  lineNum = VVYo8S.VVjpse() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFufG1(self.VVBmNm, BF(self.VVmA7d, VVYo8S, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVmA7d(self, VVYo8S, lineNum, totRows, VVGZ8H):
  if VVGZ8H:
   VVGZ8H = VVGZ8H.strip()
   if VVGZ8H.isdigit():
    num = FF0CSz(int(VVGZ8H) - 1, 0, totRows)
    VVYo8S.VVG9tX(num)
    self.lastLineNum = num + 1
   else:
    FFfad8(VVYo8S, "Incorrect number", 1500)
 def VVQo3W(self, VVYo8S, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVYo8S.VVzMwz()
  VVv6X1 = []
  VVv6X1.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVv6X1.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VV7kli"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV8Cu8:
   VVv6X1.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(  ("Delete Line"         , "deleteLine"   ))
  FFLwVh(self.VVBmNm, BF(self.VV6GTg, VVYo8S, lineNum), VVv6X1=VVv6X1, title="Line Options")
 def VV6GTg(self, VVYo8S, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVpy1r("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVYo8S)
   elif item == "VV7kli"  : self.VV7kli(VVYo8S, lineNum)
   elif item == "copyToClipboard"  : self.VVZUfu(VVYo8S, lineNum)
   elif item == "pasteFromClipboard" : self.VVfXyJ(VVYo8S, lineNum)
   elif item == "deleteLine"   : self.VVpy1r("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVYo8S)
 def VVNliz(self, VVYo8S):
  VVYo8S.VVRcVH()
 def VVjgb3(self, VVYo8S, title, txt, colList):
  if   self.insertMode == 1: VVYo8S.VVBeNQ()
  elif self.insertMode == 2: VVYo8S.VVVLgx()
  self.insertMode = 0
 def VV7kli(self, VVYo8S, lineNum):
  if lineNum == VVYo8S.VVzMwz():
   self.insertMode = 1
   self.VVpy1r("echo '' >> '%s'" % self.tmpFile, VVYo8S)
  else:
   self.insertMode = 2
   self.VVpy1r("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVYo8S)
 def VVZUfu(self, VVYo8S, lineNum):
  global VV8Cu8
  VV8Cu8 = FFTbYu("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVYo8S.VVu9dh("Copied to clipboard")
 def VVOzkS(self, VVYo8S, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFWqNF("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFWqNF("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVYo8S.VVu9dh("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVYo8S.VVRcVH()
    else:
     FFRGBb(self.VVBmNm, "Cannot save file!")
   else:
    FFRGBb(self.VVBmNm, "Cannot create backup copy of original file!")
 def VVE2Z4(self, VVYo8S):
  if self.fileChanged:
   FFWkqs(self.VVBmNm, BF(self.VVJ4kf, VVYo8S), "Cancel changes ?")
  else:
   finalOK = os.system(FFWqNF("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVJ4kf(VVYo8S)
 def VVJ4kf(self, VVYo8S):
  VVYo8S.cancel()
  FFsF1P(self.tmpFile)
  if self.VVkuAk:
   self.VVkuAk(self.fileSaved)
 def VV0nic(self, VVYo8S, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVH2yZ + "ORIGINAL TEXT:\n" + VVe79W + lineTxt
  FFufG1(self.VVBmNm, BF(self.VV26QF, lineNum, VVYo8S), title="File Line", defaultText=lineTxt, message=message)
 def VV26QF(self, lineNum, VVYo8S, VVGZ8H):
  if not VVGZ8H is None:
   if VVYo8S.VVzMwz() <= 1:
    self.VVpy1r("echo %s > '%s'" % (VVGZ8H, self.tmpFile), VVYo8S)
   else:
    self.VVLGYA(VVYo8S, lineNum, VVGZ8H)
 def VVfXyJ(self, VVYo8S, lineNum):
  if lineNum == VVYo8S.VVzMwz() and VVYo8S.VVzMwz() == 1:
   self.VVpy1r("echo %s >> '%s'" % (VV8Cu8, self.tmpFile), VVYo8S)
  else:
   self.VVLGYA(VVYo8S, lineNum, VV8Cu8)
 def VVLGYA(self, VVYo8S, lineNum, newTxt):
  VVYo8S.VVhzMj("Saving ...")
  lines = FFRtPk(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVYo8S.VV9NIW()
  VV4Gbf = self.VVz15Q()
  VVYo8S.VVPCrn(VV4Gbf)
 def VVpy1r(self, cmd, VVYo8S):
  tCons = CCo0hB()
  tCons.ePopen(cmd, BF(self.VVkeFj, VVYo8S))
  self.fileChanged = True
  VVYo8S.VV9NIW()
 def VVkeFj(self, VVYo8S, result, retval):
  VV4Gbf = self.VVz15Q()
  VVYo8S.VVPCrn(VV4Gbf)
 def VVz15Q(self):
  if fileExists(self.tmpFile):
   lines = FFRtPk(self.tmpFile)
   VV4Gbf = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV4Gbf.append((str(ndx), line.strip()))
   if not VV4Gbf:
    VV4Gbf.append((str(1), ""))
   return VV4Gbf
  else:
   FFZBzs(self.VVBmNm, self.tmpFile)
class CCFC3v():
 def __init__(self, callingSELF, VVyRL8="#22003344", VVmr0Y="#22002233"):
  self.callingSELF = callingSELF
  self.VVv6X1  = []
  self.satList  = []
  self.VVyRL8  = VVyRL8
  self.VVmr0Y   = VVmr0Y
 def VVgJ0W(self, VVkuAk):
  self.VVv6X1 = []
  VVv6X1, VVDExR = CCFC3v.VVVzEQ(self.callingSELF, False, True)
  if VVv6X1:
   self.VVv6X1 += VVv6X1
   self.VVgHAE(VVkuAk, VVDExR)
 def VVz8kj(self, mode, VVYo8S, satCol, VVkuAk, inFilterFnc=None):
  VVYo8S.VVhzMj("Loading Filters ...")
  self.VVv6X1 = []
  self.VVv6X1.append(("All Services" , "all"))
  if mode == 1:
   self.VVv6X1.append(VVdKVg)
   self.VVv6X1.append(("Parental Control", "parentalControl"))
   self.VVv6X1.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVv6X1.append(VVdKVg)
   self.VVv6X1.append(("Selected Transponder"   , "selectedTP" ))
   self.VVv6X1.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVGUqm(VVYo8S, satCol)
  VVv6X1, VVDExR = CCFC3v.VVVzEQ(self.callingSELF, True, False)
  if VVv6X1:
   VVv6X1.insert(0, FF9558("Custom Words"))
   self.VVv6X1 += VVv6X1
  VVYo8S.VVxwMk()
  self.VVgHAE(VVkuAk, VVDExR, inFilterFnc)
 def VVTmbZ(self, VVv6X1, sats, VVkuAk, inFilterFnc=None):
  self.VVv6X1 = VVv6X1
  VVv6X1, VVDExR = CCFC3v.VVVzEQ(self.callingSELF, True, False)
  if VVv6X1:
   self.VVv6X1.append(FF9558("Custom Words"))
   self.VVv6X1 += VVv6X1
  self.VVgHAE(VVkuAk, VVDExR, inFilterFnc)
 def VVgHAE(self, VVkuAk, VVDExR, inFilterFnc=None):
  VV3h4q  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVqSIC = ("Edit Filter"  , BF(self.VVbhir, VVDExR))
  VVxtuz  = ("Filter Help"  , BF(self.VVtN62, VVDExR))
  FFLwVh(self.callingSELF, BF(self.VVnsJg, VVkuAk), VVv6X1=self.VVv6X1, title="Select Filter", VV3h4q=VV3h4q, VVqSIC=VVqSIC, VVxtuz=VVxtuz, VV8k4Z=True, VVyRL8=self.VVyRL8, VVmr0Y=self.VVmr0Y)
 def VVnsJg(self, VVkuAk, item):
  if item:
   VVkuAk(item)
 def VVbhir(self, VVDExR, VVLmuPObj, sel):
  if fileExists(VVDExR) : CCyIuf(self.callingSELF, VVDExR, VVkuAk=None)
  else       : FFZBzs(self.callingSELF, VVDExR)
  VVLmuPObj.cancel()
 def VVtN62(self, VVDExR, VVLmuPObj, sel):
  FFAqgP(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVGUqm(self, VVYo8S, satColNum):
  if not self.satList:
   satList = VVYo8S.VVZj7I(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFvyCa(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FF9558("Satellites"))
  if self.VVv6X1:
   self.VVv6X1 += self.satList
 @staticmethod
 def VVVzEQ(SELF, addTag, VVy0Oi):
  FFI9nQ()
  fileName  = "ajpanel_services_filter"
  VVDExR = VVsoKC + fileName
  VVv6X1  = []
  if not fileExists(VVDExR):
   os.system(FFWqNF("cp -f '%s' '%s'" % (VVCsc2 + fileName, VVDExR)))
  fileFound = False
  if fileExists(VVDExR):
   fileFound = True
   lines = FFRtPk(VVDExR)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVv6X1.append((line, "__w__" + line))
       else  : VVv6X1.append((line, line))
  if VVy0Oi:
   if   not fileFound : FFZBzs(SELF, VVDExR)
   elif not VVv6X1 : FFr7wg(SELF, VVDExR)
  return VVv6X1, VVDExR
 @staticmethod
 def VVXFHp(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC3iyH():
 def __init__(self, callingSELF, VVYo8S, addSep=True):
  self.callingSELF = callingSELF
  self.VVYo8S = VVYo8S
  self.VVv6X1 = []
  iMulSel = self.VVYo8S.VVlPxr()
  if iMulSel : self.VVv6X1.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVv6X1.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVYo8S.VVTK0J()
  self.VVv6X1.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVv6X1.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVv6X1.append(VVdKVg)
 def VVzccf(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVv6X1.extend(extraMenu)
  FFLwVh(self.callingSELF, BF(self.VVmP2u, cbFncDict, okFnc), width=width, title="Options", VVv6X1=self.VVv6X1)
 def VVmP2u(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVYo8S.VVw9l3(True)
   elif item == "MultSelDisab" : self.VVYo8S.VVw9l3(False)
   elif item == "selectAll" : self.VVYo8S.VVMrk8()
   elif item == "unselectAll" : self.VVYo8S.VVO0Vn()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CClAPU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVJ2KD, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFDBTO(self)
  FFjeeE(self["keyRed"]  , "Exit")
  FFjeeE(self["keyGreen"]  , "Save")
  FFjeeE(self["keyYellow"] , "Refresh")
  FFjeeE(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VV12yc  ,
   "green" : self.VV7Buy ,
   "yellow": self.VVbEeZ  ,
   "blue" : self.VVUgWq   ,
   "up" : self.VVCsIb    ,
   "down" : self.VV3ZBv   ,
   "left" : self.VVJXQv   ,
   "right" : self.VV54hN   ,
   "cancel": self.VV12yc
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self.VVbEeZ()
  self.VVPArW()
  FFjMgg(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVeyW5)
  except:
   self.timer.callback.append(self.VVeyW5)
  self.timer.start(1000, False)
  self.VVeyW5()
 def onExit(self):
  self.timer.stop()
 def VV12yc(self) : self.close(True)
 def VVbhDY(self) : self.close(False)
 def VVUgWq(self):
  self.session.openWithCallback(self.VVTiu1, BF(CC07cE))
 def VVTiu1(self, closeAll):
  if closeAll:
   self.close()
 def VVeyW5(self):
  self["curTime"].setText(str(FFQFpj(iTime())))
 def VVCsIb(self):
  self.VVNMMQ(1)
 def VV3ZBv(self):
  self.VVNMMQ(-1)
 def VVJXQv(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVPArW()
 def VV54hN(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVPArW()
 def VVNMMQ(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVBt7K(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVBt7K(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVBt7K(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVo5Ao(year)):
   days += 1
  return days
 def VVo5Ao(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVPArW(self):
  for obj in self.list:
   FF2A0B(obj, "#11404040")
  FF2A0B(self.list[self.index], "#11ff8000")
 def VVbEeZ(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV7Buy(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCo0hB()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVt77W)
 def VVt77W(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFrNpu(self, "Nothing returned from the system!")
  else:
   FFrNpu(self, str(result))
class CC07cE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVxJQK, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFDBTO(self, addLabel=True)
  FFjeeE(self["keyRed"]  , "Exit")
  FFjeeE(self["keyGreen"]  , "Sync")
  FFjeeE(self["keyYellow"] , "Refresh")
  FFjeeE(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VV12yc   ,
   "green" : self.VV8KyJ  ,
   "yellow": self.VV7Jps ,
   "blue" : self.VVUgd1  ,
   "cancel": self.VV12yc
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVokSr()
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  FFjMgg(self)
  FFFO8C(self.refresh)
 def refresh(self):
  self.VVuMw5()
  self.VVf5z5(False)
 def VV12yc(self)  : self.close(True)
 def VVUgd1(self) : self.close(False)
 def VVokSr(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVuMw5(self):
  self.VVZTAS()
  self.VVV5ms()
  self.VVXcJE()
  self.VVXgCi()
 def VV7Jps(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVokSr()
   self.VVuMw5()
   FFFO8C(self.refresh)
 def VV8KyJ(self):
  if len(self["keyGreen"].getText()) > 0:
   FFWkqs(self, self.VVOAkq, "Synchronize with Internet Date/Time ?")
 def VVOAkq(self):
  self.VVuMw5()
  FFFO8C(BF(self.VVf5z5, True))
 def VVZTAS(self)  : self["keyRed"].show()
 def VV3ygA(self)  : self["keyGreen"].show()
 def VVeMyo(self) : self["keyYellow"].show()
 def VVVah6(self)  : self["keyBlue"].show()
 def VVV5ms(self)  : self["keyGreen"].hide()
 def VVXcJE(self) : self["keyYellow"].hide()
 def VVXgCi(self)  : self["keyBlue"].hide()
 def VVf5z5(self, sync):
  localTime = FFGSTP()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVcJiw(server)
   if epoch_time is not None:
    ntpTime = FFQFpj(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCo0hB()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVt77W, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVeMyo()
  self.VVVah6()
  if ok:
   self.VV3ygA()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVt77W(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVf5z5(False)
  except:
   pass
 def VVcJiw(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFGXQq():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC0vLz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFUxcO(VVS7k0, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFDBTO(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFFO8C(self.VV71RG)
 def VV71RG(self):
  if FFGXQq(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF2A0B(self["myBody"], color)
   FF2A0B(self["myLabel"], color)
  except:
   pass
class CCrLDb(Screen):
 VVBQtj = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFEnkn()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFUxcO(VV5ACW, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC1vvu(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC1vvu(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC1vvu(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCqPhk()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFDBTO(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVCsIb       ,
   "down"  : self.VV3ZBv      ,
   "left"  : self.VVJXQv      ,
   "right"  : self.VV54hN      ,
   "info"  : self.VVTDGM     ,
   "epg"  : self.VVTDGM     ,
   "menu"  : self.VVh1Ss      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVWNVb, -1)  ,
   "next"  : BF(self.VVWNVb, 1)  ,
   "pageUp" : BF(self.VVdfd3, True) ,
   "chanUp" : BF(self.VVdfd3, True) ,
   "pageDown" : BF(self.VVdfd3, False) ,
   "chanDown" : BF(self.VVdfd3, False) ,
   "0"   : BF(self.VVWNVb, 0)  ,
   "1"   : BF(self.VVUWtx, pos=1) ,
   "2"   : BF(self.VVUWtx, pos=2) ,
   "3"   : BF(self.VVUWtx, pos=3) ,
   "4"   : BF(self.VVUWtx, pos=4) ,
   "5"   : BF(self.VVUWtx, pos=5) ,
   "6"   : BF(self.VVUWtx, pos=6) ,
   "7"   : BF(self.VVUWtx, pos=7) ,
   "8"   : BF(self.VVUWtx, pos=8) ,
   "9"   : BF(self.VVUWtx, pos=9) ,
  }, -1)
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  if not CCrLDb.VVBQtj:
   CCrLDb.VVBQtj = self
  self.sliderSNR.VVgtGH()
  self.sliderAGC.VVgtGH()
  self.sliderBER.VVgtGH(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVUWtx()
  self.VVt3LA()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVOv7k)
  except:
   self.timer.callback.append(self.VVOv7k)
  self.timer.start(500, False)
 def VVt3LA(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVTPIO(service)
  serviceName = self.tunerInfo.VV931q()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  tp = CCg4Ht()
  tpTxt, satTxt = tp.VVaPsv(refCode)
  if tpTxt == "?" :
   tpTxt = FFf1xo("NO SIGNAL", VV8tcv)
  self["myTPInfo"].setText(tpTxt + "  " + FFf1xo(satTxt, VVKiZJ))
 def VVOv7k(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVTPIO(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVbeI1())
   self["mySNR"].setText(self.tunerInfo.VVJR1j())
   self["myAGC"].setText(self.tunerInfo.VVZidI())
   self["myBER"].setText(self.tunerInfo.VVQ6n6())
   self.sliderSNR.VVA4jz(self.tunerInfo.VV2MK3())
   self.sliderAGC.VVA4jz(self.tunerInfo.VVRphM())
   self.sliderBER.VVA4jz(self.tunerInfo.VV9LtE())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVA4jz(0)
   self.sliderAGC.VVA4jz(0)
   self.sliderBER.VVA4jz(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
    if state and not state == "Tuned":
     FFfad8(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVTDGM(self):
  FFwYti(self, fncMode=CCWhEO.VVCjHI)
 def VVh1Ss(self):
  FFAqgP(self, "_help_signal", "Signal Monitor (Keys)")
 def VVCsIb(self)  : self.VVUWtx(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV3ZBv(self) : self.VVUWtx(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVJXQv(self) : self.VVUWtx(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV54hN(self) : self.VVUWtx(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVUWtx(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFcghP(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVWNVb(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF0CSz(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFcghP(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCrLDb.VVBQtj = None
 def VVdfd3(self, isUp):
  FFfad8(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVt3LA()
  except:
   pass
class CC1vvu(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVgtGH(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF2A0B(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVCsc2 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF2A0B(self.covObj, self.covColor)
   else:
    FF2A0B(self.covObj, "#00006688")
    self.isColormode = True
  self.VVA4jz(0)
 def VVA4jz(self, val):
  val  = FF0CSz(val, self.minN, self.maxN)
  width = int(FFF1Ee(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF0CSz(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCF2c1(Screen):
 VVYiGp    = 0
 VVVDkX = 1
 VViD0Y = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVkuAk=None, barTheme=VVYiGp, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVbu2d(barTheme)
  self.skin, self.skinParam = FFUxcO(VVn5nb, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVkuAk = VVkuAk
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVwHZ6 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFDBTO(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self.VV9Qet()
  self["myProgBarVal"].setText("0%")
  FF2A0B(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVf95V()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVf95V)
  except:
   self.timer.callback.append(self.VVf95V)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVhRNu(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV4a50(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVwHZ6), self.counter, self.maxValue, catName)
 def VVt6fp(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVXoWi(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV5aV1(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVPMCq(self, title):
  self.newTitle = title
  try:
   self.VVf95V()
  except:
   pass
 def VVyHD5(self, txt):
  self.newTitle = txt
 def VVcdeL(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVwHZ6), self.counter, self.maxValue)
  except:
   pass
 def VVV4KZ(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVdKNh(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVRnkp(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFfad8(self, "Cancelling ...")
  self.isCancelled = True
  self.VVMnAz(False)
 def VVMnAz(self, isDone):
  if self.VVkuAk:
   self.VVkuAk(isDone, self.VVwHZ6, self.counter, self.maxValue, self.isError)
  self.close()
 def VVf95V(self):
  val = FF0CSz(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFF1Ee(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVMnAz(True)
 def VV9Qet(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVVDkX, self.VViD0Y):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVbu2d(self, barTheme):
  if   barTheme == self.VVVDkX : return 0.7
  if   barTheme == self.VViD0Y : return 0.5
  else             : return 1
class CCo0hB(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVkuAk = {}
  self.commandRunning = False
  self.VVQr59  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVkuAk, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVkuAk[name] = VVkuAk
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVQr59:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VV02SG, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVlzYV , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VV02SG, name))
    self.appContainers[name].appClosed.append(BF(self.VVlzYV , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVlzYV(name, retval)
  return True
 def VV02SG(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFf1xo("[UN-DECODED STRING]", VV8tcv))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVlzYV(self, name, retval):
  if not self.VVQr59:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVkuAk[name]:
   self.VVkuAk[name](self.appResults[name], retval)
  del self.VVkuAk[name]
 def VVjxR1(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCFteI(Screen):
 def __init__(self, session, title="", VVdEBn=None, VVp6aH=False, VVESIo=False, VVZ5tc=False, VVh2ED=False, VV6cmr=False, VVKVlv=False, VVKhCn=VVKes2, VVo3en=None, VViaRD=False, VVaAze=None, VVgfAq="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFUxcO(VVvoh9, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFDBTO(self, addScrollLabel=True)
  if not VVgfAq:
   VVgfAq = "Processing ..."
  self["myLabel"].setText("   %s" % VVgfAq)
  self.VVp6aH   = VVp6aH
  self.VVESIo   = VVESIo
  self.VVZ5tc   = VVZ5tc
  self.VVh2ED  = VVh2ED
  self.VV6cmr = VV6cmr
  self.VVKVlv = VVKVlv
  self.VVKhCn   = VVKhCn
  self.VVo3en = VVo3en
  self.VViaRD  = VViaRD
  self.VVaAze  = VVaAze
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCo0hB()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFs7ER()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVdEBn, str):
   self.VVdEBn = [VVdEBn]
  else:
   self.VVdEBn = VVdEBn
  if self.VVZ5tc or self.VVh2ED:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVT41S, VVT41S)
   self.VVdEBn.append("echo -e '\n%s\n' %s" % (restartNote, FFy8kX(restartNote, VVy4op)))
   if self.VVZ5tc:
    self.VVdEBn.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVdEBn.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV6cmr:
   FFfad8(self, "Processing ...")
  self.onLayoutFinish.append(self.VVDW7c)
  self.onClose.append(self.VVAGoS)
 def VVDW7c(self):
  self["myLabel"].VVUfQy(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVp6aH:
   self["myLabel"].VVCO8f()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVUKmo()
  else:
   self.VVdwQC()
 def VVUKmo(self):
  if FFGXQq():
   self["myLabel"].setText("Processing ...")
   self.VVdwQC()
  else:
   self["myLabel"].setText(FFf1xo("\n   No connection to internet!", VVqskC))
 def VVdwQC(self):
  allOK = self.container.ePopen(self.VVdEBn[0], self.VVRqhW, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVRqhW("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVKVlv or self.VVZ5tc or self.VVh2ED:
    self["myLabel"].setText(FFb8P2("STARTED", VVy4op) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVaAze:
   colorWhite = CCZV4T.VVPzaV(VVH2yZ)
   color  = CCZV4T.VVPzaV(self.VVaAze[0])
   words  = self.VVaAze[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVKhCn=self.VVKhCn)
 def VVRqhW(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVdEBn):
   allOK = self.container.ePopen(self.VVdEBn[self.cmdNum], self.VVRqhW, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVRqhW("Cannot connect to Console!", -1)
  else:
   if self.VV6cmr and FFCEoK(self):
    FFfad8(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVKVlv:
    self["myLabel"].appendText("\n" + FFb8P2("FINISHED", VVy4op), self.VVKhCn)
   if self.VVp6aH or self.VVESIo:
    self["myLabel"].VVCO8f()
   if self.VVo3en is not None:
    self.VVo3en()
   if not retval and self.VViaRD:
    self.VVAGoS()
 def VVAGoS(self):
  if self.container.VVjxR1():
   self.container.killAll()
class CCnmf5(Screen):
 def __init__(self, session, VVdEBn=None, VV6cmr=False):
  self.skin, self.skinParam = FFUxcO(VVvoh9, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVsoKC + "ajpanel_terminal.history"
  self.customCommandsFile = VVsoKC + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFTbYu("pwd") or "/home/root"
  self.container   = CCo0hB()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFDBTO(self, title="Terminal", addScrollLabel=True)
  FFjeeE(self["keyRed"] , self.exitBtnText)
  FFjeeE(self["keyGreen"] , "OK = History")
  FFjeeE(self["keyYellow"], "Menu = Custom Cmds")
  FFjeeE(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVhb5h ,
   "cancel": self.VV533w  ,
   "menu" : self.VVFoRW ,
   "last" : self.VVYwmF  ,
   "next" : self.VVYwmF  ,
   "1"  : self.VVYwmF  ,
   "2"  : self.VVYwmF  ,
   "3"  : self.VVYwmF  ,
   "4"  : self.VVYwmF  ,
   "5"  : self.VVYwmF  ,
   "6"  : self.VVYwmF  ,
   "7"  : self.VVYwmF  ,
   "8"  : self.VVYwmF  ,
   "9"  : self.VVYwmF  ,
   "0"  : self.VVYwmF
  })
  self.onLayoutFinish.append(self.VVzGCv)
  self.onClose.append(self.VVjpfg)
 def VVzGCv(self):
  self["myLabel"].VVUfQy(isResizable=False, outputFileToSave="terminal")
  FFqst5(self["keyRed"]  , "#00ff8000")
  FF2A0B(self["keyRed"]  , self.skinParam["titleColor"])
  FF2A0B(self["keyGreen"]  , self.skinParam["titleColor"])
  FF2A0B(self["keyYellow"] , self.skinParam["titleColor"])
  FF2A0B(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVffFF(FFTbYu("date"), 5)
  result = FFTbYu("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVaSqr()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVCsc2 + "LinuxCommands.lst"
   newTemplate = VVCsc2 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFWqNF("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFWqNF("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVjpfg(self):
  if self.container.VVjxR1():
   self.container.killAll()
   self.VVffFF("Process killed\n", 4)
   self.VVaSqr()
 def VV533w(self):
  if self.container.VVjxR1():
   self.VVjpfg()
  else:
   FFWkqs(self, self.close, "Exit ?", VVxoh5=False)
 def VVaSqr(self):
  self.VVffFF(self.prompt, 1)
  self["keyRed"].hide()
 def VVffFF(self, txt, mode):
  if   mode == 1 : color = VVy4op
  elif mode == 2 : color = VV0HRz
  elif mode == 3 : color = VVH2yZ
  elif mode == 4 : color = VVqskC
  elif mode == 5 : color = VVe79W
  elif mode == 6 : color = VVpLjr
  else   : color = VVH2yZ
  try:
   self["myLabel"].appendText(FFf1xo(txt, color))
  except:
   pass
 def VVhb5h(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVYGN0() == "":
   self.VV1Agi("cd /tmp")
   self.VV1Agi("ls")
  VV4Gbf = []
  if fileExists(self.commandHistoryFile):
   lines  = FFRtPk(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV4Gbf.append((str(c), line, str(lNum)))
   self.VVqzkm(VV4Gbf, title, self.commandHistoryFile, isHistory=True)
  else:
   FFZBzs(self, self.commandHistoryFile, title=title)
 def VVYGN0(self):
  lastLine = FFTbYu("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV1Agi(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVFoRW(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFRtPk(self.customCommandsFile)
   lastLineIsSep = False
   VV4Gbf = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV4Gbf.append((str(c), line, str(lNum)))
   self.VVqzkm(VV4Gbf, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFZBzs(self, self.customCommandsFile, title=title)
 def VVqzkm(self, VV4Gbf, title, filePath=None, isHistory=False):
  if VV4Gbf:
   VVuQjw = "#05333333"
   if isHistory: VVyRL8 = VVmr0Y = VVOSNp = "#11000020"
   else  : VVyRL8 = VVmr0Y = VVOSNp = "#06002020"
   VVXwx9   = ("Send"   , BF(self.VVC1Yp, isHistory)  , [])
   VV6vKb  = ("Modify & Send" , self.VVtnwF     , [])
   if isHistory:
    VVPogp = ("Clear History" , self.VV8oRi     , [])
    VVxkVZ = None
   elif filePath:
    VVPogp = ("Options"  , self.VVeK5S      , [])
    VVxkVZ = ("Edit File"  , BF(self.VVEN1I, filePath) , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVK4mA = (CENTER , LEFT   , CENTER )
   VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ, lastFindConfigObj=CFG.lastFindTerminal, VVWKtq=True, searchCol=1
         , VVyRL8=VVyRL8, VVmr0Y=VVmr0Y, VVOSNp=VVOSNp, VV5fad="#05ffff00", VVuQjw=VVuQjw)
   if not isHistory:
    VVYo8S.VVG9tX(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFr7wg(self, filePath, title=title)
 def VVeK5S(self, VVYo8S, title, txt, colList):
  mSel = CC3iyH(self, VVYo8S)
  if VVYo8S.VVRSSP:
   totSel = VVYo8S.VVTK0J()
   totTxt = str(totSel)
   txt = "Send %s Command%s" % (FFf1xo(totTxt, VVy4op) if totSel else totTxt, FF2vwS(totSel))
   VVv6X1 = [(txt, "send")] if totSel else [(txt,)]
  else:
   VVv6X1 = [("Send current line", "send")]
  cbFncDict = {"send": BF(self.VVC1Yp, False, VVYo8S, title, txt, colList)}
  mSel.VVzccf(VVv6X1, cbFncDict, okFnc=BF(self.VVxYrD, VVYo8S))
 def VVxYrD(self, VVYo8S):
  if VVYo8S.VVRSSP : VVYo8S.VVRcVH()
  else        : VVYo8S.VV9NIW()
 def VVC1Yp(self, isHistory, VVYo8S, title, txt, colList):
  if VVYo8S.VVRSSP:
   lst = VVYo8S.VVZ4YI(1)
   curNdx = VVYo8S.VV0zSO()
  else:
   lst = [colList[1]]
   curNdx = VVYo8S.VVjpse()
  if not isHistory:
   FFcghP(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVYo8S.cancel()
  FFFO8C(self.VV8XyS)
 def VV8XyS(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVffFF("\n%s\n" % cmd, 6)
    self.VVffFF(self.prompt, 1)
    self.VV8XyS()
   else:
    self.VVDF85(cmd)
 def VVDF85(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVffFF(cmd, 2)
   self.VVffFF("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVffFF(ch, 0)
   self.VVffFF("\nor\n", 4)
   self.VVffFF("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVaSqr()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFf1xo(parts[0].strip(), VV0HRz)
    right = FFf1xo("#" + parts[1].strip(), VVpLjr)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVffFF(txt, 2)
   lastLine = self.VVYGN0()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV1Agi(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVRqhW, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFRGBb(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVffFF(data, 3)
 def VVRqhW(self, data, retval):
  if not retval == 0:
   self.VVffFF("Exit Code : %d\n" % retval, 4)
  self.VVaSqr()
  if self.commandsList:
   self.VV8XyS()
 def VVtnwF(self, VVYo8S, title, txt, colList):
  if VVYo8S.VVtep6():
   cmd = colList[1]
   self.VVNn74(VVYo8S, cmd)
 def VV8oRi(self, VVYo8S, title, txt, colList):
  FFWkqs(self, BF(self.VVNwCZ, VVYo8S), "Reset History File ?", title="Command History")
 def VVNwCZ(self, VVYo8S):
  os.system(FFWqNF("echo '' > %s" % self.commandHistoryFile))
  VVYo8S.cancel()
 def VVEN1I(self, filePath, VVYo8S, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCyIuf(self, filePath, VVkuAk=BF(self.VVC47L, VVYo8S), curRowNum=rowNum)
  else     : FFZBzs(self, filePath)
 def VVC47L(self, VVYo8S, fileChanged):
  if fileChanged:
   VVYo8S.cancel()
   FFFO8C(self.VVFoRW)
 def VVYwmF(self):
  self.VVNn74(None, self.lastCommand)
 def VVNn74(self, VVYo8S, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFufG1(self, BF(self.VVjQGK, VVYo8S), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVjQGK(self, VVYo8S, cmd):
  if cmd and len(cmd) > 0:
   self.VVDF85(cmd)
   if VVYo8S:
    VVYo8S.cancel()
class CC2vEc(Screen):
 def __init__(self, session, title="", message="", VVKhCn=VVKes2, width=1400, height=800, VVjYPr=False, VVOSNp=None, VVcK4p=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFUxcO(VVvoh9, width, height, titleFontSize, 30, 20, "#22002020", "#22001122", VVcK4p)
  self.session   = session
  FFDBTO(self, title, addScrollLabel=True)
  self.VVKhCn   = VVKhCn
  self.VVjYPr   = VVjYPr
  self.VVOSNp   = VVOSNp
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self["myLabel"].VVUfQy(VVjYPr=self.VVjYPr, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVKhCn)
  if self.VVOSNp:
   FF2A0B(self["myBody"], self.VVOSNp)
   FF2A0B(self["myLabel"], self.VVOSNp)
   FFJbsx(self["myLabel"], self.VVOSNp)
  self["myLabel"].VVCO8f()
class CCHSKa(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFUxcO(VVg8qH, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFDBTO(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFcuek(self["errPic"], "err")
class CCKXTc(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFUxcO(VVJKGg, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFDBTO(self, " ", addCloser=True)
class CCIwVQ():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCKXTc, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFfZuu(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdj8h)
  except:
   self.timer.callback.append(self.VVdj8h)
  self.timer.start(timeout, True)
 def VVdj8h(self):
  self.session.deleteDialog(self.win)
class CCNUxQ():
 VVjtov    = 0
 VVNtgE  = 1
 VV10Y8   = ""
 VVlFY1    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVYo8S   = None
  self.timer     = eTimer()
  self.VVIuoZ   = 0
  self.VV5DRn  = 1
  self.VVwIFt  = 2
  self.VVLJuR   = 3
  self.VVyxlq   = 4
  VV4Gbf = self.VVEnTD()
  if VV4Gbf:
   self.VVYo8S = self.VV9z6d(VV4Gbf)
  if not VV4Gbf and mode == self.VVjtov:
   self.VVa2fj("Download list is empty !")
   self.cancel()
  if mode == self.VVNtgE:
   FF0rXP(self.VVYo8S or self.SELF, BF(self.VV1sHv, startDnld, decodedUrl), title="Checking Server ...")
  self.VVfQ6M(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVfQ6M)
  except:
   self.timer.callback.append(self.VVfQ6M)
  self.timer.start(1000, False)
 def VV9z6d(self, VV4Gbf):
  VV4Gbf.sort(key=lambda x: int(x[0]))
  VVgYq4 = self.VVxpMG
  VVXwx9  = ("Play"  , self.VVsCaM , [])
  VVTMvN = (""   , self.VVgrx9  , [])
  VVtXvO = ("Stop"  , self.VV7zUn  , [])
  VV6vKb = ("Resume"  , self.VVXJzO , [])
  VVPogp = ("Options" , self.VVwliW  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVK4mA  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFl3hs(self.SELF, None, title=self.Title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVXwx9=VVXwx9, VVTMvN=VVTMvN, VVgYq4=VVgYq4, VVtXvO=VVtXvO, VV6vKb=VV6vKb, VVPogp=VVPogp, lastFindConfigObj=CFG.lastFindIptv, VVyRL8="#11220022", VVmr0Y="#11110011", VVOSNp="#11110011", VV5fad="#00ffff00", VVuQjw="#00223025", VVVwZb="#0a333333", VVU8z2="#0a400040", VVWKtq=True, searchCol=1)
 def VVEnTD(self):
  lines = CCNUxQ.VV08ut()
  VV4Gbf = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVndcW(decodedUrl)
      if fName:
       if   FFrq1B(decodedUrl) : sType = "Movie"
       elif FFTyfy(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVLQaz(decodedUrl, fName)
       if size > -1: sizeTxt = CCOjzn.VV7GBO(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV4Gbf.append((str(len(VV4Gbf) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV4Gbf
 def VVW4Bg(self):
  VV4Gbf = self.VVEnTD()
  if VV4Gbf:
   if self.VVYo8S : self.VVYo8S.VVPCrn(VV4Gbf, VVokSrMsg=False)
   else     : self.VVYo8S = self.VV9z6d(VV4Gbf)
  else:
   self.cancel()
 def VVfQ6M(self, force=False):
  if self.VVYo8S:
   thrListUrls = self.VVV6GV()
   VV4Gbf = []
   changed = False
   for ndx, row in enumerate(self.VVYo8S.VVl6T3()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVIuoZ
    if m3u8Log:
     percent = CCNUxQ.VV5GYi(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVLJuR , "%.2f %%" % percent
      else   : flag, progr = self.VVyxlq , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFDH0v(mPath)
     if curSize > -1:
      fSize = CCOjzn.VV7GBO(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCOjzn.VV7GBO(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFDH0v(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVLJuR , "%.2f %%" % percent
       else   : flag, progr = self.VVyxlq , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCOjzn.VV7GBO(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVwIFt
     if m3u8Log :
      if not speed and not force : flag = self.VV5DRn
      elif curSize == -1   : self.VVLMEL(False)
    elif flag == self.VVIuoZ  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVIuoZ  : color2 = "#f#00555555#"
    elif flag == self.VV5DRn : color2 = "#f#0000FFFF#"
    elif flag == self.VVwIFt : color2 = "#f#0000FFFF#"
    elif flag == self.VVLJuR  : color2 = "#f#00FF8000#"
    elif flag == self.VVyxlq  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVBuS6(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV4Gbf.append(row)
   if changed or force:
    self.VVYo8S.VVPCrn(VV4Gbf, VVokSrMsg=False)
 def VVBuS6(self, flag):
  tDict = self.VVeiqa()
  return tDict.get(flag, "?")
 def VVtClh(self, state):
  for flag, txt in self.VVeiqa().items():
   if txt == state:
    return flag
  return -1
 def VVeiqa(self):
  return { self.VVIuoZ: "Not started", self.VV5DRn: "Connecting", self.VVwIFt: "Downloading", self.VVLJuR: "Stopped", self.VVyxlq: "Completed" }
 def VVPwzz(self, title):
  colList = self.VVYo8S.VVK0Ui()
  path = colList[6]
  url  = colList[8]
  if self.VVn2cz() : self.VVa2fj("Cannot delete !\n\nFile is downloading.")
  else      : FFWkqs(self.SELF, BF(self.VVb05J, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVb05J(self, path, url):
  m3u8Log = self.VVYo8S.VVK0Ui()[12]
  if m3u8Log : os.system(FFWqNF("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFWqNF("rm -r '%s'" % path))
  self.VVG9E0(False)
  self.VVW4Bg()
 def VVG9E0(self, VVy0Oi=True):
  if self.VVn2cz():
   FFfad8(self.VVYo8S, self.VVBuS6(self.VVwIFt), 500)
  else:
   colList  = self.VVYo8S.VVK0Ui()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVtClh(state) in (self.VVIuoZ, self.VVyxlq, self.VVLJuR):
    lines = CCNUxQ.VV08ut()
    newLines = []
    found = False
    for line in lines:
     if CCNUxQ.VVv2AF(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVMGDv(newLines)
     self.VVW4Bg()
     FFfad8(self.VVYo8S, "Removed.", 1000)
    else:
     FFfad8(self.VVYo8S, "Not found.", 1000)
   elif VVy0Oi:
    self.VVa2fj("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVAEIo(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFWkqs(self.SELF, BF(self.VVs7HP, flag), ques, title=title)
 def VVs7HP(self, flag):
  list = []
  for ndx, row in enumerate(self.VVYo8S.VVl6T3()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVtClh(state)
   if   flag == flagVal == self.VVyxlq: list.append(decodedUrl)
   elif flag == flagVal == self.VVIuoZ : list.append(decodedUrl)
  lines = CCNUxQ.VV08ut()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVMGDv(newLines)
   self.VVW4Bg()
   FFfad8(self.VVYo8S, "%d removed." % totRem, 1000)
  else:
   FFfad8(self.VVYo8S, "Not found.", 1000)
 def VV3U4S(self):
  colList  = self.VVYo8S.VVK0Ui()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFfad8(self.VVYo8S, "Poster exists", 1500)
  else    : FF0rXP(self.VVYo8S, BF(self.VVtNl8, decodedUrl, path, png), title="Checking Server ...")
 def VVtNl8(self, decodedUrl, path, png):
  err = self.VVp0f9(decodedUrl, path, png)
  if err:
   FFRGBb(self.SELF, err, title="Poster Download")
 def VVp0f9(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCWc1W.VVOkTh(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCGrE.VVcPPT(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCCGrE.VVMcOx(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFn4Tu(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFWqNF("mv -f '%s' '%s'" % (tPath, png)))
   CCXjSu.VVTYNz(self.SELF, VV8Zdd=png, showGrnMsg="Downloaded")
   return ""
 def VVgrx9(self, VVYo8S, title, txt, colList):
  def VVko9g(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV8Lwm(key, val) : return "\n%s:\n%s\n" % (FFf1xo(key, VVKiZJ), val.strip())
  heads  = self.VVYo8S.VVe3lP()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVko9g(heads[i]  , CCOjzn.VV7GBO(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVko9g("Downloaded" , CCOjzn.VV7GBO(int(curSize), mode=0))
   else:
    txt += VVko9g(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV8Lwm(heads[i], colList[i])
  FFipfq(self.SELF, txt, title=title)
 def VVsCaM(self, VVYo8S, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCOjzn.VVaWiz(self.SELF, path)
  else    : FFfad8(self.VVYo8S, "File not found", 1000)
 def VVxpMG(self, VVYo8S):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVYo8S:
   self.VVYo8S.cancel()
  del self
 def VVwliW(self, VVYo8S, title, txt, colList):
  c1, c2, c3 = VVityU, VVqskC, VVKiZJ
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVv6X1 = []
  VVv6X1.append((c1 + "Remove current row"       , "VVG9E0" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVv6X1.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c2 + "Delete the file (and remove from list)"  , "VVPwzz"))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((resumeTxt + " Auto Resume"       , "VVHtsv" ))
  VVv6X1.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVv6X1.append(VVdKVg)
  t = "Download Movie Poster "
  if FFrq1B(decodedUrl): VVv6X1.append((c3 + "%s(from server)" % t , "VV3U4S"  ))
  else      : VVv6X1.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVv6X1.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVv6X1.append(("Open in File Manager"  ,      ))
  FFLwVh(self.SELF, BF(self.VVyU40, VVYo8S), VVv6X1=VVv6X1, title=self.Title, VVrAw7=True, width=800, VV8k4Z=True, VVyRL8="#1a001122", VVmr0Y="#1a001122")
 def VVyU40(self, VVYo8S, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVG9E0"  : self.VVG9E0()
   elif ref == "remFinished"   : self.VVAEIo(self.VVyxlq, txt)
   elif ref == "remPending"   : self.VVAEIo(self.VVIuoZ, txt)
   elif ref == "VVPwzz" : self.VVPwzz(txt)
   elif ref == "VV3U4S"  : self.VV3U4S()
   elif ref == "VVHtsv"  : FFcghP(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFcghP(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCOjzn, mode=CCOjzn.VVTQdI, jumpToFile=path)
    else    : FFfad8(VVYo8S, "Path not found !", 1500)
 def VV1sHv(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCWc1W.VVOkTh(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVa2fj("Could not get download link !\n\nTry again later.")
     return
  for line in CCNUxQ.VV08ut():
   if CCNUxQ.VVv2AF(decodedUrl, line):
    if self.VVYo8S:
     self.VVAO2i(decodedUrl)
     FFFO8C(BF(FFfad8, self.VVYo8S, "Already listed !", 2000))
    break
  else:
   params = self.VVBn6n(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVa2fj(params[0])
   elif len(params) == 2:
    FFWkqs(self.SELF, BF(self.VVtMoz, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCOjzn.VV7GBO(fSize)
    FFWkqs(self.SELF, BF(self.VVZXSv, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVZXSv(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCNUxQ.VVwqFp(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVW4Bg()
  if self.VVYo8S:
   self.VVYo8S.VVVLgx()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCNUxQ.VVlFY1, path, decodedUrl)
   self.VVLmv4(threadName, url, decodedUrl, path, resp)
 def VVAO2i(self, decodedUrl):
  if self.VVYo8S:
   for ndx, row in enumerate(self.VVYo8S.VVl6T3()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVYo8S:
     self.VVYo8S.VVG9tX(ndx)
     break
 def VVBn6n(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVndcW(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVLQaz(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCWc1W.VVOkTh(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCWc1W.VV9JCs()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCNUxQ.VVvWcp(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCNUxQ.VVsfkO(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVtMoz(self, resp, decodedUrl):
  if not os.system(FFWqNF("which ffmpeg")) == 0:
   FFWkqs(self.SELF, BF(CCCGrE.VV2FlJ, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVndcW(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVoVs0(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFWkqs(self.SELF, BF(self.VVW2l0, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVW2l0(rTxt, rUrl)
  else:
   self.VVa2fj("Cannot process m3u8 file !")
 def VVoVs0(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVv6X1 = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCCGrE.VVrJAJ(rUrl, fPath)
   VVv6X1.append((resol, fullUrl))
  if VVv6X1:
   FFLwVh(self.SELF, self.VVi376, VVv6X1=VVv6X1, title="Resolution", VVrAw7=True, VV8k4Z=True)
  else:
   self.VVa2fj("Cannot get Resolutions list from server !")
 def VVi376(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFWkqs(self.SELF, BF(FFFO8C, BF(self.VVYuUm, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFFO8C(BF(self.VVYuUm, resolUrl))
 def VVYuUm(self, resolUrl):
  txt, err = CCWc1W.VV7euB(resolUrl)
  if err : self.VVa2fj(err)
  else : self.VVW2l0(txt, resolUrl)
 def VVbxVS(self, logF, decodedUrl):
  found = False
  lines = CCNUxQ.VV08ut()
  with open(CCNUxQ.VVwqFp(), "w") as f:
   for line in lines:
    if CCNUxQ.VVv2AF(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCNUxQ.VVwqFp(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVW4Bg()
  if self.VVYo8S:
   self.VVYo8S.VVVLgx()
 def VVW2l0(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCCGrE.VVrJAJ(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVa2fj("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVbxVS(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFWqNF("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCNUxQ.VVlFY1, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VV5GYi(dnldLog):
  if fileExists(dnldLog):
   dur = CCNUxQ.VVkGvr(dnldLog)
   if dur > -1:
    tim = CCNUxQ.VVUQLQ(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVkGvr(dnldLog):
  lines = FFqfZV("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVUQLQ(dnldLog):
  lines = FFqfZV("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVLQaz(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFTyfy(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFWqNF("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVLmv4(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVYo8S.VVK0Ui()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVc2ML, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVc2ML(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VV10Y8 == path:
       break
     else:
      break
  except:
   return
  if CCNUxQ.VV10Y8:
   CCNUxQ.VV10Y8 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFDH0v(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVBn6n(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVc2ML(url, decodedUrl, path, resp, totFileSize, True)
 def VV7zUn(self, VVYo8S, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVG7XY() : FFfad8(self.VVYo8S, self.VVBuS6(self.VVyxlq), 500)
  elif not self.VVn2cz() : FFfad8(self.VVYo8S, self.VVBuS6(self.VVLJuR), 500)
  elif m3u8Log      : FFWkqs(self.SELF, self.VVLMEL, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVV6GV():
    CCNUxQ.VV10Y8 = colList[6]
    FFfad8(self.VVYo8S, "Stopping ...", 1000)
   else:
    FFfad8(self.VVYo8S, "Stopped", 500)
 def VVLMEL(self, withMsg=True):
  if withMsg:
   FFfad8(self.VVYo8S, "Stopping ...", 1000)
  os.system(FFWqNF("killall -INT ffmpeg"))
 def VVXJzO(self, *args):
  if   self.VVG7XY() : FFfad8(self.VVYo8S, self.VVBuS6(self.VVyxlq) , 500)
  elif self.VVn2cz() : FFfad8(self.VVYo8S, self.VVBuS6(self.VVwIFt), 500)
  else:
   resume = False
   m3u8Log = self.VVYo8S.VVK0Ui()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFWkqs(self.SELF, BF(self.VVFRwf, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VViLay():
    resume = True
   if resume: FF0rXP(self.VVYo8S, BF(self.VVVP2h), title="Checking Server ...")
   else  : FFfad8(self.VVYo8S, "Cannot resume !", 500)
 def VVFRwf(self, m3u8Log):
  os.system(FFWqNF("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF0rXP(self.VVYo8S, BF(self.VVVP2h), title="Checking Server ...")
 def VVVP2h(self):
  colList  = self.VVYo8S.VVK0Ui()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCWc1W.VVOkTh(decodedUrl)
   if url:
    decodedUrl = self.VVUJR8(decodedUrl, url)
   else:
    self.VVa2fj("Could not get download link !\n\nTry again later.")
    return
  curSize = FFDH0v(path)
  params = self.VVBn6n(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVa2fj(params[0])
   return
  elif len(params) == 2:
   self.VVtMoz(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVUJR8(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCNUxQ.VVlFY1, path, decodedUrl)
  if resumable: self.VVLmv4(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVa2fj("Cannot resume from server !")
 def VVndcW(self, decodedUrl):
  fileExt = CCCGrE.VVNn5z(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF35eK(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVa2fj(self, txt):
  FFRGBb(self.SELF, txt, title=self.Title)
 def VVV6GV(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCNUxQ.VVlFY1, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVn2cz(self):
  decodedUrl = self.VVYo8S.VVK0Ui()[9]
  return decodedUrl in self.VVV6GV()
 def VVG7XY(self):
  colList = self.VVYo8S.VVK0Ui()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFDH0v(path)) == size
 def VViLay(self):
  colList = self.VVYo8S.VVK0Ui()
  path = colList[6]
  size = int(colList[7])
  curSize = FFDH0v(path)
  if curSize > -1:
   size -= curSize
  err = CCNUxQ.VVsfkO(size)
  if err:
   FFRGBb(self.SELF, err, title=self.Title)
   return False
  return True
 def VVMGDv(self, list):
  with open(CCNUxQ.VVwqFp(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVUJR8(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCNUxQ.VV08ut()
  url = decodedUrl
  with open(CCNUxQ.VVwqFp(), "w") as f:
   for line in lines:
    if CCNUxQ.VVv2AF(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVW4Bg()
  return url
 @staticmethod
 def VV08ut():
  list = []
  if fileExists(CCNUxQ.VVwqFp()):
   for line in FFRtPk(CCNUxQ.VVwqFp()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVv2AF(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVsfkO(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCOjzn.VVFSvh(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCOjzn.VV7GBO(size), CCOjzn.VV7GBO(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVaCag(SELF):
  tot = CCNUxQ.VVwRUz()
  if tot:
   FFRGBb(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVwRUz():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCNUxQ.VVlFY1):
    c += 1
  return c
 @staticmethod
 def VVRN4z():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCNUxQ.VVlFY1, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVFz7u():
  return len(CCNUxQ.VV08ut()) == 0
 @staticmethod
 def VVlQam():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVJBm0():
  mPoints = CCNUxQ.VVlQam()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFWqNF("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVwqFp():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VV4XQs(SELF):
  CCNUxQ.VV2YrP(SELF, CCNUxQ.VVjtov)
 @staticmethod
 def VVN5CP(SELF):
  CCNUxQ.VV2YrP(SELF, CCNUxQ.VVNtgE, startDnld=True)
 @staticmethod
 def VV9jjO(SELF, url):
  CCNUxQ.VV2YrP(SELF, CCNUxQ.VVNtgE, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVEc6r(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF)
  added, skipped = CCNUxQ.VV2whx([decodedUrl])
  FFfad8(SELF, "Added", 1000)
 @staticmethod
 def VV2whx(list):
  added = skipped = 0
  for line in CCNUxQ.VV08ut():
   for ndx, url in enumerate(list):
    if url and CCNUxQ.VVv2AF(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCNUxQ.VVwqFp(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV2YrP(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCavOd.VVYiQx(SELF):
   return
  if mode == CCNUxQ.VVjtov and CCNUxQ.VVFz7u():
   FFRGBb(SELF, "Download list is empty !", title=title)
  else:
   inst = CCNUxQ(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVvWcp(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCSeoi(Screen, CCN3wh):
 VVN5AL = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFUxcO(VViEfp, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCN3wh.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFDBTO(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VV5vqD())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVsJp0       ,
   "info"  : self.VVTDGM      ,
   "epg"  : self.VVTDGM      ,
   "menu"  : self.VVqwPw     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVq72j   ,
   "green"  : self.VVPNIv  ,
   "blue"  : self.VVjMnG      ,
   "yellow" : self.VVWtPD ,
   "left"  : BF(self.VVhAqX, -1)    ,
   "right"  : BF(self.VVhAqX,  1)    ,
   "play"  : self.VV58vw      ,
   "pause"  : self.VV58vw      ,
   "playPause" : self.VV58vw      ,
   "stop"  : self.VV58vw      ,
   "rewind" : self.VVfd0s      ,
   "forward" : self.VVUHcq      ,
   "rewindDm" : self.VVfd0s      ,
   "forwardDm" : self.VVUHcq      ,
   "last"  : self.VV65q2      ,
   "next"  : self.VVXIVr      ,
   "pageUp" : BF(self.VVJ4HD, True)  ,
   "pageDown" : BF(self.VVJ4HD, False)  ,
   "chanUp" : BF(self.VVJ4HD, True)  ,
   "chanDown" : BF(self.VVJ4HD, False)  ,
   "up"  : BF(self.VVJ4HD, True)  ,
   "down"  : BF(self.VVJ4HD, False)  ,
   "audio"  : BF(self.VVVkrm, True)  ,
   "subtitle" : BF(self.VVVkrm, False)  ,
   "text"  : self.VVbE67  ,
   "0"   : BF(self.VVKhoF , 10)   ,
   "1"   : BF(self.VVKhoF , 1)   ,
   "2"   : BF(self.VVKhoF , 2)   ,
   "3"   : BF(self.VVKhoF , 3)   ,
   "4"   : BF(self.VVKhoF , 4)   ,
   "5"   : BF(self.VVKhoF , 5)   ,
   "6"   : BF(self.VVKhoF , 6)   ,
   "7"   : BF(self.VVKhoF , 7)   ,
   "8"   : BF(self.VVKhoF , 8)   ,
   "9"   : BF(self.VVKhoF , 9)
  }, -1)
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  if not CCSeoi.VVN5AL:
   CCSeoi.VVN5AL = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFcuek(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFcuek(self["myPlayRpt"], "rpt")
  self.VVWjfW()
  self.instance.move(ePoint(40, 40))
  self.VVBcJ0(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVL7HF)
  except:
   self.timer.callback.append(self.VVL7HF)
  self.timer.start(250, False)
  self.VVL7HF("Checking ...")
  self.VVmBnr()
 def VVPNIv(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  self.lastSubtitle = CC0VSe.VVCBwf()
  if "chCode" in iptvRef:
   if CCavOd.VVYiQx(self):
    self.VVmBnr(True)
  else:
   self.VVL7HF("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVWjfW(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNnek()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VV8tcv + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FF2A0B(self["myTitle"], tColor)
  FF2A0B(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FF2A0B(self["myPlay%s" % item], tColor)
  picFile = CCWhEO.VValRW(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCWhEO.VVAZrJ(self)
  cl = CCe2gv.VVmA3G(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVL7HF(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCNUxQ.VVwRUz()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNnek()
  if evName:
   evName = "    %s    " % FFf1xo(evName, VVe79W)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVDuST():
   FFqst5(self["myPlayBlu"], "#00FFFFFF")
   FF2A0B(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFqst5(self["myPlayBlu"], "#00FFFF88")
   FF2A0B(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FF2A0B(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FF0CSz(percVal, 0, 100)
   width = int(FFF1Ee(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FF2A0B(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFqst5(self["myPlayMsg"], "#0000ffff")
   else  : FFqst5(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFqst5(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFqst5(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVic3F()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVW7X8(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CC0VSe.VVLbEk(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV65q2()
  state = self.VVxrrU()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFqst5(self["myPlayMsg"], "#0000ff00")
  else     : FFqst5(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVNnek(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFaQmC(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCWhEO.VVJdzg(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCg4Ht()
   tpTxt, satTxt = tp.VVaPsv(refCode)
   self.satInfo_TP = tpTxt + "  " + FFf1xo(satTxt, VVq8cV)
  evName = evNameNext = ""
  evLst = CC8oCo.VVcHFq(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFL4y8(info, iServiceInformation.sVideoWidth) or -1
   h = FFL4y8(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFL4y8(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCWhEO.VVKWCf(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVcLwy(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFD88e(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFD88e(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFD88e(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVqwPw(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNnek()
  FFrq1BSeries = FF35eK(decodedUrl)
  VVv6X1 = []
  if self.isFromExternal:
   VVv6X1.append((VVq8cV + "IPTV Menu", "iptv"))
   VVv6X1.append(VVdKVg)
  if isIptv and not "&end=" in decodedUrl and not FFrq1BSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVv6X1.append((VVq8cV + "Catchup Programs", "catchup" ))
    VVv6X1.append(VVdKVg)
  if refCode:
   c = VV8tcv
   VVv6X1.append((c + "Stop Current Service"  , "stop"  ))
   VVv6X1.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVv6X1.append((txt     ,    ))
   else : VVv6X1.append((c + txt    , "replayWith" ))
   VVv6X1.append(VVdKVg)
  if FFrq1BSeries:
   VVv6X1.append((VVq8cV + "File Size (on server)", "fileSize" ))
   VVv6X1.append(VVdKVg)
  if self.enableDownloadMenu:
   c = VVq8cV
   addSep = False
   if isIptv and FFrq1BSeries:
    VVv6X1.append((c + "Start Download"   , "dload_cur" ))
    VVv6X1.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCNUxQ.VVFz7u():
    VVv6X1.append((VVq8cV + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVv6X1.append(VVdKVg)
  fPath, fDir, fName = CCOjzn.VVb4Zf(self)
  if fPath:
   c = VVkC8X
   if self.enableOpenInFMan and not CCOjzn.VV0ceJ:
    VVv6X1.append((c + "Open path in File Manager", "VVIa8T"))
   VVv6X1.append((c + "Add to Bouquet"             , "VVLl4t" ))
   VVv6X1.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVo7Jh"  ))
   VVv6X1.append(VVdKVg)
  if isDvb:
   VVv6X1.append((VVq8cV + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVv6X1.append((VVKiZJ + "Start Subtitle", "VVx89H"))
   VVv6X1.append(VVdKVg)
  if CFG.playerPos.getValue() : VVv6X1.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVv6X1.append(("Move Bar to Top"  , "top"     ))
  VVv6X1.append(("Help"             , "help"    ))
  FFLwVh(self, self.VVQZGq, VVv6X1=VVv6X1, width=600, title="Options")
 def VVQZGq(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVWtPD()
   elif item == "stop"     : self.VVIwhm(0)
   elif item == "restart"    : self.VVIwhm(1)
   elif item == "replayWith"   : self.VVuY6Q()
   elif item == "fileSize"    : FF0rXP(self, BF(CCWhEO.VVKSMV, self), title="Checking Server")
   elif item == "dload_cur"   : CCNUxQ.VVN5CP(self)
   elif item == "addToDload"   : CCNUxQ.VVEc6r(self)
   elif item == "dload_stat"   : CCNUxQ.VV4XQs(self)
   elif item == "VVIa8T" : self.close("close_openInFileMan")
   elif item == "VVLl4t" : self.VVLl4t()
   elif item == "VVx89H"  : self.VVAbFV()
   elif item == "VVo7Jh"  : self.VVo7Jh()
   elif item == "botm"     : self.VVBcJ0(0)
   elif item == "top"     : self.VVBcJ0(1)
   elif item == "sigMon"    : self.VVq72j()
   elif item == "help"     : FFAqgP(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCSeoi.VVN5AL = None
 def VVIwhm(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVWjfW()
   elif typ == 1:
    self.VVL7HF("Restarting Service ...")
    FFFO8C(BF(self.VVVCoo, serv))
 def VVVCoo(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  if "&end=" in decodedUrl: BF(self.VVmBnr, True)
  else     : self.session.nav.playService(serv)
 def VVuY6Q(self):
  FFLwVh(self, self.VVGNOw, VVv6X1=CCOjzn.VVXMB8(), width=650, title="Select Player", VVyRL8="#11220000", VVmr0Y="#11220000")
 def VVGNOw(self, rType=None):
  if rType:
   FFj6M9(self, eServiceReference(rType + ":" + self.session.nav.getCurrentlyPlayingServiceReference().toString().split(":", 1)[1]))
 def VVLl4t(self):
  fPath, fDir, fName = CCOjzn.VVb4Zf(self)
  if fPath: picker = CCQii3(self, self, "Add Current Movie to a Bouquet", BF(self.VVVVIt, [fPath]))
  else : FFfad8(self, "Path not found !", 1500)
 def VVVVIt(self, pathLst):
  return CCQii3.VVlojO(pathLst)
 def VVo7Jh(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVL7HF(txt, highlight=ok)
 def VVBcJ0(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFcghP(CFG.playerPos, pos)
 def VVq72j(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCWhEO.VVJdzg(serv)
   if isDvb: self.close("close_sig")
   else : self.VVL7HF("No Signal for Current Service")
 def VVAbFV(self):
  self.session.openWithCallback(self.VVZU2c, BF(CC0VSe))
 def VVbE67(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNnek()
   if posTxt and durTxt: self.VVAbFV()
   else    : self.VVL7HF("No duration Info. !")
 def VVZU2c(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVJ4HD(True)
  elif reason == "subtZapDn" : self.VVJ4HD(False)
  elif reason == "pause"  : self.VV58vw()
  elif reason == "audio"  : self.VVVkrm(True)
  elif reason == "subtitle" : self.VVVkrm(False)
  elif reason == "rewind"     : self.VVfd0s()
  elif reason == "forward" : self.VVUHcq()
  elif reason == "rewindDm" : self.VVfd0s()
  elif reason == "forwardDm" : self.VVUHcq()
  else      : txt = reason
  if txt:
   FFfad8(self, txt, 2000)
 def VVsJp0(self):
  if self.isManualSeek:
   self.VVn9Qz()
   self.VVW7X8(self.manualSeekPts)
  elif self.shown:
   if CC0VSe.VVydOM(self): self.VVAbFV()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVn9Qz()
  else    : self.close()
 def VVTDGM(self):
  FFwYti(self, fncMode=CCWhEO.VVeN1z)
 def VV58vw(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVL7HF("Toggling Play/Pause ...")
 def VVn9Qz(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVhAqX(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVrC0w()
   else:
    self.manualSeekSec += direc * self.VVrC0w()
    self.manualSeekSec = FF0CSz(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFF1Ee(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFD88e(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVKhoF(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VV5vqD())
   FFcghP(CFG.playerJumpMin, self.jumpMinutes)
  self.VVL7HF("Changed Seek Time to : %d%s" % (val, self.VVj4rx()))
 def VV5vqD(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVj4rx())
 def VVj4rx(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVoRtx(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVrC0w(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVic3F(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVjMnG(self):
  cList = self.VVDuST()
  if cList:
   VVv6X1 = []
   for pts, what in cList:
    txt = FFD88e(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVv6X1.append((txt, pts))
   FFLwVh(self, self.VVbLER, VVv6X1=VVv6X1, title="Cut List")
  else:
   self.VVL7HF("No Cut-List for this channel !")
 def VVbLER(self, item=None):
  if item:
   self.VVW7X8(item)
 def VVDuST(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVUHcq(self) : self.VVO6vD(1)
 def VVfd0s(self) : self.VVO6vD(-1)
 def VVO6vD(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVrC0w() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVoRtx())
    self.VVL7HF(txt)
  except:
   self.VVL7HF("Cannot jump")
 def VVW7X8(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVL7HF("Changing Time ...")
 def VV65q2(self):
  self.VVIwhm(1)
  self.VVL7HF("Replaying ...")
  self.VVn9Qz()
 def VVXIVr(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVL7HF("Jumping to end ...")
  except:
   pass
 def VVxrrU(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVJ4HD(self, isUp):
  if self.enableZapping:
   self.VVL7HF("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVn9Qz()
   if self.iptvTableParams:
    FFFO8C(BF(self.VVJx1r, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
    if "/timeshift/" in decodedUrl:
     self.VVL7HF("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVW63W()
  else:
   self.VVL7HF("Zap Disabled !")
 def VVW63W(self):
  self.lastPlayPos = 0
  self.VVWjfW()
  self.VVmBnr()
 def VVJx1r(self, isUp):
  CCCGrE_inatance, VVYo8S, mode = self.iptvTableParams
  if isUp : VVYo8S.VVKEm1()
  else : VVYo8S.VVDxbN()
  colList = VVYo8S.VVK0Ui()
  if mode == "localIptv":
   chName, chUrl = CCCGrE_inatance.VVwW9m(VVYo8S, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCCGrE_inatance.VV663c(VVYo8S, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCCGrE_inatance.VVgwhf(mode, VVYo8S, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCCGrE_inatance.VVVP2J(mode, VVYo8S, colList)
  else:
   self.VVL7HF("Cannot Zap")
   return
  FFTztI(self, chUrl, VVLjiH=False)
  self.VVW63W()
 def VVmBnr(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
   if not self.VVcORG(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVL7HF("Refreshing Portal")
   FFFO8C(self.VVdWqb)
  except:
   pass
 def VVdWqb(self):
  self.restoreLastPlayPos = self.VVw5aC()
 def VVWtPD(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
  if not decodedUrl or FF35eK(decodedUrl):
   self.VVL7HF("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCCGrE.VVs0VG(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVL7HF("Reading Program List ...")
   ok_fnc = BF(self.VVgJIG, refCode, chName, streamId, uHost, uUser, uPass)
   FFFO8C(BF(CCCGrE.VVjkog, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVL7HF("Cannot process this channel")
 def VVgJIG(self, refCode, chName, streamId, uHost, uUser, uPass, VVYo8S, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVYo8S.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVL7HF("Changing Program ...")
   FFFO8C(BF(self.VVgQhL, chUrl))
  else:
   self.VVL7HF("Incorrect Timestamp !")
 def VVgQhL(self, chUrl):
  FFTztI(self, chUrl, VVLjiH=False)
  self.lastPlayPos = 0
  self.VVWjfW()
 def VVVkrm(self, isAudio):
  try:
   VVY2Pt = InfoBar.instance
   if VVY2Pt:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVY2Pt)
    else  : self.session.open(SubtitleSelection, VVY2Pt)
  except:
   pass
 @staticmethod
 def VVlb6H(session, mode=None):
  if   mode == "close_sig"   : FF7oMJ(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCCGrE)
  elif mode == "close_openInFileMan" : session.open(CCOjzn, gotoMovie=True)
 @staticmethod
 def VVLNOL(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCSeoi.VVlb6H, session), CCSeoi, isFromExternal=isFromExternal, **kwargs)
class CCUwZ9(Screen):
 def __init__(self, session, title="", VVfTYp="Continue?", VVxoh5=True, VVaQmw=False):
  self.skin, self.skinParam = FFUxcO(VVO4Rs, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVfTYp = VVfTYp
  self.VVaQmw = VVaQmw
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVxoh5 : VVv6X1 = [no , yes]
  else   : VVv6X1 = [yes, no ]
  FFDBTO(self, title, VVv6X1=VVv6X1, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVsJp0 ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVfTYp)
  if self.VVaQmw:
   self["myLabel"].instance.setHAlign(0)
  self.VVTvSL()
  FFIpXz(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFW4LM(self["myMenu"])
  FFWRKG(self, self["myMenu"])
 def VVsJp0(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVTvSL(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC6eSf(Screen):
 def __init__(self, session, title="", VVv6X1=None, width=1000, height=850, VVcK4p=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVrX4i=None, VV3h4q=None, VVqSIC=None, VVxtuz=None, VVrAw7=False, VV8k4Z=False, yellowBasePath=None, VVyRL8="#22003344", VVmr0Y="#22002233"):
  self.skin, self.skinParam = FFUxcO(VVonST, width, height, 50, 40, 30, VVyRL8, VVmr0Y, VVcK4p, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVv6X1   = VVv6X1
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVrX4i   = VVrX4i
  self.VV3h4q  = VV3h4q
  self.VVqSIC  = ("Delete File", BF(self.VVM5sA, yellowBasePath)) if not yellowBasePath is None else VVqSIC
  self.VVxtuz   = VVxtuz
  self.VVrAw7  = VVrAw7
  self.VV8k4Z  = VV8k4Z
  self.Title    = title
  FFDBTO(self, title, VVv6X1=VVv6X1)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVsJp0    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVha6M   ,
   "red"  : self.VVktRn   ,
   "green"  : self.VVIy3I   ,
   "yellow" : self.VVj00B   ,
   "blue"  : self.VVp90r   ,
   "pageUp" : self.VVzSkC ,
   "chanUp" : self.VVzSkC ,
   "pageDown" : self.VVd7am  ,
   "chanDown" : self.VVd7am  ,
   "0"   : BF(self.VVAARY, 0) ,
   "1"   : BF(self.VVAARY, 1) ,
   "2"   : BF(self.VVAARY, 2) ,
   "3"   : BF(self.VVAARY, 3) ,
   "4"   : BF(self.VVAARY, 4) ,
   "5"   : BF(self.VVAARY, 5) ,
   "6"   : BF(self.VVAARY, 6) ,
   "7"   : BF(self.VVAARY, 7) ,
   "8"   : BF(self.VVAARY, 8) ,
   "9"   : BF(self.VVAARY, 9)
  }, -1)
  FFOeBX(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFIpXz(self["myMenu"])
  FFhukk(self, minRows=self.minRows)
  FFK8YM(self)
  self.VV5nUK(self["keyRed"]  , self.VVrX4i )
  self.VV5nUK(self["keyGreen"] , self.VV3h4q )
  self.VV5nUK(self["keyYellow"] , self.VVqSIC )
  self.VV5nUK(self["keyBlue"]  , self.VVxtuz )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFjMgg(self)
 def VV5nUK(self, btnObj, btnFnc):
  if btnFnc:
   FFjeeE(btnObj, btnFnc[0])
 def VVFggW(self, fnc=None):
  self.VV3h4q = fnc
  if fnc : self.VV5nUK(self["keyGreen"], self.VV3h4q)
  else : self["keyGreen"].hide()
 def VVAARY(self, digit):
  digit = str(digit)
  VVv6X1 = self["myMenu"].list
  for ndx, item in enumerate(VVv6X1):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFtomh(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVsnMy(ndx)
     self.VVsJp0()
     break
 def VVsJp0(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVrAw7: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVha6M(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVktRn(self)  : self.VVa7Ed(self.VVrX4i)
 def VVIy3I(self) : self.VVa7Ed(self.VV3h4q)
 def VVj00B(self) : self.VVa7Ed(self.VVqSIC)
 def VVp90r(self) : self.VVa7Ed(self.VVxtuz)
 def VVa7Ed(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV8k4Z:
    self.cancel()
 def VVsnMy(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVhLy9(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVv6X1 = self["myMenu"].list
  VVv6X1.pop(ndx)
  if len(VVv6X1) > 0: self["myMenu"].setList(VVv6X1)
  else    : self.close()
 def VVM5sA(self, basePath, menuObj, fName):
  FFWkqs(self, BF(self.VVISuZ, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVISuZ(self, path):
  FFsF1P(path)
  if fileExists(path) : FFfad8(self, "Not deleted", 1000)
  else    : self.VVhLy9()
 def VV6wAR(self, VVv6X1):
  if len(VVv6X1) > 0:
   newList = []
   for item in VVv6X1:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFhukk(self, minRows=self.minRows)
  else:
   self.close("")
 def VVDk4Z(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFhukk(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVthe5(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVzSkC(self) : self["myMenu"].moveToIndex(0)
 def VVd7am(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCJhfe(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVouKi=None, VVK4mA=None, VVw7oP=None, VVcK4p=26, VVWKtq=False, VVPhoH=0, VVXwx9=None, VVTMvN=None, VVtXvO=None, VV6vKb=None, VVPogp=None, VVxkVZ=None, VVCUH0=None, VVxKfW=None, VVgYq4=None, VVUkBS=-1, VVJevj=0, searchCol=0, lastFindConfigObj=None, VVyRL8=None, VVmr0Y=None, VVifff="#00dddddd", VVOSNp="#11002233", VV5fad="#00ff8833", VVuQjw="#11111111", VVVwZb="#0a555555", VVxG4z="#0affffff", VVU8z2="#11552200", VVc5so="#0055ff55"):
  self.skin, self.skinParam = FFUxcO(VVy6jt, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFDBTO(self, title)
  self.Title     = title
  self.header     = header
  self.VVouKi     = VVouKi
  self.totalCols    = len(VVouKi[0])
  self.VVPhoH   = VVPhoH
  self.lastSortModeIsReverese = False
  self.VVWKtq   = VVWKtq
  self.VVxFCp   = 0.01
  self.VVuV6g   = 0.02
  self.VVDBX4 = 0.03
  self.VVYVAD  = 1
  self.VVw7oP = VVw7oP
  self.colWidthPixels   = []
  self.VVXwx9   = VVXwx9
  self.OKButtonObj   = None
  self.VVTMvN   = VVTMvN
  self.VVtXvO   = VVtXvO
  self.VV6vKb   = VV6vKb
  self.VVPogp  = VVPogp
  self.VVxkVZ   = VVxkVZ
  self.VVCUH0    = VVCUH0
  self.VVxKfW   = VVxKfW
  self.tableRefreshCB   = None
  self.VVgYq4  = VVgYq4
  self.VVUkBS    = VVUkBS
  self.VVJevj   = VVJevj
  self.searchCol    = searchCol
  self.VVK4mA    = VVK4mA
  self.keyPressed    = -1
  self.VVcK4p    = FFjaaN(VVcK4p)
  self.VVv9gC    = FFewIR(self.VVcK4p, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVyRL8    = VVyRL8
  self.VVmr0Y      = VVmr0Y
  self.VVifff    = FFKd79(VVifff)
  self.VVOSNp    = FFKd79(VVOSNp)
  self.VV5fad    = FFKd79(VV5fad)
  self.VVuQjw    = FFKd79(VVuQjw)
  self.VVVwZb   = FFKd79(VVVwZb)
  self.VVxG4z    = FFKd79(VVxG4z)
  self.VVU8z2    = FFKd79(VVU8z2)
  self.VVc5so   = FFKd79(VVc5so)
  self.VVRSSP  = False
  self.selectedItems   = 0
  self.VV8ns8   = FFKd79("#01fefe01")
  self.VVrcrd   = FFKd79("#11400040")
  self.VVpd8d  = self.VV8ns8
  self.VV2OZm  = self.VVuQjw
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVJevj:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVJevj == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVXEe0  ,
   "red"  : self.VVH4kX  ,
   "green"  : self.VVoK4x ,
   "yellow" : self.VVlCgV ,
   "blue"  : self.VVPSvg  ,
   "menu"  : self.VVQWyi ,
   "info"  : self.VVgSL1  ,
   "cancel" : self.VVDjJy  ,
   "up"  : self.VVDxbN    ,
   "down"  : self.VVKEm1  ,
   "left"  : self.VVJZqu   ,
   "right"  : self.VVZjkk  ,
   "next"  : self.VVvuOT  ,
   "last"  : self.VVUJjn  ,
   "home"  : self.VVmkWo  ,
   "pageUp" : self.VVmkWo  ,
   "chanUp" : self.VVmkWo  ,
   "end"  : self.VVVLgx  ,
   "pageDown" : self.VVVLgx  ,
   "chanDown" : self.VVVLgx
  }, -1)
  FFOeBX(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  try:
   self.VVemsj()
  except Exception as e:
   FFRGBb(self, str(e), title=self.Title)
   self.close(None)
 def VVemsj(self):
  FFjMgg(self)
  if self.VVyRL8:
   FF2A0B(self["myTitle"], self.VVyRL8)
  if self.VVmr0Y:
   FF2A0B(self["myBody"] , self.VVmr0Y)
   FF2A0B(self["myTableH"] , self.VVmr0Y)
   FF2A0B(self["myTable"] , self.VVmr0Y)
   FF2A0B(self["myBar"]  , self.VVmr0Y)
  self.VV5nUK(self.VVtXvO  , self["keyRed"])
  self.VV5nUK(self.VV6vKb  , self["keyGreen"])
  self.VV5nUK(self.VVPogp , self["keyYellow"])
  self.VV5nUK(self.VVxkVZ  , self["keyBlue"])
  if self.VVXwx9:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVXwx9[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVXwx9[0])
    FF2A0B(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVv9gC)
  self["myTableH"].l.setFont(0, gFont(VVRQSa, self.VVcK4p))
  self["myTable"].l.setItemHeight(self.VVv9gC)
  self["myTable"].l.setFont(0, gFont(VVRQSa, self.VVcK4p))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVv9gC)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVv9gC))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVv9gC)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVv9gC
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVv9gC * len(self.VVouKi) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVw7oP:
   self.VVw7oP = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVw7oP)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVK4mA:
   self.VVK4mA = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVK4mA
   self.VVK4mA = []
   for item in tmpList:
    self.VVK4mA.append(item | RT_VALIGN_CENTER)
  self.VVLpNK()
  if self.VVCUH0:
   self.VVCUH0(self)
 def VV5nUK(self, btnFnc, btn):
  if btnFnc : FFjeeE(btn, btnFnc[0])
  else  : FFjeeE(btn, "")
 def VVyX5T(self, waitTxt):
  FF0rXP(self, self.VVLpNK, title=waitTxt)
 def VVLpNK(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VV5Htu(0, self.header, self.VVxG4z, self.VVU8z2, self.VVxG4z, self.VVU8z2, self.VVc5so)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVouKi):
    self["myTable"].list.append(self.VV5Htu(c, row, self.VVifff, self.VVOSNp, self.VV5fad, self.VVuQjw, None))
   self.VVouKi = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVUkBS > -1:
    self["myTable"].moveToIndex(self.VVUkBS )
   self.VVZH6J()
   if self.VVJevj:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVv9gC * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFrVM8(self, width, newH)
   if self.VVxKfW:
    self.VVa7Ed(self.VVxKfW, None)
   if self.tableRefreshCB:
    self.VVa7Ed(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFRGBb(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VV5Htu(self, keyIndex, columns, VVifff, VVOSNp, VV5fad, VVuQjw, VVc5so):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVc5so and ndx == self.VVPhoH : textColor = VVc5so
   else           : textColor = VVifff
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFKd79(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVOSNp = c
    entry = span.group(3)
   if self.VVK4mA[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVv9gC)
           , font   = 0
           , flags   = self.VVK4mA[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVOSNp
           , color_sel  = VV5fad
           , backcolor_sel = VVuQjw
           , border_width = 1
           , border_color = self.VVVwZb
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVgSL1(self):
  rowData = self.VVzFmL()
  if rowData:
   title, txt, colList = rowData
   if self.VVTMvN:
    fnc  = self.VVTMvN[1]
    params = self.VVTMvN[2]
    fnc(self, title, txt, colList)
   else:
    FFipfq(self, txt, title)
 def VVXEe0(self):
  if   self.VVRSSP : self.VVgQQE(self.VVjpse(), mode=2)
  elif self.VVXwx9  : self.VVa7Ed(self.VVXwx9, None)
  else      : self.VVgSL1()
 def VVH4kX(self) : self.VVa7Ed(self.VVtXvO , self["keyRed"])
 def VVoK4x(self) : self.VVa7Ed(self.VV6vKb , self["keyGreen"])
 def VVlCgV(self): self.VVa7Ed(self.VVPogp , self["keyYellow"])
 def VVPSvg(self) : self.VVa7Ed(self.VVxkVZ , self["keyBlue"])
 def VVa7Ed(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFfad8(self, buttonFnc[3])
    FFFO8C(BF(self.VVmgLb, buttonFnc))
   else:
    self.VVmgLb(buttonFnc)
 def VVmgLb(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVzFmL()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVgQQE(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VV8ns8
   newRow = self.VVK0Ui()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV5Htu(ndx, newRow, self.VVifff, self.VVOSNp, self.VV5fad, self.VVuQjw, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV5Htu(ndx, newRow, self.VV8ns8, self.VVrcrd, self.VVpd8d, self.VV2OZm, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVjpse() < len(self["myTable"].list) - 1:
    self.VVKEm1()
   else:
    self.VVZH6J()
 def VVMrk8(self)  : FF0rXP(self, BF(self.VVcwAI, True ), title="Selecting all ..."  )
 def VVO0Vn(self) : FF0rXP(self, BF(self.VVcwAI, False), title="Unselecting all ...")
 def VVcwAI(self, isSel=True):
  if isSel:
   fg, bg = self.VV8ns8, self.VVrcrd
   self.selectedItems = len(self["myTable"].list)
   self.VVw9l3(True)
  else:
   fg, bg = self.VVifff, self.VVOSNp
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VV8ns8
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVzFmL(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVw7oP[i] > 1 or self.VVw7oP[i] == self.VVxFCp or self.VVw7oP[i] == self.VVDBX4:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVDjJy(self):
  if self.VVgYq4 : self.VVgYq4(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVjAQ8(self):
  return self["myTitle"].getText().strip()
 def VVe3lP(self):
  return self.header
 def VV7nKt(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVx1Wv(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFqst5(self["myBar"], color)
 def VVhzMj(self, txt):
  FFfad8(self, txt)
 def VVu9dh(self, txt, Time=1000):
  FFfad8(self, txt, Time)
 def VV9NIW(self): self["keyGreen"].show()
 def VVRcVH(self): self["keyGreen"].hide()
 def VVtep6(self): return self["keyGreen"].visible
 def VVxwMk(self):
  FFfad8(self)
 def VVDhZV(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVzMwz(self):
  return len(self["myTable"].list)
 def VVjpse(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVDPuF(self):
  return len(self["myTable"].list)
 def VVw9l3(self, isOn):
  self.VVRSSP = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVxkVZ: self["keyBlue"].hide()
   if self.VVXwx9 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVxkVZ: self["keyBlue"].show()
   if self.VVXwx9 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVXwx9[0])
   self.VVO0Vn()
  FF2A0B(self["myTitle"], color)
  FF2A0B(self["myBar"]  , color)
 def VVlPxr(self):
  return self.VVRSSP
 def VVTK0J(self):
  return self.selectedItems
 def VVBeNQ(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVZH6J()
 def VVqMmu(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV9V4s(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVzMwz()
  txt += FFb8P2("Total Unique Items", VVqskC)
  for i in range(self.totalCols):
   if self.VVw7oP[i - 1] > 1 or self.VVw7oP[i - 1] == self.VVxFCp or self.VVw7oP[i - 1] == self.VVDBX4:
    name, tot = self.VVqMmu(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFipfq(self, txt)
 def VVN3DQ(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVK0Ui(self):
  return self.VVYyZ7(self["myTable"].l.getCurrentSelectionIndex())
 def VVYyZ7(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVPCrn(self, newList, newTitle="", VVokSrMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VV7nKt(newTitle)
  if newList:
   self.VVouKi = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVWKtq and self.VVPhoH == 0:
    isNum = True
   else:
    for cols in self.VVouKi:
     if not FFwmlV(cols[self.VVPhoH]): break
    else:
     isNum = True
   if isNum: self.VVouKi.sort(key=lambda x: int(x[self.VVPhoH])  , reverse=self.lastSortModeIsReverese)
   else : self.VVouKi.sort(key=lambda x: x[self.VVPhoH].lower() , reverse=self.lastSortModeIsReverese)
   if VVokSrMsg : self.VVyX5T("Refreshing ...")
   else   : self.VVLpNK()
  else:
   FFRGBb(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVrN9N(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VV5Htu(self.VVDPuF(), row, self.VVifff, self.VVOSNp, self.VV5fad, self.VVuQjw, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVVLgx()
 def VVtGy5(self):
  self["myTable"].list.pop(self.VVjpse())
  self["myTable"].l.setList(self["myTable"].list)
 def VVfm3U(self, data):
  ndx = self.VVjpse()
  newRow = self.VV5Htu(ndx, data, self.VVifff, self.VVOSNp, self.VV5fad, self.VVuQjw, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVZH6J()
   return True
  else:
   return False
 def VVLdUA(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VV5Htu(ndx, data, self.VVifff, self.VVOSNp, self.VV5fad, self.VVuQjw, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVwkHD()
 def VVwkHD(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVUlfa(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVFzdA(self, colNum, textToFind, VVy0Oi=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVZH6J()
    break
  else:
   if VVy0Oi:
    FFfad8(self, "Not found", 1000)
 def VVawPk(self, colDict, VVy0Oi=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVZH6J()
    return
  if VVy0Oi:
   FFfad8(self, "Not found", 1000)
 def VVZj7I(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVqNzs(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFwmlV(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVZ4YI(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV8ns8:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV0zSO(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VV8ns8:
     return ndx
  return -1
 def VVEFwV(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV8ns8:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VV3b3Q(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VV8ns8: return True
  else        : return False
 def VVl6T3(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVQWyi(self):
  if not self["keyMenu"].getVisible() or self.VVJevj:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVjpse()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVv6X11, VVDExR = CCFC3v.VVVzEQ(self, False, False)
  VVv6X1 = []
  VVv6X1.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVv6X1.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVv6X1.append(("Find ...\t\t%s" % (FFf1xo(txt, VV0HRz) if txt else ""), "findNew"   ))
  VVv6X1.append(itemOf(bool(VVv6X11)    , "Find (from Filter) ..."   , "filter"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Table Statistcis"             , "tableStat"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((FFf1xo("Export Table to .html"     , VVqskC) , "VVEBV2" ))
  VVv6X1.append((FFf1xo("Export Table to .csv"     , VVqskC) , "VVM7Ek" ))
  VVv6X1.append((FFf1xo("Export Table to .txt (Tab Separated)", VVqskC) , "VV6Xfz" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVw7oP[i] > 1 or self.VVw7oP[i] == self.VVuV6g:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVv6X1.append(VVdKVg)
   if tot == 1 : VVv6X1.append(("Sort", sList[0][1]))
   else  : VVv6X1 += sList
  VVxtuz = ("Keys Help", self.FFl3hsHelp)
  FFLwVh(self, self.VVCv0H, VVv6X1=VVv6X1, title=self.VVjAQ8(), VVxtuz=VVxtuz)
 def VVCv0H(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VV9Csb()
   elif item == "findPrev"  : self.VV9Csb(isPrev=True)
   elif item == "findNew"  : self.VVdFng()
   elif item == "filter"  : self.VVyVHc()
   elif item == "tableStat" : self.VV9V4s()
   elif item == "VVEBV2": FF0rXP(self, self.VVEBV2, title=title)
   elif item == "VVM7Ek" : FF0rXP(self, self.VVM7Ek , title=title)
   elif item == "VV6Xfz" : FF0rXP(self, self.VV6Xfz , title=title)
   else:
    self.lastSortModeIsReverese = False
    if self.VVPhoH == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVPhoH = item
    if self.VVWKtq and self.VVPhoH == 0 or self.VVqNzs(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVLpNK(onlyHeader=True)
 def FFl3hsHelp(self, menuInstance, path):
  FFAqgP(self, "_help_table", "Table (Keys Help)")
 def VVDxbN(self):
  self["myTable"].up()
  self.VVZH6J()
 def VVKEm1(self):
  self["myTable"].down()
  self.VVZH6J()
 def VVJZqu(self):
  self["myTable"].pageUp()
  self.VVZH6J()
 def VVZjkk(self):
  self["myTable"].pageDown()
  self.VVZH6J()
 def VVmkWo(self):
  self["myTable"].moveToIndex(0)
  self.VVZH6J()
 def VVVLgx(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVZH6J()
 def VVG9tX(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVZH6J()
 def VVvuOT(self):
  if self.lastFindConfigObj.getValue():
   if self.VVjpse() == len(self["myTable"].list) - 1 : FFfad8(self, "End reached", 1000)
   else              : self.VV9Csb()
  else:
   FFfad8(self, 'Set "Find" in Menu', 1500)
 def VVUJjn(self):
  if self.lastFindConfigObj.getValue():
   if self.VVjpse() == 0 : FFfad8(self, "Top reached", 1000)
   else       : self.VV9Csb(isPrev=True)
  else:
   FFfad8(self, 'Set "Find" in Menu', 1500)
 def VV9Pu4(self, txt):
  FFcghP(self.lastFindConfigObj, txt)
 def VVdFng(self):
  FFufG1(self, self.VVq86t, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVq86t(self, VVGZ8H):
  if not VVGZ8H is None:
   txt = VVGZ8H.strip()
   self.VV9Pu4(txt)
   if VVGZ8H: self.VV9Csb(reset=True)
   else  : FFfad8(self, "Nothing to find !", 1500)
 def VVyVHc(self):
  VVv6X1, VVDExR = CCFC3v.VVVzEQ(self, False, False)
  VVqSIC = ("Edit Filter", BF(self.VVRpJ5, VVDExR))
  if VVv6X1 : FFLwVh(self, self.VV8xOY, VVv6X1=VVv6X1, VVqSIC=VVqSIC, title="Find from Filter")
  else  : FFfad8(self, "Filter Error !", 1500)
 def VV8xOY(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VV9Pu4(txt)
    self.VV9Csb(reset=True)
   else:
    FFfad8(self, "No entry !", 1500)
 def VVRpJ5(self, VVDExR, VVLmuPObj, sel):
  if fileExists(VVDExR) : CCyIuf(self, VVDExR, VVkuAk=None)
  else       : FFZBzs(self, VVDExR)
  VVLmuPObj.cancel()
 def VV9Csb(self, reset=False, isPrev=False):
  curRow = self.VVjpse()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCFC3v.VVXFHp(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVG9tX(i)
      break
    elif any(x in line for x in tupl):
     self.VVG9tX(i)
     break
   else:
    FFfad8(self, "Not found", 1000)
  else:
   FFfad8(self, "Check your query", 1500)
 def VV6Xfz(self):
  expFile = self.VVRdMS() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV7l1l()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVYyZ7(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVw7oP[ndx] > self.VVYVAD or self.VVw7oP[ndx] == self.VVDBX4:
      col = self.VVHGRz(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVqBBA(expFile)
 def VVM7Ek(self):
  expFile = self.VVRdMS() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV7l1l()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVYyZ7(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVw7oP[ndx] > self.VVYVAD or self.VVw7oP[ndx] == self.VVDBX4:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVHGRz(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVqBBA(expFile)
 def VVEBV2(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVjAQ8(), PLUGIN_NAME, VVGsPD)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVjAQ8()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV7l1l()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVw7oP:
   colgroup += '   <colgroup>'
   for w in self.VVw7oP:
    if w > self.VVYVAD or w == self.VVDBX4:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVRdMS() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVYyZ7(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVw7oP[ndx] > self.VVYVAD or self.VVw7oP[ndx] == self.VVDBX4:
      col = self.VVHGRz(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVqBBA(expFile)
 def VV7l1l(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVw7oP[ndx] > self.VVYVAD or self.VVw7oP[ndx] == self.VVDBX4:
     newRow.append(col.strip())
  return newRow
 def VVHGRz(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFtomh(col)
 def VVRdMS(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVjAQ8())
  fileName = fileName.replace("__", "_")
  path  = FFiSR4(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFWWBu()
  return expFile
 def VVqBBA(self, expFile):
  FFrNpu(self, "File exported to:\n\n%s" % expFile, title=self.VVjAQ8())
 def VVZH6J(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCe2gv():
 def __init__(self, pixmapObj, picPath, VVOSNp=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVOSNp  = VVOSNp or "#2200002a"
 def VVgPWn(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVXErM)
    except:
     self.picLoad.PictureData.get().append(self.VVXErM)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVOSNp])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVXErM(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVFeYy(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVmA3G(pixmapObj, path, VVOSNp=None):
  cl = CCe2gv(pixmapObj, path, VVOSNp)
  ok = cl.VVgPWn()
  if ok: return cl
  else : return None
class CCXjSu(Screen):
 def __init__(self, session, title="", VV8Zdd=None, showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  scrW, scrH = FFEnkn()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFUxcO(VVaujM, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VV8Zdd = VV8Zdd
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFDBTO(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVp9Ij  ,
   "up" : BF(self.VV7Dbw, -1),
   "down" : BF(self.VV7Dbw,  1),
   "left" : BF(self.VV7Dbw, -1),
   "right" : BF(self.VV7Dbw,  1)
  }, -1)
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  self.VVuEQc()
  self.picViewer = CCe2gv.VVmA3G(self["myPic"], self.VV8Zdd)
  if self.picViewer:
   if self.showGrnMsg:
    FFfad8(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFRGBb(self, "Cannot view picture file:\n\n%s" % self.VV8Zdd)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVFeYy()
  if self.cbFnc: self.cbFnc(self.VV8Zdd)
 def VV7Dbw(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VV8Zdd = FFiSR4(os.path.dirname(self.VV8Zdd)) + fName
    self.picViewer.picPath = self.VV8Zdd
    self.picViewer.VVgPWn()
    self.VVuEQc()
 def VVp9Ij(self):
  txt = "%s:\n  %s" % (FFf1xo("Path", VVKiZJ), self.VV8Zdd)
  size, sizeTxt, resTxt, form, mode = CCtNnf.VVU2CH(self.VV8Zdd)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFf1xo("Properties", VVKiZJ)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFipfq(self, txt, title="File Information")
 def VVuEQc(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VV8Zdd)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVTYNz(SELF, VV8Zdd, title="", showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  SELF.session.open(BF(CCXjSu, title=title, VV8Zdd=VV8Zdd, showGrnMsg=showGrnMsg, fileList=fileList, curIndex=curIndex, cbFnc=cbFnc))
class CCBQez(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFUxcO(VVB9B6, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFDBTO(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.onExit)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFWqNF("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVvVDy(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCBQez.VVKMGV, SELF), CCBQez, mviFile)
 @staticmethod
 def VVKMGV(SELF, reason=None):
  if reason == -1: FFRGBb(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCLmoH(Screen, ConfigListScreen):
 VVzrG7 = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VV8dFn, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFDBTO(self, title=self.Title)
  FFjeeE(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry(VVT41S *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVT41S *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVT41S *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVk1ia()
  self.onShown.append(self.VVzGCv)
 def VVk1ia(self):
  kList = {
    "ok" : self.VVsJp0   ,
    "green" : self.VVFCy6 ,
    "menu" : self.VVMdyH ,
    "cancel": self.VVuXk7 ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVHdl7, 0)
     kList["chanDown"] = BF(self["config"].VVHdl7, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFK8YM(self)
  FFIpXz(self["config"])
  FFhukk(self, self["config"])
  FFjMgg(self)
  self["config"].onSelectionChanged.append(self.VV9Wzy)
  FF2A0B(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VV9Wzy()
 def VV9Wzy(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVsJp0(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVBV6z()
   elif item == CFG.MovieDownloadPath   : self.VVIPO1(item, self["config"].getCurrent()[0])
   elif isinstance(item, ConfigDirectory) : self.VVa0mq(item)
   else         : CCLmoH.VVgq2y(self, item, title)
 @staticmethod
 def VVgq2y(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVv6X1 = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVT41S)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VV0HRz + txt
    elif val == confItem.default: defNdx, txt = ndx, VVy4op + txt
   VVv6X1.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVxtuz  = ("Current", BF(CCLmoH.VVyiuX, curNdx))
  VVqSIC = ("Default", BF(CCLmoH.VVyiuX, defNdx))
  menuInstance = FFLwVh(SELF, BF(CCLmoH.VVGfH2, confItem, cbFnc), VVv6X1=VVv6X1, width=1200, VVqSIC=VVqSIC, VVxtuz=VVxtuz, title=title, VVyRL8="#33221111", VVmr0Y="#33110011")
  menuInstance.VVsnMy(curNdx)
 @staticmethod
 def VVGfH2(confItem, cbFnc, item=None):
  if not item is None:
   FFcghP(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVyiuX(ndx, VVLmuPObj, item):
  VVLmuPObj.VVsnMy(ndx)
 @staticmethod
 def VVsent(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVIPO1(self, item, title):
  tot = CCNUxQ.VVwRUz()
  if tot : FFRGBb(self, "Cannot change while downloading.", title=title)
  else : self.VVa0mq(item)
 def VVBV6z(self):
  VVv6X1 = []
  VVv6X1.append(("Auto Find" , "auto"))
  VVv6X1.append(("Custom Path" , "cust"))
  FFLwVh(self, self.VVkff4, VVv6X1=VVv6X1, title="IPTV Hosts Files Path")
 def VVkff4(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVAg8j)
   elif item == "cust":
    VV4Gbf = self.VVaY03()
    if VV4Gbf : self.VVdKLa(VV4Gbf)
    else  : self.session.openWithCallback(self.VVdlky, BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG="/"))
 def VVdKLa(self, VV4Gbf):
  VVgYq4 = self.VVszTY
  VVtXvO = ("Remove"  , self.VVopeD , [])
  VVPogp = ("Add "  , self.VVDHkz, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVK4mA  = (LEFT   , LEFT  )
  FFl3hs(self, None, title="IPTV Hosts Search Paths", header=header, VVouKi=VV4Gbf, width=1200, height=700, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=26, VVgYq4=VVgYq4, VVtXvO=VVtXvO, VVPogp=VVPogp
    , VVyRL8="#11220000", VVmr0Y="#11110000", VVOSNp="#11110011", VV5fad="#00ffff00", VVuQjw="#00223025", VVVwZb="#0a333333", VVU8z2="#0a400040")
 def VVszTY(self, VVYo8S):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VV2g07)
  VVYo8S.cancel()
 def VVdlky(self, path):
  if path:
   FFcghP(CFG.iptvHostsDirs, FFiSR4(path.strip()))
   VV4Gbf = self.VVaY03()
   if VV4Gbf : self.VVdKLa(VV4Gbf)
   else  : FFfad8(self, "Cannot add dir", 1500)
 def VVUFhH(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVAg8j:
   return []
  return lst
 def VVaY03(self):
  lst = self.VVUFhH()
  if lst:
   VV4Gbf = []
   for Dir in lst:
    VV4Gbf.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VV4Gbf.sort(key=lambda x: x[0].lower())
   return VV4Gbf
  else:
   return []
 def VVDHkz(self, VVYo8S, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VV8Hdp, VVYo8S)
         , BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG=sDir))
 def VV8Hdp(self, VVYo8S, path):
  if path:
   path = FFiSR4(path.strip())
   if self.VVRult(VVYo8S, path):
    FFfad8(VVYo8S, "Already added", 1500)
   else:
    lst = self.VVUFhH()
    lst.append(path)
    FFcghP(CFG.iptvHostsDirs, ",".join(lst))
    VV4Gbf = self.VVaY03()
    VVYo8S.VVPCrn(VV4Gbf, tableRefreshCB=BF(self.VVcXLm, path))
 def VVcXLm(self, path, VVYo8S, title, txt, colList):
  self.VVRult(VVYo8S, path)
 def VVRult(self, VVYo8S, path):
  for ndx, row in enumerate(VVYo8S.VVl6T3()):
   if row[0].strip() == path.strip():
    VVYo8S.VVG9tX(ndx)
    return True
  return False
 def VVopeD(self, VVYo8S, title, txt, colList):
  path = colList[0]
  FFWkqs(self, BF(self.VVFLlr, VVYo8S), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVFLlr(self, VVYo8S):
  row = VVYo8S.VVK0Ui()
  path, rem = row[0], row[1]
  VV4Gbf = []
  lst = []
  for ndx, row in enumerate(VVYo8S.VVl6T3()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VV4Gbf.append((tPath, tRem))
  if len(VV4Gbf) > 0:
   FFcghP(CFG.iptvHostsDirs, ",".join(lst))
   VVYo8S.VVPCrn(VV4Gbf)
   FFfad8(VVYo8S, "Deleted", 1500)
  else:
   FFcghP(CFG.iptvHostsMode, VVAg8j)
   FFcghP(CFG.iptvHostsDirs, "")
   VVYo8S.cancel()
   FFFO8C(BF(FFfad8, self, "Changed to Auto-Find", 1500))
 def VVa0mq(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVMEOv, configObj)
         , BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG=sDir))
 def VVMEOv(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVuXk7(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFWkqs(self, self.VVFCy6, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVFCy6(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV64cS()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVMdyH(self):
  VVv6X1 = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVv6X1.append((txt    , "VV9BEg"   ))
  else        : VVv6X1.append((txt    ,       ))
  VVv6X1.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Reset %s Settings" % PLUGIN_NAME      , "VVgCco"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Backup %s Settings" % PLUGIN_NAME      , "VVhjKX"  ))
  VVv6X1.append(("Restore %s Settings" % PLUGIN_NAME     , "VVlPac"  ))
  if fileExists(VVsoKC + CCLmoH.VVzrG7):
   VVv6X1.append(VVdKVg)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVv6X1.append(('%s Checking for Update' % txt1     , txt2     ))
   VVv6X1.append(("Reinstall %s" % PLUGIN_NAME      , "VVo0T6"  ))
   VVv6X1.append(("Update %s" % PLUGIN_NAME      , "VVy5Wo"   ))
  FFLwVh(self, self.VVKjbw, VVv6X1=VVv6X1, title="Config. Options")
 def VVKjbw(self, item=None):
  if item:
   if   item == "VV9BEg"  : FFWkqs(self, self.VV9BEg , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCZV4T)
   elif item == "VVgCco"  : FFWkqs(self, BF(self.VVgCco, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVhjKX" : self.VVhjKX()
   elif item == "VVlPac" : FF0rXP(self, self.VVlPac, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFcghP(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFcghP(CFG.checkForUpdateAtStartup, False)
   elif item == "VVo0T6" : FF0rXP(self, self.VVo0T6 , "Checking Server ...")
   elif item == "VVy5Wo"  : FF0rXP(self, self.VVy5Wo  , "Checking Server ...")
 def VVhjKX(self):
  path = "%sajpanel_settings_%s" % (VVsoKC, FFWWBu())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVxlEW, path))
  FFrNpu(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVlPac(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFqfZV("find / %s -iname '%s*' | grep %s" % (FFpy4F(1), name, name))
  if files:
   for line in files:
    if not fileExists(line):
     FFWkqs(self, BF(self.VV6xSm, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
     break
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVv6X1 = []
    for line in files:
     VVv6X1.append((line, line))
    FFLwVh(self, BF(self.VV6Vku, title), title=title, VVv6X1=VVv6X1, width=1200, yellowBasePath="")
  else:
   FFRGBb(self, "No settings files found !", title=title)
 def VV6xSm(self, title, path=None):
  sDir = "/"
  for path in (VVsoKC, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VV6Vku, title), BF(CCOjzn, patternMode="ajpSet", VVOgpG=sDir))
 def VV6Vku(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFRtPk(path)
    self.VVgCco()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VV64cS()
    FFI9nQ()
    FFfad8(self, "Apllied", 1500, isGrn=True)
   else:
    FFZBzs(self, path, title=title)
 def VV9BEg(self):
  newPath = FFiSR4(VVsoKC)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV64cS()
 @staticmethod
 def VV6bvJ():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVgCco(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV64cS()
  if exit:
   self.close()
 def VV64cS(self):
  configfile.save()
  global VVsoKC
  VVsoKC = CFG.backupPath.getValue()
  FFfuTq()
 def VVy5Wo(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV4spl(title)
  if webVer:
   FFWkqs(self, BF(FF0rXP, self, BF(self.VVFiDl, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVo0T6(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV4spl(title, True)
  if webVer:
   FFWkqs(self, BF(FF0rXP, self, BF(self.VVFiDl, webVer, title, True)), "Install and Restart ?", title=title)
 def VVFiDl(self, webVer, title, isReinst=False):
  url = self.VVY3Pv(self, title)
  if url:
   VVQr59 = FF6lF9() == "dpkg"
   if VVQr59 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVQr59 else "ipk")
   path, err = FFn4Tu(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFohUm(VVaj7G, path)
    else  : cmd = FFohUm(VVTIdG, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FF8ZtC(self, cmd)
    else:
     FF2yhz(self, title=title)
   else:
    FFRGBb(self, err, title=title)
 def VV4spl(self, title, anyVer=False):
  url = self.VVY3Pv(self, title)
  if not url:
   return ""
  path, err = FFn4Tu(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFRGBb(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFUKzq(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFRGBb(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVGsPD.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFqfZV(cmd)
   if list and curVer == list[0]:
    return webVer
  FFrNpu(self, FFf1xo("No update required.", VVvsR7) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVY3Pv(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVsoKC + CCLmoH.VVzrG7
  if fileExists(path):
   span = iSearch(r"(http.+)", FFUKzq(path), IGNORECASE)
   if span : url = FFiSR4(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFRGBb(SELF, err, title)
  return url
 @staticmethod
 def VVIiuY(url):
  path, err = FFn4Tu(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFUKzq(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVGsPD.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFqfZV(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCZV4T(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VVmB4e, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFDBTO(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVE66X("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVE66X("\c00888888", i) + sp + "GREY\n"
   txt += self.VVE66X("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVE66X("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVE66X("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVE66X("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVE66X("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVE66X("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVE66X("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVE66X("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVE66X("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVE66X("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVsJp0 ,
   "green" : self.VVsJp0 ,
   "left" : self.VVJXQv ,
   "right" : self.VV54hN ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  self.VVSylV()
 def VVsJp0(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFWkqs(self, self.VVfOcI, "Change to : %s" % txt, title=self.Title)
 def VVfOcI(self):
  FFcghP(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVgnGv()
  self.close()
 def VVJXQv(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVSylV()
 def VV54hN(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVSylV()
 def VVSylV(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVE66X(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVPzaV(color):
  if VVy4op: return "\\" + color
  else    : return ""
 @staticmethod
 def VVgnGv():
  global VVpLjr, VVe79W, VVL1qM, VV8tcv, VVqskC, VVityU, VVQZ69, VVacyG, VVvsR7, VVkC8X, VVy4op, VVKiZJ, VV0HRz, VVq8cV, VVRgTn, VVH2yZ
  VVH2yZ   = CCZV4T.VVE66X("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVe79W    = CCZV4T.VVE66X("\c00888888", COLOR_SCHEME_NUM)
  VVpLjr  = CCZV4T.VVE66X("\c005A5A5A", COLOR_SCHEME_NUM)
  VVacyG    = CCZV4T.VVE66X("\c00FF0000", COLOR_SCHEME_NUM)
  VVL1qM   = CCZV4T.VVE66X("\c00FF5000", COLOR_SCHEME_NUM)
  VV8tcv   = CCZV4T.VVE66X("\c00FFBB66", COLOR_SCHEME_NUM)
  VVy4op   = CCZV4T.VVE66X("\c00FFFF00", COLOR_SCHEME_NUM)
  VVKiZJ = CCZV4T.VVE66X("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVvsR7   = CCZV4T.VVE66X("\c0000FF00", COLOR_SCHEME_NUM)
  VVkC8X  = CCZV4T.VVE66X("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVQZ69    = CCZV4T.VVE66X("\c000066FF", COLOR_SCHEME_NUM)
  VV0HRz    = CCZV4T.VVE66X("\c0000FFFF", COLOR_SCHEME_NUM)
  VVq8cV  = CCZV4T.VVE66X("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVRgTn   = CCZV4T.VVE66X("\c00FA55E7", COLOR_SCHEME_NUM)
  VVqskC    = CCZV4T.VVE66X("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVityU  = CCZV4T.VVE66X("\c00FFC0C0", COLOR_SCHEME_NUM)
CCZV4T.VVgnGv()
class CC5Nh4(Screen):
 def __init__(self, session, path, VVQr59):
  self.skin, self.skinParam = FFUxcO(VVxJQK, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVOsKZ   = path
  self.VVMvz0   = ""
  self.VVEwIl   = ""
  self.VVQr59    = VVQr59
  self.VVRGjW    = ""
  self.VVIn8a  = ""
  self.VVpDFv    = False
  self.VVrPNE  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVTIFQ  = "enigma2-plugin-extensions-"
  self.VV6CKo  = "enigma2-plugin-systemplugins-"
  self.VVRGCL = "enigma2-"
  self.VVcJHt  = 0
  self.VVnUvc  = 1
  self.VVs4YO  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVWXRj = "DEBIAN"
  else        : self.VVWXRj = "CONTROL"
  self.controlPath = self.Path + self.VVWXRj
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVQr59:
   self.packageExt  = ".deb"
   self.VVOSNp  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVOSNp  = "#11001020"
  FFDBTO(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFjeeE(self["keyRed"] , "Create")
  FFjeeE(self["keyGreen"] , "Post Install")
  FFjeeE(self["keyYellow"], "Installation Path")
  FFjeeE(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVC9lU  ,
   "green"   : self.VV6bAp ,
   "yellow"  : self.VVeLW3  ,
   "blue"   : self.VVRbnC  ,
   "cancel"  : self.VV12yc
  }, -1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFjMgg(self)
  if self.VVOSNp:
   FF2A0B(self["myBody"], self.VVOSNp)
   FF2A0B(self["myLabel"], self.VVOSNp)
  self.VV0lYk(True)
  self.VV8Q7r(True)
 def VV8Q7r(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV1DNi()
  if isFirstTime:
   if   package.startswith(self.VVTIFQ) : self.VVOsKZ = VVUsb0 + self.VVRGjW + "/"
   elif package.startswith(self.VV6CKo) : self.VVOsKZ = VVBqIe + self.VVRGjW + "/"
   else            : self.VVOsKZ = self.Path
  if self.VVpDFv : myColor = VVqskC
  else    : myColor = VVH2yZ
  txt  = ""
  txt += "Source Path\t: %s\n" % FFf1xo(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFf1xo(self.VVOsKZ, VVy4op)
  if self.VVEwIl : txt += "Package File\t: %s\n" % FFf1xo(self.VVEwIl, VVe79W)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFf1xo("Check Control File fields : %s" % errTxt, VVL1qM)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFf1xo("Restart GUI", VVqskC)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFf1xo("Reboot Device", VVqskC)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFf1xo("Post Install", VVvsR7), act)
  if not errTxt and VVL1qM in controlInfo:
   txt += "Warning\t: %s\n" % FFf1xo("Errors in control file may affect the result package.", VVL1qM)
  txt += "\nControl File\t: %s\n" % FFf1xo(self.controlFile, VVe79W)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV6bAp(self):
  if self["keyGreen"].getVisible():
   VVv6X1 = []
   VVv6X1.append(("No Action"    , "noAction"  ))
   VVv6X1.append(("Restart GUI"    , "VVZ5tc"  ))
   VVv6X1.append(("Reboot Device"   , "rebootDev"  ))
   FFLwVh(self, self.VVC3eD, title="Package Installation Option (after completing installation)", VVv6X1=VVv6X1)
 def VVC3eD(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVZ5tc"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV0lYk(False)
   self.VV8Q7r()
 def VVeLW3(self):
  rootPath = FFf1xo("/%s/" % self.VVRGjW, VVKiZJ)
  VVv6X1 = []
  VVv6X1.append(("Current Path"        , "toCurrent"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Extension Path"       , "toExtensions" ))
  VVv6X1.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVv6X1.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFLwVh(self, self.VVIJuU, title="Installation Path", VVv6X1=VVv6X1)
 def VVIJuU(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVvIHs(FFEP6Z(self.Path, True))
   elif item == "toExtensions"  : self.VVvIHs(VVUsb0)
   elif item == "toSystemPlugins" : self.VVvIHs(VVBqIe)
   elif item == "toRootPath"  : self.VVvIHs("/")
   elif item == "toRoot"   : self.VVvIHs("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVIUQD, BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG=VVsoKC))
 def VVIUQD(self, path):
  if len(path) > 0:
   self.VVvIHs(path)
 def VVvIHs(self, parent, withPackageName=True):
  if withPackageName : self.VVOsKZ = parent + self.VVRGjW + "/"
  else    : self.VVOsKZ = "/"
  mode = self.VVuV9d()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVczMy(mode), self.controlFile))
  self.VV8Q7r()
 def VVRbnC(self):
  if fileExists(self.controlFile):
   lines = FFRtPk(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFufG1(self, self.VVZnjX, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFRGBb(self, "Version not found or incorrectly set !")
  else:
   FFZBzs(self, self.controlFile)
 def VVZnjX(self, VVGZ8H):
  if VVGZ8H:
   version, color = self.VV3lXm(VVGZ8H, False)
   if color == VV0HRz:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVGZ8H, self.controlFile))
    self.VV8Q7r()
   else:
    FFRGBb(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV12yc(self):
  if self.newControlPath:
   if self.VVpDFv:
    self.VVN7t8()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFf1xo(self.newControlPath, VVe79W)
    txt += FFf1xo("Do you want to keep these files ?", VVy4op)
    FFWkqs(self, self.close, txt, callBack_No=self.VVN7t8, title="Create Package", VVaQmw=True)
  else:
   self.close()
 def VVN7t8(self):
  os.system(FFWqNF("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVczMy(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVIn8a
  if package.startswith(self.VVRGCL):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVRGCL, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVnUvc : prefix = self.VVTIFQ
  elif mode == self.VVs4YO : prefix = self.VV6CKo
  return (prefix + name).lower()
 def VVuV9d(self):
  if   self.VVOsKZ.startswith(VVUsb0) : return self.VVnUvc
  elif self.VVOsKZ.startswith(VVBqIe) : return self.VVs4YO
  else            : return self.VVcJHt
 def VV0lYk(self, isFirstTime):
  self.VVRGjW   = FFj5JI(self.Path)
  self.VVRGjW   = "_".join(self.VVRGjW.split())
  self.VVIn8a = self.VVRGjW.lower()
  self.VVpDFv = self.VVIn8a == VVq9zD.lower()
  if self.VVpDFv and self.VVIn8a.endswith("ajpan"):
   self.VVIn8a += "el"
  if self.VVpDFv : self.VVMvz0 = VVsoKC
  else    : self.VVMvz0 = CFG.packageOutputPath.getValue()
  self.VVMvz0 = FFiSR4(self.VVMvz0)
  if not pathExists(self.controlPath):
   os.system(FFWqNF("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVuV9d()
  if fileExists(self.controlFile):
   lines = FFRtPk(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVpDFv : version, descripton, maintainer = VVGsPD , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVRGjW , self.VVRGjW
   txt = ""
   txt += "Package: %s\n"  % self.VVczMy(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVpDFv : t = PLUGIN_NAME
  else    : t = self.VVRGjW
  self.VVkMcI(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVkMcI(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVpDFv : self.VVkMcI(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVGsPD))
  else    : self.VVkMcI(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVRGjW)
  if isFirstTime and not mode == self.VVcJHt:
   self.postInstAcion = 1
  txt = self.VV6Rvo(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFUKzq(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VV6Rvo(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFWqNF("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVkMcI(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VV6Rvo(self, action):
  sep  = "echo '%s'\n" % VVT41S
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VV1DNi(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFRtPk(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFf1xo(line, VVL1qM)
     elif not line.startswith(" ")    : line = FFf1xo(line, VVL1qM)
     else          : line = FFf1xo(line, VV0HRz)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV0HRz
   else   : color = VVL1qM
   descr = FFf1xo(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVL1qM
     elif line.startswith((" ", "\t")) : color = VVL1qM
     elif line.startswith("#")   : color = VVe79W
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV3lXm(val, True)
      elif key == "Version"  : version, color = self.VV3lXm(val, False)
      elif key == "Maintainer" : maint  , color = val, VV0HRz
      elif key == "Architecture" : arch  , color = val, VV0HRz
      else:
       color = VV0HRz
      if not key == "OE" and not key.istitle():
       color = VVL1qM
     else:
      color = VVqskC
     txt += FFf1xo(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVEwIl = self.VVMvz0 + packageName
   self.VVrPNE = True
   errTxt = ""
  else:
   self.VVEwIl  = ""
   self.VVrPNE = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV3lXm(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV0HRz
  else          : return val, VVL1qM
 def VVC9lU(self):
  if not self.VVrPNE:
   FFRGBb(self, "Please fix Control File errors first.")
   return
  if self.VVQr59: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFEP6Z(self.VVOsKZ, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVRGjW
  symlinkTo  = FFvuYj(self.Path)
  dataDir   = self.VVOsKZ.rstrip("/")
  removePorjDir = FFWqNF("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFWqNF("rm -f '%s'" % self.VVEwIl) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFwHJG()
  if self.VVQr59:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF3uXq("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVpDFv:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVOsKZ == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVWXRj)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVEwIl, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVEwIl
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVEwIl, FFy8kX(result  , VVvsR7))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVOsKZ, FFy8kX(instPath, VV0HRz))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFy8kX(failed, VVL1qM))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF8ZtC(self, cmd)
class CCQii3():
 VVJsaS  = "666"
 VVy63F   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VVJQoQ()
 def VVJQoQ(self):
  VVv6X1 = CCQii3.VVkefo()
  if VVv6X1:
   VVqSIC = ("Create New", self.VV0dHm)
   self.menuInstance = FFLwVh(self.SELF, self.VVy1k7, VVv6X1=VVv6X1, title=self.Title, VVqSIC=VVqSIC, VVrAw7=True, VVyRL8="#22222233", VVmr0Y="#22222233")
  else:
   self.VV0dHm()
 def VVy1k7(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVB1VL(bName, bRef)
  else:
   CCQii3.VV3rUw(self)
 def VV0dHm(self, VVLmuPObj=None, item=None):
  FFufG1(self.SELF, BF(self.VVeOss), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVeOss(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVB1VL(bName, "")
   else:
    FFfad8(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCQii3.VV3rUw(self)
 def VVB1VL(self, bName, bRef):
  FF0rXP(self.waitMsgSELF, BF(self.VVEe04, bName, bRef), title="Adding Services ...")
 def VVEe04(self, bName, bRef):
  CCQii3.VVGUOl(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VV3rUw(classObj):
  del classObj
 @staticmethod
 def VVGUOl(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFRGBb(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVxlEW + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFZBzs(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCQii3.VVPXhz(bRef)
   bPath = VVxlEW + bFile
  else:
   fName = CCCGrE.VVyead(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVxlEW + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVxlEW + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCQii3.VVah43(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCQii3.VVah43(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCxA8L.VV76e0()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFWqNF("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCWhEO.VVZvOp(picon))
       break
  FFVJ21()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFipfq(SELF, txt, title=title)
 @staticmethod
 def VVkefo(mode=2, showTitle=True, prefix=""):
  VVv6X1 = []
  if mode in (0, 2): VVv6X1.extend(CCQii3.VVfneV(0, showTitle, prefix))
  if mode in (1, 2): VVv6X1.extend(CCQii3.VVfneV(1, showTitle, prefix))
  return VVv6X1
 @staticmethod
 def VVfneV(mode, showTitle, prefix):
  VVv6X1 = []
  lst = CCQii3.VV7s4i(mode)
  if lst:
   if showTitle:
    VVv6X1.append(FF9558("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVv6X1.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVv6X1.append((item[0], item[1].toString()))
  return VVv6X1
 @staticmethod
 def VVJfLd():
  bLise = CCQii3.VV7s4i(0)
  bLise.extend(CCQii3.VV7s4i(1))
  return bLise
 @staticmethod
 def VV7s4i(mode=0):
  bList = []
  VVY2Pt = InfoBar.instance
  VVpvWi = VVY2Pt and VVY2Pt.servicelist
  if VVpvWi:
   curMode = VVpvWi.mode
   CCQii3.VVMWsq(VVpvWi, mode)
   bList.extend(VVpvWi.getBouquetList() or [])
   CCQii3.VVMWsq(VVpvWi, curMode)
  return bList
 @staticmethod
 def VVMWsq(VVpvWi, mode):
  if not mode == VVpvWi.mode:
   if   mode == 0: VVpvWi.setModeTv()
   elif mode == 1: VVpvWi.setModeRadio()
 @staticmethod
 def VVah43(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVPXhz(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVZqkg():
  try:
   fName = CCQii3.VVPXhz(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVxlEW, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVVZ1I():
  path = CCQii3.VVZqkg()
  if path:
   txt = FFUKzq(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVEToZ():
  return FFWeXA(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VV1Zvo():
  lst = []
  for b in CCQii3.VVJfLd():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVxlEW + CCQii3.VVPXhz(bRef)
   if fileExists(path):
    lines = FFRtPk(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VV4XEk(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VV0Mk9(SID="", stripRType=False):
  if SID : patt = CCQii3.VV4XEk(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCQii3.VVJfLd():
   for service in FFWeXA(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVmVK4():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCQii3.VVJfLd():
   for service in FFWeXA(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVUZsf(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVlojO(pathLst):
  refLst = CCQii3.VV0Mk9(CCQii3.VVJsaS, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCQii3.VVUZsf(rType, CCQii3.VVJsaS, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCOjzn(Screen):
 VVTQdI   = 0
 VVKizH  = 1
 VVmcgf  = 2
 VVxTz5 = 3
 VVgjbI    = 20
 VV0ceJ  = None
 def __init__(self, session, VVOgpG="/", mode=VVTQdI, VVaUGp="Select", height=920, VVcK4p=30, gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFUxcO(VVonST, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFDBTO(self)
  FFjeeE(self["keyRed"] , "Exit")
  FFjeeE(self["keyYellow"], "More Options")
  FFjeeE(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVaUGp = VVaUGp
  self.jumpToFile   = jumpToFile
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  CCOjzn.VV0ceJ = self
  VVcoHN = None
  if patternMode:
   self.mode = self.VVxTz5
   FFjeeE(self["keyRed"], "Cancel")
   if   patternMode == "srt"   : VVcoHN = "^.*\.srt"
   elif patternMode == "ajpSet": VVcoHN = "^.*\/ajpanel_settings_"
   else      : VVcoHN = None
  if   self.jumpToFile       : VVw76n, self.VVOgpG = True , FFEP6Z(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVw76n, self.VVOgpG = True , CCOjzn.VVb4Zf(self)[1] or "/"
  elif self.mode == self.VVTQdI  : VVw76n, self.VVOgpG = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVmcgf : VVw76n, self.VVOgpG = False, VVOgpG
  elif self.mode == self.VVxTz5 : VVw76n, self.VVOgpG = True , VVOgpG
  else           : VVw76n, self.VVOgpG = True , VVOgpG
  self.VVOgpG = FFiSR4(self.VVOgpG)
  self["myMenu"] = CCh76K(  directory   = None
         , VVcoHN = VVcoHN
         , VVw76n   = VVw76n
         , VVV0tx = True
         , VVXgTP = True
         , VV1VzA   = self.skinParam["width"]
         , VVcK4p   = self.skinParam["bodyFontSize"]
         , VVv9gC  = self.skinParam["bodyLineH"]
         , VVyLdo  = self.skinParam["bodyColor"]
         , pngBGColorSelStr = self.cursorBG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVsJp0    ,
   "red" : self.VVSrtz   ,
   "green" : self.VV98Hx,
   "yellow": self.VVQQIf  ,
   "blue" : self.VVGocO ,
   "menu" : self.VVlEJ1  ,
   "info" : self.VVdEuV  ,
   "cancel": self.VV11UG    ,
   "pageUp": self.VVC0Bg   ,
   "chanUp": self.VVC0Bg
  }, -1)
  FFOeBX(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVPArW)
 def onExit(self):
  CCOjzn.VV0ceJ = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVPArW)
  FFK8YM(self)
  FFIpXz(self["myMenu"], bg=self.cursorBG)
  FFjMgg(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVmcgf, self.VVxTz5):
   FFjeeE(self["keyGreen"], self.VVaUGp)
   color = "#22000022"
   FF2A0B(self["myBody"], color)
   FF2A0B(self["myMenu"], color)
   color = "#22220000"
   FF2A0B(self["myTitle"], color)
   FF2A0B(self["myBar"], color)
  self.VVPArW()
  if self.VVGSrn(self.VVOgpG) > self.bigDirSize: FF0rXP(self, self.VV4zJx, title="Changing directory...")
  else              : self.VV4zJx()
 def VV4zJx(self):
  if self.jumpToFile : self.VVoWJ7(self.jumpToFile)
  elif self.gotoMovie : self.VV9BXY(chDir=False)
  else    : self["myMenu"].VV0Tr7(self.VVOgpG)
 def VVG9tX(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVNcPb(self):
  self["myMenu"].refresh()
  FFuDkg()
 def VVGSrn(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVsJp0(self):
  if self["myMenu"].VVEjDz() : self.VVi8VB()
  else       : self.VVaNZw()
 def VVC0Bg(self):
  self["myMenu"].moveToIndex(0)
  if self["myMenu"].VVharu():
   self.VVi8VB()
 def VVi8VB(self, isDirUp=False):
  if self["myMenu"].VVEjDz():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVtf8O(self.VVLmuP())
   if self.VVGSrn(path) > self.bigDirSize : FF0rXP(self, self.VVbYGG, title="Changing directory...")
   else           : self.VVbYGG()
 def VVbYGG(self):
  self["myMenu"].descent()
  self.VVPArW()
 def VV11UG(self):
  if CFG.FileManagerExit.getValue() == "e": self.VVSrtz()
  else         : self.VVC0Bg()
 def VVSrtz(self):
  if not FFCEoK(self):
   self.close("")
 def VV98Hx(self):
  path = self.VVtf8O(self.VVLmuP())
  if self.mode == self.VVmcgf:
   self.close(path)
  elif self.mode == self.VVxTz5:
   if os.path.isfile(path) : self.close(path)
   else     : FFfad8(self, "Cannot access this file", 1000)
 def VVdEuV(self):
  FF0rXP(self, self.VVTSBn, title="Calculating size ...")
 def VVTSBn(self):
  path = self.VVtf8O(self.VVLmuP())
  param = self.VVeuYl(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFTbYu("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCOjzn.VV894G(path)
     freeSize = CCOjzn.VVFSvh(path)
     size = totSize - freeSize
     totSize  = CCOjzn.VV7GBO(totSize)
     freeSize = CCOjzn.VV7GBO(freeSize)
    else:
     size = FFTbYu("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCOjzn.VV7GBO(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFf1xo(pathTxt, VVqskC) + "\n"
   if slBroken : fileTime = self.VV8UDU(path)
   else  : fileTime = self.VViX0h(path)
   def VVko9g(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVko9g("Path"    , pathTxt)
   txt += VVko9g("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVko9g("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVko9g("Total Size"   , "%s" % totSize)
    txt += VVko9g("Used Size"   , "%s" % usedSize)
    txt += VVko9g("Free Size"   , "%s" % freeSize)
   else:
    txt += VVko9g("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVko9g("Owner"    , owner)
   txt += VVko9g("Group"    , group)
   txt += VVko9g("Perm. (User)"  , permUser)
   txt += VVko9g("Perm. (Group)"  , permGroup)
   txt += VVko9g("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVko9g("Perm. (Ext.)" , permExtra)
   txt += VVko9g("iNode"    , iNode)
   txt += VVko9g("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVT41S, VVT41S)
    txt += hLinkedFiles
   txt += self.VVgqyk(path)
  else:
   FFRGBb(self, "Cannot access information !")
  if len(txt) > 0:
   FFipfq(self, txt)
 def VVeuYl(self, path):
  path = path.strip()
  path = FFvuYj(path)
  result = FFTbYu("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVGM9r(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVGM9r(perm, 1, 4)
   permGroup = VVGM9r(perm, 4, 7)
   permOther = VVGM9r(perm, 7, 10)
   permExtra = VVGM9r(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFrvKF("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVgqyk(self, path):
  txt  = ""
  res  = FFTbYu("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFf1xo("File Attributes:", VVRgTn), txt)
  return txt
 def VViX0h(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFQFpj(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFQFpj(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFQFpj(os.path.getctime(path))
  return txt
 def VV8UDU(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFTbYu("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFTbYu("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFTbYu("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVtf8O(self, currentSel):
  currentDir  = self["myMenu"].VVNKrW()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVEjDz():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVLmuP(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVPArW(self):
  path = self.VVtf8O(self.VVLmuP())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVAox3()
  if self.mode == self.VVTQdI and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVxTz5 and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVxTz5:
   path = self.VVtf8O(self.VVLmuP())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVAox3(self):
  if self.VV2rU0() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VVlEJ1(self):
  if self.mode == self.VVTQdI:
   color1  = VVityU
   color2  = VVKiZJ
   path  = self.VVtf8O(self.VVLmuP())
   VVv6X1 = []
   VVv6X1.append(("Properties", "properties"))
   if os.path.isdir(path):
    if not self.VVYtcY(path):
     VVv6X1.append(VVdKVg)
     VVv6X1.append((color1 + "Archiving / Packaging", "VVDWcv_dir"))
   elif os.path.isfile(path):
    selFile = self.VVLmuP()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVv6X1.append((color1 + "Archive ...", "VVDWcv_file"))
    isText = False
    txt = ""
    if   isArch            : VVv6X1.extend(self.VVJ2Z0(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVv6X1.extend(self.VVjckE(True))
    elif selFile.endswith(".sh"):
     VVv6X1.extend(self.VV1n9F(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCOjzn.VVVW9C(path):
     VVv6X1.append(VVdKVg)
     VVv6X1.append((color2 + "View"     , "textView_def"))
     VVv6X1.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVv6X1.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVvJp4(path) == "pic":
     VVv6X1.append(VVdKVg)
     VVv6X1.append((color2 + "Set as PIcon for current channel" , "VVoAjR" ))
     if FFN0sR("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVv6X1.append(VVdKVg)
      VVv6X1.append((color2 + "Convert to MVI (1280 x 720 )" , "VVMMunHd"   ))
      VVv6X1.append((color2 + "Convert to MVI (1920 x 1080)" , "VVMMunFhd"   ))
    elif selFile.endswith(CCOjzn.VVtxEe()):
     if selFile.endswith(".mvi"):
      if FFN0sR("showiframe"):
       VVv6X1.append(VVdKVg)
       VVv6X1.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVv6X1.append(VVdKVg)
      VVv6X1.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVv6X1.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVv6X1.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVv6X1.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVv6X1.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVv6X1.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV2j4T" ))
    if len(txt) > 0:
     VVv6X1.append(VVdKVg)
     VVv6X1.append((color1 + txt, "VVaNZw"))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("[4] Create SymLink", "VVn3EW"))
   if not self.VVYtcY(path):
    VVv6X1.append(("[5] Rename"      , "VVCwB0" ))
    VVv6X1.append(("[6] Copy"       , "copyFileOrDir" ))
    VVv6X1.append(("[7] Move"       , "moveFileOrDir" ))
    VVv6X1.append(("[8] %sDELETE" % VVqskC , "VV5pwL" ))
    if fileExists(path):
     VVv6X1.append(VVdKVg)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVv6X1.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVv6X1.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVv6X1.append((chmodTxt + "777)", "chmod777"))
   c = VVq8cV
   VVv6X1.append(VVdKVg)
   VVv6X1.append((c + "Create New File (in current directory)"  , "createNewFile" ))
   VVv6X1.append((c + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCOjzn.VVb4Zf(self)
   if fPath:
    VVv6X1.append(VVdKVg)
    VVv6X1.append((color2 + "Go to Current Movie Dir", "VV9BXY"))
   FFLwVh(self, self.VVzR8y, height=1050, title="Options", VVv6X1=VVv6X1, VVyRL8="#00101020", VVmr0Y="#00101A2A")
 def VVzR8y(self, item=None):
  if self.mode == self.VVTQdI:
   if item is not None:
    path = self.VVtf8O(self.VVLmuP())
    selFile = self.VVLmuP()
    if   item == "properties"    : self.VVdEuV()
    elif item == "VVDWcv_dir" : self.VVDWcv(path, True)
    elif item == "VVDWcv_file" : self.VVDWcv(path, False)
    elif item == "VVSEOP"  : self.VVSEOP(path)
    elif item == "VVgYnw"  : self.VVgYnw(path)
    elif item.startswith("extract_")  : self.VVuDJp(path, selFile, item)
    elif item.startswith("script_")   : self.VVf9Cx(path, selFile, item)
    elif item.startswith("m3u_")   : self.VV6UhR(path, selFile, item)
    elif item.startswith("textView_def") : FFKFmx(self, path)
    elif item.startswith("textView_enc") : self.VVvKWQ(path)
    elif item.startswith("text_Edit")  : FF0rXP(self, BF(CCyIuf, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVKKSu(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVKKSu(path, "Save as Other Encoding", False)
    elif item.startswith("VV2j4T") : self.VV2j4T(path)
    elif item == "viewAsBootlogo"   : self.VVQg9B(path, True)
    elif item == "addMovieToBouquet"  : self.VVxaIf(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVxaIf(path, True)
    elif item == "playWith"     : self.VVYn6S(path)
    elif item == "VVoAjR" : self.VVoAjR(path)
    elif item == "VVMMunHd"   : FF0rXP(self, BF(self.VVMMun, path, False))
    elif item == "VVMMunFhd"   : FF0rXP(self, BF(self.VVMMun, path, True))
    elif item == "VVn3EW"   : self.VVn3EW(path, selFile)
    elif item == "VVCwB0"   : self.VVCwB0(path, selFile)
    elif item == "copyFileOrDir"   : self.VVumRf(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVumRf(path, selFile, True)
    elif item == "VV5pwL"   : self.VV5pwL(path, selFile)
    elif item == "chmod644"     : self.VVCX8I(path, selFile, "644")
    elif item == "chmod755"     : self.VVCX8I(path, selFile, "755")
    elif item == "chmod777"     : self.VVCX8I(path, selFile, "777")
    elif item == "createNewFile"   : self.VVF75s(path, True)
    elif item == "createNewDir"    : self.VVF75s(path, False)
    elif item == "VV9BXY"   : self.VV9BXY()
    elif item == "VVaNZw"    : self.VVaNZw()
 def VVaNZw(self):
  if self.mode == self.VVxTz5:
   return
  selFile = self.VVLmuP()
  path  = self.VVtf8O(selFile)
  if os.path.isfile(path):
   VVdEBn  = []
   category = self["myMenu"].VVvJp4(path)
   if   category == "pic"      : self.VVJVaQ(path)
   elif category == "txt"      : FFKFmx(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVKkx8(path, selFile)
   elif category == "scr"      : self.VVTBgm(path, selFile)
   elif category == "m3u"      : self.VVirk8(path, selFile)
   elif category in ("ipk", "deb")    : self.VVMnPC(path, selFile)
   elif category in ("mov", "mus")    : self.VVQg9B(path)
   elif not CCOjzn.VVVW9C(path) : FFKFmx(self, path)
 def VVJVaQ(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVvJp4(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCXjSu.VVTYNz(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVfIuf)
 def VVfIuf(self, path):
  self.VVoWJ7(path)
 def VVQg9B(self, path, asLogo=False):
  if asLogo : CCBQez.VVvVDy(self, path)
  else  : FF0rXP(self, BF(self.VVaWiz, self, path), title="Playing Media ...")
 def VVGocO(self):
  if self["keyBlue"].getVisible():
   VVouKi = self.VV2rU0()
   if VVouKi:
    path = self.VVtf8O(self.VVLmuP())
    enableGreenBtn = False if path in self.VV2rU0() else True
    newList = []
    for line in VVouKi:
     newList.append((line, line))
    VVrX4i  = ("Delete"    , self.VVQprN    )
    VV3h4q  = ("Add Current Dir"   , BF(self.VVFC3H, path) ) if enableGreenBtn else None
    VVqSIC = ("Move Up"     , self.VVuhFP    )
    VVxtuz  = ("Move Down"   , self.VVqG4A    )
    self.bookmarkMenu = FFLwVh(self, self.VV5XLm, width=1200, title="Bookmarks", VVv6X1=newList, minRows=10 ,VVrX4i=VVrX4i, VV3h4q=VV3h4q, VVqSIC=VVqSIC, VVxtuz=VVxtuz, VVyRL8="#00000022", VVmr0Y="#00000022")
 def VVQprN(self, menuInstance=None, path=None):
  VVouKi = self.VV2rU0()
  if VVouKi:
   while path in VVouKi:
    VVouKi.remove(path)
   self.VVDCus(VVouKi)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV6wAR(VVouKi)
   self.bookmarkMenu.VVFggW(("Add Current Dir", BF(self.VVFC3H, path)))
  else:
   FFfad8(self, "Removed", 800)
  self.VVAox3()
 def VVFC3H(self, path, menuInstance=None, item=None):
  VVouKi = self.VV2rU0()
  if len(VVouKi) >= self.VVgjbI:
   FFRGBb(SELF, "Max bookmarks reached (max=%d)." % self.VVgjbI)
  elif not path in VVouKi:
   newList = [path] + VVouKi
   self.VVDCus(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV6wAR(newList)
    self.bookmarkMenu.VVFggW()
   else:
    FFfad8(self, "Added", 800)
  self.VVAox3()
 def VVuhFP(self, VVLmuPObj, path):
  if self.bookmarkMenu:
   VVouKi = self.bookmarkMenu.VVthe5(True)
   if VVouKi:
    self.VVDCus(VVouKi)
 def VVqG4A(self, VVLmuPObj, path):
  if self.bookmarkMenu:
   VVouKi = self.bookmarkMenu.VVthe5(False)
   if VVouKi:
    self.VVDCus(VVouKi)
 def VV5XLm(self, folder=None):
  if folder:
   folder = FFiSR4(folder)
   self["myMenu"].VV0Tr7(folder)
   self["myMenu"].moveToIndex(0)
  self.VVPArW()
 def VV2rU0(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV7eEu(self):
  return True if VV2rU0() else False
 def VVDCus(self, VVouKi):
  line = ",".join(VVouKi)
  FFcghP(CFG.browserBookmarks, line)
 def VVoWJ7(self, path):
  if fileExists(path):
   fDir  = FFiSR4(os.path.dirname(path))
   if fDir:
    self["myMenu"].VV0Tr7(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFfad8(self, "Not found", 1000)
 def VV9BXY(self, chDir=True):
  fPath, fDir, fName = CCOjzn.VVb4Zf(self)
  self.VVoWJ7(fPath)
 def VVQQIf(self):
  path = self.VVtf8O(self.VVLmuP())
  isAdd = False if path in self.VV2rU0() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  VVv6X1 = []
  VVv6X1.append(   ("Find Files ..."      , "find" ))
  VVv6X1.append(   ("Sort ..."        , "sort" ))
  VVv6X1.append(VVdKVg)
  if isAdd: VVv6X1.append( ("Add %s Dir to Bookmarks" % dirTxt  , "addBM" ))
  else : VVv6X1.append( ("Remove %s Dir from Bookmarks" % dirTxt, "remBM" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(   ('Set %s Dir as "Startup Dir"' % dirTxt , "start" ))
  FFLwVh(self, BF(self.VVJHbA, path), width=750, title="More Options", VVv6X1=VVv6X1, VVyRL8="#00221111", VVmr0Y="#00221111")
 def VVJHbA(self, path, item):
  if item:
   if   item == "find" : self.VV9vmL(path)
   elif item == "sort" : self.VVSo9z()
   elif item == "addBM": self.VVFC3H(path)
   elif item == "remBM": self.VVQprN(None, path)
   elif item == "start": self.VV0O8y(path)
 def VV9vmL(self, path):
  VVv6X1 = []
  VVv6X1.append(("Find in Current Directory"    , "findCur"  ))
  VVv6X1.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVv6X1.append(("Find in all Storage Systems"    , "findAll"  ))
  FFLwVh(self, BF(self.VVxhn7, path), width=700, title="Find File/Pattern", VVv6X1=VVv6X1, VVrAw7=True, VV8k4Z=True, VVyRL8="#00221111", VVmr0Y="#00221111")
 def VVxhn7(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVK6EP(0, path, title)
   elif item == "findCurR" : self.VVK6EP(1, path, title)
   elif item == "findAll" : self.VVK6EP(2, path, title)
 def VVK6EP(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFufG1(self, BF(self.VVeas5, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVeas5(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFcghP(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFfad8(self, "No entery", 1500)
   elif badLst  : FFfad8(self, "Too many file !", 1500)
   else   : FF0rXP(self, BF(self.VVzRFN, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVzRFN(self, mode, path, title, filePatt):
  FFfad8(self)
  lst = FFqfZV(FFRsJX("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVngly:
    FFRGBb(self, VVngly)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVTMvN = (""     , self.VVMpFL , [])
    VV6vKb = ("Go to File Location", self.VVw5Mr  , [])
    FFl3hs(self, None, title="%s : %s" % (title, filePatt), header=header, VVouKi=lst, VVw7oP=widths, VVcK4p=26, VVTMvN=VVTMvN, VV6vKb=VV6vKb)
  else:
   FFfad8(self, "Not found !", 2000)
 def VVw5Mr(self, VVYo8S, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVYo8S.cancel()
   self.VVoWJ7(path)
  else:
   FFfad8(VVYo8S, "Path not found !", 1000)
 def VVMpFL(self, VVYo8S, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFf1xo("File:"  , VVKiZJ), colList[0])
  txt += "%s\n%s"  % (FFf1xo("Directory:", VVKiZJ), FFiSR4(colList[1]))
  FFipfq(VVYo8S, txt, title=title)
 def VVSo9z(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVkIai()
  VVv6X1 = []
  VVv6X1.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVv6X1.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVv6X1.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVv6X1.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVxtuz = ("Mix", BF(self.VVKbh7, True))
  FFLwVh(self, BF(self.VVuk5z, False), barText=txt, width=650, title="Sort Options", VVv6X1=VVv6X1, VVxtuz=VVxtuz, VV8k4Z=True, VVyRL8="#00221111", VVmr0Y="#00221111")
 def VVKbh7(self, isMix, menuInstance, item):
  self.VVuk5z(True, item)
 def VVuk5z(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVkIai()
   title = "Sorting ... "
   if   item == "nameAlp": FF0rXP(self, BF(self["myMenu"].VVwwCm, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF0rXP(self, BF(self["myMenu"].VVwwCm, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF0rXP(self, BF(self["myMenu"].VVwwCm, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF0rXP(self, BF(self["myMenu"].VVwwCm, typeMode , isMix, False), title=title)
 def VV0O8y(self, path):
  if not os.path.isdir(path):
   path = FFEP6Z(path, True)
  FFcghP(CFG.browserStartPath, path)
  FFfad8(self, "Done", 500)
 def VVhALE(self, selFile, VVfTYp, command):
  FFWkqs(self, BF(FF8ZtC, self, command, VVo3en=self.VVNcPb), "%s\n\n%s" % (VVfTYp, selFile))
 def VVJ2Z0(self, path, calledFromMenu):
  destPath = self.VVSB4L(path)
  lastPart = FFj5JI(destPath)
  VVv6X1 = []
  if calledFromMenu:
   VVv6X1.append(VVdKVg)
   color = VVKiZJ
  else:
   color = ""
  VVv6X1.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVv6X1.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVv6X1.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVv6X1.append(VVdKVg)
    VVv6X1.append((color + "Convert .zip to .tar.gz"       , "VVSEOP" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVv6X1.append(VVdKVg)
    VVv6X1.append((color + "Convert .tar.gz to .zip"       , "VVgYnw" ))
  return VVv6X1
 def VVKkx8(self, path, selFile):
  FFLwVh(self, BF(self.VVuDJp, path, selFile), title="Compressed File Options", VVv6X1=self.VVJ2Z0(path, False))
 def VVuDJp(self, path, selFile, item=None):
  if item is not None:
   parent  = FFEP6Z(path, False)
   destPath = self.VVSB4L(path)
   lastPart = FFj5JI(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVT41S
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF3uXq("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF3uXq("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVT41S, VVT41S)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFXvUZ(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVSEOP" : self.VVSEOP(path)
    else       : self.VV4pco(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVgYnw" and path.endswith(".tar.gz"):
    self.VVgYnw(path)
   elif path.endswith(".rar"):
    self.VVNEM9(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFWqNF("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVhALE(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVhALE(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFEP6Z(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVhALE(selFile, "Extract Here ?"      , cmd)
 def VVSB4L(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VV4pco(self, item, path, parent, destPath, VVfTYp):
  FFWkqs(self, BF(self.VVuCK1, item, path, parent, destPath), VVfTYp)
 def VVuCK1(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVT41S
  cmd  = FF3uXq("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFy8kX(destPath, VVvsR7))
  cmd +=   sep
  cmd += "fi;"
  FFHuBX(self, cmd, VVo3en=self.VVNcPb)
 def VVNEM9(self, item, path, parent, destPath, VVfTYp):
  FFWkqs(self, BF(self.VVesV7, item, path, parent, destPath), VVfTYp)
 def VVesV7(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFiSR4(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVT41S
  cmd  = FF3uXq("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFy8kX(destPath, VVvsR7))
  cmd +=   sep
  cmd += "fi;"
  FFHuBX(self, cmd, VVo3en=self.VVNcPb)
 def VV1n9F(self, addSep=False):
  VVv6X1 = []
  if addSep:
   VVv6X1.append(VVdKVg)
  VVv6X1.append((VVKiZJ + "View Script File"  , "script_View"  ))
  VVv6X1.append((VVKiZJ + "Execute Script File" , "script_Execute" ))
  VVv6X1.append((VVKiZJ + "Edit"     , "script_Edit" ))
  return VVv6X1
 def VVTBgm(self, path, selFile):
  FFLwVh(self, BF(self.VVf9Cx, path, selFile), title="Script File Options", VVv6X1=self.VV1n9F())
 def VVf9Cx(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFKFmx(self, path)
   elif item == "script_Execute" : self.VVhALE(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCyIuf(self, path)
 def VVjckE(self, addSep=False):
  VVv6X1 = []
  if addSep:
   VVv6X1.append(VVdKVg)
  VVv6X1.append((VVKiZJ + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVv6X1.append((VVKiZJ + "Edit"      , "m3u_Edit" ))
  VVv6X1.append((VVKiZJ + "View"      , "m3u_View" ))
  return VVv6X1
 def VVirk8(self, path, selFile):
  FFLwVh(self, BF(self.VV6UhR, path, selFile), title="M3U/M3U8 File Options", VVv6X1=self.VVjckE())
 def VV6UhR(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF0rXP(self, BF(self.session.open, CCCGrE, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCyIuf(self, path)
   elif item == "m3u_View"  : FFKFmx(self, path)
 def VVvKWQ(self, path):
  if fileExists(path) : FF0rXP(self, BF(CCzVQo.VVmOQL, self, path, BF(self.VV0GoB, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFZBzs(self, path)
 def VV0GoB(self, path, item=None):
  if item:
   FFKFmx(self, path, encLst=item)
 def VVKKSu(self, path, title, asUtf8):
  if fileExists(path) : FF0rXP(self, BF(CCzVQo.VVmOQL, self, path, BF(self.VV02LF, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFZBzs(self, path)
 def VV02LF(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVa1rr(path, title, fromEnc, "UTF-8")
   else  : CCzVQo.VVmOQL(self, path,  BF(self.VVa1rr, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVa1rr(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFf1xo("Successful\n\n", VVvsR7)
      txt += FFf1xo("From Encoding (%s):\n" % fromEnc, VVy4op)
      txt += "%s\n\n" % path
      txt += FFf1xo("To Encoding (%s):\n" % toEnc, VVy4op)
      txt += "%s\n\n" % outFile
      FFipfq(self, txt, title=title)
    except:
     FFRGBb(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFfad8(self, "Cannot open file", 2000)
  self.VVNcPb()
 def VV2j4T(self, path):
  title = "File Line-Break Conversion"
  FFWkqs(self, BF(self.VVVxKI, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVVxKI(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFf1xo("File converted:", VVvsR7), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFrNpu(self, txt, title=title)
  else:
   FFZBzs(self, path, title=title)
 def VVCX8I(self, path, selFile, newChmod):
  FFWkqs(self, BF(self.VVz5mK, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVz5mK(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVpXho)
  result = FFTbYu(cmd)
  if result == "Successful" : FFrNpu(self, result)
  else      : FFRGBb(self, result)
 def VVn3EW(self, path, selFile):
  parent = FFEP6Z(path, False)
  self.session.openWithCallback(self.VVUPaU, BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG=parent, VVaUGp="Create Symlink here"))
 def VVUPaU(self, newPath):
  if len(newPath) > 0:
   target = self.VVtf8O(self.VVLmuP())
   target = FFvuYj(target)
   linkName = FFj5JI(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFiSR4(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFRGBb(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFWkqs(self, BF(self.VVofwZ, target, link), "Create Soft Link ?\n\n%s" % txt, VVaQmw=True)
 def VVofwZ(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVpXho)
  result = FFTbYu(cmd)
  if result == "Successful" : FFrNpu(self, result)
  else      : FFRGBb(self, result)
 def VVCwB0(self, path, selFile):
  lastPart = FFj5JI(path)
  FFufG1(self, BF(self.VVvRl7, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVvRl7(self, path, selFile, VVGZ8H):
  if VVGZ8H:
   parent = FFEP6Z(path, True)
   if os.path.isdir(path):
    path = FFvuYj(path)
   newName = parent + VVGZ8H
   cmd = "mv '%s' '%s' %s" % (path, newName, VVpXho)
   if VVGZ8H:
    if selFile != VVGZ8H:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFWkqs(self, BF(self.VVcX02, cmd), message, title="Rename file?")
    else:
     FFRGBb(self, "Cannot use same name!", title="Rename")
 def VVcX02(self, cmd):
  result = FFTbYu(cmd)
  if "Fail" in result:
   FFRGBb(self, result)
  self.VVNcPb()
 def VVumRf(self, path, selFile, isMove):
  if isMove : VVaUGp = "Move to here"
  else  : VVaUGp = "Paste here"
  parent = FFEP6Z(path, False)
  self.session.openWithCallback(BF(self.VVbPAB, isMove, path, selFile)
         , BF(CCOjzn, mode=CCOjzn.VVmcgf, VVOgpG=parent, VVaUGp=VVaUGp))
 def VVbPAB(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FFj5JI(path)
   if os.path.isdir(path):
    path = FFvuYj(path)
   newPath = FFiSR4(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFRGBb(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFWkqs(self, BF(FFYYbP, self, cmd, VVo3en=self.VVNcPb), txt, VVaQmw=True)
   else:
    FFRGBb(self, "Cannot %s to same directory !" % action.lower())
 def VV5pwL(self, path, fileName):
  path = FFvuYj(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFWkqs(self, BF(self.VV4QTU, path), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV4QTU(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVNcPb()
 def VVYtcY(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVhvL2 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVF75s(self, path, isFile):
  dirName = FFiSR4(os.path.dirname(path))
  if isFile : objName, VVGZ8H = "File"  , self.edited_newFile
  else  : objName, VVGZ8H = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFufG1(self, BF(self.VVkMdN, dirName, isFile, title), title=title, defaultText=VVGZ8H, message="Enter %s Name:" % objName)
 def VVkMdN(self, dirName, isFile, title, VVGZ8H):
  if VVGZ8H:
   if isFile : self.edited_newFile = VVGZ8H
   else  : self.edited_newDir  = VVGZ8H
   path = dirName + VVGZ8H
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVpXho)
    else  : cmd = "mkdir '%s' %s" % (path, VVpXho)
    result = FFTbYu(cmd)
    if "Fail" in result:
     FFRGBb(self, result)
    self.VVNcPb()
   else:
    FFRGBb(self, "Name already exists !\n\n%s" % path, title)
 def VVMnPC(self, path, selFile):
  c1, c2, c3 = VVkC8X, VVKiZJ, VVityU
  VVv6X1 = []
  VVv6X1.append((c1 + "List Package Files"         , "VV2iPT"     ))
  VVv6X1.append((c1 + "Package Information"         , "VVMd11"     ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c2 + "Install Package"          , "VVmi26_CheckVersion" ))
  VVv6X1.append((c2 + "Install Package (force reinstall)"     , "VVmi26_ForceReinstall" ))
  VVv6X1.append((c2 + "Install Package (force overwrite)"     , "VVmi26_ForceOverwrite" ))
  VVv6X1.append((c2 + "Install Package (force downgrade)"     , "VVmi26_ForceDowngrade" ))
  VVv6X1.append((c2 + "Install Package (ignore failed dependencies)"  , "VVmi26_IgnoreDepends" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c3 + "Remove Related Package"        , "VVrX7s_ExistingPackage" ))
  VVv6X1.append((c3 + "Remove Related Package (force remove)"    , "VVrX7s_ForceRemove"  ))
  VVv6X1.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVrX7s_IgnoreDepends" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Extract Files"           , "VViftC"     ))
  VVv6X1.append(("Unbuild Package"           , "VVv7NH"     ))
  FFLwVh(self, BF(self.VVzCYO, path, selFile), VVv6X1=VVv6X1)
 def VVzCYO(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV2iPT"      : self.VV2iPT(path, selFile)
   elif item == "VVMd11"      : self.VVMd11(path)
   elif item == "VVmi26_CheckVersion"  : self.VVmi26(path, selFile, VViQjU     )
   elif item == "VVmi26_ForceReinstall" : self.VVmi26(path, selFile, VVaj7G )
   elif item == "VVmi26_ForceOverwrite" : self.VVmi26(path, selFile, VVTIdG )
   elif item == "VVmi26_ForceDowngrade" : self.VVmi26(path, selFile, VVQVWS )
   elif item == "VVmi26_IgnoreDepends" : self.VVmi26(path, selFile, VVlNe9 )
   elif item == "VVrX7s_ExistingPackage" : self.VVrX7s(path, selFile, VVdipQ     )
   elif item == "VVrX7s_ForceRemove"  : self.VVrX7s(path, selFile, VV4yPs  )
   elif item == "VVrX7s_IgnoreDepends"  : self.VVrX7s(path, selFile, VVnbOp )
   elif item == "VViftC"     : self.VViftC(path, selFile)
   elif item == "VVv7NH"     : self.VVv7NH(path, selFile)
   else           : self.close()
 def VV2iPT(self, path, selFile):
  if FFN0sR("ar") : cmd = "allOK='1';"
  else    : cmd  = FFwHJG()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVT41S, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVT41S, VVT41S)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFepZj(self, cmd, VVo3en=self.VVNcPb)
 def VViftC(self, path, selFile):
  lastPart = FFj5JI(path)
  dest  = FFEP6Z(path, True) + selFile[:-4]
  cmd  =  FFwHJG()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFWqNF("mkdir '%s'" % dest) + ";"
  cmd +=    FFWqNF("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFy8kX(dest, VVvsR7))
  cmd += "fi;"
  FF8ZtC(self, cmd, VVo3en=self.VVNcPb)
 def VVv7NH(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVpBdT = os.path.splitext(path)[0]
  else        : VVpBdT = path + "_"
  if path.endswith(".deb")   : VVWXRj = "DEBIAN"
  else        : VVWXRj = "CONTROL"
  cmd  = FFwHJG()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVpBdT, FFzrh0())
  cmd += "  mkdir '%s';"    % VVpBdT
  cmd += "  CONTPATH='%s/%s';"  % (VVpBdT, VVWXRj)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVpBdT
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVpBdT, VVpBdT)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpBdT
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVpBdT, VVpBdT)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpBdT
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVpBdT
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVpBdT, FFy8kX(VVpBdT, VVvsR7))
  cmd += "fi;"
  FF8ZtC(self, cmd, VVo3en=self.VVNcPb)
 def VVMd11(self, path):
  listCmd  = FFrxPD(VVmMeS, "")
  infoCmd  = FFohUm(VV9TTi , "")
  filesCmd = FFohUm(VVXRXE, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF743i(VVy4op)
   notInst = "Package not installed."
   cmd  = FFaNdy("File Info", VVy4op)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFaNdy("System Info", VVy4op)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFy8kX(notInst, VVqskC))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFaNdy("Related Files", VVy4op)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFXvUZ(self, cmd)
  else:
   FF2yhz(self)
 def VVmi26(self, path, selFile, cmdOpt):
  cmd = FFohUm(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFWkqs(self, BF(FF8ZtC, self, cmd, VVo3en=FFuDkg), "Install Package ?\n\n%s" % selFile)
  else:
   FF2yhz(self)
 def VVrX7s(self, path, selFile, cmdOpt):
  listCmd  = FFrxPD(VVmMeS, "")
  infoCmd  = FFohUm(VV9TTi, "")
  instRemCmd = FFohUm(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFy8kX(errTxt, VVqskC))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFy8kX(cannotTxt, VVqskC))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFy8kX(tryTxt, VVqskC))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFWkqs(self, BF(FF8ZtC, self, cmd, VVo3en=FFuDkg), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF2yhz(self)
 def VVjcTc(self, path):
  hostName = FFTbYu("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVDWcv(self, path, isDir):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVv6X1 = []
  VVv6X1.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVv6X1.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVv6X1.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVv6X1.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVv6X1.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVv6X1.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVv6X1.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVv6X1.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVv6X1.append(("%s.zip"  % Path   , "archPath_zip"  ))
  if isDir:
   VVv6X1.append(VVdKVg)
   VVv6X1.append(('Convert to ".ipk" Package' , "convertDirToIpk" ))
   VVv6X1.append(('Convert to ".deb" Package' , "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFLwVh(self, BF(self.VVCVwO, path, isDir, title), VVv6X1=VVv6X1, title=title, VVyRL8=c1, VVmr0Y=c2)
 def VVCVwO(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV3ntM(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VV3ntM(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV3ntM(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV3ntM(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VV3ntM(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VV3ntM(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VV3ntM(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV3ntM(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV3ntM(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VV3ntM(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VV4pJ1(path, False)
   elif item == "convertDirToDeb"   : self.VV4pJ1(path, True)
   else         : self.close()
 def VV4pJ1(self, path, VVQr59):
  self.session.openWithCallback(self.VVNcPb, BF(CC5Nh4, path=path, VVQr59=VVQr59))
 def VV3ntM(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFEP6Z(path, True)
  lastPart = FFj5JI(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF3uXq("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF3uXq("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF3uXq("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVT41S
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFWqNF("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFy8kX(failed, VV8tcv))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFy8kX(srcTxt, VV0HRz))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFy8kX("Output", VVvsR7))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFy8kX(failed, VVL1qM))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFepZj(self, cmd, VVo3en=self.VVNcPb, title=title)
 def VVxaIf(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCOjzn.VV9eFG(FFEP6Z(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCQii3(self, self, title, BF(self.VVVVIt, pathLst))
 def VVVVIt(self, pathLst):
  return CCQii3.VVlojO(pathLst)
 def VVSEOP(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVBdCD, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWkqs(self, BF(FF0rXP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF0rXP(self, fnc, title=txt)
  else:
   FFRGBb(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVBdCD(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, 'w:gz') as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFipfq(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVNcPb()
  else:
   FFsF1P(tarPath)
   FFRGBb(self, "Error while converting.", title=title)
 def VVgYnw(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVE0ZW, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWkqs(self, BF(FF0rXP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF0rXP(self, fnc, title=txt)
  else:
   FFRGBb(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVE0ZW(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFipfq(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVNcPb()
  else:
   FFsF1P(zipPath)
   FFRGBb(self, "Error while converting.", title=title)
 def VVMMun(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFiSR4(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFWqNF("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFWqNF("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFWqNF("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VVNcPb()
   FFrNpu(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFRGBb(self, "Cannot convert this file !", title=title)
 def VVoAjR(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCxA8L.VV76e0()
  if pathExists(pPath):
   if CCtNnf.VVdCzy(self, title, False, cbFnc=BF(self.VVoAjR, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVv6X1 = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVv6X1.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VVJFfh
    VVxtuz = ("Stretch", BF(self.VVbvP9, title, path, picon))
    menuInstance = FFLwVh(self, BF(self.VVUj7Z, title, path, picon, False), VVv6X1=VVv6X1, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VVxtuz=VVxtuz, barText="OK = Fit within size")
    menuInstance.VVsnMy(3)
  else:
   FFRGBb(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVbvP9(self, title, path, picon, VVLmuPObj, item):
  self.VVUj7Z(title, path, picon, True, item)
  VVLmuPObj.cancel()
 def VVUj7Z(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFwYti(self, fncMode=CCWhEO.VV9IGI)
   except Exception as e:
    FFRGBb(self, "Image Processing error:\n\n%s" % e)
 def VVJFfh(self, menuInstance, txt, ref, ndx):
  FFAqgP(self, "_help_resize", "Picture File Resizing")
 @staticmethod
 def VVXMB8():
  lst = (("1"  , "DVB Stream"  , True)
   , ("4097", "servicemp3"  , True)
   , ("5001", "GST Player"  , os.path.exists("/usr/bin/gstplayer"))
   , ("5002", "Ext-3 EPlayer" , os.path.exists("/usr/bin/exteplayer3"))
   , ("8193", "eServiceUri" , os.path.exists("/usr/bin/apt-get")))
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVv6X1 = []
  for ndx, (rt, txt, ok) in enumerate(lst):
   txt = "%s\t... %s" % ((VVkC8X if rt == defRt else "") + txt, rt)
   if ok: VVv6X1.append((txt, rt))
   else : VVv6X1.append((txt, ))
   if ndx < 4 and ndx % 2: VVv6X1.append(VVdKVg)
  return VVv6X1
 def VVYn6S(self, path):
  FFLwVh(self, BF(self.VVZwGm, path), VVv6X1=CCOjzn.VVXMB8(), width=650, title="Select Player", VVyRL8="#11220000", VVmr0Y="#11220000")
 def VVZwGm(self, path, rType=None):
  if rType:
   FF0rXP(self, BF(self.VVaWiz, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVaWiz(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCSeoi.VVLNOL(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVb4Zf(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFiSR4(fDir), fName
  return "", "", ""
 @staticmethod
 def VV894G(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVFSvh(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV7GBO(size, mode=0):
  txt = CCOjzn.VVXLh9(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVXLh9(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVVW9C(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVAreK(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFRGBb(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVtxEe():
  tDict = CCh76K.VVH988()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VV9eFG(path):
  lst = []
  for ext in CCOjzn.VVtxEe():
   lst.extend(FF37hM(path, "*.%s" % ext))
  return sorted(lst, key=FFo3Is(FFvJTl))
 @staticmethod
 def VVdIsR(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVcFRD(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
class CCh76K(MenuList):
 VVwrlA  = 0
 VV5v1Y  = 1
 VVkFz6  = 2
 VVozO7  = 3
 VVPibe  = 4
 VVg5xJ  = 5
 VVVhZN  = 6
 VV6Gs6  = 7
 VVmsZl  = "<List of Storage Devices>"
 VVQIwl = "<Parent Directory>"
 def __init__(self, VVXgTP=False, directory="/", VVZCWh=True, VVw76n=True, VVV0tx=True, VVcoHN=None, VVy3kb=False, VVWzky=False, VVDFGm=False, isTop=False, VVoRfz=None, VV1VzA=1000, VVcK4p=30, VVv9gC=30, VVyLdo="#00000000", pngBGColorSelStr="#06003333"):
  MenuList.__init__(self, list, VVXgTP, eListboxPythonMultiContent)
  self.VVZCWh  = VVZCWh
  self.VVw76n    = VVw76n
  self.VVV0tx  = VVV0tx
  self.VVcoHN  = VVcoHN
  self.VVy3kb   = VVy3kb
  self.VVWzky   = VVWzky or []
  self.VVDFGm   = VVDFGm or []
  self.isTop     = isTop
  self.additional_extensions = VVoRfz
  self.VV1VzA    = VV1VzA
  self.VVcK4p    = VVcK4p
  self.VVv9gC    = VVv9gC
  self.pngBGColor    = FFKd79(VVyLdo)
  self.pngBGColorSel   = FFKd79(pngBGColorSelStr)
  self.EXTENSIONS    = CCh76K.VVH988()
  self.VV1zoa   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VVRQSa, self.VVcK4p))
  self.l.setItemHeight(self.VVv9gC)
  self.png_mem   = self.VVzhsh("mem")
  self.png_usb   = self.VVzhsh("usb")
  self.png_fil   = self.VVzhsh("fil")
  self.png_dir   = self.VVzhsh("dir")
  self.png_dirup   = self.VVzhsh("dirup")
  self.png_srv   = self.VVzhsh("srv")
  self.png_slwfil   = self.VVzhsh("slwfil")
  self.png_slbfil   = self.VVzhsh("slbfil")
  self.png_slwdir   = self.VVzhsh("slwdir")
  self.VVJur2()
  self.VV0Tr7(directory)
 def VVzhsh(self, category):
  return LoadPixmap("%s%s.png" % (VVCsc2, category), getDesktop(0))
 @staticmethod
 def VVH988():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVV56Y(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFvuYj(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFf1xo(" -> " , VVy4op) + FFf1xo(os.readlink(path), VVvsR7)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVv9gC + 10, 0, self.VV1VzA, self.VVv9gC, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV7k54: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVv9gC-4, self.VVv9gC-4, png, self.pngBGColor, self.pngBGColorSel, VV7k54))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVv9gC-4, self.VVv9gC-4, png, self.pngBGColor, self.pngBGColorSel))
  return tableRow
 def VVvJp4(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVJur2(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVXUfq(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVu56O(self, file):
  if os.path.realpath(file) == file:
   return self.VVXUfq(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVXUfq(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVXUfq(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVxECg(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV1zoa.info(l[0][0]).getEvent(l[0][0])
 def VV5ohk(self):
  return self.list
 def VVfjGV(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV0Tr7(self, directory, select = None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVV0tx:
    self.current_mountpoint = self.VVu56O(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVV0tx:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVDFGm and not self.VVfjGV(path, self.VVWzky):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVV56Y(name=p.description, absolute=path, isDir=True, png=png))
    path = "/"
    if path not in self.VVDFGm and not self.VVfjGV(path, self.VVWzky):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVV56Y(name="INTERNAL FLASH", absolute="/", isDir=True, png=self.png_mem))
  elif self.VVy3kb:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV1zoa = eServiceCenter.getInstance()
   list = VV1zoa.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVZCWh and not self.isTop:
   if directory == self.current_mountpoint and self.VVV0tx:
    self.list.append(self.VVV56Y(name=self.VVmsZl, absolute=None, isDir=True, png=self.png_dirup))
   elif (directory != "/") and not (self.VVDFGm and self.VVXUfq(directory) in self.VVDFGm):
    self.list.append(self.VVV56Y(name=self.VVQIwl, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, png=self.png_dirup))
  if self.VVZCWh:
   for x in directories:
    if not (self.VVDFGm and self.VVXUfq(x) in self.VVDFGm) and not self.VVfjGV(x, self.VVWzky):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVV56Y(name=name, absolute=x, isDir=True, png=png))
  if self.VVw76n:
   for x in files:
    if self.VVy3kb:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFf1xo(" -> " , VVy4op) + FFf1xo(target, VVvsR7)
       else:
        png = self.png_slbfil
        name += FFf1xo(" -> " , VVy4op) + FFf1xo(target, VVL1qM)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVvJp4(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVCsc2, category))
    if (self.VVcoHN is None) or iCompile(self.VVcoHN).search(path):
     self.list.append(self.VVV56Y(name=name, absolute=x , isDir=False, png=png))
  if self.VVV0tx and len(self.list) == 0:
   self.list.append(self.VVV56Y(name=FFf1xo("No USB connected", VVe79W), absolute=None, isDir=False, png=self.png_usb))
  self.l.setList(self.list)
  self.VVwwCm()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVNKrW(self):
  return self.current_directory
 def VVEjDz(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVharu(self):
  return self.VVJ53r() and self.VVNKrW()
 def VVJ53r(self):
  return self.list[0][1][7] in (self.VVmsZl, self.VVQIwl)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV0Tr7(self.getSelection()[0], select = self.current_directory)
 def VVdpx8(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVVu9v(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVMtuF)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVMtuF)
 def refresh(self):
  self.VV0Tr7(self.current_directory, self.VVdpx8())
 def VVMtuF(self, action, device):
  self.VVJur2()
  if self.current_directory is None:
   self.refresh()
 def VVkIai(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVwrlA : nameAlpMode, nameAlpTxt = self.VV5v1Y, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVwrlA, sAZ
  if mode == self.VVkFz6 : nameNumMode, nameNumTxt = self.VVozO7, s90
  else       : nameNumMode, nameNumTxt = self.VVkFz6, s09
  if mode == self.VVPibe : dateMode, dateTxt = self.VVg5xJ, sON
  else       : dateMode, dateTxt = self.VVPibe, sNO
  if mode == self.VVVhZN : typeMode, typeTxt = self.VV6Gs6, sZA
  else       : typeMode, typeTxt = self.VVVhZN, sAZ
  if   mode in (self.VVwrlA, self.VV5v1Y): txt = "Name (%s)" % (sAZ if mode == self.VVwrlA else sZA)
  elif mode in (self.VVkFz6, self.VVozO7): txt = "Name (%s)" % (s09 if mode == self.VVwrlA else s90)
  elif mode in (self.VVPibe, self.VVg5xJ): txt = "Date (%s)" % (sNO if mode == self.VVPibe else sON)
  elif mode in (self.VVVhZN, self.VV6Gs6): txt = "Type (%s)" % (sAZ if mode == self.VVVhZN else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVwwCm(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFcghP(CFG.browserSortMode, mode)
   FFcghP(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVJ53r() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVwrlA, self.VV5v1Y):
    rev = True if mode == self.VV5v1Y else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVkFz6, self.VVozO7):
    rev = True if mode == self.VVozO7 else False
    self.list = sorted(self.list[item0:], key=FFo3Is(BF(self.VV950r, isMix, rev)), reverse=rev)
   elif mode in (self.VVPibe, self.VVg5xJ):
    rev = True if mode == self.VVg5xJ else False
    self.list = sorted(self.list[item0:], key=FFo3Is(BF(self.VVDiXG, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VV6Gs6 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VV950r(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFvJTl(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFMKzN(dir2, dir1) or FFvJTl(name1, name2)
 def VVDiXG(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFMKzN(stat2.st_ctime, stat1.st_ctime)
    else : return FFMKzN(dir2, dir1) or FFMKzN(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCEdpz(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFUxcO(VVJN8J, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVouKi   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVKwLp(defFG, "#00FFFFFF")
  self.defBG   = self.VVKwLp(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFDBTO(self, self.Title)
  self["keyRed"].show()
  FFjeeE(self["keyGreen"] , "< > Transp.")
  FFjeeE(self["keyYellow"], "Foreground")
  FFjeeE(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVdhub     ,
   "green"   : self.VVdhub     ,
   "yellow"  : BF(self.VVVYya, False)  ,
   "blue"   : BF(self.VVVYya, True)  ,
   "up"   : self.VVCsIb       ,
   "down"   : self.VV3ZBv      ,
   "left"   : self.VVJXQv      ,
   "right"   : self.VV54hN      ,
   "last"   : BF(self.VVSfRt, -5) ,
   "next"   : BF(self.VVSfRt, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVzGCv)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF2A0B(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF2A0B(self["keyRed"] , c)
  FF2A0B(self["keyGreen"] , c)
  self.VVSst1()
  self.VVR07o()
  FFqst5(self["myColorTst"], self.defFG)
  FF2A0B(self["myColorTst"], self.defBG)
 def VVKwLp(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVR07o(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVfeb3(0, 0)
     return
 def VVdhub(self):
  self.close(self.defFG, self.defBG)
 def VVCsIb(self): self.VVfeb3(-1, 0)
 def VV3ZBv(self): self.VVfeb3(1, 0)
 def VVJXQv(self): self.VVfeb3(0, -1)
 def VV54hN(self): self.VVfeb3(0, 1)
 def VVfeb3(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVhZCe()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVcnnG()
 def VVSst1(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVcnnG(self):
  color = self.VVhZCe()
  if self.isBgMode: FF2A0B(self["myColorTst"], color)
  else   : FFqst5(self["myColorTst"], color)
 def VVVYya(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVSst1()
   self.VVR07o()
 def VVSfRt(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVfeb3(0, 0)
 def VVIiEe(self):
  return hex(self.transp)[2:].zfill(2)
 def VVhZCe(self):
  return ("#%s%s" % (self.VVIiEe(), self.colors[self.curRow][self.curCol])).upper()
class CC0VSe(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFUxcO(VVD6Qj, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFDBTO(self, title="%s%s%s" % (self.Title, " " * 10, FFf1xo("Change values with Up , Down, < , 0 , >", VVe79W)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVsJp0      ,
   "cancel" : self.VVTBnX      ,
   "info"  : self.VVwlFo    ,
   "red"  : self.VVBN8Y  ,
   "green"  : self.VVMn2E   ,
   "yellow" : BF(self.VVKhOa, 0)  ,
   "blue"  : self.VV5n91    ,
   "menu"  : self.VVmQ4M      ,
   "left"  : self.VVJXQv      ,
   "right"  : self.VV54hN      ,
   "last"  : self.VVqGeV     ,
   "next"  : self.VVSmeV     ,
   "0"   : self.VV1RF9    ,
   "up"  : self.VVCsIb       ,
   "down"  : self.VV3ZBv      ,
   "pageUp" : BF(self.VVtf9A, True) ,
   "pageDown" : BF(self.VVtf9A, False) ,
   "chanUp" : BF(self.VVtf9A, True) ,
   "chanDown" : BF(self.VVtf9A, False) ,
   "play"  : BF(self.VVuUi4, "pause")  ,
   "pause"  : BF(self.VVuUi4, "pause")  ,
   "playPause" : BF(self.VVuUi4, "pause")  ,
   "stop"  : BF(self.VVuUi4, "pause")  ,
   "audio"  : BF(self.VVuUi4, "audio")  ,
   "subtitle" : BF(self.VVuUi4, "subtitle") ,
   "rewind" : BF(self.VVuUi4, "rewind" ) ,
   "forward" : BF(self.VVuUi4, "forward" ) ,
   "rewindDm" : BF(self.VVuUi4, "rewindDm") ,
   "forwardDm" : BF(self.VVuUi4, "forwardDm")
  }, -1)
  self.VVgrO6()
  self.onShown.append(self.VVzGCv)
  self.onClose.append(self.VVpvY2)
 def VVgrO6(self):
  lst = []
  for fil in FF37hM(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VV3WSx:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVzGCv(self):
  self.onShown.remove(self.VVzGCv)
  FFjMgg(self)
  FFK8YM(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VVmZWk()
  self.VVgxit()
  self.VVx89H()
 def VVpvY2(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVt4yW(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FF2A0B(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVaKJC()
 def VVmZWk(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FF2A0B(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVsJp0(self):
  if self.settingShown:
   confItem = self.VVPB7S()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVv6X1 = []
   if isinstance(lst[0], tuple):
    for item in lst: VVv6X1.append((item[1], item[0]))
   else:
    for item in lst: VVv6X1.append((item, item))
   menuInstance = FFLwVh(self, self.VVwrpZ, VVv6X1=VVv6X1, width=700, title=title, VVyRL8="#33221111", VVmr0Y="#33110011")
   menuInstance.VVsnMy(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVwrpZ(self, item=None):
  if item:
   self.VVPB7S()[self.CursorPos].setValue(item)
   self.VVaKJC()
   self.VVgxit()
   self.VVxaMb(True)
 def VVTBnX(self):
  for confItem in self.VVPB7S():
   if confItem.isChanged():
    FFWkqs(self, self.VVZTGA, "Save Changes ?", callBack_No=self.VVRZ0n, title=self.Title)
    break
  else:
   if self.settingShown: self.VVmZWk()
   else    : self.close("subtExit")
 def VVmQ4M(self):
  if self.settingShown: self.VV8Glb()
  else    : self.VVt4yW()
 def VVJXQv(self): self.VVlwyN(-1)
 def VV54hN(self): self.VVlwyN(1)
 def VVlwyN(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVhClU()
   if pos == -1: ndx = self.VVxeWw(posVal)
   else  : ndx = self.VVVQya(posVal)
   if   ndx < 0      : FFfad8(self, "Not found" , 500)
   elif ndx == 0      : FFfad8(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFfad8(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVUvUo(frmSec)
    if allow:
     self.VVKhOa(delay, True)
     self.VVxaMb(force=True)
    else:
     FFfad8(self, "Delay out of range", 800)
 def VVtf9A(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVuUi4(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVqGeV(self) : self.VVkC06(5)
 def VVSmeV(self) : self.VVkC06(6)
 def VV1RF9(self) : self.VVkC06(-1)
 def VVCsIb(self):
  if self.settingShown: self.VVkC06(1)
  else    : self.VVtf9A(True)
 def VV3ZBv(self):
  if self.settingShown: self.VVkC06(0)
  else    : self.VVtf9A(False)
 def VVkC06(self, direction):
  if self.settingShown:
   confItem = self.VVPB7S()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVaKJC()
   self.VVgxit()
   self.VVxaMb(True)
 def VVPB7S(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVRZ0n(self):
  for confItem in self.VVPB7S(): confItem.cancel()
  self.VVaKJC()
  self.VVgxit()
  self.VVmZWk()
 def VVBN8Y(self):
  if self.settingShown:
   FFWkqs(self, self.VVAAbz, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVAAbz(self):
  for confItem in self.VVPB7S(): confItem.setValue(confItem.default)
  self.VVZTGA()
  self.VVaKJC()
  self.VVgxit()
 def VVKhOa(self, delay, force=False):
  if self.settingShown or force:
   FFcghP(CFG.subtDelaySec, delay)
   self.VVftho()
   self.VVaKJC()
   self.VVgxit()
   if self.settingShown:
    FFfad8(self, 'Reset to "0"', 800, isGrn=True)
 def VVMn2E(self):
  if self.settingShown:
   self.VVZTGA()
   self.VVmZWk()
 def VVZTGA(self):
  for confItem in self.VVPB7S(): confItem.save()
  configfile.save()
  self.VVftho()
  FFfad8(self, "Saved", 1000, isGrn=True)
 def VVaKJC(self):
  cfgLst = self.VVPB7S()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVgxit(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFuEOA(path, fnt, isRepl=1)
  else:
   fnt = VVRQSa
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFF1Ee(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFqst5(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FF2A0B(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFewIR(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFF1Ee(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFEnkn()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFrVM8(self, winW, winH)
 def VVwlFo(self):
  sp = "    "
  txt  = "%s\n"   % FFf1xo("Subtitle File:", VVKiZJ)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFf1xo("Subtitle Settings:", VVKiZJ)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVhClU()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFD88e(frmSec1)
   time2 = FFD88e(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFf1xo("Timing:", VVKiZJ)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFD88e(durVal)
   txt += sp + "Progress\t: %s\n" % FFD88e(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFf1xo("Subtitle end reached.", VV8tcv)
  FFipfq(self, txt, title="Current Subtitle")
 def VVx89H(self, path="", delay=0, enc=""):
  FF0rXP(self, BF(self.VV3ZB7, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VV3ZB7(self, path="", delay=0, enc=""):
  FFfad8(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVviWR(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVaKJC()
     self.VVwpc3()
   else:
    path, delay, enc = CC0VSe.VVgDgM(self)
    if path:
     self.VVx89H(path=path, delay=delay, enc=enc)
    else:
     self.VV8Glb()
  except:
   pass
 def VVwpc3(self):
  posVal, durVal = self.VVhClU()
  if self.VVxkb6(posVal):
   return
  CC0VSe.VVLbEk(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVxaMb)
  except:
   self.timerUpdate.callback.append(self.VVxaMb)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVLgyz)
  except:
   self.timerEndText.callback.append(self.VVLgyz)
  FFfad8(self, "Subtitle started", 700, isGrn=True)
 def VVxkb6(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CC0VSe.VVyS3o(self)
   FFsF1P(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV8Glb(self):
  c1, c2, c3, c4, c5 = "", VVKiZJ, VVq8cV, VVityU, VV8tcv
  VVv6X1 = []
  VVv6X1.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVv6X1.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVv6X1.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVv6X1.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVv6X1.append(VVdKVg)
   VVv6X1.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVv6X1.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVv6X1.append(VVdKVg)
   VVv6X1.append(("Help (Keys)"        , "help"  ))
  FFLwVh(self, self.VVACW0, VVv6X1=VVv6X1, width=700, title='Find Subtitle ".srt" File', VVyRL8="#33221111", VVmr0Y="#33110011")
 def VVACW0(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVpBJB(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVpBJB(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVjUHs, BF(CCOjzn, patternMode="srt", VVOgpG=sDir))
   elif item.startswith("sugSrt") : self.VVpBJB(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF0rXP(self, BF(CCzVQo.VVmOQL, self, self.lastSubtFile, self.VVLLUb, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFfad8(self, "SRT File error", 1000)
   elif item == "disab":
    FFsF1P(CC0VSe.VVyS3o(self))
    self.close("subtExit")
   elif item == "help"    : FFAqgP(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVLLUb(self, item=None):
  if item:
   FF0rXP(self, BF(self.VVx89H, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVjUHs(self, path):
  if path:
   FFcghP(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVx89H(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVpBJB(self, defSrt="", mode=0, coeff=0.25):
  FF0rXP(self, BF(self.VVbR8s, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVbR8s(self, defSrt="", mode=0, coeff=0.25):
  FFfad8(self)
  if mode == 1:
   srtList = CC0VSe.VVzJv8(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFqfZV('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFpy4F(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVpz9B(srtList, coeff)
     if err:
      if self.settingShown: FFfad8(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VV4Gbf = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFiSR4(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VV4Gbf.append((fName, Dir))
   VVXwx9  = ("Select"    , self.VVPCIp     , [])
   VVgYq4 = self.VVj7aA
   VVTMvN = (""     , self.VV7knV       , [])
   VVxKfW = (""     , BF(self.VV09Yo, defSrt, False) , [])
   VV6vKb = ("Find Current File" , BF(self.VV09Yo, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVw7oP=widths, VVcK4p=28, VVXwx9=VVXwx9, VVgYq4=VVgYq4, VVTMvN=VVTMvN, VVxKfW=VVxKfW, VV6vKb=VV6vKb, lastFindConfigObj=CFG.lastFindSubtitle
     , VVyRL8="#11002222", VVmr0Y="#33001111", VVOSNp="#33001111", VV5fad="#11ffff00", VVuQjw="#11445544", VVVwZb="#22222222", VVU8z2="#11002233")
  elif self.settingShown : FFfad8(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVj7aA(self, VVYo8S):
  VVYo8S.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VV7knV(self, VVYo8S, title, txt, colList):
  fName, Dir = colList
  FFipfq(VVYo8S, "%s\n\n%s%s" % (FFf1xo("Path:", VVKiZJ), Dir, fName), title=title)
 def VV09Yo(self, path, VVy0Oi, VVYo8S, title, txt, colList):
  for ndx, row in enumerate(VVYo8S.VVl6T3()):
   if path == row[1].strip() + row[0].strip():
    VVYo8S.VVG9tX(ndx)
    break
  else:
   if VVy0Oi:
    FFfad8(VVYo8S, "Not in list !", 1000)
 def VVPCIp(self, VVYo8S, title, txt, colList):
  VVYo8S.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVx89H(path=path)
 def VVpz9B(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8oCo.VVles6(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CC8oCo.VVmeWx(evName, "en")[0] or evName
   lst, err = CC0VSe.VVgDwC(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVviWR(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFDH0v(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFRtPk(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVZztL(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVQtCz(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVftho()
  return subtList, ""
 def VVQtCz(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVZztL(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVftho(self):
  path = CC0VSe.VVyS3o(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVxaMb(self, force=False):
  posVal, durVal = self.VVhClU()
  if self.VVxkb6(posVal):
   return
  curIndex = self.VVDTa7(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVLgyz()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFqst5(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVhClU(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCSeoi.VVcLwy(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8oCo.VVles6(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVDTa7(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVxeWw(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVVQya(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVLgyz(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFqst5(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VV5n91(self):
  FF0rXP(self, self.VVgGb1, title="Loading Lines ...", clearMsg=False)
 def VVgGb1(self):
  FFfad8(self)
  VV4Gbf = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VV4Gbf.append((cap, FFD88e(frm), str(frm), firstLine))
  if VV4Gbf:
   title = "Select Current Subtitle Line"
   VVCUH0  = self.VV8IWP
   VVgYq4 = self.VVjxAc
   VVXwx9  = ("Select"   , self.VV7ZAR , [title])
   VV6vKb = ("Current Line" , self.VVGmbv , [True])
   VVPogp = ("Reset Delay" , self.VVCF8Z , [])
   VVxkVZ = ("New Delay"  , self.VV4W8l   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVK4mA  = (CENTER , CENTER, CENTER , LEFT    )
   VVYo8S = FFl3hs(self, None, title=title, header=header, VVouKi=VV4Gbf, VVK4mA=VVK4mA, VVw7oP=widths, VVcK4p=28, VVCUH0=VVCUH0, VVgYq4=VVgYq4, VVXwx9=VVXwx9, VV6vKb=VV6vKb, VVPogp=VVPogp, VVxkVZ=VVxkVZ
          , VVyRL8="#33002222", VVmr0Y="#33001111", VVOSNp="#33110011", VV5fad="#11ffff00", VVuQjw="#0a334455", VVVwZb="#22222222", VVU8z2="#33002233")
  else:
   FFfad8(self, "Cannot read lines !", 2000)
 def VV8IWP(self, VVYo8S):
  self.subtLinesTable = VVYo8S
  if CFG.subtDelaySec.getValue():
   VVYo8S["keyYellow"].show()
   VVYo8S["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVYo8S["keyYellow"].hide()
  VVYo8S["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FF2A0B(VVYo8S["keyBlue"], "#22222222")
  VVYo8S.VVDhZV(BF(self.VVbEc1, VVYo8S))
  self.VVGmbv(VVYo8S, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVckYl)
  except:
   self.timerSubtLines.callback.append(self.VVckYl)
  self.timerSubtLines.start(1000, False)
 def VVjxAc(self, VVYo8S):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVYo8S.cancel()
 def VVckYl(self):
  if self.subtLinesTable:
   VVYo8S = self.subtLinesTable
   posVal, durVal = self.VVhClU()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVDTa7(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVYo8S.VVYyZ7(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVYo8S.VVLdUA(self.subtLinesTableNdx, row)
     row = VVYo8S.VVYyZ7(curIndex)
     row[0] = color + row[0]
     VVYo8S.VVLdUA(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VV7ZAR(self, VVYo8S, Title):
  delay, color, allow = self.VVgvaM(VVYo8S)
  if allow:
   self.VVjxAc(VVYo8S)
   self.VVKhOa(delay, True)
  else:
   FFfad8(VVYo8S, "Delay out of range", 1500)
 def VVGmbv(self, VVYo8S, VVy0Oi, onlyColor=False):
  if VVYo8S:
   posVal, durVal = self.VVhClU()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVDTa7(posVal)
    if curIndex > -1:
     VVYo8S.VVG9tX(curIndex)
    else:
     ndx = self.VVxeWw(posVal)
     if ndx > -1:
      VVYo8S.VVG9tX(ndx)
 def VVCF8Z(self, VVYo8S, title, txt, colList):
  if VVYo8S["keyYellow"].getVisible():
   self.VVKhOa(0, True)
   VVYo8S["keyYellow"].hide()
   self.VVGmbv(VVYo8S, False)
 def VVbEc1(self, VVYo8S):
  delay, color, allow = self.VVgvaM(VVYo8S)
  VVYo8S["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVgvaM(self, VVYo8S):
  lineTime = float(VVYo8S.VVK0Ui()[2].strip())
  return self.VVUvUo(lineTime)
 def VVUvUo(self, lineTime):
  posVal, durVal = self.VVhClU()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVkC8X
   else     : allow, color = False, VV8tcv
   delay = FF0CSz(val, -600, 600)
  return delay, color, allow
 def VV4W8l(self, VVYo8S, title, txt, colList):
  pass
 @staticmethod
 def VVydOM(SELF):
  path, delay, enc = CC0VSe.VVgDgM(SELF)
  return True if path else False
 @staticmethod
 def VVgDgM(SELF):
  path, delay, enc = CC0VSe.VV5SGG(SELF)
  if not path:
   path = CC0VSe.VVsBDA(SELF)
  return path, delay, enc
 @staticmethod
 def VV5SGG(SELF):
  srtCfgPath = CC0VSe.VVyS3o(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFRtPk(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVyS3o(SELF):
  fPath, fDir, fName = CCOjzn.VVb4Zf(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8oCo.VVles6(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFaQmC(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVsBDA(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCOjzn.VVb4Zf(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CC0VSe.VVzJv8(SELF)
    bLst, err = CC0VSe.VVgDwC(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVzJv8(SELF):
  fPath, fDir, fName = CCOjzn.VVb4Zf(SELF)
  if pathExists(fDir):
   files = FF37hM(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVgDwC(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVCBwf():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVLbEk(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CC0VSe.VVZjwW()
 @staticmethod
 def VVZjwW():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCKwgM(ScrollLabel):
 def __init__(self, parentSELF, text="", VVLG2k=True):
  ScrollLabel.__init__(self, text)
  self.VVLG2k   = VVLG2k
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVmT8F  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVcK4p    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVHYuf ,
   "green"   : self.VVryTQ ,
   "yellow"  : self.VVxqUq ,
   "blue"   : self.VVBHBi ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VV0XFk, 0) ,
   "0"    : BF(self.VV0XFk, 1) ,
   "next"   : BF(self.VV0XFk, 2) ,
   "pageUp"  : self.VVukDN   ,
   "chanUp"  : self.VVukDN   ,
   "pageDown"  : self.VVC6hA   ,
   "chanDown"  : self.VVC6hA
  }, -1)
 def VVUfQy(self, isResizable=True, VVjYPr=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFqst5(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FF2A0B(self.parentSELF["keyRedTop"], "#113A5365")
  FFjMgg(self.parentSELF, True)
  self.isResizable = isResizable
  if VVjYPr:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVcK4p  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF2A0B(self, color)
 def VVndIx(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVmT8F - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVyvQe()
 def pageUp(self):
  if self.VVmT8F > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVmT8F > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVukDN(self):
  self.setPos(0)
 def VVC6hA(self):
  self.setPos(self.VVmT8F-self.pageHeight)
 def VVBaR5(self):
  return self.VVmT8F <= self.pageHeight or self.curPos == self.VVmT8F - self.pageHeight
 def getText(self):
  return self.message
 def VVyvQe(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVmT8F, 3))
   start = int((100 - vis) * self.curPos / (self.VVmT8F - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVKhCn=VVKes2):
  old_VVBaR5 = self.VVBaR5()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   h = self.parentSELF.skinParam["bodyLineH"] * (len(self.message.splitlines()) + 1) - self.parentSELF.skinParam["marginTop"]
   h = max(h, self.long_text.calculateSize().height())
   self.VVmT8F = h if h > 0 else self.pageHeight
   if self.VVLG2k and self.VVmT8F > self.pageHeight:
    self.scrollbar.show()
    self.VVyvQe()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVmT8F))
   if   VVKhCn == VVW8Aw: self.setPos(0)
   elif VVKhCn == VVdsv6 : self.VVC6hA()
   elif old_VVBaR5    : self.VVC6hA()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVKhCn=VVKhCn)
 def appendText(self, text, VVKhCn=VVdsv6):
  self.setText(self.message + str(text), VVKhCn=VVKhCn)
 def VVxqUq(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV56Uw(size)
 def VVBHBi(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV56Uw(size)
 def VVryTQ(self):
  self.VV56Uw(self.VVcK4p)
 def VV56Uw(self, VVcK4p):
  self.long_text.setFont(gFont(self.fontFamily, VVcK4p))
  self.setText(self.message, VVKhCn=VVKes2)
  self.VVCO8f(calledFromFontSizer=True)
 def VV0XFk(self, align):
  self.long_text.setHAlign(align)
 def VVHYuf(self):
  VVv6X1 = []
  VVv6X1.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Align Left"  , "left" ))
  VVv6X1.append(("Align Center"  , "center" ))
  VVv6X1.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVv6X1.append(VVdKVg)
   VVv6X1.append((FFf1xo("Save to File", VVKiZJ), "save" ))
  VVv6X1.append(VVdKVg)
  VVv6X1.append(("Keys (Shortcuts)" , "help" ))
  FFLwVh(self.parentSELF, self.VV8nYT, VVv6X1=VVv6X1, title="Text Option", width=500)
 def VV8nYT(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VV0XFk(0)
   elif item == "center" : self.VV0XFk(1)
   elif item == "right" : self.VV0XFk(2)
   elif item == "save"  : self.VV5sH4()
   elif item == "help"  : FFAqgP(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VV5sH4(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFiSR4(expPath), self.outputFileToSave, FFWWBu())
   with open(outF, "w") as f:
    f.write(FFtomh(self.message))
   FFrNpu(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFRGBb(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVCO8f(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVmT8F > 0 and self.pageHeight > 0:
   if self.VVmT8F < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVmT8F
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
