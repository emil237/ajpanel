import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVO0ZM   = "v8.8.8"
VVCXFL    = "25-08-2023"
EASY_MODE    = 0
VVcWQh   = 0
VVuKBJ   = 0
VVe5fU  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVDVsC  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVkv1M   = "AJPan"
VVbCvh  = "AUTO FIND"
VVAiFv  = "Custom"
VVVcWE    = "/media/usb/"
VVHcpR    = "/usr/share/enigma2/picon/"
VVSs5p   = "/etc/enigma2/"
VVabb3   = VVSs5p + "settings"
VVrsN0 = VVSs5p + "blacklist"
VVyzBk  = None
VV7Xe7    = ""
VVgqhc = "Regular"
VV0LYI = "Fixed"
VVYijj  = "AJP_Main"
VVnza8 = "AJP_Terminal"
VVOR6M = "AJP_System"
VVa2lu  = VVgqhc
VVEQ0S    = ""
VVB6fx   = " && echo 'Successful' || echo 'Failed!'"
VVqTJi  = "Cannot continue (No Enough Memory) !"
VV1DvD  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVyASM    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVNrVP  = "utf8"
VVuAtK    = ("-" * 100, )
SEP      = "-" * 80
VVvct2  = False
VVT9SH  = False
VV35C4     = 0
VVSnw0    = 1
VVBxpZ    = 2
VVua82   = 3
VVWvtV    = 4
VV8Z1U    = 5
VVegdj = 6
VVj7jx = 7
VVC2sq  = 8
VVDgCl   = 9
VVXazS  = 10
VVpmGw  = 11
VViNNi = 12
VVMLDh = 13
VVKzh4 = 14
VVYPDO  = 15
VVPN5p    = 16
VVz6y3   = 17
VVYvQ9   = 18
VVZfrj    = 19
VVujZS    = 20
VV2PUu  = 21
VVDkmp    = 22
VVDdVy   = 0
VVEPk2   = 1
VVevDz   = 2
def FFcnL7():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVa2lu
  if VVYijj in lst and CFG.fontPathMain.getValue(): VVa2lu = VVYijj
  else               : VVa2lu = VVgqhc
  return lst
 else:
  return [VVgqhc]
def FFOTGs(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVNrVP)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVbCvh, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVHcpR, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVVcWE, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFeedPkgsDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVa2lu, choices=[(x,  x) for x in FFcnL7()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FF2sKc():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVNzDl  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV1dUs = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVNzDl  : return 0
  elif VV1dUs : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVTlMX = FF2sKc()
VV6rcy = VVlrJC = VVvrDy = VVeCLm = VVdSiQ = VVHH6F = VVA3Oc = VVFSYX = VVfPTB = VVuj5g = VVqZDD = VVdVoc = VVEhqe = VVmvsU = VVGdv9 = VViVXH = ""
def FFWvMH()  : FFd75E(FFNCIp())
def FFfJQe()  : FFd75E(FF8cuU())
def FFYjsY(tDict): FFd75E(iDumps(tDict, indent=4, sort_keys=True))
def FF5BDO(*args): FFn3cQ(True, True, *args)
def FFd75E(*args) : FFn3cQ(True , False , *args)
def FFvtGV(*args): FFn3cQ(False, False, *args)
def FFn3cQ(addSep=True, isArray=True, *args):
 if VVcWQh:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFWWn4(fnc):
 def VVhpOX(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFd75E(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVhpOX
def FFdKzF(*args):
 if VVcWQh:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFvtGV("Added to : %s" % path)
def FF0gaU(txt, isAppend=True, ignoreErr=False):
 if VVcWQh:
  tm = FFr4d7()
  err = ""
  if not ignoreErr:
   err = FF8cuU()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFd75E(err)
  FFd75E("Output Log File : %s" % fileName)
def FF8cuU():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFr4d7()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFNCIp():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV2xh9 = 0
def FFChS3():
 global VV2xh9
 VV2xh9 = iTime()
def FFxoWf(txt=""):
 FFd75E(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VV2xh9)).rstrip("0"), txt))
VVDzyL = []
def FFuz2Q(win):
 global VVDzyL
 if not win in VVDzyL:
  VVDzyL.append(win)
def FFKdOO(*args):
 global VVDzyL
 for win in VVDzyL:
  try:
   win.close()
  except:
   pass
 VVDzyL = []
def FFnsKm(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFxtTp():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV1yVM = FFxtTp()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF3tSz()    : return PluginDescriptor(fnc=FFup5I, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFbJg9()      : return getDescriptor(FFLBJ7  , [ PluginDescriptor.WHERE_MENU   ] , PLUGIN_NAME     , descr="Main Menu")
def FF8u2y()     : return getDescriptor(FFV2Dw   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFIyRT()  : return getDescriptor(FF4b7Y , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFhOQ3() : return getDescriptor(FF5FIO  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFY7kX()  : return getDescriptor(FFiZGn  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFmS14(): return getDescriptor(FFzEVz, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Plugin Browser"  , descr="Plugin Browser")
def FFiqtr()  : return getDescriptor(FFJb7k   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFi8py() : return getDescriptor(FFLf1U  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FF3TuP()      : return getDescriptor(FFsYZC , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF8u2y() , FFbJg9() , FF3tSz() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFIyRT())
  result.append(FFhOQ3())
  result.append(FFY7kX())
  result.append(FFmS14())
  result.append(FFiqtr())
  result.append(FFi8py())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF3TuP())
 return result
def FFup5I(reason, **kwargs):
 if reason == 0:
  CCb8LV.VVxgPn()
  if "session" in kwargs:
   session = kwargs["session"]
   FFyalq(session)
   CCWFaD(session)
def FFLBJ7(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFV2Dw, PLUGIN_NAME, 45)]
 else:
  return []
def FFV2Dw(session, **kwargs):
 session.open(Main_Menu)
def FF4b7Y(session, **kwargs) : session.open(CCf82q)
def FF5FIO(session, **kwargs)  : session.open(CC8Yh1)
def FFiZGn(session, **kwargs)  : CCqLbA.VVZoRN(session)
def FFzEVz(session, **kwargs): CC6KoU.VVHYF2(session)
def FFJb7k(session, **kwargs)   : FFUcYA(session, reopen=True)
def FFLf1U(session, **kwargs)  : session.open(CCLbFT)
def FFsYZC(session, **kwargs):
 session.open(CCscAN, fncMode=CCscAN.VVOJRT)
def FFMHiW():
 FFRFzg(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFIyRT(), FFhOQ3(), FFY7kX(), FFmS14(), FFiqtr(), FFi8py()])
 FFRFzg(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF3TuP() ])
def FFRFzg(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFyalq(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FF7KEn, session, "lok")
 hk.actions["longCancel"]= BF(FF7KEn, session, "lesc")
 hk.actions["longRed"] = BF(FF7KEn, session, "lred")
 for k in (CC67Fj.VV8l1s, CC67Fj.VVanl5, CC67Fj.VV32AD):
  hk.actions[k] = BF(CC67Fj.VVvVWx, session, k)
def FF7KEn(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCN4Do.VVNeYm:
    CCN4Do.VVNeYm.close()
   if not CCqLbA.VVoQCR:
    CCqLbA.VVZoRN(session)
  except:
   pass
def FFsMp0(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFTlW1(SELF, title="", addLabel=False, addScrollLabel=False, VVhIDJ=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFNcNO()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VV9a9t = eTimer()
 try: SELF.VVJf9Q = SELF.VV9a9t.timeout.connect(BF(FFNcFa, SELF))
 except: SELF.VV9a9t.callback.append(BF(FFNcFa, SELF))
 SELF.onClose.append(SELF.VV9a9t.stop)
 FFNcFa(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC7rq1(SELF)
 if VVhIDJ:
  SELF["myMenu"] = MenuList(VVhIDJ)
  SELF["myActionMap"] = ActionMap(VVyASM,
  {
   "ok" : SELF.VVYfT9 ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVyASM,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFNuVS(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFAdug, SELF, "0"),
  "1" : BF(FFAdug, SELF, "1"),
  "2" : BF(FFAdug, SELF, "2"),
  "3" : BF(FFAdug, SELF, "3"),
  "4" : BF(FFAdug, SELF, "4"),
  "5" : BF(FFAdug, SELF, "5"),
  "6" : BF(FFAdug, SELF, "6"),
  "7" : BF(FFAdug, SELF, "7"),
  "8" : BF(FFAdug, SELF, "8"),
  "9" : BF(FFAdug, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFm9B7, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFAdug(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VViVXH:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VViVXH + SELF.keyPressed + VVlrJC)
    txt = VVlrJC + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFM3N1(SELF, txt)
def FFm9B7(SELF, tableObj, colNum, isMenu):
 FFM3N1(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFpdHF(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVflXp(i)
     else  : SELF.VVj43f(i)
     break
 except:
  pass
def FFNcNO():
 return ("  %s" % VVEQ0S)
def FFMz2e(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFpdHF(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFwQZC(color):
 return parseColor(color).argb()
def FFqypJ(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFOrd9(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFqFT8(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFw0WV(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VViVXH)
 else:
  return ""
def FFYaeB(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VViVXH)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFwXwL(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VViVXH
def FFXA2w(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFw0WV(SEP, VVqZDD))
 else : return "echo -e '%s';" % SEP
def FF6F4t(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFwXwL(title, color)
def FFjM4Z(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFCkpW(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFbn1D(fncCB):
 tCons = CCeOtv()
 tCons.ePopen(":", BF(FFhFt1, fncCB))
def FFhFt1(fncCB, result, retval):
 fncCB()
def FFuMBP(SELF, fnc, title="Processing ...", clearMsg=True):
 FFM3N1(SELF, title)
 tCons = CCeOtv()
 tCons.ePopen(":", BF(FFUOQ8, SELF, fnc, clearMsg))
def FFUOQ8(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFM3N1(SELF)
def FFO9ap(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVqTJi
  else       : return ""
def FFpNiE(cmd):
 txt = FFO9ap(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFkd4T(cmd):
 lines = FFpNiE(cmd)
 if lines: return lines[0]
 else : return ""
def FF9STG(SELF, cmd):
 lines = FFpNiE(cmd)
 VVkNlM = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVkNlM.append((key, val))
  elif line:
   VVkNlM.append((line, ""))
 if VVkNlM:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFNCSP(SELF, None, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=28)
 else:
  FFJU8q(SELF, cmd)
def FFcZm9(cmd):
 return os.system(FFUGBP(cmd)) == 0
def FFQIMd(cmd):
 return os.system(FF5Yea(cmd)) == 0
def FFUGBP(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FF5Yea(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFJU8q(    SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVLcTO=True, VVCqdo=VVEPk2, **kwargs)
def FFzco6(  SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, **kwargs)
def FF1Ubx(   SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVB8vW=True, VVHWrU=True, VVCqdo=VVEPk2, **kwargs)
def FF8Tx8(  SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVB8vW=True, VVHWrU=True, VVCqdo=VVevDz, **kwargs)
def FFFPZ4(  SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVEd3y=True , **kwargs)
def FFCVEc(  session, cmd, **kwargs):      session.open(CCF7vX, VV0FrL=cmd, VVEd3y=True , **kwargs)
def FFmULY( SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVVcYg=True   , **kwargs)
def FFsji8( SELF, cmd, **kwargs): SELF.session.open(CCF7vX, VV0FrL=cmd, VVhCLY=True  , **kwargs)
def FFBf4e(cmd):
 return FFcZm9("which %s" % cmd)
def FFn597():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFkd4T(cmd)
def FF9R5Y(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVdMlb     = 0
VVHVEB      = 1
VVEidq   = 2
VVA9cR   = 3
VVREjx      = 4
VVEH2u      = 5
VVqBbR     = 6
VVZ14B     = 7
VVTdap     = 8
VVq2DR = 9
VVsUET = 10
VVitUq = 11
VVnSnN  = 12
VVdRQL     = 13
VVSwkt  = 14
VVTZQY  = 15
def FF2wdN(parmNum, grepTxt):
 if   parmNum == VVdMlb  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVHVEB   : param = ["list"   , "apt list"    ]
 elif parmNum == VVEidq: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVA9cR: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFn597()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFyOYr(parmNum, package):
 if   parmNum == VVREjx      : param = ["info"      , "apt show"         ]
 elif parmNum == VVEH2u      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVqBbR     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVZ14B     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVTdap     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVq2DR : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVsUET : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVitUq : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVnSnN  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVdRQL     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVSwkt  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVTZQY  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFn597()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFGFBz():
 result = FFkd4T("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFyOYr(VVTdap, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFUGBP("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFUGBP("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFw0WV(failed1, VVqZDD))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFw0WV(failed2, VVqZDD))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFw0WV(failed3, VVvrDy))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFJfZ1(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFyOYr(VVTdap , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFUGBP("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFw0WV(failed1, VVqZDD))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFw0WV(failed2, VVvrDy))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFQDOO(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCbony.VVp5ZV()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF9z80(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFQDOO(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFsPfZ(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFoQQd(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFQDOO(path, maxSize=maxSize, encLst=encLst)
  if lines: FF3nHt(SELF, lines, title=title, VVCqdo=VVEPk2, width=1600, height=1000, titleFontSize=30)
  else : FFQGz4(SELF, path, title=title)
 else:
  FFM8jr(SELF, path, title)
def FFYqxx(SELF, fName, title):
 path = VVobIL + fName
 if fileExists(path):
  txt = FFQDOO(path)
  txt = txt.replace("#W#", VViVXH)
  txt = txt.replace("#Y#", VVdVoc)
  txt = txt.replace("#G#", VVlrJC)
  txt = txt.replace("#C#", VVEhqe)
  txt = txt.replace("#P#", VVdSiQ)
  FF3nHt(SELF, txt, title=title)
 else:
  FFM8jr(SELF, path, title)
def FFUshp(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFO4Nw(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF77SS(parent)
 else    : return FFOE3h(parent)
def FFtnj1(path):
 return os.path.basename(os.path.normpath(path))
def FFoe8F(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFoQQd(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFzvzT(path):
 path = FFOE3h(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFS0NV(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFEwyA(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFZ5Mj(path):
 try: os.remove(path)
 except: pass
def FF3j5I(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFjbFj(path):
 return FFcZm9("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFGli3(path):
 return FFcZm9("cp -f '%s' '%s.bak'" % (path, path))
def FF77SS(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFOE3h(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFleqb():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVe5fU)
 paths.append(VVe5fU.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFUshp(ba)
 for p in list:
  p = ba + p + VVe5fU
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVkv1M, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVe5fU, VVkv1M , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVdqxv, VVobIL = FFleqb()
def FFjSyn():
 def VVkvQI(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVhbrH   = VVkvQI(CFG.backupPath, CCayJh.VViHmR())
 VVVCtk   = VVkvQI(CFG.downloadedPackagesPath, t)
 VV3R8j  = VVkvQI(CFG.exportedTablesPath, t)
 VVl7wT  = VVkvQI(CFG.exportedPIconsPath, t)
 VVV7sF   = VVkvQI(CFG.packageOutputPath, t)
 global VVVcWE
 VVVcWE = FF77SS(CFG.backupPath.getValue())
 if VVhbrH or VVV7sF or VVVCtk or VV3R8j or VVl7wT or oldMovieDownloadPath:
  configfile.save()
 return VVhbrH, VVV7sF, VVVCtk, VV3R8j, VVl7wT, oldMovieDownloadPath
def FF851E(path):
 path = FFOE3h(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFrin4(SELF, pathList, tarFileName, addTimeStamp=True):
 VVFWkP = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVFWkP.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVFWkP.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVFWkP.append(path)
 if not VVFWkP:
  FFB8Nz(SELF, "Files not found!")
 elif not pathExists(VVVcWE):
  FFB8Nz(SELF, "Path not found!\n\n%s" % VVVcWE)
 else:
  VVSbtQ = FF77SS(VVVcWE)
  tarFileName = "%s%s" % (VVSbtQ, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFERmH())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVFWkP:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFw0WV(tarFileName, VVfPTB))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFw0WV(failed, VVfPTB))
  cmd += "fi;"
  cmd +=  sep
  FFzco6(SELF, cmd)
def FFfgOw(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFdJ3C(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFdJ3C(SELF["keyInfo"], "info")
def FFdJ3C(barObj, fName):
 path = "%s%s%s" % (VVobIL, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFIxYe(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FF0QId(satNum)
  return satName
def FF0QId(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFeI49(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFIxYe(val)
  else  : sat = FF0QId(val)
 return sat
def FFPrtr(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFIxYe(num)
 except:
  pass
 return sat
def FFGFoO(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFWctZ(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFtI1N(info, iServiceInformation.sServiceref)
   prov = FFtI1N(info, iServiceInformation.sProvider)
   state = str(FFtI1N(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFrhBg(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFpqbA(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFtI1N(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFoeJu(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFvBDy(refCode):
 info = FFGsrp(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFKGMY(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFbyIO(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFGsrp(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVQHDq = eServiceCenter.getInstance()
  if VVQHDq:
   info = VVQHDq.info(service)
 return info
def FFtU9E(SELF, refCode, VVpkYJ=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFpqbA(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCwwJU()
  if pr.VVj8He(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVemSS(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFFprm(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVpkYJ:
   FFhrS2(SELF, isFromSession)
 try:
  VVOzoq = InfoBar.instance
  if VVOzoq:
   VVJK1Q = VVOzoq.servicelist
   if VVJK1Q:
    servRef = eServiceReference(refCode)
    VVJK1Q.saveChannel(servRef)
 except:
  pass
def FFFprm(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCwwJU()
    if pr.VVj8He(refCode, chName, decodedUrl, iptvRef):
     pr.VVemSS(SELF, isFromSession)
def FFrhBg(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFf209(ref):
 return "FROM BOUQUET " in ref.upper()
def FFzL2x(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFzKhS(url): return FF8tzC(url) or FFSKBc(url)
def FF8tzC(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFSKBc(url): return any(x in url for x in ("/series/", "mode=series"))
def FFpqbA(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFtaHD(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFtaHD(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFyoN9(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFNbl8(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFbClU(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF4nUF(txt):
 try:
  return FFNbl8(FFbClU(txt)) == txt
 except:
  return False
def FFjT7E(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF77SS(newPath), patt))
def FFhrS2(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not FFf209(servPath):
   isForPlayer = True
 if iptvRef or isForPlayer: CCqLbA.VVZoRN(session)
 else      : FFUcYA(session, reopen=True)
def FFUcYA(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFUcYA, session), CCN4Do)
  except:
   try:
    FFQhlG(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FF7Jqd(refCode):
 tp = CCpNxn()
 if tp.VV4v1g(refCode) : return True
 else        : return False
def FFuH1v(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFBOOj(True)
     return True
 return False
def FFBOOj(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFRTTB()
def FFRTTB():
 VVOzoq = InfoBar.instance
 if VVOzoq:
  VVJK1Q = VVOzoq.servicelist
  if VVJK1Q:
   VVJK1Q.setMode()
def FFxxyk(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVQHDq = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVQHDq.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFXAmG():
 VV2HRF = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVlyQB = list(VV2HRF)
 return VVlyQB, VV2HRF
def FF33DL():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFiwJD(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFzHDX(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFqUVM():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFERmH():
 return FFqUVM().replace(" ", "_").replace("-", "").replace(":", "")
def FFdy8f(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFr4d7():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFlHhH(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC8Yh1.VVYuLl(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC8Yh1.VV5TZE(fName)
     phpFile = tmpDir + fName + ext
     FFcZm9("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFt95z(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFW43m(num):
 return "s" if num > 1 else ""
def FFYuUY(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFdPXt(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFh6kh(a, b):
 return (a > b) - (a < b)
def FFrOKA(a, b):
 def VV2kEl(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV2kEl(a)
 b = VV2kEl(b)
 return (a > b) - (a < b)
def FF6Bhf(mycmp):
 class CC7ZGE(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CC7ZGE
def FFWB0Q(SELF, message, title="", VVLUmk=None):
 SELF.session.openWithCallback(VVLUmk, CCR9Hh, title=title, message=message, VVfTAX=True)
def FF3nHt(SELF, message, title="", VVCqdo=VVEPk2, VVLUmk=None, **kwargs):
 SELF.session.openWithCallback(VVLUmk, CCR9Hh, title=title, message=message, VVCqdo=VVCqdo, **kwargs)
def FFrf5q(SELF, txt):
 SELF.session.open(CC3yml, txt)
def FFB8Nz(SELF, message, title="")  : FFQhlG(SELF.session, message, title)
def FFM8jr(SELF, path, title="") : FFQhlG(SELF.session, "File not found !\n\n%s" % path, title)
def FFQGz4(SELF, path, title="") : FFQhlG(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF4L5V(SELF, title="")  : FFQhlG(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFQhlG(session, message, title="") : session.open(BF(CCwKQn, title=title, message=message))
def FFs37j(SELF, VVLUmk, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVLUmk, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVLUmk, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFB8Nz(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF5jVY(SELF, callBack_Yes, VVZNNf, callBack_No=None, title="", VVQk5i=False, VV3C0x=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFZodl, callBack_Yes, callBack_No)
         , BF(CCPshn, title=title, VVZNNf=VVZNNf, VV3C0x=VV3C0x, VVQk5i=VVQk5i))
def FFZodl(callBack_Yes, callBack_No, FF5jVYed):
 if FF5jVYed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFM3N1(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFOrd9(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VV9a9t.start(timeout, True)
  except: pass
 else: FFNcFa(SELF)
def FFkqUz(*kargs, **kwargs):
 FFbn1D(BF(FFM3N1, *kargs, **kwargs))
def FFNcFa(SELF):
 try:
  SELF.VV9a9t.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FF5tzJ(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFNCSP(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCajLx, **kwargs))
  else   : win = SELF.session.open(BF(CCajLx, **kwargs))
  FFuz2Q(win)
  return win
 except:
  return None
def FFRHhp(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCFDvX, **kwargs))
 FFuz2Q(win)
 return win
def FFw8eL(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFyXfa(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFcAqb(SELF, **kwargs):
 SELF.session.open(CCscAN, **kwargs)
def FF3wB4(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFnR2Y(SELF[name], "#000000", 3)
  except:
   pass
def FFnR2Y(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FF478Y(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVa2lu, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFH94q(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF478Y(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFYyVW(SELF, winSize.width(), winSize.height())
def FFYyVW(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFfZ8G():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFsuww(VVNWWl):
 screenSize  = FFfZ8G()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVNWWl)
 return bodyFontSize
def FFYlXF(VVNWWl, extraSpace):
 font = gFont(VVa2lu, VVNWWl)
 VV97fw = fontRenderClass.getInstance().getLineHeight(font) or (VVNWWl * 1.25)
 return int(VV97fw + VV97fw * extraSpace)
def FFMkht(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFfZ8G()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVa2lu, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFYlXF(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVa2lu, titleFontSize, alignLeftCenter)
 if winType == VVDkmp:
  pass
 elif winType in (VV35C4, VVSnw0):
  if winType == VVSnw0 : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VV2PUu:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVujZS:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVa2lu, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVPN5p:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFWB0QL = b2Left2 + timeW + marginLeft
  FFWB0QW = b2Left3 - marginLeft - FFWB0QL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFWB0QL , b2Top, FFWB0QW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVz6y3:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVWvtV:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVBxpZ:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVua82:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVa2lu, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVa2lu, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVXazS:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVa2lu, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVYvQ9:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVa2lu, fontH, alignCenter)
 elif winType in (VVpmGw, VViNNi, VVMLDh, VVKzh4, VVYPDO):
  if   winType == VVpmGw  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VViNNi : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVMLDh : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVKzh4 : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVpmGw:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVa2lu, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVa2lu, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVa2lu, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVa2lu, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVa2lu, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVa2lu, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVa2lu, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVZfrj:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV8Z1U:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVj7jx : align = alignLeftCenter
  elif winType == VVegdj : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVDgCl:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVa2lu
  if usefixedFont and winType == VVegdj:
   fLst = FFcnL7()
   if   VVnza8 in fLst and CFG.fontPathTerm.getValue(): fontName = VVnza8
   elif VV0LYI in fLst         : fontName = VV0LYI
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVNWWl = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVa2lu, VVNWWl, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVa2lu, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VV1DvD[i], VVa2lu, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVegdj:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV1DvD[i], VVa2lu, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVnZi1 = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVO0ZM)
  VVhIDJ = []
  if VVuKBJ:
   VVhIDJ.append(("-- MY TEST --", "myTest" ))
  VVhIDJ.append(("File Manager"  , "fMan" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("IPTV"    , "iptv" ))
  VVhIDJ.append(("Movies Browser" , "movie" ))
  VVhIDJ.append(("Services/Channels", "chan" ))
  VVhIDJ.append(("Bouquet Editor" , "bouq" ))
  VVhIDJ.append(("PIcons"   , "picon" ))
  VVhIDJ.append(("EPG"    , "epg"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Terminal"   , "term" ))
  VVhIDJ.append(("SoftCam"   , "soft" ))
  VVhIDJ.append(("Plugins"   , "plug" ))
  VVhIDJ.append(("Backup & Restore" , "bakup" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Date/Time"  , "date" ))
  VVhIDJ.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVhIDJ):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVhIDJ[ndx] = tuple(item)
  FFTlW1(self, title=self.Title, VVhIDJ=VVhIDJ)
  FFMz2e(self["keyRed"] , "Exit")
  FFMz2e(self["keyGreen"] , "Settings")
  FFMz2e(self["keyYellow"], "Dev. Info.")
  FFMz2e(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VV5h1W      ,
   "yellow": self.VVVoWI      ,
   "blue" : self.VVbL5O     ,
   "info" : BF(FFuMBP, self, self.VVIgdf) ,
   "text" : self.VVmoSG      ,
   "menu" : self.VVlMjN    ,
   "0"  : BF(self.VVAnI0, 0)   ,
   "1"  : BF(self.VVE2L9, "fMan")   ,
   "2"  : BF(self.VVE2L9, "iptv")   ,
   "3"  : BF(self.VVE2L9, "movie")   ,
   "4"  : BF(self.VVE2L9, "chan")   ,
   "5"  : BF(self.VVE2L9, "bouq")   ,
   "6"  : BF(self.VVE2L9, "picon")   ,
   "7"  : BF(self.VVE2L9, "epg")   ,
   "8"  : BF(self.VVE2L9, "term")   ,
   "9"  : BF(self.VVE2L9, "soft")   ,
   "last" : BF(self.VVE2L9, "plug")   ,
   "next" : BF(self.VVE2L9, "bakup")
  })
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
  global VVvct2, VVT9SH, VViG77
  VVvct2 = VVT9SH = False
  VViG77 = True
 def VVYfT9(self):
  self.VVE2L9(self["myMenu"].l.getCurrentSelection()[1])
 def VVE2L9(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVEQ0S
   VVEQ0S = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVJVFm()
   elif item == "fMan"  : self.session.open(CCf82q)
   elif item == "iptv"  : self.session.open(CC8Yh1)
   elif item == "movie" : FFuMBP(self, BF(CCr3DN.VVYU0F, self))
   elif item == "chan"  : self.session.open(CCn3v3)
   elif item == "bouq"  : self.session.open(CCod57)
   elif item == "picon" : self.VVNge0()
   elif item == "epg"  : self.session.open(CCwOKQ)
   elif item == "term"  : self.session.open(CCLbFT)
   elif item == "soft"  : self.session.open(CC1coX)
   elif item == "plug"  : self.session.open(CCxLZd)
   elif item == "bakup" : self.session.open(CCZvl2)
   elif item == "date"  : self.session.open(CCUz6Y)
   elif item == "net"  : self.session.open(CCmUs0)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
  FF3wB4(self)
  FFfgOw(self)
  VVhbrH, VVV7sF, VVVCtk, VV3R8j, VVl7wT, oldMovieDownloadPath = FFjSyn()
  if VVhbrH or VVV7sF or VVVCtk or VV3R8j or VVl7wT or oldMovieDownloadPath:
   VVnxYh = lambda path, subj: "%s:\n%s\n\n" % (subj, FFwXwL(path, VVeCLm)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVnxYh(VVhbrH   , "Backup/Restore Path"    )
   txt += VVnxYh(VVV7sF  , "Created Package Files (IPK/DEB)" )
   txt += VVnxYh(VVVCtk  , "Download Packages (from feeds)" )
   txt += VVnxYh(VV3R8j , "Exported Tables"     )
   txt += VVnxYh(VVl7wT , "Exported PIcons"     )
   txt += VVnxYh(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FF3nHt(self, txt, title="Settings Paths")
  self.VV0IHZ()
  if (EASY_MODE or VVcWQh or VVuKBJ):
   FFOrd9(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFM3N1(self, "Welcome", 300)
  FFbn1D(self.VV7cl8)
 def VV7cl8(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCayJh.VV6Tqq()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFcZm9("rm -f /tmp/ajp_*")
  global VVvct2, VVT9SH
  VVvct2 = VVT9SH = False
  FFnsKm("VViG77")
 def VVAnI0(self, digit):
  self.VVnZi1 += str(digit)
  ln = len(self.VVnZi1)
  global VVvct2
  if ln == 4:
   if self.VVnZi1 == "0" * ln:
    VVvct2 = True
    FFOrd9(self["myTitle"], "#11805040")
   else:
    self.VVnZi1 = "x"
 def VVmoSG(self):
  self.VVnZi1 += "t"
  if self.VVnZi1 == "0" * 4 + "t" * 2:
   global VVT9SH
   VVT9SH = True
   FFOrd9(self["myTitle"], "#dd5588")
 def VVNge0(self):
  found = False
  pPath = CCTdjW.VVJwSu()
  if pathExists(pPath):
   for fName, fType in CCTdjW.VVSXaF(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCTdjW)
  else:
   VVhIDJ = []
   VVhIDJ.append(("PIcons Tools" , "CCTdjW" ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(CCTdjW.VVAH5i())
   VVhIDJ.append(VVuAtK)
   VVhIDJ += CCTdjW.VVe7Kq()
   FFRHhp(self, self.VV9DZ9, VVhIDJ=VVhIDJ)
 def VV9DZ9(self, item=None):
  if item:
   if   item == "CCTdjW"   : self.session.open(CCTdjW)
   elif item == "VVTELK"  : CCTdjW.VVTELK(self)
   elif item == "VVUCmM"  : CCTdjW.VVUCmM(self)
   elif item == "findPiconBrokenSymLinks" : CCTdjW.VVFpAj(self, True)
   elif item == "FindAllBrokenSymLinks" : CCTdjW.VVFpAj(self, False)
 def VVIgdf(self):
  changeLogFile = VVobIL + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF9z80(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFwXwL("\n%s\n%s\n%s" % (SEP, line, SEP), VVqZDD, VViVXH)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFwXwL(line, VVlrJC, VViVXH)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF3nHt(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVO0ZM, PLUGIN_DESCRIPTION), VVNWWl=28, width=1600, height=1000, VVHZxf="#11000011")
 def VVlMjN(self):
  VVhIDJ = []
  VVhIDJ.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Keys Help"     , "hlp" ))
  FFRHhp(self, self.VV3f2I, VVhIDJ=VVhIDJ, width=650, title="Options")
 def VV3f2I(self, item=None):
  if item:
   if   item == "libr" : FFuMBP(self, BF(self.VVxEWL))
   elif item == "hlp" : FFYqxx(self, "_help_main", "Main Page (Keys Help)")
 def VV5h1W(self) : self.session.open(CCayJh)
 def VVVoWI(self) : self.session.open(CCQSOE)
 def VVbL5O(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVuj5g, VVeCLm, VVdVoc, VVHH6F
  VVhIDJ = []
  VVhIDJ.append((c1 + "Change Title Colors"   , "title"  ))
  VVhIDJ.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVhIDJ.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVhIDJ.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVhIDJ.append((c2 + "Reset Colors"    , "resetColor" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVhIDJ.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c4 + "Change System Font"    , "sysFont"  ))
  FFRHhp(self, BF(self.VVGLuo, title), VVhIDJ=VVhIDJ, width=600, title=title)
 def VVGLuo(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV2CcQ()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVOTOy, tDict, item), CC6wQD, defFG=fg, defBG=bg)
   elif item == "resetColor" : FF5jVY(self, self.VVUg56, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVgclz(VVYijj  )
   elif item == "termFont"  : self.VVgclz(VVnza8)
   elif item == "sysFont"  : self.VVgclz(VVOR6M  )
 def VVxEWL(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVkNlM = self.VV2lti()
  VVlrMb = ("Install", BF(self.VVpdBV, title)    , [])
  VV1FeB  = ("Update Sys. Packages", self.VVFO1w , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVrLHE = (LEFT  , CENTER , LEFT  )
  VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, width=1350, VVlrMb=VVlrMb, VV1FeB=VV1FeB, VVgLJ3="#00ffffaa", VVUMPl=1)
 def VVpdBV(self, Title, VVhqv2, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVKrSx, VVhqv2)
   pkgDict = self.VVFFO3()
   pkg = colList[0]
   if   pkg == "requests" : CCskCr.VVztta(self, cbFnc=cbFnc)
   elif pkg == "Imaging" : CC67Fj.VVoxRi(self, Title, False, cbFnc=cbFnc)
   elif pkg == "ar"  : FFFPZ4(self, FFGFBz(), VVE46B=cbFnc, title=Title)
   elif pkg in pkgDict  : FFFPZ4(self, FFJfZ1(pkgDict[pkg], pkg, pkg.capitalize()), VVE46B=cbFnc, title=Title)
  else:
   FFM3N1(VVhqv2, "Already installed.", 700, isGrn=True)
 def VVFO1w(self, VVhqv2, title, txt, colList):
  CCxLZd.VVUETr(self)
 def VVKrSx(self, VVhqv2):
  VVkNlM = self.VV2lti()
  VVhqv2.VVuBFc(VVkNlM[VVhqv2.VVHqmL()])
 def VV2lti(self):
  tDict = {}
  path = VVobIL + "_sup_lib"
  if fileExists(path):
   for line in FF9z80(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVnxYh(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFwXwL("Installed", VVfPTB), txt)
   else : return (lib, FFwXwL("Not installed", VVvrDy), txt)
  VVkNlM = []
  VVkNlM.append(VVnxYh("requests", CCskCr.VVztta(self, install=False)))
  VVkNlM.append(VVnxYh("Imaging" , CC67Fj.VVoxRi(self, "", False, install=False)))
  VVkNlM.append(VVnxYh("ar"   , CCxLZd.VVbkVT()))
  for pkg, cmd in self.VVFFO3().items(): VVkNlM.append(VVnxYh(pkg, FFBf4e(cmd)))
  VVkNlM.sort(key=lambda x: x[0].lower())
  return VVkNlM
 def VVFFO3(self):
  d = {}
  for pkg in ("xz", "zip", "p7zip", "unrar", "bzip2", "ffmpeg"):
   d[pkg] = pkg
  d["p7zip"] = "7za"
  return d
 def VVlEE2(self):
  return VVVcWE + "ajpanel_colors"
 def VV2CcQ(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVlEE2()
  if fileExists(p):
   txt = FFQDOO(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVOTOy(self, tDict, item, fg, bg):
  if fg:
   self.VVWbUF(item, fg)
   self.VV7iES(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVIOEU(tDict)
 def VVIOEU(self, tDict):
   p = self.VVlEE2()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVWbUF(self, item, fg):
  if   item == "title" : FFqypJ(self["myTitle"], fg)
  elif item == "body"  :
   FFqypJ(self["myMenu"], fg)
   FFqypJ(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFqypJ(self[item], fg)
 def VV7iES(self, item, bg):
  if   item == "title" : FFOrd9(self["myTitle"], bg)
  elif item == "body"  :
   FFOrd9(self["myMenu"], bg)
   FFOrd9(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFOrd9(self["myBar"], bg)
 def VVUg56(self):
  FFcZm9("rm '%s'" % self.VVlEE2())
  self.close()
 def VV0IHZ(self):
  tDict = self.VV2CcQ()
  for item in ("title", "body", "cursor", "bar"):
   self.VVSF5W(tDict, item)
 def VVSF5W(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVWbUF(name, fg)
  if bg: self.VV7iES(name, bg)
 def VVgclz(self, which):
  if   which == VVYijj  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVnza8 : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVOR6M  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CC3Fqq.VVTL2O(self, "Change %s Font" % title, defFnt, rest, BF(self.VVDvtK, which))
 def VVDvtK(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVYijj  : FFsMp0(CFG.fontPathMain, path)
   elif which == VVnza8: FFsMp0(CFG.fontPathTerm, path)
   elif which == VVOR6M  : FFsMp0(CFG.fontPathSys , path)
   err = Main_Menu.VVr491(which)
   if err          : FFB8Nz(self, err, title=title)
   elif which == VVYijj   : self.close()
   elif which == VVnza8  : FFM3N1(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVOR6M and path: FFM3N1(self, "System font applied", 1500, isGrn=True)
   elif which == VVOR6M   : FF5jVY(self, BF(Main_Menu.VVVcYg, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVVcYg(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVr491(name):
  if   name == VVYijj : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVnza8: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVOR6M : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFcnL7()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVOR6M:
   nameLst = []
   for nm in FFcnL7():
    if not nm in (VVYijj, VVnza8):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFOTGs(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFcnL7()
  else    : return "Could not add font"
 def VVJVFm(self):
  self.session.open(CCod57)
class CCmUs0(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVVcWE, "ajpanel_network")
  c1, c2 = VVdVoc, VVuj5g
  VVhIDJ = []
  VVhIDJ.append((c1 + "Network Devices"     , "dev" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Network Scanner (ping)"    , "ping"))
  VVhIDJ.append(("Port Scanner (scan for famous ports)" , "port"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Check Internet Connection"  , "intr"))
  FFTlW1(self, title="Network Tools", VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFuMBP(self, self.VVFQlX, title="Reading Devices ...")
  elif item == "ping" : FFuMBP(self, self.VVF7ny, title="Scanning ...")
  elif item == "port" : CCBOP8.VVkNur(self, self.VVyjOQ, title="Select host to scan")
  elif item == "intr" : self.session.open(CC1VLk)
 def VVFQlX(self, canCencel=False):
  title = "Network Devices"
  VVkNlM = self.VVVh9n()
  if VVkNlM:
   bg = "#0a223333"
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVPEsb = BF(self.VVrg7r, canCencel)
   VVlUqf  = ("Start FTP"   , self.VVf1Hv    , [])
   VVkGmL = ("Entry Options"  , self.VVIbWF  , [])
   VV1FeB = ("Scan for Devices" , self.VVEpyM , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVrLHE = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, width=1500, height=900, VVN1SU=widths, VVNWWl=28, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVkGmL=VVkGmL, VV1FeB=VV1FeB
       , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVgLJ3="#11ffff00", VVSzMt="#11220000", VVvy9F="#00333333", VVRt6l="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVhqv2.VVj43f(ndx)
  else:
   FF5jVY(self, BF(FFuMBP, self, BF(self.VVH6wU, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVrg7r, canCencel), title=title)
 def VVIbWF(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(("Change Username"   , "user"))
  VVhIDJ.append(("Change Password"   , "pass"))
  VVhIDJ.append(("Change Remarks"   , "rem"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Remove Selected Server" , "del"))
  FFRHhp(self, BF(self.VV2zAX, VVhqv2), VVhIDJ=VVhIDJ, title="Entry Options")
 def VV2zAX(self, VVhqv2, item=None):
  if item:
   if   item == "user" : self.VVzqbj("u", VVhqv2)
   elif item == "pass" : self.VVzqbj("p", VVhqv2)
   elif item == "rem" : self.VVzqbj("r", VVhqv2)
   elif item == "del" : FF5jVY(self, BF(FFuMBP, self, BF(self.VVpmkN, VVhqv2), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVrg7r(self, canCencel, VVhqv2=None):
  if VVhqv2: VVhqv2.cancel()
  if canCencel : self.close()
 def VVf1Hv(self, VVhqv2, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFsMp0(CFG.lastNetworkDevice, VVhqv2.VVHqmL())
  self.session.openWithCallback(BF(self.VVCK5j, entry, VVhqv2), CCPh8t, entry)
 def VVCK5j(self, entry, VVhqv2, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVlrWJ("d", newPath, ip, u, p, path, rem)
    self.VVCG3f(VVhqv2)
 def VVEpyM(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVH6wU, mainTableInst=VVhqv2), title="Scanning Network ...")
 def VVH6wU(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCBOP8.VVdBzU(CCBOP8.VVaBl0)
  if err:
   FFB8Nz(self, err, title=title)
   return
  telLst, err = CCBOP8.VVdBzU(CCBOP8.VVmJBR)
  if err:
   FFB8Nz(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VV4fWU(p1, p2): return FFrOKA(p1[0], p2[0])
   lst.sort(key=FF6Bhf(VV4fWU))
   bg = "#0a202020"
   VVPEsb = BF(self.VVrg7r, canCencel)
   VVlUqf  = ("Add to Devices" , BF(self.VVgDoN, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVrLHE = (LEFT   , CENTER  , CENTER  )
   FFNCSP(self, None, title=title, header=header, VVFWkP=lst, VVrLHE=VVrLHE, VVN1SU=widths, width=1200, VVNWWl=30, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVUMPl=2
     , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#0a225555", VVRt6l="#11403040")
  else:
   FFB8Nz(self, "No devices found !", title=title)
 def VVF7ny(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCBOP8.VVdBzU(-1)
  if err:
   FFB8Nz(self, err, title=title)
  elif lst:
   def VV4fWU(p1, p2): return FFrOKA(p1[0], p2[0])
   lst.sort(key=FF6Bhf(VV4fWU))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVrLHE = (LEFT   , LEFT   )
   FFNCSP(self, None, title=title, header=header, VVFWkP=lst, VVrLHE=VVrLHE, VVN1SU=widths, width=1000, height=700, VVNWWl=30
     , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#0a225555", VVRt6l="#11403040")
  else:
   FFB8Nz(self, "Network scanning failed !", title=title)
 def VVyjOQ(self, ip=None):
  if ip:
   FFuMBP(self, BF(self.VV3P5g, ip), title="Scanning %s" % ip)
 def VV3P5g(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCBOP8.VVASFI(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCBOP8.VVnUqs(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FF3nHt(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVVh9n(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFQDOO(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VV4fWU(p1, p2): return FFrOKA(p1[0], p2[0])
  tLst.sort(key=FF6Bhf(VV4fWU))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVgDoN(self, mainTableInst, canCencel, VVhqv2, title, txt, colList):
  ip, mac, typ = VVhqv2.VVregv(VVhqv2.VVHqmL())
  if "Own" in ip:
   FFM3N1(VVhqv2, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVVh9n():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FF3j5I(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVnWzB(ip, u, p, path, rem))
   if mainTableInst: self.VVCG3f(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVFQlX(canCencel)
   VVhqv2.cancel()
 def VVnWzB(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVpmkN(self, VVhqv2):
  num, ip, u, p, path, rem = VVhqv2.VVregv(VVhqv2.VVHqmL())
  lst = self.VVVh9n()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVnWzB(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVCG3f(VVhqv2)
  else:
   VVhqv2.cancel()
 def VVzqbj(self, col, VVhqv2):
  num, ip, u, p, path, rem = VVhqv2.VVregv(VVhqv2.VVHqmL())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFs37j(self, BF(self.VVAAss, col, orig, VVhqv2, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVAAss(self, col, orig, VVhqv2, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFM3N1(VVhqv2, "No change", 1500)
   elif not newTxt and col == "u":
    FFM3N1(VVhqv2, "No user !", 2000)
   else:
    self.VVlrWJ(col, newTxt, ip, u, p, path, rem)
    self.VVCG3f(VVhqv2)
 def VVlrWJ(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVVh9n()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVnWzB(ip1, u1, p1, path1, rem1))
 def VVCG3f(self, VVhqv2, newEntry=None):
  VVkNlM = self.VVVh9n()
  if VVkNlM : VVhqv2.VVartp(VVkNlM, tableRefreshCB=BF(self.VVUJKt, newEntry))
  else  : VVhqv2.cancel()
 def VVUJKt(self, newEntry, VVhqv2, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVhqv2.VVOazu()):
    if row[1:] == newEntry:
     VVhqv2.VVj43f(ndx)
 def VVrg7r(self, canCencel, VVhqv2=None):
  if VVhqv2: VVhqv2.cancel()
  if canCencel : self.close()
class CCBOP8():
 VVaBl0 = 21
 VVmJBR = 23
 def __init__(self):
  self.VVEI5h()
 def VVEI5h(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VV2LLJ(self, ip, User, Pass, timeout=5):
  myIp = CCBOP8.VVYGeJ()
  if ip != myIp:
   if CCBOP8.VVnUqs(ip, CCBOP8.VVaBl0):
    self.VVEI5h()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVCviD(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVEdQj(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VV3Qho(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVEdQj()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV2TSZ(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVljFb(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VV32iu(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VV9FnF(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVAEKL(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VV9FnF()
   if self.VV32iu(path) : typ = "d"
   else      : typ = "b"
   self.VV32iu(curDir)
   return typ
 def VVDbgt(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VV32iu(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVfLLu(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVKnpc(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVfr1X(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVIrVP(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVDbgt(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFZ5Mj(locFile)
   return "", sz, str(e)
 def VVZl9G(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVEI5h()
 @staticmethod
 def VVYZic():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVYGeJ():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVeS1W():
  myIp = CCBOP8.VVYGeJ()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VV5tB7():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFkd4T("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VV5orI(port=-1):
  lst = []
  def VVlfuJ(ip):
   if port > -1: ok = CCBOP8.VVnUqs(ip, port)
   else  : ok = CCBOP8.VVASFI(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCBOP8.VVeS1W()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVlfuJ, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVdBzU(port):
  myIp = CCBOP8.VVYGeJ()
  myGw = CCBOP8.VV5tB7()
  tDict = { myIp: CCBOP8.VVYZic() }
  devLst, err = CCBOP8.VV5orI(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFO9ap("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVdVoc
    elif key == myGw: txt = " %s Gateway" % VVdVoc
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVASFI(ip):
  return FFcZm9("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVnUqs(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVk4Hv(ip="1.1.1.1", timeout=1):
  if CCBOP8.VVnUqs(ip, 53, timeout):
   return True
  if CCBOP8.VVASFI(ip):
   return True
  return FFcZm9("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVkNur(SELF, okFnc, title):
  baseIp = CCBOP8.VVeS1W()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFRHhp(SELF, okFnc, VVhIDJ=lst, width=600, title=title, VVl9AY="#222222", VVLICL="#222222")
class CCPh8t(Screen, CCBOP8):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFMkht(VV35C4, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVNWWl  = self.skinParam["bodyFontSize"]
  self.VV97fw  = self.skinParam["bodyLineH"]
  self.VVsRxY  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCuvev.VVddI8("fil")
  self.png_dir  = CCuvev.VVddI8("dir")
  self.png_dirup  = CCuvev.VVddI8("dirup")
  self.png_slwfil  = CCuvev.VVddI8("slwfil")
  self.png_slbfil  = CCuvev.VVddI8("slbfil")
  self.png_slwdir  = CCuvev.VVddI8("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCBOP8.__init__(self)
  VVhIDJ = [("Item-%d" % x,) for x in range(50)]
  FFTlW1(self, title=self.Title, VVhIDJ=VVhIDJ)
  FFMz2e(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVhIDJ, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVa2lu, self.VVNWWl))
  self["myMenu"].l.setItemHeight(self.VV97fw)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "red" : BF(self.VVslRd, True) ,
   "ok" : self.VVYfT9    ,
   "cancel": self.VVslRd    ,
   "menu" : self.VV8ivh   ,
   "info" : self.VVL1qx  ,
   "pageUp": self.VVuw2a    ,
   "chanUp": self.VVuw2a
  })
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVAf2x)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
  FF3wB4(self)
  FFfgOw(self)
  FFOrd9(self["keyBlue"], "#11333333")
  FFuMBP(self, self.VVkVfr, title="Connecting ...")
 def VVkVfr(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VV2LLJ(ip, u, p)
  if err:
   FFB8Nz(self, err, title=self.Title)
   FFMz2e(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFMz2e(self["keyBlue"], self.ftpIp)
   if not self.VV32iu(path):
    path = "/"
   self.VV2vbP(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVEdQj():
   self.VVZl9G()
 def VVYfT9(self):
  if self.VVi0aU():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VV2vbP(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVuw2a()
    else         : self.VVXtkH(os.path.join(self.curDir, name))
 def VVslRd(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVuw2a()
 def VVi0aU(self):
  if self.VVEdQj():
   return True
  else:
   FFB8Nz(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVXtkH(self, path):
  cat = self.VVsatM(path)
  if cat in ("pic"):
   FFuMBP(self, BF(self.VVAlMJ, path))
  elif cat in ("mov", "mus"):
   if CC8Yh1.VVk5Uy("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFuMBP(self, BF(CCf82q.VV8VtC, self, url, rType=rType), title="Playing Media ...")
 def VVAlMJ(self, path):
  locFile, size, err = self.VVIrVP(path)
  if err: FFB8Nz(self, err, title="View Picture File")
  else  : CCuhvG.VVqol3(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFZ5Mj))
 def VVAf2x(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCuvev.VVGrI2 else sel[0][0])
  else  : title=  VVvrDy + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVuw2a(self):
  if self.VVi0aU():
   lastPart = FFtnj1(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VV2vbP(parentDir, lastPart, "d")
 def VV2vbP(self, Dir, moveTo="", moveToType=""):
  FFuMBP(self, BF(self.VVSyWy, Dir, moveTo, moveToType))
 def VVSyWy(self, Dir, moveTo, moveToType):
  files, err = self.VVljFb(Dir, isLong=True)
  self.curDir = self.VV9FnF() or "/"
  self.VVHl97(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVHl97(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVRWnO(CCuvev.VVGrI2, CCuvev.VVGrI2, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVAEKL(target)
    color = VVvrDy if targetState == "b" else VVfPTB
    origName = name + VVqZDD + linkSep + color + " "+ target
   self.list.append(self.VVRWnO(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVRWnO(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVsatM(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVobIL, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCuvev.VVGrI2: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV97fw + 10, 0, self.VVsRxY, self.VV97fw, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCajLx.VVG9jM(0, 2, self.VV97fw-4, self.VV97fw-4, png))
  return tableRow
 def VVsatM(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCuvev.VVO8mQ().items():
    if ext in lst:
     return cat
  return ""
 def VV8ivh(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCuvev.VVGrI2
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVKNFf(titl, ref, chk, color=""):
   if chk: return VVhIDJ.append((color + titl, ref))
   else  : return VVhIDJ.append((titl, ))
  VVhIDJ = []
  VVKNFf("Properties", "VVL1qx", not isTop)
  c = VVdVoc
  VVhIDJ.append(VVuAtK)
  VVKNFf("Download Selected File ..."    , "FFlHhHFromServer", isFile, c)
  VVKNFf("Upload a Local File to Remote Server ...", "VVjj6Y" , True  , c)
  VVhIDJ.append(VVuAtK)
  VVKNFf("Create new directory", "VV9NHH", True)
  VVKNFf("Rename", "VVEzip", not isTop)
  VVKNFf("DELETE", "VVk7i0", not isTop, VVdSiQ)
  VVhIDJ.append(VVuAtK)
  VVKNFf("FTP Server Information", "VVXxJx", True)
  VVhIDJ.append(VVuAtK)
  VVKNFf("Refresh File List", "refresh", True)
  FFRHhp(self, self.VVNPaw, VVhIDJ=VVhIDJ, title="Options")
 def VVNPaw(self, item=None):
  if item:
   if   item == "VVL1qx"     : self.VVL1qx()
   elif item == "FFlHhHFromServer"   : self.FFlHhHFromServer()
   elif item == "VVjj6Y"   : self.VVjj6Y()
   elif item == "VV9NHH"   : self.VV9NHH()
   elif item == "VVEzip"   : self.VVEzip()
   elif item == "VVk7i0"   : self.VVk7i0()
   elif item == "VVXxJx"    : self.VVXxJx()
   elif item == "refresh" and self.VVi0aU(): self.VV2vbP(self.curDir)
 def VVL1qx(self):
  if self.VVi0aU():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFwXwL("Path", VVdVoc), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVDbgt(path)
    if sz > -1: txt += "Size\t: %s" % CCf82q.VVeeDD(sz)
   else:
    txt = "Nothing selected"
   FF3nHt(self, txt, title="Properties")
 def VVXxJx(self):
  if self.VVi0aU():
   Sys  = self.VVCviD() or " -"
   txt = "%s\n  %s\n\n" % (FFwXwL("System:", VVdVoc), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV2TSZ() or " -"
   txt += "%s\n" % (FFwXwL("Status:", VVdVoc))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FF3nHt(self, txt, title="FTP Server Information")
 def VV9NHH(self, name=""):
  if self.VVi0aU():
   title = "Add New Directory"
   FFs37j(self, BF(self.VVJW2x, title), defaultText=name, title=title, message="Enter Directory name")
 def VVJW2x(self, title, name):
  if name and name.strip():
   if self.VVfLLu(name) : self.VV2vbP(self.curDir, name, "d")
   else     : FFB8Nz(self, "Failed to create : %s" % name, title)
 def VVEzip(self):
  if self.VVi0aU():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFs37j(self, BF(self.VVtenr, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVtenr(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVfr1X(name, newName.strip()) : self.VV2vbP(self.curDir, newName, flag)
   else          : FFB8Nz(self, "Failed to rename to : %s" % newName, title)
 def VVk7i0(self):
  if self.VVi0aU():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FF5jVY(self, BF(FFuMBP, self, BF(self.VVbE3l, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVbE3l(self, name, flag):
  if self.VVKnpc(name, flag) : self.VV2vbP(self.curDir)
  else         : FFB8Nz(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFlHhHFromServer(self):
  if self.VVi0aU():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVDbgt(remFile)
    if size == -1:
     FFB8Nz(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVVcWE
     self.session.openWithCallback(BF(self.VVauVY, title, remFile, name, size), BF(CCf82q, mode=CCf82q.VVa1qF, VV5Ab4="Download here", VVQzCM=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVauVY(self, title, remFile, name, size, locPath):
  if locPath:
   FFsMp0(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVAzbx, remFile, size, locFile)
       , VVLUmk = BF(self.VVa936, remFile, size, locFile))
 def VVAzbx(self, remFile, size, locFile, VVVRSv):
  VVVRSv.VVWtjR(size)
  VVVRSv.VVPpbS = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVeKUU(data):
     if not VVVRSv or VVVRSv.isCancelled:
      return
     locFileObj.write(data)
     VVVRSv.VVBQzv(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVeKUU)
   except Exception as e:
    VVVRSv.VVPpbS = str(e)
 def VVa936(self, remFile, size, locFile, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVPpbS:
   FFB8Nz(self, "%s\n\nftp:/%s" % (VVPpbS, remFile), title="Download Error")
   delF = True
  elif not VVVUTO:
   FFB8Nz(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFoQQd(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFWB0Q(self, txt, title=title)
   else:
    FFB8Nz(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFZ5Mj(locFile)
 def VVjj6Y(self):
  if self.VVi0aU():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVVcWE
   self.session.openWithCallback(self.VV43A3, BF(CCf82q, VV5Ab4="Upload selected file", VVQzCM=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VV43A3(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFsMp0(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFoQQd(locFile)
   if size == -1:
    FFB8Nz(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVkd5m, locFile, size, remFile)
        , VVLUmk = BF(self.VV0U17, locFile, size, remFile))
 def VVkd5m(self, locFile, size, remFile, VVVRSv):
  VVVRSv.VVWtjR(size)
  VVVRSv.VVPpbS = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVt59g(data):
     if not VVVRSv or VVVRSv.isCancelled:
      VVVRSv.VVPpbS = "Upload cancelled"
      locFileObj.close()
      return
     VVVRSv.VVBQzv(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVt59g)
   except Exception as e:
    VVVRSv.VVPpbS = VVVRSv.VVPpbS or str(e)
 def VV0U17(self, locFile, size, remFile, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVVUTO:
   if size == FFoQQd(locFile) : FFWB0Q(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVPpbS : err = "%s\n\n%s" % (VVPpbS, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFB8Nz(self, err, title=title)
   self.VV3Qho()
   self.VVKnpc(remFile, "")
  self.VV2vbP(self.curDir)
class CC67Fj():
 VV8l1s  = "all"
 VVanl5 = "vid"
 VV32AD  = "osd"
 @staticmethod
 def VVvVWx(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFBf4e("grab"):
    winShown = session.current_dialog.shown
    if k == CC67Fj.VVanl5 and winShown: session.current_dialog.hide()
    FFbn1D(BF(CC67Fj.VV8Art, title, session, k, winShown))
   else:
    FFQhlG(session, "No Grab command !", title=title)
 @staticmethod
 def VV8Art(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC67Fj.VV32AD:
   if not winShown:
    FFQhlG(session, "No Window to capture !", title=title)
    return
   if not CC67Fj.VVoxRi(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC67Fj.VVtxyr(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFQhlG(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FF77SS(CFG.exportedPIconsPath.getValue()), fTitle, FFERmH(), ext)
  ok = FFQIMd("grab -q -s %s > '%s'" % (typ, path))
  if k == CC67Fj.VVanl5 and winShown:
   session.current_dialog.show()
  elif k == CC67Fj.VV32AD:
   ok = CC67Fj.VVNQUf(path, x, y, w, h)
   if not ok:
    FFZ5Mj(path)
    FFQhlG(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCuhvG, title=path, VVmyei=path))
  else      : FFQhlG(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVoxRi(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FF5jVY(SELF, BF(CC67Fj.VVb1p8, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVb1p8(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFCVEc, VVE46B=cbFnc)
  else    : fnc = BF(FFFPZ4 , VVE46B=cbFnc)
  fnc(SELF, FFyOYr(VVTdap, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVtxyr(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVNQUf(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFfZ8G()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFdPXt(x , 0, scrW, 0, w)
     y  = FFdPXt(y , 0, scrH, 0, h)
     x1 = FFdPXt(x1, 0, scrW, 0, w)
     y1 = FFdPXt(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVEJxm(path):
  size = FFoQQd(path)
  sizeTxt = CCf82q.VVeeDD(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CC3Fqq(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFMkht(VV35C4, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFwXwL(" (Requires GUI Restart)", VVHH6F) if withRestart else ""
  VVhIDJ = []
  for path in self.fontsList:
   VVhIDJ.append((os.path.splitext(os.path.basename(path))[0], path))
  VVhIDJ.sort(key=lambda x: x[0].lower())
  VVhIDJ.insert(0, VVuAtK)
  VVhIDJ.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVhIDJ):
    if len(item) == 2 and item[1] == self.defFnt:
     VVhIDJ[ndx] = (VVfPTB + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVhIDJ[curIndex] = (VVfPTB + VVhIDJ[curIndex][0], VVhIDJ[curIndex][1])
  FFTlW1(self, VVhIDJ=VVhIDJ, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
  self["myBar"].setText(self.VViIAo())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVLFdc)
  self.VVLFdc()
 def VVYfT9(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVLFdc(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFOTGs(path, fnt, isRepl=1)
  else:
   fnt = VVgqhc
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VViIAo(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVTL2O(SELF, title, defFnt, rest, VVLUmk):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFjT7E(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVLUmk, CC3Fqq, title, fontsList, defFnt, rest)
  else  : FFB8Nz(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CC45Bc(Screen):
 def __init__(self, session, path, VVhIDJ, title):
  self.skin, self.skinParam = FFMkht(VV35C4, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFTlW1(self, VVhIDJ=VVhIDJ, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok"  : self.VVYfT9   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVBlP9,
   "chanUp" : self.VVBlP9,
   "pageDown" : self.VVlBoU ,
   "chanDown" : self.VVlBoU ,
  }, -1)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
  FFOrd9(self["myLabelFrm"], "#11110000")
  FFOrd9(self["myLabelTit"], "#11663322")
  FFOrd9(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVlQIc)
  self.VVlQIc()
 def VVlQIc(self):
  if fileExists(self.path): txt = FFQDOO(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVYfT9(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVBlP9(self) : self["myMenu"].moveToIndex(0)
 def VVlBoU(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCbony():
 @staticmethod
 def VVp5ZV():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV9Yt8(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFNCSP(SELF, None, VVFWkP=lst, VVNWWl=30, VVUMPl=1)
 @staticmethod
 def VVMjuP(path, SELF=None):
  for enc in CCbony.VVp5ZV():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFB8Nz(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVwQZq(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVjI7F(SELF, path, cbFnc, curEnc=VVNrVP, title="Select Encoding"):
  lst = CCbony.VV0Uky(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CC45Bc, path, lst, title)
 @staticmethod
 def VV5IFB(SELF, cbFnc, curEnc=VVNrVP, title="Select Encoding"):
  lst = CCbony.VV0Uky(SELF, "", "")
  if lst:
   FFRHhp(SELF, cbFnc, title=title, VVhIDJ=lst, width=1000, height=1000, VVl9AY="#22220000", VVLICL="#22220000", VVWLSA=True)
 @staticmethod
 def VV0Uky(SELF, path, curEnc):
  lst = CCbony.VViwLn(path)
  if lst:
   VVhIDJ = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVfPTB
    elif enc == VVNrVP: c = VVqZDD
    else      : c = ""
    VVhIDJ.append((c + txt, enc))
   return VVhIDJ
  else:
   FFkqUz(SELF, "No proper encoding", 2000)
 @staticmethod
 def VViwLn(path=""):
  encLst = []
  cPath = VVobIL + "_sup_codecs"
  if fileExists(cPath):
   lines = FF9z80(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCbony.VVp5ZV())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCQSOE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhIDJ = []
  VVhIDJ.append(("Settings File"   , "SettingsFile"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Box Info"     , "VVRcoC"   ))
  VVhIDJ.append(("Tuners Info"    , "VVtOct"  ))
  VVhIDJ.append(("Python Version"   , "VVfhZc"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Screen Size"    , "ScreenSize"   ))
  VVhIDJ.append(("Language/Locale"   , "Locale"    ))
  VVhIDJ.append(("Processor"    , "Processor"   ))
  VVhIDJ.append(("Operating System"   , "OperatingSystem"  ))
  VVhIDJ.append(("Drivers"     , "drivers"    ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("System Users"    , "SystemUsers"   ))
  VVhIDJ.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVhIDJ.append(("Uptime"     , "Uptime"    ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Host Name"    , "HostName"   ))
  VVhIDJ.append(("MAC Address"    , "MACAddress"   ))
  VVhIDJ.append(("Network Configuration" , "NetworkConfiguration"))
  VVhIDJ.append(("Network Status"   , "NetworkStatus"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Disk Usage"    , "VVFrMU"   ))
  VVhIDJ.append(("Mount Points"    , "MountPoints"   ))
  VVhIDJ.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVhIDJ.append(("USB Devices"    , "USB_Devices"   ))
  VVhIDJ.append(("List Block-Devices"  , "listBlockDevices" ))
  VVhIDJ.append(("Directory Size"   , "DirectorySize"  ))
  VVhIDJ.append(("Memory"     , "Memory"    ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVhIDJ.append(("Running Processes"  , "RunningProcesses" ))
  VVhIDJ.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFTlW1(self, VVhIDJ=VVhIDJ, title="Device Information")
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CC8diT)
   elif item == "VVRcoC"   : self.VVRcoC()
   elif item == "VVtOct"  : self.VVtOct()
   elif item == "VVfhZc"  : self.VVfhZc()
   elif item == "ScreenSize"   : FF3nHt(self, "Width\t: %s\nHeight\t: %s" % (FFfZ8G()[0], FFfZ8G()[1]))
   elif item == "Locale"    : CCbony.VV9Yt8(self)
   elif item == "Processor"   : self.VVJpnt()
   elif item == "OperatingSystem"  : FFJU8q(self, "uname -a")
   elif item == "drivers"    : self.VV7Qgc()
   elif item == "SystemUsers"   : FFJU8q(self, "id")
   elif item == "LoggedInUsers"  : FFJU8q(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFJU8q(self, "uptime")
   elif item == "HostName"    : FFJU8q(self, "hostname")
   elif item == "MACAddress"   : self.VVQX1p()
   elif item == "NetworkConfiguration" : FFJU8q(self, "ifconfig %s %s" % (FFw0WV("HWaddr", VVGdv9), FFw0WV("addr:", VVqZDD)))
   elif item == "NetworkStatus"  : FFJU8q(self, "netstat -tulpn", VVNWWl=24, consFont=True)
   elif item == "VVFrMU"   : self.VVFrMU()
   elif item == "MountPoints"   : FFJU8q(self, "mount %s" % (FFw0WV(" on ", VVqZDD)))
   elif item == "FileSystemTable"  : FFJU8q(self, "cat /etc/fstab", VVNWWl=24, consFont=True)
   elif item == "USB_Devices"   : FFJU8q(self, "lsusb")
   elif item == "listBlockDevices"  : FFJU8q(self, "blkid")
   elif item == "DirectorySize"  : FFJU8q(self, "du -shc /* 2>/dev/null | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVj7dF="Reading size ...")
   elif item == "Memory"    : FFJU8q(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVgAVh()
   elif item == "RunningProcesses"  : FFJU8q(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFJU8q(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVl2Bk()
   else        : self.close()
 def VVQX1p(self):
  res = FFO9ap("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF3nHt(self, txt)
  else:
   FFJU8q(self, "ip link")
 def VVdRvk(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFpNiE(cmd)
  return lines
 def VVahBA(self, lines, headerRepl, widths, VVrLHE):
  VVkNlM = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVkNlM.append(parts)
  if VVkNlM and len(header) == len(widths):
   VVkNlM.sort(key=lambda x: x[0].lower())
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVUMPl=1)
   return True
  else:
   return False
 def VVFrMU(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFO9ap(cmd)
  if not "invalid option" in txt:
   lines  = self.VVdRvk(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVrLHE = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVahBA(lines, headerRepl, widths, VVrLHE)
  else:
   cmd = "df -h"
   lines  = self.VVdRvk(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVrLHE = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVahBA(lines, headerRepl, widths, VVrLHE)
  if not allOK:
   lines = FFpNiE(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFOE3h(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVfPTB:
     note = "\n%s" % FFwXwL("Green = Mounted Partitions", VVfPTB)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVqZDD
     elif line.endswith(mountList) : color = VVfPTB
     else       : color = VVlrJC
     txt += FFwXwL(line, color) + "\n"
    FF3nHt(self, txt + note)
   else:
    FFB8Nz(self, "Not data from system !")
 def VVgAVh(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVdRvk(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVrLHE = (LEFT , CENTER, LEFT )
  allOK = self.VVahBA(lines, headerRepl, widths, VVrLHE)
  if not allOK:
   FFJU8q(self, cmd)
 def VV7Qgc(self):
  cmd = FF2wdN(VVEidq, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFJU8q(self, cmd)
  else : FF4L5V(self)
 def VVJpnt(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFJU8q(self, cmd)
 def VVl2Bk(self):
  cmd = FF2wdN(VVHVEB, "| grep secondstage")
  if cmd : FFJU8q(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF4L5V(self)
 def VVRcoC(self):
  c = VVfPTB
  VVFWkP = []
  VVFWkP.append((FFwXwL("Box Type"  , c), FFwXwL(self.VVnCLK("boxtype").upper(), c)))
  VVFWkP.append((FFwXwL("Board Version", c), FFwXwL(self.VVnCLK("board_revision") , c)))
  VVFWkP.append((FFwXwL("Chipset"  , c), FFwXwL(self.VVnCLK("chipset")  , c)))
  VVFWkP.append((FFwXwL("S/N"   , c), FFwXwL(self.VVnCLK("sn")    , c)))
  VVFWkP.append((FFwXwL("Version"  , c), FFwXwL(self.VVnCLK("version")  , c)))
  VVjk7S   = []
  VVsHeX = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVsHeX = SystemInfo[key]
     else:
      VVjk7S.append((FFwXwL(str(key), VVEhqe), FFwXwL(str(SystemInfo[key]), VVEhqe)))
  except:
   pass
  if VVsHeX:
   VVXkQ8 = self.VVm1LX(VVsHeX)
   if VVXkQ8:
    VVXkQ8.sort(key=lambda x: x[0].lower())
    VVFWkP += VVXkQ8
  if VVjk7S:
   VVjk7S.sort(key=lambda x: x[0].lower())
   VVFWkP += VVjk7S
  if VVFWkP:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFNCSP(self, None, header=header, VVFWkP=VVFWkP, VVN1SU=widths, VVNWWl=28, VVUMPl=1)
  else:
   FF3nHt(self, "Could not read info!")
 def VVnCLK(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF9z80(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVm1LX(self, mbDict):
  try:
   mbList = list(mbDict)
   VVFWkP = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVFWkP.append((FFwXwL(subject, VVqZDD), FFwXwL(value, VVqZDD)))
  except:
   pass
  return VVFWkP
 def VVtOct(self):
  txt = self.VVIXKr("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVIXKr("/proc/bus/nim_sockets")
  if not txt: txt = self.VVjFwX()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF3nHt(self, txt)
 def VVjFwX(self):
  txt = ""
  VVnxYh = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVnxYh("Slot Name" , slot.getSlotName())
     txt += FFwXwL(slotName, VVqZDD)
     txt += VVnxYh("Description"  , slot.getFullDescription())
     txt += VVnxYh("Frontend ID"  , slot.frontend_id)
     txt += VVnxYh("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVIXKr(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF9z80(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFwXwL(line, VVqZDD)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVfhZc(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF3nHt(self, txt)
 @staticmethod
 def VVaBEc():
  def VVnxYh(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVnxYh(v,0), "/etc/issue.net": VVnxYh(v,1), "/etc/image-version": VVnxYh(v,2)}
  for p1, d in v.items():
   img = CCQSOE.VVA13P(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVnxYh(v,0), p + "Plugins/": VVnxYh(v,1), VVDVsC: VVnxYh(v,2), VVe5fU: VVnxYh(v,3)}
  for p1, d in v.items():
   img = CCQSOE.VVnFZt(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVA13P(path, d):
  if fileExists(path):
   txt = FFQDOO(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVnFZt(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CC8diT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhIDJ = []
  VVhIDJ.append(("Settings (All)"   , "Settings_All"   ))
  VVhIDJ.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVhIDJ.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVhIDJ.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVhIDJ.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVhIDJ.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVhIDJ.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVT9SH:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVhIDJ.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %s" % VVabb3
   grep = " | grep "
   if   item == "Settings_All"   : FFJU8q(self, cmd)
   elif item == "Settings_HotKeys"  : FFJU8q(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFJU8q(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFJU8q(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFJU8q(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFJU8q(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFJU8q(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFJU8q(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFJU8q(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CC1coX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVwU3Z, VVMBM4, VV1guo, camCommand = CC1coX.VV6rSU()
  self.VVMBM4 = VVMBM4
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVMBM4:
   c = VVuj5g if VV1guo else VVmvsU
   if   "oscam" in VVMBM4 : camName, oC = "OSCam", c
   elif "ncam"  in VVMBM4 : camName, nC = "NCam" , c
  VVhIDJ = []
  VVhIDJ.append(("OSCam Files" , "OSCamFiles" ))
  VVhIDJ.append(("NCam Files" , "NCamFiles" ))
  VVhIDJ.append(("CCcam Files" , "CCcamFiles" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((VVdVoc + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VV71wT" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVhIDJ.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVhIDJ.append(VVuAtK)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVhIDJ.append(FFyXfa(txt, "camInfo", VVMBM4, c))
  VVhIDJ.append(VVuAtK)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVMBM4:
   for item in camLst: VVhIDJ.append(item)
  else:
   for item in camLst: VVhIDJ.append((item[0], ))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCOllY, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCOllY, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCOllY, "cccam"))
   elif item == "VV71wT" : self.VV71wT()
   elif item == "OSCamReaders"  : self.VVoaJ1("os")
   elif item == "NSCamReaders"  : self.VVoaJ1("n")
   elif item == "camInfo"   : FF9STG(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CC1coX.VVWkqU(self.session, CCbZat.VViyUH)
   elif item == "camLiveReaders" : CC1coX.VVWkqU(self.session, CCbZat.VVpoOr)
   elif item == "camLiveLog"  : CC1coX.VVWkqU(self.session, CCbZat.VVejJQ)
   else       : self.close()
 def VV71wT(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVVcWE, FFERmH())
  if fileExists(path):
   lines = FF9z80("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVnxYh = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVnxYh("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVnxYh("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVnxYh("protocol"   , "cccam"))
      f.write(VVnxYh("device"    , "%s,%s" % (host, port)))
      f.write(VVnxYh("user"    , User))
      f.write(VVnxYh("password"   , Pass))
      f.write(VVnxYh("fallback"   , "1"))
      f.write(VVnxYh("group"    , "64"))
      f.write(VVnxYh("cccversion"   , "2.3.2"))
      f.write(VVnxYh("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFWB0Q(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFW43m(tot), outFile))
   else:
    FFM3N1(self, "No valid CCcam lines", 1500)
  else:
   FFM3N1(self, "%s not found" % path, 1500)
 def VVoaJ1(self, camPrefix):
  VVkNlM = self.VV3PEr(camPrefix)
  if VVkNlM:
   VVkNlM.sort(key=lambda x: int(x[0]))
   if self.VVMBM4 and self.VVMBM4.startswith(camPrefix):
    VVlrMb = ("Toggle State", self.VVJp38, [camPrefix], "Changing State ...")
   else:
    VVlrMb = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVrLHE  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlrMb=VVlrMb, VVJcAk=True)
 def VV3PEr(self, camPrefix):
  readersFile = self.VVwU3Z + camPrefix + "cam.server"
  VVkNlM = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF9z80(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVkNlM.append((str(len(VVkNlM) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVkNlM:
    FFB8Nz(self, "No readers found !")
  else:
   FFM8jr(self, readersFile)
  return VVkNlM
 def VVJp38(self, VVhqv2, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVwU3Z, camPrefix)
  readerState  = VVhqv2.VV26F4(1)
  readerLabel  = VVhqv2.VV26F4(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC1coX.VVxtmF(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVhqv2.VV0Sa3()
    FFB8Nz(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVkNlM = self.VV3PEr(camPrefix)
   if VVkNlM:
    VVhqv2.VVartp(VVkNlM)
  else:
   VVhqv2.VV0Sa3()
 @staticmethod
 def VVxtmF(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF9z80(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFB8Nz(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFB8Nz(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFM8jr(SELF, confFile)
   return None
  if not iRequest:
   FFB8Nz(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CC1coX.VV0r6H(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFB8Nz(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VV0r6H(SELF):
  if iElem:
   return True
  else:
   FFB8Nz(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVWkqU(session, VVlcJO):
  VVwU3Z, VVMBM4, VV1guo, camCommand = CC1coX.VV6rSU()
  if VVMBM4:
   runLog = False
   if   VVlcJO == CCbZat.VViyUH : runLog = True
   elif VVlcJO == CCbZat.VVpoOr : runLog = True
   elif not VV1guo          : FFQhlG(session, message="SoftCam not started yet!")
   elif fileExists(VV1guo)        : runLog = True
   else             : FFQhlG(session, message="File not found !\n\n%s" % VV1guo)
   if runLog:
    session.open(BF(CCbZat, VVwU3Z=VVwU3Z, VVMBM4=VVMBM4, VV1guo=VV1guo, VVlcJO=VVlcJO))
  else:
   FFQhlG(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VV6rSU():
  VVwU3Z = "/etc/tuxbox/config/"
  VVMBM4 = None
  VV1guo  = None
  camCommand = FFkd4T("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVMBM4 = "oscam"
   elif camCmd.startswith("ncam") : VVMBM4 = "ncam"
  if VVMBM4:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     fTxt = FFQDOO(path)
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", fTxt, IGNORECASE)
     if span:
      VVwU3Z = FF77SS(span.group(1))
      var = "$CAMNAME"
      if var in VVwU3Z:
       span = iSearch(r'CAMNAME="(.+)"', fTxt, IGNORECASE)
       if span:
        VVwU3Z = VVwU3Z.replace(var, span.group(1))
      break
   else:
    path = FFkd4T(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF77SS(path)
    if pathExists(path):
     VVwU3Z = path
   tFile = FF77SS(VVwU3Z) + VVMBM4 + ".conf"
   tFile = FFkd4T("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VV1guo = tFile
  return VVwU3Z, VVMBM4, VV1guo, camCommand
class CCOllY(Screen):
 def __init__(self, VVApIb, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVwU3Z, VVMBM4, VV1guo, camCommand = CC1coX.VV6rSU()
  if   VVApIb == "ncam" : self.prefix = "n"
  elif VVApIb == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVhIDJ = []
  if self.prefix == "":
   VVhIDJ.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVhIDJ.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVhIDJ.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVhIDJ.append(("constant.cw"         , "x_constant_cw" ))
   VVhIDJ.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVhIDJ.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVhIDJ.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVhIDJ.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVhIDJ.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVhIDJ.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVhIDJ.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVhIDJ.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVhIDJ.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVhIDJ.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVhIDJ.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFsPfZ(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFsPfZ(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFsPfZ(self, self.VVwU3Z + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFsPfZ(self, self.VVwU3Z + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVKtp9("cam.ccache")
   elif item == "x_cam_conf"  : self.VVKtp9("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVKtp9("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVKtp9("cam.provid")
   elif item == "x_cam_server"  : self.VVKtp9("cam.server")
   elif item == "x_cam_services" : self.VVKtp9("cam.services")
   elif item == "x_cam_srvid2"  : self.VVKtp9("cam.srvid2")
   elif item == "x_cam_user"  : self.VVKtp9("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVdtTw()
   elif item == "x_CCcam_cfg"  : FFsPfZ(self, self.VVwU3Z + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFsPfZ(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFsPfZ(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFsPfZ(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVKtp9(self, fileName):
  FFsPfZ(self, self.VVwU3Z + self.prefix + fileName)
 def VVdtTw(self):
  path = self.VVwU3Z + "SoftCam.Key"
  if fileExists(path) : FFsPfZ(self, path)
  else    : FFsPfZ(self, path.replace(".Key", ".key"))
class CCbZat(Screen):
 VViyUH  = 0
 VVpoOr = 1
 VVejJQ = 2
 def __init__(self, session, VVwU3Z="", VVMBM4="", VV1guo="", VVlcJO=VViyUH):
  self.skin, self.skinParam = FFMkht(VVegdj, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV1guo   = VV1guo
  self.VVlcJO  = VVlcJO
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVwU3Z + VVMBM4 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVMBM4 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVwU3Z, self.camPrefix)
  if self.VVlcJO == self.VViyUH:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVlcJO == self.VVpoOr:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFTlW1(self, self.Title, addScrollLabel=True)
  FFMz2e(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVUvYt
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self["myLabel"].VVsOYo(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF3wB4(self)
  self.VVUvYt()
 def onExit(self):
  self.timer.stop()
 def VV6Dwo(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGnRX)
  except:
   self.timer.callback.append(self.VVGnRX)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFM3N1(self, "Started", 1000)
 def VVu3AX(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVGnRX)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFM3N1(self, "Stopped", 1000)
 def VVUvYt(self):
  if self.timerRunning:
   self.VVu3AX()
  else:
   self.VV6Dwo()
   if self.VVlcJO == self.VViyUH or self.VVlcJO == self.VVpoOr:
    if self.VVlcJO == self.VViyUH : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC1coX.VVxtmF(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFbn1D(self.VVCWne)
    else:
     self.close()
   else:
    self.VVFNQN()
 def VVGnRX(self):
  if self.timerRunning:
   if   self.VVlcJO == self.VViyUH : self.VVUwbj()
   elif self.VVlcJO == self.VVpoOr : self.VVUwbj()
   else            : self.VVFNQN()
 def VVFNQN(self):
  if fileExists(self.VV1guo):
   fTime = FFzHDX(os.path.getmtime(self.VV1guo))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVm2Ia(), VVCqdo=VVevDz)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV1guo)
 def VVCWne(self):
  self.VVUwbj()
 def VVUwbj(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFwXwL("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVdSiQ))
   self.camWebIfErrorFound = True
   self.VVu3AX()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVlcJO == self.VViyUH : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFwXwL("Error while parsing data elements !\n\nError = %s" % str(e), VVvrDy)
   self.camWebIfErrorFound = True
   self.VVu3AX()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVbBer(root)
  self["myLabel"].setText(txt, VVCqdo=VVevDz)
  self["myBar"].setText("Last Update : %s" % FFqUVM())
 def VVbBer(self, rootElement):
  def VVnxYh(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVlcJO == self.VViyUH:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFwXwL(status, VVfPTB)
    else          : status = FFwXwL(status, VVvrDy)
    txt += SEP + "\n"
    txt += VVnxYh("Name"  , name)
    txt += VVnxYh("Description" , desc)
    txt += VVnxYh("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVnxYh("Protocol" , protocol)
    txt += VVnxYh("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFwXwL("Yes", VVfPTB)
    else    : enabTxt = FFwXwL("No", VVvrDy)
    txt += SEP + "\n"
    txt += VVnxYh("Label"  , label)
    txt += VVnxYh("Protocol" , protocol)
    txt += VVnxYh("Enabled" , enabTxt)
  return txt
 def VVm2Ia(self):
  lines = FFpNiE("tail -n %d %s" % (100, self.VV1guo))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVHH6F + line[:19] + VVlrJC + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVA3Oc + "WebIf" + VVlrJC)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVEhqe + h1 + h2 + VVlrJC + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVfPTB + span.group(2) + VVdVoc + span.group(3) + VVlrJC + span.group(4)
    line = self.VVQe6e(line, VVdVoc, ("(webif)", ))
    line = self.VVQe6e(line, VVdVoc, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVQe6e(line, VVfPTB, ("OSCam", "NCam", "log switched"))
    line = self.VVQe6e(line, VVeCLm, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVqZDD + line[ndx + 3:] + VVlrJC
   elif line.startswith("----") or ">>" in line:
    line = FFwXwL(line, VViVXH)
   txt += line + "\n"
  return txt
 def VVQe6e(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVlrJC + t3
  return line
class CCZvl2(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVhIDJ = []
  VVhIDJ.append(("Backup Channels"    , "VVIOIJ"   ))
  VVhIDJ.append(("Restore Channels"    , "Restore_Channels"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Backup SoftCAM Files"   , "VV7tJE" ))
  VVhIDJ.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVhIDJ.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVhIDJ.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Backup Network Settings"  , "VVbgtC"   ))
  VVhIDJ.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVT9SH:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((VVdSiQ + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVrTVV"   ))
   VVhIDJ.append((VVfPTB + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVCXFL), "createMyIpk"   ))
   VVhIDJ.append((VVfPTB + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVCXFL), "createMyDeb"   ))
   VVhIDJ.append((VVEhqe + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVhIDJ.append((VVEhqe + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVeeFI" ))
   VVhIDJ.append((VVEhqe + "Show Windows Stats"           , "VVyLyn" ))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVIOIJ"    : self.VVIOIJ()
   elif item == "Restore_Channels"    : self.VVU2TC("channels_backup*.tar.gz", self.VV0Km7, isChan=True)
   elif item == "VV7tJE"   : self.VV7tJE()
   elif item == "Restore_SoftCAM_Files"  : self.VVU2TC("softcam_backup*.tar.gz", self.VViaXK)
   elif item == "Backup_TunerDiSEqC"   : self.VVQVT3("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVU2TC("tuner_backup*.backup", BF(self.VVPhQM, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVQVT3("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVU2TC("hotkey_*backup*.backup", BF(self.VVPhQM, "misc"))
   elif item == "VVbgtC"    : self.VVbgtC()
   elif item == "Restore_Network"    : self.VVU2TC("network_backup*.tar.gz", self.VVK6Jq)
   elif item == "VVrTVV"     : FF5jVY(self, BF(FFuMBP, self, BF(CCZvl2.VVrTVV, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVEzlk(False)
   elif item == "createMyDeb"     : self.VVEzlk(True)
   elif item == "createMyTar"     : self.VVZmVr()
   elif item == "VVeeFI"   : self.VVeeFI()
   elif item == "VVyLyn"    : CCZvl2.VVyLyn(self)
 @staticmethod
 def VV0Kal(SELF):
  OBF_Path = VVdqxv + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFM8jr(SELF, OBF_Path)
   return None
 @staticmethod
 def VVyLyn(SELF):
  obf = CCZvl2.VV0Kal(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FF3nHt(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVrTVV(SELF):
  obf = CCZvl2.VV0Kal(SELF)
  if obf:
   txt, err = obf.fixCode(VVdqxv, VVO0ZM, VVCXFL)
   if err : FFB8Nz(SELF, err)
   else : FF3nHt(SELF, txt)
 def VVEzlk(self, VVcMDF):
  OBF_Path = VVdqxv + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFB8Nz(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFcZm9("rm -f %s__pycache__/" % VVdqxv)
  FFcZm9("mv -f '%smain.py' '%s'" % (VVdqxv, OBF_Path))
  FFcZm9("mv -f '%splugin.py' '%s'" % (VVdqxv, OBF_Path))
  FFcZm9("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVdqxv))
  self.session.openWithCallback(self.VV0HE1, BF(CCo3lT, path=VVdqxv, VVcMDF=VVcMDF))
 def VV0HE1(self):
  FFcZm9("mv -f %s %s" % (VVdqxv + "OBF/main.py" , VVdqxv))
  FFcZm9("mv -f %s %s" % (VVdqxv + "OBF/plugin.py", VVdqxv))
 def VVeeFI(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFB8Nz(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFB8Nz(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVq2N3("%s*.list" % path)
  if err:
   FFM8jr(self, path + "*.list")
   return
  srcF, err = self.VVq2N3("%s*main_final.py" % path)
  if err:
   FFM8jr(self, path + "*.final.py")
   return
  VVFWkP = []
  for f in files:
   f = os.path.basename(f)
   VVFWkP.append((f, f))
  FFRHhp(self, BF(self.VVxnIJ, path, codF, srcF), VVhIDJ=VVFWkP)
 def VVxnIJ(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFM8jr(self, logF)
   else     : FFuMBP(self, BF(self.VV3S0S, logF, codF, srcF))
 def VV3S0S(self, logF, codF, srcF):
  lst  = []
  lines = FF9z80(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFB8Nz(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVBg3u(lst, logF, newLogF)
  totSrc  = self.VVBg3u(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF3nHt(self, txt)
 def VVq2N3(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVBg3u(self, lst, f1, f2):
  txt = FFQDOO(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVZmVr(self):
  VVFWkP = []
  VVFWkP.append("%s%s" % (VVdqxv, "*.py"))
  VVFWkP.append("%s%s" % (VVdqxv, "*.png"))
  VVFWkP.append("%s%s" % (VVdqxv, "*.xml"))
  VVFWkP.append("%s"  % (VVobIL))
  FFrin4(self, VVFWkP, "%s_%s" % (PLUGIN_NAME, VVO0ZM), addTimeStamp=False)
 def VVIOIJ(self):
  path1 = VVSs5p
  path2 = "/etc/tuxbox/"
  VVFWkP = []
  VVFWkP.append("%s%s" % (path1, "*.tv"))
  VVFWkP.append("%s%s" % (path1, "*.radio"))
  VVFWkP.append("%s%s" % (path1, "*list"))
  VVFWkP.append("%s%s" % (path1, "lamedb*"))
  VVFWkP.append("%s%s" % (path2, "*.xml"))
  FFrin4(self, VVFWkP, self.VVI5Rc("channels_backup"), addTimeStamp=True)
 def VV7tJE(self):
  VVFWkP = []
  VVFWkP.append("/etc/tuxbox/config/")
  VVFWkP.append("/usr/keys/")
  VVFWkP.append("/usr/scam/")
  VVFWkP.append("/etc/CCcam.cfg")
  FFrin4(self, VVFWkP, self.VVI5Rc("softcam_backup"), addTimeStamp=True)
 def VVbgtC(self):
  VVFWkP = []
  VVFWkP.append("/etc/hostname")
  VVFWkP.append("/etc/default_gw")
  VVFWkP.append("/etc/resolv.conf")
  VVFWkP.append("/etc/wpa_supplicant*.conf")
  VVFWkP.append("/etc/network/interfaces")
  VVFWkP.append("%snameserversdns.conf" % VVSs5p)
  FFrin4(self, VVFWkP, self.VVI5Rc("network_backup"), addTimeStamp=True)
 def VVI5Rc(self, fName):
  img = CCQSOE.VVaBEc()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VV0Km7(self, fileName=None):
  if fileName:
   FF5jVY(self, BF(FFuMBP, self, BF(self.VVMe92, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVMe92(self, fileName):
  path = "%s%s" % (VVVcWE, fileName)
  if fileExists(path):
   if CCf82q.VVLF8C(path):
    VVReaw , VVhCQx = CCn3v3.VV0Xv3()
    VVlXPB, VVsZQv = CCn3v3.VVnkJV()
    cmd  = FFUGBP("cd %s" % VVSs5p)
    cmd += FFUGBP("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVhCQx, VVsZQv))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFcZm9(cmd)
    FFBOOj()
    if ok: FFWB0Q(self, "Channels Restored.")
    else : FFB8Nz(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFB8Nz(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFM8jr(self, path)
 def VViaXK(self, fileName=None):
  if fileName:
   FF5jVY(self, BF(self.VV23iR, fileName), "Overwrite SoftCAM files ?")
 def VV23iR(self, fileName):
  fileName = "%s%s" % (VVVcWE, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF8Tx8(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFw0WV(note, VVqZDD), sep))
  else:
   FFM8jr(self, fileName)
 def VVK6Jq(self, fileName=None):
  if fileName:
   FF5jVY(self, BF(self.VVBHKV, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVBHKV(self, fileName):
  fileName = "%s%s" % (VVVcWE, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFFPZ4(self,  cmd)
  else:
   FFM8jr(self, fileName)
 def VVU2TC(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFNcNO()
  if pathExists(VVVcWE):
   myFiles = FFjT7E(VVVcWE, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVFWkP = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVFWkP.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVbPo7 = ("Sat. List", self.VVksac)
    elif isChan and iTar: VVbPo7 = ("Bouquets Importer", CChSGV.VVG2Ko)
    else    : VVbPo7 = None
    FFRHhp(self, callBackFunction, title=title, width=1200, VVhIDJ=VVFWkP, VVbPo7=VVbPo7, VV8Vs4=VVVcWE)
   else:
    FFB8Nz(self, "No files found in:\n\n%s" % VVVcWE, title)
  else:
   FFB8Nz(self, "Path not found:\n\n%s" % VVVcWE, title)
 def VVQVT3(self, filePrefix, wordsFilter):
  title = FFNcNO()
  if fileExists(VVabb3):
   tCons = CCeOtv()
   tCons.ePopen("cat %s | grep '%s'" % (VVabb3, wordsFilter), BF(self.VVd1uL, title, filePrefix))
  else:
   FFB8Nz(self, "Cannot read settings file", title)
 def VVd1uL(self, title, filePrefix, result, retval):
  if pathExists(VVVcWE):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFB8Nz(self, "No settings found to backup !", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVVcWE, filePrefix, self.VVI5Rc(""), FFERmH())
    try:
     VVFWkP = str(result.strip()).split()
     if VVFWkP:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVFWkP:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFwXwL(fName, VVqZDD), SEP)
       FF3nHt(self, txt, title=title, VVCqdo=VVevDz)
      else:
       FFB8Nz(self, "File creation failed!", title)
     else:
      FFB8Nz(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFcZm9("rm %s" % fName)
     FFB8Nz(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFcZm9("rm %s" % fName)
     FFB8Nz(self, "Error while writing file.")
  else:
   FFB8Nz(self, "Path not found:\n\n%s" % VVVcWE, title)
 def VVPhQM(self, mode, path=None):
  if path:
   path = "%s%s" % (VVVcWE, path)
   if fileExists(path):
    lines = FF9z80(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FF5jVY(self, BF(self.VVoXGr, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFQGz4(self, path, title=FFNcNO())
   else:
    FFM8jr(self, path)
 def VVoXGr(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VV0FrL = []
  tFile = "/tmp/ajp_tmp"
  VV0FrL.append("echo -e 'Reading current settings ...'")
  VV0FrL.append("cat %s | grep -v '%s' > %s" % (VVabb3, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VV0FrL.append("echo -e 'Preparing new settings ...'")
  VV0FrL.append(settingsLines)
  VV0FrL.append("echo -e 'Applying new settings ...'")
  VV0FrL.append("mv -f %s %s" % (tFile, VVabb3))
  FFsji8(self, VV0FrL)
 def VVksac(self, selectionObj, path):
  if not path:
   return
  path = VVVcWE + path
  if not fileExists(path):
   FFM8jr(self, path)
   return
  txt = FFQDOO(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFIxYe(item[1]))
   FF3nHt(self, txt, title="Satellites List")
  else:
   FFB8Nz(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CChSGV():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
  self.cbFnc   = None
 @staticmethod
 def VVG2Ko(SELF, fName):
  bi = CChSGV(SELF)
  bi.instance = bi
  bi.VVFw1w(SELF, fName)
 @staticmethod
 def VVb5WS(SELF, cbFnc=None):
  bi = CChSGV(SELF)
  bi.instance = bi
  bi.cbFnc = cbFnc
  bi.VVykaA()
 def VVFw1w(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVVcWE + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFuMBP(waitObg, self.VVSIKp, title="Reading bouquets ...")
  else      : self.VVZ9Bq(self.filePath)
 def VVqMWO(self, txt) : FFB8Nz(self.SELF, txt, title=self.Title)
 def VVzp4h(self, txt)  : FFM3N1(self, txt, 1500)
 def VVZ9Bq(self, path) : FFM8jr(self.SELF, path, title=self.Title)
 def VVykaA(self):
  if pathExists(VVVcWE):
   lst = FFjT7E(VVVcWE, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVlDvO())
   if len(lst) > 0:
    VVhIDJ = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFwXwL(item, VVdVoc) if item.endswith(".zip") else item
     VVhIDJ.append((txt, item))
    VVhIDJ.sort(key=lambda x: x[1].lower())
    VVvXZx = self.VV9i4T
    FFRHhp(self.SELF, self.VV3kL2, minRows=3, title=self.Title, width=1200, VVhIDJ=VVhIDJ, VVvXZx=VVvXZx, VV8Vs4=VVVcWE, VVl9AY="#22111111", VVLICL="#22111111")
   else:
    self.VVqMWO("No valid backup files found in:\n\n%s" % VVVcWE)
  else:
   self.VVqMWO("Backup Directory not found:\n\n%s" % VVVcWE)
 def VV9i4T(self, item=None):
  if item:
   VVCarR, txt, fName, ndx = item
   self.VVFw1w(VVCarR, fName)
 def VV3kL2(self, item=None):
  if self.cbFnc: self.cbFnc()
  if not item and self.instance:
   del self.instance
 def VVlDvO(self):
  files = FFjT7E(VVVcWE, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVSIKp(self):
  lines, err = CChSGV.VVw8Tt(self.filePath, "bouquets.tv")
  if err:
   self.VVqMWO(err)
   return
  bTvSortLst  = self.VVDWLI(lines)
  lines, err = CChSGV.VVw8Tt(self.filePath, "bouquets.radio")
  if err:
   self.VVqMWO(err)
   return
  bRadSortLst = self.VVDWLI(lines)
  VVkNlM = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVgcxX(f, mode, len(VVkNlM), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVkNlM.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVgcxX(f, mode, len(VVkNlM), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVgcxX(f, mode, len(VVkNlM), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVkNlM.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVgcxX(f, mode, len(VVkNlM), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVkNlM:
   VVkNlM.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVkNlM): VVkNlM[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVkNlM):
     if key == os.path.basename(row[9]):
      VVkNlM = VVkNlM[:ndx+1] + lst + VVkNlM[ndx+1:]
      break
   for ndx, item in enumerate(VVkNlM): VVkNlM[ndx][0] = str(ndx + 1)
   VVHZxf = "#11000600"
   VVlUqf  = ("Show Services" , self.VVL1Dk  , [], "Reading ..." )
   VVJEWY = (""    , self.VV5m28, [])
   VVkGmL = ("Options"  , self.VVuWLp, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVrLHE  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFNCSP(self.SELF, None, title=self.Title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=24, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVkGmL=VVkGmL, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVl9AY=VVHZxf, VVLICL=VVHZxf, VVHZxf=VVHZxf, VVSzMt="#00004455", VVvy9F="#0a282828")
  else:
   self.VVqMWO("No valid bouquets in:\n\n%s" % self.filePath)
 def VVDWLI(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VV5m28(self, VVhqv2, title, txt, colList):
  FF3nHt(self.SELF, FFpdHF(txt), title=title)
 def VVuWLp(self, VVhqv2, title, txt, colList):
  mSel = CCr5W8(self.SELF, VVhqv2)
  if VVhqv2.VVVoic:
   totSel = VVhqv2.VVv2WG()
   if totSel: VVhIDJ = [("Import %s Bouquet%s" % (FFwXwL(str(totSel), VVfPTB), FFW43m(totSel)), "imp")]
   else  : VVhIDJ = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFwXwL(bName, VVfPTB)
   VVhIDJ = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFuMBP, VVhqv2, BF(CChSGV.VVw0sp, self.SELF, VVhqv2, self.filePath))}
  mSel.VVklJK(VVhIDJ, cbFncDict)
 def VVL1Dk(self, VVhqv2, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CChSGV.VVw8Tt(self.filePath, "lamedb")
   if err:
    self.VVqMWO(err)
    return
   dbServLst = CCn3v3.VVo8ey(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVhqv2.VVHMjy()
   lines, err = CChSGV.VVw8Tt(self.filePath, os.path.basename(fName))
   if err:
    self.VVqMWO(err)
    return
   VVkNlM = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVkNlM.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVkNlM.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVkNlM.append((span.group(1).strip() or "-", "Stream Relay" if FFzL2x(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVkNlM.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVkNlM.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCn3v3.VVBMKc(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVkNlM.append((name.strip() or "-", FFeI49(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVkNlM):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CChSGV.VVw8Tt(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVkNlM[ndx] = (bName, descr)
   if VVkNlM:
    VVHZxf = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVrLHE = (LEFT  , CENTER)
    FFNCSP(self.SELF, None, title="Services in : %s" % bName, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVl9AY=VVHZxf, VVLICL=VVHZxf, VVHZxf=VVHZxf, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFM3N1(VVhqv2, err, 1500)
  else : VVhqv2.VV0Sa3()
 def VVgcxX(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVqMWO("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFzL2x(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVNpAU(var):
   return str(var) if var else VV6rcy + str(var)
  totItem = VVqZDD + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVdSiQ   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVdVoc, "Sub-B."
  else  : bColor, totBnb = ""      , VVNpAU(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVNpAU(totDVB), VVNpAU(totIptv), VVNpAU(totSRelay), VVNpAU(totLoc), VVNpAU(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVw0sp(SELF, VVhqv2, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVSs5p + "bouquets.tv"
  radBouquetFile = VVSs5p + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFM8jr(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFM8jr(SELF, radBouquetFile, title=title)
   return
  isMulti = VVhqv2.VVVoic
  if isMulti : rows = VVhqv2.VV9Uef()
  else  : rows = [VVhqv2.VVHMjy()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFB8Nz(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFpdHF(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFpdHF(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVSs5p + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVSs5p + newFile
    CChSGV.VVOHzi(archPath, fName, VVSs5p, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FF3j5I(tvBouquetFile)
   FF3j5I(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CChSGV.VVPFsg(SELF, archPath, bList)
   FFBOOj()
  txt  = FFwXwL("Added:\n", VVdVoc)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFwXwL("Imported to lamedab:\n", VVdVoc)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFwXwL("Missing from archived lamedb:\n", VVdSiQ)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FF3nHt(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVPFsg(SELF, archPath, bList):
  VVReaw, err = CCn3v3.VVlBmF(SELF, VV8QCM=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCn3v3.VV2du2(VVReaw, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF9z80(VVSs5p + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCn3v3.VVBMKc(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCn3v3.VVbMPw(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CChSGV.VViZY3(archPath, dbName)
   CChSGV.VVOHzi(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCn3v3.VV2du2(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCn3v3.VV2du2(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCn3v3.VV2du2(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCn3v3.VV2du2(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFZ5Mj(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVReaw + ".tmp"
   lines   = FF9z80(VVReaw)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFcZm9("mv -f '%s' '%s'" % (tmpDbFile, VVReaw))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVgFuQ(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VViZY3(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVOHzi(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVw8Tt(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCsrtc():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVb12c()
 def VVb12c(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVgQtM(self):
  FFuMBP(self, self.VVryns)
 def VVryns(self):
  if pathExists(self.projMainPath):
   lst = FFUshp(self.projMainPath)
   VVhIDJ = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVhIDJ.append((prName, prName))
   if VVhIDJ:
    VVhIDJ.sort(key=lambda x: x[1].lower())
    VVvXZx = self.VV5POH
    VVbPo7 = ("Add new project", self.VV5efQ)
    VVVW3K= ("Delete Project" , self.VVACmg)
    self.projMenu = FFRHhp(self, None, VVhIDJ=VVhIDJ, width=1100, VVvXZx=VVvXZx, VVbPo7=VVbPo7, VVVW3K=VVVW3K, minRows=5, VVl9AY="#22111133", VVLICL="#22111133")
   else:
    FF5jVY(self, self.VVVb1Q, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVZn4e("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVVb1Q(self)    : FFuMBP(self, BF(self.VVXhHC))
 def VV5efQ(self, VVCarR, item) : FFuMBP(self.projMenu, BF(self.VVXhHC))
 def VVXhHC(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVVrTh(name)
 def VVVrTh(self, name, cbFnc=None):
  FFs37j(self, cbFnc or self.VVy4VR, defaultText=name, title="New Project Name", message="Enter project name")
 def VVy4VR(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FF5jVY(self, BF(self.VVVrTh, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFoe8F(path)
    if err:
     self.VVZn4e("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVcn0L((item, item), isSort=True)
     else   : self.VVgQtM()
 def VVACmg(self, VVCarR, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFEwyA(path)
    FF5jVY(self, BF(self.VVq3Or, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVq3Or(self, path):
  if FFcZm9("rm -rf '%s'" % path):
   self.projMenu.VVORMC()
 def VV5POH(self, item=None):
  if item:
   VVCarR, txt, Dir, ndx = item
   self.VVb12c()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVobIL
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF9z80(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFqUVM()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVjsR3()
   else      : self.VVZn4e("Cannot create project file:\n\n%s" % self.projFile)
 def VVjsR3(self, VVCarR=None, jmpDict=None):
  FFuMBP(VVCarR or self.projTable or self, BF(self.VVLSvY, jmpDict))
 def VVLSvY(self, jmpDict):
  self.VVb12c()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF9z80(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVwJg6(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVZn4e('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFoQQd(path)
    if sz > -1: size = CCf82q.VVeeDD(sz, mode=4)
    else   : size = FFwXwL("Size error", VVdSiQ)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF9z80(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVWTgn(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVCgDs(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFwXwL("Unknown value", VVdSiQ), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFwXwL(rem, VVdSiQ), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVkNlM = pkgRows
  VVkNlM.extend(actnRows)
  VVkNlM.extend(ctrlRows)
  VVkNlM.extend(fileRows)
  VVkNlM.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVkNlM):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFwXwL("Valid", VVfPTB), " ... " + Remarks if Remarks else "")
    VVkNlM[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVartp(VVkNlM, tableRefreshCB=BF(self.VVjYY6, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVJEWY = (""     , self.VV6cVo   , [])
   menuButtonFnc = (""     , self.VVNpVC   , [])
   VVlpv3 = ("Create Package"  , self.VVy4rk , [])
   VVkGmL = ("Post Install Action", self.VVOeNW, [])
   VV1FeB = ("Edit File"   , self.VVbDyv  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVrLHE = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, width=1850, height=1040, VVNWWl=26, VVJEWY=VVJEWY, menuButtonFnc=menuButtonFnc, VVlpv3=VVlpv3, VVkGmL=VVkGmL, VV1FeB=VV1FeB, searchCol=2
         , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#00664411", VVvy9F="#00444444", VVRt6l="#08442211")
   self.projTable.VVAuRJ(self.VVxlLD, True)
 def VVjYY6(self, jmpDict, VVhqv2, title, txt, colList):
  self.projTable.VVTlR4(jmpDict)
 def VVxlLD(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVHMjy()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVwJg6(self, line):
  def VVlfuJ(patt, val, Len):
   if len(val) < Len   : return FFwXwL("Length error" , VVdSiQ)
   elif not iMatch(patt, val) : return FFwXwL("Invalid format" , VVdSiQ)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVlfuJ(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVlfuJ(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVWTgn(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFzvzT(path)
  path = FFOE3h(path)
  c = VVdSiQ
  if   typ == "Mount" : rem = FFwXwL("Not allowed", c)
  elif not typ  : rem = FFwXwL("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFwXwL("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFS0NV(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFzvzT(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFwXwL("Not allowed", c)
     elif targetType == "Directory" : sz = FFS0NV(targetPath)
     elif targetType == "File"  : sz = FFoQQd(targetPath)
     else       : sz, rem = FFoQQd(path), FFwXwL("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFoQQd(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCf82q.VVeeDD(sz, mode=4)
     else:
      size = FFwXwL("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVCgDs(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVbDyv(self, VVhqv2, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCwZEN(self, path, VVLUmk=self.VVeuVa, curRowNum=lineNdx)
  else    : FFM8jr(self, path)
 def VVeuVa(self, fileChanged):
  if fileChanged:
   self.VVjsR3()
 def VVZn4e(self, txt):
  FFB8Nz(self, txt, title=self.projTitle)
 def VV6cVo(self, VVhqv2, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVdVoc
  s  = FF6F4t("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FF6F4t("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCf82q.VVeeDD(self.projFilesSize))
  FF3nHt(self, s, title="Project Info", width=1600)
 def VVNpVC(self, VVhqv2, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVuj5g, VVmvsU, VVdVoc
  VVhIDJ = []
  VVhIDJ.append((c1 + "Add Resource File"  , "addFile" ))
  VVhIDJ.append((c1 + "Add Resource Directory" , "addDir" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Package Name"   , "pkgNam" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Add Dependency"   , "addDep" ))
  VVhIDJ.append((c2 + "Remove Dependency"  , "delDep" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVhIDJ.append(FFyXfa('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVdSiQ))
  FFRHhp(self, self.VVQwfV, VVhIDJ=VVhIDJ, width=1050, title="Options", VVl9AY="#11001122", VVLICL="#11001122")
 def VVQwfV(self, item=None):
  if item:
   if   item == "addFile" : self.VVGgr5(False)
   elif item == "addDir" : self.VVGgr5(True)
   elif item == "pkgNam" : self.VVKVsk()
   elif item == "addDep" : FFuMBP(self.projTable, self.VVb5di)
   elif item == "delDep" : self.VVGNew()
   elif item == "ctrlFMan" : self.VVzJPS()
   elif item == "ctrlImprt": FFuMBP(self.projTable, self.VVtFxz)
   elif item == "ctrlUndo" : self.VVTmcL()
   elif item == "delRow" : self.VVmZB8()
 def VVGgr5(self, isDir):
  Dir = FFO4Nw(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VV8l9q, BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=Dir))
  else : self.session.openWithCallback(self.VV8l9q, BF(CCf82q, patternMode="all", VVQzCM=Dir))
 def VV8l9q(self, path):
  if path:
   FFsMp0(CFG.lastPkgProjDir, path)
   self.VV3jGL(path, 2)
 def VVzJPS(self):
  Dir = FFO4Nw(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVOFQ9, BF(CCf82q, patternMode="pkgCtrl", VVQzCM=Dir))
 def VVOFQ9(self, path):
  if path:
   FFsMp0(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFcZm9("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVjsR3()
    self.projTable.VVTlR4({1:"Script", 2:fName})
 def VVtFxz(self):
  cmd = FF2wdN(VVEidq, "")
  if not cmd:
   FF4L5V(self)
   return
  lst = FFpNiE(cmd)
  if lst:
   err = CCf82q.VVIxYK(lst, fromFind=False)
   if err:
    self.VVZn4e(err)
    return
   lst.sort()
   VVkNlM = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVkNlM.append(("", span.group(1), span.group(2)))
   if VVkNlM:
    VVlrMb = ("Import 'control' data", self.VVYbvy, [])
    VVkGmL = ("Package Info.", self.VV2m7B     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=30, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVv8tN=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVl9AY="#22110011", VVLICL="#22191111", VVHZxf="#22191111", VVSzMt="#00003030", VVvy9F="#00333333")
   else:
    self.VVZn4e("Cannot process installed packages !")
  else:
   self.VVZn4e("Cannot read installed packages !")
 def VVTmcL(self):
  if FFcZm9("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVjsR3(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVZn4e("Process Failed !")
 def VVYbvy(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVUxmH, VVhqv2, colList[1]))
 def VVUxmH(self, VVhqv2, pkg):
  lines = []
  for line in FFpNiE(FFyOYr(VVREjx, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FF5jVY(self, BF(self.VVBWIj, VVhqv2, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVZn4e("Cannot import from this package:\n\n%s" % pkg)
 def VVBWIj(self, VVhqv2, lines):
  VVhqv2.cancel()
  FFGli3(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVjsR3(jmpDict={1:"Control", 2:"Package"})
 def VVmZB8(self):
  lineNum = int(self.projTable.VVHMjy()[0]) + 1
  FFcZm9("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVjsR3()
 def VV3jGL(self, line, jmp):
  if fileExists(self.projFile):
   FFGli3(self.projFile)
   FF3j5I(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVjsR3(jmpDict=jmpDict)
  else:
   FFM8jr(self, self.projFile, title=self.projTitle)
 def VVOeNW(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(FFyXfa("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVhIDJ.append(FFyXfa("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVhIDJ.append(FFyXfa("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVhIDJ.append(FFyXfa("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVhIDJ.append(FFyXfa("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFRHhp(self, self.VVOrVj, VVhIDJ=VVhIDJ, title="Action (after the package is installed/removed)")
 def VVOrVj(self, item=None):
  if item:
   if   item == "instNon" : self.VVFjye("postinst", 0)
   elif item == "instRes" : self.VVFjye("postinst", 1)
   elif item == "instReb" : self.VVFjye("postinst", 2)
   elif item == "rmNon" : self.VVFjye("postrm", 0)
   elif item == "rmRes" : self.VVFjye("postrm", 1)
   elif item == "rmReb" : self.VVFjye("postrm", 2)
 def VVFjye(self, subj, val):
  if fileExists(self.projFile):
   lines = FF9z80(self.projFile)
   FFGli3(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VV3jGL("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVjsR3()
 def VVKVsk(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVhIDJ = []
  VVhIDJ.append((pkg, pkg))
  VVhIDJ.append(VVuAtK)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVdVoc if name == self.projPkg else ""
    VVhIDJ.append((c + name, name))
   else:
    VVhIDJ.append(VVuAtK)
  FFRHhp(self, self.VVSRiQ, VVhIDJ=VVhIDJ, title="Package Name")
 def VVSRiQ(self, item=None):
  if item:
   self.VVXHFJ("Package", item)
 def VVb5di(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVhIDJ = []
   for item in lst: VVhIDJ.append((item, item))
   VVhIDJ.sort(key=lambda x: x[0].lower())
   VVCarR = FFRHhp(self, self.VVLnrt, VVhIDJ=VVhIDJ, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVCarR.VVjcmp(self.projLastDepends)
  else:
   self.VVZn4e("Cannot read dependencies list !")
 def VVLnrt(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF9z80(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVXHFJ("Depends", ", ".join(lst))
   else:
    FFM3N1(self.projTable, "Already added", 1500)
    self.projTable.VVTlR4({1:"Control", 2:"Depends"})
 def VVGNew(self):
  lst = []
  for row in self.projTable.VVOazu():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVhIDJ = []
   for item in lst: VVhIDJ.append((item, item))
   FFRHhp(self, BF(self.VVINHa, lst), VVhIDJ=VVhIDJ, title="Remove Dependency")
  else:
   self.VVZn4e("No dependencies to remove !")
 def VVINHa(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVXHFJ("Depends", ", ".join(lst))
   else:
    FFcZm9("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVjsR3()
 def VVXHFJ(self, subj, val):
  lines = FF9z80(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVjsR3(jmpDict={1:"Control", 2:subj})
 def VVy4rk(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(("Create .ipk"  , "ipk"))
  VVhIDJ.append(("Create .deb"  , "deb"))
  VVhIDJ.append(("Create .tar.gz" , "tar"))
  FFRHhp(self, self.VVvlxt, VVhIDJ=VVhIDJ, width=500, title=self.projTitle)
 def VVvlxt(self, item=None):
  if item:
   FFuMBP(self.projTable, BF(self.VVYfjT, item))
 def VVYfjT(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVZn4e("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVcMDF, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVcMDF, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVZn4e(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFUGBP("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFw0WV(result  , VVfPTB))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFw0WV(failed, VVvrDy))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFUGBP("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVOazu()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFFPZ4(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFcZm9(cmd) or not pathExists(ctrlDir):
   VVZn4e(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVlfuJ(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFcZm9("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVlfuJ(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FF3j5I(dstF)
   FFcZm9("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFGFBz()
  if VVcMDF:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFJfZ1("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFFPZ4(self, cmd)
class CCxLZd(Screen, CCsrtc):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VV35C4, 850, 900, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCsrtc.__init__(self)
  c1, c2, c3, c4 = VVuj5g, VVmvsU, VVHH6F, VVdVoc
  VVhIDJ = []
  VVhIDJ.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c3 + "Remove Packages (show all)"     , "VVYwossAll"  ))
  VVhIDJ.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Update Packages List from Feed"    , "VVUETr"  ))
  VVhIDJ.append((c2 + "Upgradable Packages"       , "VVRJZ3" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c4 + "Generate Package.gz (from ipk/deb directory)", "VVovQJ"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Packaging Tool"         , "VV7mga"   ))
  VVhIDJ.append(("Active Feeds"          , "VVC3pL"   ))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CC6KoU.VVHYF2(self.session)
   elif item == "downloadInstallPackages"  : FFuMBP(self, BF(self.VVxI7R, 0, ""))
   elif item == "VVYwossAll"   : FFuMBP(self, BF(self.VVxI7R, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFuMBP(self, BF(self.VVxI7R, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVUETr"   : CCxLZd.VVUETr(self)
   elif item == "VVRJZ3"  : FFuMBP(self, self.VVRJZ3)
   elif item == "packageCreator"    : self.VVgQtM()
   elif item == "VVovQJ"   : self.VVovQJ()
   elif item == "VV7mga"    : self.VV7mga()
   elif item == "VVC3pL"    : FFuMBP(self, self.VVC3pL)
   else          : self.close()
 def VVC3pL(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVkNlM = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVkNlM.append((os.path.basename(path), str(tot)))
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVrLHE = (LEFT  , CENTER )
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, width=1000, VVNWWl=26, VVUMPl=2)
  else:
   self.VVZn4e("Cannot read packages list !")
 def VVRJZ3(self, VVhqv2=None):
  lst = FFpNiE(FF2wdN(VVA9cR, ""))
  VVkNlM = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVkNlM.append((str(len(VVkNlM) + 1), pkg, curV, newVer))
   if VVkNlM:
    if VVhqv2:
     VVhqv2.VVartp(VVkNlM, VVEO5wMsg=True)
    else:
     bg = "#00221111"
     VVlrMb = ("Upgrade", self.VVTZdi   , [])
     VVkGmL = ("Package Info.", self.VV2m7B , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVrLHE = (CENTER , LEFT  , LEFT  , LEFT   )
     FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, width=1700, VVNWWl=26, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVJcAk=True, VVOOaR=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVgLJ3="#00ffff55", VVSzMt="#00003040")
  if not VVkNlM:
   FFkqUz(self, "Nothing to upgrade", 1500)
   if VVhqv2: VVhqv2.cancel()
 def VVTZdi(self, VVhqv2, title, txt, colList):
  pkg = colList[1]
  cmd = FFyOYr(VVTdap, pkg)
  if cmd : FFFPZ4(self, cmd, title="Installing : %s" % pkg, VVE46B=BF(self.VVRJZ3, VVhqv2))
  else : FF4L5V(SELF)
 def VVovQJ(self):
  if CCxLZd.VVbUuk(self):
   self.session.openWithCallback(self.VVprMu, BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=CFG.lastFeedPkgsDir.getValue()))
 def VVprMu(self, path):
  FFuMBP(self, BF(self.VVOZuD, path))
 def VVOZuD(self, path):
  title = "Feed Package.gz Creator"
  if len(path) > 0:
   FFsMp0(CFG.lastFeedPkgsDir, path)
   files = []
   lst = iGlob(path + "*.ipk")
   totIpk = len(lst)
   for f in lst:
    files.append(os.path.basename(f))
   lst = iGlob(path + "*.deb")
   totDeb = len(lst)
   for f in lst:
    files.append(os.path.basename(f))
   lst = None
   if len(files) > 0:
    files.sort(key=lambda x: x[0].lower())
   else:
    FFB8Nz(self, "No ipk/deb files found in:\n\n%s" % path)
    return
   pFile = os.path.join(path, "Packages")
   gFile = "%s.gz" % pFile
   tFile = os.path.join(path, "Packages.stamps")
   with open(pFile, "w") as pF:
    with open(tFile, "w") as tF:
     for fName in files:
      fPath = os.path.join(path, fName)
      txt, mTime = CCxLZd.VVrPIq(fPath)
      pF.write("%s\n" % txt)
      tF.write("%s\n" % mTime)
   FFZ5Mj(gFile)
   os.system("gzip -k '%s'" % pFile)
   c = VVuj5g
   txt  = "%s: %s\n" % (FFwXwL("Processed Files:", c), len(files))
   txt += "  ipk   : %s\n" % totIpk
   txt += "  deb  : %s\n" % totDeb
   txt += "\n%s\n" % FFwXwL("Output Files:", c)
   txt += "  %s\n" % pFile
   txt += "  %s\n" % gFile
   txt += "  %s" % tFile
   FF3nHt(self, txt)
 def VV7mga(self):
  pkg = FFn597()
  aptT = "apt - Advanced Package Tool" if FFBf4e("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFWB0Q(self, txt or "No packaging tools found!")
 def VVxI7R(self, mode, grep, VVhqv2=None, title=""):
  if   mode == 0: cmd = FF2wdN(VVHVEB    , grep)
  elif mode == 1: cmd = FF2wdN(VVEidq , grep)
  elif mode == 2: cmd = FF2wdN(VVEidq , grep)
  if not cmd:
   FF4L5V(self)
   return
  VVkNlM = FFpNiE(cmd)
  if VVkNlM:
   err = CCf82q.VVIxYK(VVkNlM, fromFind=False)
   if err:
    FFB8Nz(self, err)
    return
  else:
   if VVhqv2: VVhqv2.VV0Sa3()
   FFB8Nz(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVFWkP  = []
  for item in VVkNlM:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVFWkP.append((name, package, version))
  if mode > 0:
   extensions = FFpNiE("ls %s -l | grep '^d' | awk '{print $9}'" % VVe5fU)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVFWkP:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVkv1M: name += "el"
      VVFWkP.append((name, VVe5fU + item, "-"))
   systemPlugins = FFpNiE("ls %s -l | grep '^d' | awk '{print $9}'" % VVDVsC)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVFWkP:
      if item.lower() == row[0].lower():
       break
     else:
      VVFWkP.append((item, VVDVsC + item, "-"))
  if not VVFWkP:
   FFB8Nz(self, "No packages found!")
   return
  if VVhqv2:
   VVFWkP.sort(key=lambda x: x[0].lower())
   VVhqv2.VVartp(VVFWkP, title)
  else:
   widths = (20, 50, 30)
   VVlrMb = None
   VV1FeB = None
   if mode == 0:
    VVlpv3 = ("Install" , self.VVMNGj   , [])
    VVlrMb = ("Download" , self.VV01tF   , [])
    VV1FeB = ("Filter"  , self.VVhfeR , [])
   elif mode == 1:
    VVlpv3 = ("Uninstall", self.VVYwos, [])
   elif mode == 2:
    VVlpv3 = ("Uninstall", self.VVYwos, [])
    widths= (18, 57, 25)
   VVFWkP.sort(key=lambda x: x[0].lower())
   VVkGmL = ("Package Info.", self.VV2m7B, [])
   header   = ("Name" ,"Package" , "Version" )
   FFNCSP(self, None, header=header, VVFWkP=VVFWkP, VVN1SU=widths, VVNWWl=28, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVv8tN=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVl9AY="#22110011", VVLICL="#22191111", VVHZxf="#22191111", VVSzMt="#00003030", VVvy9F="#00333333")
 def VV2m7B(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVokbS, VVhqv2, colList[1]))
 def VVokbS(self, VVhqv2, pkg):
  if pathExists(pkg):
   pkg, err = CCxLZd.VVuX2k(pkg)
   if err:
    FFkqUz(VVhqv2, err, 1000)
    return
  CCxLZd.VVfqcr(self, pkg)
 def VVhfeR(self, VVhqv2, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVhIDJ = []
  VVhIDJ.append(("All Packages", "all"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVhIDJ.append(VVuAtK)
  for word in words:
   VVhIDJ.append((word, word))
  FFRHhp(self, BF(self.VVAEX5, VVhqv2), VVhIDJ=VVhIDJ, title="Select Filter")
 def VVAEX5(self, VVhqv2, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFuMBP(VVhqv2, BF(self.VVxI7R, 0, grep, VVhqv2, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVYwos(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VV5Q13, VVhqv2, colList[1]))
 def VV5Q13(self, VVhqv2, package):
  if pathExists(package):
   pkg, err = CCxLZd.VVuX2k(package)
   if pkg:
    package = pkg
  if package.startswith((VVe5fU, VVDVsC)):
   FF5jVY(self, BF(self.VVMOSf, VVhqv2, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVhIDJ = []
   VVhIDJ.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVhIDJ.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVhIDJ.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFRHhp(self, BF(self.VV1AMO, VVhqv2, package), VVhIDJ=VVhIDJ)
 def VVMOSf(self, VVhqv2, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVB6fx)
  FFFPZ4(self, cmd, VVE46B=BF(self.VVySac, VVhqv2))
 def VV1AMO(self, VVhqv2, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVdRQL
   elif item == "remove_ForceRemove"  : cmdOpt = VVSwkt
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVTZQY
   FF5jVY(self, BF(self.VV0zAr, VVhqv2, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV0zAr(self, VVhqv2, package, cmdOpt):
  self.lastSelectedRow = VVhqv2.VVHqmL()
  cmd = FFyOYr(cmdOpt, package)
  if cmd : FFFPZ4(self, cmd, VVE46B=BF(self.VVySac, VVhqv2))
  else : FF4L5V(self)
 def VVySac(self, VVhqv2):
  VVhqv2.cancel()
  FF33DL()
 def VVMNGj(self, VVhqv2, title, txt, colList):
  package  = colList[1]
  VVhIDJ = []
  VVhIDJ.append(("Install Package"        , "install_CheckVersion" ))
  VVhIDJ.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVhIDJ.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVhIDJ.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVhIDJ.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFRHhp(self, BF(self.VV5YNy, package), VVhIDJ=VVhIDJ)
 def VV5YNy(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVTdap
   elif item == "install_ForceReinstall" : cmdOpt = VVq2DR
   elif item == "install_ForceOverwrite" : cmdOpt = VVsUET
   elif item == "install_ForceDowngrade" : cmdOpt = VVitUq
   elif item == "install_IgnoreDepends" : cmdOpt = VVnSnN
   FF5jVY(self, BF(self.VV4NRc, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV4NRc(self, package, cmdOpt):
  cmd = FFyOYr(cmdOpt, package)
  if cmd : FFFPZ4(self, cmd, VVE46B=FF33DL, checkNetAccess=True)
  else : FF4L5V(self)
 def VV01tF(self, VVhqv2, title, txt, colList):
  package  = colList[1]
  FF5jVY(self, BF(self.VVheVK, package), "Download Package ?\n\n%s" % package)
 def VVheVK(self, package):
  if CCBOP8.VVk4Hv():
   cmd = FFyOYr(VVZ14B, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFw0WV(success, VVfPTB))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFw0WV(fail, VVvrDy))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFFPZ4(self, cmd, VVZweB=[VVvrDy, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF4L5V(self)
  else:
   FFB8Nz(self, "No internet connection !")
 @staticmethod
 def VVUETr(SELF):
  cmd = FF2wdN(VVdMlb, "")
  if cmd : FFFPZ4(SELF, cmd, checkNetAccess=True, title="Available Packages List Upadate")
  else : FF4L5V(SELF)
 @staticmethod
 def VVuX2k(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFpNiE(FFyOYr(VVqBbR, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVfqcr(SELF, package, title=""):
  title = title or package
  infoCmd  = FFyOYr(VVREjx, package)
  filesCmd = FFyOYr(VVEH2u, package)
  listInstCmd = FF2wdN(VVEidq, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFXA2w(VVqZDD)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFw0WV(notInst, VVdSiQ))
   cmd += "else "
   cmd +=   FFYaeB("System Info", VVqZDD)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFYaeB("Related Files", VVqZDD)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF1Ubx(SELF, cmd, title=title)
  else:
   FF4L5V(SELF, title=title)
 @staticmethod
 def VVbkVT():
  return FFcZm9("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")
 @staticmethod
 def VVbUuk(SELF):
  if not CCxLZd.VVbkVT():
   FF5jVY(SELF, BF(FFFPZ4, SELF, FFGFBz(), title="Installing 'ar'"), "'ar' package is required.\n\nInstall ?")
   return False
  elif not FFBf4e("xz"):
   FF5jVY(SELF, BF(FFFPZ4, SELF, FFJfZ1("xz", "xz", "XZ"), title="Installing 'xz'"), "'xz' package is required.\n\nInstall ?")
   return False
  else:
   return True
 @staticmethod
 def VVrPIq(path):
  txt = mTime = ""
  if fileExists(path):
   fName = os.path.basename(path)
   isDeb = os.path.splitext(fName)[1] == ".deb"
   if isDeb: ext, tarP = "xz", "J"
   else : ext, tarP = "gz", "z"
   txt += FFO9ap("ar -p '%s' control.tar.%s | tar %sxO ./control" % (path, ext, tarP))
   txt += "\n"
   txt += "Size: %s\n" % FFoQQd(path)
   txt += "Filename: %s\n" % fName
   txt += "MD5sum: %s\n" % FFkd4T("md5sum '%s' | cut -b-32" % path)
   txt += "SHA256sum: %s\n" % FFkd4T("sha256sum '%s' | cut -b-64"  % path)
   mTime = "%s %s" % (FFkd4T("stat -c%%Y '%s'" % path), fName)
  return txt, mTime
class CCBYxw():
 def VV0rYM(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VV9AOX()
 def VV9AOX(self):
  files = FFjT7E(VVVcWE, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVhIDJ = []
   for fil in files:
    VVhIDJ.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVl9AY, VVLICL = "#22221133", "#22221133"
   else    : VVl9AY, VVLICL = "#22003344", "#22002233"
   VVbPo7  = ("Add new File", self.VVjRJ1)
   FFRHhp(self, self.VV3f0O, VVhIDJ=VVhIDJ, width=1100, VVbPo7=VVbPo7, VV8Vs4="", minRows=4, VVl9AY=VVl9AY, VVLICL=VVLICL)
  else:
   FF5jVY(self, self.VVXsVs, "No files found.\n\nCreate a new file ?")
 def VVXsVs(self):
  path = self.VVTpFN()
  if fileExists(path) : self.VV9AOX()
  else    : FFM3N1(self, "Cannot create file", 1500)
 def VVjRJ1(self, VVCarR, path):
  path = self.VVTpFN()
  VVCarR.VVcn0L((os.path.basename(path), path), isSort=True)
 def VVTpFN(self):
  path = "%s%s%s.xml" % (VVVcWE, self.shareFilePrefix, FFERmH())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VV3f0O(self, path=None):
  if path:
   FFuMBP(self, BF(self.VVt2DS, path))
 def VVt2DS(self, path):
  if not fileExists(path):
   FFM8jr(self, path)
   return
  elif not CCf82q.VVg9pn(self, path, FFNcNO()):
   return
  else:
   self.shareFilePath = path
  if not CC1coX.VV0r6H(self):
   return
  tree = CCn3v3.VVsbpC(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCJEC1.VVkrP4()
  def VVnxYh(refCode):
   if   FF7Jqd(refCode): return FFwXwL("DVB", VVuj5g)
   elif refCode in refLst     : return FFwXwL("IPTV", VVuj5g)
   else         : return ""
  VVkNlM= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVJRxW(ch)
   if ok:
    srcTxt = VVnxYh(srcRef)
    dstTxt = VVnxYh(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVkNlM:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVkNlM.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVkNlM:
   if self.shareIsRef : VVl9AY, VVLICL, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVl9AY, VVLICL, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVNBO3 = (""    , BF(self.VVYE0P, dupl), [])
   VVJEWY = (""    , self.VVwR6Q    , [])
   VVlpv3 = ("Delete Entry" , self.VVaWtb   , [])
   VVlrMb = ("Add Entry"  , self.VVktjZ   , [])
   VVkGmL = (optTxt   , self.VVEtU9  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVrLHE = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVhqv2 = FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=24, VVNBO3=VVNBO3, VVJEWY=VVJEWY, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVJcAk=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVLICL, VVSzMt="#0a000000")
  else:
   FFB8Nz(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVYE0P(self, dupl, VVhqv2, title, txt, colList):
  if dupl:
   VVhqv2.VVomXH("Skipped %d duplicate%s" % (dupl, FFW43m(dupl)), 2000)
 def VVwR6Q(self, VVhqv2, title, txt, colList):
  def VVnxYh(key, val): return "%s\t: %s\n" % (key, val or FFwXwL("?", VVeCLm))
  Keys = VVhqv2.VV7cIM()
  Vals = VVhqv2.VVHMjy()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVnxYh(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVfPTB, VVeCLm
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FF3nHt(self, txt + txt1, title=title)
 def VVJRxW(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVaWtb(self, VVhqv2, title, txt, colList):
  if VVhqv2.VVHqmL() == 0 and VVhqv2.VVfbKq() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FF5jVY(self, BF(self.VVI1JR, isLast, VVhqv2), ques)
 def VVI1JR(self, isLast, VVhqv2):
  if isLast:
   FFZ5Mj(self.shareFilePath)
   VVhqv2.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVhqv2.VVHMjy()
   if self.VVy2B8(srcName, srcRef, dstName, dstRef):
    VVhqv2.VVCuQK()
    VVhqv2.VVWVH1()
    FFM3N1(VVhqv2, "Deleted", 500, isGrn=True)
   else:
    FFM3N1(VVhqv2, "Cannot delete from file", 2000)
 def VVktjZ(self, VVhqv2, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VV67J0(VVhqv2, isDvb=True)
  else    : self.VVwujb(VVhqv2, "Source Channel", "#22003344", "#22002233")
 def VVwujb(self, mainTableInst, title, VVl9AY, VVLICL):
  FFRHhp(self, BF(self.VVA8C2, mainTableInst, title), VVhIDJ=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVl9AY=VVl9AY, VVLICL=VVLICL)
 def VVA8C2(self, mainTableInst, title, item=None):
  if item:
   FFuMBP(mainTableInst, BF(self.VVj2pY, mainTableInst, title, item), clearMsg=False)
 def VVj2pY(self, mainTableInst, title, item):
  FFM3N1(mainTableInst)
  if item == "DVB": self.VV67J0(mainTableInst, isDvb=True)
  else   : self.VV67J0(mainTableInst, isDvb=False)
 def VVasV6(self, mainTableInst, chType, VVhqv2, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVhqv2.VVHqmL()
  if   chType == "DVB" : FFsMp0(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFsMp0(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVOazu()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFB8Nz(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVc7vB(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVmgjb((str(mainTableInst.VVfbKq() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFM3N1(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFM3N1(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFM3N1(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VV67J0(mainTableInst, isDvb=False)
   else    : FFbn1D(BF(self.VVwujb, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVhqv2.cancel()
 def VVMWqN(self, item, VVhqv2, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVhqv2.VVj43f(ndx)
 def VV67J0(self, VVhqv2, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVasV6, VVhqv2, typ)
  doneFnc = BF(self.VVMWqN, typ)
  if isDvb: CCBYxw.VVIIhA(VVhqv2 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCBYxw.VVFQgL(VVhqv2, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVIIhA(SELF, title, okFnc, doneFnc=None):
  FFuMBP(SELF, BF(CCBYxw.VVuCqi, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVuCqi(SELF, title, okFnc, doneFnc=None):
  VVkNlM, err = CCn3v3.VVwReR(SELF, CCn3v3.VVp8pu)
  if VVkNlM:
   color = "#0a000022"
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVlUqf = ("Select" , okFnc, [])
   VVNBO3= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVrLHE = (LEFT  , LEFT  , CENTER, LEFT    )
   FFNCSP(SELF, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVl9AY=color, VVLICL=color, VVHZxf=color, VVlUqf=VVlUqf, VVNBO3=VVNBO3, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFB8Nz(SELF, "No DVB Services !")
 @staticmethod
 def VVFQgL(SELF, title, okFnc, doneFnc=None):
  FFuMBP(SELF, BF(CCBYxw.VVOcRg, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVOcRg(SELF, title, okFnc, doneFnc=None):
  VVkNlM = CCBYxw.VV6Xz9()
  if VVkNlM:
   color = "#0a112211"
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVlUqf = ("Select" , okFnc, [])
   VVNBO3= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFNCSP(SELF, None, title=title, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=26, VVl9AY=color, VVLICL=color, VVHZxf=color, VVlUqf=VVlUqf, VVNBO3=VVNBO3, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFB8Nz(SELF, "No IPTV Services !")
 @staticmethod
 def VV6Xz9():
  VVkNlM = []
  files  = CC8Yh1.VVYsfN()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFQDOO(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVCJZW = span.group(1)
    else : VVCJZW = ""
    VVCJZW_lCase = VVCJZW.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVkNlM.append((chName, VVCJZW, url, refCode))
  return VVkNlM
 def VVc7vB(self, srcName, srcRef, dstName, dstRef):
  tree = CCn3v3.VVsbpC(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVM85V(tree, root)
  return True
 def VVy2B8(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCn3v3.VVsbpC(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVJRxW(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVM85V(tree, root)
  return found
 def VVM85V(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCn3v3.VVP0tP(xmlTxt)
  parser = CCn3v3.CCQuMB()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVEtU9(self, VVhqv2, title, txt, colList):
  if self.onlyEpg:
   self.VVfcaz(VVhqv2, "epg")
  else:
   if self.shareIsRef:
    FF5jVY(self, BF(FFuMBP, VVhqv2, BF(self.VVLHH2, VVhqv2)), "Copy all References from Source to Destination ?")
   else:
    VVhIDJ = []
    VVhIDJ.append(("Copy EPG\t (All List)" , "epg"  ))
    VVhIDJ.append(("Copy Picons\t (All List)" , "picon" ))
    FFRHhp(self, BF(self.VVfcaz, VVhqv2), VVhIDJ=VVhIDJ, width=1000)
 def VVfcaz(self, VVhqv2, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVxDOu  , "EPG"
   elif item == "picon": fnc, txt = self.VV0bmy , "PIcons"
   title = "Copy %s" % txt
   tot   = VVhqv2.VVfbKq()
   FF5jVY(self, BF(FFuMBP, VVhqv2, BF(fnc, VVhqv2, title)), "Overwrite %s for %d Service%s ?" % (FFwXwL(txt, VVqZDD), tot, FFW43m(tot)), title=title)
 def VVLHH2(self, VVhqv2):
  files = CC8Yh1.VVYsfN()
  totChange = 0
  if files:
   for path in files:
    txt = FFQDOO(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhqv2.VVOazu():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFBOOj()
  tot = VVhqv2.VVfbKq()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FF3nHt(self, txt)
 def VV0bmy(self, VVhqv2, title):
  if not iCopyfile:
   FFB8Nz(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCTdjW.VVJwSu()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhqv2.VVOazu():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVhqv2.VVfbKq()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FF3nHt(self, txt, title=title)
 def VVxDOu(self, VVhqv2, title):
  txt, err = CCwOKQ.VVs7qK(VVhqv2, title)
  if err : FFB8Nz(self, err, title=title)
  else : FF3nHt(self, txt, title=title)
 class CCQuMB(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVsbpC(SELF, path, withComments=True, title=""):
  try:
   if withComments:
    try:
     return iElem.parse(path, parser=iElem.XMLParser(target=CCn3v3.CCQuMB()))
    except:
     return iElem.parse(path)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFwXwL("XML Parse Error in:", VVeCLm), path)
   txt += "%s\n%s\n\n" % (FFwXwL("Error:", VVeCLm), str(e))
   FF3nHt(SELF, txt, VVHZxf="#11220000", title=title)
   return None
 @staticmethod
 def VVP0tP(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCwOKQ(Screen, CCBYxw):
 VVqhAg  = "BDTSE"
 VVBo0x   = "save"
 VVl1mF   = "load"
 VV7MIG  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VV35C4, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt, modTm = CCwOKQ.VVaXoo()
  qUrl, decodedUrl, iptvRef = CC8Yh1.VVOiYT(self)
  VVhIDJ = []
  VVhIDJ.append((VVuj5g + "Cache File Info." , "inf"))
  VVhIDJ.append(VVuAtK)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVhIDJ.append(FFyXfa("Save EPG to File%s" % fTxt , self.VVBo0x, valid))
  VVhIDJ.append(FFyXfa("Load EPG from File%s" % fTxt , self.VVl1mF, valid))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((VVdSiQ + "Delete EPG (from RAM only)", self.VV7MIG))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVhIDJ.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Translate Current Channel EPG %s(Experimental)" % VVdSiQ, "VVoRHM"))
  FFTlW1(self, VVhIDJ=VVhIDJ)
  self.onShown.append(self.VVtpg1)
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVZb0t()
   elif item in (self.VVBo0x, self.VVl1mF, self.VV7MIG):
    reset = item == self.VVl1mF
    FF5jVY(self, BF(FFuMBP, self, BF(self.VVX9pC, item, reset)), VVZNNf="Continue ?")
   elif item == "refreshIptvEPG"  : CC8Yh1.VVxSdd(self)
   elif item == "VVoRHM" : self.VVoRHM()
   elif item == "copyEpg"    : self.VV0rYM(False, onlyEpg=True)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVX9pC(self, act, reset=False):
  ok = CCwOKQ.VVoyVF(act)
  if ok:
   if reset:
    CCwOKQ.VVBHq9(self)
   FFWB0Q(self, "Done")
  else:
   FFWB0Q(self, "Failed!")
 def VVZb0t(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt, modTm = CCwOKQ.VVaXoo()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n\nModified\t: %s\n" % (path, szTxt or "?", modTm)
   else : txt = "System Settings: %s\n\n%s" % (path, FFwXwL("File not found (check System EPG settings).", VVdSiQ))
   FF3nHt(self, txt, title=title)
  else:
   FFB8Nz(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVRFEe():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVoRHM(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVlUqf  = (""  , BF(self.VV4g4o, title, True) , [])
  VVlrMb = ("Start" , BF(self.VV4g4o, title, False), [])
  VV1FeB = ("Change Language", self.VVHZeZ      , [])
  widths  = (70 , 30)
  VVrLHE = (LEFT , CENTER)
  FFNCSP(self, None, title=title, VVFWkP=self.VV8Q3d(), VVrLHE=VVrLHE, VVN1SU=widths, width=1200, vMargin=20, VVNWWl=30, VVlUqf=VVlUqf, VVlrMb=VVlrMb, VV1FeB=VV1FeB, VVUMPl=2
    , VVl9AY="#11201010", VVLICL=bg, VVHZxf=bg, VVSzMt="#00004455", VVvy9F=bg)
 def VV8Q3d(self):
  Def, ch = "DISABLED", dict(CCwOKQ.VVRFEe())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVFWkP = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVFWkP
 def VVHZeZ(self, VVhqv2, title, txt, colList):
  ndx = VVhqv2.VVHqmL()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCayJh.VVL4yy(self, confItem, title, lst=CCwOKQ.VVRFEe(), cbFnc=BF(self.VVzKtE, VVhqv2), isSave=True)
 def VVzKtE(self, VVhqv2):
  for ndx, row in enumerate(self.VV8Q3d()):
   VVhqv2.VVjqpY(ndx, row)
 def VV4g4o(self, Title, isAsk, VVhqv2, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFM3N1(VVhqv2, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
   refCode, evList, err = CCwOKQ.VVZHjh(refCode)
   fnc = BF(self.VVlnqF, Title, refCode, evList, VVhqv2)
   if   err : FFB8Nz(self, err, title=Title)
   elif isAsk : FF5jVY(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVlnqF(self, title, refCode, evList, VVhqv2):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVbCEH, evList)
      , VVLUmk = BF(self.VVusCN, title, refCode))
  VVhqv2.cancel()
 def VVbCEH(self, evList, VVVRSv):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVVRSv.VVWtjR(totEv)
  VVVRSv.VVPpbS = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCwOKQ.VVtro0(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1)
   VVVRSv.VVFpGs(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVVRSv.VVPpbS = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVusCN(self, title, refCode, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVPpbS
  if newLst: totEv, totOK = CCwOKQ.VV0bIB(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCwOKQ.VVnm5n()
   CCwOKQ.VVBHq9(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FF3nHt(self, txt, title=title)
 @staticmethod
 def VVtro0(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVnxYh(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCwOKQ.VVv1nQ(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVnxYh, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVv1nQ(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFyoN9(txt))
   txt, err = CC8Yh1.VVaxHl(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFtaHD(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCwOKQ.VVc9yq(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVaXoo():
  path = szTxt = modTm = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFoQQd(path)
   szTxt = CCf82q.VVeeDD(sz) if sz > -1 else ""
   modTm = FFzHDX(os.path.getmtime(path))
  return valid, path, sz, szTxt, modTm
 @staticmethod
 def VVw4kR():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVnm5n(): CCwOKQ.VVoyVF(CCwOKQ.VVBo0x)
 @staticmethod
 def VVoyVF(act):
  ec, inst = CCwOKQ.VVw4kR()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVBHq9(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVZHjh(refCode):
  ec, inst = CCwOKQ.VVw4kR()
  if inst:
   try:
    evList = inst.lookupEvent([CCwOKQ.VVqhAg, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VV0bIB(refCode, events, longDescDays=0):
  ec, inst = CCwOKQ.VVw4kR()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVyJ62(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCwOKQ.VVw4kR()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCwOKQ.VVJPqX(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCscAN.CCwOKQ(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVJPqX(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCwOKQ.VV4aBy(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVbLnn(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCwOKQ.VVw4kR()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCwOKQ.VVJPqX(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFzHDX(evTime)
       evEndTxt  = FFzHDX(evEnd)
       evDurTxt  = FFdy8f(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFdy8f(evPos)
        evRem = evEnd - now
        evRemTxt = FFdy8f(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFdy8f(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VV4aBy(event):
  genre = PR = ""
  try:
   genre  = CCwOKQ.VV9OVm(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCwOKQ.VVLSch(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVLSch(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV9OVm(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCwOKQ.VVWHGU()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVWHGU():
  path = VVobIL + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFQDOO(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFQDOO(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVs7qK(VVhqv2, title):
  ec, inst = CCwOKQ.VVw4kR()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhqv2.VVOazu():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCwOKQ.VVqhAg, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCwOKQ.VV0bIB(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCwOKQ.VVnm5n()
  txt  = "Services\t: %d\n"  % VVhqv2.VVfbKq()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVbD6r(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCwOKQ.VViz5a(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCwOKQ.VViz5a(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCwOKQ.VViz5a(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VViz5a(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCwOKQ.VVJPqX(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCwOKQ.VVtro0(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFwXwL(evName, VVdVoc)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFwXwL(evNameTransl, VVdVoc))
    if evTime           : txt += "Start Time\t: %s\n" % FFzHDX(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFzHDX(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFdy8f(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFdy8f(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFdy8f(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFwXwL(evShort, VVmvsU)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFwXwL(evDesc , VVmvsU)
    if txt:
     txt = FFwXwL("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVdVoc) + txt
  return txt
 @staticmethod
 def VVc9yq(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCn3v3(Screen, CCBYxw):
 VVNBrG  = 0
 VVSIwV = 1
 VV9thE  = 2
 VVBf0W  = 3
 VVSBfk = 4
 VVsanQ = 5
 VVntsY = 6
 VVp8pu   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VV35C4, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVq47S = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVhIDJ = self.VVg4Gd()
  FFTlW1(self, VVhIDJ=VVhIDJ, title="Services/Channels")
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self["myMenu"].setList(self.VVg4Gd())
  FFjM4Z(self["myMenu"])
  FFH94q(self)
 def VVg4Gd(self):
  VVhIDJ = []
  c = VVuj5g
  VVhIDJ.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVhIDJ.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVhIDJ.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVhIDJ.append(VVuAtK)
  c = VVdVoc
  VVhIDJ.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVhIDJ.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVhIDJ.append((VVeCLm + "More tables ..."     , "VVxZrV"    ))
  c = VVmvsU
  VVhIDJ.append(VVuAtK)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVhIDJ.append((c + txt          , "VVb5WS"  ))
  else : VVhIDJ.append((txt           ,          ))
  VVhIDJ.append((c + 'Export Services to "channels.xml"'    , "VVgG15"      ))
  VVhIDJ.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVHH6F
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVhIDJ.append((c + "Invalid Services Cleaner"       , "VVk13n"    ))
  c = VVHH6F
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c + "Delete Channels with no names"     , "VV61MS"    ))
  VVhIDJ.append((c + "Delete Empty Bouquets"       , "VVCKCn"     ))
  VVhIDJ.append(VVuAtK)
  VVReaw, VVhCQx = CCn3v3.VV0Xv3()
  if fileExists(VVReaw):
   enab = fileExists(VVhCQx)
   if enab: VVhIDJ.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVhIDJ.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVhIDJ.append(("Reset Parental Control Settings"      , "VVaF6d"    ))
  VVhIDJ.append(("Reload Channels and Bouquets"       , "VVJAZC"      ))
  return VVhIDJ
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCqLbA.VVZoRN(self.session)
   elif item == "openSignal"       : FFUcYA(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFcAqb(self, fncMode=CCscAN.VVOJRT)
   elif item == "lameDB_allChannels_with_refCode"  : FFuMBP(self, self.VVuDjv)
   elif item == "lameDB_allChannels_with_tranaponder" : FFuMBP(self, self.VVgxK3)
   elif item == "VVxZrV"     : self.VVxZrV()
   elif item == "VVb5WS"  : CChSGV.VVb5WS(self)
   elif item == "VVgG15"      : self.VVgG15()
   elif item == "copyEpgPicons"      : self.VV0rYM(False)
   elif item == "SatellitesCleaner"     : FFuMBP(self, self.FFuMBP_SatellitesCleaner)
   elif item == "VVk13n"    : FFuMBP(self, BF(self.VVk13n))
   elif item == "VV61MS"    : FFuMBP(self, self.VV61MS)
   elif item == "VVCKCn"     : self.VVCKCn(self)
   elif item == "enableHiddenChannels"     : self.VVF2v9(True)
   elif item == "disableHiddenChannels"    : self.VVF2v9(False)
   elif item == "VVaF6d"    : FF5jVY(self, self.VVaF6d, "Reset and Restart ?")
   elif item == "VVJAZC"      : FFuMBP(self, BF(CCn3v3.VVJAZC, self))
 def VVxZrV(self):
  VVhIDJ = []
  VVhIDJ.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVhIDJ.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVhIDJ.append(("Services with PIcons for the System"  , "VVxiMJ"    ))
  VVhIDJ.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVhIDJ.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFRHhp(self, self.VVRoc2, VVhIDJ=VVhIDJ, title="Service Information", VVWLSA=True)
 def VVRoc2(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFuMBP(self, BF(self.VVsk3z, title))
   elif ref == "parentalControlChannels"   : FFuMBP(self, BF(self.VVB5vO, title))
   elif ref == "showHiddenChannels"    : FFuMBP(self, BF(self.VV2CX1, title))
   elif ref == "VVxiMJ"    : FFuMBP(self, BF(self.VVPRhT, title))
   elif ref == "servicesWithMissingPIcons"   : FFuMBP(self, BF(self.VV2gyl, title))
   elif ref == "TranspondersStats"     : FFuMBP(self, BF(self.VVaEUg, title))
   elif ref == "SatellitesXmlStats"    : FFuMBP(self, BF(self.VVP8nm, title))
 def VVgG15(self):
  VVhIDJ = []
  VVhIDJ.append(("All DVB-S/C/T Services", "all"))
  VVhIDJ.extend(CCJEC1.VVbosM())
  FFRHhp(self, self.VVgPks, VVhIDJ=VVhIDJ, title="", VVWLSA=True)
 def VVgPks(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCn3v3.VVW9Ct("1:7:")
   else   : lst = FFxxyk(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFeI49(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFzL2x(r)  : sat = "Stream Relay"
       elif FFrhBg(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF77SS(CFG.exportedTablesPath.getValue()), FFERmH())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFWB0Q(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFM3N1(self, "No Services found !", 1500)
 @staticmethod
 def VVJAZC(SELF):
  FFBOOj()
  FFWB0Q(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVuDjv(self):
  self.VVq47S = None
  self.lastfilterUsed  = None
  self.filterObj   = CCf604(self)
  VVkNlM, err = CCn3v3.VVwReR(self, self.VVNBrG)
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVlUqf  = ("Zap"   , self.VVUpfk     , [])
   VVJEWY = (""    , self.VVkBxQ   , [])
   VVkGmL = ("Options"  , self.VVwPTH , [])
   VVlrMb = ("Current Service", self.VVLyQs , [])
   VV1FeB = ("Filter"   , self.VVu9Bw  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVrLHE  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindServices)
 def VVgxK3(self):
  self.VVq47S = None
  self.lastfilterUsed  = None
  self.filterObj   = CCf604(self)
  VVkNlM, err = CCn3v3.VVwReR(self, self.VVSIwV)
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVlUqf  = ("Zap"   , self.VVUpfk      , [])
   VVJEWY = (""    , self.VVkBxQ    , [])
   VVlrMb = ("Current Service", self.VVLyQs  , [])
   VVkGmL = ("Options"  , self.VV9Pl8 , [])
   VV1FeB = ("Filter"   , self.VVgI9M  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVrLHE  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindServices)
 def VVwPTH(self, VVhqv2, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCr5W8(self, VVhqv2)
  VVhIDJ = []
  isMulti = VVhqv2.VVVoic
  if isMulti:
   refCodeList = VVhqv2.VVeAfz(3)
   if refCodeList:
    VVhIDJ.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVhIDJ.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVhIDJ.append(VVuAtK)
    VVhIDJ.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVhIDJ.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVhIDJ.append(VVuAtK)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVhIDJ.append((txt1, "parentalControl_add" ))
    VVhIDJ.append((txt2,        ))
   else:
    VVhIDJ.append((txt1,       ))
    VVhIDJ.append((txt2, "parentalControl_remove" ))
   VVhIDJ.append(VVuAtK)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVhIDJ.append((txt1, "hiddenServices_add"  ))
    VVhIDJ.append((txt2,       ))
   else:
    VVhIDJ.append((txt1,        ))
    VVhIDJ.append((txt2, "hiddenServices_remove" ))
   VVhIDJ.append(VVuAtK)
  cbFncDict = { "parentalControl_add"   : BF(self.VVf1zZ, VVhqv2, refCode, True)
     , "parentalControl_remove"  : BF(self.VVf1zZ, VVhqv2, refCode, False)
     , "hiddenServices_add"   : BF(self.VVrq7s, VVhqv2, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVrq7s, VVhqv2, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVPtZv, VVhqv2, True)
     , "parentalControl_sel_remove" : BF(self.VVPtZv, VVhqv2, False)
     , "hiddenServices_sel_add"  : BF(self.VV6pXR, VVhqv2, True)
     , "hiddenServices_sel_remove" : BF(self.VV6pXR, VVhqv2, False)
     }
  VVhIDJ1, cbFncDict1 = CCn3v3.VVXkrh(self, VVhqv2, servName, 3)
  VVhIDJ.extend(VVhIDJ1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVklJK(VVhIDJ, cbFncDict)
 def VV9Pl8(self, VVhqv2, title, txt, colList):
  servName = colList[0]
  mSel = CCr5W8(self, VVhqv2)
  VVhIDJ, cbFncDict = CCn3v3.VVXkrh(self, VVhqv2, servName, 3)
  mSel.VVklJK(VVhIDJ, cbFncDict)
 @staticmethod
 def VVXkrh(SELF, VVhqv2, servName, refCodeCol):
  tot = VVhqv2.VVv2WG()
  if tot > 0:
   sTxt = FFwXwL("%d Service%s" % (tot, FFW43m(tot)), VVdVoc)
   VVhIDJ = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFpdHF(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFwXwL(servName, VVdVoc)
   VVhIDJ = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCn3v3.VVwgZt, SELF, VVhqv2, refCodeCol, True)
     , "addToBouquet_one" : BF(CCn3v3.VVwgZt, SELF, VVhqv2, refCodeCol, False)
     }
  return VVhIDJ, cbFncDict
 @staticmethod
 def VVwgZt(SELF, VVhqv2, refCodeCol, isMulti):
  picker = CCJEC1(SELF, VVhqv2, "Add to Bouquet", BF(CCn3v3.VVaURE, VVhqv2, refCodeCol, isMulti))
 @staticmethod
 def VVaURE(VVhqv2, refCodeCol, isMulti):
  if isMulti : refCodeList = VVhqv2.VVeAfz(refCodeCol)
  else  : refCodeList = [VVhqv2.VVHMjy()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVf1zZ(self, VVhqv2, refCode, isAddToBlackList):
  VVhqv2.VVrUMm("Processing ...")
  FFbn1D(BF(self.VVeISg, VVhqv2, [refCode], isAddToBlackList))
 def VVPtZv(self, VVhqv2, isAddToBlackList):
  refCodeList = VVhqv2.VVeAfz(3)
  if not refCodeList:
   FFB8Nz(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVhqv2.VVrUMm("Processing ...")
  FFbn1D(BF(self.VVeISg, VVhqv2, refCodeList, isAddToBlackList))
 def VVeISg(self, VVhqv2, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVrsN0, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVrsN0):
   lines = FF9z80(VVrsN0)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVrsN0, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVhqv2.VVVoic
   if isMulti:
    self.VVpBUU(VVhqv2, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVg6UX(VVhqv2, refCode)
    VVhqv2.VV0Sa3()
  else:
   VVhqv2.VVomXH("No changes")
 def VVrq7s(self, VVhqv2, refCode, isHide):
  title = "Change Hidden State"
  if FF7Jqd(refCode):
   VVhqv2.VVrUMm("Processing ...")
   ret = FFuH1v(refCode, isHide)
   if ret : FFuMBP(self, BF(self.VVg6UX, VVhqv2, refCode))
   else : FFB8Nz(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFB8Nz(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVg6UX(self, VVhqv2, refCode):
  VVkNlM, err = CCn3v3.VVwReR(self, self.VVNBrG, VVLueR=[3, [refCode], False])
  done = False
  if VVkNlM:
   data = VVkNlM[0]
   if data[3] == refCode:
    done = VVhqv2.VVuBFc(data)
  if not done:
   self.VVTvxs(VVhqv2, VVhqv2.VV34q2(), self.VVNBrG)
  VVhqv2.VV0Sa3()
 def VVpBUU(self, VVhqv2, totRefCodes):
  VVkNlM, err = CCn3v3.VVwReR(self, self.VVNBrG, VVLueR=self.VVq47S)
  VVhqv2.VVartp(VVkNlM)
  VVhqv2.VVAHRi(False)
  VVhqv2.VVomXH("%d Processed" % totRefCodes)
 def VV6pXR(self, VVhqv2, isHide):
  refCodeList = VVhqv2.VVeAfz(3)
  if not refCodeList:
   FFB8Nz(self, "Nothing selected", title="Change Hidden State")
   return
  VVhqv2.VVrUMm("Processing ...")
  FFbn1D(BF(self.VVQD0L, VVhqv2, refCodeList, isHide))
 def VVQD0L(self, VVhqv2, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFuH1v(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFBOOj(True)
   self.VVpBUU(VVhqv2, len(refCodeList))
  else:
   VVhqv2.VVomXH("No changes")
 def VVu9Bw(self, VVhqv2, title, txt, colList):
  inFilterFnc = BF(self.VVoFzm, VVhqv2) if self.VVq47S else None
  self.filterObj.VVi0iu(1, VVhqv2, 2, BF(self.VVn8fg, VVhqv2), inFilterFnc=inFilterFnc)
 def VVn8fg(self, VVhqv2, item):
  self.VVmnvj(VVhqv2, False, item, 2, self.VVNBrG)
 def VVoFzm(self, VVhqv2, VVCarR, item):
  self.VVmnvj(VVhqv2, True, item, 2, self.VVNBrG)
 def VVgI9M(self, VVhqv2, title, txt, colList):
  inFilterFnc = BF(self.VVIoeZ, VVhqv2) if self.VVq47S else None
  self.filterObj.VVi0iu(2, VVhqv2, 4, BF(self.VVKnIv, VVhqv2), inFilterFnc=inFilterFnc)
 def VVKnIv(self, VVhqv2, item):
  self.VVmnvj(VVhqv2, False, item, 4, self.VVSIwV)
 def VVIoeZ(self, VVhqv2, VVCarR, item):
  self.VVmnvj(VVhqv2, True, item, 4, self.VVSIwV)
 def VVULrK(self, VVhqv2, title, txt, colList):
  inFilterFnc = BF(self.VVs8mL, VVhqv2) if self.VVq47S else None
  self.filterObj.VVi0iu(0, VVhqv2, 4, BF(self.VVAYQW, VVhqv2), inFilterFnc=inFilterFnc)
 def VVAYQW(self, VVhqv2, item):
  self.VVmnvj(VVhqv2, False, item, 4, self.VV9thE)
 def VVs8mL(self, VVhqv2, VVCarR, item):
  self.VVmnvj(VVhqv2, True, item, 4, self.VV9thE)
 def VVmnvj(self, VVhqv2, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVhqv2.VV26F4(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVq47S = None
  else:
   words, asPrefix = CCf604.VV7zA4(words)
   self.VVq47S = [col, words, asPrefix]
  if words: FFuMBP(VVhqv2, BF(self.VVTvxs, VVhqv2, title, mode), clearMsg=False)
  else : FFM3N1(VVhqv2, "Incorrect filter", 2000)
 def VVTvxs(self, VVhqv2, title, mode):
  VVkNlM, err = CCn3v3.VVwReR(self, mode, VVLueR=self.VVq47S, VV4Nwj=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVhqv2.VVOazu():
    try:
     ndx = VVkNlM.index(tuple(list(map(str.strip, row))))
     lst.append(VVkNlM[ndx])
    except:
     pass
   VVkNlM = lst
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVhqv2.VVartp(VVkNlM, title, VVEO5wMsg=True)
  else:
   FFM3N1(VVhqv2, "Not found!", 1500)
 def VVsXU7(self, title, VVFWkP, VVlUqf=None, VVJEWY=None, VVlpv3=None, VVlrMb=None, VVkGmL=None, VV1FeB=None):
  VVlrMb = ("Current Service", self.VVLyQs, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVrLHE = (LEFT  , LEFT  , CENTER, LEFT    )
  FFNCSP(self, None, title=title, header=header, VVFWkP=VVFWkP, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindServices)
 def VVLyQs(self, VVhqv2, title, txt, colList):
  self.VV7aWH(VVhqv2)
 def VVEVM9(self, VVhqv2, title, txt, colList):
  self.VV7aWH(VVhqv2, True)
 def VV7aWH(self, VVhqv2, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVhqv2.VVTlR4(colDict, VVzp4h=True)
   else:
    VVhqv2.VV3g7B(3, refCode, True)
   return
  FFB8Nz(self, "Cannot read current Reference Code !")
 def VVsk3z(self, title):
  self.VVq47S = None
  self.lastfilterUsed  = None
  self.filterObj   = CCf604(self)
  VVkNlM, err = CCn3v3.VVwReR(self, self.VV9thE)
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVJEWY = (""    , self.VVE8RJ , []      )
   VVlrMb = ("Current Service", self.VVEVM9  , []      )
   VV1FeB = ("Filter"   , self.VVULrK   , [], "Loading Filters ..." )
   VVlUqf  = ("Zap"   , self.VVReR8      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVrLHE  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVlrMb=VVlrMb, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindServices)
 def VVE8RJ(self, VVhqv2, title, txt, colList):
  refCode  = self.VVoUS5(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFcAqb(self, fncMode=CCscAN.VVD8Ft, refCode=refCode, chName=chName, text=txt)
 def VVReR8(self, VVhqv2, title, txt, colList):
  refCode = self.VVoUS5(colList)
  FFtU9E(self, refCode)
 def VVUpfk(self, VVhqv2, title, txt, colList):
  FFtU9E(self, colList[3])
 def VVoUS5(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV2du2(VVReaw, mode=0):
  lines = FF9z80(VVReaw, encLst=["UTF-8"])
  return CCn3v3.VVo8ey(lines, mode)
 @staticmethod
 def VVo8ey(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVwReR(SELF, mode, VVLueR=None, VV4Nwj=True, VV8QCM=True):
  VVReaw, err = CCn3v3.VVlBmF(SELF, VV8QCM)
  if err:
   return None, err
  asPrefix = False
  if VVLueR:
   filterCol = VVLueR[0]
   filterWords = VVLueR[1]
   asPrefix = VVLueR[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCn3v3.VVNBrG:
   blackList = None
   if fileExists(VVrsN0):
    blackList = FF9z80(VVrsN0)
    if blackList:
     blackList = set(blackList)
  elif mode == CCn3v3.VVSIwV:
   tp = CCpNxn()
  VVlyQB, VV2HRF = FFXAmG()
  if mode in (CCn3v3.VVsanQ, CCn3v3.VVntsY):
   VVkNlM = {}
  else:
   VVkNlM = []
  tagFound = False
  with ioOpen(VVReaw, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FF0QId(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCn3v3.VV9thE:
       if sTypeInt in VVlyQB:
        STYPE = VV2HRF[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVkNlM.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVkNlM.append(tRow)
       else:
        VVkNlM.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCn3v3.VVp8pu:
        VVkNlM.append((chName, chProv, sat, refCode))
       elif mode == CCn3v3.VVsanQ:
        VVkNlM[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCn3v3.VVntsY:
        VVkNlM[chName] = refCode
       elif mode == CCn3v3.VVNBrG:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVkNlM.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVkNlM.append(tRow)
        else:
         VVkNlM.append(tRow)
       elif mode == CCn3v3.VVSIwV:
        if sTypeInt in VVlyQB:
         STYPE = VV2HRF[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVeuXj(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVkNlM.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVkNlM.append(tRow)
        else:
         VVkNlM.append(tRow)
       elif mode == CCn3v3.VVBf0W:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVkNlM.append((chName, chProv, sat, refCode))
       elif mode == CCn3v3.VVSBfk:
        VVkNlM.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVkNlM and VV4Nwj:
   FFB8Nz(SELF, "No services found!")
  return VVkNlM, ""
 def VVB5vO(self, title):
  if fileExists(VVrsN0):
   lines = FF9z80(VVrsN0)
   if lines:
    newRows = []
    VVkNlM, err = CCn3v3.VVwReR(self, self.VVSBfk)
    if VVkNlM:
     lines = set(lines)
     for item in VVkNlM:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVkNlM = newRows
      VVkNlM.sort(key=lambda x: x[0].lower())
      VVJEWY = ("", self.VVkBxQ, [])
      VVlUqf = ("Zap", self.VVUpfk, [])
      self.VVsXU7(title, VVkNlM, VVlUqf=VVlUqf, VVJEWY=VVJEWY)
     else:
      FF3nHt(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVkNlM)))
   else:
    FFWB0Q(self, "No active Parental Control services.", FFNcNO())
  else:
   FFM8jr(self, VVrsN0)
 def VV2CX1(self, title):
  VVkNlM, err = CCn3v3.VVwReR(self, self.VVBf0W)
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVJEWY = ("" , self.VVkBxQ, [])
   VVlUqf  = ("Zap", self.VVUpfk, [])
   self.VVsXU7(title, VVkNlM, VVlUqf=VVlUqf, VVJEWY=VVJEWY)
  elif err:
   pass
  else:
   FFWB0Q(self, "No hidden services.", FFNcNO())
 def VVk13n(self):
  title = "Services unused in Tuner Configuration"
  VVReaw, err = CCn3v3.VVlBmF(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCn3v3.VVvdkM()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVe36U(str(item[0]))
    nsLst.add(ns)
  sysLst = CCn3v3.VVW9Ct("1:7:")
  tpLst  = CCn3v3.VV2du2(VVReaw, mode=1)
  VVkNlM = []
  for refCode, chName in sysLst:
   servID = CCn3v3.VVBMKc(refCode)
   tpID = CCn3v3.VVbMPw(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVkNlM.append((chName, FFeI49(refCode, False), refCode, servID))
  if VVkNlM:
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVkGmL = ("Options"   , BF(self.VV9NIT, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVrLHE  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVkGmL=VVkGmL, VVl9AY="#0a001122", VVLICL="#0a001122", VVHZxf="#0a001122", VVSzMt="#00004455", VVvy9F="#0a333333", VVRt6l="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFWB0Q(self, "No invalid service found !", title=title)
 def VV9NIT(self, Title, VVhqv2, title, txt, colList):
  mSel = CCr5W8(self, VVhqv2)
  isMulti = VVhqv2.VVVoic
  if isMulti : txt = "Remove %s Services" % FFwXwL(str(VVhqv2.VVv2WG()), VVeCLm)
  else  : txt = "Remove : %s" % FFwXwL(VVhqv2.VVHMjy()[0], VVeCLm)
  VVhIDJ = [(txt, "del")]
  cbFncDict = {"del": BF(FFuMBP, VVhqv2, BF(self.VVVBGH, VVhqv2, Title))}
  mSel.VVklJK(VVhIDJ, cbFncDict)
 def VVVBGH(self, VVhqv2, title):
  VVReaw, err = CCn3v3.VVlBmF(self, title=title)
  if err:
   return
  isMulti = VVhqv2.VVVoic
  skipLst = []
  if isMulti : skipLst = VVhqv2.VVeAfz(3)
  else  : skipLst = [VVhqv2.VVHMjy()[3]]
  tpLst = CCn3v3.VV2du2(VVReaw, mode=0)
  servLst = CCn3v3.VV2du2(VVReaw, mode=10)
  tmpDbFile = VVReaw + ".tmp"
  lines   = FF9z80(VVReaw)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFcZm9("mv -f '%s' '%s'" % (tmpDbFile, VVReaw))
  VVkNlM = []
  for row in VVhqv2.VVOazu():
   if not row[3] in skipLst:
    VVkNlM.append(row)
  FFBOOj()
  FF3nHt(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVkNlM:
   VVhqv2.VVartp(VVkNlM, title)
   VVhqv2.VVAHRi(False)
  else:
   VVhqv2.cancel()
 def VVaEUg(self, title):
  VVReaw, err = CCn3v3.VVlBmF(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV4uck(VVReaw)
  txt = FFwXwL("Total Transponders:\n\n", VVEhqe)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFwXwL("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVEhqe)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFGFoO(item), satList.count(item))
  FF3nHt(self, txt, title)
 def VV4uck(self, VVReaw):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVReaw, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVP8nm(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFM8jr(self, path, title=title)
   return
  elif not CCf82q.VVg9pn(self, path, title):
   return
  if not CC1coX.VV0r6H(self):
   return
  tree = CCn3v3.VVsbpC(self, path, title=title)
  if not tree:
   return
  VVkNlM = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FF0QId(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVkNlM.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVkNlM:
   VVkNlM.sort(key=lambda x: int(x[1]))
   VVlrMb = ("Current Satellite", BF(self.VV0y8D, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVrLHE  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=25, VVOOaR=1, VVlrMb=VVlrMb, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFB8Nz(self, "No data found !", title=title)
 def VV0y8D(self, satCol, VVhqv2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  sat = FFeI49(refCode, False)
  for ndx, row in enumerate(VVhqv2.VVOazu()):
   if sat == row[satCol].strip():
    VVhqv2.VVj43f(ndx)
    break
  else:
   FFM3N1(VVhqv2, "No listed !", 1500)
 def FFuMBP_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFB8Nz(self, "No Satellites found !")
   return
  usedSats = CCn3v3.VVvdkM()
  VVkNlM = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVkNlM.append((sat[1], posTxt, FF0QId(sat[0]), tuners, str(posVal)))
  if VVkNlM:
   VVHZxf = "#11222222"
   VVkNlM.sort(key=lambda x: int(x[1]))
   VVlrMb = ("Current Satellite" , BF(self.VV0y8D, 2) , [])
   VVkGmL = ("Options"   , self.VVFBqc  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVrLHE  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVl9AY=VVHZxf, VVLICL=VVHZxf, VVHZxf=VVHZxf, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFB8Nz(self, "No data found !")
 def VVFBqc(self, VVhqv2, title, txt, colList):
  mSel = CCr5W8(self, VVhqv2)
  isMulti = VVhqv2.VVVoic
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFwXwL(str(VVhqv2.VVv2WG()), VVeCLm)
  else  : txt = "Remove ALL Services on : %s" % FFwXwL(VVhqv2.VVHMjy()[0], VVeCLm)
  VVhIDJ = []
  VVhIDJ.append((txt, "deleteSat"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Delete Empty Bouquets", "VVCKCn"))
  cbFncDict = { "deleteSat"   : BF(FFuMBP, VVhqv2, BF(self.VVSioB, VVhqv2))
     , "VVCKCn" : BF(self.VVCKCn, VVhqv2)
     }
  mSel.VVklJK(VVhIDJ, cbFncDict)
 def VVSioB(self, VVhqv2):
  posLst = []
  isMulti = VVhqv2.VVVoic
  posLst = []
  if isMulti : posLst = VVhqv2.VVeAfz(4)
  else  : posLst = [VVhqv2.VVHMjy()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVe36U(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVrHfy(nsLst)
  FFBOOj(True)
  FF3nHt(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVCKCn(self, winObj):
  title = "Delete Empty Bouquets"
  FF5jVY(self, BF(FFuMBP, winObj, BF(self.VVHC0S, title)), "Delete bouquets with no services ?", title=title)
 def VVHC0S(self, title):
  bList = CCJEC1.VVvYk6()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCJEC1.VVmvex(bRef)
    bPath = VVSs5p + bFile
    FFZ5Mj(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVSs5p + fil
     if fileExists(path):
      lines = FF9z80(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFBOOj(True)
  if bNames: txt = "%s\n\n%s" % (FFwXwL("Deleted Bouquets:", VVdVoc), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FF3nHt(self, txt, title=title)
 def VVe36U(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVrHfy(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVSs5p)
  for srcF in files:
   if fileExists(srcF):
    lines = FF9z80(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFKGMY(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVPRhT(self, title)   : self.VVxiMJ(title, True)
 def VV2gyl(self, title) : self.VVxiMJ(title, False)
 def VVxiMJ(self, title, isWithPIcons):
  piconsPath = CCTdjW.VVJwSu()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCTdjW.VVSXaF(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVkNlM, err = CCn3v3.VVwReR(self, self.VVSBfk)
    if VVkNlM:
     channels = []
     for (chName, chProv, sat, refCode) in VVkNlM:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFbyIO(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVkNlM)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVnxYh(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVnxYh("PIcons Path"  , piconsPath)
     txt += VVnxYh("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVnxYh("Total services" , totalServices)
     txt += VVnxYh("With PIcons"  , totalWithPIcons)
     txt += VVnxYh("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF3nHt(self, txt)
     else:
      VVJEWY     = (""      , self.VVkBxQ , [])
      if isWithPIcons : VV1FeB = ("Export Current PIcon", self.VVM0aP  , [])
      else   : VV1FeB = None
      VVkGmL     = ("Statistics", FF3nHt, [txt])
      VVlUqf      = ("Zap", self.VVUpfk, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVsXU7(title, channels, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVkGmL=VVkGmL, VV1FeB=VV1FeB)
   else:
    FFB8Nz(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFB8Nz(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVkBxQ(self, VVhqv2, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFcAqb(self, fncMode=CCscAN.VVD8Ft, refCode=refCode, chName=chName, text=txt)
 def VVM0aP(self, VVhqv2, title, txt, colList):
  png, path = CCTdjW.VV0iL6(colList[3], colList[0])
  if path:
   CCTdjW.VV73UN(self, png, path)
 @staticmethod
 def VV0Xv3():
  VVReaw  = "%slamedb" % VVSs5p
  VVhCQx = "%slamedb.disabled" % VVSs5p
  return VVReaw, VVhCQx
 @staticmethod
 def VVnkJV():
  VVlXPB  = "%slamedb5" % VVSs5p
  VVsZQv = "%slamedb5.disabled" % VVSs5p
  return VVlXPB, VVsZQv
 def VVF2v9(self, isEnable):
  VVReaw, VVhCQx = CCn3v3.VV0Xv3()
  if isEnable and not fileExists(VVhCQx):
   FFWB0Q(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVReaw):
   FFB8Nz(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF5jVY(self, BF(self.VVl8Bt, isEnable), "%s Hidden Channels ?" % word)
 def VVl8Bt(self, isEnable):
  VVReaw , VVhCQx = CCn3v3.VV0Xv3()
  VVlXPB, VVsZQv = CCn3v3.VVnkJV()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVhCQx, VVhCQx, VVReaw)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVsZQv, VVsZQv, VVlXPB)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVReaw  , VVReaw , VVhCQx)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVlXPB , VVlXPB, VVsZQv)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVhCQx, VVReaw )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVsZQv, VVlXPB)
  ok = FFcZm9(cmd)
  FFBOOj()
  if ok: FFWB0Q(self, "Hidden List %s" % word)
  else : FFB8Nz(self, "Error while restoring:\n\n%s" % fileName)
 def VVaF6d(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %s | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVabb3
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %s" % VVabb3
  FFsji8(self, cmd)
 def VV61MS(self):
  VVReaw, err = CCn3v3.VVlBmF(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFZ5Mj(tmpFile)
  totChan = totRemoved = 0
  lines = FF9z80(VVReaw, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FF5jVY(self, BF(FFuMBP, self, BF(self.VVXXjM, tmpFile, VVReaw, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFW43m(totRemoved), totChan, FFW43m(totChan))
      , callBack_No=BF(self.VVmY6P, tmpFile))
  else:
   FF3nHt(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVXXjM(self, tmpFile, VVReaw, totRemoved, totChan):
  FFcZm9("mv -f '%s' '%s'" % (tmpFile, VVReaw))
  FFBOOj()
  FF3nHt(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVmY6P(self, tmpFile):
  FFZ5Mj(tmpFile)
 @staticmethod
 def VVlBmF(SELF, VV8QCM=True, title=""):
  VVReaw, VVhCQx = CCn3v3.VV0Xv3()
  if   not fileExists(VVReaw)       : err = "File not found !\n\n%s" % VVReaw
  elif not CCf82q.VVg9pn(SELF, VVReaw) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VV8QCM:
   FFB8Nz(SELF, err, title=title)
  return VVReaw, err
 @staticmethod
 def VVbMPw(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVBMKc(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVW9Ct(servTypes):
  VVQHDq  = eServiceCenter.getInstance()
  VV1LdX   = '%s ORDER BY name' % servTypes
  VVK51a   = eServiceReference(VV1LdX)
  VVMy6Y = VVQHDq.list(VVK51a)
  if VVMy6Y: return VVMy6Y.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVvdkM():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCscAN(Screen):
 VVOJRT  = 0
 VVVOT1   = 1
 VVzA1c   = 2
 VVD8Ft    = 3
 VVFOvX    = 4
 VV1VYQ   = 5
 VVcZ3A   = 6
 VVQ1jV    = 7
 VVpttR   = 8
 VVHzXh   = 9
 VVmhwo   = 10
 VVY5OL   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFMkht(VVegdj, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVOJRT)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFwXwL("%s\n", VV6rcy) % SEP
  self.picViewer  = None
  FFTlW1(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVBI7b })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self["myLabel"].VVsOYo(outputFileToSave="chann_info")
  if   self.fncMode == self.VVOJRT : fnc = self.VVvVJQ
  elif self.fncMode == self.VVVOT1  : fnc = self.VVvVJQ
  elif self.fncMode == self.VVzA1c  : fnc = self.VVvVJQ
  elif self.fncMode == self.VVD8Ft  : fnc = self.VV3lF9
  elif self.fncMode == self.VVFOvX  : fnc = self.VVdIbA
  elif self.fncMode == self.VV1VYQ  : fnc = self.VVgHtj
  elif self.fncMode == self.VVcZ3A  : fnc = self.VV6Ja7
  elif self.fncMode == self.VVQ1jV  : fnc = self.VVvqDC
  elif self.fncMode == self.VVpttR  : fnc = self.VVQdF4
  elif self.fncMode == self.VVHzXh : fnc = self.VVUOQM
  elif self.fncMode == self.VVmhwo  : fnc = self.VVe69y
  elif self.fncMode == self.VVY5OL : fnc = self.VVCG7f
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVKLWe
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVjhj8()
  FFbn1D(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVcoIX()
 def VV3nxF(self, err):
  self["myLabel"].setText(err)
  FFOrd9(self["myTitle"], "#22200000")
  FFOrd9(self["myBody"], "#22200000")
  self["myLabel"].VVdzKe("#22200000")
  self["myLabel"].VVjhj8()
 def VVvVJQ(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  self.refCode = refCode
  self.VVwIfC(chName)
 def VV3lF9(self):
  self.VVwIfC(self.chName)
 def VVdIbA(self):
  self.VVwIfC(self.chName)
 def VVgHtj(self):
  self.VVwIfC(self.chName)
 def VV6Ja7(self):
  self.VVwIfC("Picon Info")
 def VVvqDC(self):
  self.VVwIfC(self.chName)
 def VVQdF4(self):
  self.VVwIfC(self.chName)
 def VVUOQM(self):
  self.VVwIfC(self.chName)
 def VVe69y(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFbClU(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VV7Ahq(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVwIfC(self.chName)
 def VVCG7f(self):
  self.VVwIfC(self.chName)
 def VVKLWe(self):
  self.VVELRo(self.picPath)
  self.VVXyiW()
 def VVwIfC(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFWctZ(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVXrm7(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FFwXwL(self.VVMxgN(tUrl), VVlrJC)
  if not self.epg:
   epg = CCwOKQ.VVbD6r(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVELRo(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCTdjW.VV0iL6(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVELRo(path)
  self.VVqV7p()
  self.VV4N5t(decodedUrl)
  self.VVXyiW()
 def VVXyiW(self):
  self["myLabel"].setText(self.text or "   No active service", VVCqdo=VVEPk2)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVjhj8(minHeight=minH)
 def VV4N5t(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFrhBg(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVVm7p(FFtaHD(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCIbAM.VVxkTN(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCIbAM.VVxkTN(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FF6F4t("EPG:", VVdVoc) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVqV7p()
 def VVqV7p(self):
  if not self.piconShown and self.picUrl:
   path, err = FFlHhH(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVELRo(path)
    if self.piconShown and self.refCode:
     self.VVic1V(path, self.refCode)
 def VVic1V(self, path, refCode):
  if path and fileExists(path) and FFBf4e("ffmpeg"):
   pPath = CCTdjW.VVJwSu()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCscAN.VVsRkF(path)
    cmd += FFUGBP("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFcZm9(cmd)
 def VVELRo(self, path):
  if path and fileExists(path):
   err, w, h = self.VVtav9(path)
   if not err:
    if h > w:
     self.VVzxi8(self["myPicF"], w, h, True)
     self.VVzxi8(self["myPicB"], w, h, False)
     self.VVzxi8(self["myPic"] , w, h, False)
   self.picViewer = CCpfQt.VV8yot(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVzxi8(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVtav9(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFkd4T(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVXrm7(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFwXwL(chName, VVdVoc)
  txt += self.VVnxYh(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFwXwL(state, VVdSiQ)
   txt += "State\t: %s\n" % state
  w = FFtI1N(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFtI1N(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVPrsu(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVnxYh(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVnxYh(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVnxYh(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVBNDL()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVnLfD()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCscAN.VVGaIS(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFwXwL("Stream-Relay" if FFzL2x(decodedUrl) else "IPTV", VVEhqe)
   txt += self.VVRGP8(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VV3lrR(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCpNxn()
    tpTxt, namespace = tp.VVt5Ag(refCode)
    if tpTxt:
     txt += FFwXwL("Tuner:\n", VVdVoc)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFwXwL("Codes:\n", VVdVoc)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVnxYh(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVnxYh(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVnxYh(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVnxYh(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVnxYh(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVnxYh(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVnxYh(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVnxYh(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVnxYh(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVPrsu(info):
  if info:
   aspect = FFtI1N(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVnxYh(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFtI1N(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVEiXy(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVEiXy(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVBNDL(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVnLfD(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VV3lrR(self, refCode, iptvRef, chName):
  refCode = FFoeJu(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFQDOO(VVSs5p + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFQDOO(VVSs5p + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVFWkP = []
  tmpRefCode = FFtaHD(refCode)
  for item in fList:
   path = VVSs5p + item
   if fileExists(path):
    txt = FFQDOO(path)
    if tmpRefCode in FFtaHD(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVFWkP.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVFWkP:
   if len(VVFWkP) == 1:
    txt += "%s\t: %s%s\n" % (FFwXwL("Bouquet", VVdVoc), VVFWkP[0][0], " (%s)" % VVFWkP[0][1] if VVvct2 else "")
   else:
    txt += FFwXwL("Bouquets:\n", VVdVoc)
    for ndx, item in enumerate(VVFWkP):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVvct2 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVRGP8(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFpqbA(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCIbAM()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFwXwL("URL:", VVEhqe) + "\n%s\n" % self.VVMxgN(decodedUrl)
  else:
   txt = "\n"
   txt += FFwXwL("Reference:", VVEhqe) + "\n%s\n" % refCode
  return txt
 def VVMxgN(self, url):
  if not FFzL2x(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVT9SH:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFtaHD(url)
 def VVVm7p(self, decodedUrl):
  if not CCBOP8.VVk4Hv():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC8Yh1.VVaxHl(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVBPJ7(tDict)
   elif uType == "movie" : epg, picUrl = CCscAN.VVZIuJ(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVBPJ7(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC8Yh1.VVfIBq(item, "title"    , is_base64=True )
     lang    = CC8Yh1.VVfIBq(item, "lang"         ).upper()
     description   = CC8Yh1.VVfIBq(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC8Yh1.VVfIBq(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC8Yh1.VVfIBq(item, "start_timestamp"      )
     stop_timestamp  = CC8Yh1.VVfIBq(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC8Yh1.VVfIBq(item, "stop_timestamp"       )
     now_playing   = CC8Yh1.VVfIBq(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VViVXH, ""
      else     : color, txt = VVdSiQ , "    (CURRENT EVENT)"
      epg += FFwXwL("_" * 32 + "\n", VV6rcy)
      epg += FFwXwL("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFwXwL(description, VVlrJC)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCwOKQ.VV0bIB(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVZIuJ(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC8Yh1.VVfIBq(item, "movie_image" )
    genre  = CC8Yh1.VVfIBq(item, "genre"   ) or "-"
    plot  = CC8Yh1.VVfIBq(item, "plot"   ) or "-"
    country  = CC8Yh1.VVfIBq(item, "country"  ) or "-"
    actors  = CC8Yh1.VVfIBq(item, "actors"   ) or "-"
    cast  = CC8Yh1.VVfIBq(item, "cast"   ) or "-"
    rating  = CC8Yh1.VVfIBq(item, "rating"   ) or "-"
    director = CC8Yh1.VVfIBq(item, "director"  ) or "-"
    releasedate = CC8Yh1.VVfIBq(item, "releasedate" ) or "-"
    duration = CC8Yh1.VVfIBq(item, "duration"  ) or "-"
    try:
     lang = CC8Yh1.VVfIBq(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFwXwL(cast if cast != "-" else actors, VVlrJC)
    epg += "Plot:\n%s"    % FFwXwL(plot, VVlrJC)
   except:
    pass
  return epg, movie_image
 def VVBI7b(self):
  if VVT9SH:
   def VVnxYh(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVnxYh(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCIbAM()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVnxYh(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFM3N1(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVODqh(SELF):
  if not CCskCr.VVztta(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF)
  err = url =  fSize = resumable = ""
  if FFzKhS(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCIbAM.VV4H6G(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCIbAM.VVNqjQ(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFB8Nz(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCf82q.VVeeDD(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFwXwL(" (M3U/M3U8 File)", VVlrJC)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCSDOM.VV1qeD(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVNpAU(subj, val):
   return "%s\n%s\n\n" % (FFwXwL("%s:" % subj, VVdVoc), val)
  title = "File Size"
  txt  = VVNpAU(title , fSize or "?")
  txt += VVNpAU("Name" , chName)
  txt += VVNpAU("URL" , url)
  if resumable: txt += VVNpAU("Supports Download-Resume", resumable)
  if err  : txt += FFwXwL("Error:\n", VVdSiQ) + err
  FF3nHt(SELF, txt, title=title)
 @staticmethod
 def VVGaIS(SELF):
  fPath, fDir, fName = CCf82q.VVs3Cw(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVsRkF(path):
  return FFUGBP("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVllaU(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCTdjW.VVJwSu() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVPHoh(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFrhBg(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFKGMY(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCIbAM():
 def __init__(self):
  self.VV6GXl()
  self.VVCvVr    = ""
  self.VV86Zo   = "#f#11ffffaa#User"
  self.VVuPp3   = "#f#11aaffff#Server"
 def VV6GXl(self):
  self.VV47AR   = ""
  self.VVS3cB    = ""
  self.VVyOCY   = ""
  self.VVwYV5 = ""
  self.VVFk7g  = ""
  self.VVW4im = 0
 def VVUnRS(self, url, mac, ph1="", VVzp4h=True):
  self.VV6GXl()
  self.VVCvVr = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVqjET(url)
  if not host:
   if VVzp4h:
    self.VVqMWO("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVXAwQ(mac)
  if not host:
   if VVzp4h:
    self.VVqMWO("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV47AR = host
  self.VVS3cB  = mac
  return True
 def VVJY6F(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVCvVr, "")
 def VVqjET(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVXAwQ(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVNMql(self):
  res, err = self.VV4XWK(self.VVIzJ9())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VV47AR.endswith("/c"):
    self.VV47AR = self.VV47AR[:-2]
    res, err = self.VV4XWK(self.VVIzJ9())
   elif self.VV47AR.endswith("/stalker_portal"):
    self.VV47AR = self.VV47AR[:-15]
    res, err = self.VV4XWK(self.VVIzJ9())
   else:
    self.VV47AR += "/c"
    res, err = self.VV4XWK(self.VVIzJ9())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC8Yh1.VVfIBq(tDict["js"], "token")
    rand  = CC8Yh1.VVfIBq(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VV0ZY9(self, VVzp4h=True):
  if not self.VVCvVr:
   self.VV10rX()
  err = blkMsg = FFWB0QTxt = ""
  try:
   token, rand, err = self.VVNMql()
   if token:
    self.VVyOCY = token
    self.VVwYV5 = rand
    if rand:
     self.VVW4im = 2
    prof, retTxt = self.VVn6uf(True)
    if prof:
     self.VVFk7g = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVW4im = 3
      prof, retTxt = self.VVn6uf(False)
      if retTxt:
       self.VVFk7g = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFWB0QTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFWB0QTxt: tErr += "\n%s" % FFWB0QTxt
  if VVzp4h:
   self.VVqMWO(tErr)
  return "", "", tErr
 def VV10rX(self):
  try:
   import requests
   url = self.VVD3Aa()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCIbAM.VVNqjQ(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCIbAM.VVNqjQ(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VV47AR = url
       self.VVCvVr = span.group(1)
       return
  except:
   pass
  self.VVCvVr = "/server/load.php"
 def VVD3Aa(self):
  url = self.VV47AR.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VV8gLt(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VV4XWK("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VV4XWK("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVn6uf(self, capMac):
  res, err = self.VV4XWK(self.VVOlXd(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC8Yh1.VVfIBq(tDict["js"], "block_%s" % word)
    FFWB0QTxt = CC8Yh1.VVfIBq(tDict["js"], word)
    return tDict, FFWB0QTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVOlXd(self, capMac):
  param = ""
  if self.VVFk7g or self.VVwYV5:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVS3cB.upper() if capMac else self.VVS3cB.lower(), self.VVwYV5))
  return self.VVkV5v() + "type=stb&action=get_profile" + param
 exec(FFbClU("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVYQy4(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV5YPY()
  if len(rows) < 10:
   rows = self.VVbFGr()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV47AR ))
   rows.append(("MAC (from URL)" , self.VVS3cB ))
   rows.append(("Token"   , self.VVyOCY ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VV86Zo  , "MAC" , self.VVS3cB ))
   rows.append(("2", self.VVuPp3, "Host" , self.VV47AR ))
   rows.append(("2", self.VVuPp3, "Token" , self.VVyOCY ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVxEdw(self, isPhp=True, VVzp4h=False):
  token, profile, tErr = self.VV0ZY9(VVzp4h)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VV7ij6()
  res, err = self.VV4XWK(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC8Yh1.VVfIBq(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFyoN9(span.group(2))
     pass1 = FFyoN9(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV5YPY(self):
  m3u_Url, host, user1, pass1, err = self.VVxEdw()
  rows = []
  if m3u_Url:
   res, err = self.VV4XWK(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFzHDX(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VV86Zo, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFzHDX(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVuPp3, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVbFGr(self):
  token, profile, tErr = self.VV0ZY9()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF4nUF(val): val = FFbClU(val.decode("UTF-8"))
     else     : val = self.VVS3cB
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFzHDX(int(parts[1]))
      if parts[2] : ends = FFzHDX(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFzHDX(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV7Ahq(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VV0ZY9(VVzp4h=False)
  if not token:
   return ""
  crLinkUrl = self.VVZ7FB(mode, chCm, epNum, epId)
  res, err = self.VV4XWK(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC8Yh1.VVfIBq(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVkV5v(self):
  return self.VV47AR + self.VVCvVr + "?"
 def VVIzJ9(self):
  return self.VVkV5v() + "type=stb&action=handshake&token=&mac=%s" % self.VVS3cB
 def VVDTjW(self, mode):
  url = self.VVkV5v() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVHkme(self, catID):
  return self.VVkV5v() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVrV3C(self, mode, catID, page):
  url = self.VVkV5v() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVXlnz(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVkV5v() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVEzf1(self, stID):
  return self.VVkV5v() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVZ7FB(self, mode, chCm, serCode, serId):
  url = self.VVkV5v() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV7ij6(self):
  return self.VVkV5v() + "type=itv&action=create_link"
 def VVefbI(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVZ101(catID, stID, chNum)
  query = self.VVc7Jm(mode, self.VVJY6F(), FFNbl8(host), FFNbl8(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVc7Jm(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVoANg(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVc7Jm(mode, ph1, host, mac, epNum, epId, FFyoN9(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFbClU(host)
  mac   = FFbClU(mac)
  valid = False
  if self.VVqjET(playHost) and self.VVqjET(host) and self.VVqjET(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VV4XWK(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCIbAM.VVNqjQ()
   if self.VVyOCY:
    headers["Authorization"] = "Bearer %s" % self.VVyOCY
   if useCookies : cookies = {"mac": self.VVS3cB, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVTbwO(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCIbAM.VVNqjQ(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVNqjQ():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVqMWO(self, err, title="Portal Browser"):
  FFB8Nz(self, str(err), title=title)
 def VVVc72(self, mode):
  if   mode in ("itv"  , CC8Yh1.VVL8JW , CC8Yh1.VV6G9Q)  : return "Live"
  elif mode in ("vod"  , CC8Yh1.VVTHW6 , CC8Yh1.VVR002)  : return "VOD"
  elif mode in ("series" , CC8Yh1.VVLLfH , CC8Yh1.VV9two) : return "Series"
  else                          : return "IPTV"
 def VVtf6s(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVVc72(mode), FFwXwL(searchName, VVlrJC))
 def VVrMo0(self, catchup=False):
  VVhIDJ = []
  VVhIDJ.append(("Live"    , "live"  ))
  VVhIDJ.append(("VOD"    , "vod"   ))
  VVhIDJ.append(("Series"   , "series"  ))
  if catchup:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Catch-up TV" , "catchup"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Account Info." , "accountInfo" ))
  return VVhIDJ
 @staticmethod
 def VV9LRd(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCIbAM()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
  if valid:
   ok = p.VVUnRS(host, mac, ph1, VVzp4h=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVxEdw(isPhp=False, VVzp4h=False)
    streamId = CCIbAM.VV1o8t(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VV1o8t(decodedUrl):
  p = CCIbAM()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFbClU(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VV4H6G(decodedUrl):
  p = CCIbAM()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
  if valid:
   if CCIbAM.VVRKJQ(chCm):
    return FFtaHD(chCm)
   else:
    ok = p.VVUnRS(host, mac, ph1, VVzp4h=False)
    if ok:
     try:
      chUrl = p.VV7Ahq(mode, chCm, epNum, epId)
      return FFtaHD(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVRKJQ(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVxkTN(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCIbAM()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
   if valid:
    if not stID:
     stID = CCIbAM.VV1o8t(decodedUrl)
    if stID:
     if p.VVUnRS(host, mac, ph1, VVzp4h=False):
      token, profile, tErr = p.VV0ZY9(VVzp4h=False)
      if token:
       res, err = p.VV4XWK(p.VVEzf1(stID))
       if res:
        epg, err = CCIbAM.VV7OvK(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCIbAM.VV7OvK(res.text, retLst=True)
         if pList:
          totEv, totOK = CCwOKQ.VV0bIB(refCode, pList)
  return epg, err
 @staticmethod
 def VV7OvK(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CC8Yh1.VVfIBq(item, "actor"       )
    category   = CC8Yh1.VVfIBq(item, "category"      )
    descr    = CC8Yh1.VVfIBq(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CC8Yh1.VVfIBq(item, "director"      )
    name    = CC8Yh1.VVfIBq(item, "name"   , is_base64=True)
    start_timestamp  = CC8Yh1.VVfIBq(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CC8Yh1.VVfIBq(item, "start_timestamp"    )
    stop_timestamp  = CC8Yh1.VVfIBq(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CC8Yh1.VVfIBq(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFwXwL("    (CURRENT EVENT)", VVuj5g)
     except:
      pass
     if not skip:
      epg += FFwXwL("_" * 32 + "\n", VV6rcy)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFwXwL(name, VVdVoc)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFwXwL(descr , VVlrJC) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFwXwL(category, VVlrJC) if category else ""
      epg += "Actors:\n%s\n"  % FFwXwL(actor , VVlrJC) if actor else ""
      epg += "Director:\n%s\n" % FFwXwL(director, VVlrJC) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCwwJU(CCIbAM):
 def __init__(self):
  CCIbAM.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVj8He(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVoANg(decodedUrl)
  if valid:
   if self.VVUnRS(host, mac, ph1, VVzp4h=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVemSS(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   if self.chCm.startswith("Zz1"):
    self.chCm = FFbClU(self.chCm[3:])
   else:
    chUrl = self.VV7Ahq(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCIbAM.VVRKJQ(self.chCm):
   chUrl = FFtaHD(self.chCm)
   chUrl = FFyoN9(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVit0d(chUrl)
  bPath = CCJEC1.VVVtxo()
  if newIptvRef:
   if passedSELF:
    FFtU9E(passedSELF, newIptvRef, VVpkYJ=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFtU9E(self, newIptvRef, VVpkYJ=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVjbed(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVit0d(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVjbed(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF9z80(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFBOOj()
class CCWFaD(CCwwJU):
 def __init__(self, passedSession):
  CCwwJU.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVr491(VVYijj  )
  Main_Menu.VVr491(VVnza8)
  Main_Menu.VVr491(VVOR6M  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVgWnb, iPlayableService.evEOF: self.VVCeUi, iPlayableService.evEnd: self.VVjQH4})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVpz8Y)
  except:
   self.timer2.callback.append(self.VVpz8Y)
  self.timer2.start(3000, False)
  self.VVpz8Y()
 def VVpz8Y(self):
  if not CFG.downloadMonitor.getValue():
   self.VVuowk()
   return
  lst = CCSDOM.VVDNZq()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFoQQd(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCSDOM.VVliVo(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCwMZZ.VVmeiK(self.passedSession, txt, 30)
   else    : CCwMZZ.VVpgb7(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVuowk()
 def VVuowk(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVgWnb(self):
  self.startTime = iTime()
 def VVCeUi(self):
  global VVM9go
  VVM9go = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFzKhS(decodedUrl):
     self.isFromEOF = True
     CCwMZZ(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVjQH4(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVuURc)
  except:
   self.timer1.callback.append(self.VVuURc)
  self.timer1.start(100, True)
 def VVuURc(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVj8He(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCqLbA.VVoQCR:
       self.isFromEOF = False
       self.VVemSS(self.passedSession, isFromSession=True)
       InfoBar.instance.hide()
class CC2c5I():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVWaJ8(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVWaJ8(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVWaJ8(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVobIL, VVVcWE):
    path += fName
    if fileExists(path):
     for line in FF9z80(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVzsRi(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC8Yh1.VVVywz(name):
   return CC8Yh1.VVSHlK(name)
  return self.VVS8Lq(name)
 def VVS8Lq(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VV2ucW(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVS8Lq(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVzh5B(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VV7pMv(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVl3zf(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCskCr(CCIbAM):
 def __init__(self):
  self.curPortalCatId = ""
  CCIbAM.__init__(self)
 def VVDk85(self):
  if CCskCr.VVztta(self):
   FFuMBP(self, BF(self.VV4NLl, 2), title="Searching ...")
 def VVFIiS(self, winSession, url, mac):
  self.curUrl = url
  if CCskCr.VVztta(self):
   if self.VVUnRS(url, mac):
    FFuMBP(winSession, self.VVns8x, title="Checking Server ...")
   else:
    FFB8Nz(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV29vI(self, item=None):
  if item:
   VVCarR, txt, path, ndx = item
   enc = CCbony.VVMjuP(path, self)
   if enc == -1:
    return
   self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVhmOP, path, enc)
       , VVLUmk = BF(self.VVTPYW, VVCarR, path))
 def VVhmOP(self, path, enc, VVVRSv):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVVRSv.VVWtjR(totLines)
  VVVRSv.VVPpbS = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVVRSv or VVVRSv.isCancelled:
     return
    VVVRSv.VVBQzv(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip().strip('"') or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(';"') or "-"
     host = self.VVqjET(url).strip('"')
     mac  = self.VVXAwQ(mac)
     if host and mac and VVVRSv:
      VVVRSv.VVPpbS.append((str(c), str(lineNum), subj, host, mac, info))
     url = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip().strip('"') or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(';"') or "-"
      host = self.VVqjET(url).strip('"')
      mac  = self.VVXAwQ(mac)
      if host and mac and not mac.startswith("AC") and VVVRSv:
       VVVRSv.VVPpbS.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVTPYW(self, VVCarR, path, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVPpbS:
   VVlpv3  = ("Home Menu"  , FFKdOO            , [])
   VVkGmL = ("Edit File"  , BF(self.VVzIrV, path)       , [])
   VVlrMb = ("M3U Options" , self.VVy4jV         , [])
   VV1FeB = ("Check & Filter" , BF(self.VVQiec, VVCarR, path), [])
   VVlUqf  = ("Select"   , self.VVQTnd      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVrLHE  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVPpbS, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVl9AY="#0a001122", VVLICL="#0a001122", VVHZxf="#0a001122", VVSzMt="#00004455", VVvy9F="#0a333333", VVRt6l="#11331100", VVJcAk=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVVUTO:
    FFM3N1(VVhqv2, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVVUTO:
    FFB8Nz(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVy4jV(self, VVhqv2, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVhIDJ = []
  VVhIDJ.append(("Browse as M3U"  , "browse"))
  VVhIDJ.append(("Download M3U File" , "downld"))
  FFRHhp(self, BF(self.VVGvGk, VVhqv2, host, mac), title=title, VVhIDJ=VVhIDJ, width=600, VVWLSA=True)
 def VVGvGk(self, VVhqv2, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFuMBP(VVhqv2, BF(self.VVBZ8F, VVhqv2, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FF5jVY(self, BF(FFuMBP, VVhqv2, BF(self.VVBZ8F, VVhqv2, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVBZ8F(self, VVhqv2, title, host, mac, item):
  p = CCIbAM()
  m3u_Url = ""
  ok = p.VVUnRS(host, mac, VVzp4h=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVxEdw(VVzp4h=False)
  if m3u_Url:
   if   item == "browse": self.VVTSzs(title, m3u_Url)
   elif item == "downld": self.VVhUA7(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFB8Nz(self, err or "No response from Server !", title=title)
 def VVQTnd(self, VVhqv2, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVFIiS(VVhqv2, url, mac)
 def VVzIrV(self, path, VVhqv2, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCwZEN(self, path, VVLUmk=BF(self.VVnBP2, VVhqv2), curRowNum=rowNum)
  else    : FFM8jr(self, path)
 def VVQiec(self, VVCarR, path, VVhqv2, title, txt, colList):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVo8Ar, VVhqv2)
      , VVLUmk = BF(self.VVo3uI, VVCarR, VVhqv2, path))
 def VVo8Ar(self, VVhqv2, VVVRSv):
  VVVRSv.VVPpbS = []
  VVVRSv.VVWtjR(VVhqv2.VVfbKq())
  for row in VVhqv2.VVOazu():
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVUnRS(host, mac, VVzp4h=False):
    token, profile, tErr = self.VV0ZY9(VVzp4h=False)
    if token and VVVRSv and not VVVRSv.isCancelled:
     res, err = self.VV4XWK(self.VVDTjW("itv"))
     if res and VVVRSv and not VVVRSv.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVVRSv.VVBQzv(0, showFound=True)
       VVVRSv.VVPpbS.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVVRSv:
    return
 def VVo3uI(self, VVCarR, VVhqv2, path, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVPpbS:
   VVhqv2.close()
   VVCarR.close()
   newPath = "%s_OK_%s.txt" % (path, FFERmH())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVPpbS:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFwXwL(str(threadCounter), VVdSiQ)
    skipped = FFwXwL(str(threadTotal - threadCounter), VVdSiQ)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVPpbS)
   txt += "%s\n\n%s"    %  (FFwXwL("Result File:", VVdVoc), newPath)
   FF3nHt(self, txt, title="Accessible Portals")
  elif VVVUTO:
   FFB8Nz(self, "No portal access found !", title="Accessible Portals")
 def VVvxge(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFbClU(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVns8x(self):
  token, profile, tErr = self.VV0ZY9()
  if token:
   dots = "." * self.VVW4im
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVJY6F(), "")
   dots += "*" if not self.VV47AR == self.curUrl else ""
   VVhIDJ  = self.VVrMo0()
   VVvXZx = self.VVyhcC
   VVW4TT = self.VVriak
   VVMVWG = ("Home Menu", FFKdOO)
   VVVW3K= ("Add to Menu", BF(CC8Yh1.VVxprn, self, True, self.VV47AR + "\t" + self.VVS3cB))
   VVzwta = ("Bookmark Server", BF(CC8Yh1.VVHyfZ, self, True, self.VV47AR + "\t" + self.VVS3cB))
   VVCarR = FFRHhp(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVS3cB, dots), VVhIDJ=VVhIDJ, VVvXZx=VVvXZx, VVW4TT=VVW4TT, VVMVWG=VVMVWG, VVVW3K=VVVW3K, VVzwta=VVzwta)
   self.VVMiTV(VVCarR)
 def VVyhcC(self, item=None):
  if item:
   VVCarR, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFuMBP(VVCarR, BF(self.VVxQPo, mode), title="Reading Categories ...")
   else : FFuMBP(VVCarR, BF(self.VVJiUp, VVCarR, title), title="Reading Account ...")
 def VVJiUp(self, VVCarR, title, forceMoreInfo=False):
  rows, totCols = self.VVYQy4(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVS3cB)
  VVlpv3  = ("Home Menu" , FFKdOO           , [])
  VVlrMb  = None
  if VVT9SH:
   VVlrMb = ("Get JS"  , BF(self.VVkYy5, self.VVD3Aa()) , [])
  if totCols == 2:
   VV1FeB = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VV1FeB = ("More Info.", BF(self.VVV2N3, VVCarR)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFNCSP(self, None, title=title, width=1200, header=header, VVFWkP=rows, VVN1SU=widths, VVNWWl=26, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VV1FeB=VV1FeB, VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000", searchCol=searchCol)
 def VVkYy5(self, url, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVImhx, url), title="Getting JS ...")
 def VVImhx(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVS3cB)
  ver, err = self.VV8gLt(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VV8gLt(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FF3nHt(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVV2N3(self, VVCarR, VVhqv2, title, txt, colList):
  VVhqv2.cancel()
  FFuMBP(VVCarR, BF(self.VVJiUp, VVCarR, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVxQPo(self, mode):
  token, profile, tErr = self.VV0ZY9()
  if not token:
   return
  res, err = self.VV4XWK(self.VVDTjW(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CC8Yh1.VVfIBq(item, "id"       )
      Title  = CC8Yh1.VVfIBq(item, "title"      )
      censored = CC8Yh1.VVfIBq(item, "censored"     )
      Title = self.VVzh5B(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVvct2:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVVc72(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT(mode)
   mName = self.VVVc72(mode)
   VVNBO3  = (""     , BF(self.VV6qoY, mode), [])
   VVlUqf   = ("Show List"   , BF(self.VVROHX, mode)   , [])
   VVlpv3  = ("Home Menu"   , FFKdOO        , [])
   if mode in ("vod", "series"):
    VVkGmL = ("Find in %s" % mName , BF(self.VVLGPz, mode, False), [])
    VV1FeB = ("Find in Selected" , BF(self.VVLGPz, mode, True) , [])
   else:
    VVkGmL = None
    VV1FeB = None
   header   = None
   widths   = (100   , 0  )
   FFNCSP(self, None, title=title, width=1200, header=header, VVFWkP=list, VVN1SU=widths, VVNWWl=30, VVlpv3=VVlpv3, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVNBO3=VVNBO3, VVlUqf=VVlUqf, VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVFk7g:
     txt += "\n\n( %s )" % self.VVFk7g
   else:
    txt = "Could not get Categories from server!"
   FFB8Nz(self, txt, title=title)
 def VVCIEd(self, mode, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVYuBh, mode, VVhqv2, title, txt, colList), title="Downloading ...")
 def VVYuBh(self, mode, VVhqv2, title, txt, colList):
  token, profile, tErr = self.VV0ZY9()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV4XWK(self.VVHkme(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CC8Yh1.VVfIBq(item, "id"    )
      actors   = CC8Yh1.VVfIBq(item, "actors"   )
      added   = CC8Yh1.VVfIBq(item, "added"   )
      age    = CC8Yh1.VVfIBq(item, "age"   )
      category_id  = CC8Yh1.VVfIBq(item, "category_id" )
      description  = CC8Yh1.VVfIBq(item, "description" )
      director  = CC8Yh1.VVfIBq(item, "director"  )
      genres_str  = CC8Yh1.VVfIBq(item, "genres_str"  )
      name   = CC8Yh1.VVfIBq(item, "name"   )
      path   = CC8Yh1.VVfIBq(item, "path"   )
      screenshot_uri = CC8Yh1.VVfIBq(item, "screenshot_uri" )
      series   = CC8Yh1.VVfIBq(item, "series"   )
      cmd    = CC8Yh1.VVfIBq(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVNBO3 = (""     , BF(self.VVcjMc, mode, True)  , [])
   VVlUqf  = ("Play"    , BF(self.VV1EmI, mode)       , [])
   VVJEWY = (""     , BF(self.VVxIkQ, mode)     , [])
   VVlpv3 = ("Home Menu"   , FFKdOO            , [])
   VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, "sp", seriesName) , [])
   VVkGmL = ("Options"   , BF(self.VVugTw, "pEp", mode, seriesName) , [])
   VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVrLHE  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFNCSP(self, None, title=seriesName, width=1200, header=header, VVFWkP=list, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVNBO3=VVNBO3, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindIptv, VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000")
  else:
   FFB8Nz(self, "Could not get Episodes from server!", title=seriesName)
 def VVLGPz(self, mode, searchInCat, VVhqv2, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVhIDJ = []
  VVhIDJ.append(("Keyboard"  , "manualEntry"))
  VVhIDJ.append(("From Filter" , "fromFilter"))
  FFRHhp(self, BF(self.VV9gm7, VVhqv2, mode, searchCatId), title="Input Type", VVhIDJ=VVhIDJ, width=400)
 def VV9gm7(self, VVhqv2, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFs37j(self, BF(self.VV7mDV, VVhqv2, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCf604(self)
    filterObj.VV98nA(BF(self.VV7mDV, VVhqv2, mode, searchCatId))
 def VV7mDV(self, VVhqv2, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFsMp0(CFG.lastFindIptv, searchName)
   title = self.VVtf6s(mode, searchName)
   if "," in searchName : FFB8Nz(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFB8Nz(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VV7pMv([searchName]):
     FFB8Nz(self, self.VVl3zf(), title=title)
    else:
     self.VVLPcL(mode, searchName, "", searchName, searchCatId)
 def VVROHX(self, mode, VVhqv2, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVLPcL(mode, bName, catID, "", "")
 def VVLPcL(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VV3d6F, mode, bName, catID, searchName, searchCatId)
      , VVLUmk = BF(self.VVZRRl, mode, bName, catID, searchName, searchCatId))
 def VVZRRl(self, mode, bName, catID, searchName, searchCatId, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVtf6s(mode, searchName)
  else   : title = "%s : %s" % (self.VVVc72(mode), bName)
  if VVPpbS:
   VVlrMb = None
   VVkGmL = None
   if mode == "series":
    VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT("series2")
    VVlUqf  = ("Episodes"   , BF(self.VVCIEd, mode)           , [])
   else:
    VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT("")
    VVlUqf  = ("Play"    , BF(self.VV1EmI, mode)           , [])
    VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, "vp" if mode == "vod" else "", "") , [])
    VVkGmL = ("Options"   , BF(self.VVugTw, "pCh", mode, bName)      , [])
   VVNBO3 = (""      , BF(self.VVcjMc, mode, False)      , [])
   VVJEWY = (""      , BF(self.VVgldt, mode)         , [])
   VVlpv3 = ("Home Menu"    , FFKdOO                , [])
   VV1FeB = ("Posters Mode"   , BF(self.VVbEDp, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVrLHE  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVPpbS, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindIptv, VVlUqf=VVlUqf, VVNBO3=VVNBO3, VVJEWY=VVJEWY, VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt, VVJcAk=True, searchCol=1)
   if not VVVUTO:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVhqv2.VVUQf7(VVhqv2.VV34q2() + tot)
    if threadErr: FFM3N1(VVhqv2, "Error while reading !", 2000)
    else  : FFM3N1(VVhqv2, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFB8Nz(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFB8Nz(self, "Could not get list from server !", title=title)
 def VVgldt(self, mode, VVhqv2, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFwXwL(x, VVdVoc), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFcAqb(self, fncMode=CCscAN.VVY5OL, portalHost=self.VV47AR, portalMac=self.VVS3cB, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVnraN(mode, VVhqv2, title, txt, colList)
 def VVxIkQ(self, mode, VVhqv2, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFwXwL(colList[10], VVlrJC)
  txt += "Description:\n%s" % FFwXwL(colList[11], VVlrJC)
  self.VVnraN(mode, VVhqv2, title, txt, colList)
 def VVnraN(self, mode, VVhqv2, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, colList)
  refCode, chUrl = self.VVefbI(self.VV47AR, self.VVS3cB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFcAqb(self, fncMode=CCscAN.VVmhwo, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VV3d6F(self, mode, bName, catID, searchName, searchCatId, VVVRSv):
  try:
   token, profile, tErr = self.VV0ZY9()
   if not token:
    return
   if VVVRSv.isCancelled:
    return
   VVVRSv.VVPpbS, total_items, max_page_items, err = self.VVtHr1(mode, catID, 1, 1, searchName, searchCatId)
   if VVVRSv.isCancelled:
    return
   if VVVRSv.VVPpbS and total_items > -1 and max_page_items > -1:
    VVVRSv.VVWtjR(total_items)
    VVVRSv.VVBQzv(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVVRSv.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVtHr1(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVVRSv.VVmMZj()
     if VVVRSv.isCancelled:
      return
     if list:
      VVVRSv.VVPpbS += list
      VVVRSv.VVBQzv(len(list), True)
  except:
   pass
 def VVtHr1(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVXlnz(mode, searchName, searchCatId, page)
  else   : url = self.VVrV3C(mode, catID, page)
  res, err = self.VV4XWK(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV4IIR(CC8Yh1.VVfIBq(item, "total_items" ))
     max_page_items = self.VV4IIR(CC8Yh1.VVfIBq(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC8Yh1.VVfIBq(item, "id"    )
      name   = CC8Yh1.VVfIBq(item, "name"   )
      o_name   = CC8Yh1.VVfIBq(item, "o_name"   )
      category_id  = CC8Yh1.VVfIBq(item, "category_id" )
      tv_genre_id  = CC8Yh1.VVfIBq(item, "tv_genre_id" )
      number   = CC8Yh1.VVfIBq(item, "number"   ) or str(counter)
      logo   = CC8Yh1.VVfIBq(item, "logo"   )
      screenshot_uri = CC8Yh1.VVfIBq(item, "screenshot_uri" )
      pic    = CC8Yh1.VVfIBq(item, "pic"   )
      cmd    = CC8Yh1.VVfIBq(item, "cmd"   )
      censored  = CC8Yh1.VVfIBq(item, "censored"  )
      genres_str  = CC8Yh1.VVfIBq(item, "genres_str"  )
      curPlay   = CC8Yh1.VVfIBq(item, "cur_playing" )
      actors   = CC8Yh1.VVfIBq(item, "actors"   )
      descr   = CC8Yh1.VVfIBq(item, "description" )
      director  = CC8Yh1.VVfIBq(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFNbl8(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VV47AR + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVzsRi(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV4IIR(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV1EmI(self, mode, VVhqv2, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, colList)
  refCode, chUrl = self.VVefbI(self.VV47AR, self.VVS3cB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVVywz(chName):
   FFM3N1(VVhqv2, "This is a marker!", 300)
  else:
   FFuMBP(VVhqv2, BF(self.VV3zOy, mode, VVhqv2, chUrl), title="Playing ...")
 def VV3zOy(self, mode, VVhqv2, chUrl):
  FFtU9E(self, chUrl, VVpkYJ=False)
  CCqLbA.VVZoRN(self.session, iptvTableParams=(self, VVhqv2, mode))
 def VVcZNb(self, mode, VVhqv2, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, colList)
  refCode, chUrl = self.VVefbI(self.VV47AR, self.VVS3cB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV4qge(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVztta(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVhIDJ = []
    VVhIDJ.append((title        , "inst" ))
    VVhIDJ.append(("Update Packages then %s" % title , "updInst" ))
    FFRHhp(SELF, BF(CCskCr.VVowG3, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVhIDJ=VVhIDJ)
   return False
 @staticmethod
 def VVowG3(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FF2wdN(VVdMlb, "")
   if cmdUpd:
    cmdInst = FFyOYr(VVTdap, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFFPZ4(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVE46B=cbFnc)
   else:
    FF4L5V(SELF)
 def VVMhuD(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVoANg(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVMiTV(self, VVCarR):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVMhuD()
  if all((curMode, curHost, curCat)) and curHost == self.VV47AR:
   VVCarR.VVflXp({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VV6qoY(self, mode, VVhqv2, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVMhuD()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VV47AR:
   VVhqv2.VVTlR4({1:curCat})
 def VVcjMc(self, mode, isEp, VVhqv2, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVMhuD()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VV47AR:
   if mode in ("itv", "vod"):
    VVhqv2.VVTlR4({2:curStID})
   else: #series
    if isEp:
     VVhqv2.VVTlR4({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVhqv2.VVTlR4({2:ser2})
     if not ok: VVhqv2.VVTlR4({2:ser1})
class CC8Yh1(Screen, CCskCr, CC2c5I, CCBYxw):
 VVabNX    = 0
 VVGBW8    = 1
 VVdbr4    = 2
 VVbNHK    = 3
 VVTgoS     = 4
 VVjWxE     = 5
 VVHDp7     = 6
 VVS1Cm     = 7
 VVgbj6     = 8
 VVw010     = 9
 VVyG5Z      = 10
 VV9Bn1     = 11
 VVRmSs     = 12
 VVNKkS     = 13
 VVdRmz     = 14
 VVnh2b      = 15
 VVDwcM      = 16
 VVTrm2      = 17
 VVEC2W      = 18
 VV3aUJ      = 19
 VVfC8A    = 0
 VVL8JW   = 1
 VVTHW6   = 2
 VVLLfH   = 3
 VVmosx  = 4
 VVMQJd  = 5
 VV6G9Q   = 6
 VVR002   = 7
 VV9two  = 8
 VV0jRF  = 9
 VVkJci  = 10
 VV15Si = 0
 VVpM9d = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFMkht(VV35C4, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVhqv2    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV9j4YData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CC8Yh1.VVYsfN(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCskCr.__init__(self)
  CC2c5I.__init__(self)
  VVhIDJ = self.VVg4Gd()
  FFTlW1(self, title="IPTV", VVhIDJ=VVhIDJ)
  self["myActionMap"].actions.update({
   "menu" : self.VVw3CG
  })
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVLjY0)
  global VVsQQd
  VVsQQd = True
 def VVtpg1(self):
  self["myMenu"].setList(self.VVg4Gd())
  FFH94q(self)
  FFfgOw(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFjM4Z(self["myMenu"])
   FFuz2Q(self)
   if self.m3uOrM3u8File:
    self.VVP32O(self.m3uOrM3u8File)
   else:
    self.VVuBaN()
 def VVuBaN(self):
  qUrl, decodedUrl, iptvRef = CC8Yh1.VVOiYT(self)
  if qUrl or "chCode" in iptvRef:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFnsKm("VVsQQd")
 def VVLjY0(self):
  if self["myMenu"].getCurrent()[1] in ("VVeQeI", "VVCoXBPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVw3CG(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVCoXBPortal" : confItem = CFG.favServerPortal
   elif item == "VVeQeI" : confItem = CFG.favServerPlaylist
   else         : return
   FF5jVY(self, BF(self.VVRDvP, confItem), 'Remove from menu ?', title=title)
 def VVRDvP(self, confItem):
  FFsMp0(confItem, "")
  self.VVtpg1()
 def VVg4Gd(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVHH6F
  VVhIDJ = []
  if isFav1: VVhIDJ.append((c +  "Favourite Playlist Server"   , "VVeQeI" ))
  if isFav2: VVhIDJ.append((c +  "Favourite Portal Server"    , "VVCoXBPortal" ))
  VVhIDJ.append(("IPTV Server Browser (from Playlists)"     , "VV9j4Y_fromPlayList" ))
  VVhIDJ.append(("IPTV Server Browser (from Portal List)"    , "VV9j4Y_fromMac"  ))
  VVhIDJ.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV9j4Y_fromM3u"  ))
  qUrl, decodedUrl, iptvRef = CC8Yh1.VVOiYT(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVhIDJ.append(FFyXfa("IPTV Server Browser (from Current Channel)", "VV9j4Y_fromCurrChan", fromCurCond))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("M3U/M3U8 File Browser"        , "VVMz4F"   ))
  if self.iptvFileAvailable:
   VVhIDJ.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVhIDJ.append(FFyXfa("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVhIDJ.append(VVuAtK)
   c1, c2 = VVmvsU, VVdVoc
   t1 = FFwXwL("auto-match names", VVHH6F)
   t2 = FFwXwL("from xml file"  , VVHH6F)
   VVhIDJ.append((c1 + "Count Available IPTV Channels"    , "VVCjhU"    ))
   VVhIDJ.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVhIDJ.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVCeyH" ))
   VVhIDJ.append((VVeCLm + "More Reference Tools ..."  , "VV6ber"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Reload Channels and Bouquets"       , "VVJAZC"   ))
  VVhIDJ.append(VVuAtK)
  if not CCSDOM.VVDxIp():
   VVhIDJ.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVhIDJ.append(("Download Manager ... No downloads"    ,       ))
  return VVhIDJ
 def VVE2L9(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVSyk5"   : self.VVSyk5()
   elif item == "VVadZE" : FF5jVY(self, self.VVadZE, "Change Current List References to Unique Codes ?")
   elif item == "VVJGGk_rows" : FF5jVY(self, BF(FFuMBP, self.VVhqv2, self.VVJGGk), "Change Current List References to Identical Codes ?")
   elif item == "VViA2U"   : self.VViA2U(tTitle)
   elif item == "VVlUMe"   : self.VVlUMe(tTitle)
   elif item == "VVeQeI" : self.VVCoXB(False)
   elif item == "VVCoXBPortal" : self.VVCoXB(True)
   elif item == "VV9j4Y_fromPlayList" : FFuMBP(self, BF(self.VV4NLl, 1), title=title)
   elif item == "VV9j4Y_fromM3u"  : FFuMBP(self, BF(self.VV9cJI, CC8Yh1.VV15Si), title=title)
   elif item == "VV9j4Y_fromMac"  : self.VVDk85()
   elif item == "VV9j4Y_fromCurrChan" : self.VVq6cW()
   elif item == "VVMz4F"   : self.VVMz4F()
   elif item == "iptvTable_all"   : FFuMBP(self, BF(self.VV7YE6, self.VVabNX), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CC8Yh1.VVxSdd(self)
   elif item == "refreshIptvPicons"  : self.VVWiRH()
   elif item == "VVCjhU"    : FFuMBP(self, self.VVCjhU)
   elif item == "copyEpgPicons"   : self.VV0rYM(False)
   elif item == "renumIptvRef_fromFile" : self.VV0rYM(True)
   elif item == "VVCeyH" : FF5jVY(self, BF(FFuMBP, self, self.VVCeyH), VVZNNf="Continue ?")
   elif item == "VV6ber"    : self.VV6ber()
   elif item == "VVJAZC"   : FFuMBP(self, BF(CCn3v3.VVJAZC, self))
   elif item == "dload_stat"    : CCSDOM.VV2g5x(self)
 def VVMz4F(self):
  if CCskCr.VVztta(self):
   FFuMBP(self, BF(self.VV9cJI, CC8Yh1.VVpM9d), title="Searching ...")
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVE2L9(item)
 def VV7YE6(self, mode):
  VVkNlM = self.VVkzM7(mode)
  if VVkNlM:
   VVlrMb = ("Current Service", self.VVTfay , [])
   VVkGmL = ("Options"  , self.VV4QJs   , [])
   VV1FeB = ("Filter"   , self.VVQETV   , [])
   VVlUqf  = ("Play"   , BF(self.VVbgKL)  , [])
   VVJEWY = (""    , self.VVgpWd    , [])
   VVNBO3 = (""    , self.VVL4Oa     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVrLHE  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFNCSP(self, None, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26
     , VVlUqf=VVlUqf, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVJEWY=VVJEWY, VVNBO3=VVNBO3
     , VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000", VVJcAk=True, searchCol=1)
  else:
   if mode == self.VVw010: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFB8Nz(self, err)
 def VVL4Oa(self, VVhqv2, title, txt, colList):
  self.VVhqv2 = VVhqv2
 def VV4QJs(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(("Add Current List to a New Bouquet"    , "VVSyk5"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Current List References to Unique Codes" , "VVadZE"))
  VVhIDJ.append(("Change Current List References to Identical Codes", "VVJGGk_rows" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Share Reference with DVB Service (manual entry)" , "VViA2U"   ))
  VVhIDJ.append(("Share Reference with DVB Service (auto-find)"  , "VVlUMe"   ))
  FFRHhp(self, self.VVE2L9, title="IPTV Tools", VVhIDJ=VVhIDJ)
 def VVQETV(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVqJ5M, VVhqv2))
 def VVqJ5M(self, VVhqv2):
  VVhIDJ = []
  VVhIDJ.append(("All"         , "all"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Prefix of Selected Channel"   , "sameName" ))
  VVhIDJ.append(("Suggest Words from Selected Channel" , "partName" ))
  VVhIDJ.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVhIDJ.append(("Duplicate References"     , "depRef"  ))
  VVhIDJ.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVhIDJ.append(("Stream Relay"       , "SRelay"  ))
  VVhIDJ.append(FFw8eL("Category"))
  VVhIDJ.append(("Live TV"        , "live"  ))
  VVhIDJ.append(("VOD"         , "vod"   ))
  VVhIDJ.append(("Series"        , "series"  ))
  VVhIDJ.append(("Uncategorised"      , "uncat"  ))
  VVhIDJ.append(FFw8eL("Media"))
  VVhIDJ.append(("Video"        , "video"  ))
  VVhIDJ.append(("Audio"        , "audio"  ))
  VVhIDJ.append(FFw8eL("File Type"))
  VVhIDJ.append(("MKV"         , "MKV"   ))
  VVhIDJ.append(("MP4"         , "MP4"   ))
  VVhIDJ.append(("MP3"         , "MP3"   ))
  VVhIDJ.append(("AVI"         , "AVI"   ))
  VVhIDJ.append(("FLV"         , "FLV"   ))
  VVhIDJ.extend(CCJEC1.VVbosM(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VV3epJ, VVhqv2) if VVhqv2.VV34q2().startswith("IPTV Filter ") else None
  filterObj = CCf604(self)
  filterObj.VVVOhK(VVhIDJ, VVhIDJ, BF(self.VVSI75, VVhqv2, False), inFilterFnc=inFilterFnc)
 def VV3epJ(self, VVhqv2, VVCarR, item):
  self.VVSI75(VVhqv2, True, item)
 def VVSI75(self, VVhqv2, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVhqv2.VV26F4(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVabNX , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVGBW8 , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVdbr4 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVbNHK , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVHDp7  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVS1Cm  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVgbj6  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVw010  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVyG5Z   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV9Bn1  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVRmSs  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVNKkS  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVdRmz  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVnh2b   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVDwcM   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVTrm2   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVEC2W   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV3aUJ   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVTgoS  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVjWxE  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVdbr4:
   VVhIDJ = []
   chName = VVhqv2.VV26F4(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVhIDJ.append((item, item))
    if not VVhIDJ and chName:
     VVhIDJ.append((chName, chName))
    FFRHhp(self, BF(self.VVOSaF, title), title="Words from Current Selection", VVhIDJ=VVhIDJ)
   else:
    VVhqv2.VVomXH("Invalid Channel Name")
  else:
   words, asPrefix = CCf604.VV7zA4(words)
   if not words and mode in (self.VVTgoS, self.VVjWxE):
    FFM3N1(self.VVhqv2, "Incorrect filter", 2000)
   else:
    FFuMBP(self.VVhqv2, BF(self.VV8qc5, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVOSaF(self, title, word=None):
  if word:
   words = [word.lower()]
   FFuMBP(self.VVhqv2, BF(self.VV8qc5, self.VVdbr4, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVSHlK(txt):
  return "#f#11ffff00#" + txt
 def VV8qc5(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVkNlM = self.VVXEmL(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVkNlM = self.VVkzM7(mode=mode, words=words, asPrefix=asPrefix)
  if VVkNlM : self.VVhqv2.VVartp(VVkNlM, title)
  else  : self.VVhqv2.VVomXH("Not found")
 def VVXEmL(self, mode=0, words=None, asPrefix=False):
  VVkNlM = []
  for row in self.VVhqv2.VVOazu():
   row = list(map(str.strip, row))
   chNum, chName, VVCJZW, chType, refCode, url = row
   if self.VVXlCC(mode, refCode, FFtaHD(url).lower(), chName, words, VVCJZW.lower(), asPrefix):
    VVkNlM.append(row)
  VVkNlM = self.VVQ9gw(mode, VVkNlM)
  return VVkNlM
 def VVkzM7(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVkNlM = []
  files = CC8Yh1.VVYsfN()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFQDOO(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVCJZW = span.group(1)
    else : VVCJZW = ""
    VVCJZW_lCase = VVCJZW.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVVywz(chName): chNameMod = self.VVSHlK(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVCJZW, chType + (" SRel" if FFzL2x(url) else ""), refCode, url)
     if self.VVXlCC(mode, refCode, FFtaHD(url).lower(), chName, words, VVCJZW_lCase, asPrefix):
      VVkNlM.append(row)
      chNum += 1
  VVkNlM = self.VVQ9gw(mode, VVkNlM)
  return VVkNlM
 def VVQ9gw(self, mode, VVkNlM):
  newRows = []
  if VVkNlM and mode == self.VVHDp7:
   counted  = iCounter(elem[4] for elem in VVkNlM)
   for item in VVkNlM:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVkNlM
 def VVXlCC(self, mode, refCode, tUrl, chName, words, VVCJZW_lCase, asPrefix):
  if   mode == self.VVabNX : return True
  elif mode == self.VVHDp7 : return True
  elif mode == self.VVS1Cm  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVgbj6 : return FFzL2x(tUrl)
  elif mode == self.VVNKkS  : return CC8Yh1.VVYuLl(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVdRmz  : return CC8Yh1.VVYuLl(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVw010  : return CC8Yh1.VVYuLl(tUrl, compareType="live")
  elif mode == self.VVyG5Z  : return CC8Yh1.VVYuLl(tUrl, compareType="movie")
  elif mode == self.VV9Bn1 : return CC8Yh1.VVYuLl(tUrl, compareType="series")
  elif mode == self.VVRmSs  : return CC8Yh1.VVYuLl(tUrl, compareType="")
  elif mode == self.VVnh2b  : return CC8Yh1.VVYuLl(tUrl, compareExt="mkv")
  elif mode == self.VVDwcM  : return CC8Yh1.VVYuLl(tUrl, compareExt="mp4")
  elif mode == self.VVTrm2  : return CC8Yh1.VVYuLl(tUrl, compareExt="mp3")
  elif mode == self.VVEC2W  : return CC8Yh1.VVYuLl(tUrl, compareExt="avi")
  elif mode == self.VV3aUJ  : return CC8Yh1.VVYuLl(tUrl, compareExt="flv")
  elif mode == self.VVGBW8: return chName.lower().startswith(words[0])
  elif mode == self.VVdbr4: return words[0] in chName.lower()
  elif mode == self.VVbNHK: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVTgoS : return words[0] == VVCJZW_lCase
  elif mode == self.VVjWxE :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVSyk5(self):
  picker = CCJEC1(self, self.VVhqv2, "Add to Bouquet", self.VVKMch)
 def VVKMch(self):
  chUrlLst = []
  for row in self.VVhqv2.VVOazu():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VV6ber(self):
  t1 = FFwXwL("Bouquet" , VVdVoc)
  t2 = FFwXwL("ALL"  , VVeCLm)
  t3 = FFwXwL("Unique"  , VVmvsU)
  t4 = FFwXwL("Identical" , VVHH6F)
  VVhIDJ = []
  VVhIDJ.append((VVuj5g + "Check System Acceptable Reference Types", "VVwE8l"))
  VVhIDJ.append(FFyXfa("Check Reference Codes Format", "VVX6tv", self.iptvFileAvailable, VVuj5g))
  VVhIDJ.append(VVuAtK)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVhIDJ.append((txt % t1, "VVYUy4" ))
  VVhIDJ.append((txt % t2, "VV4qd9_all"  ))
  VVhIDJ.append(VVuAtK)
  txt = "Change %s References to %s Codes .."
  VVhIDJ.append((txt % (t1, t3), "VV9u7c" ))
  VVhIDJ.append((txt % (t2, t3), "VVFrcT"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change %s References to %s Codes" % (t2, t4) , "VVJGGk_all"))
  VVvXZx = self.VVBxO4
  FFRHhp(self, None, width=1150, title="IPTV Reference Tools", VVhIDJ=VVhIDJ, VVvXZx=VVvXZx, VVl9AY="#22002233", VVLICL="#22001122")
 def VVBxO4(self, item=None):
  if item:
   ques = "Continue ?"
   VVCarR, txt, item, ndx = item
   if   item == "VVwE8l"    : FFuMBP(VVCarR, self.VVwE8l)
   elif item == "VVX6tv"     : FFuMBP(VVCarR, self.VVX6tv)
   elif item == "VVYUy4" : self.VV9sna(VVCarR, self.VVJQ0z)
   elif item == "VV4qd9_all"  : self.VVJQ0z(VVCarR, None, None)
   elif item == "VV9u7c" : self.VV9u7c(VVCarR, txt)
   elif item == "VVFrcT"  : FF5jVY(self, BF(self.VVFrcT , VVCarR, txt), title=txt, VVZNNf=ques)
   elif item == "VVJGGk_all"  : FF5jVY(self, BF(FFuMBP, VVCarR, self.VVJGGk), title=txt, VVZNNf=ques)
 def VVJQ0z(self, VVCarR, bName, bPath):
  VVhIDJ = []
  for rt in CC8Yh1.VVj2DV():
   VVhIDJ.append(("%s\t ... %s" % (rt, CC8Yh1.VVOHeM(rt)), rt))
  FFRHhp(self, BF(self.VVCOwQ, VVCarR, bName, bPath), VVhIDJ=VVhIDJ, width=800, title="Change Reference Types to:")
 def VVCOwQ(self, VVCarR, bName, bPath, rType=None):
  if rType:
   self.VV05BO(VVCarR, bName, bPath, rType)
 def VV9sna(self, VVCarR, fnc):
  VVhIDJ = CCJEC1.VVbosM()
  if VVhIDJ:
   FFRHhp(self, BF(self.VVlimP, VVCarR, fnc), VVhIDJ=VVhIDJ, title="IPTV Bouquets", VVWLSA=True)
  else:
   FFM3N1(VVCarR, "No bouquets Found !", 1500)
 def VVlimP(self, VVCarR, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVSs5p + span.group(1)
    if fileExists(bPath): fnc(VVCarR, bName, bPath)
    else    : FFM3N1(VVCarR, "Bouquet file not found!", 2000)
   else:
    FFM3N1(VVCarR, "Cannot process bouquet !", 2000)
 def VV05BO(self, VVCarR, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFwXwL(bName, VVqZDD)
  else : title = "Change for %s" % FFwXwL("All IPTV Services", VVqZDD)
  FF5jVY(self, BF(FFuMBP, VVCarR, BF(self.VV2l9b, VVCarR, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFwXwL(rType, VVqZDD), title=title)
 def VV2l9b(self, VVCarR, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CC8Yh1.VVYsfN()
  if files:
   newRType = rType + ":"
   piconPath = CCTdjW.VVJwSu()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCf82q.VVg9pn(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFB8Nz(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFcZm9("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFcZm9(cmd)
  self.VVko4N(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVCjhU(self):
  totFiles = 0
  files  = CC8Yh1.VVYsfN()
  if files:
   totFiles = len(files)
  totChans = 0
  VVkNlM = self.VVkzM7()
  if VVkNlM:
   totChans = len(VVkNlM)
  FF3nHt(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVX6tv(self):
  files = CC8Yh1.VVYsfN()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFQDOO(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVfPTB
   else    : color = VVdSiQ
   totInvalid = FFwXwL(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFwXwL("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF3nHt(self, txt, title="Check IPTV References")
 def VVwE8l(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CC8Yh1.VVj2DV()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCJEC1.VVH0cU(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVQd8W = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVQd8W:
   VVibol = FFxxyk(VVQd8W)
   if VVibol:
    for service in VVibol:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVSs5p + userBName
  bFile = VVSs5p + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFUGBP("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFUGBP("rm -f '%s'" % path)
  FFcZm9(cmd)
  FFBOOj()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVfPTB
    else     : res, color = "No" , VVdSiQ
    pl = CC8Yh1.VVOHeM(item)
    txt += "    %s\t: %s%s\n" % (item, FFwXwL(res, color), FFwXwL("\t... %s" % pl, VVlrJC) if pl else "")
   FF3nHt(self, txt, title=title)
  else:
   txt = FFB8Nz(self, "Could not complete the test on your system!", title=title)
 def VVCeyH(self):
  VVjMIb, err = CCn3v3.VVwReR(self, CCn3v3.VVntsY)
  if VVjMIb:
   totChannels = 0
   totChange = 0
   for path in CC8Yh1.VVYsfN():
    toSave = False
    txt = FFQDOO(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVjMIb.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVko4N(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFB8Nz(self, 'No channels in "lamedb" !')
 def VVFrcT(self, VVCarR, title):
  bFiles = CC8Yh1.VVYsfN()
  if bFiles: self.VVWpNi(bFiles, title)
  else  : FFM3N1(VVCarR, "No bouquets files !", 1500)
 def VV9u7c(self, VVCarR, title):
  self.VV9sna(VVCarR, BF(self.VVzbr8, title))
 def VVzbr8(self, title, VVCarR, bName, bPath):
  self.VVWpNi([bPath], title)
 def VVWpNi(self, bFiles, title):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVj8w5, bFiles)
      , VVLUmk = BF(self.VVScCL, title))
 def VVj8w5(self, bFiles, VVVRSv):
  VVVRSv.VVPpbS = ""
  VVVRSv.VVIQXG("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF9z80(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVVRSv or VVVRSv.isCancelled:
   return
  elif not totLines:
   VVVRSv.VVPpbS = "No IPTV Services !"
   return
  else:
   VVVRSv.VVWtjR(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVVRSv or VVVRSv.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF9z80(path)
    for ndx, line in enumerate(lines):
     if not VVVRSv or VVVRSv.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVVRSv:
       VVVRSv.VVIQXG("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVVRSv:
       VVVRSv.VVBQzv(1)
      refCode, startId, startNS = CCJEC1.VVgSI8(rType, CCJEC1.VVFUf6, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVVRSv:
        VVVRSv.VVPpbS = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVScCL(self, title, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVPpbS:
   txt += "\n\n%s\n%s" % (FFwXwL("Ended with Error:", VVdSiQ), VVPpbS)
  self.VVko4N(True, title, txt)
 def VVadZE(self):
  bFiles = CC8Yh1.VVYsfN()
  if not bFiles:
   FFM3N1(self.VVhqv2, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVhqv2.VVOazu():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFM3N1(self.VVhqv2, "Cannot read list", 1500)
   return
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVls4I, bFiles, tableRefList)
      , VVLUmk = BF(self.VVScCL, "Change Current List References to Unique Codes"))
 def VVls4I(self, bFiles, tableRefList, VVVRSv):
  VVVRSv.VVPpbS = ""
  VVVRSv.VVIQXG("Reading System References ...")
  refLst = CCJEC1.VVMlwj(CCJEC1.VVFUf6, stripRType=True)
  if not VVVRSv or VVVRSv.isCancelled:
   return
  VVVRSv.VVWtjR(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVVRSv or VVVRSv.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFQDOO(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVVRSv or VVVRSv.isCancelled:
     return
    VVVRSv.VVIQXG("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVVRSv or VVVRSv.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVVRSv.VVBQzv(1)
      refCode, startId, startNS = CCJEC1.VVgSI8(rType, CCJEC1.VVFUf6, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVVRSv:
        VVVRSv.VVPpbS = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVJGGk(self):
  list = None
  if self.VVhqv2:
   list = []
   for row in self.VVhqv2.VVOazu():
    list.append(row[4] + row[5])
  files = CC8Yh1.VVYsfN()
  totChange = 0
  if files:
   for path in files:
    lines = FF9z80(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVko4N(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVko4N(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFBOOj()
   if refreshTable and self.VVhqv2:
    VVkNlM = self.VVkzM7()
    if VVkNlM and self.VVhqv2:
     self.VVhqv2.VVartp(VVkNlM, self.tableTitle)
     self.VVhqv2.VVomXH(txt)
   FF3nHt(self, txt, title=title)
  else:
   FFWB0Q(self, "No changes.")
 @staticmethod
 def VVYsfN(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVSs5p + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFQDOO(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVgpWd(self, VVhqv2, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFtaHD(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFcAqb(self, fncMode=CCscAN.VVQ1jV, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VV16SF(self, VVhqv2, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVbgKL(self, VVhqv2, title, txt, colList):
  chName, chUrl = self.VV16SF(VVhqv2, colList)
  self.VVdymz(VVhqv2, chName, chUrl, "localIptv")
 def VV1efs(self, mode, VVhqv2, colList):
  chName, chUrl, picUrl, refCode = self.VV3HX8(mode, colList)
  return chName, chUrl
 def VV3Y24(self, mode, VVhqv2, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV3HX8(mode, colList)
  self.VVdymz(VVhqv2, chName, chUrl, mode)
 def VVdymz(self, VVhqv2, chName, chUrl, playerFlag):
  chName = FFpdHF(chName)
  if self.VVVywz(chName):
   FFM3N1(VVhqv2, "This is a marker!", 300)
  else:
   FFuMBP(VVhqv2, BF(self.VV1Eob, VVhqv2, chUrl, playerFlag), title="Playing ...")
 def VV1Eob(self, VVhqv2, chUrl, playerFlag):
  FFtU9E(self, chUrl, VVpkYJ=False)
  CCqLbA.VVZoRN(self.session, iptvTableParams=(self, VVhqv2, playerFlag))
 @staticmethod
 def VVVywz(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVTfay(self, VVhqv2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if refCode:
   url1 = FFtaHD(origUrl.strip())
   for ndx, row in enumerate(VVhqv2.VVOazu()):
    if refCode in row[4]:
     tableRow = FFtaHD(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVhqv2.VVj43f(ndx)
      break
   else:
    FFM3N1(VVhqv2, "No found", 1000)
 def VV9cJI(self, m3uMode):
  lines = self.VVCEL3(3)
  if lines:
   lines.sort()
   VVhIDJ = []
   for line in lines:
    VVhIDJ.append((line, line))
   if m3uMode == CC8Yh1.VV15Si:
    title = "Browse Server from M3U URLs"
    VVzwta = ("All to Playlist", self.VV9Qyq)
   else:
    title = "M3U/M3U8 File Browser"
    VVzwta = None
   VVvXZx = BF(self.VVrWie, m3uMode, title)
   VVW4TT = self.VV5BZ8
   FFRHhp(self, None, title=title, VVhIDJ=VVhIDJ, width=1200, VVvXZx=VVvXZx, VVW4TT=VVW4TT, VV8Vs4="", VVzwta=VVzwta, VVl9AY="#11221122", VVLICL="#11221122")
 def VVrWie(self, m3uMode, title, item=None):
  if item:
   VVCarR, txt, path, ndx = item
   if m3uMode == CC8Yh1.VV15Si:
    FFuMBP(VVCarR, BF(self.VV1xJY, title, path))
   else:
    FFuMBP(VVCarR, BF(self.VVP32O, path))
 def VVP32O(self, path, m3uFilterParam=None, VVhqv2=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFQDOO(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVQY09(propLine, "group-title") or "-"
   if not group == "-" and self.VVzh5B(group):
    if not chName or self.VVzsRi(chName):
     if self.VVXlCC(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVkNlM = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVkNlM.append((name, str(tot), name))
    totAll += tot
   VVkNlM.sort(key=lambda x: x[0].lower())
   VVkNlM.insert(0, ("ALL", str(totAll), ""))
  if VVkNlM:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVhqv2:
    VVhqv2.VVartp(VVkNlM, newTitle=title, VVEO5wMsg=True)
   else:
    VVPEsb = self.VVGl7n
    VVlUqf  = ("Select" , BF(self.VVgtMR, path, m3uFilterParam)  , [])
    VV1FeB = ("Filter" , BF(self.VVqiZi, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVrLHE  = (LEFT  , CENTER , LEFT )
    FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, width= 1400, height= 1000, VVNWWl=28, VVlUqf=VVlUqf, VV1FeB=VV1FeB, VVPEsb=VVPEsb, lastFindConfigObj=CFG.lastFindIptv
      , VVl9AY="#11110022", VVLICL="#11110022", VVHZxf="#11110022", VVSzMt="#00444400")
  elif VVhqv2:
   FFkqUz(VVhqv2, "Not found !", 1500)
  else:
   self.VVk2lk(FFQDOO(path), "", m3uFilterParam)
 def VVgtMR(self, path, m3uFilterParam, VVhqv2, title, txt, colList):
  self.VVk2lk(FFQDOO(path), colList[2], m3uFilterParam)
 def VVqiZi(self, path, m3uFilterParam, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(("All"      , "all"  ))
  VVhIDJ.append(FFw8eL("Category"))
  VVhIDJ.append(("Live TV"     , "live" ))
  VVhIDJ.append(("VOD"      , "vod"  ))
  VVhIDJ.append(("Series"     , "series" ))
  VVhIDJ.append(("Uncategorised"   , "uncat" ))
  VVhIDJ.append(FFw8eL("Media"))
  VVhIDJ.append(("Video"     , "video" ))
  VVhIDJ.append(("Audio"     , "audio" ))
  VVhIDJ.append(FFw8eL("File Type"))
  VVhIDJ.append(("MKV"      , "MKV"  ))
  VVhIDJ.append(("MP4"      , "MP4"  ))
  VVhIDJ.append(("MP3"      , "MP3"  ))
  VVhIDJ.append(("AVI"      , "AVI"  ))
  VVhIDJ.append(("FLV"      , "FLV"  ))
  filterObj = CCf604(self, VVl9AY="#11332244", VVLICL="#11222244")
  filterObj.VVVOhK(VVhIDJ, [], BF(self.VVajCm, VVhqv2, path), inFilterFnc=None)
 def VVajCm(self, VVhqv2, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVabNX , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVw010  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVyG5Z  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VV9Bn1  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVRmSs  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVNKkS  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVdRmz  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVnh2b  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVDwcM  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVTrm2  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVEC2W  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VV3aUJ  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVjWxE  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCf604.VV7zA4(words)
   if not mode == self.VVabNX:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFwXwL(fTitle, VVlrJC)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFuMBP(VVhqv2, BF(self.VVP32O, path, m3uFilterParam, VVhqv2), title="Filtering ...")
 def VVk2lk(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVj6oD, lst, filterGroup, m3uFilterParam)
       , VVLUmk = BF(self.VVloA6, title, bName))
  else:
   self.VVtlSr("No valid lines found !", title)
 def VVj6oD(self, lst, filterGroup, m3uFilterParam, VVVRSv):
  VVVRSv.VVPpbS = []
  VVVRSv.VVWtjR(len(lst))
  num = 0
  for cols in lst:
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVQY09(propLine, "group-title") or "-"
   picon = self.VVQY09(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVzh5B(group) : skip = True
    elif chName and not self.VVzsRi(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVXlCC(mode, "", FFtaHD(url).lower(), chName, words, "", asPrefix)
    if not skip and VVVRSv:
     num += 1
     VVVRSv.VVPpbS.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVloA6(self, title, bName, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVPpbS:
   VVPEsb = self.VVGl7n
   VVlUqf  = ("Select"   , BF(self.VV8dcG, title)   , [])
   VVJEWY = (""    , self.VVhGMY        , [])
   VVlrMb = ("Download PIcons", self.VVspUZ       , [])
   VVkGmL = ("Options"  , BF(self.VVugTw, "m3Ch", "", bName) , [])
   VV1FeB = ("Posters Mode" , BF(self.VVbEDp, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVrLHE  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVPpbS, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVJEWY=VVJEWY, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindIptv, VVJcAk=True, searchCol=1
     , VVl9AY="#0a00192B", VVLICL="#0a00192B", VVHZxf="#0a00192B", VVSzMt="#00000000")
  else:
   self.VVtlSr("Not found !", title)
 def VVspUZ(self, VVhqv2, title, txt, colList):
  self.VVOQGl(VVhqv2, "m3u/m3u8")
 def VVy2m8(self, rowNum, url, chName):
  refCode = self.VVsYov(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFyoN9(url), chName)
  return chUrl
 def VVsYov(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVZ101(catID, stID, chNum)
  return refCode
 def VVQY09(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VV8dcG(self, Title, VVhqv2, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFuMBP(VVhqv2, BF(self.VVSkAY, Title, VVhqv2, colList), title="Checking Server ...")
  else:
   self.VV4TN3(VVhqv2, url, chName)
 def VVSkAY(self, title, VVhqv2, colList):
  if not CCskCr.VVztta(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCIbAM.VVTbwO(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVhIDJ = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC8Yh1.VVbtfd(url, fPath)
     VVhIDJ.append((resol, fullUrl))
    if VVhIDJ:
     if len(VVhIDJ) > 1:
      FFRHhp(self, BF(self.VVanfo, VVhqv2, chName), VVhIDJ=VVhIDJ, title="Resolution", VVWLSA=True, VV14QT=True)
     else:
      self.VV4TN3(VVhqv2, VVhIDJ[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VV4TN3(VVhqv2, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CC8Yh1.VVbtfd(url, span.group(1))
       self.VV4TN3(VVhqv2, fullUrl, chName)
      else:
       self.VVqMWO("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVk2lk(txt, filterGroup="")
      return
    self.VV4TN3(VVhqv2, url, chName)
   else:
    self.VVtlSr("Cannot process this channel !", title)
  else:
   self.VVtlSr(err, title)
 def VVanfo(self, VVhqv2, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VV4TN3(VVhqv2, resolUrl, chName)
 def VV4TN3(self, VVhqv2, url, chName):
  FFuMBP(VVhqv2, BF(self.VV9V0Q, VVhqv2, url, chName), title="Playing ...")
 def VV9V0Q(self, VVhqv2, url, chName):
  chUrl = self.VVy2m8(VVhqv2.VVHqmL(), url, chName)
  FFtU9E(self, chUrl, VVpkYJ=False)
  CCqLbA.VVZoRN(self.session, iptvTableParams=(self, VVhqv2, "m3u/m3u8"))
 def VV7roc(self, VVhqv2, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVy2m8(VVhqv2.VVHqmL(), url, chName)
  return chName, chUrl
 def VVhGMY(self, VVhqv2, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFcAqb(self, fncMode=CCscAN.VVQ1jV, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVtlSr(self, err, title):
  FFB8Nz(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVGl7n(self, VVhqv2):
  if self.m3uOrM3u8File:
   self.close()
  VVhqv2.cancel()
 def VV9Qyq(self, selectionObj, item=None):
  FFuMBP(selectionObj, BF(self.VVjOVz, selectionObj, item))
 def VVjOVz(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVhIDJ):
    path = item[1]
    if fileExists(path):
     enc = CCbony.VVMjuP(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CC8Yh1.VV9BFu(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC8Yh1.VVquG5()
    pListF = "%sPlaylist_%s.txt" % (path, FFERmH())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVhIDJ)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF3nHt(self, txt, title=title)
   else:
    FFB8Nz(self, "Could not obtain URLs from this file list !", title=title)
 def VV4NLl(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVKJ5y
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV29vI
  lines = self.VVCEL3(mode)
  if lines:
   lines.sort()
   VVhIDJ = []
   for line in lines:
    VVhIDJ.append((FFwXwL(line, VVdVoc) if "Bookmarks" in line else line, line))
   VVW4TT = self.VV5BZ8
   FFRHhp(self, None, title=title, VVhIDJ=VVhIDJ, width=1200, VVvXZx=okFnc, VVW4TT=VVW4TT, VV8Vs4="")
 def VV5BZ8(self, VVCarR, txt, ref, ndx):
  txt = ref
  sz = FFoQQd(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCf82q.VVeeDD(sz)
  FF3nHt(self, txt, title="File Path")
 def VVKJ5y(self, item=None):
  if item:
   VVCarR, txt, path, ndx = item
   FFuMBP(VVCarR, BF(self.VVoDNt, VVCarR, path), title="Processing File ...")
 def VVoDNt(self, VVnsdq, path):
  enc = CCbony.VVMjuP(path, self)
  if enc == -1:
   return
  VVkNlM = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF77SS(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC8Yh1.VVF7gn(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVkNlM:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVkNlM.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVkNlM:
   title = "Playlist File : %s" % os.path.basename(path)
   VVlUqf  = ("Start"    , BF(self.VVbQ3J, "Playlist File")      , [])
   VVlpv3 = ("Home Menu"   , FFKdOO             , [])
   VVlrMb = ("Download M3U File" , self.VV3RK6         , [])
   VVkGmL = ("Edit File"   , BF(self.VV7Dlq, path)        , [])
   VV1FeB = ("Check & Filter"  , BF(self.VVnnsV, VVnsdq, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVrLHE  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVlpv3=VVlpv3, VV1FeB=VV1FeB, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVl9AY="#11001116", VVLICL="#11001116", VVHZxf="#11001116", VVSzMt="#00003635", VVvy9F="#0a333333", VVRt6l="#11331100", VVJcAk=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFB8Nz(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV3RK6(self, VVhqv2, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FF5jVY(self, BF(FFuMBP, VVhqv2, BF(self.VVhUA7, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVhUA7(self, title, url):
  path, err = FFlHhH(url, "ajp_tmp.m3u", timeout=10)
  errTitle = "Download Problem"
  if err:
   FFB8Nz(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFQDOO(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFZ5Mj(path)
    FFB8Nz(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFZ5Mj(path)
    FFB8Nz(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC8Yh1.VVquG5() + fName
    FFcZm9("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFWB0Q(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFB8Nz(self, "Could not download the M3U file!", title=errTitle)
 def VVbQ3J(self, Title, VVhqv2, title, txt, colList):
  url = colList[6]
  FFuMBP(VVhqv2, BF(self.VVTSzs, Title, url), title="Checking Server ...")
 def VV7Dlq(self, path, VVhqv2, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCwZEN(self, path, VVLUmk=BF(self.VVnBP2, VVhqv2), curRowNum=rowNum)
  else    : FFM8jr(self, path)
 def VVnBP2(self, VVhqv2, fileChanged):
  if fileChanged:
   VVhqv2.cancel()
 def VViA2U(self, title):
  curChName = self.VVhqv2.VV26F4(1)
  FFs37j(self, BF(self.VVbGIu, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVbGIu(self, title, name):
  if name:
   VVjMIb, err = CCn3v3.VVwReR(self, CCn3v3.VVSBfk, VV4Nwj=False, VV8QCM=False)
   list = []
   if VVjMIb:
    name = self.VV2ucW(name)
    ratio = "1"
    for item in VVjMIb:
     if name in item[0].lower():
      list.append((item[0], FFPrtr(item[2]), item[3], ratio))
   if list : self.VVTxAj(list, title)
   else : FFB8Nz(self, "Not found:\n\n%s" % name, title=title)
 def VVlUMe(self, title):
  curChName = self.VVhqv2.VV26F4(1)
  self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVYBSv
      , VVLUmk = BF(self.VV1aMm, title, curChName))
 def VVYBSv(self, VVVRSv):
  curChName = self.VVhqv2.VV26F4(1)
  VVjMIb, err = CCn3v3.VVwReR(self, CCn3v3.VVsanQ, VV4Nwj=False, VV8QCM=False)
  if not VVjMIb or not VVVRSv or VVVRSv.isCancelled:
   return
  VVVRSv.VVPpbS = []
  VVVRSv.VVWtjR(len(VVjMIb))
  curCh = self.VV2ucW(curChName)
  for refCode in VVjMIb:
   chName, sat, inDB = VVjMIb.get(refCode, ("", "", 0))
   ratio = CCTdjW.VVNtAV(chName.lower(), curCh)
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1, True)
   if VVVRSv and ratio > 50:
    VVVRSv.VVPpbS.append((chName, FFPrtr(sat), refCode.replace("_", ":"), str(ratio)))
 def VV1aMm(self, title, curChName, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVPpbS: self.VVTxAj(VVPpbS, title)
  elif VVVUTO: FFB8Nz(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVTxAj(self, VVkNlM, title):
  curChName = self.VVhqv2.VV26F4(1)
  VVlu0e = self.VVhqv2.VV26F4(4)
  curUrl  = self.VVhqv2.VV26F4(5)
  VVkNlM.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVlUqf  = ("Share Sat/C/T Ref.", BF(self.VVjFaL, title, curChName, VVlu0e, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVl9AY="#0a00112B", VVLICL="#0a001126", VVHZxf="#0a001126", VVSzMt="#00000000")
 def VVjFaL(self, newtitle, curChName, VVlu0e, curUrl, VVhqv2, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVlu0e, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF5jVY(self.VVhqv2, BF(FFuMBP, self.VVhqv2, BF(self.VVQTf0, VVhqv2, data)), ques, title=newtitle, VVQk5i=True)
 def VVQTf0(self, VVhqv2, data):
  VVhqv2.cancel()
  title, curChName, VVlu0e, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVlu0e = VVlu0e.strip()
  newRefCode = newRefCode.strip()
  if not VVlu0e.endswith(":") : VVlu0e += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVlu0e, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVlu0e + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CC8Yh1.VVYsfN():
    txt = FFQDOO(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFBOOj()
    newRow = []
    for i in range(6):
     newRow.append(self.VVhqv2.VV26F4(i))
    newRow[4] = newRefCode
    done = self.VVhqv2.VVuBFc(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFbn1D(BF(FFWB0Q , self, resTxt, title=title))
  elif resErr: FFbn1D(BF(FFB8Nz, self, resErr, title=title))
 def VVnnsV(self, VVnsdq, path, VVhqv2, title, txt, colList):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVnYPf, VVhqv2)
      , VVLUmk = BF(self.VV5xZn, VVnsdq, path, VVhqv2))
 def VVnYPf(self, VVhqv2, VVVRSv):
  VVVRSv.VVWtjR(VVhqv2.VVczIx())
  VVVRSv.VVPpbS = []
  for row in VVhqv2.VVOazu():
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1, True)
   qUrl = self.VVMa7d(self.VVfC8A, row[6])
   txt, err = self.VVaxHl(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVfIBq(item, "auth") == "0":
       VVVRSv.VVPpbS.append(qUrl)
    except:
     pass
 def VV5xZn(self, VVnsdq, path, VVhqv2, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVVUTO:
   list = VVPpbS
   title = "Authorized Servers"
   if list:
    totChk = VVhqv2.VVczIx()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFERmH()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV4NLl(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFwXwL(str(totAuth), VVfPTB)
     txt += "%s\n\n%s"    %  (FFwXwL("Result File:", VVdVoc), newPath)
     FF3nHt(self, txt, title=title)
     VVhqv2.close()
     VVnsdq.close()
    else:
     FFWB0Q(self, "All URLs are authorized.", title=title)
   else:
    FFB8Nz(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVaxHl(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVF7gn(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVYuLl(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCuvev.VVO8mQ()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVpIc5(decodedUrl):
  return CC8Yh1.VVYuLl(decodedUrl, justRetDotExt=True)
 def VVMa7d(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVF7gn(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVfC8A   : return "%s"            % url
  elif mode == self.VVL8JW   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVTHW6   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVLLfH  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVmosx  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVMQJd : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV6G9Q   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVR002    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV9two  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVkJci : return "%s&action=get_live_streams"      % url
  elif mode == self.VV0jRF  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVfIBq(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFzHDX(int(val))
    elif is_base64 : val = FFbClU(val)
    elif isToHHMMSS : val = FFdy8f(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV1xJY(self, title, path):
  if fileExists(path):
   enc = CCbony.VVMjuP(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CC8Yh1.VV9BFu(line)
     if qUrl:
      break
   if qUrl : self.VVTSzs(title, qUrl)
   else : FFB8Nz(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFB8Nz(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVq6cW(self):
  title = "Current Channel Server"
  qUrl, decodedUrl, iptvRef = CC8Yh1.VVOiYT(self)
  if qUrl or "chCode" in iptvRef:
   p = CCIbAM()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVoANg(decodedUrl)
   if valid:
    self.VVFIiS(self, host, mac)
    return
   elif qUrl:
    FFuMBP(self, BF(self.VVTSzs, title, qUrl), title="Checking Server ...")
    return
  FFB8Nz(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVOiYT(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF)
  qUrl = CC8Yh1.VV9BFu(decodedUrl)
  return qUrl, decodedUrl, iptvRef
 @staticmethod
 def VV9BFu(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVTSzs(self, title, url):
  self.curUrl = url
  self.VV9j4YData = {}
  qUrl = self.VVMa7d(self.VVfC8A, url)
  txt, err = self.VVaxHl(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV9j4YData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV9j4YData["username"    ] = self.VVfIBq(item, "username"        )
    self.VV9j4YData["password"    ] = self.VVfIBq(item, "password"        )
    self.VV9j4YData["message"    ] = self.VVfIBq(item, "message"        )
    self.VV9j4YData["auth"     ] = self.VVfIBq(item, "auth"         )
    self.VV9j4YData["status"    ] = self.VVfIBq(item, "status"        )
    self.VV9j4YData["exp_date"    ] = self.VVfIBq(item, "exp_date"    , isDate=True )
    self.VV9j4YData["is_trial"    ] = self.VVfIBq(item, "is_trial"        )
    self.VV9j4YData["active_cons"   ] = self.VVfIBq(item, "active_cons"       )
    self.VV9j4YData["created_at"   ] = self.VVfIBq(item, "created_at"   , isDate=True )
    self.VV9j4YData["max_connections"  ] = self.VVfIBq(item, "max_connections"      )
    self.VV9j4YData["allowed_output_formats"] = self.VVfIBq(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV9j4YData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV9j4YData["url"    ] = self.VVfIBq(item, "url"        )
    self.VV9j4YData["port"    ] = self.VVfIBq(item, "port"        )
    self.VV9j4YData["https_port"  ] = self.VVfIBq(item, "https_port"      )
    self.VV9j4YData["server_protocol" ] = self.VVfIBq(item, "server_protocol"     )
    self.VV9j4YData["rtmp_port"   ] = self.VVfIBq(item, "rtmp_port"       )
    self.VV9j4YData["timezone"   ] = self.VVfIBq(item, "timezone"       )
    self.VV9j4YData["timestamp_now"  ] = self.VVfIBq(item, "timestamp_now"  , isDate=True )
    self.VV9j4YData["time_now"   ] = self.VVfIBq(item, "time_now"       )
    VVhIDJ  = self.VVrMo0(True)
    VVvXZx = self.VV0XQT
    VVW4TT = self.VVriak
    VVMVWG = ("Home Menu", FFKdOO)
    VVVW3K= ("Add to Menu", BF(CC8Yh1.VVxprn, self, False, self.VV9j4YData["playListURL"]))
    VVzwta = ("Bookmark Server", BF(CC8Yh1.VVHyfZ, self, False, self.VV9j4YData["playListURL"]))
    VVCarR = FFRHhp(self, None, title="IPTV Server Resources", VVhIDJ=VVhIDJ, VVvXZx=VVvXZx, VVW4TT=VVW4TT, VVMVWG=VVMVWG, VVVW3K=VVVW3K, VVzwta=VVzwta)
    self.VVDje5(VVCarR)
   else:
    err = "Could not get data from server !"
  if err:
   FFB8Nz(self, err, title=title)
  FFM3N1(self)
 def VV0XQT(self, item=None):
  if item:
   VVCarR, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFuMBP(VVCarR, BF(self.VVH4SI, self.VVL8JW  , title=title), title=wTxt)
   elif ref == "vod"   : FFuMBP(VVCarR, BF(self.VVH4SI, self.VVTHW6  , title=title), title=wTxt)
   elif ref == "series"  : FFuMBP(VVCarR, BF(self.VVH4SI, self.VVLLfH , title=title), title=wTxt)
   elif ref == "catchup"  : FFuMBP(VVCarR, BF(self.VVH4SI, self.VVmosx , title=title), title=wTxt)
   elif ref == "accountInfo" : FFuMBP(VVCarR, BF(self.VVdsDT           , title=title), title=wTxt)
 def VVDje5(self, VVCarR):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if   FF8tzC(decodedUrl) : VVCarR.VVflXp(1)
  elif FFSKBc(decodedUrl): VVCarR.VVflXp(2)
 def VVriak(self, VVCarR, txt, ref, ndx):
  FFuMBP(VVCarR, self.VVeKk8)
 def VVeKk8(self):
  txt = self.curUrl
  if VVT9SH:
   ver, err = self.VV8gLt(self.VVD3Aa())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VV47AR
   txt += "PHP\t: %s\n"  % self.VVCvVr
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVW4im, "-")
   txt += "Version\t: %s"  % (ver or err)
  FF3nHt(self, txt, title="Current Server URL")
 def VVdsDT(self, title):
  rows = []
  for key, val in self.VV9j4YData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVuPp3
   else:
    num, part = "1", self.VV86Zo
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVlpv3  = ("Home Menu", FFKdOO, [])
  VVlrMb  = None
  if VVT9SH:
   VVlrMb = ("Get JS" , BF(self.VVkYy5, "/".join(self.VV9j4YData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFNCSP(self, None, title=title, width=1200, header=header, VVFWkP=rows, VVN1SU=widths, VVNWWl=26, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000", searchCol=2)
 def VVYfti(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VV6G9Q, self.VV0jRF):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVfIBq(item, "num"         )
      name     = self.VVfIBq(item, "name"        )
      stream_id    = self.VVfIBq(item, "stream_id"       )
      stream_icon    = self.VVfIBq(item, "stream_icon"       )
      epg_channel_id   = self.VVfIBq(item, "epg_channel_id"      )
      added     = self.VVfIBq(item, "added"    , isDate=True )
      is_adult    = self.VVfIBq(item, "is_adult"       )
      category_id    = self.VVfIBq(item, "category_id"       )
      tv_archive    = self.VVfIBq(item, "tv_archive"       )
      direct_source   = self.VVfIBq(item, "direct_source"      )
      tv_archive_duration  = self.VVfIBq(item, "tv_archive_duration"     )
      name = self.VVzsRi(name, is_adult)
      if name:
       if mode == self.VV6G9Q or mode == self.VV0jRF and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVR002:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVfIBq(item, "num"         )
      name    = self.VVfIBq(item, "name"        )
      stream_id   = self.VVfIBq(item, "stream_id"       )
      stream_icon   = self.VVfIBq(item, "stream_icon"       )
      added    = self.VVfIBq(item, "added"    , isDate=True )
      is_adult   = self.VVfIBq(item, "is_adult"       )
      category_id   = self.VVfIBq(item, "category_id"       )
      container_extension = self.VVfIBq(item, "container_extension"     ) or "mp4"
      name = self.VVzsRi(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VV9two:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVfIBq(item, "num"        )
      name    = self.VVfIBq(item, "name"       )
      series_id   = self.VVfIBq(item, "series_id"      )
      cover    = self.VVfIBq(item, "cover"       )
      genre    = self.VVfIBq(item, "genre"       )
      episode_run_time = self.VVfIBq(item, "episode_run_time"    )
      category_id   = self.VVfIBq(item, "category_id"      )
      container_extension = self.VVfIBq(item, "container_extension"    ) or "mp4"
      name = self.VVzsRi(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVH4SI(self, mode, title):
  cList, err = self.VVVxG5(mode)
  if cList and mode == self.VVmosx:
   cList = self.VVnZlR(cList)
  if err:
   FFB8Nz(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT(mode)
   mName = self.VVVc72(mode)
   if   mode == self.VVL8JW  : fMode = self.VV6G9Q
   elif mode == self.VVTHW6  : fMode = self.VVR002
   elif mode == self.VVLLfH : fMode = self.VV9two
   elif mode == self.VVmosx : fMode = self.VV0jRF
   if mode == self.VVmosx:
    VVkGmL = None
    VV1FeB = None
   else:
    VVkGmL = ("Find in %s" % mName , BF(self.VVtEjU, fMode, True) , [])
    VV1FeB = ("Find in Selected" , BF(self.VVtEjU, fMode, False) , [])
   VVlUqf   = ("Show List"   , BF(self.VVjJ2H, mode)  , [])
   VVlpv3  = ("Home Menu"   , FFKdOO         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFNCSP(self, None, title=title, width=1200, header=header, VVFWkP=cList, VVN1SU=widths, VVNWWl=30, VVlpv3=VVlpv3, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVlUqf=VVlUqf, VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFB8Nz(self, "No list from server !", title=title)
  FFM3N1(self)
 def VVVxG5(self, mode):
  qUrl  = self.VVMa7d(mode, self.VV9j4YData["playListURL"])
  txt, err = self.VVaxHl(qUrl, timeout=20 if mode == self.VVL8JW else 3)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVfIBq(item, "category_id"  )
     category_name = self.VVfIBq(item, "category_name" )
     parent_id  = self.VVfIBq(item, "parent_id"  )
     category_name = self.VVzh5B(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVnZlR(self, catList):
  mode  = self.VV0jRF
  qUrl  = self.VVMa7d(mode, self.VV9j4YData["playListURL"])
  txt, err = self.VVaxHl(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVYfti(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVjJ2H(self, mode, VVhqv2, title, txt, colList):
  title = colList[1]
  FFuMBP(VVhqv2, BF(self.VVf5ch, mode, VVhqv2, title, txt, colList), title="Downloading ...")
 def VVf5ch(self, mode, VVhqv2, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVVc72(mode) + " : "+ bName
  if   mode == self.VVL8JW  : mode = self.VV6G9Q
  elif mode == self.VVTHW6  : mode = self.VVR002
  elif mode == self.VVLLfH : mode = self.VV9two
  elif mode == self.VVmosx : mode = self.VV0jRF
  qUrl  = self.VVMa7d(mode, self.VV9j4YData["playListURL"], catID)
  txt, err = self.VVaxHl(qUrl)
  list  = []
  if not err and mode in (self.VV6G9Q, self.VVR002, self.VV9two, self.VV0jRF):
   list, err = self.VVYfti(mode, txt)
  if err:
   FFB8Nz(self, err, title=title)
  elif list:
   VVlpv3  = ("Home Menu"   , FFKdOO            , [])
   if mode in (self.VV6G9Q, self.VV0jRF):
    VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT(mode)
    VVJEWY = (""     , BF(self.VVQIkO, mode)      , [])
    VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, "", "")   , [])
    VVkGmL = ("Options"   , BF(self.VVugTw, "lv", mode, bName)   , [])
    VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, False)     , [])
    if mode == self.VV6G9Q:
     VVlUqf = ("Play"    , BF(self.VV3Y24, mode)       , [])
    else:
     VVlUqf = ("Programs"   , BF(self.VVogWO, mode, bName) , [])
   elif mode == self.VVR002:
    VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT(mode)
    VVlUqf  = ("Play"    , BF(self.VV3Y24, mode)       , [])
    VVJEWY = (""     , BF(self.VVQIkO, mode)      , [])
    VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, "v", "")   , [])
    VVkGmL = ("Options"   , BF(self.VVugTw, "v", mode, bName)   , [])
    VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, False)     , [])
   elif mode == self.VV9two:
    VVl9AY, VVLICL, VVHZxf, VVSzMt = self.VV5hqT("series2")
    VVlUqf  = ("Show Seasons"  , BF(self.VVDXgP, mode)       , [])
    VVJEWY = (""     , BF(self.VVTvcz, mode)     , [])
    VVlrMb = None
    VVkGmL = None
    VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, True)      , [])
   header, widths, VVrLHE = self.VVl6Uc(mode)
   FFNCSP(self, None, title=title, header=header, VVFWkP=list, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindIptv, VVJEWY=VVJEWY, VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt, VVJcAk=True, searchCol=1)
  else:
   FFB8Nz(self, "No Channels found !", title=title)
  FFM3N1(self)
 def VVl6Uc(self, mode):
  if mode in (self.VV6G9Q, self.VV0jRF):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVrLHE  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVR002:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVrLHE  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VV9two:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVrLHE  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVrLHE
 def VVogWO(self, mode, bName, VVhqv2, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV9j4YData["playListURL"]
  ok_fnc  = BF(self.VVyItV, hostUrl, chName, catId, streamId)
  FFuMBP(VVhqv2, BF(CC8Yh1.VVVLLg, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVyItV(self, chUrl, chName, catId, streamId, VVhqv2, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC8Yh1.VVF7gn(chUrl)
   chNum = "333"
   refCode = CC8Yh1.VVZ101(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFtU9E(self, chUrl, VVpkYJ=False)
   CCqLbA.VVZoRN(self.session)
  else:
   FFB8Nz(self, "Incorrect Timestamp", pTitle)
 def VVDXgP(self, mode, VVhqv2, title, txt, colList):
  title = colList[1]
  FFuMBP(VVhqv2, BF(self.VV7V44, mode, VVhqv2, title, txt, colList), title="Downloading ...")
 def VV7V44(self, mode, VVhqv2, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVMa7d(self.VVMQJd, self.VV9j4YData["playListURL"], series_id)
  txt, err = self.VVaxHl(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVfIBq(tDict["info"], "name"   )
      category_id = self.VVfIBq(tDict["info"], "category_id" )
      icon  = self.VVfIBq(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVfIBq(EP, "id"     )
        episode_num   = self.VVfIBq(EP, "episode_num"   )
        epTitle    = self.VVfIBq(EP, "title"     )
        container_extension = self.VVfIBq(EP, "container_extension" )
        seasonNum   = self.VVfIBq(EP, "season"    )
        epTitle = self.VVzsRi(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFB8Nz(self, err, title=title)
  elif list:
   VVlpv3 = ("Home Menu"   , FFKdOO          , [])
   VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, "s", title), [])
   VVkGmL = ("Options"   , BF(self.VVugTw, "s", mode, title) , [])
   VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, False)   , [])
   VVJEWY = (""     , BF(self.VVQIkO, mode)    , [])
   VVlUqf  = ("Play"    , BF(self.VV3Y24, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVrLHE  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFNCSP(self, None, title=title, header=header, VVFWkP=list, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVkGmL=VVkGmL, VV1FeB=VV1FeB, lastFindConfigObj=CFG.lastFindIptv, VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000")
  else:
   FFB8Nz(self, "No Channels found !", title=title)
  FFM3N1(self)
 def VVtEjU(self, mode, isAll, VVhqv2, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVhIDJ = []
  VVhIDJ.append(("Keyboard"  , "manualEntry"))
  VVhIDJ.append(("From Filter" , "fromFilter"))
  FFRHhp(self, BF(self.VVAcgU, VVhqv2, mode, onlyCatID), title="Input Type", VVhIDJ=VVhIDJ, width=400)
 def VVAcgU(self, VVhqv2, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFs37j(self, BF(self.VVkV58, VVhqv2, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCf604(self)
    filterObj.VV98nA(BF(self.VVkV58, VVhqv2, mode, onlyCatID))
 def VVkV58(self, VVhqv2, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFsMp0(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCf604.VV7zA4(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFB8Nz(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFB8Nz(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VV7pMv(words):
      FFB8Nz(self, self.VVl3zf(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVvyGL, VVhqv2, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVLUmk = BF(self.VVL6cA, mode, toFind, title))
   if not words:
    FFM3N1(VVhqv2, "Nothing to find !", 1500)
 def VVvyGL(self, VVhqv2, mode, onlyCatID, title, words, toFind, asPrefix, VVVRSv):
  VVVRSv.VVWtjR(VVhqv2.VVfbKq() if onlyCatID is None else 1)
  VVVRSv.VVPpbS = []
  for row in VVhqv2.VVOazu():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVBQzv(1)
   VVVRSv.VVZ4Fr(catName)
   qUrl  = self.VVMa7d(mode, self.VV9j4YData["playListURL"], catID)
   txt, err = self.VVaxHl(qUrl)
   if not err:
    tList, err = self.VVYfti(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVzsRi(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVVRSv or VVVRSv.isCancelled:
        return
       VVVRSv.VVPpbS.append(item)
       VVVRSv.VVZ4Fr(catName)
 def VVL6cA(self, mode, toFind, title, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVPpbS:
   title = self.VVtf6s(mode, toFind)
   if mode == self.VV6G9Q or mode == self.VVR002:
    if mode == self.VVR002 : typ = "v"
    else          : typ = ""
    bName   = CC8Yh1.VV5TZE(toFind)
    VVlUqf  = ("Play"     , BF(self.VV3Y24, mode)     , [])
    VVlrMb = ("Download Options" , BF(self.VVSoTk, mode, typ, "") , [])
    VVkGmL = ("Options"   , BF(self.VVugTw, "fnd", mode, bName), [])
    VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, False)   , [])
    VVJEWY = (""     , BF(self.VVQIkO, mode)    , [])
   elif mode == self.VV9two:
    VVlUqf  = ("Show Seasons"  , BF(self.VVDXgP, mode)     , [])
    VVkGmL = None
    VVlrMb = None
    VV1FeB = ("Posters Mode"  , BF(self.VVbEDp, mode, True)    , [])
    VVJEWY = (""     , BF(self.VVTvcz, mode)   , [])
   VVlpv3  = ("Home Menu"   , FFKdOO          , [])
   header, widths, VVrLHE = self.VVl6Uc(mode)
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVPpbS, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVJEWY=VVJEWY, VVl9AY="#0a00292B", VVLICL="#0a002126", VVHZxf="#0a002126", VVSzMt="#00000000", VVJcAk=True, searchCol=1)
   if not VVVUTO:
    FFM3N1(VVhqv2, "Stopped" , 1000)
  else:
   if VVVUTO:
    FFB8Nz(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VV3HX8(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VV6G9Q, self.VV0jRF):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVR002:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFpdHF(chName)
  url = self.VV9j4YData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVF7gn(url)
  refCode = self.VVZ101(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVQIkO(self, mode, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVh4t8, mode, VVhqv2, title, txt, colList))
 def VVh4t8(self, mode, VVhqv2, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV3HX8(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFcAqb(self, fncMode=CCscAN.VVpttR, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVTvcz(self, mode, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVadLr, mode, VVhqv2, title, txt, colList))
 def VVadLr(self, mode, VVhqv2, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFcAqb(self, fncMode=CCscAN.VVHzXh, chName=name, text=txt, picUrl=Cover)
 def VVbEDp(self, mode, isSerNames, VVhqv2, title, txt, colList):
  if   mode in ("itv"  , CC8Yh1.VV6G9Q, CC8Yh1.VV0jRF): category = "live"
  elif mode in ("vod"  , CC8Yh1.VVR002 )          : category = "vod"
  elif mode in ("series" , CC8Yh1.VV9two)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VV6G9Q : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV0jRF : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVR002  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV9two : picCol, descCol, descTxt = 5, 0, "Season"
  FFuMBP(VVhqv2, BF(self.session.open, CCjskR, VVhqv2, category, nameCol, picCol, descCol, descTxt))
 def VVSoTk(self, mode, typ, seriesName, VVhqv2, title, txt, colList):
  VVhIDJ = []
  isMulti = VVhqv2.VVVoic
  tot  = VVhqv2.VVv2WG()
  if isMulti:
   if tot < 1:
    FFM3N1(VVhqv2, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVhIDJ.append(("Download %s PIcon%s" % (name, FFW43m(tot)), "dnldPicons" ))
  if typ:
   VVhIDJ.append(VVuAtK)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVhIDJ.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVhIDJ.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVhIDJ.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCSDOM.VVDxIp():
    VVhIDJ.append(VVuAtK)
    VVhIDJ.append(("Download Manager"      , "dload_stat" ))
  FFRHhp(self, BF(self.VVCHTt, VVhqv2, mode, typ, seriesName, colList), title="Download Options", VVhIDJ=VVhIDJ)
 def VVCHTt(self, VVhqv2, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVOQGl(VVhqv2, mode)
   elif item == "dnldSel"  : self.VVFoXE(VVhqv2, mode, typ, colList, True)
   elif item == "addSel"  : self.VVFoXE(VVhqv2, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVIDus(VVhqv2, mode, typ, seriesName)
   elif item == "dload_stat" : CCSDOM.VV2g5x(self, VVhqv2)
 def VVFoXE(self, VVhqv2, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVzebp(mode, typ, colList)
  if startDnld:
   CCSDOM.VVotcn(self, decodedUrl)
  else:
   self.VVqyNn(VVhqv2, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVIDus(self, VVhqv2, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVhqv2.VVOazu():
   chName, decodedUrl = self.VVzebp(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVqyNn(VVhqv2, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVqyNn(self, VVhqv2, title, chName, decodedUrl_list, startDnld):
  FF5jVY(self, BF(self.VVUS6z, VVhqv2, decodedUrl_list, startDnld), chName, title=title)
 def VVUS6z(self, VVhqv2, decodedUrl_list, startDnld):
  added, skipped = CCSDOM.VVp0TY(decodedUrl_list)
  FFM3N1(VVhqv2, "Added", 1000)
 def VVzebp(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VV3HX8(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, colList)
   refCode, chUrl = self.VVefbI(self.VV47AR, self.VVS3cB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFpqbA(chUrl)
  return chName, decodedUrl
 def VVOQGl(self, VVhqv2, mode):
  if FFBf4e("ffmpeg"):
   self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VV61up, VVhqv2, mode)
       , VVLUmk = self.VVmrff)
  else:
   FF5jVY(self, BF(CC8Yh1.VVNEU2, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVmrff(self, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVPpbS["proces"], VVPpbS["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVPpbS["ok"], VVPpbS["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVPpbS["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVPpbS["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVPpbS["badURL"]
  txt += "Download Failure\t: %d\n"   % VVPpbS["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVPpbS["path"]
  if not VVVUTO  : color = "#11402000"
  elif VVPpbS["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVPpbS["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVPpbS["err"], txt)
  title = "PIcons Download Result"
  if not VVVUTO:
   title += "  (cancelled)"
  FF3nHt(self, txt, title=title, VVHZxf=color)
 def VV61up(self, VVhqv2, mode, VVVRSv):
  isMulti = VVhqv2.VVVoic
  if isMulti : totRows = VVhqv2.VVv2WG()
  else  : totRows = VVhqv2.VVfbKq()
  VVVRSv.VVWtjR(totRows)
  VVVRSv.VV8wiV(0)
  counter     = VVVRSv.counter
  maxValue    = VVVRSv.maxValue
  pPath     = CCTdjW.VVJwSu()
  VVVRSv.VVPpbS = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVhqv2.VVOazu()):
    if VVVRSv.isCancelled:
     break
    if not isMulti or VVhqv2.VVfcYI(rowNum):
     VVVRSv.VVPpbS["proces"] += 1
     VVVRSv.VVBQzv(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, row)
      refCode = CC8Yh1.VVZ101(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVsYov(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VV3HX8(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVVRSv.VVPpbS["attempt"] += 1
       path, err = FFlHhH(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVVRSv:
         VVVRSv.VVPpbS["ok"] += 1
         VVVRSv.VV8wiV(VVVRSv.VVPpbS["ok"])
        if FFoQQd(path) > 0:
         cmd = CCscAN.VVsRkF(path)
         cmd += FFUGBP("mv -f '%s' '%s'" % (path, pPath))
         FFcZm9(cmd)
        else:
         if VVVRSv:
          VVVRSv.VVPpbS["size0"] += 1
         FFZ5Mj(path)
       elif err:
        if VVVRSv:
         VVVRSv.VVPpbS["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVVRSv:
          VVVRSv.VVPpbS["err"] = err.title()
         break
      else:
       if VVVRSv:
        VVVRSv.VVPpbS["exist"] += 1
     else:
      if VVVRSv:
       VVVRSv.VVPpbS["badURL"] += 1
  except:
   pass
 def VVWiRH(self):
  title = "Download PIcons for Current Bouquet"
  if FFBf4e("ffmpeg"):
   self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
       , titlePrefix = ""
       , fncToRun  = self.VVd0RZ
       , VVLUmk = BF(self.VVBeBU, title))
  else:
   FF5jVY(self, BF(CC8Yh1.VVNEU2, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVd0RZ(self, VVVRSv):
  bName = CCJEC1.VVk53P()
  pPath = CCTdjW.VVJwSu()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVVRSv.VVPpbS = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCJEC1.VVbWPR()
  if not VVVRSv or VVVRSv.isCancelled:
   return
  if not services or len(services) == 0:
   VVVRSv.VVPpbS = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVVRSv.VVWtjR(totCh)
  VVVRSv.VV8wiV(0)
  for serv in services:
   if not VVVRSv or VVVRSv.isCancelled:
    return
   VVVRSv.VVPpbS = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVVRSv.VVBQzv(1)
   VVVRSv.VV8wiV(totPic)
   fullRef  = serv[0]
   if FFrhBg(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFpqbA(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCIbAM.VV9LRd(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC8Yh1.VVaxHl(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCscAN.VVZIuJ(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFlHhH(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVVRSv:
     VVVRSv.VV8wiV(totPic)
    if FFoQQd(path) > 0:
     cmd = CCscAN.VVsRkF(path)
     cmd += FFUGBP("mv -f '%s' '%s'" % (path, pPath))
     FFcZm9(cmd)
     totPicOK += 1
    else:
     totSize0
     FFZ5Mj(path)
  if VVVRSv:
   VVVRSv.VVPpbS = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVBeBU(self, title, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVPpbS
  if err:
   FFB8Nz(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFwXwL(str(totExist)  , VVdSiQ)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFwXwL(str(totNotIptv)  , VVdSiQ)
    if totServErr : txt += "Server Errors\t: %s\n" % FFwXwL(str(totServErr) + t1, VVdSiQ)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFwXwL(str(totParseErr) , VVdSiQ)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFwXwL(str(totInvServ)  , VVdSiQ)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFwXwL(str(totInvPicUrl) , VVdSiQ)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFwXwL(str(totSize0)  , VVdSiQ)
   if not VVVUTO:
    title += "  (stopped)"
   FF3nHt(self, txt, title=title)
 @staticmethod
 def VVNEU2(SELF):
  cmd = FFyOYr(VVTdap, "ffmpeg")
  if cmd : FFFPZ4(SELF, cmd, title="Installing FFmpeg")
  else : FF4L5V(SELF)
 @staticmethod
 def VVxSdd(SELF):
  SELF.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW
      , titlePrefix = ""
      , fncToRun  = CC8Yh1.VVWqKh
      , VVLUmk = BF(CC8Yh1.VVMRC3, SELF))
 @staticmethod
 def VVWqKh(VVVRSv):
  bName = CCJEC1.VVk53P()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVVRSv.VVPpbS = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCJEC1.VVbWPR()
  if not VVVRSv or VVVRSv.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVVRSv.VVWtjR(totCh)
   for serv in services:
    if not VVVRSv or VVVRSv.isCancelled:
     return
    VVVRSv.VVBQzv(1)
    fullRef = serv[0]
    if FFrhBg(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFpqbA(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCIbAM.VVxkTN(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CC8Yh1.VVH6pG(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVVRSv:
      VVVRSv.VVgURK(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCwOKQ.VV0bIB(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVVRSv:
     VVVRSv.VVPpbS = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVVRSv.VVPpbS = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVMRC3(SELF, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVPpbS
  title = "IPTV EPG Import"
  if err:
   FFB8Nz(SELF, err, title=title)
  else:
   if VVVUTO and totEpgOK > 0:
    CCwOKQ.VVnm5n()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFwXwL(str(totNotIptv), VVdSiQ)
    if totServErr : txt += "Server Errors\t: %s\n" % FFwXwL(str(totServErr) + t1, VVdSiQ)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFwXwL(str(totInv), VVdSiQ)
   if not VVVUTO:
    title += "  (stopped)"
   FF3nHt(SELF, txt, title=title)
 @staticmethod
 def VVH6pG(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC8Yh1.VVF7gn(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC8Yh1.VVaxHl(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC8Yh1.VVfIBq(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC8Yh1.VVfIBq(item, "lang"        ).upper()
    now_playing   = CC8Yh1.VVfIBq(item, "now_playing"      )
    start    = CC8Yh1.VVfIBq(item, "start"        )
    start_timestamp  = CC8Yh1.VVfIBq(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC8Yh1.VVfIBq(item, "start_timestamp"     )
    stop_timestamp  = CC8Yh1.VVfIBq(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC8Yh1.VVfIBq(item, "stop_timestamp"      )
    tTitle    = CC8Yh1.VVfIBq(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVZ101(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC8Yh1.VVryd3(catID, MAX_4b)
  TSID = CC8Yh1.VVryd3(chNum, MAX_4b)
  ONID = CC8Yh1.VVryd3(chNum, MAX_4b)
  NS  = CC8Yh1.VVryd3(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVryd3(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV5TZE(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV5hqT(mode):
  if   mode in ("itv"  , CC8Yh1.VVL8JW)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC8Yh1.VVTHW6)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC8Yh1.VVLLfH) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC8Yh1.VVmosx) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC8Yh1.VV0jRF    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVCEL3(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVbCvh:
   excl = FF9R5Y(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFB8Nz(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf\|\.json"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFpNiE('find %s %s %s' % (path, excl, par))
  if files:
   err = CCf82q.VVIxYK(files)
   if err : FFB8Nz(self, err + FFwXwL('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVdVoc))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFB8Nz(self, err)
  return []
 @staticmethod
 def VVquG5():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF77SS(path)
  return "/"
 @staticmethod
 def VVVLLg(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC8Yh1.VVH6pG(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFB8Nz(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVl9AY, VVLICL, VVHZxf, VVSzMt = CC8Yh1.VV5hqT("")
   VVlpv3 = ("Home Menu" , FFKdOO, [])
   VVlUqf  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVrLHE  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFNCSP(SELF, None, title="Programs for : " + chName, header=header, VVFWkP=pList, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=24, VVlUqf=VVlUqf, VVlpv3=VVlpv3, VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt)
  else:
   FFB8Nz(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVbtfd(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVxprn(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FF5jVY(self, BF(self.VVX4Gg, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFsMp0(confItem, line)
   FFWB0Q(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVX4Gg(self, title, confItem):
  FFsMp0(confItem, "")
  FFWB0Q(self, "Removed from IPTV Menu.", title=title)
 def VVCoXB(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVFIiS(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFuMBP(self, BF(self.VVTSzs, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFB8Nz(self, "Incorrect server data !")
 @staticmethod
 def VVHyfZ(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC8Yh1.VVquG5()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFB8Nz(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFWB0Q(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFB8Nz(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVugTw(self, source, mode, curBName, VVhqv2, title, txt, colList):
  isMulti = VVhqv2.VVVoic
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVhqv2.VVv2WG()
   totTxt = "%d Service%s" % (tot, FFW43m(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFwXwL(totTxt, VVdVoc)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCr5W8(self, VVhqv2, addSep=False)
  thTxt = "Adding Services ..."
  VVhIDJ, cbFncDict = [], None
  VVhIDJ.append(VVuAtK)
  if itemsOK:
   VVhIDJ.append(("Add %s to New Bouquet : %s"    % (totTxt, FFwXwL(curBName , VVfPTB)), "addToCur1"))
   if curBName2: VVhIDJ.append(("Add %s to New Bouquet : %s" % (totTxt, FFwXwL(curBName2, VVEhqe)) , "addToCur2"))
   VVhIDJ.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFuMBP, mSel.VVhqv2, BF(self.VVLMuZ,source, mode, curBName , VVhqv2, title), title=thTxt)
      , "addToCur2": BF(FFuMBP, mSel.VVhqv2, BF(self.VVLMuZ,source, mode, curBName2, VVhqv2, title), title=thTxt)
      , "addToNew" : BF(self.VVbfNP, source, mode, curBName, VVhqv2, title)
      }
  else:
   VVhIDJ.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVklJK(VVhIDJ, cbFncDict, width=1400)
 def VVLMuZ(self, source, mode, curBName, VVhqv2, Title):
  chUrlLst = self.VVAqFI(source, mode, VVhqv2)
  CCJEC1.VVH0cU(self, Title, curBName, "", chUrlLst)
 def VVbfNP(self, source, mode, curBName, VVhqv2, Title):
  picker = CCJEC1(self, VVhqv2, Title, BF(self.VVAqFI, source, mode, VVhqv2), defBName=curBName)
 def VVAqFI(self, source, mode, VVhqv2):
  totChange = 0
  isMulti = VVhqv2.VVVoic
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVhqv2.VVOazu()):
   if not isMulti or VVhqv2.VVfcYI(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV4qge(mode, row)
     refCode, chUrl = self.VVefbI(self.VV47AR, self.VVS3cB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVy2m8(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VV3HX8(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVV6bL():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVj2DV():
  return sorted(tuple(CC8Yh1.VVV6bL()))
 @staticmethod
 def VVOHeM(rt):
  return CC8Yh1.VVV6bL().get(str(rt), "")
 @staticmethod
 def VVn9n1(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CC8Yh1.VVOHeM(span.group(1)) if span else ""
 @staticmethod
 def VVk5Uy(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVgMAZ():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVhIDJ = []
  for ndx, rt in enumerate(CC8Yh1.VVj2DV()):
   VVhIDJ.append(FFyXfa("%s\t... %s" % (CC8Yh1.VVOHeM(rt), rt), rt, CC8Yh1.VVk5Uy(rt), VVuj5g if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVhIDJ.append(VVuAtK)
  return VVhIDJ
class CCkFkY(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVpkZD(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFOrd9(self.frm, frmColor)
  FFOrd9(self.bak, bakColor)
  FFOrd9(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VV2Lea(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFdPXt(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCQNdY(CCkFkY):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCkFkY.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV1OZ7()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVyASM,
  {
   "up" : self.VVUREY   ,
   "down" : self.VVrBVj  ,
   "left" : self.VV2KSP  ,
   "right" : self.VVVV8y  ,
   "next" : self.VV7l89 ,
   "last" : self.VVn9SE
  }, -1)
 def VVmqft(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVpkZD(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VV3f20()
  self["myPiconPtr"].hide()
 def VVxbir(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVUREY(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVSxFN()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVpbN4()
 def VVrBVj(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVlhUf()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVpbN4()
 def VV2KSP(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVSxFN()
  else:
   self.curCol -= 1
   self.VVpbN4()
 def VVVV8y(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVlhUf()
  else:
   self.curCol += 1
   self.VVpbN4()
 def VVn9SE(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVpbN4(oldPage != self.curPage)
 def VV7l89(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVpbN4(oldPage != self.curPage)
 def VVlhUf(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVpbN4(force)
 def VVSxFN(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVpbN4(force)
 def VVpbN4(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVwbOx = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVwbOx: self.curPage = VVwbOx
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVLYbr()
  self["myPiconPtr"].hide()
  self.VV2Lea(self.curPage + 1, self.totalPages)
  FFbn1D(BF(self.VVOp6Z, force or not oldPage == self.curPage, VVwbOx))
 def VVOp6Z(self, force, VVwbOx):
  try:
   if force:
    self.VVVDMG()
   if self.curPage == VVwbOx:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVLYbr()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVqlGr(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVpbN4(False if oldPage == self.curPage else True)
  else:
   FFM3N1(self, "Not found", 1000)
 def VV7Bey(self):
  self.VVqlGr(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VV1OZ7(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVf39W(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVRiLh, CC6wQD, defFG=fg, defBG=bg, onlyBG=True)
 def VVRiLh(self, fg, bg):
  if self.colorCfg and bg:
   FFsMp0(self.colorCfg, bg)
   self.VV3f20()
 def VV3f20(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFOrd9(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVLpvH(self, lbl, txt, color=""):
  CCQNdY.VV8gYI(lbl, txt, color)
 @staticmethod
 def VV8gYI(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVgw8m(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCjskR(Screen, CCQNdY):
 def __init__(self, session, VVhqv2, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFMkht(VViNNi, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVhqv2  = VVhqv2
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVFWkP    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFTlW1(self, self.Title)
  CCQNdY.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVVcWE, subPath)
  if not pathExists(self.pPath):
   FFcZm9("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVYfT9    ,
   "cancel": self.close    ,
   "menu" : self.VVMpx8 ,
   "info" : self.VVrKHe  ,
   "0"  : self.VV7Bey
  })
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  FF3wB4(self)
  self.VVmqft()
  self.VVOxcP()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVMpx8(self):
  chName, subj, desc, fName, picUrl = self.VVFWkP[self.curIndex]
  VVhIDJ = []
  VVhIDJ.append(FFyXfa("Show Selected Picture"        , "VVFqQ6"  , fName))
  VVhIDJ.append(FFyXfa("Copy Selected Picture to Export-Directory"   , "VVNWAI" , fName))
  VVhIDJ.append(FFyXfa("Set Selected Picture as a Poster for a Local Media" , "VVOyJK", fName))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Cache details"       , "VVOm14"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Poster/Picon Transparency Color" , "VVf39W" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Help (Keys)"        , "help"     ))
  FFRHhp(self, self.VVGKJG, title=self.Title, VVhIDJ=VVhIDJ)
 def VVGKJG(self, item=None):
  if item is not None:
   if   item == "VVFqQ6"   : self.VVFqQ6()
   elif item == "VVNWAI"   : self.VVNWAI()
   elif item == "VVOyJK"  : self.VVOyJK()
   elif item == "VVOm14"  : FFuMBP(self, self.VVOm14, title="Calculating ...")
   elif item == "VVf39W": self.VVf39W()
   elif item == "help"     : FFYqxx(self, "_help_servBr", "Server Browser (Keys)")
 def VVYfT9(self):
  self.VVhqv2.VVj43f(self.curIndex)
  self.VVhqv2.VVpnjd()
 def VVrKHe(self):
  self.VVhqv2.VVj43f(self.curIndex)
  self.VVhqv2.VVHhJn()
 def VVOxcP(self):
  for colList in self.VVhqv2.VVOazu():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = self.VVsjY8(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVFWkP.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVFWkP)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVhqv2.VVHqmL()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVpbN4(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVwlhO)
  except:
   self.timer.callback.append(self.VVwlhO)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVMb7W)
  self.myThread.start()
 def VVsjY8(self, url):
  fName = os.path.basename(url)
  span = iSearch(r'(.+\.(?:png|jpg))', fName, IGNORECASE)
  return span.group(1) if span else fName
 def VVMb7W(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVFWkP):
    if not self.stopThread:
     if picUrl and not fName:
      fName = self.VVsjY8(picUrl)
      path, err = FFlHhH(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFcZm9("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVFWkP[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVwlhO(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVvrDy + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVFWkP[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVFWkP[ndx] = (chName, subj, desc, fName, "")
     CCQNdY.VVgw8m(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVVDMG(self):
  self.VV1OZ7()
  f1, f2 = self.VVxbir()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVFWkP[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVLpvH(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVobIL + "iptv.png"
   CCQNdY.VVgw8m(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVLYbr(self):
  chName, subj, desc, fName, picUrl = self.VVFWkP[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVFqQ6(self):
  chName, subj, desc, fName, picUrl = self.VVFWkP[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCuhvG.VVqol3(self, self.pPath + fName)
  else          : FFM3N1(self, "File not found", 1500)
 def VVNWAI(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVFWkP[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFcZm9("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFWB0Q(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFB8Nz(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFB8Nz(self, "No Poster/PIcon found", title=title)
 def VVOyJK(self):
  self.session.openWithCallback(self.VVhGXr, BF(CCf82q, patternMode="movies", VVQzCM=CFG.MovieDownloadPath.getValue()))
 def VVhGXr(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVFWkP[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFcZm9("cp -f '%s' '%s'" % (srcF, dstF)):
     FFWB0Q(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFB8Nz(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCr3DN.VVBA0d(dstF)
   else:
    FFB8Nz(self, "No Poster/PIcon found", title=title)
 def VVOm14(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVVcWE, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFkd4T("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCf82q.VVeeDD(size)
   txt += "%s\n    %s\n\n" % (FFwXwL(path, VVdVoc), size)
  mainPath = "%sPosters" % VVVcWE
  totFiles = FFkd4T("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFW43m(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFwXwL("Total space used by Posters/PIcons%s:" % totFTxt, VVqZDD), CCf82q.VVeeDD(totSize))
  mountPath = CCf82q.VVAl76(mainPath)
  if pathExists(mountPath):
   totSize  = CCf82q.VVb2sA(mountPath)
   freeSize = CCf82q.VVHPLs(mountPath)
   usedSize = CCf82q.VVeeDD(totSize - freeSize)
   totSize  = CCf82q.VVeeDD(totSize)
   freeSize = CCf82q.VVeeDD(freeSize)
   txt += "%s\n" % SEP
   txt += FFwXwL("Media Space:\n", VVHH6F)
   txt += "    Media Path\t: %s\n" % FFwXwL(mountPath, VVmvsU)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FF3nHt(self, txt, title="Cache Used Size", height=1000)
class CCr3DN(Screen, CCQNdY):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFMkht(VVMLDh, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVFWkP    = lst
  FFTlW1(self, self.Title)
  CCQNdY.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVYfT9    ,
   "cancel": self.close    ,
   "menu" : self.VVosnK ,
   "info" : self.VV5nKH  ,
   "0"  : self.VV7Bey
  })
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  FF3wB4(self)
  self.VVmqft()
  self.totalItems = len(self.VVFWkP)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVpbN4(True)
 def VVVDMG(self):
  self.VV1OZ7()
  f1, f2 = self.VVxbir()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVFWkP[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVobIL + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVLpvH(lbl, os.path.splitext(os.path.basename(path))[0])
   CCQNdY.VVgw8m(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV2HdD(self):
  path, movie, poster = self.VVFWkP[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVLYbr(self):
  path, poster = self.VV2HdD()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVosnK(self):
  path, poster = self.VV2HdD()
  VVhIDJ = []
  VVhIDJ.append(("Go to movie ...", "VVw3tS"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("Show Poster"      , "VVFqQ6" , poster))
  VVhIDJ.append(FFyXfa("Copy Poster to Export-Directory" , "VVNWAI", poster))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Poster/Picon Transparency Color"  , "VVf39W" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Poster (from current movie path) ..." , "VVVRXI1"  ))
  VVhIDJ.append(("Change Poster (locate manually) ..."   , "VVVRXI2"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Help (Keys)"         , "help"     ))
  FFRHhp(self, self.VVuoel, title=self.Title, VVhIDJ=VVhIDJ)
 def VVuoel(self, item=None):
  if item is not None:
   if   item == "VVw3tS"    : self.VVw3tS()
   elif item == "VVNWAI"    : self.VVNWAI()
   elif item == "VVFqQ6"    : self.VVFqQ6()
   elif item == "VVf39W" : self.VVf39W()
   elif item == "VVVRXI1"  : self.VVVRXI()
   elif item == "VVVRXI2"  : self.VVVRXI(True)
   elif item == "help"      : FFYqxx(self, "_help_movBr", "Movies Browser (Keys)")
 def VVw3tS(self):
  VVkNlM = []
  for ndx, item in enumerate(self.VVFWkP):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVkNlM.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVkNlM.sort(key=lambda x: x[0].lower())
  VVlUqf = ("Select" , self.VVWdMf, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFNCSP(self, None, title="Select Movie", width=1800, height=1000, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, lastFindConfigObj=CFG.lastFindMovie)
 def VVWdMf(self, VVhqv2, title, txt, colList):
  self.VVqlGr(int(colList[2].strip()))
  VVhqv2.cancel()
 def VVYfT9(self):
  path, poster = self.VV2HdD()
  FFuMBP(self, BF(CCf82q.VV8VtC, self, path), title="Playing Media ...")
 def VV5nKH(self):
  path, poster = self.VV2HdD()
  txt = "%s:\n%s\n\n" % (FFwXwL("Path", VVdVoc), path)
  size = FFoQQd(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFwXwL("File Size", VVdVoc), CCf82q.VVeeDD(size))
  if poster:
   txt += "%s:\n%s" % (FFwXwL("Poster", VVdVoc), poster)
  FF3nHt(self, txt, title="Media File Information")
 def VVFqQ6(self):
  path, poster = self.VV2HdD()
  if fileExists(poster): CCuhvG.VVqol3(self, poster)
  else     : FFM3N1(self, "No Poster", 1500)
 def VVNWAI(self):
  title = "Copy Poster"
  path, poster = self.VV2HdD()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFcZm9("cp -f '%s' '%s'" % (poster, dstF)):
    FFWB0Q(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFB8Nz(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFM3N1(self, "No Poster", 1500)
 def VVVRXI(self, isManual=False):
  path, poster = self.VV2HdD()
  sDir = FF77SS(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVLiC0, sDir, path), BF(CCf82q, patternMode="poster", VVQzCM=sDir))
  else:
   VVhIDJ = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVhIDJ.append((os.path.basename(item), sDir + item))
   if VVhIDJ:
    VVhIDJ.sort(key=lambda x: x[0].lower())
    VVW4TT = self.VVZjhN
    FFRHhp(self, BF(self.VVLiC0, sDir, path), VVhIDJ=VVhIDJ, title="Posters", VVW4TT=VVW4TT, VV8Vs4=sDir)
   else:
    FFM3N1(self, "No jpg/png in current dir", 1500)
 def VVZjhN(self, VVCarR, txt, ref, ndx):
  CCuhvG.VVqol3(self, VVmyei=ref)
 def VVLiC0(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFcZm9("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVFWkP[self.curIndex] = (self.VVFWkP[self.curIndex][0], self.VVFWkP[self.curIndex][1], os.path.basename(newPath))
    FFuMBP(self, self.VVVDMG)
    CCr3DN.VVBA0d(newPath)
   else:
    FFM3N1(self, "Cannot copy file", 1000)
 @staticmethod
 def VVBA0d(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFcZm9("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVYU0F(SELF):
  eLst = CCuvev.VVO8mQ()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCr3DN, title, lst)
  else  : FFB8Nz(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCO5EF(Screen, CCQNdY):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFMkht(VVKzh4, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVFWkP    = lst
  self.pPath    = CCTdjW.VVJwSu()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFTlW1(self, self.Title)
  FFMz2e(self["keyRed"] , "OK = Zap (Review)")
  FFMz2e(self["keyGreen"] , "Zap & Exit")
  FFMz2e(self["keyYellow"], "Find Current Service")
  CCQNdY.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVYthV, False),
   "cancel" : self.VVslRd      ,
   "menu"  : self.VV0Pq6   ,
   "red"  : self.VVslRd      ,
   "green"  : BF(self.VVYthV, True) ,
   "yellow" : BF(self.VVZp96, True)  ,
   "0"   : self.VV7Bey
  })
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFfgOw(self)
   FF3wB4(self)
   FFOrd9(self["keyRed"], "#0a333333")
   self.VVmqft()
  else:
   pName, srvLst = CCO5EF.VVgL9m()
   if srvLst and not srvLst == self.VVFWkP:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVFWkP = srvLst
   else:
    force = False
  self.totalItems = len(self.VVFWkP)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVpbN4(force)
  self.VVZp96()
 def VV0Pq6(self):
  VVhIDJ = []
  VVhIDJ.append(("Find Name (sorted list)" , "findSrt"  ))
  VVhIDJ.append(("Find Name (as listed)" , "findNoSrt"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Change Background Color" , "VVf39W"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Help (Keys)", "help"))
  FFRHhp(self, self.VVpfTa, title="Options", VVhIDJ=VVhIDJ)
 def VVpfTa(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVshnR(True)
   elif item == "findNoSrt"   : self.VVshnR(False)
   elif item == "VVf39W": self.VVf39W()
   elif item == "help"     : FFYqxx(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVshnR(self, isSort):
  VVhIDJ = []
  for ndx, item in enumerate(self.VVFWkP):
   VVhIDJ.append((item[1], ndx))
  if isSort:
   VVhIDJ.sort(key=lambda x: x[0].lower())
  FFRHhp(self, self.VVQKdJ, title="Find Name", VVhIDJ=VVhIDJ, width=1300)
 def VVQKdJ(self, ndx=None):
  if ndx is not None:
   self.VVqlGr(ndx)
 def VVslRd(self):
  if self.shown: self.close()
  else   : self.show()
 def VVYthV(self, isExit):
  FFuMBP(self, BF(self.VVn2Ms, isExit), title="Starting ...")
 def VVn2Ms(self, isExit):
  try:
   if self.shown:
    FFtU9E(self, self.VVFWkP[self.curIndex][0], VVpkYJ=False)
    if isExit: self.close()
    else  : CCqLbA.VVZoRN(self.session)
   else:
    self.show()
  except:
   pass
 def VVZp96(self, VVzp4h=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVFWkP):
    if curRef == item[0]:
     self.VVqlGr(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVzp4h and err:
   FFM3N1(self, err, 500)
  return -1
 def VVVDMG(self):
  self.VV1OZ7()
  f1, f2 = self.VVxbir()
  row = col = 0
  noPos = VVobIL + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVFWkP[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVLpvH(lbl, name)
   path = CCTdjW.VVofv1(self.pPath, ref, name) or noPos
   CCQNdY.VVgw8m(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVLYbr(self):
  ref, name = self.VVFWkP[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVavTn():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVOzoq = InfoBar.instance
  if VVOzoq:
   csel = VVOzoq.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFvBDy(rootRef)
    refName  = FFvBDy(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVgL9m(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCO5EF.VVavTn()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFxxyk(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCJEC1.VVbWPR()
   pName  = CCJEC1.VVk53P() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVwan4(SELF):
  pName, srvLst = CCO5EF.VVgL9m()
  if srvLst: SELF.session.open(CCO5EF, pName, srvLst)
  else  : FFB8Nz(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CC6KoU(Screen, CCQNdY):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFMkht(VVYPDO, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVFWkP    = CC6KoU.VVG7kp(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  self.firstTime   = True
  FFTlW1(self, self.Title)
  FFMz2e(self["keyRed"] , "Remove Plugins")
  FFMz2e(self["keyGreen"] , "Download New Plugins")
  FFMz2e(self["keyYellow"], "Package Info.")
  FFMz2e(self["keyBlue"] , "Plugins Group")
  CCQNdY.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVeSUQ   ,
   "cancel" : self.close    ,
   "menu"  : self.VV4J5Q ,
   "info"  : self.VVtpV8  ,
   "red"  : BF(self.VV9o3j, False)   ,
   "green"  : BF(self.VV9o3j, True)   ,
   "yellow" : BF(FFuMBP, self, self.VV0oXT),
   "blue"  : self.VVgmEe  ,
   "0"   : self.VV7Bey
  })
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  FF3wB4(self)
  self.VVmqft()
  self.VVQlZe()
 def VVQlZe(self):
  self.totalItems = len(self.VVFWkP)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVpbN4(True)
 def VVcVMD(self):
  lst = CC6KoU.VVRqyd(PluginDescriptor.WHERE_PLUGINMENU)
  if lst:
   lst = CC6KoU.VVG7kp(lst)
   if lst != self.VVFWkP:
    self.VVFWkP = lst
    self.VVQlZe()
  else:
   self.close()
 def VV9o3j(self, isInstall):
  FFM3N1(self, "Processing ...")
  try:
   from Screens.PluginBrowser import PluginDownloadBrowser as pb
   if isInstall:
    self.session.openWithCallback(self.VVcVMD, pb, pb.DOWNLOAD, self.firstTime)
    self.firstTime = False
   else:
    self.session.openWithCallback(self.VVcVMD, pb, pb.REMOVE)
  except:
   try:
    from Screens.PluginBrowser import PluginAction as pa
    self.session.openWithCallback(self.VVcVMD, pa, pa.DOWNLOAD if isInstall else pa.REMOVE)
   except:
    try:
     from Plugins.SystemPlugins.SoftwareManager.plugin import PluginManager as pb
     self.session.openWithCallback(self.VVcVMD, pb)
    except Exception as e:
     FFB8Nz(self, 'Cannot open "Extensions Management" !', title=self.Title)
  FFM3N1(self)
 def VVeSUQ(self):
  name, desc = self.VVSEMB(self.curIndex)
  if name == PLUGIN_NAME and "VViG77" in globals() and VViG77:
   FFM3N1(self, "Already running.", 500)
  else:
   try:
    p = self.VVFWkP[self.curIndex]
    p(session=self.session)
   except:
    FFB8Nz(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVtpV8(self):
  def VVnxYh(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVFWkP[self.curIndex]
  txt = ""
  try:
   txt += VVnxYh("Path"  , p.path  )
   txt += VVnxYh("Description" , p.description )
   txt += VVnxYh("Icon"  , p.iconstr  )
   txt += VVnxYh("Wakeup Fnc" , p.wakeupfnc )
   txt += VVnxYh("NeedsRestart", p.needsRestart)
   txt += VVnxYh("Internal" , p.internal )
   txt += VVnxYh("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVSEMB(self.curIndex)
  if txt : FF3nHt(self, txt, title=name)
  else : FFB8Nz(self, "Could not read plugin info.", title=name)
 def VV0oXT(self):
  p = self.VVFWkP[self.curIndex]
  name, desc = self.VVSEMB(self.curIndex)
  path = p.path
  pkg, err = CCxLZd.VVuX2k(path)
  if pkg : CCxLZd.VVfqcr(self, pkg, name)
  else : FFkqUz(self, err, 1000)
 def VV4J5Q(self):
  path = self.VVFWkP[self.curIndex].path
  VVhIDJ = []
  txt = "Open Plugin Path in File Manager"
  VVhIDJ.append(FFyXfa("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Use Original Icon Size", "setOrigSize"))
  FFRHhp(self, self.VV6ejj, title="Plugins Group", VVhIDJ=VVhIDJ)
 def VV6ejj(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCf82q, mode=CCf82q.VVfI6P, VVQzCM=self.VVFWkP[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVpbN4(True)
 def VVgmEe(self):
  FFRHhp(self, self.VVhBrs, title="Plugins Group", VVhIDJ=CC6KoU.VVa1dv(True, True), width=700, VVWLSA=True)
 def VVhBrs(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CC6KoU.VVRqyd(where)
   if lst:
    self.VVFWkP = CC6KoU.VVG7kp(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVFWkP)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVpbN4(True)
   else:
    FFB8Nz(self, "Not found !", title=self.Title)
 def VVVDMG(self):
  self.VV1OZ7()
  f1, f2 = self.VVxbir()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVSEMB(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVLpvH(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVFWkP[ndx].icon:
    try:
     pngSz = self.VVFWkP[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVFWkP[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVFWkP[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVobIL + "plugin.png")
    for path in icons:
     pixMap = CCQNdY.VVgw8m(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVSEMB(self, ndx):
  name = str(self.VVFWkP[ndx].name).strip()
  desc = str(self.VVFWkP[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFtnj1(self.VVFWkP[ndx].path)
  return name, desc
 def VVLYbr(self):
  name, desc = self.VVSEMB(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVa1dv(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CC6KoU.VVRqyd(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVlrJC, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVuAtK)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVRqyd(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVG7kp(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFtnj1(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVHYF2(session):
  title = "Plugins Browser"
  lst = CC6KoU.VVRqyd(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : session.open(CC6KoU, title, lst)
  else : FFQhlG(session, "No plugins found !", title=title)
class CCb8LV(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFMkht(VV35C4, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VV0m7n  = 0
  self.VVIZkW = 1
  self.VVoBlj  = 2
  VVhIDJ = []
  VVhIDJ.append(("Find in All Service (from filter)" , "VVSx9z" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Find in All (Manual Entry)"   , "VVhTjd"    ))
  VVhIDJ.append(("Find in TV"       , "VVc1nP"    ))
  VVhIDJ.append(("Find in Radio"      , "VVUjDH"   ))
  if self.VVKVZ0():
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Hide Channel: %s" % self.servName , "VVU9Gx"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Zap History"       , "VV7tYv"    ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("IPTV Tools"       , "iptv"      ))
  VVhIDJ.append(("PIcons Tools"       , "PIconsTools"     ))
  VVhIDJ.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVhIDJ.append(("EPG Tools"       , "epgTools"     ))
  FFTlW1(self, VVhIDJ=VVhIDJ, title=title)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self)
  if self.isFindMode:
   self.VVyXYr(self.VVAI5q())
 def VVYfT9(self):
  global VVEQ0S
  VVEQ0S = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVhTjd"    : self.VVhTjd()
   elif item == "VVSx9z" : self.VVSx9z()
   elif item == "VVc1nP"    : self.VVc1nP()
   elif item == "VVUjDH"   : self.VVUjDH()
   elif item == "VVU9Gx"   : self.VVU9Gx()
   elif item == "VV7tYv"    : self.VV7tYv()
   elif item == "iptv"       : self.session.open(CC8Yh1)
   elif item == "PIconsTools"     : self.session.open(CCTdjW)
   elif item == "ChannelsTools"    : self.session.open(CCn3v3)
   elif item == "epgTools"      : self.session.open(CCwOKQ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVc1nP(self) : self.VVyXYr(self.VV0m7n)
 def VVUjDH(self) : self.VVyXYr(self.VVIZkW)
 def VVhTjd(self) : self.VVyXYr(self.VVoBlj)
 def VVyXYr(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFs37j(self, BF(self.VVLeZE, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVSx9z(self):
  filterObj = CCf604(self)
  filterObj.VV98nA(self.VV187S)
 def VV187S(self, item):
  self.VVLeZE(self.VVoBlj, item)
 def VVKVZ0(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFrhBg(self.refCode)        : return False
  return True
 def VVLeZE(self, mode, VVQEL1):
  FFuMBP(self, BF(self.VV38tg, mode, VVQEL1), title="Searching ...")
 def VV38tg(self, mode, VVQEL1):
  if VVQEL1:
   VVQEL1 = VVQEL1.strip()
  if VVQEL1:
   self.findTxt = VVQEL1
   CFG.lastFindContextFind.setValue(VVQEL1)
   if   mode == self.VV0m7n  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVIZkW : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVQEL1)
   if len(title) > 55:
    title = title[:55] + ".."
   VVkNlM = self.VVKWhy(VVQEL1, servTypes)
   if self.isFindMode or mode == self.VVoBlj:
    VVkNlM += self.VVHUsx(VVQEL1)
   if VVkNlM:
    VVkNlM.sort(key=lambda x: x[0].lower())
    VVPEsb = self.VVzGDm
    VVlUqf  = ("Zap"   , self.VVnxTZ    , [])
    VVlrMb = ("Current Service", self.VVHlEV , [])
    VVkGmL = ("Options"  , self.VVjk5V , [])
    VVJEWY = (""    , self.VV0lWW , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVrLHE  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VVJEWY=VVJEWY, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVyXYr(self.VVAI5q())
    FFWB0Q(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVKWhy(self, VVQEL1, servTypes):
  VVFWkP = CCn3v3.VVW9Ct(servTypes)
  VVkNlM = []
  if VVFWkP:
   VVlyQB, VV2HRF = FFXAmG()
   tp = CCpNxn()
   words, asPrefix = CCf604.VV7zA4(VVQEL1)
   colorYellow  = CCbkDP.VVhXkO(VVqZDD)
   colorWhite  = CCbkDP.VVhXkO(VViVXH)
   for s in VVFWkP:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFeI49(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVlyQB:
        STYPE = VV2HRF[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVeuXj(refCode)
       if not "-S" in syst:
        sat = syst
       VVkNlM.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVkNlM
 def VVHUsx(self, VVQEL1):
  VVQEL1 = VVQEL1.lower()
  VVkNlM = []
  colorYellow  = CCbkDP.VVhXkO(VVqZDD)
  colorWhite  = CCbkDP.VVhXkO(VViVXH)
  for b in CCJEC1.VVuK6D():
   VVCJZW  = b[0]
   VVxCZh  = b[1].toString()
   VVQd8W = eServiceReference(VVxCZh)
   VVibol = FFxxyk(VVQd8W)
   for service in VVibol:
    refCode  = service[0]
    if FFrhBg(refCode):
     servName = service[1]
     if VVQEL1 in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVQEL1), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVkNlM.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVkNlM
 def VVAI5q(self):
  mode = CCod57.VVXj2B(default=-1)
  return self.VVoBlj if mode == -1 else mode
 def VVzGDm(self, VVhqv2):
  self.close()
  VVhqv2.cancel()
 def VVnxTZ(self, VVhqv2, title, txt, colList):
  FFtU9E(VVhqv2, colList[2], VVpkYJ=False, checkParentalControl=True)
 def VVHlEV(self, VVhqv2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(VVhqv2)
  if refCode:
   VVhqv2.VV3g7B(2, FFoeJu(refCode, iptvRef, chName), True)
 def VVjk5V(self, VVhqv2, title, txt, colList):
  servName = colList[0]
  mSel = CCr5W8(self, VVhqv2)
  VVhIDJ, cbFncDict = CCn3v3.VVXkrh(self, VVhqv2, servName, 2)
  mSel.VVklJK(VVhIDJ, cbFncDict)
 def VV0lWW(self, VVhqv2, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFcAqb(self, fncMode=CCscAN.VVFOvX, refCode=refCode, chName=chName, text=txt)
 def VVU9Gx(self):
  FF5jVY(self, self.VV8tMQ, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV8tMQ(self):
  ret = FFuH1v(self.refCode, True)
  if ret:
   self.VVOktB()
   self.close()
  else:
   FFM3N1(self, "Cannot change state" , 1000)
 def VVOktB(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVDKXb()
  except:
   self.VV4Kao()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFFprm(self, serviceRef)
 def VVDKXb(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVOzoq = InfoBar.instance
   if VVOzoq:
    VVJK1Q = VVOzoq.servicelist
    if VVJK1Q:
     hList = VVJK1Q.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVJK1Q.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVJK1Q.history  = newList
       VVJK1Q.history_pos = pos
 def VV4Kao(self):
  VVOzoq = InfoBar.instance
  if VVOzoq:
   VVJK1Q = VVOzoq.servicelist
   if VVJK1Q:
    VVJK1Q.history  = []
    VVJK1Q.history_pos = 0
 def VV7tYv(self):
  VVOzoq = InfoBar.instance
  VVkNlM = []
  if VVOzoq:
   VVJK1Q = VVOzoq.servicelist
   if VVJK1Q:
    VVlyQB, VV2HRF = FFXAmG()
    for serv in VVJK1Q.history:
     refCode = serv[-1].toString()
     chName = FFvBDy(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFrhBg(refCode)
     isSRel = FFzL2x(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFeI49(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVlyQB:
       STYPE = VV2HRF[sTypeInt]
     VVkNlM.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVkNlM:
   VVlUqf  = ("Zap"   , self.VV0jfu   , [])
   VVkGmL = ("Clear History" , self.VVAHUQ   , [])
   VVJEWY = (""    , self.VV2XQJ , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVrLHE  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVlUqf=VVlUqf, VVkGmL=VVkGmL, VVJEWY=VVJEWY)
  else:
   FFWB0Q(self, "History is empty.", title=title)
 def VV0jfu(self, VVhqv2, title, txt, colList):
  FFtU9E(VVhqv2, colList[3], VVpkYJ=False, checkParentalControl=True)
 def VVAHUQ(self, VVhqv2, title, txt, colList):
  FF5jVY(self, BF(self.VVjoA1, VVhqv2), "Clear Zap History ?")
 def VVjoA1(self, VVhqv2):
  self.VV4Kao()
  VVhqv2.cancel()
 def VV2XQJ(self, VVhqv2, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFcAqb(self, fncMode=CCscAN.VV1VYQ, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVxgPn():
  try:
   global VVyzBk
   if VVyzBk is None:
    VVyzBk    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCb8LV.VVyhMr
   ChannelContextMenu.VViFbp = CCb8LV.VViFbp
  except:
   pass
 @staticmethod
 def VVyhMr(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVyzBk(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VViFbp, csel, ndx, title))))
 @staticmethod
 def VViFbp(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFvBDy(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCO5EF.VVwan4(SELF)
  elif mode == 2: SELF.session.open(CCod57)
  else    : SELF.session.open(CCb8LV, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCod57(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFMkht(VVDkmp, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCTdjW.VVJwSu()
  self.bTables = []
  FFTlW1(self)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.VVoXkr()
 def VVMuT3(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
  self.VVLqTu(tbl)
 def VVoXkr(self):
  rootStr = CCod57.VVKN9L()
  rows = self.VVMrJG(rootStr)
  if rows :
   self.VVdUmC(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCO5EF.VVavTn()
   if not self.bTables[-1].VVTlR4({3:refCode}):
    self.bTables[-1].VVTlR4({3:rootRef})
  else:
   FFB8Nz(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVVH55(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVMrJG(self, bRef=None):
  blkLst = CCod57.VVN8ig()
  rows = []
  for ndx, row in enumerate(FFxxyk(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCod57.VV6CNx(flags)
   lck = "1" if CCod57.VVVZj2(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVdUmC(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FFwXwL("Fav: ", VVlrJC), bName), 2:"%s %s" % (FFwXwL("Sub: ", VVlrJC), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVPEsb = self.VVx8u4
  VVJEWY = (""     , self.VVWFjx   , [])
  VVlUqf  = ("Enter Bouquet"  , self.VVKYHu  , [])
  VVlpv3 = ("Delete"    , self.VVNGu3  , [])
  VVlrMb = ("Bouquets Importer" , self.VVALB0 , [])
  VVkGmL = ("Options"   , self.VV22kS  , [])
  VV1FeB = ("Move Here"   , self.VVyPQy  , [])
  picParams  = (1, self.VVgIQz, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVrLHE = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFNCSP(self, None, title=title, VVFWkP=rows, VVrLHE=VVrLHE, width=1500, height=1000, VVN1SU=widths, VVNWWl=28, addSort=False, VVJEWY=VVJEWY, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVJcAk=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#0a442200", borderWidth=0, VVRt6l="#11330000")
  tbl.VVAuRJ(BF(self.VVnnsl, tbl), True)
  self.VVMuT3(tbl, bName, bRef)
 def VVMKGR(self, VVhqv2, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFBOOj()
   rows = self.VVMrJG(VVhqv2.bouqRef)
   if rows:
    VVhqv2.VVAHRi(False)
    VVhqv2.VVartp(rows, VVEO5wMsg=True, isSort=False, tableRefreshCB=BF(self.VVu8e0, jumpDict))
   else:
    self.VVVH55()
    totTbl = len(self.bTables)
    FFM3N1(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFkqUz(VVhqv2, "No change !", 1500)
 def VVu8e0(self, jumpDict, VVhqv2, title, txt, colList):
  if jumpDict:
   VVhqv2.VVTlR4(jumpDict)
 def VVnnsl(self, VVhqv2):
  VVhqv2["keyRed"].hide()
  VVhqv2["keyBlue"].hide()
  if VVhqv2.VVVoic:
   if VVhqv2.VVv2WG() > 0:
    VVhqv2["keyRed"].show()
    VVhqv2["keyBlue"].show()
  else:
   VVhqv2["keyRed"].show()
  self.VVLqTu(VVhqv2)
 def VVLqTu(self, VVhqv2):
  if len(self.bTables) == 1 and not VVhqv2.VVNb4j():
   VVhqv2.VV7m1I()
  else:
   VVhqv2.VVFwsu()
 def VVWFjx(self, VVhqv2, title, txt, colList):
  c1, c2, c3 = VVqZDD, VVEhqe, VVdSiQ
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FFwXwL(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCod57.VV2uUY(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVhqv2.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCod57.VV2uUY(VVhqv2.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVT9SH else ""
  txt += ttl("Remarks"   , rem, c3) if VVT9SH else ""
  path = CCTdjW.VVofv1(self.pPath, ref, name)
  FFcAqb(self, fncMode=CCscAN.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVKYHu(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VV91kV, VVhqv2, colList) )
 def VV91kV(self, VVhqv2, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if FFf209(ref):
   if len(self.bTables) <= maxLev:
    rows = self.VVMrJG(ref)
    if rows : self.VVdUmC(VVhqv2, name, ref, rows)
    else : FFkqUz(VVhqv2, "Empty list !", 1500)
   else:
    FFB8Nz(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCod57.VVlRLh(ref) == 0:
   FFtU9E(self, ref, VVpkYJ=False)
   FFrf5q(self, "Cancel to go back to table")
  else:
   FFM3N1(VVhqv2, "No action", 300)
 def VVx8u4(self, VVhqv2):
  if VVhqv2.VVVoic:
   VVhqv2.VVAHRi(False)
   self.VVnnsl(VVhqv2)
  else:
   self.VVVH55()
 def VV22kS(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  iMulSel = VVhqv2.VVNb4j()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVhqv2.VVv2WG()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFW43m(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  okToMain = False
  if not inMain:
   for ref in self.VV0Wh1(VVhqv2):
    if not FFf209(ref) and not ref.startswith("1:64:"): break
   else:
    okToMain = True
  totDel = len(self.VV2YTW())
  c1, c2, c3, c4 = VVEhqe, VVuj5g, VVdVoc, VVdSiQ
  VVhIDJ.append(FFyXfa("Rename"   , "renm" , not iMulSel, c1))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(FFyXfa("Add Marker"  , "mrkr" , not iMulSel, c2))
  VVhIDJ.append(FFyXfa("Add Empty Bouquet", "addBouq" , not iMulSel and inMain, c2))
  if totDel:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((c4 + 'Delete %d Unused ".del" Bouquets File%s' % (totDel, FFW43m(totDel)), "unused"))
  if inMain:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(FFyXfa("Hide %s" % bTxt , "hidOn" , isSel, c3))
   VVhIDJ.append(FFyXfa("Unhide %s" % bTxt , "hidOff" , isSel, c3))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(FFyXfa("Protect %s" % bTxt , "lckOn" , isSel, c3))
   VVhIDJ.append(FFyXfa("Unprotect %s" % bTxt , "lckOff" , isSel, c3))
   VVl9AY, VVLICL = "#22001122", "#22000a15"
  else:
   VVl9AY, VVLICL = "#2200120a", "#2200120a"
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(sortItem)
  VVhIDJ.append(FFyXfa("Copy to Main Bouquets List" , "toMain", okToMain))
  VVhIDJ.append(FFyXfa("Copy to a Bouquet"   , "toBouq", isSel))
  cbFncDict = { "renm" : BF(self.VVderJ  , VVhqv2)
     , "mrkr" : BF(self.VViPqa , VVhqv2)
     , "addBouq" : BF(self.VV9KU4, VVhqv2)
     , "unused" : BF(self.VVTXNs , VVhqv2)
     , "hidOn" : BF(self.VVCcou  , VVhqv2, True)
     , "hidOff" : BF(self.VVCcou  , VVhqv2, False)
     , "lckOn" : BF(self.VVebM6  , VVhqv2, True)
     , "lckOff" : BF(self.VVebM6  , VVhqv2, False)
     , "sort" : BF(self.VVHodO  , VVhqv2)
     , "toMain" : BF(self.VVZ2i7 , VVhqv2)
     , "toBouq" : BF(self.VVIzzc , VVhqv2) }
  fnc = BF(self.VVnnsl, VVhqv2)
  mSel = CCr5W8(self, VVhqv2)
  mSel.VVklJK(VVhIDJ, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc, height=1000, VVl9AY=VVl9AY, VVLICL=VVLICL)
 def VVNGu3(self, VVhqv2, title, txt, colList):
  txt, totSel = "", 0
  if VVhqv2.VVNb4j():
   totSel = VVhqv2.VVv2WG()
   if totSel:
    txt = "Delete %s item%s" % (FFwXwL(str(totSel), VVqZDD), FFW43m(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FFwXwL(name, VVqZDD)
  if txt:
   FF5jVY(self, BF(self.VVbUlz, VVhqv2), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVALB0(self, VVhqv2, title, txt, colList):
  CChSGV.VVb5WS(self, cbFnc=BF(self.VVqdiq, VVhqv2))
 def VVqdiq(self, VVhqv2):
  self.VVMKGR(VVhqv2, None, 1)
 def VVbUlz(self, VVhqv2):
  FFuMBP(VVhqv2, BF(self.VVh2yi, VVhqv2))
 def VVh2yi(self, VVhqv2):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCJEC1.VVmvex(ref)
     if bFile:
      bFile = VVSs5p + bFile
      FFcZm9("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VVMKGR(VVhqv2, mutableList, tot)
 def VVyPQy(self, VVhqv2, title, txt, colList):
  FFuMBP(VVhqv2, BF(self.VVdYeG, VVhqv2))
 def VVdYeG(self, VVhqv2):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  if mutableList is not None:
   curNdx = VVhqv2.VVHqmL()
   if curNdx <= VVhqv2.VV3nbn(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVMKGR(VVhqv2, mutableList, tot)
 def VVHodO(self, VVhqv2):
  FFuMBP(VVhqv2, BF(self.VVJGDk, VVhqv2))
 def VVJGDk(self, VVhqv2):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  if mutableList is not None:
   nmlst = VVhqv2.VVeAfz(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVhqv2.VV3nbn()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVMKGR(VVhqv2, mutableList, tot)
 def VVderJ(self, VVhqv2, item=None):
  name = VVhqv2.VVHMjy()[2]
  FFs37j(self, BF(self.VVKRzb, VVhqv2), defaultText=name, title="Rename", message="Enter new name")
 def VVKRzb(self, VVhqv2, name):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVhqv2.VVHMjy()[3]
    if FFf209(ref):
     CCJEC1.VVRRmT(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVhqv2.VVHqmL())
    self.VVMKGR(VVhqv2, mutableList, 1)
 def VViPqa(self, VVhqv2):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFuMBP(VVhqv2, BF(self.VVEyuP, VVhqv2, name))
 def VVEyuP(self, VVhqv2, name):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  if mutableList is not None:
   curServ = eServiceReference(VVhqv2.VVHMjy()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VVMKGR(VVhqv2, mutableList, tot)
 def VV9KU4(self, VVhqv2):
  names = VVhqv2.VVyaay(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFs37j(self, BF(self.VV5KaL, VVhqv2), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VV5KaL(self, VVhqv2, name=None):
  if name and name.strip():
   FFuMBP(VVhqv2, BF(self.VVRXXP, VVhqv2, name.strip()))
 def VVRXXP(self, VVhqv2, bName):
  CCJEC1.VVLw9b(bName)
  self.VVMKGR(VVhqv2, None, 1, jumpDict={2:bName})
 def VV2YTW(self):
  lst = []
  for fil in os.listdir(VVSs5p):
   if fil.endswith(".tv.del") or fil.endswith(".radio.del"):
    lst.append(fil)
  return lst
 def VVTXNs(self, VVhqv2):
  lst = self.VV2YTW()
  for fil in lst:
   FFZ5Mj(VVSs5p + fil)
  VVhqv2.VVomXH("Done")
 def VV0Wh1(self, VVhqv2):
  if VVhqv2.VVVoic : return VVhqv2.VVeAfz(3)
  else        : return [VVhqv2.VVHMjy()[3]]
 def VVZ2i7(self, VVhqv2):
  dstFile = "bouquets.%s" % ("tv" if CCod57.VVXj2B() == 0 else "radio")
  FFuMBP(VVhqv2, BF(self.VVHzRH, VVhqv2, "Main Bouquets List", dstFile, True))
 def VVIzzc(self, VVhqv2):
  bRows = CCJEC1.VVukZQ()
  lst = self.VV0Wh1(VVhqv2)
  VVhIDJ = []
  for name, ref in bRows:
   if not ref in lst:
    VVhIDJ.append((name, ref))
  if VVhIDJ : FFRHhp(self,  BF(self.VVa1GY, VVhqv2), VVhIDJ=VVhIDJ, width=1100, height=900, VVl9AY="#22220000", VVLICL="#22110000", title="Destination Bouquet", VVWLSA=True)
  else  : FFM3N1(VVhqv2, "No bouquets left !", 1000)
 def VVa1GY(self, VVhqv2, item=None):
  if item:
   bName, bRef, ndx = item
   dstFile = CCJEC1.VVmvex(bRef)
   FFuMBP(VVhqv2, BF(self.VVHzRH, VVhqv2, bName, dstFile))
 def VVHzRH(self, VVhqv2, bName, dstFile, mainToo=False):
  lst = self.VV0Wh1(VVhqv2)
  tot = 0
  for ref in lst:
   ok = CCJEC1.VV5654(ref, dstFile)
   if ok:
    tot += 1
  self.VVMKGR(VVhqv2, None, tot)
  if mainToo:
   rootStr = CCod57.VVKN9L()
   rows = self.VVMrJG(rootStr)
   self.bTables[0].VVartp(rows, VVEO5wMsg=True)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFwXwL(x, VVdVoc), y)
  txt  = ttl("Source Bouquet"  , VVhqv2.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FF3nHt(VVhqv2, txt, title="Copy Services")
 def VVCcou(self, VVhqv2, isHide):
  FFuMBP(VVhqv2, BF(self.VVPULL, VVhqv2, isHide))
 def VVPULL(self, VVhqv2, isHide):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  mode = CCod57.VVXj2B()
  path = VVSs5p + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF9z80(path)))
   for ref in lst:
    if FFf209(ref):
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VVMKGR(VVhqv2, None, tot)
 def VVebM6(self, VVhqv2, isLck):
  FFuMBP(VVhqv2, BF(self.VVZTfW, VVhqv2, isLck))
 def VVZTfW(self, VVhqv2, isLck):
  lst, mutableList, csel, bServ = self.VVKX73(VVhqv2)
  blkLst = CCod57.VVN8ig()
  tot = 0
  for ref in lst:
   if FFf209(ref):
    ndx = CCod57.VVVZj2(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VVrsN0, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VVMKGR(VVhqv2, None, tot)
 def VVKX73(self, VVhqv2, bServ=None):
  lst = self.VV0Wh1(VVhqv2)
  mutableList = csel = None
  VVOzoq = InfoBar.instance
  if VVOzoq:
   csel = VVOzoq.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVhqv2.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVgIQz(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VVobIL, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif FFf209(ref):
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCTdjW.VVofv1(self.pPath, ref, name)
 @staticmethod
 def VV6CNx(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.isNumberedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VV2uUY(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVT9SH:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVSs5p + span.group(1)
  return path
 @staticmethod
 def VVlRLh(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVXj2B(default=0):
  VVOzoq = InfoBar.instance
  if VVOzoq:
   csel = VVOzoq.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVKN9L():
  VVOzoq = InfoBar.instance
  if VVOzoq:
   csel = VVOzoq.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVN8ig():
  return FF9z80(VVrsN0) if fileExists(VVrsN0) else []
 @staticmethod
 def VVVZj2(ref, lst=None):
  if not lst:
   lst = CCod57.VVN8ig()
  if FFf209(ref):
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCTdjW(Screen, CCQNdY, CC2c5I):
 VVWMbV   = 0
 VVCSf4  = 1
 VVgCPX  = 2
 VVtGTA  = 3
 VVxz5O  = 4
 VV9BWp  = 5
 VVeuMG  = 6
 VVt9C0  = 7
 VVVMgA = 8
 VVhm1s = 9
 VVdrf6 = 10
 VVL3LE = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VVpmGw, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCTdjW.VVJwSu()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVFWkP    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFTlW1(self, self.Title)
  FFMz2e(self["keyRed"] , "OK = Zap")
  FFMz2e(self["keyGreen"] , "Current Service")
  FFMz2e(self["keyYellow"], "Page Options")
  FFMz2e(self["keyBlue"] , "Filter")
  CCQNdY.__init__(self, 5, 7, CFG.transpColorPicons)
  CC2c5I.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVXq2u     ,
   "green"  : self.VVLm2w    ,
   "yellow" : self.VVk0Pj     ,
   "blue"  : self.VVoLUB     ,
   "menu"  : self.VVHNtC     ,
   "info"  : self.VVruuS    ,
   "pageUp" : BF(self.VVxwiv, True) ,
   "chanUp" : BF(self.VVxwiv, True) ,
   "pageDown" : BF(self.VVxwiv, False) ,
   "chanDown" : BF(self.VVxwiv, False) ,
   "0"   : self.VV7Bey  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  FF3wB4(self)
  FFOrd9(self["keyRed"], "#0a333333")
  self.VVmqft()
  FFuMBP(self, BF(self.VVqhzF, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVHNtC(self):
  if not self.isBusy:
   VVhIDJ = []
   VVhIDJ.append(("Statistics"           , "VVZI42"    ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Suggest PIcons for Current Channel"     , "VVOifa"   ))
   VVhIDJ.append(("Set to Current Channel (copy file)"     , "VVOXY4_file"  ))
   VVhIDJ.append(("Set to Current Channel (as SymLink)"     , "VVOXY4_link"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Export Current File Names List"      , "VVM15C" ))
   VVhIDJ.append(CCTdjW.VVAH5i())
   VVhIDJ.append(VVuAtK)
   c, cond = VVeCLm, self.filterTitle == "PIcons without Channels"
   VVhIDJ.append(FFyXfa("Move Unused PIcons to a Directory", "VVf1CP" , cond, c))
   VVhIDJ.append(FFyXfa("DELETE Unused PIcons"    , "VVYM9V" , cond, c))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VViWld"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ += CCTdjW.VVe7Kq()
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Change Poster/Picon Transparency Color"    , "VVf39W" ))
   VVhIDJ.append(("Keys Help"           , "VVfTLh"    ))
   FFRHhp(self, self.VVE2L9, width=1100, height=1050, title=self.Title, VVhIDJ=VVhIDJ)
 def VVE2L9(self, item=None):
  if item is not None:
   if   item == "VVZI42"    : self.VVZI42()
   elif item == "VVOifa"   : self.VVOifa()
   elif item == "VVOXY4_file"  : self.VVOXY4(0)
   elif item == "VVOXY4_link"  : self.VVOXY4(1)
   elif item == "VVM15C"  : self.VVM15C()
   elif item == "VVTELK"  : CCTdjW.VVTELK(self)
   elif item == "VVf1CP"   : self.VVf1CP()
   elif item == "VVYM9V"  : self.VVYM9V()
   elif item == "VViWld"  : self.VViWld()
   elif item == "VVUCmM"  : CCTdjW.VVUCmM(self)
   elif item == "findPiconBrokenSymLinks" : CCTdjW.VVFpAj(self, True)
   elif item == "FindAllBrokenSymLinks" : CCTdjW.VVFpAj(self, False)
   elif item == "VVf39W" : self.VVf39W()
   elif item == "VVfTLh"     : FFYqxx(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVk0Pj(self):
  if not self.isBusy:
   VVhIDJ = []
   VVhIDJ.append(("Go to First PIcon"  , "VVlhUf"  ))
   VVhIDJ.append(("Go to Last PIcon"   , "VVSxFN"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Sort by Channel Name"     , "sortByChan" ))
   VVhIDJ.append(("Sort by File Name"  , "sortByFile" ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Find from File List .." , "VVtktR" ))
   FFRHhp(self, self.VVqZrd, title=self.Title, VVhIDJ=VVhIDJ)
 def VVqZrd(self, item=None):
  if item is not None:
   if   item == "VVlhUf"   : self.VVlhUf()
   elif item == "VVSxFN"   : self.VVSxFN()
   elif item == "sortByChan"  : self.VVDU5g(2)
   elif item == "sortByFile"  : self.VVDU5g(0)
   elif item == "VVtktR"  : self.VVtktR()
 def VVtktR(self):
  VVhIDJ = []
  for item in self.VVFWkP:
   VVhIDJ.append((item[0], item[0]))
  FFRHhp(self, self.VVIwNb, title='PIcons ".png" Files', VVhIDJ=VVhIDJ, VVWLSA=True)
 def VVIwNb(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVqlGr(ndx)
 def VVXq2u(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVKhUT()
   if refCode:
    FFtU9E(self, refCode)
    self.VVSj7M()
    self.VVLYbr()
 def VVxwiv(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVSj7M()
   self.VVLYbr()
  except:
   pass
 def VVLm2w(self):
  if self["keyGreen"].getVisible():
   self.VVqlGr(self.curChanIndex)
 def VVDU5g(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFuMBP(self, BF(self.VVqhzF, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVOXY4(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVKhUT()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVhIDJ = []
     VVhIDJ.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVhIDJ.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFRHhp(self, BF(self.VVsKzn, mode, curChF, selPiconF), VVhIDJ=VVhIDJ, title="Current Channel PIcon (already exists)")
    else:
     self.VVsKzn(mode, curChF, selPiconF, "overwrite")
   else:
    FFB8Nz(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFB8Nz(self, "Could not read current channel info. !", title=title)
 def VVsKzn(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFcZm9(cmd)
   FFuMBP(self, BF(self.VVqhzF, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVf1CP(self):
  defDir = FF77SS(CCTdjW.VVJwSu() + "picons_backup")
  FFcZm9("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVo8FH, defDir), BF(CCf82q
         , mode=CCf82q.VVa1qF, VVQzCM=CCTdjW.VVJwSu()))
 def VVo8FH(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCTdjW.VVJwSu():
    FFB8Nz(self, "Cannot move to same directory !", title=title)
   else:
    if not FF77SS(path) == FF77SS(defDir):
     self.VVuYvp(defDir)
    FF5jVY(self, BF(FFuMBP, self, BF(self.VVw7o5, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVFWkP), path), title=title)
  else:
   self.VVuYvp(defDir)
 def VVw7o5(self, title, defDir, toPath):
  if not iMove:
   self.VVuYvp(defDir)
   FFB8Nz(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF77SS(toPath)
  pPath = CCTdjW.VVJwSu()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVFWkP:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVFWkP)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF3nHt(self, txt, title=title, VVHZxf="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVRPyP("all")
 def VVuYvp(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVYM9V(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVFWkP)
  FF5jVY(self, BF(FFuMBP, self, BF(self.VVciRA, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFW43m(tot)), title=title)
 def VVciRA(self, title):
  pPath = CCTdjW.VVJwSu()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVFWkP:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVFWkP)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFwXwL(str(totErr), VVdSiQ)
  FF3nHt(self, txt, title=title)
 def VViWld(self):
  lines = FFpNiE("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FF5jVY(self, BF(self.VVXFOS, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFW43m(tot)), VVQk5i=True)
  else:
   FFWB0Q(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVXFOS(self, fList):
  FFcZm9("find -L '%s' -type l -delete" % self.pPath)
  FFWB0Q(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVruuS(self):
  FFuMBP(self, self.VVJPNg)
 def VVJPNg(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVKhUT()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFwXwL("PIcon Directory:\n", VVEhqe)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF851E(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF851E(path)
   txt += FFwXwL("PIcon File:\n", VVEhqe)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFwXwL("Found %d SymLink%s to this file from:\n" % (tot, FFW43m(tot)), VVEhqe)
     for fPath in slLst:
      txt += "  %s\n" % FFwXwL(fPath, VVlrJC)
     txt += "\n"
   if chName:
    txt += FFwXwL("Channel:\n", VVEhqe)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFwXwL(chName, VVfPTB)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFwXwL("Remarks:\n", VVEhqe)
    txt += "  %s\n" % FFwXwL("Unused", VVdSiQ)
  else:
   txt = "No info found"
  FFcAqb(self, fncMode=CCscAN.VVcZ3A, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVKhUT(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVFWkP[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFPrtr(sat)
  return fName, refCode, chName, sat, inDB
 def VVSj7M(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVFWkP):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVLYbr(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVKhUT()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFwXwL("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVEhqe))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVKhUT()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFzL2x(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFwXwL(self.curChanName, VVqZDD)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVKhUT()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVZI42(self):
  VVlyQB, VV2HRF = FFXAmG()
  sTypeNameDict = {}
  for key, val in VV2HRF.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVFWkP:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VV2HRF: sTypeDict[VV2HRF[stNum]] = sTypeDict.get(VV2HRF[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFkd4T("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVkNlM = []
  c = "#b#11003333#"
  VVkNlM.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVkNlM.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVkNlM.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVkNlM.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVkNlM.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVkNlM.append((c + "Satellites"    , str(len(self.nsList))))
  VVkNlM.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVkNlM.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVkNlM.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVkNlM.extend(sTypeRows)
  FFNCSP(self, None, title=self.Title, VVFWkP=VVkNlM, VVNWWl=28, VVSzMt="#00003333", VVvy9F="#00222222")
 def VVM15C(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF77SS(CFG.exportedTablesPath.getValue()), txt, FFERmH())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVFWkP:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFWB0Q(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVoLUB(self):
  if not self.isBusy:
   VVhIDJ = []
   VVhIDJ.append(("All"        , "all"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Used by Channels"     , "used" ))
   VVhIDJ.append(("Unused PIcons"     , "unused" ))
   VVhIDJ.append(("IPTV PIcons"      , "iptv" ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("PIcons Files"      , "pFiles" ))
   VVhIDJ.append(("SymLinks to PIcons"    , "pLinks" ))
   VVhIDJ.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVhIDJ.append(("By Files Date ..."    , "pDate" ))
   VVhIDJ.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVhIDJ.append(FFw8eL("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FF0QId(val)
      VVhIDJ.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCf604(self)
   filterObj.VVVOhK(VVhIDJ, self.nsList, self.VV4HHx)
 def VV4HHx(self, item=None):
  if item is not None:
   self.VVRPyP(item)
 def VVRPyP(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVWMbV   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVCSf4   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVgCPX  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVeuMG   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVtGTA  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVxz5O  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV9BWp  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVdrf6 , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVL3LE , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVt9C0   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVVMgA , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV9BWp:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFpNiE("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFtnj1(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFM3N1(self, "Not found", 1000)
     return
   elif mode == self.VVdrf6:
    self.VVQshI(mode)
    return
   elif mode == self.VVL3LE:
    self.VVU0NI(mode)
    return
   elif mode == self.VVhm1s:
    return
   else:
    words, asPrefix = CCf604.VV7zA4(words)
   if not words and mode in (self.VVt9C0, self.VVVMgA):
    FFM3N1(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFuMBP(self, BF(self.VVqhzF, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVQshI(self, mode):
  VVhIDJ = []
  VVhIDJ.append(("Today"   , "today" ))
  VVhIDJ.append(("Since Yesterday" , "yest" ))
  VVhIDJ.append(("Since 7 days"  , "week" ))
  FFRHhp(self, BF(self.VVlzoG, mode), VVhIDJ=VVhIDJ, title="Filter by Added/Modified Date")
 def VVlzoG(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFiwJD(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFiwJD(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFiwJD(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFuMBP(self, BF(self.VVqhzF, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVU0NI(self, mode):
  VVlyQB, VV2HRF = FFXAmG()
  lst = set()
  for key, val in VV2HRF.items():
   lst.add(val)
  VVhIDJ = []
  for item in lst:
   VVhIDJ.append((item, item))
  VVhIDJ.sort(key=lambda x: x[0])
  FFRHhp(self, BF(self.VVJy0h, mode), VVhIDJ=VVhIDJ, title="Filter by Service Type")
 def VVJy0h(self, mode, item=None):
  if item:
   VVlyQB, VV2HRF = FFXAmG()
   sTypeList = []
   for key, val in VV2HRF.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFuMBP(self, BF(self.VVqhzF, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVOifa(self):
  self.session.open(CCZyfd, barTheme=CCZyfd.VVYJKb
      , titlePrefix = ""
      , fncToRun  = self.VV0QCu
      , VVLUmk = self.VVTYrt)
 def VV0QCu(self, VVVRSv):
  VVjMIb, err = CCn3v3.VVwReR(self, CCn3v3.VVsanQ, VV4Nwj=False, VV8QCM=False)
  files = []
  words = []
  if not VVVRSv or VVVRSv.isCancelled:
   return
  VVVRSv.VVPpbS = []
  VVVRSv.VVWtjR(len(VVjMIb))
  if VVjMIb:
   curCh = self.VV2ucW(self.curChanName)
   for refCode in VVjMIb:
    if not VVVRSv or VVVRSv.isCancelled:
     return
    VVVRSv.VVBQzv(1, True)
    chName, sat, inDB = VVjMIb.get(refCode, ("", "", 0))
    ratio = CCTdjW.VVNtAV(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCTdjW.VV4LgX(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFtnj1(f)
       fil = f.replace(".png", "")
       if not fil in VVVRSv.VVPpbS:
        VVVRSv.VVPpbS.append(fil)
 def VVTYrt(self, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  if VVPpbS : FFuMBP(self, BF(self.VVqhzF, mode=self.VVhm1s, words=VVPpbS), title="Loading ...")
  else   : FFM3N1(self, "Not found", 2000)
 def VVqhzF(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVFHHu(isFirstTime):
   return
  self.isBusy = True
  VV8QCM = True if isFirstTime else False
  VVjMIb, err = CCn3v3.VVwReR(self, CCn3v3.VVsanQ, VV4Nwj=False, VV8QCM=VV8QCM)
  if err:
   self.close()
  iptvRefList = self.VVcmVh()
  tList = []
  for fName, fType in CCTdjW.VVSXaF(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVjMIb:
    if fName in VVjMIb:
     chName, sat, inDB = VVjMIb.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVWMbV:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVCSf4  and chName         : isAdd = True
   elif mode == self.VVgCPX and not chName        : isAdd = True
   elif mode == self.VVtGTA  and fType == 0        : isAdd = True
   elif mode == self.VVxz5O  and fType == 1        : isAdd = True
   elif mode == self.VV9BWp  and fName in words       : isAdd = True
   elif mode == self.VVhm1s and fName in words       : isAdd = True
   elif mode == self.VVeuMG  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVt9C0  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVVMgA:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVdrf6:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVL3LE:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVFWkP   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFM3N1(self)
  else:
   self.isBusy = False
   FFM3N1(self, "Not found", 1000)
   return
  self.VVFWkP.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVSj7M()
  self.totalItems = len(self.VVFWkP)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVpbN4(True)
 def VVFHHu(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCTdjW.VVSXaF(self.pPath):
    if fName:
     return True
   if isFirstTime : FFB8Nz(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFM3N1(self, "Not found", 1000)
  else:
   FFB8Nz(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVcmVh(self):
  VVkNlM = {}
  files  = CC8Yh1.VVYsfN()
  if files:
   for path in files:
    txt = FFQDOO(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVkNlM[refCode] = item[1]
  return VVkNlM
 def VVVDMG(self):
  self.VV1OZ7()
  f1, f2 = self.VVxbir()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVFWkP[ndx]
   fName = self.VVFWkP[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCQNdY.VVgw8m(pic, path) : color = VVfPTB if inDB else ""
   elif not chName           : color = ""
   else             : color = VVGdv9
   self.VVLpvH(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVNtAV(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVAH5i():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVTELK")
 @staticmethod
 def VVe7Kq():
  VVhIDJ = []
  VVhIDJ.append(("Find SymLinks (to PIcon Directory)"   , "VVUCmM"  ))
  VVhIDJ.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVhIDJ.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVhIDJ
 @staticmethod
 def VVTELK(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF)
  png, path = CCTdjW.VV0iL6(refCode)
  if path : CCTdjW.VV73UN(SELF, png, path)
  else : FFB8Nz(SELF, "No PIcon found for current channel in:\n\n%s" % CCTdjW.VVJwSu())
 @staticmethod
 def VVUCmM(SELF):
  if VVqZDD:
   sed1 = FFw0WV("->", VVqZDD)
   sed2 = FFw0WV("picon", VVdSiQ)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVGdv9, VViVXH)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF1Ubx(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FF9R5Y(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVFpAj(SELF, isPIcon):
  sed1 = FFw0WV("->", VVGdv9)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFw0WV("picon", VVdSiQ)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF1Ubx(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FF9R5Y(), grep, sed1, sed2))
 @staticmethod
 def VV73UN(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFw0WV("%s%s" % (dest, png), VVfPTB))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFw0WV(errTxt, VVvrDy))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFJU8q(SELF, cmd)
 @staticmethod
 def VVSXaF(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVJwSu():
  path = CFG.PIconsPath.getValue()
  return FF77SS(path)
 @staticmethod
 def VV0iL6(refCode, chName=None):
  if FFrhBg(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFpqbA(refCode)
  allPath, fName, refCodeFile, pList = CCTdjW.VV4LgX(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVofv1(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CC8Yh1.VVj2DV():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFpdHF(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VV4LgX(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCTdjW.VVJwSu()
   pList = []
   lst = FFjT7E(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFpdHF(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFtnj1(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCCU3j():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVMUVx  = None
  self.VVjjgp = ""
  self.VVStZV  = noService
  self.VVPEfk = 0
  self.VVAsk7  = noService
  self.VVhLeU = 0
  self.VVDTX3  = "-"
  self.VVwycM = 0
  self.VVA79Q  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVMiBw(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVMUVx = frontEndStatus
     self.VVjwoq()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVjwoq(self):
  if self.VVMUVx:
   val = self.VVMUVx.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVjjgp = "%3.02f dB" % (val / 100.0)
   else         : self.VVjjgp = ""
   val = self.VVMUVx.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVPEfk = int(val)
   self.VVStZV  = "%d%%" % val
   val = self.VVMUVx.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVhLeU = int(val)
   self.VVAsk7  = "%d%%" % val
   val = self.VVMUVx.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVDTX3  = "%d" % val
   val = int(val * 100 / 500)
   self.VVwycM = min(500, val)
   val = self.VVMUVx.get("tuner_locked", 0)
   if val == 1 : self.VVA79Q = "Locked"
   else  : self.VVA79Q = "Not locked"
 def VVntdY(self)   : return self.VVjjgp
 def VVkUkN(self)   : return self.VVStZV
 def VVoWgT(self)  : return self.VVPEfk
 def VVhwwe(self)   : return self.VVAsk7
 def VVpUxo(self)  : return self.VVhLeU
 def VVtjIA(self)   : return self.VVDTX3
 def VV8CYS(self)  : return self.VVwycM
 def VVLGQF(self)   : return self.VVA79Q
 def VV4iJX(self) : return self.serviceName
class CCpNxn():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVmVg5(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFKGMY(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVHa1e(self.ORPOS  , mod=1   )
      self.sat2  = self.VVHa1e(self.ORPOS  , mod=2   )
      self.freq  = self.VVHa1e(self.FREQ  , mod=3   )
      self.sr   = self.VVHa1e(self.SR   , mod=4   )
      self.inv  = self.VVHa1e(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVHa1e(self.POL  , self.D_POL )
      self.fec  = self.VVHa1e(self.FEC  , self.D_FEC )
      self.syst  = self.VVHa1e(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVHa1e("modulation" , self.D_MOD )
       self.rolof = self.VVHa1e("rolloff"  , self.D_ROLOF )
       self.pil = self.VVHa1e("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVHa1e("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVHa1e("pls_code"  )
       self.iStId = self.VVHa1e("is_id"   )
       self.t2PlId = self.VVHa1e("t2mi_plp_id" )
       self.t2PId = self.VVHa1e("t2mi_pid"  )
 def VVHa1e(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FF0QId(val)
  elif mod == 2   : return FFIxYe(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVt5Ag(self, refCode):
  txt = ""
  self.VVmVg5(refCode)
  if self.data:
   def VVnxYh(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVnxYh("System"   , self.syst)
    txt += VVnxYh("Satellite"  , self.sat2)
    txt += VVnxYh("Frequency"  , self.freq)
    txt += VVnxYh("Inversion"  , self.inv)
    txt += VVnxYh("Symbol Rate"  , self.sr)
    txt += VVnxYh("Polarization" , self.pol)
    txt += VVnxYh("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVnxYh("Modulation" , self.mod)
     txt += VVnxYh("Roll-Off" , self.rolof)
     txt += VVnxYh("Pilot"  , self.pil)
     txt += VVnxYh("Input Stream", self.iStId)
     txt += VVnxYh("T2MI PLP ID" , self.t2PlId)
     txt += VVnxYh("T2MI PID" , self.t2PId)
     txt += VVnxYh("PLS Mode" , self.plsMod)
     txt += VVnxYh("PLS Code" , self.plsCod)
   else:
    txt += VVnxYh("System"   , self.txMedia)
    txt += VVnxYh("Frequency"  , self.freq)
  return txt, self.namespace
 def VVsB6f(self, refCode):
  txt = "Transpoder : ?"
  self.VVmVg5(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVeuXj(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFKGMY(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVHa1e(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVHa1e(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVHa1e(self.SYST, self.D_SYS_S)
     freq = self.VVHa1e(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVHa1e(self.POL , self.D_POL)
      fec = self.VVHa1e(self.FEC , self.D_FEC)
      sr = self.VVHa1e(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV4v1g(self, refCode):
  self.data = None
  self.VVmVg5(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCwZEN():
 def __init__(self, VVJ5Oo, path, VVLUmk=None, curRowNum=-1):
  self.VVJ5Oo  = VVJ5Oo
  self.origFile   = path
  self.Title    = "File Editor: " + FFtnj1(path)
  self.VVLUmk  = VVLUmk
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFcZm9("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFuMBP(self.VVJ5Oo, BF(self.VVflgW, curRowNum), title="Loading file ...")
  else:
   FFB8Nz(self.VVJ5Oo, "Error while preparing edit!")
 def VVflgW(self, curRowNum):
  VVkNlM = self.VVjYyH()
  VVlrMb = ("Save Changes" , self.VVdZcW   , [])
  VVlUqf  = ("Edit Line"  , self.VV7svS    , [])
  VVkGmL = ("Options"  , self.VVQIUB  , [])
  VV1FeB = ("Line Options" , self.VVFi0s   , [])
  VVNBO3 = (""    , self.VV1e1R , [])
  VVPEsb = self.VV5b5a
  VVNgbt  = self.VVHAnm
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVrLHE  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFNCSP(self.VVJ5Oo, None, title=self.Title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, width=1600, height=1000, VVNWWl=26, isEditor=True, VVlrMb=VVlrMb, VVlUqf=VVlUqf, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVPEsb=VVPEsb, VVNgbt=VVNgbt, VVNBO3=VVNBO3, VVJcAk=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#05333333", VVvy9F="#00303030", VVRt6l="#11331133")
  self.editorTable.VVj43f(curRowNum)
 def VVHAnm(self, VVhqv2):
  VVhqv2.VVFwsu()
 def VVQIUB(self, VVhqv2, title, txt, colList):
  VVhIDJ = []
  VVhIDJ.append(("Go to Line Num" , "toLine"))
  VVhIDJ.append(("Find & Replace" , "repl"))
  FFRHhp(self.VVJ5Oo, self.VVqOq2, VVhIDJ=VVhIDJ, width=500, title="Options", VVWLSA=True)
 def VVqOq2(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVGwe6()
   elif ref == "repl"  : self.VV6BUC(title)
 def VV6BUC(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVlUqf  = ("Change" , BF(self.VVOWnZ, title, lst) , [])
  VVlrMb = ("Start" , BF(self.VVypbe, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVrLHE = (LEFT   , LEFT  , CENTER)
  FFNCSP(self.VVJ5Oo, None, title=title, VVFWkP=lst, header=header, VVrLHE=VVrLHE, VVN1SU=widths, width=1200, VVNWWl=30, isEditor=True, VVlUqf=VVlUqf, VVlrMb=VVlrMb, VVUMPl=2
    , VVl9AY=bg, VVLICL=bg, VVHZxf=bg, VVSzMt="#06224455", VVvy9F="#0a303030")
 def VVOWnZ(self, Title, lst, VVhqv2, title, txt, colList):
  title = VVhqv2.VV26F4(0)
  ndx = VVhqv2.VVHqmL()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFs37j(self.VVJ5Oo, BF(self.VVJmBq, VVhqv2, ndx), title=title, defaultText=txt, message="New entry")
 def VVJmBq(self, VVhqv2, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FFsMp0(CFG.lastFindRepl_fnd, newTxt)
   else  : FFsMp0(CFG.lastFindRepl_rpl, newTxt)
   VVhqv2.VVMFmy({1:newTxt, 2:len(newTxt)})
 def VVypbe(self, Title, VVhqv2, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFQDOO(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FF5jVY(self.VVJ5Oo, BF(FFuMBP, VVhqv2, BF(self.VVGrtu, VVhqv2, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFM3N1(VVhqv2, "Not found in file !", 1000)
    VVhqv2.VVj43f(0)
  else:
   FFM3N1(VVhqv2, "Nothing to find", 1000)
 def VVGrtu(self, VVhqv2, fnd, rpl):
  txt = FFQDOO(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVhqv2.cancel()
  self.fileChanged = True
  self.editorTable.VV7m1I()
  VVkNlM = self.VVjYyH()
  self.editorTable.VVartp(VVkNlM)
 def VVGwe6(self):
  totRows = self.editorTable.VVfbKq()
  lineNum = self.editorTable.VVHqmL() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFs37j(self.VVJ5Oo, BF(self.VV9EGw, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VV9EGw(self, lineNum, totRows, VVSRUl):
  if VVSRUl:
   VVSRUl = VVSRUl.strip()
   if VVSRUl.isdigit():
    num = FFYuUY(int(VVSRUl) - 1, 0, totRows)
    self.editorTable.VVj43f(num)
    self.lastLineNum = num + 1
   else:
    FFM3N1(self.editorTable, "Incorrect number", 1500)
 def VVFi0s(self, VVhqv2, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVhqv2.VVczIx()
  VVhIDJ = []
  VVhIDJ.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVhIDJ.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VViLdp"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV7Xe7:
   VVhIDJ.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(  ("Delete Line"         , "deleteLine"   ))
  FFRHhp(self.VVJ5Oo, BF(self.VVa3LE, lineNum), VVhIDJ=VVhIDJ, title="Line Options")
 def VVa3LE(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVzxaJ("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VViLdp"  : self.VViLdp(lineNum)
   elif item == "copyToClipboard"  : self.VVPRW4(lineNum)
   elif item == "pasteFromClipboard" : self.VVgQib(lineNum)
   elif item == "deleteLine"   : self.VVzxaJ("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VV1e1R(self, VVhqv2, title, txt, colList):
  if   self.insertMode == 1: VVhqv2.VVzAvj()
  elif self.insertMode == 2: VVhqv2.VVa0Kk()
  self.insertMode = 0
 def VViLdp(self, lineNum):
  if lineNum == self.editorTable.VVczIx():
   self.insertMode = 1
   self.VVzxaJ("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVzxaJ("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVPRW4(self, lineNum):
  global VV7Xe7
  VV7Xe7 = FFkd4T("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVomXH("Copied to clipboard")
 def VVdZcW(self, VVhqv2, title, txt, colList):
  if self.fileChanged:
   if FFGli3(self.origFile):
    if FFcZm9("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVhqv2.VVomXH("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVhqv2.VVFwsu()
    else:
     FFB8Nz(self.VVJ5Oo, "Cannot save file!")
   else:
    FFB8Nz(self.VVJ5Oo, "Cannot create backup copy of original file!")
 def VV5b5a(self, VVhqv2):
  if self.fileChanged:
   FF5jVY(self.VVJ5Oo, BF(self.VV6v1o, VVhqv2), "Cancel changes ?")
  else:
   FFcZm9("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VV6v1o(VVhqv2)
 def VV6v1o(self, VVhqv2):
  VVhqv2.cancel()
  FFZ5Mj(self.tmpFile)
  if self.VVLUmk:
   self.VVLUmk(self.fileSaved)
 def VV7svS(self, VVhqv2, title, txt, colList):
  lineNum = int(VVhqv2.VV26F4(0))
  lineTxt = VVhqv2.VV26F4(1, isStrip=False)
  message = VViVXH + "ORIGINAL TEXT:\n" + VVlrJC + lineTxt
  FFs37j(self.VVJ5Oo, BF(self.VVhA5e, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVhA5e(self, lineNum, VVSRUl):
  if not VVSRUl is None:
   if self.editorTable.VVczIx() <= 1:
    self.VVzxaJ("echo %s > '%s'" % (VVSRUl, self.tmpFile))
   else:
    self.VVn15X(lineNum, VVSRUl)
 def VVgQib(self, lineNum):
  if lineNum == self.editorTable.VVczIx() and self.editorTable.VVczIx() == 1:
   self.VVzxaJ("echo %s >> '%s'" % (VV7Xe7, self.tmpFile))
  else:
   self.VVn15X(lineNum, VV7Xe7)
 def VVn15X(self, lineNum, newTxt):
  self.editorTable.VVrUMm("Saving ...")
  lines = FF9z80(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VV7m1I()
  VVkNlM = self.VVjYyH()
  self.editorTable.VVartp(VVkNlM)
 def VVzxaJ(self, cmd):
  tCons = CCeOtv()
  tCons.ePopen(cmd, self.VVtA4J)
  self.fileChanged = True
  self.editorTable.VV7m1I()
 def VVtA4J(self, result, retval):
  VVkNlM = self.VVjYyH()
  self.editorTable.VVartp(VVkNlM)
 def VVjYyH(self):
  if fileExists(self.tmpFile):
   lines = FF9z80(self.tmpFile)
   VVkNlM = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVkNlM.append((str(ndx), line))
   if not VVkNlM:
    VVkNlM.append((str(1), ""))
   return VVkNlM
  else:
   FFM8jr(self.VVJ5Oo, self.tmpFile)
class CCf604():
 def __init__(self, callingSELF, VVl9AY="#22003344", VVLICL="#22002233"):
  self.callingSELF = callingSELF
  self.VVhIDJ  = []
  self.satList  = []
  self.VVl9AY  = VVl9AY
  self.VVLICL   = VVLICL
 def VV98nA(self, VVLUmk):
  self.VVhIDJ = []
  VVhIDJ, VVYpjp = CCf604.VVYrzi(self.callingSELF, False, True)
  if VVhIDJ:
   self.VVhIDJ += VVhIDJ
   self.VV8bkE(VVLUmk, VVYpjp)
 def VVi0iu(self, mode, VVhqv2, satCol, VVLUmk, inFilterFnc=None):
  VVhqv2.VVrUMm("Loading Filters ...")
  self.VVhIDJ = []
  self.VVhIDJ.append(("All Services" , "all"))
  if mode == 1:
   self.VVhIDJ.append(VVuAtK)
   self.VVhIDJ.append(("Parental Control", "parentalControl" ))
   self.VVhIDJ.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVhIDJ.append(VVuAtK)
   self.VVhIDJ.append(("Selected Transponder"   , "selectedTP" ))
   self.VVhIDJ.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVT6bb(VVhqv2, satCol)
  VVhIDJ, VVYpjp = CCf604.VVYrzi(self.callingSELF, True, False)
  if VVhIDJ:
   VVhIDJ.insert(0, FFw8eL("Custom Words"))
   self.VVhIDJ += VVhIDJ
  VVhqv2.VV0Sa3()
  self.VV8bkE(VVLUmk, VVYpjp, inFilterFnc)
 def VVVOhK(self, VVhIDJ, sats, VVLUmk, inFilterFnc=None):
  self.VVhIDJ = VVhIDJ
  VVhIDJ, VVYpjp = CCf604.VVYrzi(self.callingSELF, True, False)
  if VVhIDJ:
   self.VVhIDJ.append(FFw8eL("Custom Words"))
   self.VVhIDJ += VVhIDJ
  self.VV8bkE(VVLUmk, VVYpjp, inFilterFnc)
 def VV8bkE(self, VVLUmk, VVYpjp, inFilterFnc=None):
  VVbPo7  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVVW3K = ("Edit Filter"  , BF(self.VVnBEo, VVYpjp))
  VVzwta  = ("Filter Help"  , BF(self.VVT4rx, VVYpjp))
  FFRHhp(self.callingSELF, BF(self.VV1ifO, VVLUmk), VVhIDJ=self.VVhIDJ, title="Select Filter", VVbPo7=VVbPo7, VVVW3K=VVVW3K, VVzwta=VVzwta, VV14QT=True, VVl9AY=self.VVl9AY, VVLICL=self.VVLICL)
 def VV1ifO(self, VVLUmk, item):
  if item:
   VVLUmk(item)
 def VVnBEo(self, VVYpjp, selectionObj, sel):
  if fileExists(VVYpjp) : CCwZEN(self.callingSELF, VVYpjp, VVLUmk=None)
  else       : FFM8jr(self.callingSELF, VVYpjp)
  selectionObj.cancel()
 def VVT4rx(self, VVYpjp, selectionObj, sel):
  FFYqxx(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVT6bb(self, VVhqv2, satColNum):
  if not self.satList:
   satList = VVhqv2.VVyaay(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFPrtr(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFw8eL("Satellites"))
  if self.VVhIDJ:
   self.VVhIDJ += self.satList
 @staticmethod
 def VVYrzi(SELF, addTag, VVzp4h):
  FFjSyn()
  fileName  = "ajpanel_services_filter"
  VVYpjp = VVVcWE + fileName
  VVhIDJ  = []
  if not fileExists(VVYpjp):
   FFcZm9("cp -f '%s' '%s'" % (VVobIL + fileName, VVYpjp))
  fileFound = False
  if fileExists(VVYpjp):
   fileFound = True
   lines = FF9z80(VVYpjp)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVhIDJ.append((line, "__w__" + line))
       else  : VVhIDJ.append((line, line))
  if VVzp4h:
   if   not fileFound : FFM8jr(SELF, VVYpjp)
   elif not VVhIDJ : FFQGz4(SELF, VVYpjp)
  return VVhIDJ, VVYpjp
 @staticmethod
 def VV7zA4(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCr5W8():
 def __init__(self, callingSELF, VVhqv2, addSep=True):
  self.callingSELF = callingSELF
  self.VVhqv2 = VVhqv2
  self.VVhIDJ = []
  iMulSel = self.VVhqv2.VVNb4j()
  if iMulSel : self.VVhIDJ.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVhIDJ.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVhqv2.VVv2WG()
  self.VVhIDJ.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVhIDJ.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVhIDJ.append(VVuAtK)
 def VVklJK(self, extraMenu, cbFncDict, okFnc=None, onMultiSelFnc=None, width=1000, height=850, VVl9AY="#22003344", VVLICL="#22002233"):
  self.VVhqv2.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVhIDJ.extend(extraMenu)
  FFRHhp(self.callingSELF, BF(self.VV0Fea, cbFncDict, okFnc), width=width, height=height, title="Options", VVhIDJ=self.VVhIDJ, VVl9AY=VVl9AY, VVLICL=VVLICL)
 def VV0Fea(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVhqv2.VVAHRi(True)
   elif item == "MultSelDisab" : self.VVhqv2.VVAHRi(False)
   elif item == "selectAll" : self.VVhqv2.VVsR9P()
   elif item == "unselectAll" : self.VVhqv2.VVqXj9()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCUz6Y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VVua82, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFTlW1(self)
  FFMz2e(self["keyRed"]  , "Exit")
  FFMz2e(self["keyGreen"]  , "Save")
  FFMz2e(self["keyYellow"] , "Refresh")
  FFMz2e(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVyASM,
  {
   "red" : self.VVJnCM  ,
   "green" : self.VVHK8n ,
   "yellow": self.VVtWhr  ,
   "blue" : self.VVkCCC   ,
   "up" : self.VVUREY    ,
   "down" : self.VVrBVj   ,
   "left" : self.VV2KSP   ,
   "right" : self.VVVV8y   ,
   "cancel": self.VVJnCM
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.VVtWhr()
  self.VVO8KX()
  FF3wB4(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVfEAz)
  except:
   self.timer.callback.append(self.VVfEAz)
  self.timer.start(1000, False)
  self.VVfEAz()
 def onExit(self):
  self.timer.stop()
 def VVJnCM(self) : self.close(True)
 def VVyoKY(self) : self.close(False)
 def VVkCCC(self):
  self.session.openWithCallback(self.VVXo0F, BF(CCtToK))
 def VVXo0F(self, closeAll):
  if closeAll:
   self.close()
 def VVfEAz(self):
  self["curTime"].setText(str(FFzHDX(iTime())))
 def VVUREY(self):
  self.VVYO8x(1)
 def VVrBVj(self):
  self.VVYO8x(-1)
 def VV2KSP(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVO8KX()
 def VVVV8y(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVO8KX()
 def VVYO8x(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVXavv(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVXavv(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVXavv(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVkDv2(year)):
   days += 1
  return days
 def VVkDv2(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVO8KX(self):
  for obj in self.list:
   FFOrd9(obj, "#11404040")
  FFOrd9(self.list[self.index], "#11ff8000")
 def VVtWhr(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVHK8n(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCeOtv()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV4tsn)
 def VV4tsn(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFWB0Q(self, "Nothing returned from the system!")
  else    : FFWB0Q(self, str(result))
class CCtToK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VVj7jx, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFTlW1(self, addLabel=True)
  FFMz2e(self["keyRed"]  , "Exit")
  FFMz2e(self["keyGreen"]  , "Sync")
  FFMz2e(self["keyYellow"] , "Refresh")
  FFMz2e(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVyASM,
  {
   "red" : self.VVJnCM   ,
   "green" : self.VVFi30  ,
   "yellow": self.VVqF0L ,
   "blue" : self.VVb71r  ,
   "cancel": self.VVJnCM
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVEO5w()
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  FF3wB4(self)
  FFbn1D(self.VVZUYM)
 def VVZUYM(self):
  self.VVISVy()
  self.VVQeSe(False)
 def VVJnCM(self)  : self.close(True)
 def VVb71r(self) : self.close(False)
 def VVEO5w(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVISVy(self):
  self.VVuJwv()
  self.VVZfW7()
  self.VV68E6()
  self.VVFnh7()
 def VVqF0L(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVEO5w()
   self.VVISVy()
   FFbn1D(self.VVZUYM)
 def VVFi30(self):
  if len(self["keyGreen"].getText()) > 0:
   FF5jVY(self, self.VVn0Z6, "Synchronize with Internet Date/Time ?")
 def VVn0Z6(self):
  self.VVISVy()
  FFbn1D(BF(self.VVQeSe, True))
 def VVuJwv(self)  : self["keyRed"].show()
 def VV6GsK(self)  : self["keyGreen"].show()
 def VVv0LZ(self) : self["keyYellow"].show()
 def VVCDAq(self)  : self["keyBlue"].show()
 def VVZfW7(self)  : self["keyGreen"].hide()
 def VV68E6(self) : self["keyYellow"].hide()
 def VVFnh7(self)  : self["keyBlue"].hide()
 def VVQeSe(self, sync):
  localTime = FFqUVM()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVEcbx(server)
   if epoch_time is not None:
    ntpTime = FFzHDX(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCeOtv()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV4tsn, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVv0LZ()
  self.VVCDAq()
  if ok:
   self.VV6GsK()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV4tsn(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVQeSe(False)
  except:
   pass
 def VVEcbx(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCBOP8.VVk4Hv():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC1VLk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFMkht(VVC2sq, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFTlW1(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFbn1D(self.VVnMtl)
 def VVnMtl(self):
  if CCBOP8.VVk4Hv() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFOrd9(self["myBody"], color)
   FFOrd9(self["myLabel"], color)
  except:
   pass
class CCN4Do(Screen):
 VVNeYm = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFfZ8G()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFMkht(VVXazS, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCZaFH(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCZaFH(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCZaFH(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCCU3j()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFTlW1(self, title="Signal")
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok"  : self.close      ,
   "up"  : self.VVUREY       ,
   "down"  : self.VVrBVj      ,
   "left"  : self.VV2KSP      ,
   "right"  : self.VVVV8y      ,
   "info"  : self.VVynXw     ,
   "epg"  : self.VVynXw     ,
   "menu"  : self.VVfTLh      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVkMJU, -1)  ,
   "next"  : BF(self.VVkMJU, 1)  ,
   "pageUp" : BF(self.VVwXht, True) ,
   "chanUp" : BF(self.VVwXht, True) ,
   "pageDown" : BF(self.VVwXht, False) ,
   "chanDown" : BF(self.VVwXht, False) ,
   "0"   : BF(self.VVkMJU, 0)  ,
   "1"   : BF(self.VVXhit, pos=1) ,
   "2"   : BF(self.VVXhit, pos=2) ,
   "3"   : BF(self.VVXhit, pos=3) ,
   "4"   : BF(self.VVXhit, pos=4) ,
   "5"   : BF(self.VVXhit, pos=5) ,
   "6"   : BF(self.VVXhit, pos=6) ,
   "7"   : BF(self.VVXhit, pos=7) ,
   "8"   : BF(self.VVXhit, pos=8) ,
   "9"   : BF(self.VVXhit, pos=9) ,
  }, -1)
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  if not CCN4Do.VVNeYm:
   CCN4Do.VVNeYm = self
  self.sliderSNR.VVamql()
  self.sliderAGC.VVamql()
  self.sliderBER.VVamql(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVXhit()
  self.VV9dze()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVsyCM)
  except:
   self.timer.callback.append(self.VVsyCM)
  self.timer.start(500, False)
 def VV9dze(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVMiBw(service)
  serviceName = self.tunerInfo.VV4iJX()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  tp = CCpNxn()
  tpTxt, satTxt = tp.VVsB6f(refCode)
  if tpTxt == "?" :
   tpTxt = FFwXwL("NO SIGNAL", VVeCLm)
  self["myTPInfo"].setText(tpTxt + "  " + FFwXwL(satTxt, VVdVoc))
 def VVsyCM(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVMiBw(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVntdY())
   self["mySNR"].setText(self.tunerInfo.VVkUkN())
   self["myAGC"].setText(self.tunerInfo.VVhwwe())
   self["myBER"].setText(self.tunerInfo.VVtjIA())
   self.sliderSNR.VVSzAY(self.tunerInfo.VVoWgT())
   self.sliderAGC.VVSzAY(self.tunerInfo.VVpUxo())
   self.sliderBER.VVSzAY(self.tunerInfo.VV8CYS())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVSzAY(0)
   self.sliderAGC.VVSzAY(0)
   self.sliderBER.VVSzAY(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
    if state and not state == "Tuned":
     FFM3N1(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVynXw(self):
  FFcAqb(self, fncMode=CCscAN.VVVOT1)
 def VVfTLh(self):
  FFYqxx(self, "_help_signal", "Signal Monitor (Keys)")
 def VVUREY(self)  : self.VVXhit(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVrBVj(self) : self.VVXhit(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV2KSP(self) : self.VVXhit(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVVV8y(self) : self.VVXhit(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVXhit(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFsMp0(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVkMJU(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFYuUY(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFsMp0(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCN4Do.VVNeYm = None
 def VVwXht(self, isUp):
  FFM3N1(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV9dze()
  except:
   pass
class CCZaFH(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVamql(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFOrd9(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVobIL +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFOrd9(self.covObj, self.covColor)
   else:
    FFOrd9(self.covObj, "#00006688")
    self.isColormode = True
  self.VVSzAY(0)
 def VVSzAY(self, val):
  val  = FFYuUY(val, self.minN, self.maxN)
  width = int(FFdPXt(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFYuUY(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCZyfd(Screen):
 VVYJKb    = 0
 VVL0BW = 1
 VVEaYs = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVLUmk=None, barTheme=VVYJKb, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVgyWU(barTheme)
  self.skin, self.skinParam = FFMkht(VVYvQ9, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVLUmk = VVLUmk
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVPpbS = None
  self.timer   = eTimer()
  self.myThread  = None
  FFTlW1(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVyASM, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.VV7dgc()
  self["myProgBarVal"].setText("0%")
  FFOrd9(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVGZyw()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGZyw)
  except:
   self.timer.callback.append(self.VVGZyw)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVWtjR(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVZ4Fr(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVPpbS), self.counter, self.maxValue, catName)
 def VVgURK(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV8wiV(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVFpGs(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVR8fR(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVzj1d(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVIQXG(self, txt):
  self.newTitle = txt
 def VVBQzv(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVPpbS), self.counter, self.maxValue)
  except:
   pass
 def VVaiWl(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVlnuk(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVmMZj(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFM3N1(self, "Cancelling ...")
  self.isCancelled = True
  self.VV6tzu(False)
 def VV6tzu(self, isDone):
  FFbn1D(BF(self.VViv7V, isDone))
 def VViv7V(self, isDone):
  if self.VVLUmk:
   self.VVLUmk(isDone, self.VVPpbS, self.counter, self.maxValue, self.isError)
  self.close()
 def VVGZyw(self):
  val = FFYuUY(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFdPXt(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV6tzu(True)
 def VV7dgc(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVL0BW, self.VVEaYs):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVgyWU(self, barTheme):
  if   barTheme == self.VVL0BW : return 0.7
  if   barTheme == self.VVEaYs : return 0.5
  else             : return 1
class CCeOtv(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVLUmk = {}
  self.commandRunning = False
  self.VVcMDF  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVLUmk, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVLUmk[name] = VVLUmk
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVcMDF:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVTiYu, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVhWwU , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVTiYu, name))
    self.appContainers[name].appClosed.append(BF(self.VVhWwU , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVhWwU(name, retval)
  return True
 def VVTiYu(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFwXwL("[UN-DECODED STRING]", VVeCLm))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVhWwU(self, name, retval):
  if not self.VVcMDF:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVLUmk[name]:
   self.VVLUmk[name](self.appResults[name], retval)
  del self.VVLUmk[name]
 def VV8CKq(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCF7vX(Screen):
 def __init__(self, session, title="", VV0FrL=None, VVLcTO=False, VVHWrU=False, VVVcYg=False, VVhCLY=False, VVB8vW=False, VVEd3y=False, VVCqdo=VVDdVy, VVE46B=None, VVp6ie=False, VVZweB=None, VVj7dF="", checkNetAccess=False, VVNWWl=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFMkht(VVegdj, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVNWWl, usefixedFont=consFont)
  self.session   = session
  self.VVj7dF = VVj7dF
  FFTlW1(self, addScrollLabel=True)
  self.VVLcTO   = VVLcTO
  self.VVHWrU   = VVHWrU
  self.VVVcYg   = VVVcYg
  self.VVhCLY  = VVhCLY
  self.VVB8vW = VVB8vW
  self.VVEd3y = VVEd3y
  self.VVCqdo   = VVCqdo
  self.VVE46B = VVE46B
  self.VVp6ie  = VVp6ie
  self.VVZweB  = VVZweB
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCeOtv()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFNcNO()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV0FrL, str):
   self.VV0FrL = [VV0FrL]
  else:
   self.VV0FrL = VV0FrL
  if self.VVVcYg or self.VVhCLY:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VV0FrL.append("echo -e '\n%s\n' %s" % (restartNote, FFw0WV(restartNote, VVqZDD)))
   if self.VVVcYg:
    self.VV0FrL.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV0FrL.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVB8vW:
   FFM3N1(self, "Processing ...")
  self.onLayoutFinish.append(self.VVaMaX)
  self.onClose.append(self.VVJJr3)
 def VVaMaX(self):
  self["myLabel"].VVsOYo(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVj7dF or "Processing ..."))
  if self.VVLcTO:
   self["myLabel"].VVjhj8()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVY3M7()
  else:
   self.VVA2g0()
 def VVY3M7(self):
  if CCBOP8.VVk4Hv():
   self["myLabel"].setText("Processing ...")
   self.VVA2g0()
  else:
   self["myLabel"].setText(FFwXwL("\n   No connection to internet!", VVdSiQ))
 def VVA2g0(self):
  allOK = self.container.ePopen(self.VV0FrL[0], self.VV5P0p, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV5P0p("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVEd3y or self.VVVcYg or self.VVhCLY:
    self["myLabel"].setText(FF6F4t("STARTED", VVqZDD) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVZweB:
   colorWhite = CCbkDP.VVhXkO(VViVXH)
   color  = CCbkDP.VVhXkO(self.VVZweB[0])
   words  = self.VVZweB[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVCqdo=self.VVCqdo)
 def VV5P0p(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV0FrL):
   allOK = self.container.ePopen(self.VV0FrL[self.cmdNum], self.VV5P0p, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV5P0p("Cannot connect to Console!", -1)
  else:
   if self.VVB8vW and FF5tzJ(self):
    FFM3N1(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVEd3y:
    self["myLabel"].appendText("\n" + FF6F4t("FINISHED", VVqZDD), self.VVCqdo)
   if self.VVLcTO or self.VVHWrU:
    self["myLabel"].VVjhj8()
   if self.VVE46B is not None:
    self.VVE46B()
   if not retval and self.VVp6ie:
    self.VVJJr3()
 def VVJJr3(self):
  if self.container.VV8CKq():
   self.container.killAll()
class CCLbFT(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VVegdj, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVVcWE + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFkd4T("pwd") or "/home/root"
  self.container   = CCeOtv()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFTlW1(self, title="Terminal", addScrollLabel=True)
  FFMz2e(self["keyRed"] , self.exitBtnText)
  FFMz2e(self["keyGreen"] , "OK = History")
  FFMz2e(self["keyYellow"], "Menu = Custom Cmds")
  FFMz2e(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVPHXS ,
   "cancel": self.VVombI  ,
   "menu" : self.VVvEne ,
   "last" : self.VVTtzc  ,
   "next" : self.VVTtzc  ,
   "1"  : self.VVTtzc  ,
   "2"  : self.VVTtzc  ,
   "3"  : self.VVTtzc  ,
   "4"  : self.VVTtzc  ,
   "5"  : self.VVTtzc  ,
   "6"  : self.VVTtzc  ,
   "7"  : self.VVTtzc  ,
   "8"  : self.VVTtzc  ,
   "9"  : self.VVTtzc  ,
   "0"  : self.VVTtzc
  })
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.VVHIRC)
 def VVtpg1(self):
  self["myLabel"].VVsOYo(isResizable=False, outputFileToSave="terminal")
  FFqypJ(self["keyRed"]  , "#00ff8000")
  FFOrd9(self["keyRed"]  , self.skinParam["titleColor"])
  FFOrd9(self["keyGreen"]  , self.skinParam["titleColor"])
  FFOrd9(self["keyYellow"] , self.skinParam["titleColor"])
  FFOrd9(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV144m(FFkd4T("date"), 5)
  result = FFkd4T("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVuNOD()
  if pathExists(VVVcWE):
   self.VV0sGp()
  else:
   FFB8Nz(self, 'Cannot access the path:\n\n%s' % VVVcWE)
   self.close()
 def VV0sGp(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVVcWE + "LinuxCommands.lst"
  templPath = VVobIL + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFcZm9("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFQIMd("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVHIRC(self):
  if self.container.VV8CKq():
   self.container.killAll()
   self.VV144m("Process killed\n", 4)
   self.VVuNOD()
 def VVombI(self):
  if self.container.VV8CKq():
   self.VVHIRC()
  else:
   FF5jVY(self, self.close, "Exit ?", VV3C0x=False)
 def VVuNOD(self):
  self.VV144m(self.prompt, 1)
  self["keyRed"].hide()
 def VV144m(self, txt, mode):
  if   mode == 1 : color = VVqZDD
  elif mode == 2 : color = VVEhqe
  elif mode == 3 : color = VViVXH
  elif mode == 4 : color = VVdSiQ
  elif mode == 5 : color = VVlrJC
  elif mode == 6 : color = VV6rcy
  else   : color = VViVXH
  try:
   self["myLabel"].appendText(FFwXwL(txt, color))
  except:
   pass
 def VVPHXS(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVBGIw() == "":
   self.VVC3mc("cd /tmp")
   self.VVC3mc("ls")
  VVkNlM = []
  if fileExists(self.commandHistoryFile):
   lines  = FF9z80(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVkNlM.append((str(c), line, str(lNum)))
   self.VVseP8(VVkNlM, title, self.commandHistoryFile, isHistory=True)
  else:
   FFM8jr(self, self.commandHistoryFile, title=title)
 def VVBGIw(self):
  lastLine = FFkd4T("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVC3mc(self, cmd):
  try:
   with open(self.commandHistoryFile, "a") as f:
    f.write("%s\n" % cmd)
  except Exception as e:
   FFB8Nz(self, str(e))
 def VVvEne(self, VVhqv2=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF9z80(self.customCommandsFile)
   VVkNlM = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVkNlM.append((str(c), line, str(lNum)))
   if VVhqv2:
    VVhqv2.VVartp(VVkNlM)
    VVhqv2.VVj43f(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVseP8(VVkNlM, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFM8jr(self, self.customCommandsFile, title=title)
 def VVseP8(self, VVkNlM, title, filePath=None, isHistory=False):
  if VVkNlM:
   VVSzMt = "#05333333"
   if isHistory: VVl9AY = VVLICL = VVHZxf = "#11000020"
   else  : VVl9AY = VVLICL = VVHZxf = "#06002020"
   VVlUqf   = ("Send"   , BF(self.VVNYrP, isHistory)  , [])
   VVlrMb  = ("Modify & Send" , self.VV5xhf     , [])
   if isHistory:
    VVkGmL = ("Clear History" , self.VV7nQy     , [])
    VV1FeB = None
    VVJEWY = None
   elif filePath:
    VVkGmL = ("Options"  , self.VVNHbO      , [])
    VV1FeB = ("Edit File"  , BF(self.VV9eDk, filePath) , [])
    VVJEWY = (""    , self.VVtO6R     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVrLHE = (CENTER , LEFT   , CENTER )
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB, VVJEWY=VVJEWY, lastFindConfigObj=CFG.lastFindTerminal, VVJcAk=True, searchCol=1
         , VVl9AY=VVl9AY, VVLICL=VVLICL, VVHZxf=VVHZxf, VVSzMt=VVSzMt)
   if not isHistory:
    VVhqv2.VVj43f(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FF5jVY(self, BF(self.VVvz66, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVtO6R(self, VVhqv2, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFwXwL("Command:", VVdVoc), colList[1])
  txt += "%s\n%s\n\n" % (FFwXwL("Line %s in File:" % colList[2], VVdVoc), self.customCommandsFile)
  FF3nHt(self, txt, title=title)
 def VVNHbO(self, VVhqv2, title, txt, colList):
  mSel = CCr5W8(self, VVhqv2)
  VVhIDJ = []
  txt1 = "Change Custom Commands File"
  if VVhqv2.VVVoic:
   VVhIDJ.append((txt1, ))
   VVhIDJ.append(VVuAtK)
   totSel = VVhqv2.VVv2WG()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFwXwL(totTxt, VVqZDD) if totSel else totTxt, FFW43m(totSel))
   VVhIDJ.append((txt2, "send") if totSel else (txt2,))
  else:
   VVhIDJ.append((txt1, "newFile"))
   VVhIDJ.append(VVuAtK)
   txt2 = "Send current line"
   VVhIDJ.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVvz66, VVhqv2, txt1)
     , "send" : BF(self.VVNYrP, False, VVhqv2, title, txt2, colList) }
  mSel.VVklJK(VVhIDJ, cbFncDict, okFnc=BF(self.VVgTlO, VVhqv2))
 def VVvz66(self, VVhqv2, title):
  VVhIDJ = []
  for fName in os.listdir(VVVcWE):
   path = os.path.join(VVVcWE, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVhIDJ.append((fName, path))
  VVhIDJ.sort(key=lambda x: x[0].lower())
  if VVhIDJ : FFRHhp(self, BF(self.VVHfuX, VVhqv2, title), VVhIDJ=VVhIDJ, title=title, minRows=3, VVl9AY="#11220000", VVLICL="#11220000")
  else  : FFB8Nz(self, "No valid files found in:\n\n%s" % VVVcWE, title=title)
 def VVHfuX(self, VVhqv2, title, path=None):
  if path:
   if CCf82q.VVr1AP(path):
    FFB8Nz(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF9z80(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFsMp0(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFsMp0(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVvEne(VVhqv2)
      break
    else:
     FFB8Nz(self, "File is empty:\n\n%s" % path, title=title)
 def VVgTlO(self, VVhqv2):
  if VVhqv2.VVVoic : VVhqv2.VVFwsu()
  else        : VVhqv2.VV7m1I()
 def VVNYrP(self, isHistory, VVhqv2, title, txt, colList):
  if VVhqv2.VVVoic:
   lst = VVhqv2.VVeAfz(1)
   curNdx = VVhqv2.VV3nbn()
  else:
   lst = [colList[1]]
   curNdx = VVhqv2.VVHqmL()
  if not isHistory:
   FFsMp0(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVhqv2.cancel()
  FFbn1D(self.VVsU2G)
 def VVsU2G(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VV144m("\n%s\n" % cmd, 6)
    self.VV144m(self.prompt, 1)
    self.VVsU2G()
   else:
    self.VVoF1M(cmd)
 def VVoF1M(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV144m(cmd, 2)
   self.VV144m("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV144m(ch, 0)
   self.VV144m("\nor\n", 4)
   self.VV144m("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVuNOD()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFwXwL(parts[0].strip(), VVEhqe)
    right = FFwXwL("#" + parts[1].strip(), VV6rcy)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV144m(txt, 2)
   lastLine = self.VVBGIw()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVC3mc(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV5P0p, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFB8Nz(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV144m(data, 3)
 def VV5P0p(self, data, retval):
  if not retval == 0:
   self.VV144m("Exit Code : %d\n" % retval, 4)
  self.VVuNOD()
  if self.commandsList:
   self.VVsU2G()
 def VV5xhf(self, VVhqv2, title, txt, colList):
  if VVhqv2.VVd6Ep():
   cmd = colList[1]
   self.VVFQEg(VVhqv2, cmd)
 def VV7nQy(self, VVhqv2, title, txt, colList):
  FF5jVY(self, BF(self.VVVW0k, VVhqv2), "Reset History File ?", title="Command History")
 def VVVW0k(self, VVhqv2):
  FFQIMd("> '%s'" % self.commandHistoryFile)
  VVhqv2.cancel()
 def VV9eDk(self, filePath, VVhqv2, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCwZEN(self, filePath, VVLUmk=BF(self.VV1B40, VVhqv2), curRowNum=rowNum)
  else     : FFM8jr(self, filePath)
 def VV1B40(self, VVhqv2, fileChanged):
  if fileChanged:
   VVhqv2.cancel()
   FFbn1D(self.VVvEne)
 def VVTtzc(self):
  self.VVFQEg(None, self.lastCommand)
 def VVFQEg(self, VVhqv2, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFs37j(self, BF(self.VVJntp, VVhqv2), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVJntp(self, VVhqv2, cmd):
  if cmd and len(cmd) > 0:
   self.VVoF1M(cmd)
   if VVhqv2:
    VVhqv2.cancel()
class CCR9Hh(Screen):
 def __init__(self, session, title="", message="", VVCqdo=VVDdVy, width=1400, height=900, VVfTAX=False, titleBg="#22002020", VVHZxf="#22001122", VVNWWl=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFMkht(VVegdj, width, height, titleFontSize, 30, 20, titleBg, VVHZxf, VVNWWl)
  self.session   = session
  FFTlW1(self, title, addScrollLabel=True)
  self.VVCqdo   = VVCqdo
  self.VVfTAX   = VVfTAX
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self["myLabel"].VVsOYo(VVfTAX=self.VVfTAX, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVCqdo)
  self["myLabel"].VVjhj8()
class CC3yml(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFMkht(VV2PUu, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFTlW1(self, " ", addCloser=True)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  CCwMZZ.VVpgb7(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCwKQn(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFMkht(VVDgCl, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFTlW1(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFdJ3C(self["errPic"], "err")
class CCkgIS(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFMkht(VV2PUu, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFTlW1(self, " ", addCloser=True)
class CCwMZZ():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCwMZZ.VVmeiK(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VV6IAV)
  except: self.timer.callback.append(self.VV6IAV)
  self.timer.start(timeout, True)
 def VV6IAV(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVmeiK(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCkgIS, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFnR2Y(win["myWinTitle"], shadColor, shadW)
  CCwMZZ.VVpgb7(win, txt)
  return win
 @staticmethod
 def VVpgb7(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCSDOM():
 VVaNLr    = 0
 VVCW13  = 1
 VViwRc   = ""
 VVg8sB    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVhqv2   = None
  self.timer     = eTimer()
  self.VVonvQ   = 0
  self.VV8aU8  = 1
  self.VVtlsa  = 2
  self.VV1rns   = 3
  self.VVZ8do   = 4
  VVkNlM = self.VVGKGj()
  if VVkNlM:
   self.VVhqv2 = self.VVG5YQ(VVkNlM)
  if not VVkNlM and mode == self.VVaNLr:
   self.VVqMWO("Download list is empty !")
   self.cancel()
  if mode == self.VVCW13:
   FFuMBP(self.VVhqv2 or self.SELF, BF(self.VVlSBR, startDnld, decodedUrl), title="Checking Server ...")
  self.VVf7GG(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVf7GG)
  except:
   self.timer.callback.append(self.VVf7GG)
  self.timer.start(1000, False)
 def VVG5YQ(self, VVkNlM):
  VVkNlM.sort(key=lambda x: int(x[0]))
  VVPEsb = self.VV5ypV
  VVlUqf  = ("Play"  , self.VVXMDW , [])
  VVJEWY = (""   , self.VVTCuP  , [])
  VVlpv3 = ("Stop"  , self.VVsDPI  , [])
  VVlrMb = ("Resume"  , self.VVaZdx , [])
  VVkGmL = ("Options" , self.VVHNtC  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVrLHE  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFNCSP(self.SELF, None, title=self.Title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVlUqf=VVlUqf, VVJEWY=VVJEWY, VVPEsb=VVPEsb, VVlpv3=VVlpv3, VVlrMb=VVlrMb, VVkGmL=VVkGmL, lastFindConfigObj=CFG.lastFindIptv, VVl9AY="#11220022", VVLICL="#11110011", VVHZxf="#11110011", VVSzMt="#00223025", VVvy9F="#0a333333", VVRt6l="#0a400040", VVJcAk=True, searchCol=1)
 def VVGKGj(self):
  lines = CCSDOM.VVcEGj()
  VVkNlM = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVBaYb(decodedUrl)
      if fName:
       if   FF8tzC(decodedUrl) : sType = "Movie"
       elif FFSKBc(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVZEZK(decodedUrl, fName)
       if size > -1: sizeTxt = CCf82q.VVeeDD(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVkNlM.append((str(len(VVkNlM) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVkNlM
 def VVJj99(self):
  VVkNlM = self.VVGKGj()
  if VVkNlM:
   if self.VVhqv2 : self.VVhqv2.VVartp(VVkNlM, VVEO5wMsg=False)
   else     : self.VVhqv2 = self.VVG5YQ(VVkNlM)
  else:
   self.cancel()
 def VVf7GG(self, force=False):
  if self.VVhqv2:
   thrListUrls = self.VVg83o()
   VVkNlM = []
   changed = False
   for ndx, row in enumerate(self.VVhqv2.VVOazu()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVonvQ
    if m3u8Log:
     percent = CCSDOM.VVliVo(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VV1rns , "%.2f %%" % percent
      else   : flag, progr = self.VVZ8do , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFoQQd(mPath)
     if curSize > -1:
      fSize = CCf82q.VVeeDD(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCf82q.VVeeDD(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFoQQd(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VV1rns , "%.2f %%" % percent
       else   : flag, progr = self.VVZ8do , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCf82q.VVeeDD(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVtlsa
     if m3u8Log :
      if not speed and not force : flag = self.VV8aU8
      elif curSize == -1   : self.VVY4cu(False)
    elif flag == self.VVonvQ  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVonvQ  : color2 = "#f#00555555#"
    elif flag == self.VV8aU8 : color2 = "#f#0000FFFF#"
    elif flag == self.VVtlsa : color2 = "#f#0000FFFF#"
    elif flag == self.VV1rns  : color2 = "#f#00FF8000#"
    elif flag == self.VVZ8do  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVlRVH(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVkNlM.append(row)
   if changed or force:
    self.VVhqv2.VVartp(VVkNlM, VVEO5wMsg=False)
 def VVlRVH(self, flag):
  tDict = self.VVjNgx()
  return tDict.get(flag, "?")
 def VVrqAA(self, state):
  for flag, txt in self.VVjNgx().items():
   if txt == state:
    return flag
  return -1
 def VVjNgx(self):
  return { self.VVonvQ: "Not started", self.VV8aU8: "Connecting", self.VVtlsa: "Downloading", self.VV1rns: "Stopped", self.VVZ8do: "Completed" }
 def VVdz9N(self, title):
  colList = self.VVhqv2.VVHMjy()
  path = colList[6]
  url  = colList[8]
  if self.VVHcu3() : self.VVqMWO("Cannot delete !\n\nFile is downloading.")
  else      : FF5jVY(self.SELF, BF(self.VVzaS9, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVzaS9(self, path, url):
  m3u8Log = self.VVhqv2.VVHMjy()[12]
  if m3u8Log : FFcZm9("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFcZm9("rm -rf '%s'" % path)
  self.VVgBVx(False)
  self.VVJj99()
 def VVgBVx(self, VVzp4h=True):
  if self.VVHcu3():
   FFM3N1(self.VVhqv2, self.VVlRVH(self.VVtlsa), 500)
  else:
   colList  = self.VVhqv2.VVHMjy()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVrqAA(state) in (self.VVonvQ, self.VVZ8do, self.VV1rns):
    lines = CCSDOM.VVcEGj()
    newLines = []
    found = False
    for line in lines:
     if CCSDOM.VVNjBZ(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVE38E(newLines)
     self.VVJj99()
     FFM3N1(self.VVhqv2, "Removed.", 1000)
    else:
     FFM3N1(self.VVhqv2, "Not found.", 1000)
   elif VVzp4h:
    self.VVqMWO("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVu3lA(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FF5jVY(self.SELF, BF(self.VVVaeB, flag), ques, title=title)
 def VVVaeB(self, flag):
  list = []
  for ndx, row in enumerate(self.VVhqv2.VVOazu()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVrqAA(state)
   if   flag == flagVal == self.VVZ8do: list.append(decodedUrl)
   elif flag == flagVal == self.VVonvQ : list.append(decodedUrl)
  lines = CCSDOM.VVcEGj()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVE38E(newLines)
   self.VVJj99()
   FFM3N1(self.VVhqv2, "%d removed." % totRem, 1000)
  else:
   FFM3N1(self.VVhqv2, "Not found.", 1000)
 def VVfHt0(self):
  colList  = self.VVhqv2.VVHMjy()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFM3N1(self.VVhqv2, "Poster exists", 1500)
  else    : FFuMBP(self.VVhqv2, BF(self.VVirNr, decodedUrl, path, png), title="Checking Server ...")
 def VVirNr(self, decodedUrl, path, png):
  err = self.VVUb6l(decodedUrl, path, png)
  if err:
   FFB8Nz(self.SELF, err, title="Poster Download")
 def VVUb6l(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCIbAM.VV4H6G(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC8Yh1.VVaxHl(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC8Yh1.VVfIBq(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFlHhH(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFcZm9("mv -f '%s' '%s'" % (tPath, png))
   CCuhvG.VVqol3(self.SELF, VVmyei=png, showGrnMsg="Downloaded")
   return ""
 def VVTCuP(self, VVhqv2, title, txt, colList):
  def VVNpAU(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVnxYh(key, val) : return "\n%s:\n%s\n" % (FFwXwL(key, VVdVoc), val.strip())
  heads  = self.VVhqv2.VV7cIM()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVNpAU(heads[i]  , CCf82q.VVeeDD(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVNpAU("Downloaded" , CCf82q.VVeeDD(int(curSize), mode=0))
   else:
    txt += VVNpAU(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVnxYh(heads[i], colList[i])
  FF3nHt(self.SELF, txt, title=title)
 def VVXMDW(self, VVhqv2, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCf82q.VV8VtC(self.SELF, path)
  else    : FFM3N1(self.VVhqv2, "File not found", 1000)
 def VV5ypV(self, VVhqv2):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVhqv2:
   self.VVhqv2.cancel()
  del self
 def VVHNtC(self, VVhqv2, title, txt, colList):
  c1, c2, c3 = VVHH6F, VVdSiQ, VVdVoc
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVhIDJ = []
  VVhIDJ.append((c1 + "Remove current row"       , "VVgBVx" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVhIDJ.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Delete the file (and remove from list)"  , "VVdz9N"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((resumeTxt + " Auto Resume"       , "VVLbS0" ))
  VVhIDJ.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVhIDJ.append(VVuAtK)
  cond = FF8tzC(decodedUrl)
  VVhIDJ.append(FFyXfa("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVfHt0", cond, c3))
  VVhIDJ.append(FFyXfa("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFRHhp(self.SELF, BF(self.VV8XYG, VVhqv2), VVhIDJ=VVhIDJ, title=self.Title, VVWLSA=True, width=800, VV14QT=True, VVl9AY="#1a001122", VVLICL="#1a001122")
 def VV8XYG(self, VVhqv2, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVgBVx"  : self.VVgBVx()
   elif ref == "remFinished"   : self.VVu3lA(self.VVZ8do, txt)
   elif ref == "remPending"   : self.VVu3lA(self.VVonvQ, txt)
   elif ref == "VVdz9N" : self.VVdz9N(txt)
   elif ref == "VVfHt0"  : self.VVfHt0()
   elif ref == "VVLbS0"  : FFsMp0(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFsMp0(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCf82q, mode=CCf82q.VVEWyL, jumpToFile=path)
    else    : FFM3N1(VVhqv2, "Path not found !", 1500)
 def VVlSBR(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCIbAM.VV4H6G(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVqMWO("Could not get download link !\n\nTry again later.")
     return
  for line in CCSDOM.VVcEGj():
   if CCSDOM.VVNjBZ(decodedUrl, line):
    if self.VVhqv2:
     self.VVLqUP(decodedUrl)
     FFbn1D(BF(FFM3N1, self.VVhqv2, "Already listed !", 2000))
    break
  else:
   params = self.VV5Yt4(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVqMWO(params[0])
   elif len(params) == 2:
    FF5jVY(self.SELF, BF(self.VV19Xq, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCf82q.VVeeDD(fSize)
    FF5jVY(self.SELF, BF(self.VV6PJx, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV6PJx(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCSDOM.VVZ8EY(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVJj99()
  if self.VVhqv2:
   self.VVhqv2.VVa0Kk()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCSDOM.VVg8sB, path, decodedUrl)
   self.VVWOUF(threadName, url, decodedUrl, path, resp)
 def VVLqUP(self, decodedUrl):
  if self.VVhqv2:
   for ndx, row in enumerate(self.VVhqv2.VVOazu()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVhqv2:
     self.VVhqv2.VVj43f(ndx)
     break
 def VV5Yt4(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVBaYb(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVZEZK(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCIbAM.VV4H6G(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCIbAM.VVNqjQ()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCSDOM.VV1qeD(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCSDOM.VVYwCX(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VV19Xq(self, resp, decodedUrl):
  if not FFBf4e("ffmpeg"):
   FF5jVY(self.SELF, BF(CC8Yh1.VVNEU2, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVBaYb(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVMa9i(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FF5jVY(self.SELF, BF(self.VVf3Lm, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVf3Lm(rTxt, rUrl)
  else:
   self.VVqMWO("Cannot process m3u8 file !")
 def VVMa9i(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVhIDJ = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC8Yh1.VVbtfd(rUrl, fPath)
   VVhIDJ.append((resol, fullUrl))
  if VVhIDJ:
   FFRHhp(self.SELF, self.VV4vWZ, VVhIDJ=VVhIDJ, title="Resolution", VVWLSA=True, VV14QT=True)
  else:
   self.VVqMWO("Cannot get Resolutions list from server !")
 def VV4vWZ(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FF5jVY(self.SELF, BF(FFbn1D, BF(self.VV7O34, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFbn1D(BF(self.VV7O34, resolUrl))
 def VV7O34(self, resolUrl):
  txt, err = CCIbAM.VVTbwO(resolUrl)
  if err : self.VVqMWO(err)
  else : self.VVf3Lm(txt, resolUrl)
 def VVEpCR(self, logF, decodedUrl):
  found = False
  lines = CCSDOM.VVcEGj()
  with open(CCSDOM.VVZ8EY(), "w") as f:
   for line in lines:
    if CCSDOM.VVNjBZ(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCSDOM.VVZ8EY(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVJj99()
  if self.VVhqv2:
   self.VVhqv2.VVa0Kk()
 def VVf3Lm(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC8Yh1.VVbtfd(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVqMWO("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVEpCR(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFUGBP("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCSDOM.VVg8sB, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVliVo(dnldLog):
  if fileExists(dnldLog):
   dur = CCSDOM.VVSwZN(dnldLog)
   if dur > -1:
    tim = CCSDOM.VVXy79(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVSwZN(dnldLog):
  lines = FFpNiE("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVXy79(dnldLog):
  lines = FFpNiE("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVZEZK(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFSKBc(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFcZm9("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVWOUF(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVhqv2.VVHMjy()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVLwDQ, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVLwDQ(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VViwRc == path:
       break
     else:
      break
  except:
   return
  if CCSDOM.VViwRc:
   CCSDOM.VViwRc = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFoQQd(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV5Yt4(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVLwDQ(url, decodedUrl, path, resp, totFileSize, True)
 def VVsDPI(self, VVhqv2, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVCQLr() : FFM3N1(self.VVhqv2, self.VVlRVH(self.VVZ8do), 500)
  elif not self.VVHcu3() : FFM3N1(self.VVhqv2, self.VVlRVH(self.VV1rns), 500)
  elif m3u8Log      : FF5jVY(self.SELF, self.VVY4cu, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVg83o():
    CCSDOM.VViwRc = colList[6]
    FFM3N1(self.VVhqv2, "Stopping ...", 1000)
   else:
    FFM3N1(self.VVhqv2, "Stopped", 500)
 def VVY4cu(self, withMsg=True):
  if withMsg:
   FFM3N1(self.VVhqv2, "Stopping ...", 1000)
  FFcZm9("killall -INT ffmpeg")
 def VVaZdx(self, *args):
  if   self.VVCQLr() : FFM3N1(self.VVhqv2, self.VVlRVH(self.VVZ8do) , 500)
  elif self.VVHcu3() : FFM3N1(self.VVhqv2, self.VVlRVH(self.VVtlsa), 500)
  else:
   resume = False
   m3u8Log = self.VVhqv2.VVHMjy()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FF5jVY(self.SELF, BF(self.VVbPWI, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV5xcd():
    resume = True
   if resume: FFuMBP(self.VVhqv2, BF(self.VVK5XK), title="Checking Server ...")
   else  : FFM3N1(self.VVhqv2, "Cannot resume !", 500)
 def VVbPWI(self, m3u8Log):
  FFcZm9("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFuMBP(self.VVhqv2, BF(self.VVK5XK), title="Checking Server ...")
 def VVK5XK(self):
  colList  = self.VVhqv2.VVHMjy()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCIbAM.VV4H6G(decodedUrl)
   if url:
    decodedUrl = self.VVXcpw(decodedUrl, url)
   else:
    self.VVqMWO("Could not get download link !\n\nTry again later.")
    return
  curSize = FFoQQd(path)
  params = self.VV5Yt4(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVqMWO(params[0])
   return
  elif len(params) == 2:
   self.VV19Xq(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVXcpw(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCSDOM.VVg8sB, path, decodedUrl)
  if resumable: self.VVWOUF(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVqMWO("Cannot resume from server !")
 def VVBaYb(self, decodedUrl):
  fileExt = CC8Yh1.VVpIc5(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFzKhS(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVqMWO(self, txt):
  FFB8Nz(self.SELF, txt, title=self.Title)
 def VVg83o(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCSDOM.VVg8sB, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVHcu3(self):
  decodedUrl = self.VVhqv2.VVHMjy()[9]
  return decodedUrl in self.VVg83o()
 def VVCQLr(self):
  colList = self.VVhqv2.VVHMjy()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFoQQd(path)) == size
 def VV5xcd(self):
  colList = self.VVhqv2.VVHMjy()
  path = colList[6]
  size = int(colList[7])
  curSize = FFoQQd(path)
  if curSize > -1:
   size -= curSize
  err = CCSDOM.VVYwCX(size)
  if err:
   FFB8Nz(self.SELF, err, title=self.Title)
   return False
  return True
 def VVE38E(self, list):
  with open(CCSDOM.VVZ8EY(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVXcpw(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCSDOM.VVcEGj()
  url = decodedUrl
  with open(CCSDOM.VVZ8EY(), "w") as f:
   for line in lines:
    if CCSDOM.VVNjBZ(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVJj99()
  return url
 @staticmethod
 def VVcEGj():
  list = []
  if fileExists(CCSDOM.VVZ8EY()):
   for line in FF9z80(CCSDOM.VVZ8EY()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVNjBZ(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVYwCX(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCf82q.VVHPLs(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCf82q.VVeeDD(size), CCf82q.VVeeDD(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVje3g(SELF):
  tot = CCSDOM.VV1qOR()
  if tot:
   FFB8Nz(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV1qOR():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCSDOM.VVg8sB):
    c += 1
  return c
 @staticmethod
 def VVDNZq():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCSDOM.VVg8sB, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVDxIp():
  return len(CCSDOM.VVcEGj()) == 0
 @staticmethod
 def VVhElr():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVgyuz():
  mPoints = CCSDOM.VVhElr()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFcZm9("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVZ8EY():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VV2g5x(SELF, waitMsgObj=None):
  FFuMBP(waitMsgObj or SELF, BF(CCSDOM.VVCeu3, SELF, CCSDOM.VVaNLr))
 @staticmethod
 def VVGDnL(SELF):
  CCSDOM.VVCeu3(SELF, CCSDOM.VVCW13, startDnld=True)
 @staticmethod
 def VVotcn(SELF, url):
  CCSDOM.VVCeu3(SELF, CCSDOM.VVCW13, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVkzef(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF)
  added, skipped = CCSDOM.VVp0TY([decodedUrl])
  FFM3N1(SELF, "Added", 1000)
 @staticmethod
 def VVp0TY(list):
  added = skipped = 0
  for line in CCSDOM.VVcEGj():
   for ndx, url in enumerate(list):
    if url and CCSDOM.VVNjBZ(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCSDOM.VVZ8EY(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVCeu3(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCskCr.VVztta(SELF):
   return
  if mode == CCSDOM.VVaNLr and CCSDOM.VVDxIp():
   FFB8Nz(SELF, "Download list is empty !", title=title)
  else:
   inst = CCSDOM(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VV1qeD(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCqLbA(Screen, CCwwJU):
 VVoQCR = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFMkht(VVPN5p, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCwwJU.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFTlW1(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVdaGB())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVyASM,
  {
   "ok"  : self.VVYfT9       ,
   "info"  : self.VVynXw      ,
   "epg"  : self.VVynXw      ,
   "menu"  : self.VVVKgW     ,
   "cancel" : self.cancel       ,
   "red"  : self.VV8jOF   ,
   "green"  : self.VVUpp4  ,
   "blue"  : self.VVSc2w      ,
   "yellow" : self.VV15g1 ,
   "left"  : BF(self.VVB0Hy, -1)    ,
   "right"  : BF(self.VVB0Hy,  1)    ,
   "play"  : self.VVrw5i      ,
   "pause"  : self.VVrw5i      ,
   "playPause" : self.VVrw5i      ,
   "stop"  : self.VVrw5i      ,
   "rewind" : self.VVwQFp      ,
   "forward" : self.VVokGP      ,
   "rewindDm" : self.VVwQFp      ,
   "forwardDm" : self.VVokGP      ,
   "last"  : self.VVYYMg      ,
   "next"  : self.VVZsM1      ,
   "pageUp" : BF(self.VVN8od, True)  ,
   "pageDown" : BF(self.VVN8od, False)  ,
   "chanUp" : BF(self.VVN8od, True)  ,
   "chanDown" : BF(self.VVN8od, False)  ,
   "up"  : BF(self.VVN8od, True)  ,
   "down"  : BF(self.VVN8od, False)  ,
   "audio"  : BF(self.VVWiRZ, True)  ,
   "subtitle" : BF(self.VVWiRZ, False)  ,
   "text"  : self.VVw78D  ,
   "0"   : BF(self.VVaYVq , 10)   ,
   "1"   : BF(self.VVaYVq , 1)   ,
   "2"   : BF(self.VVaYVq , 2)   ,
   "3"   : BF(self.VVaYVq , 3)   ,
   "4"   : BF(self.VVaYVq , 4)   ,
   "5"   : BF(self.VVaYVq , 5)   ,
   "6"   : BF(self.VVaYVq , 6)   ,
   "7"   : BF(self.VVaYVq , 7)   ,
   "8"   : BF(self.VVaYVq , 8)   ,
   "9"   : BF(self.VVaYVq , 9)
  }, -1)
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  if not CCqLbA.VVoQCR:
   CCqLbA.VVoQCR = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFdJ3C(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFdJ3C(self["myPlayRpt"], "rpt")
  self.VVl12g()
  self.instance.move(ePoint(40, 40))
  self.VVTZp2(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViL7X)
  except:
   self.timer.callback.append(self.VViL7X)
  self.timer.start(250, False)
  self.VViL7X("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVr84v()
 def VVUpp4(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  self.lastSubtitle = CCyP4s.VViLWu()
  if "chCode" in iptvRef:
   if CCskCr.VVztta(self):
    self.VVr84v(True)
  else:
   self.VViL7X("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVl12g(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGBy7()
  chName = FFpdHF(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVeCLm + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFOrd9(self["myTitle"], tColor)
  FFOrd9(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFOrd9(self["myPlay%s" % item], tColor)
  picFile = ""
  if not iMatch("^\d*:(0:){9}\/.+", refCode):
   picFile = CCscAN.VVllaU(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCscAN.VVGaIS(self)
  cl = CCpfQt.VV8yot(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VViL7X(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCSDOM.VV1qOR()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGBy7()
  if evName:
   evName = "    %s    " % FFwXwL(evName, VVlrJC)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVKJI5():
   FFqypJ(self["myPlayBlu"], "#00FFFFFF")
   FFOrd9(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFqypJ(self["myPlayBlu"], "#00FFFF88")
   FFOrd9(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CC8Yh1.VVn9n1(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VV6rcy + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFOrd9(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFYuUY(percVal, 0, 100)
   width = int(FFdPXt(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFOrd9(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFqypJ(self["myPlayMsg"], "#0000ffff")
   else  : FFqypJ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFqypJ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFqypJ(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVWrms()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVcxkG(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCyP4s.VVuJdx(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVYYMg()
  state = self.VVTbP7()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFqypJ(self["myPlayMsg"], "#0000ff00")
  else     : FFqypJ(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVGBy7(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFWctZ(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCscAN.VVPHoh(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCpNxn()
   tpTxt, satTxt = tp.VVsB6f(refCode)
   self.satInfo_TP = tpTxt + "  " + FFwXwL(satTxt, VVmvsU)
  evName = evNameNext = ""
  evLst = CCwOKQ.VVbLnn(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFtI1N(info, iServiceInformation.sVideoWidth) or -1
   h = FFtI1N(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFtI1N(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCscAN.VVPrsu(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVCqHv(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFdy8f(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFdy8f(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFdy8f(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVVKgW(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGBy7()
  FF8tzCSeries = FFzKhS(decodedUrl)
  VVhIDJ = []
  if not "VViG77" in globals() and not "VVsQQd" in globals():
   VVhIDJ.append((VVmvsU + "IPTV Menu", "iptv"))
   VVhIDJ.append(VVuAtK)
  if isIptv and not "&end=" in decodedUrl and not FF8tzCSeries:
   uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVhIDJ.append((VVmvsU + "Catchup Programs", "catchup" ))
    VVhIDJ.append(VVuAtK)
  if refCode:
   c = VVeCLm
   VVhIDJ.append((c + "Stop Current Service"  , "stop"  ))
   VVhIDJ.append((c + "Restart Current Service" , "restart"  ))
   VVhIDJ.append(FFyXfa("Replay with ..." , "replayWith", not isDvb, c))
   VVhIDJ.append(VVuAtK)
  if FF8tzCSeries:
   VVhIDJ.append((VVmvsU + "File Size (on server)", "fileSize" ))
   VVhIDJ.append(VVuAtK)
  if self.enableDownloadMenu:
   c = VVmvsU
   addSep = False
   if isIptv and FF8tzCSeries:
    VVhIDJ.append((c + "Start Download"  , "dload_cur" ))
    VVhIDJ.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCSDOM.VVDxIp():
    VVhIDJ.append((VVmvsU + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVhIDJ.append(VVuAtK)
  fPath, fDir, fName = CCf82q.VVs3Cw(self)
  if fPath:
   c = VVuj5g
   if not "VVB2qN" in globals():
    VVhIDJ.append((c + "Open path in File Manager", "VVax1N"))
   VVhIDJ.append((c + "Add to Bouquet"             , "VVoH1o" ))
   VVhIDJ.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVGSwL"  ))
   VVhIDJ.append(VVuAtK)
  elif isFtp:
   VVhIDJ.append((VVdVoc + "Add FTP Media to Bouquet"     , "VVMGMa"))
  if isDvb:
   VVhIDJ.append((VVmvsU + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVhIDJ.append((VVdVoc + "Start Subtitle", "VV9Rqm"))
  if isDvb or posTxt and durTxt:
   VVhIDJ.append(VVuAtK)
  if CFG.playerPos.getValue() : VVhIDJ.append(("Move Bar to Bottom" , "botm"))
  else      : VVhIDJ.append(("Move Bar to Top" , "top" ))
  VVhIDJ.append(("Help", "help"))
  FFRHhp(self, self.VVjoBk, VVhIDJ=VVhIDJ, width=600, title="Options")
 def VVjoBk(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VV15g1()
   elif item == "stop"     : self.VV8i7w(0)
   elif item == "restart"    : self.VV8i7w(1)
   elif item == "replayWith"   : self.VVWdF2()
   elif item == "fileSize"    : FFuMBP(self, BF(CCscAN.VVODqh, self), title="Checking Server")
   elif item == "dload_cur"   : CCSDOM.VVGDnL(self)
   elif item == "addToDload"   : CCSDOM.VVkzef(self)
   elif item == "dload_stat"   : CCSDOM.VV2g5x(self)
   elif item == "VVax1N" : self.close("close_openInFileMan")
   elif item == "VVoH1o" : self.VVoH1o()
   elif item == "VVMGMa" : self.VVMGMa()
   elif item == "VV9Rqm"  : self.VV9DVn()
   elif item == "VVGSwL"  : self.VVGSwL()
   elif item == "botm"     : self.VVTZp2(0)
   elif item == "top"     : self.VVTZp2(1)
   elif item == "sigMon"    : self.VV8jOF()
   elif item == "help"     : FFYqxx(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCqLbA.VVoQCR = None
 def VV8i7w(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVl12g()
   elif typ == 1:
    self.VViL7X("Restarting Service ...")
    FFbn1D(BF(self.VVykJF, serv))
 def VVykJF(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if "&end=" in decodedUrl: BF(self.VVr84v, True)
  else     : self.session.nav.playService(serv)
 def VVWdF2(self):
  FFRHhp(self, self.VVzdMC, VVhIDJ=CC8Yh1.VVgMAZ(), width=650, title="Select Player", VVl9AY="#11220000", VVLICL="#11220000")
 def VVzdMC(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFFprm(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VViL7X("No active service !")
 def VVoH1o(self):
  fPath, fDir, fName = CCf82q.VVs3Cw(self)
  if fPath: picker = CCJEC1(self, self, "Add Current Movie to a Bouquet", BF(self.VVTFzc, [fPath]))
  else : FFM3N1(self, "Path not found !", 1500)
 def VVTFzc(self, pathLst):
  return CCJEC1.VVaU4W(pathLst)
 def VVMGMa(self):
  picker = CCJEC1(self, self, "Add FTP Media to Bouquet", self.VVK2r3)
 def VVK2r3(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  return CCJEC1.VVaU4W([origUrl], rType=refCode.split(":", 1)[0])
 def VVGSwL(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VViL7X(txt, highlight=ok)
 def VVTZp2(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFsMp0(CFG.playerPos, pos)
 def VV8jOF(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCscAN.VVPHoh(serv)
   if isDvb: self.close("close_sig")
   else : self.VViL7X("No Signal for Current Service")
 def VV9DVn(self):
  self.session.openWithCallback(self.VV8xcX, BF(CCyP4s))
 def VVw78D(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGBy7()
   if posTxt and durTxt: self.VV9DVn()
   else    : self.VViL7X("No duration Info. !")
 def VV8xcX(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVN8od(True)
  elif reason == "subtZapDn" : self.VVN8od(False)
  elif reason == "pause"  : self.VVrw5i()
  elif reason == "audio"  : self.VVWiRZ(True)
  elif reason == "subtitle" : self.VVWiRZ(False)
  elif reason == "rewind"     : self.VVwQFp()
  elif reason == "forward" : self.VVokGP()
  elif reason == "rewindDm" : self.VVwQFp()
  elif reason == "forwardDm" : self.VVokGP()
  else      : txt = reason
  if txt:
   FFM3N1(self, txt, 2000)
 def VVYfT9(self):
  if self.isManualSeek:
   self.VVrBmq()
   self.VVcxkG(self.manualSeekPts)
  elif self.shown:
   if CCyP4s.VVx18n(self): self.VV9DVn()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVrBmq()
  else    : self.close()
 def VVynXw(self):
  FFcAqb(self, fncMode=CCscAN.VVzA1c)
 def VVrw5i(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VViL7X("Toggling Play/Pause ...")
 def VVrBmq(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVB0Hy(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVHSfO()
   else:
    self.manualSeekSec += direc * self.VVHSfO()
    self.manualSeekSec = FFYuUY(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFdPXt(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFdy8f(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVaYVq(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVdaGB())
   FFsMp0(CFG.playerJumpMin, self.jumpMinutes)
  self.VViL7X("Changed Seek Time to : %d%s" % (val, self.VV0Lir()))
 def VVdaGB(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV0Lir())
 def VV0Lir(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVSoYM(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVHSfO(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVWrms(self):
  if "VVM9go" in globals():
   global VVM9go
   if VVM9go:
    VVM9go = VVM9go[1:-1]
    if len(VVM9go) == 3: VVM9go = ""
    else     : return VVM9go
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVSc2w(self):
  cList = self.VVKJI5()
  if cList:
   VVhIDJ = []
   for pts, what in cList:
    txt = FFdy8f(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVhIDJ.append((txt, pts))
   FFRHhp(self, self.VVvfhP, VVhIDJ=VVhIDJ, title="Cut List")
  else:
   self.VViL7X("No Cut-List for this channel !")
 def VVvfhP(self, item=None):
  if item:
   self.VVcxkG(item)
 def VVKJI5(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVokGP(self) : self.VVivnD(1)
 def VVwQFp(self) : self.VVivnD(-1)
 def VVivnD(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVHSfO() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVSoYM())
    self.VViL7X(txt)
  except:
   self.VViL7X("Cannot jump")
 def VVcxkG(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VViL7X("Changing Time ...")
 def VVYYMg(self):
  self.VV8i7w(1)
  self.VViL7X("Replaying ...")
  self.VVrBmq()
 def VVZsM1(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VViL7X("Jumping to end ...")
  except:
   pass
 def VVTbP7(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVN8od(self, isUp):
  if self.enableZapping:
   self.VViL7X("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVrBmq()
   if self.iptvTableParams:
    FFbn1D(BF(self.VVT0zT, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
    if "/timeshift/" in decodedUrl:
     self.VViL7X("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVQBcI()
  else:
   self.VViL7X("Zap Disabled !")
 def VVQBcI(self):
  self.lastPlayPos = 0
  self.VVl12g()
  self.VVr84v()
 def VVT0zT(self, isUp):
  CC8Yh1_inatance, VVhqv2, mode = self.iptvTableParams
  if isUp : VVhqv2.VVE1dG()
  else : VVhqv2.VVgtBs()
  colList = VVhqv2.VVHMjy()
  if mode == "localIptv":
   chName, chUrl = CC8Yh1_inatance.VV16SF(VVhqv2, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC8Yh1_inatance.VV7roc(VVhqv2, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC8Yh1_inatance.VV1efs(mode, VVhqv2, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC8Yh1_inatance.VVcZNb(mode, VVhqv2, colList)
  else:
   self.VViL7X("Cannot Zap")
   return
  FFtU9E(self, chUrl, VVpkYJ=False)
  self.VVQBcI()
 def VVr84v(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
   if not self.VVj8He(refCode, chName, decodedUrl, iptvRef):
    return
   self.VViL7X("Refreshing Portal")
   FFbn1D(self.VV4Ouu)
  except:
   pass
 def VV4Ouu(self):
  self.restoreLastPlayPos = self.VVemSS()
 def VV15g1(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
  if not decodedUrl or FFzKhS(decodedUrl):
   self.VViL7X("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC8Yh1.VVYuLl(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VViL7X("Reading Program List ...")
   ok_fnc = BF(self.VV9lX5, refCode, chName, streamId, uHost, uUser, uPass)
   FFbn1D(BF(CC8Yh1.VVVLLg, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VViL7X("Cannot process this channel")
 def VV9lX5(self, refCode, chName, streamId, uHost, uUser, uPass, VVhqv2, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVhqv2.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VViL7X("Changing Program ...")
   FFbn1D(BF(self.VVAVUN, chUrl))
  else:
   self.VViL7X("Incorrect Timestamp !")
 def VVAVUN(self, chUrl):
  FFtU9E(self, chUrl, VVpkYJ=False)
  self.lastPlayPos = 0
  self.VVl12g()
 def VVWiRZ(self, isAudio):
  try:
   VVOzoq = InfoBar.instance
   if VVOzoq:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVOzoq)
    else  : self.session.open(SubtitleSelection, VVOzoq)
  except:
   pass
 @staticmethod
 def VVbrci(session, mode=None):
  if   mode == "close_sig"   : FFUcYA(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CC8Yh1)
  elif mode == "close_openInFileMan" : session.open(CCf82q, gotoMovie=True)
 @staticmethod
 def VVZoRN(session, **kwargs):
  session.openWithCallback(BF(CCqLbA.VVbrci, session), CCqLbA, **kwargs)
class CCPshn(Screen):
 def __init__(self, session, title="", VVZNNf="Continue?", VV3C0x=True, VVQk5i=False):
  self.skin, self.skinParam = FFMkht(VVWvtV, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVZNNf = VVZNNf
  self.VVQk5i = VVQk5i
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV3C0x : VVhIDJ = [no , yes]
  else   : VVhIDJ = [yes, no ]
  FFTlW1(self, title, VVhIDJ=VVhIDJ, addLabel=True)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok" : self.VVYfT9 ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVZNNf)
  if self.VVQk5i:
   self["myLabel"].instance.setHAlign(0)
  self.VVAKiu()
  FFjM4Z(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFCkpW(self["myMenu"])
  FF478Y(self, self["myMenu"])
 def VVYfT9(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVAKiu(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCFDvX(Screen):
 def __init__(self, session, title="", VVhIDJ=None, width=1000, height=850, VVNWWl=30, barText="", minRows=1, VVvXZx=None, VVW4TT=None, VVMVWG=None, VVbPo7=None, VVVW3K=None, VVzwta=None, VVWLSA=False, VV14QT=False, VV8Vs4=None, VVdCOS=True, VVl9AY="#22003344", VVLICL="#22002233"):
  self.skin, self.skinParam = FFMkht(VV35C4, width, height, 50, 40, 30, VVl9AY, VVLICL, VVNWWl, barHeight=40, topRightBtns=3 if VVW4TT else 0)
  self.session   = session
  self.VVhIDJ   = VVhIDJ
  self.barText   = barText
  self.minRows   = minRows
  self.VVvXZx   = VVvXZx
  self.VVW4TT   = VVW4TT
  self.VVMVWG   = VVMVWG
  self.VVbPo7  = VVbPo7
  self.VVVW3K  = ("Delete File", BF(self.VVsweq, VV8Vs4)) if not VV8Vs4 is None else VVVW3K
  self.VVzwta   = VVzwta
  self.VVWLSA  = VVWLSA
  self.VV14QT  = VV14QT
  self.Title    = title
  FFTlW1(self, title, VVhIDJ=VVhIDJ)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok"  : self.VVYfT9    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVIglv   ,
   "red"  : self.VVl1A6   ,
   "green"  : self.VVEU7z   ,
   "yellow" : self.VVegJC   ,
   "blue"  : self.VVLxwz   ,
   "pageUp" : self.VVBlP9 ,
   "chanUp" : self.VVBlP9 ,
   "pageDown" : self.VVlBoU  ,
   "chanDown" : self.VVlBoU  ,
   "0"   : BF(self.VVDIwO, 0) ,
   "1"   : BF(self.VVDIwO, 1) ,
   "2"   : BF(self.VVDIwO, 2) ,
   "3"   : BF(self.VVDIwO, 3) ,
   "4"   : BF(self.VVDIwO, 4) ,
   "5"   : BF(self.VVDIwO, 5) ,
   "6"   : BF(self.VVDIwO, 6) ,
   "7"   : BF(self.VVDIwO, 7) ,
   "8"   : BF(self.VVDIwO, 8) ,
   "9"   : BF(self.VVDIwO, 9)
  }, -1)
  if VVdCOS:
   FFNuVS(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFjM4Z(self["myMenu"])
  FFH94q(self, minRows=self.minRows)
  FFfgOw(self)
  self.VVgP5b(self["keyRed"]  , self.VVMVWG )
  self.VVgP5b(self["keyGreen"] , self.VVbPo7 )
  self.VVgP5b(self["keyYellow"] , self.VVVW3K )
  self.VVgP5b(self["keyBlue"]  , self.VVzwta )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF3wB4(self)
 def VVgP5b(self, btnObj, btnFnc):
  if btnFnc:
   FFMz2e(btnObj, btnFnc[0])
 def VVuGKw(self, fnc=None):
  self.VVbPo7 = fnc
  if fnc : self.VVgP5b(self["keyGreen"], self.VVbPo7)
  else : self["keyGreen"].hide()
 def VVDIwO(self, digit):
  digit = str(digit)
  VVhIDJ = self["myMenu"].list
  for ndx, item in enumerate(VVhIDJ):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFpdHF(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVflXp(ndx)
     self.VVYfT9()
     break
 def VVYfT9(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVvXZx:
    self.VVvXZx((self, txt, ref, ndx))
   else:
    if self.VVWLSA: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVIglv(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVW4TT and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVW4TT(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVl1A6(self)  : self.VVyD0n(self.VVMVWG)
 def VVEU7z(self) : self.VVyD0n(self.VVbPo7)
 def VVegJC(self) : self.VVyD0n(self.VVVW3K)
 def VVLxwz(self) : self.VVyD0n(self.VVzwta)
 def VVyD0n(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV14QT:
    self.cancel()
 def VVORMC(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVhIDJ = self["myMenu"].list
  VVhIDJ.pop(ndx)
  if len(VVhIDJ) > 0: self["myMenu"].setList(VVhIDJ)
  else    : self.close()
 def VVsweq(self, basePath, menuObj, fName):
  FF5jVY(self, BF(self.VV8QoL, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VV8QoL(self, path):
  FFZ5Mj(path)
  if fileExists(path) : FFM3N1(self, "Not deleted", 1000)
  else    : self.VVORMC()
 def VV4UQJ(self, VVhIDJ):
  if len(VVhIDJ) > 0:
   newList = []
   for item in VVhIDJ:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFH94q(self, minRows=self.minRows)
  else:
   self.close("")
 def VVcn0L(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFH94q(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVPYy0(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVflXp(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVKAoY(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVflXp(ndx)
    break
 def VVjcmp(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVflXp(ndx)
    break
 def VVBlP9(self) : self["myMenu"].moveToIndex(0)
 def VVlBoU(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCajLx(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVFWkP=None, VVrLHE=None, VVN1SU=None, VVNWWl=26, isEditor=False, addSort=True, VVJcAk=False, VVOOaR=0, picParams=None, VVlUqf=None, VVJEWY=None, menuButtonFnc=None, VVlpv3=None, VVlrMb=None, VVkGmL=None, VV1FeB=None, VVNgbt=None, VVNBO3=None, VVPEsb=None, VVv8tN=-1, VVUMPl=0, searchCol=0, lastFindConfigObj=None, VVl9AY="#22003344", VVLICL="#22002233", VVteM9="#00dddddd", VVHZxf="#11002233", VVgLJ3=None, VVSzMt="#11111111", borderWidth=1, VVvy9F="#0a555555", VVZbuu="#0affffff", VVRt6l="#11552200", VVmovW="#0055ff55", VVmovWRev="#0000bbff"):
  self.skin, self.skinParam = FFMkht(VVBxpZ, width, height, 50, 10, vMargin, VVl9AY, VVLICL, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFTlW1(self, title)
  self.Title     = title
  self.header     = header
  self.VVFWkP     = VVFWkP
  self.totalCols    = len(VVFWkP[0])
  self.VVOOaR   = VVOOaR
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVJcAk   = VVJcAk
  self.VVKbDO   = 0.01
  self.VVN00W   = 0.02
  self.VVKDzl = 0.03
  self.VVtRCF  = 1
  self.VVN1SU = VVN1SU
  self.colWidthPixels   = []
  self.VVlUqf   = VVlUqf
  self.OKButtonObj   = None
  self.VVJEWY   = VVJEWY
  self.VVlpv3   = VVlpv3
  self.VVlrMb   = VVlrMb
  self.VVkGmL  = VVkGmL
  self.VV1FeB   = VV1FeB
  self.VVNgbt    = VVNgbt
  self.VVNBO3   = VVNBO3
  self.tableRefreshCB   = None
  self.VVPEsb  = VVPEsb
  self.menuButtonFnc   = menuButtonFnc
  self.VVv8tN    = VVv8tN
  self.VVUMPl   = VVUMPl
  self.searchCol    = searchCol
  self.VVrLHE    = VVrLHE
  self.keyPressed    = -1
  self.VVNWWl    = FFsuww(VVNWWl)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VV97fw    = FFYlXF(self.VVNWWl, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVl9AY    = VVl9AY
  self.VVLICL      = VVLICL
  self.VVteM9    = FFwQZC(VVteM9)
  self.VVHZxf    = FFwQZC(VVHZxf)
  self.VVgLJ3    = VVgLJ3
  self.VVSzMt    = FFwQZC(VVSzMt)
  self.borderWidth   = borderWidth
  self.VVvy9F   = FFwQZC(VVvy9F)
  self.VVZbuu    = FFwQZC(VVZbuu)
  self.VVRt6l    = FFwQZC(VVRt6l)
  self.VVmovW   = FFwQZC(VVmovW)
  self.VVmovWRev  = FFwQZC(VVmovWRev)
  self.VVVoic  = False
  self.selectedItems   = 0
  self.VVTX33   = FFwQZC("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVUMPl:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVUMPl == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok"  : self.VVpnjd  ,
   "red"  : self.VVxiW4  ,
   "green"  : self.VVYsSS ,
   "yellow" : self.VVv887 ,
   "blue"  : self.VVIdyp  ,
   "menu"  : self.VVCeU5 ,
   "info"  : self.VVHhJn  ,
   "cancel" : self.VVT55e  ,
   "up"  : self.VVgtBs    ,
   "down"  : self.VVE1dG  ,
   "left"  : self.VVn9SE   ,
   "right"  : self.VV7l89  ,
   "next"  : self.VVoDWM  ,
   "last"  : self.VV9zTH  ,
   "home"  : self.VVxJLU  ,
   "pageUp" : self.VVxJLU  ,
   "chanUp" : self.VVxJLU  ,
   "end"  : self.VVa0Kk  ,
   "pageDown" : self.VVa0Kk  ,
   "chanDown" : self.VVa0Kk
  }, -1)
  FFNuVS(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  try:
   self.VVkty2()
  except Exception as e:
   FFB8Nz(self, str(e), title=self.Title)
   self.close(None)
 def VVkty2(self):
  FF3wB4(self)
  self.VVgP5b(self.VVlpv3 , self["keyRed"])
  self.VVgP5b(self.VVlrMb , self["keyGreen"])
  self.VVgP5b(self.VVkGmL, self["keyYellow"])
  self.VVgP5b(self.VV1FeB , self["keyBlue"])
  if self.VVlUqf:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVlUqf[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVlUqf[0])
    FFOrd9(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV97fw)
  self["myTableH"].l.setFont(0, gFont(VVa2lu, self.VVNWWl))
  self["myTable"].l.setItemHeight(self.VV97fw)
  self["myTable"].l.setFont(0, gFont(VVa2lu, self.VVNWWl))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV97fw)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV97fw))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV97fw)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV97fw
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV97fw * len(self.VVFWkP) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVN1SU:
   self.VVN1SU = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVN1SU)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVrLHE:
   self.VVrLHE = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVrLHE
   self.VVrLHE = []
   for item in tmpList:
    self.VVrLHE.append(item | RT_VALIGN_CENTER)
  self.VVVxzU()
  if self.VVNgbt:
   self.VVNgbt(self)
 def VVgP5b(self, btnFnc, btn):
  if btnFnc : FFMz2e(btn, btnFnc[0])
  else  : FFMz2e(btn, "")
 def VVa0Eq(self, waitTxt):
  FFuMBP(self, self.VVVxzU, title=waitTxt)
 def VVVxzU(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVmovWRev if self.lastSortModeIsReverese else self.VVmovW
    self["myTableH"].setList([self.VVegOb(0, self.header, self.VVZbuu, self.VVRt6l, None, self.VVRt6l, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVFWkP):
    self["myTable"].list.append(self.VVegOb(c, row, self.VVteM9, self.VVHZxf, self.VVgLJ3, self.VVSzMt, None))
   self.VVFWkP = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVv8tN > -1:
    self["myTable"].moveToIndex(self.VVv8tN )
   self.VVB9mJ()
   if self.VVUMPl:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV97fw * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFYyVW(self, width, newH)
   if self.VVNBO3:
    self.VVyD0n(self.VVNBO3, None)
   if self.tableRefreshCB:
    self.VVyD0n(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFB8Nz(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVegOb(self, keyIndex, columns, VVteM9, VVHZxf, VVgLJ3, VVSzMt, VVmovW):
  row = [keyIndex]
  if VVgLJ3:
   VVgLJ3 = FFwQZC(VVgLJ3)
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVmovW and ndx == self.VVOOaR : textColor = VVmovW
   else           : textColor = VVteM9
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFwQZC(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVHZxf = c
    entry = span.group(3)
   if not self.isEditor and self.VVrLHE[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV97fw)
           , font   = 0
           , flags   = self.VVrLHE[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVHZxf
           , color_sel  = VVgLJ3 or textColor
           , backcolor_sel = VVSzMt
           , border_width = self.borderWidth
           , border_color = self.VVvy9F
           ))
   posX += self.colWidthPixels[ndx]
  if not VVmovW and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCajLx.VVG9jM(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VV97fw-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVHhJn(self):
  rowData = self.VVg9kW()
  if rowData:
   title, txt, colList = rowData
   if self.VVJEWY:
    fnc  = self.VVJEWY[1]
    params = self.VVJEWY[2]
    fnc(self, title, txt, colList)
   else:
    FF3nHt(self, txt, title)
 def VVpnjd(self):
  if   self.VVVoic : self.VVLZsf(self.VVHqmL(), mode=2)
  elif self.VVlUqf  : self.VVyD0n(self.VVlUqf, None)
  else      : self.VVHhJn()
 def VVxiW4(self) : self.VVyD0n(self.VVlpv3 , self["keyRed"])
 def VVYsSS(self) : self.VVyD0n(self.VVlrMb , self["keyGreen"])
 def VVv887(self): self.VVyD0n(self.VVkGmL , self["keyYellow"])
 def VVIdyp(self) : self.VVyD0n(self.VV1FeB , self["keyBlue"])
 def VVyD0n(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFM3N1(self, buttonFnc[3])
    FFbn1D(BF(self.VVbz9d, buttonFnc))
   else:
    self.VVbz9d(buttonFnc)
 def VVbz9d(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVg9kW()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVLZsf(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVTX33
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVHZxf
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVTX33
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVHqmL() < len(self["myTable"].list) - 1 : self.VVE1dG()
   else              : self.VVB9mJ()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVsR9P(self)  : FFuMBP(self, BF(self.VVGUdG, True ), title="Selecting all ..."  )
 def VVqXj9(self) : FFuMBP(self, BF(self.VVGUdG, False), title="Unselecting all ...")
 def VVGUdG(self, isSel=True):
  if isSel:
   bg = self.VVTX33
   self.selectedItems = len(self["myTable"].list)
   self.VVAHRi(True)
  else:
   bg = self.VVHZxf
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVTX33
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVg9kW(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVN1SU[i] > 1 or self.VVN1SU[i] == self.VVKbDO or self.VVN1SU[i] == self.VVKDzl:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVT55e(self):
  self["myTable"].onSelectionChanged = []
  if self.VVPEsb : self.VVPEsb(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VV34q2(self):
  return self["myTitle"].getText().strip()
 def VV7cIM(self):
  return self.header
 def VVUQf7(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVyzss(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFqypJ(self["myBar"], color)
 def VVrUMm(self, txt):
  FFM3N1(self, txt)
 def VVomXH(self, txt, Time=1000):
  FFM3N1(self, txt, Time)
 def VV7m1I(self): self["keyGreen"].show()
 def VVFwsu(self): self["keyGreen"].hide()
 def VVd6Ep(self): return self["keyGreen"].visible
 def VV0Sa3(self):
  FFM3N1(self)
 def VVAuRJ(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVczIx(self):
  return len(self["myTable"].list)
 def VVHqmL(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVfbKq(self):
  return len(self["myTable"].list)
 def VVAHRi(self, isOn):
  self.VVVoic = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VV1FeB: self["keyBlue"].hide()
   if self.VVlUqf and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVl9AY
   self["keyMenu"].show()
   if self.VV1FeB: self["keyBlue"].show()
   if self.VVlUqf and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVlUqf[0])
   self.VVqXj9()
  FFOrd9(self["myTitle"], color)
  FFOrd9(self["myBar"]  , color)
 def VVNb4j(self):
  return self.VVVoic
 def VVv2WG(self):
  return self.selectedItems
 def VVzAvj(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVB9mJ()
 def VVhYUR(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVNhV9(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVczIx()
  txt += FF6F4t("Total Unique Items", VVdSiQ)
  for i in range(self.totalCols):
   if self.VVN1SU[i - 1] > 1 or self.VVN1SU[i - 1] == self.VVKbDO or self.VVN1SU[i - 1] == self.VVKDzl:
    name, tot = self.VVhYUR(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF3nHt(self, txt)
 def VV26F4(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVHMjy(self):
  return self.VVregv(self["myTable"].l.getCurrentSelectionIndex())
 def VVregv(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVartp(self, newList, newTitle="", VVEO5wMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVUQf7(newTitle)
  if newList:
   self.VVFWkP = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVJcAk and self.VVOOaR == 0:
    isNum = True
   else:
    for cols in self.VVFWkP:
     if not FFt95z(cols[self.VVOOaR]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVFWkP.sort(key=lambda x: int(x[self.VVOOaR])  , reverse=self.lastSortModeIsReverese)
    else : self.VVFWkP.sort(key=lambda x: x[self.VVOOaR].lower() , reverse=self.lastSortModeIsReverese)
   if VVEO5wMsg : self.VVa0Eq("Refreshing ...")
   else   : self.VVVxzU()
  else:
   FFB8Nz(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVmgjb(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVegOb(self.VVfbKq(), row, self.VVteM9, self.VVHZxf, self.VVgLJ3, self.VVSzMt, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVa0Kk()
 def VVCuQK(self):
  self["myTable"].list.pop(self.VVHqmL())
  self["myTable"].l.setList(self["myTable"].list)
 def VVuBFc(self, data):
  ndx = self.VVHqmL()
  newRow = self.VVegOb(ndx, data, self.VVteM9, self.VVHZxf, self.VVgLJ3, self.VVSzMt, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVB9mJ()
   return True
  else:
   return False
 def VVMFmy(self, tDict):
  ndx = self.VVHqmL()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVrLHE[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVOc9I()
 def VVjqpY(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVegOb(ndx, data, self.VVteM9, self.VVHZxf, self.VVgLJ3, self.VVSzMt, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVOc9I()
 def VVOc9I(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVB9mJ()
 def VVWVH1(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VV3g7B(self, colNum, textToFind, VVzp4h=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVB9mJ()
    break
  else:
   if VVzp4h:
    FFM3N1(self, "Not found", 1000)
 def VVTlR4(self, colDict, VVzp4h=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVB9mJ()
    return
  if VVzp4h:
   FFM3N1(self, "Not found", 1000)
  return False
 def VVyaay(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVfjI7(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFt95z(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVeAfz(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVTX33:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV3nbn(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVTX33:
     return ndx
  return -1
 def VV9Uef(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVTX33:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVfcYI(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVTX33 : return True
  else        : return False
 def VVOazu(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVCeU5(self):
  if self.menuButtonFnc:
   self.VVbz9d(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVUMPl:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVHqmL()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVhIDJ1, VVYpjp = CCf604.VVYrzi(self, False, False)
  VVhIDJ = []
  VVhIDJ.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVhIDJ.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVhIDJ.append(("Find ...\t\t%s" % (FFwXwL(txt, VVEhqe) if txt else ""), "findNew"   ))
  VVhIDJ.append(itemOf(bool(VVhIDJ1)    , "Find (from Filter) ..."   , "filter"   ))
  if self.header:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Table Statistcis"            , "tableStat"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((FFwXwL("Export Table to .html"     , VVdSiQ) , "VVClYp" ))
  VVhIDJ.append((FFwXwL("Export Table to .csv"     , VVdSiQ) , "VVAoFG" ))
  VVhIDJ.append((FFwXwL("Export Table to .txt (Tab Separated)", VVdSiQ) , "VVASaW" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVN1SU[i] > 1 or self.VVN1SU[i] == self.VVN00W:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVhIDJ.append(VVuAtK)
    if tot == 1 : VVhIDJ.append(("Sort", sList[0][1]))
    else  : VVhIDJ += sList
  VVzwta = ("Keys Help", self.FFNCSPHelp)
  FFRHhp(self, self.VVRj9O, VVhIDJ=VVhIDJ, title=self.VV34q2(), VVzwta=VVzwta)
 def VVRj9O(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVsgVx()
   elif item == "findPrev"  : self.VVsgVx(isPrev=True)
   elif item == "findNew"  : self.VVPVXd()
   elif item == "filter"  : self.VVR7dH()
   elif item == "tableStat" : self.VVNhV9()
   elif item == "VVClYp": FFuMBP(self, self.VVClYp, title=title)
   elif item == "VVAoFG" : FFuMBP(self, self.VVAoFG , title=title)
   elif item == "VVASaW" : FFuMBP(self, self.VVASaW , title=title)
   else:
    if self.VVOOaR == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVOOaR, self.lastSortModeIsReverese = item, False
    if self.VVJcAk and self.VVOOaR == 0 or self.VVfjI7(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVVxzU(onlyHeader=True)
 def FFNCSPHelp(self, VVCarR, path):
  FFYqxx(self, "_help_table", "Table (Keys Help)")
 def VVgtBs(self):
  self["myTable"].up()
  self.VVB9mJ()
 def VVE1dG(self):
  self["myTable"].down()
  self.VVB9mJ()
 def VVn9SE(self):
  self["myTable"].pageUp()
  self.VVB9mJ()
 def VV7l89(self):
  self["myTable"].pageDown()
  self.VVB9mJ()
 def VVxJLU(self):
  self["myTable"].moveToIndex(0)
  self.VVB9mJ()
 def VVa0Kk(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVB9mJ()
 def VVj43f(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVB9mJ()
 def VVoDWM(self):
  if self.lastFindConfigObj.getValue():
   if self.VVHqmL() == len(self["myTable"].list) - 1 : FFM3N1(self, "End reached", 1000)
   else              : self.VVsgVx()
  else:
   FFM3N1(self, 'Set "Find" in Menu', 1500)
 def VV9zTH(self):
  if self.lastFindConfigObj.getValue():
   if self.VVHqmL() == 0 : FFM3N1(self, "Top reached", 1000)
   else       : self.VVsgVx(isPrev=True)
  else:
   FFM3N1(self, 'Set "Find" in Menu', 1500)
 def VVsdLK(self, txt):
  FFsMp0(self.lastFindConfigObj, txt)
 def VVPVXd(self):
  FFs37j(self, self.VVryxA, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVryxA(self, VVSRUl):
  if not VVSRUl is None:
   txt = VVSRUl.strip()
   self.VVsdLK(txt)
   if VVSRUl: self.VVsgVx(reset=True)
   else  : FFM3N1(self, "Nothing to find !", 1500)
 def VVR7dH(self):
  VVhIDJ, VVYpjp = CCf604.VVYrzi(self, False, False)
  VVVW3K = ("Edit Filter", BF(self.VVRaDd, VVYpjp))
  if VVhIDJ : FFRHhp(self, self.VVdnqf, VVhIDJ=VVhIDJ, VVVW3K=VVVW3K, title="Find from Filter")
  else  : FFM3N1(self, "Filter Error !", 1500)
 def VVdnqf(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVsdLK(txt)
    self.VVsgVx(reset=True)
   else:
    FFM3N1(self, "No entry !", 1500)
 def VVRaDd(self, VVYpjp, selectionObj, sel):
  if fileExists(VVYpjp) : CCwZEN(self, VVYpjp, VVLUmk=None)
  else       : FFM8jr(self, VVYpjp)
  selectionObj.cancel()
 def VVsgVx(self, reset=False, isPrev=False):
  curRow = self.VVHqmL()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCf604.VV7zA4(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVj43f(i)
      break
    elif any(x in line for x in tupl):
     self.VVj43f(i)
     break
   else:
    FFM3N1(self, "Not found", 1000)
  else:
   FFM3N1(self, "Check your query", 1500)
 def VVASaW(self):
  expFile = self.VVsnit() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVDHdW()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVregv(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVN1SU[ndx] > self.VVtRCF or self.VVN1SU[ndx] == self.VVKDzl:
      col = self.VVZVwA(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVG8Zk(expFile)
 def VVAoFG(self):
  expFile = self.VVsnit() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVDHdW()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVregv(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVN1SU[ndx] > self.VVtRCF or self.VVN1SU[ndx] == self.VVKDzl:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVZVwA(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVG8Zk(expFile)
 def VVClYp(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV34q2(), PLUGIN_NAME, VVO0ZM)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV34q2()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVDHdW()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVN1SU:
   colgroup += '   <colgroup>'
   for w in self.VVN1SU:
    if w > self.VVtRCF or w == self.VVKDzl:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVsnit() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVregv(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVN1SU[ndx] > self.VVtRCF or self.VVN1SU[ndx] == self.VVKDzl:
      col = self.VVZVwA(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVG8Zk(expFile)
 def VVDHdW(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVN1SU[ndx] > self.VVtRCF or self.VVN1SU[ndx] == self.VVKDzl:
     newRow.append(col.strip())
  return newRow
 def VVZVwA(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFpdHF(col)
 def VVsnit(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV34q2())
  fileName = fileName.replace("__", "_")
  path  = FF77SS(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFERmH()
  return expFile
 def VVG8Zk(self, expFile):
  FFWB0Q(self, "File exported to:\n\n%s" % expFile, title=self.VV34q2())
 def VVB9mJ(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == eListboxPythonMultiContent.TYPE_TEXT:
    lastCol = totCols - 1
   else:
    lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVG9jM(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VV1yVM: return (typ, x, y, w, h, png, bg, bgSel, VV1yVM | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCpfQt():
 def __init__(self, pixmapObj, picPath, VVHZxf=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVHZxf  = VVHZxf or "#2200002a"
 def VVjJZp(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVD8CC)
    except:
     self.picLoad.PictureData.get().append(self.VVD8CC)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVHZxf])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVD8CC(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVcoIX(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VV8yot(pixmapObj, path, VVHZxf=None):
  cl = CCpfQt(pixmapObj, path, VVHZxf)
  ok = cl.VVjJZp()
  if ok: return cl
  else : return None
class CCuhvG(Screen):
 def __init__(self, session, VVmyei, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFfZ8G()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFMkht(VV8Z1U, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVmyei = VVmyei
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFTlW1(self)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVExKw  ,
   "up" : BF(self.VV6LeW, -1),
   "down" : BF(self.VV6LeW,  1),
   "left" : BF(self.VV6LeW, -1),
   "right" : BF(self.VV6LeW,  1)
  }, -1)
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  self.VVAf2x()
  self.picViewer = CCpfQt.VV8yot(self["myPic"], self.VVmyei)
  if self.picViewer:
   if self.showGrnMsg:
    FFM3N1(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFB8Nz(self, "Cannot view picture file:\n\n%s" % self.VVmyei)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVcoIX()
  if self.cbFnc  : self.cbFnc(self.VVmyei)
 def VV6LeW(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVmyei = FF77SS(os.path.dirname(self.VVmyei)) + fName
    self.picViewer.picPath = self.VVmyei
    self.picViewer.VVjJZp()
    self.VVAf2x()
 def VVExKw(self):
  txt = "%s:\n  %s" % (FFwXwL("Path", VVdVoc), self.fakePath or self.VVmyei)
  size, sizeTxt, resTxt, form, mode = CC67Fj.VVEJxm(self.VVmyei)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFwXwL("Properties", VVdVoc)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FF3nHt(self, txt, title="File Information")
 def VVAf2x(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVmyei)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVqol3(SELF, VVmyei, **kwargs):
  SELF.session.open(CCuhvG, VVmyei, **kwargs)
class CCs3ZF(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFMkht(VVDkmp, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFTlW1(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.onExit)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFcZm9("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVZZWP(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCs3ZF.VVZowc, SELF), CCs3ZF, mviFile)
 @staticmethod
 def VVZowc(SELF, reason=None):
  if reason == -1: FFB8Nz(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCayJh(Screen, ConfigListScreen):
 VVlhN3 = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VVSnw0, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFTlW1(self, title=self.Title)
  FFMz2e(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVYfrn()
  self.onShown.append(self.VVtpg1)
 def VVYfrn(self):
  kList = {
    "ok" : self.VVYfT9   ,
    "green" : self.VVR2Cw ,
    "menu" : self.VV5WlH ,
    "cancel": self.VVcAgQ ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVTqOH, 0)
     kList["chanDown"] = BF(self["config"].VVTqOH, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVyASM, kList, -1)
  else:
   self["actions"] = ActionMap(VVyASM, kList, -1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FFfgOw(self)
  FFjM4Z(self["config"])
  FFH94q(self, self["config"])
  FF3wB4(self)
  self["config"].onSelectionChanged.append(self.VVZbCB)
  self.VVZbCB()
  FFOrd9(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVZbCB(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVYfT9(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVepk0()
   elif item == CFG.MovieDownloadPath   : self.VVEHaA(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVzAmV()
   elif isinstance(item, ConfigDirectory) : self.VVkHSa(item)
   else         : CCayJh.VVL4yy(self, item, title)
 @staticmethod
 def VVL4yy(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber):
    lst = confItem.choices.choices
    if not isinstance(lst[0], tuple)  : lst = [(x, x) for x in lst]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVhIDJ = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVEhqe + txt
    elif val == confItem.default: defNdx, txt = ndx, VVqZDD + txt
   VVhIDJ.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVzwta  = ("Current", BF(CCayJh.VVzUjO, curNdx))
  VVVW3K = ("Default", BF(CCayJh.VVzUjO, defNdx))
  VVCarR = FFRHhp(SELF, BF(CCayJh.VVfxk4, confItem, cbFnc, isSave), VVhIDJ=VVhIDJ, width=1200, VVVW3K=VVVW3K, VVzwta=VVzwta, title=title, VVl9AY="#33221111", VVLICL="#33110011")
  VVCarR.VVflXp(curNdx)
 @staticmethod
 def VVfxk4(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFsMp0(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVzUjO(ndx, selectionObj, item):
  selectionObj.VVflXp(ndx)
 @staticmethod
 def VVMVez(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVEHaA(self, item, title):
  tot = CCSDOM.VV1qOR()
  if tot : FFB8Nz(self, "Cannot change while downloading.", title=title)
  else : self.VVkHSa(item)
 def VVzAmV(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCbony.VV0Uky(self, "", curEnc)
  if lst:
   VVVW3K = ("Default", self.VVAJjF)
   VVzwta  = ("Current", self.VVsZvh)
   VVCarR = FFRHhp(self, self.VVpujB, title="Select Priority Encoding", VVhIDJ=lst, width=1000, height=1000, VVzwta=VVzwta, VVVW3K=VVVW3K, VVl9AY="#22220000", VVLICL="#22220000", VVWLSA=True)
   VVCarR.VVKAoY(curEnc)
 def VVpujB(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVAJjF(self, VVCarR, item): VVCarR.VVKAoY(VVNrVP)
 def VVsZvh(self, VVCarR, item): VVCarR.VVKAoY(CFG.subtDefaultEnc.getValue())
 def VVepk0(self):
  VVhIDJ = []
  VVhIDJ.append(("Auto Find" , "auto"))
  VVhIDJ.append(("Custom Path" , "cust"))
  FFRHhp(self, self.VVhFLk, VVhIDJ=VVhIDJ, title="IPTV Hosts Files Path")
 def VVhFLk(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVbCvh)
   elif item == "cust":
    VVkNlM = self.VVGLcz()
    if VVkNlM : self.VV3gNM(VVkNlM)
    else  : self.session.openWithCallback(self.VViAkO, BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM="/"))
 def VV3gNM(self, VVkNlM):
  VVPEsb = self.VVofkM
  VVlpv3 = ("Remove"  , self.VV3W0e , [])
  VVkGmL = ("Add "  , self.VVEXid, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVrLHE  = (LEFT   , LEFT  )
  FFNCSP(self, None, title="IPTV Hosts Search Paths", header=header, VVFWkP=VVkNlM, width=1200, height=700, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=26, VVPEsb=VVPEsb, VVlpv3=VVlpv3, VVkGmL=VVkGmL
    , VVl9AY="#22220000", VVLICL="#22110000", VVHZxf="#22110011", VVSzMt="#11223025", VVvy9F="#0a333333", VVRt6l="#11400040")
 def VVofkM(self, VVhqv2):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVAiFv)
  VVhqv2.cancel()
 def VViAkO(self, path):
  if path:
   FFsMp0(CFG.iptvHostsDirs, FF77SS(path.strip()))
   VVkNlM = self.VVGLcz()
   if VVkNlM : self.VV3gNM(VVkNlM)
   else  : FFM3N1(self, "Cannot add dir", 1500)
 def VVzcLb(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVbCvh:
   return []
  return lst
 def VVGLcz(self):
  lst = self.VVzcLb()
  if lst:
   VVkNlM = []
   for Dir in lst:
    VVkNlM.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVkNlM.sort(key=lambda x: x[0].lower())
   return VVkNlM
  else:
   return []
 def VVEXid(self, VVhqv2, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VV45py, VVhqv2)
         , BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=sDir))
 def VV45py(self, VVhqv2, path):
  if path:
   path = FF77SS(path.strip())
   if self.VVUjsw(VVhqv2, path):
    FFM3N1(VVhqv2, "Already added", 1500)
   else:
    lst = self.VVzcLb()
    lst.append(path)
    FFsMp0(CFG.iptvHostsDirs, ",".join(lst))
    VVkNlM = self.VVGLcz()
    VVhqv2.VVartp(VVkNlM, tableRefreshCB=BF(self.VVGFcb, path))
 def VVGFcb(self, path, VVhqv2, title, txt, colList):
  self.VVUjsw(VVhqv2, path)
 def VVUjsw(self, VVhqv2, path):
  for ndx, row in enumerate(VVhqv2.VVOazu()):
   if row[0].strip() == path.strip():
    VVhqv2.VVj43f(ndx)
    return True
  return False
 def VV3W0e(self, VVhqv2, title, txt, colList):
  path = colList[0]
  FF5jVY(self, BF(self.VVOa4i, VVhqv2), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVOa4i(self, VVhqv2):
  row = VVhqv2.VVHMjy()
  path, rem = row[0], row[1]
  VVkNlM = []
  lst = []
  for ndx, row in enumerate(VVhqv2.VVOazu()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVkNlM.append((tPath, tRem))
  if len(VVkNlM) > 0:
   FFsMp0(CFG.iptvHostsDirs, ",".join(lst))
   VVhqv2.VVartp(VVkNlM)
   FFM3N1(VVhqv2, "Deleted", 1500)
  else:
   FFsMp0(CFG.iptvHostsMode, VVbCvh)
   FFsMp0(CFG.iptvHostsDirs, "")
   VVhqv2.cancel()
   FFbn1D(BF(FFM3N1, self, "Changed to Auto-Find", 1500))
 def VVkHSa(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVjQ1m, configObj)
         , BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=sDir))
 def VVjQ1m(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVcAgQ(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FF5jVY(self, self.VVR2Cw, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVR2Cw(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVP7sq()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV5WlH(self):
  VVhIDJ = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVhIDJ.append((txt    , "VVqNuH"   ))
  else        : VVhIDJ.append((txt    ,       ))
  VVhIDJ.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Reset %s Settings" % PLUGIN_NAME      , "VVfLbH"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Backup %s Settings" % PLUGIN_NAME      , "VVWuOz"  ))
  VVhIDJ.append(("Restore %s Settings" % PLUGIN_NAME     , "VVyUXx"  ))
  if fileExists(VVVcWE + CCayJh.VVlhN3):
   VVhIDJ.append(VVuAtK)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVhIDJ.append(('%s Checking for Update' % txt1     , txt2     ))
   VVhIDJ.append(("Reinstall %s" % PLUGIN_NAME      , "VVkruY"  ))
   VVhIDJ.append(("Update %s" % PLUGIN_NAME      , "VVGadm"   ))
  FFRHhp(self, self.VVWsBq, VVhIDJ=VVhIDJ, title="Config. Options")
 def VVWsBq(self, item=None):
  if item:
   if   item == "VVqNuH"  : FF5jVY(self, self.VVqNuH , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCbkDP)
   elif item == "VVfLbH"  : FF5jVY(self, BF(self.VVfLbH, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVWuOz" : self.VVWuOz()
   elif item == "VVyUXx" : FFuMBP(self, self.VVyUXx, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFsMp0(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFsMp0(CFG.checkForUpdateAtStartup, False)
   elif item == "VVkruY" : FFuMBP(self, BF(self.VVJNgT, True ), "Checking Server ...")
   elif item == "VVGadm"  : FFuMBP(self, BF(self.VVJNgT, False), "Checking Server ...")
 def VVWuOz(self):
  path = "%sajpanel_settings_%s" % (VVVcWE, FFERmH())
  FFQIMd("grep .%s. %s > %s" % (PLUGIN_NAME, VVabb3, path))
  FFWB0Q(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVyUXx(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFpNiE("find / %s -iname '%s*' | grep %s" % (FF9R5Y(1), name, name))
  if files:
   err = CCf82q.VVIxYK(files)
   if err:
    FF5jVY(self, BF(self.VVKE7N, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVhIDJ = []
    for line in files:
     VVhIDJ.append((line, line))
    FFRHhp(self, BF(self.VVzuVE, title), title=title, VVhIDJ=VVhIDJ, width=1200, VV8Vs4="")
  else:
   FFB8Nz(self, "No settings files found !", title=title)
 def VVKE7N(self, title, path=None):
  sDir = "/"
  for path in (VVVcWE, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVzuVE, title), BF(CCf82q, patternMode="ajpSet", VVQzCM=sDir))
 def VVzuVE(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF9z80(path)
    self.VVfLbH()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVP7sq()
    FFjSyn()
    FFM3N1(self, "Apllied", 1500, isGrn=True)
   else:
    FFM8jr(self, path, title=title)
 def VVqNuH(self):
  newPath = FF77SS(VVVcWE)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVP7sq()
 @staticmethod
 def VViHmR():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVfLbH(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVP7sq()
  if exit:
   self.close()
 def VVP7sq(self):
  configfile.save()
  global VVVcWE
  VVVcWE = CFG.backupPath.getValue()
  FFMHiW()
 def VVJNgT(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCayJh.VV6Tqq()
  if   err    : FFB8Nz(self, err, title)
  elif isHigher or force : FF5jVY(self, BF(FFuMBP, self, BF(self.VVvvsf, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFWB0Q(self, FFwXwL("No update required.", VVfPTB) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVvvsf(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFn597() == "dpkg" else "ipk")
  path, err = FFlHhH(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFyOYr(VVq2DR, path)
   else : cmd = FFyOYr(VVsUET, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFFPZ4(self, cmd, title=title)
   else:
    FF4L5V(self, title=title)
  else:
   FFB8Nz(self, err, title=title)
 @staticmethod
 def VV6Tqq():
  span = iSearch(r"v*(\d.\d.\d)", VVO0ZM, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVVcWE + CCayJh.VVlhN3
  if fileExists(path):
   span = iSearch(r"(http.+)", FFQDOO(path), IGNORECASE)
   if span : url = FF77SS(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFlHhH(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFQDOO(path).strip().replace(" ", "")
   FFZ5Mj(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCbkDP(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VVz6y3, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVTlMX
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFTlW1(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVhiY2("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVhiY2("\c00888888", i) + sp + "GREY\n"
   txt += self.VVhiY2("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVhiY2("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVhiY2("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVhiY2("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVhiY2("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVhiY2("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVhiY2("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVhiY2("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVhiY2("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVhiY2("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok" : self.VVYfT9 ,
   "green" : self.VVYfT9 ,
   "left" : self.VV2KSP ,
   "right" : self.VVVV8y ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  self.VVkiH3()
 def VVYfT9(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF5jVY(self, self.VV15IP, "Change to : %s" % txt, title=self.Title)
 def VV15IP(self):
  FFsMp0(CFG.mixedColorScheme, self.cursorPos)
  global VVTlMX
  VVTlMX = self.cursorPos
  self.VVW3mQ()
  self.close()
 def VV2KSP(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVkiH3()
 def VVVV8y(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVkiH3()
 def VVkiH3(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVhiY2(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVhXkO(color):
  if VVqZDD: return "\\" + color
  else    : return ""
 @staticmethod
 def VVW3mQ():
  global VV6rcy, VVlrJC, VVvrDy, VVeCLm, VVdSiQ, VVHH6F, VVA3Oc, VVFSYX, VVfPTB, VVuj5g, VVqZDD, VVdVoc, VVEhqe, VVmvsU, VVGdv9, VViVXH
  VViVXH   = CCbkDP.VVhiY2("\c00FFFFFF", VVTlMX)
  VVlrJC    = CCbkDP.VVhiY2("\c00888888", VVTlMX)
  VV6rcy  = CCbkDP.VVhiY2("\c005A5A5A", VVTlMX)
  VVFSYX    = CCbkDP.VVhiY2("\c00FF0000", VVTlMX)
  VVvrDy   = CCbkDP.VVhiY2("\c00FF5000", VVTlMX)
  VVeCLm   = CCbkDP.VVhiY2("\c00FFBB66", VVTlMX)
  VVqZDD   = CCbkDP.VVhiY2("\c00FFFF00", VVTlMX)
  VVdVoc = CCbkDP.VVhiY2("\c00FFFFAA", VVTlMX)
  VVfPTB   = CCbkDP.VVhiY2("\c0000FF00", VVTlMX)
  VVuj5g  = CCbkDP.VVhiY2("\c00AAFFAA", VVTlMX)
  VVA3Oc    = CCbkDP.VVhiY2("\c000066FF", VVTlMX)
  VVEhqe    = CCbkDP.VVhiY2("\c0000FFFF", VVTlMX)
  VVmvsU  = CCbkDP.VVhiY2("\c00AAFFFF", VVTlMX)  #
  VVGdv9   = CCbkDP.VVhiY2("\c00FA55E7", VVTlMX)
  VVdSiQ    = CCbkDP.VVhiY2("\c00FF8F5F", VVTlMX)
  VVHH6F  = CCbkDP.VVhiY2("\c00FFC0C0", VVTlMX)
CCbkDP.VVW3mQ()
class CCo3lT(Screen):
 def __init__(self, session, path, VVcMDF):
  self.skin, self.skinParam = FFMkht(VVj7jx, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV1CQe   = path
  self.VV7SYv   = ""
  self.VVPO8V   = ""
  self.VVcMDF    = VVcMDF
  self.VVQR3p    = ""
  self.VVpeyI  = ""
  self.VV5uIW    = False
  self.VVM2I2  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVumGt  = "enigma2-plugin-extensions-"
  self.VVATj3  = "enigma2-plugin-systemplugins-"
  self.VV6YeM = "enigma2-"
  self.VVrhKn  = 0
  self.VV7e97  = 1
  self.VVFLr9  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVMvBL = "DEBIAN"
  else        : self.VVMvBL = "CONTROL"
  self.controlPath = self.Path + self.VVMvBL
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVcMDF:
   self.packageExt  = ".deb"
   self.VVHZxf  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVHZxf  = "#11001020"
  FFTlW1(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFMz2e(self["keyRed"] , "Create")
  FFMz2e(self["keyGreen"] , "Post Install")
  FFMz2e(self["keyYellow"], "Installation Path")
  FFMz2e(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVyASM,
  {
   "red"   : self.VVRXaV  ,
   "green"   : self.VVuquO ,
   "yellow"  : self.VVfY0l  ,
   "blue"   : self.VVT8y2  ,
   "cancel"  : self.VVJnCM
  }, -1)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FF3wB4(self)
  if self.VVHZxf:
   FFOrd9(self["myBody"], self.VVHZxf)
   FFOrd9(self["myLabel"], self.VVHZxf)
  self.VVscRi(True)
  self.VVQUFJ(True)
 def VVQUFJ(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVG1Xu()
  if isFirstTime:
   if   package.startswith(self.VVumGt) : self.VV1CQe = VVe5fU + self.VVQR3p + "/"
   elif package.startswith(self.VVATj3) : self.VV1CQe = VVDVsC + self.VVQR3p + "/"
   else            : self.VV1CQe = self.Path
  if self.VV5uIW : myColor = VVdSiQ
  else    : myColor = VViVXH
  txt  = ""
  txt += "Source Path\t: %s\n" % FFwXwL(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFwXwL(self.VV1CQe, VVqZDD)
  if self.VVPO8V : txt += "Package File\t: %s\n" % FFwXwL(self.VVPO8V, VVlrJC)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFwXwL("Check Control File fields : %s" % errTxt, VVvrDy)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFwXwL("Restart GUI", VVdSiQ)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFwXwL("Reboot Device", VVdSiQ)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFwXwL("Post Install", VVfPTB), act)
  if not errTxt and VVvrDy in controlInfo:
   txt += "Warning\t: %s\n" % FFwXwL("Errors in control file may affect the result package.", VVvrDy)
  txt += "\nControl File\t: %s\n" % FFwXwL(self.controlFile, VVlrJC)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVuquO(self):
  if self["keyGreen"].getVisible():
   VVhIDJ = []
   VVhIDJ.append(("No Action"    , "noAction"  ))
   VVhIDJ.append(("Restart GUI"    , "VVVcYg"  ))
   VVhIDJ.append(("Reboot Device"   , "rebootDev"  ))
   FFRHhp(self, self.VV9pZt, title="Package Installation Option (after completing installation)", VVhIDJ=VVhIDJ)
 def VV9pZt(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVVcYg"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVscRi(False)
   self.VVQUFJ()
 def VVfY0l(self):
  rootPath = FFwXwL("/%s/" % self.VVQR3p, VVdVoc)
  VVhIDJ = []
  VVhIDJ.append(("Current Path"        , "toCurrent"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Extension Path"       , "toExtensions" ))
  VVhIDJ.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVhIDJ.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFRHhp(self, self.VVzX3K, title="Installation Path", VVhIDJ=VVhIDJ)
 def VVzX3K(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVswx6(FFO4Nw(self.Path, True))
   elif item == "toExtensions"  : self.VVswx6(VVe5fU)
   elif item == "toSystemPlugins" : self.VVswx6(VVDVsC)
   elif item == "toRootPath"  : self.VVswx6("/")
   elif item == "toRoot"   : self.VVswx6("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVzJGi, BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=VVVcWE))
 def VVzJGi(self, path):
  if len(path) > 0:
   self.VVswx6(path)
 def VVswx6(self, parent, withPackageName=True):
  if withPackageName : self.VV1CQe = parent + self.VVQR3p + "/"
  else    : self.VV1CQe = "/"
  mode = self.VVBfaZ()
  FFcZm9("sed -i '/Package/c\Package: %s' %s" % (self.VVWVVc(mode), self.controlFile))
  self.VVQUFJ()
 def VVT8y2(self):
  if fileExists(self.controlFile):
   lines = FF9z80(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFs37j(self, self.VVDX20, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFB8Nz(self, "Version not found or incorrectly set !")
  else:
   FFM8jr(self, self.controlFile)
 def VVDX20(self, VVSRUl):
  if VVSRUl:
   version, color = self.VV76E8(VVSRUl, False)
   if color == VVEhqe:
    FFcZm9("sed -i '/Version:/c\Version: %s' %s" % (VVSRUl, self.controlFile))
    self.VVQUFJ()
   else:
    FFB8Nz(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVJnCM(self):
  if self.newControlPath:
   if self.VV5uIW:
    self.VVY7tL()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFwXwL(self.newControlPath, VVlrJC)
    txt += FFwXwL("Do you want to keep these files ?", VVqZDD)
    FF5jVY(self, self.close, txt, callBack_No=self.VVY7tL, title="Create Package", VVQk5i=True)
  else:
   self.close()
 def VVY7tL(self):
  FFcZm9("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVWVVc(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVpeyI
  if package.startswith(self.VV6YeM):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VV6YeM, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV7e97 : prefix = self.VVumGt
  elif mode == self.VVFLr9 : prefix = self.VVATj3
  return (prefix + name).lower()
 def VVBfaZ(self):
  if   self.VV1CQe.startswith(VVe5fU) : return self.VV7e97
  elif self.VV1CQe.startswith(VVDVsC) : return self.VVFLr9
  else            : return self.VVrhKn
 def VVscRi(self, isFirstTime):
  self.VVQR3p   = FFtnj1(self.Path)
  self.VVQR3p   = "_".join(self.VVQR3p.split())
  self.VVpeyI = self.VVQR3p.lower()
  self.VV5uIW = self.VVpeyI == VVkv1M.lower()
  if self.VV5uIW and self.VVpeyI.endswith(VVkv1M.lower()):
   self.VVpeyI += "el"
  if self.VV5uIW : self.VV7SYv = VVVcWE
  else    : self.VV7SYv = CFG.packageOutputPath.getValue()
  self.VV7SYv = FF77SS(self.VV7SYv)
  if not pathExists(self.controlPath):
   FFcZm9("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVBfaZ()
  if fileExists(self.controlFile):
   lines = FF9z80(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VV5uIW : version, descripton, maintainer = VVO0ZM , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVQR3p , self.VVQR3p
   txt = ""
   txt += "Package: %s\n"  % self.VVWVVc(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: \n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VV5uIW : t = PLUGIN_NAME
  else    : t = self.VVQR3p
  self.VVE3kB(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVE3kB(self.postrmFile, "echo 'Package removed.'\n")
  if self.VV5uIW : self.VVE3kB(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVO0ZM))
  else    : self.VVE3kB(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVQR3p)
  if isFirstTime and not mode == self.VVrhKn:
   self.postInstAcion = 1
  txt = self.VVXsxu(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFQDOO(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVXsxu(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFcZm9("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVE3kB(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVXsxu(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVG1Xu(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF9z80(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFwXwL(line, VVvrDy)
     elif not line.startswith(" ")    : line = FFwXwL(line, VVvrDy)
     else          : line = FFwXwL(line, VVEhqe)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVEhqe
   else   : color = VVvrDy
   descr = FFwXwL(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVvrDy
     elif line.startswith((" ", "\t")) : color = VVvrDy
     elif line.startswith("#")   : color = VVlrJC
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV76E8(val, True)
      elif key == "Version"  : version, color = self.VV76E8(val, False)
      elif key == "Maintainer" : maint  , color = val, VVEhqe
      elif key == "Architecture" : arch  , color = val, VVEhqe
      else:
       color = VVEhqe
      if not key == "OE" and not key.istitle():
       color = VVvrDy
     else:
      color = VVdSiQ
     txt += FFwXwL(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVPO8V = self.VV7SYv + packageName
   self.VVM2I2 = True
   errTxt = ""
  else:
   self.VVPO8V  = ""
   self.VVM2I2 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV76E8(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVEhqe
  else          : return val, VVvrDy
 def VVRXaV(self):
  if not self.VVM2I2:
   FFB8Nz(self, "Please fix Control File errors first.")
   return
  if self.VVcMDF: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFO4Nw(self.VV1CQe, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVQR3p
  symlinkTo  = FFOE3h(self.Path)
  dataDir   = self.VV1CQe.rstrip("/")
  removePorjDir = FFUGBP("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFUGBP("rm -f '%s'" % self.VVPO8V)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFGFBz()
  if self.VVcMDF:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFJfZ1("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV5uIW:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VV1CQe == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVMvBL)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVPO8V, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVPO8V
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVPO8V, FFw0WV(result  , VVfPTB))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV1CQe, FFw0WV(instPath, VVEhqe))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFw0WV(failed, VVvrDy))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFFPZ4(self, cmd)
class CCJEC1():
 VVS474  = "666"
 VVFUf6   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVCarR   = None
  self.VVhhLx()
 def VVhhLx(self):
  VVhIDJ = CCJEC1.VVbosM()
  if VVhIDJ:
   VVVW3K = ("Create New", self.VVKm5J)
   self.VVCarR = FFRHhp(self.SELF, self.VVSC6i, VVhIDJ=VVhIDJ, title=self.Title, VVVW3K=VVVW3K, VVWLSA=True, VVl9AY="#22222233", VVLICL="#22222233")
  else:
   self.VVKm5J()
 def VVSC6i(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVQ5hW(bName, bRef)
  else:
   CCJEC1.VVx7Ha(self)
 def VVKm5J(self, selectionObj=None, item=None):
  FFs37j(self.SELF, BF(self.VV5IzW), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV5IzW(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVCarR:
     self.VVCarR.cancel()
    self.VVQ5hW(bName, "")
   else:
    FFM3N1(self.VVCarR, "Incorrect Bouquet Name !", 2000)
    CCJEC1.VVx7Ha(self)
 def VVQ5hW(self, bName, bRef):
  FFuMBP(self.waitMsgSELF, BF(self.VV1dnP, bName, bRef), title="Adding Services ...")
 def VV1dnP(self, bName, bRef):
  CCJEC1.VVH0cU(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVx7Ha(classObj):
  del classObj
 @staticmethod
 def VVH0cU(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFB8Nz(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVSs5p + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFM8jr(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCJEC1.VVmvex(bRef)
   bPath = VVSs5p + bFile
  else:
   fName = CC8Yh1.VV5TZE(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVSs5p + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVSs5p + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FF3j5I(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FF3j5I(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCTdjW.VVJwSu()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFcZm9("cp -f '%s' '%s'" % (poster, picon))
       FFcZm9(CCscAN.VVsRkF(picon))
       break
  FFBOOj()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FF3nHt(SELF, txt, title=title)
 @staticmethod
 def VVLw9b(bName):
  mode = CCod57.VVXj2B(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CC8Yh1.VV5TZE(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVSs5p + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVSs5p + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVSs5p, modeTxt)
  if fileExists(mainBFile):
   FF3j5I(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VVRRmT(ref, bName):
  bFile = CCJEC1.VVmvex(ref)
  ok = False
  if bFile:
   bFile = VVSs5p + bFile
   if fileExists(bFile):
    lines = FF9z80(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVbosM(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVhIDJ = []
  if mode in (0, 2): VVhIDJ.extend(CCJEC1.VV17P2(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVhIDJ.extend(CCJEC1.VV17P2(1, showTitle, prefix, onlyIptv))
  return VVhIDJ
 @staticmethod
 def VV17P2(mode, showTitle, prefix, onlyIptv):
  VVhIDJ = []
  lst = CCJEC1.VVhs7d(mode)
  if onlyIptv:
   lst = CCJEC1.VVtAiV(lst)
  if lst:
   if showTitle:
    VVhIDJ.append(FFw8eL("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVhIDJ.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVhIDJ.append((item[0], item[1].toString()))
  return VVhIDJ
 @staticmethod
 def VVtAiV(lst):
  fLst = CC8Yh1.VVYsfN(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVuK6D():
  lst = CCJEC1.VVhs7d(0)
  lst.extend(CCJEC1.VVhs7d(1))
  return lst
 @staticmethod
 def VVhs7d(mode=0):
  bList = []
  VVOzoq = InfoBar.instance
  VVJK1Q = VVOzoq and VVOzoq.servicelist
  if VVJK1Q:
   curMode = VVJK1Q.mode
   CCJEC1.VVIF9g(VVJK1Q, mode)
   bList.extend(VVJK1Q.getBouquetList() or [])
   CCJEC1.VVIF9g(VVJK1Q, curMode)
  return bList
 @staticmethod
 def VVIF9g(VVJK1Q, mode):
  if not mode == VVJK1Q.mode:
   if   mode == 0: VVJK1Q.setModeTv()
   elif mode == 1: VVJK1Q.setModeRadio()
 @staticmethod
 def VVukZQ(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVQHDq = eServiceCenter.getInstance()
    if onlyMain:
     info = VVQHDq.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVQHDq and VVQHDq.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVQHDq.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVmvex(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VV5654(ref, dstFile):
  dstFile = VVSs5p + dstFile
  if fileExists(dstFile):
   FF3j5I(dstFile)
   bLine = ""
   srcFile = CCJEC1.VVmvex(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVSs5p + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVSs5p + newName
     FFcZm9("cp -f '%s%s' '%s'" % (VVSs5p, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVVtxo():
  try:
   fName = CCJEC1.VVmvex(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVSs5p, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVk53P():
  path = CCJEC1.VVVtxo()
  if path:
   txt = FFQDOO(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVbWPR():
  return FFxxyk(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVvYk6():
  lst = []
  for b in CCJEC1.VVuK6D():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVSs5p + CCJEC1.VVmvex(bRef)
   if fileExists(path):
    lines = FF9z80(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVI9DP(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVMlwj(SID="", stripRType=False):
  if SID : patt = CCJEC1.VVI9DP(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCJEC1.VVuK6D():
   for service in FFxxyk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVkrP4():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCJEC1.VVuK6D():
   for service in FFxxyk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVgSI8(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVaU4W(pathLst, rType=""):
  refLst = CCJEC1.VVMlwj(CCJEC1.VVS474, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCJEC1.VVgSI8(rType, CCJEC1.VVS474, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCf82q(Screen):
 VVEWyL   = 0
 VVfI6P  = 1
 VVa1qF  = 2
 VVYWKd = 3
 VVjRhj    = 20
 VV98Y6   = 0
 VVdoK1   = 1
 VVqlG1   = 2
 def __init__(self, session, VVQzCM="/", mode=VVEWyL, VV5Ab4="Select", width=1400, height=920, VVNWWl=30, VVl9AY="#22001111", VVLICL="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFMkht(VV35C4, width, height, 30, 40, 20, VVl9AY, VVLICL, VVNWWl, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVl9AY   = VVl9AY
  self.VVLICL    = VVLICL
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFTlW1(self)
  FFMz2e(self["keyRed"] , "Exit")
  FFMz2e(self["keyYellow"], "More Options")
  FFMz2e(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV5Ab4 = VV5Ab4
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVFJ12 = None
  if patternMode:
   self.mode = self.VVYWKd
   if   patternMode == "srt"  : VVFJ12 = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVFJ12 = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVFJ12 = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVFJ12 = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVFJ12 = ("^.*\.(%s)$" % "|".join(CCuvev.VVO8mQ()["mov"]), IGNORECASE)
   else       : VVFJ12 = None
  if self.mode in (self.VVa1qF, self.VVYWKd):
   FFMz2e(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VV95sQ, self.VVQzCM = True , FFO4Nw(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VV95sQ, self.VVQzCM = True , CCf82q.VVs3Cw(self)[1] or "/"
  elif self.mode == self.VVEWyL  : VV95sQ, self.VVQzCM = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVa1qF : VV95sQ, self.VVQzCM = False, VVQzCM
  elif self.mode == self.VVYWKd : VV95sQ, self.VVQzCM = True , VVQzCM
  else           : VV95sQ, self.VVQzCM = True , VVQzCM
  self.VVQzCM = FF77SS(self.VVQzCM)
  self["myMenu"] = CCuvev(  directory   = None
         , VVFJ12 = VVFJ12
         , VV95sQ   = VV95sQ
         , VVeIGZ = True
         , VV67Mk = True
         , VVsRxY   = self.skinParam["width"]
         , VVNWWl   = self.skinParam["bodyFontSize"]
         , VV97fw  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVyASM,
  {
   "ok" : self.VVYfT9    ,
   "red" : self.VVfHnb   ,
   "green" : self.VV9gqK,
   "yellow": self.VVC90F  ,
   "blue" : self.VVmH1M ,
   "menu" : self.VVUajv  ,
   "info" : self.VV6s2b  ,
   "cancel": self.VVKyhe    ,
   "pageUp": self.VVNmwX   ,
   "chanUp": self.VVNmwX
  }, -1)
  FFNuVS(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVO8KX)
  global VVB2qN
  VVB2qN = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVEWyL:
   FFnsKm("VVB2qN")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVO8KX)
  FFfgOw(self)
  FFjM4Z(self["myMenu"], bg=self.cursorBG)
  FF3wB4(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVa1qF, self.VVYWKd):
   FFMz2e(self["keyGreen"], self.VV5Ab4)
   self.VV9OPk(self.VVdoK1)
  self.VVO8KX()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVUJk7(self.VVQzCM) > self.bigDirSize: FFuMBP(self, self.VVw1v1, title="Changing directory...")
  else              : self.VVw1v1()
 def VVw1v1(self):
  if self.jumpToFile : self.VVHYHs(self.jumpToFile)
  elif self.gotoMovie : self.VVj13x(chDir=False)
  else    : self["myMenu"].VVgmjU(self.VVQzCM)
 def VVj43f(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVFse8(self):
  FFuMBP(self, self.VVRKyk, title="Refreshing list ...")
 def VVRKyk(self):
  isSel = self["myMenu"].VVuyOr()
  if not isSel:
   self.VVFZhm(False)
  FF33DL()
 def VVPMPE(self, saved):
  if saved: self.VVFse8()
 def VVUJk7(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVYfT9(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVZsl9()
   if ok : self["keyBlue"].setText(self.VVAnrA())
   else : FFM3N1(self, "Cannot select item", 500)
  elif self["myMenu"].VVLJLY(): self.VVaydJ()
  else       : self.VVAKR3()
 def VVNmwX(self):
  if self.multiSelectState:
   FFM3N1(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVz4xG():
    self.VVaydJ()
 def VVaydJ(self, isDirUp=False):
  if self["myMenu"].VVLJLY():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVg6zq(self.VVbxr9())
   if self.VVUJk7(path) > self.bigDirSize : FFuMBP(self, self.VVg3bO, title="Changing directory...")
   else           : self.VVg3bO()
 def VVg3bO(self):
  self["myMenu"].descent()
  self.VVO8KX()
 def VVKyhe(self):
  if   self.multiSelectState     : self.VVFZhm(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVfHnb()
  else          : self.VVNmwX()
 def VVfHnb(self):
  if not FF5tzJ(self):
   self.close("")
 def VV9gqK(self):
  path = self.VVg6zq(self.VVbxr9())
  if self.mode == self.VVa1qF:
   self.close(path)
  elif self.mode == self.VVYWKd:
   if os.path.isfile(path) : self.close(path)
   else     : FFM3N1(self, "Cannot access this file", 1000)
 def VV6s2b(self):
  FFuMBP(self, self.VVTOq3, title="Calculating size ...")
 def VVTOq3(self):
  path = self.VVg6zq(self.VVbxr9())
  param = self.VVXxQt(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFkd4T("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCf82q.VVb2sA(path)
     freeSize = CCf82q.VVHPLs(path)
     size = totSize - freeSize
     totSize  = CCf82q.VVeeDD(totSize)
     freeSize = CCf82q.VVeeDD(freeSize)
    else:
     size = FFS0NV(path)
   usedSize = CCf82q.VVeeDD(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFwXwL(pathTxt, VVdSiQ) + "\n"
   if slBroken : fileTime = self.VVQeza(path)
   else  : fileTime = self.VVAG4u(path)
   def VVNpAU(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVNpAU("Path"    , pathTxt)
   txt += VVNpAU("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVNpAU("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVNpAU("Total Size"   , "%s" % totSize)
    txt += VVNpAU("Used Size"   , "%s" % usedSize)
    txt += VVNpAU("Free Size"   , "%s" % freeSize)
   else:
    txt += VVNpAU("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVNpAU("Owner"    , owner)
   txt += VVNpAU("Group"    , group)
   txt += VVNpAU("Perm. (User)"  , permUser)
   txt += VVNpAU("Perm. (Group)"  , permGroup)
   txt += VVNpAU("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVNpAU("Perm. (Ext.)" , permExtra)
   txt += VVNpAU("iNode"    , iNode)
   txt += VVNpAU("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVa3fR(path)
  else:
   FFB8Nz(self, "Cannot access information !")
  if len(txt) > 0:
   FF3nHt(self, txt)
 def VVXxQt(self, path):
  path = path.strip()
  path = FFOE3h(path)
  result = FFkd4T("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVLglk(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVLglk(perm, 1, 4)
   permGroup = VVLglk(perm, 4, 7)
   permOther = VVLglk(perm, 7, 10)
   permExtra = VVLglk(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFO9ap("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVa3fR(self, path):
  txt  = ""
  res  = FFkd4T("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFwXwL("File Attributes:", VVGdv9), txt)
  return txt
 def VVAG4u(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFzHDX(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFzHDX(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFzHDX(os.path.getctime(path))
  return txt
 def VVQeza(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFkd4T("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFkd4T("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFkd4T("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVg6zq(self, currentSel):
  currentDir  = self["myMenu"].VVamCY()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVLJLY():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVbxr9(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVO8KX(self):
  path = self.VVg6zq(self.VVbxr9())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVYYAv()
  if self.mode == self.VVEWyL:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVYWKd:
   path = self.VVg6zq(self.VVbxr9())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVUajv(self):
  color1 = VVHH6F
  color2 = VVdVoc
  color3 = VVmvsU
  totSel = 0
  menuW = 1000
  title = "Options"
  VVhIDJ= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVnm74()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFW43m(totSel))
     VVhIDJ.append((color1 + txt1     , "VV5hnv1" ))
     VVhIDJ.append((color1 + txt1 + txt2   , "VV5hnv2" ))
     VVhIDJ.append(VVuAtK)
    VVhIDJ.append(("[6] Copy"       , "copyBulk" ))
    VVhIDJ.append(("[7] Move"       , "moveBulk" ))
    VVhIDJ.append(("[8] %sDELETE" % VVdSiQ , "VVh70H" ))
   else:
    FFM3N1(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVa1qF, self.VVYWKd):
   VVhIDJ.append(("Properties"           , "properties" ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVg6zq(self.VVbxr9())
   isEditable = self["myMenu"].VVSGBf()
   VVhIDJ.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color1 + "Archiving / Packaging", "VVfw0k_dir"))
   elif os.path.isfile(path):
    selFile = self.VVbxr9()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar", ".7z"))
    if not isArch:
     VVhIDJ.append((color1 + "Archive ...", "VVfw0k_file"))
    isText = False
    txt = ""
    if   isArch            : VVhIDJ.extend(self.VV8qvs(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVhIDJ.extend(self.VVtDtu(True))
    elif selFile.endswith(".sh"):
     VVhIDJ.extend(self.VVxvCD(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCf82q.VVr1AP(path):
     VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color2 + "View"     , "textView_def"))
     VVhIDJ.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVhIDJ.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVOvsD(path) == "pic":
     VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color2 + "Set as PIcon for current channel" , "VVD1gB" ))
     if FFBf4e("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVhIDJ.append(VVuAtK)
      VVhIDJ.append((color2 + "Convert to MVI (1280 x 720 )" , "VVZQzrHd"   ))
      VVhIDJ.append((color2 + "Convert to MVI (1920 x 1080)" , "VVZQzrFhd"   ))
    elif selFile.endswith(CCf82q.VVcLrQ()):
     if selFile.endswith(".mvi"):
      if FFBf4e("showiframe"):
       VVhIDJ.append(VVuAtK)
       VVhIDJ.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVhIDJ.append(VVuAtK)
      VVhIDJ.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVhIDJ.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVhIDJ.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVhIDJ.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVhIDJ.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVhIDJ.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVYZfH" ))
    if len(txt) > 0:
     VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color1 + txt, "VVAKR3"))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("[4] Create SymLink", "VV6peC"))
   if isEditable:
    VVhIDJ.append(("[5] Rename"      , "VVHhvj" ))
    VVhIDJ.append(("[6] Copy"       , "copyFileOrDir" ))
    VVhIDJ.append(("[7] Move"       , "moveFileOrDir" ))
    VVhIDJ.append(("[8] %sDELETE" % VVdSiQ , "VV8muC" ))
    if fileExists(path):
     VVhIDJ.append(VVuAtK)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVhIDJ.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVhIDJ.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVhIDJ.append((chmodTxt + "777)", "chmod777"))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVhIDJ.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCf82q.VVs3Cw(self)
   if fPath:
    VVhIDJ.append(VVuAtK)
    VVhIDJ.append((color2 + "Go to Current Movie Dir", "VVj13x"))
  FFRHhp(self, self.VVkVRn, width=menuW, height=1050, title=title, VVhIDJ=VVhIDJ, VVdCOS=False, VVl9AY="#00101020", VVLICL="#00101A2A")
 def VVkVRn(self, item=None):
  if item is not None:
   path = self.VVg6zq(self.VVbxr9())
   selFile = self.VVbxr9()
   if   item == "VV5hnv1"    : self.VV5hnv(False)
   if   item == "VV5hnv2"    : self.VV5hnv(True)
   elif item == "copyBulk"     : self.VVaHRj(False)
   elif item == "moveBulk"     : self.VVaHRj(True)
   elif item == "VVh70H"    : self.VVh70H()
   elif item == "properties"    : self.VV6s2b()
   elif item == "VVfw0k_dir" : self.VVfw0k(path, True)
   elif item == "VVfw0k_file" : self.VVfw0k(path, False)
   elif item == "VVn9fu"  : self.VVn9fu(path)
   elif item == "VVhLAa"  : self.VVhLAa(path)
   elif item.startswith("extract_")  : self.VVpoLW(path, selFile, item)
   elif item.startswith("script_")   : self.VVTQ04(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVBOsD(path, selFile, item)
   elif item.startswith("textView_def") : FFsPfZ(self, path)
   elif item.startswith("textView_enc") : self.VVVt8p(path)
   elif item.startswith("text_Edit")  : CCwZEN(self, path, VVLUmk=self.VVPMPE)
   elif item.startswith("textSave_encUtf8"): self.VVC65r(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVC65r(path, "Save as Other Encoding", False)
   elif item.startswith("VVYZfH") : self.VVYZfH(path)
   elif item == "viewAsBootlogo"   : self.VV584R(path, True)
   elif item == "addMovieToBouquet"  : self.VVQOij(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVQOij(path, True)
   elif item == "playWith"     : self.VVhHYn(path)
   elif item == "VVD1gB" : self.VVD1gB(path)
   elif item == "VVZQzrHd"   : FFuMBP(self, BF(self.VVZQzr, path, False))
   elif item == "VVZQzrFhd"   : FFuMBP(self, BF(self.VVZQzr, path, True))
   elif item == "VV6peC"   : self.VV6peC(path, selFile)
   elif item == "VVHhvj"   : self.VVHhvj(path, selFile)
   elif item == "copyFileOrDir"   : self.VVPDCe(path, False)
   elif item == "moveFileOrDir"   : self.VVPDCe(path, True)
   elif item == "VV8muC"   : self.VV8muC(path, selFile)
   elif item == "chmod644"     : self.VVIg8b(path, selFile, "644")
   elif item == "chmod755"     : self.VVIg8b(path, selFile, "755")
   elif item == "chmod777"     : self.VVIg8b(path, selFile, "777")
   elif item == "createNewFile"   : self.VVMFSd(path, True)
   elif item == "createNewDir"    : self.VVMFSd(path, False)
   elif item == "VVj13x"   : self.VVj13x()
   elif item == "VVAKR3"    : self.VVAKR3()
 def VVAKR3(self):
  if self.mode == self.VVYWKd and not self.patternMode == "poster":
   return
  selFile = self.VVbxr9()
  path  = self.VVg6zq(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVOvsD(path)
   if   cat == "pic"       : self.VVoc1g(path)
   elif cat == "txt"       : FFsPfZ(self, path)
   elif cat in ("tar", "rar", "zip", "p7z") : self.VVLcQE(path, selFile)
   elif cat == "scr"       : self.VV6HaR(path, selFile)
   elif cat == "m3u"       : self.VVTYS2(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVnDJT(path, selFile)
   elif cat in ("mov", "mus")     : self.VV584R(path)
   elif not CCf82q.VVr1AP(path) : FFsPfZ(self, path)
 def VVoc1g(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVOvsD(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCuhvG.VVqol3(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVhqOz)
 def VVhqOz(self, path):
  self.VVHYHs(path)
 def VV584R(self, path, asLogo=False):
  if asLogo : CCs3ZF.VVZZWP(self, path)
  else  : FFuMBP(self, BF(self.VV8VtC, self, path), title="Playing Media ...")
 def VVmH1M(self):
  if self["keyBlue"].getVisible():
   VVFWkP = self.VV36UV()
   if VVFWkP:
    path = self.VVg6zq(self.VVbxr9())
    enableGreenBtn = False if path in self.VV36UV() else True
    newList = []
    for line in VVFWkP:
     newList.append((line, line))
    VVMVWG  = ("Delete"    , self.VV0iiq    )
    VVbPo7  = ("Add Current Dir"   , BF(self.VVjvru, path) ) if enableGreenBtn else None
    VVVW3K = ("Move Up"     , self.VVxpJV    )
    VVzwta  = ("Move Down"   , self.VVjnWA    )
    self.bookmarkMenu = FFRHhp(self, self.VVXc5B, width=1200, title="Bookmarks", VVhIDJ=newList, minRows=10 ,VVMVWG=VVMVWG, VVbPo7=VVbPo7, VVVW3K=VVVW3K, VVzwta=VVzwta, VVl9AY="#00000022", VVLICL="#00000022")
 def VV0iiq(self, VVCarR=None, path=None):
  VVFWkP = self.VV36UV()
  if VVFWkP:
   while path in VVFWkP:
    VVFWkP.remove(path)
   self.VVsTTl(VVFWkP)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV4UQJ(VVFWkP)
   self.bookmarkMenu.VVuGKw(("Add Current Dir", BF(self.VVjvru, path)))
  else:
   FFM3N1(self, "Removed", 800)
  self.VVYYAv()
 def VVjvru(self, path, VVCarR=None, item=None):
  VVFWkP = self.VV36UV()
  if len(VVFWkP) >= self.VVjRhj:
   FFB8Nz(SELF, "Max bookmarks reached (max=%d)." % self.VVjRhj)
  elif not path in VVFWkP:
   if not os.path.isdir(path):
    path = FFO4Nw(path, True)
   newList = [path] + VVFWkP
   self.VVsTTl(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV4UQJ(newList)
    self.bookmarkMenu.VVuGKw()
   else:
    FFM3N1(self, "Added", 800)
  self.VVYYAv()
 def VVxpJV(self, selectionObj, path):
  if self.bookmarkMenu:
   VVFWkP = self.bookmarkMenu.VVPYy0(True)
   if VVFWkP:
    self.VVsTTl(VVFWkP)
 def VVjnWA(self, selectionObj, path):
  if self.bookmarkMenu:
   VVFWkP = self.bookmarkMenu.VVPYy0(False)
   if VVFWkP:
    self.VVsTTl(VVFWkP)
 def VVXc5B(self, folder=None):
  if folder:
   folder = FF77SS(folder)
   self["myMenu"].VVgmjU(folder)
   self["myMenu"].moveToIndex(0)
  self.VVO8KX()
 def VV36UV(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVZqcR(self):
  return True if VV36UV() else False
 def VVsTTl(self, VVFWkP):
  line = ",".join(VVFWkP)
  FFsMp0(CFG.browserBookmarks, line)
 def VVHYHs(self, path):
  if fileExists(path):
   fDir  = FF77SS(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVgmjU(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFM3N1(self, "Not found", 1000)
 def VVj13x(self, chDir=True):
  fPath, fDir, fName = CCf82q.VVs3Cw(self)
  self.VVHYHs(fPath)
 def VVC90F(self):
  path = self.VVg6zq(self.VVbxr9())
  isAdd = False if path in self.VV36UV() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVEhqe, VVuj5g, VVdVoc
  VVhIDJ = []
  VVhIDJ.append(("Find Files ..." , "find"))
  VVhIDJ.append(("Sort ..."   , "sort"))
  VVhIDJ.append(VVuAtK)
  if isAdd: VVhIDJ.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVhIDJ.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVEWyL:
   VVhIDJ.append(VVuAtK)
   if self.multiSelectState: VVhIDJ.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVhIDJ.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVhIDJ.append(       (c3 + "Select all"    , "selAll"  ))
  FFRHhp(self, BF(self.VVi5mo, path), width=750, title="More Options", VVhIDJ=VVhIDJ, VVl9AY="#00221111", VVLICL="#00221111")
 def VVi5mo(self, path, item):
  if item:
   if   item == "find"  : self.VVFFw8(path)
   elif item == "sort"  : self.VV4WPe()
   elif item == "addBM" : self.VVjvru(path)
   elif item == "remBM" : self.VV0iiq(None, path)
   elif item == "start" : self.VVWXDx(path)
   elif item == "multiOn" : self.VVFZhm(True)
   elif item == "multiOff" : self.VVFZhm(False)
   elif item == "selAll" : self.VVFZhm(True, True)
 def VVFZhm(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFuMBP(self, BF(self["myMenu"].VVybOo, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VV9OPk(self.VVqlG1 if isOn else self.VV98Y6)
 def VV9OPk(self, mode=0):
  if   mode == self.VVdoK1 : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVqlG1: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVl9AY, self.VVLICL
  FFOrd9(self["myTitle"], titBg)
  FFOrd9(self["myBar"], titBg)
  FFOrd9(self["myBody"], bodBg)
  FFOrd9(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVAnrA()
  else     : bg, txt = VV1DvD[3], "Bookmarks"
  FFMz2e(self["keyBlue"], txt)
  FFOrd9(self["keyBlue"], bg)
  self.VVYYAv()
 def VVAnrA(self):
  return "Selected Items = %d" % self["myMenu"].VVnm74()
 def VVYYAv(self):
  if self.VV36UV() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVFFw8(self, path):
  VVhIDJ = []
  VVhIDJ.append(("Find in Current Directory"    , "findCur"  ))
  VVhIDJ.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVhIDJ.append(("Find in all Storage Systems"    , "findAll"  ))
  FFRHhp(self, BF(self.VVGjpG, path), width=700, title="Find File/Pattern", VVhIDJ=VVhIDJ, VVWLSA=True, VV14QT=True, VVl9AY="#00221111", VVLICL="#00221111")
 def VVGjpG(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVNeOu(0, path, title)
   elif item == "findCurR" : self.VVNeOu(1, path, title)
   elif item == "findAll" : self.VVNeOu(2, path, title)
 def VVNeOu(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFs37j(self, BF(self.VVUzw3, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVUzw3(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFsMp0(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFM3N1(self, "No entery", 1500)
   elif badLst  : FFM3N1(self, "Too many file !", 1500)
   else   : FFuMBP(self, BF(self.VVH81Y, mode, path, title, filePatt), title="Searching ...")
 def VVH81Y(self, mode, path, title, filePatt):
  lst = FFpNiE(FF5Yea("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCf82q.VVIxYK(lst)
   if err:
    FFB8Nz(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVJEWY = (""     , self.VVBrfg , [])
    VVlrMb = ("Go to File Location", self.VVQkm6  , [])
    FFNCSP(self, None, title="%s : %s" % (title, filePatt), header=header, VVFWkP=lst, VVN1SU=widths, VVNWWl=26, VVJEWY=VVJEWY, VVlrMb=VVlrMb)
  else:
   FFkqUz(self, "Not found !", 2000)
 def VVQkm6(self, VVhqv2, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVhqv2.cancel()
   self.VVHYHs(path)
  else:
   FFM3N1(VVhqv2, "Path not found !", 1000)
 def VVBrfg(self, VVhqv2, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFwXwL("File:"  , VVdVoc), colList[0])
  txt += "%s\n%s"  % (FFwXwL("Directory:", VVdVoc), FF77SS(colList[1]))
  FF3nHt(VVhqv2, txt, title=title)
 def VV4WPe(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVRd7c()
  VVhIDJ = []
  VVhIDJ.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVhIDJ.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVhIDJ.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVhIDJ.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVzwta = ("Mix", BF(self.VV9Iki, True))
  FFRHhp(self, BF(self.VVD1rN, False), barText=txt, width=650, title="Sort Options", VVhIDJ=VVhIDJ, VVzwta=VVzwta, VV14QT=True, VVl9AY="#00221111", VVLICL="#00221111")
 def VV9Iki(self, isMix, VVCarR, item):
  self.VVD1rN(True, item)
 def VVD1rN(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVRd7c()
   title = "Sorting ... "
   if   item == "nameAlp": FFuMBP(self, BF(self["myMenu"].VVFBMp, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFuMBP(self, BF(self["myMenu"].VVFBMp, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFuMBP(self, BF(self["myMenu"].VVFBMp, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFuMBP(self, BF(self["myMenu"].VVFBMp, typeMode , isMix, False), title=title)
 def VVWXDx(self, path):
  if not os.path.isdir(path):
   path = FFO4Nw(path, True)
  FFsMp0(CFG.browserStartPath, path)
  FFM3N1(self, "Done", 500)
 def VVF5UY(self, selFile, VVZNNf, command):
  FF5jVY(self, BF(FFFPZ4, self, command, consFont=True, VVE46B=self.VVFse8), "%s\n\n%s" % (VVZNNf, selFile))
 def VV8qvs(self, path, calledFromMenu):
  destPath = self.VVGuXo(path)
  lastPart = FFtnj1(destPath)
  color = VVdVoc if calledFromMenu else ""
  VVhIDJ = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVhIDJ.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVhIDJ.append(VVuAtK)
   VVhIDJ.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVhIDJ.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVhIDJ.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color + "Convert .zip to .tar.gz"       , "VVn9fu" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVhIDJ.append(VVuAtK)
     VVhIDJ.append((color + "Convert .tar.gz to .zip"       , "VVhLAa" ))
  return VVhIDJ
 def VVLcQE(self, path, selFile):
  FFRHhp(self, BF(self.VVpoLW, path, selFile), title="Compressed File Options", VVhIDJ=self.VV8qvs(path, False))
 def VVpoLW(self, path, selFile, item=None):
  if item is not None:
   parent  = FFO4Nw(path, False)
   destPath = self.VVGuXo(path)
   lastPart = FFtnj1(destPath)
   cmd   = ""
   ques  = "Extract file ?\n\n%s" % selFile
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFJfZ1("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFJfZ1("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unrar l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".7z"):
     cmd += FFJfZ1("7za", "p7zip", "P7Zip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; 7za l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FF1Ubx(self, cmd, consFont=True)
   elif path.endswith(".rar"):
    self.VVS1dm(item, path, parent, destPath, ques)
   elif path.endswith(".7z"):
    self.VVMS6L(item, path, parent, destPath, ques)
   elif path.endswith(".zip"):
    if item == "VVn9fu" : self.VVn9fu(path)
    else       : self.VVZrqU(item, path, parent, destPath, ques)
   elif item == "VVhLAa" and path.endswith(".tar.gz"):
    self.VVhLAa(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFkd4T("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFWB0Q(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVFse8()
    else:
     FFB8Nz(self, "Error:\n\n%s" % res, title=title)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFUGBP("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVF5UY(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVF5UY(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFO4Nw(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVF5UY(selFile, "Extract Here ?"      , cmd)
 def VVGuXo(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  elif path.endswith(".7z")  : extLen = 3
  elif path.endswith(".gz")  : extLen = 3
  else       : extLen = 0
  return path[:-extLen]
 def VVZrqU(self, item, path, parent, destPath, VVZNNf):
  FF5jVY(self, BF(self.VVam6p, item, path, parent, destPath), VVZNNf)
 def VVam6p(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFJfZ1("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFw0WV(destPath, VVfPTB))
  cmd +=   sep
  cmd += "fi;"
  FF8Tx8(self, cmd, VVE46B=self.VVFse8, consFont=True)
 def VVS1dm(self, item, path, parent, destPath, VVZNNf):
  FF5jVY(self, BF(self.VVgrdR, item, path, parent, destPath), VVZNNf)
 def VVgrdR(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF77SS(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFJfZ1("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFw0WV(destPath, VVfPTB))
  cmd +=   sep
  cmd += "fi;"
  FF8Tx8(self, cmd, VVE46B=self.VVFse8, consFont=True)
 def VVMS6L(self, item, path, parent, destPath, VVZNNf):
  FF5jVY(self, BF(self.VVGsch, item, path, parent, destPath), VVZNNf)
 def VVGsch(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = destPath
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += "7za x '%s' -o'%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFJfZ1("7za", "p7zip", "P7Zip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFw0WV(destPath, VVfPTB))
  cmd +=   sep
  cmd += "fi;"
  FF8Tx8(self, cmd, VVE46B=self.VVFse8, consFont=True)
 def VVxvCD(self, addSep=False):
  VVhIDJ = []
  if addSep:
   VVhIDJ.append(VVuAtK)
  VVhIDJ.append((VVdVoc + "View Script File"  , "script_View"  ))
  VVhIDJ.append((VVdVoc + "Execute Script File" , "script_Execute" ))
  VVhIDJ.append((VVdVoc + "Edit"     , "script_Edit"  ))
  return VVhIDJ
 def VV6HaR(self, path, selFile):
  FFRHhp(self, BF(self.VVTQ04, path, selFile), title="Script File Options", VVhIDJ=self.VVxvCD())
 def VVTQ04(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFsPfZ(self, path)
   elif item == "script_Execute" : self.VVF5UY(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCwZEN(self, path, VVLUmk=self.VVPMPE)
 def VVtDtu(self, addSep=False):
  VVhIDJ = []
  if addSep:
   VVhIDJ.append(VVuAtK)
  VVhIDJ.append((VVdVoc + "Browse IPTV Channels" , "m3u_Browse" ))
  VVhIDJ.append((VVdVoc + "Edit"     , "m3u_Edit" ))
  VVhIDJ.append((VVdVoc + "View"     , "m3u_View" ))
  return VVhIDJ
 def VVTYS2(self, path, selFile):
  FFRHhp(self, BF(self.VVBOsD, path, selFile), title="M3U/M3U8 File Options", VVhIDJ=self.VVtDtu())
 def VVBOsD(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFuMBP(self, BF(self.session.open, CC8Yh1, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCwZEN(self, path, VVLUmk=self.VVPMPE)
   elif item == "m3u_View"  : FFsPfZ(self, path)
 def VVVt8p(self, path):
  if fileExists(path) : FFuMBP(self, BF(CCbony.VVjI7F, self, path, BF(self.VVdUV9, path)), title="Loading Codecs ...")
  else    : FFM8jr(self, path)
 def VVdUV9(self, path, item=None):
  if item:
   FFsPfZ(self, path, encLst=item)
 def VVC65r(self, path, title, asUtf8):
  if fileExists(path) : FFuMBP(self, BF(CCbony.VVjI7F, self, path, BF(self.VVYLpx, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFM8jr(self, path)
 def VVYLpx(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VV4LLF(path, title, fromEnc, "UTF-8")
   else  : CCbony.VV5IFB(self, BF(self.VV4LLF, path, title, fromEnc), title="Convert to Encoding")
 def VV4LLF(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFwXwL("Successful\n\n", VVfPTB)
      txt += FFwXwL("From Encoding (%s):\n" % fromEnc, VVqZDD)
      txt += "%s\n\n" % path
      txt += FFwXwL("To Encoding (%s):\n" % toEnc, VVqZDD)
      txt += "%s\n\n" % outFile
      FF3nHt(self, txt, title=title)
    except:
     FFB8Nz(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFM3N1(self, "Cannot open file", 2000)
   self.VVFse8()
 def VVYZfH(self, path):
  title = "File Line-Break Conversion"
  FF5jVY(self, BF(self.VVKcrz, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVKcrz(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFwXwL("File converted:", VVfPTB), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFWB0Q(self, txt, title=title)
  else:
   FFM8jr(self, path, title=title)
 def VVIg8b(self, path, selFile, newChmod):
  FF5jVY(self, BF(self.VVU51n, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVU51n(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVB6fx)
  result = FFkd4T(cmd)
  if result == "Successful" : FFWB0Q(self, result)
  else      : FFB8Nz(self, result)
 def VV6peC(self, path, selFile):
  parent = FFO4Nw(path, False)
  self.session.openWithCallback(self.VVACnk, BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=parent, VV5Ab4="Create Symlink here"))
 def VVACnk(self, newPath):
  if len(newPath) > 0:
   target = self.VVg6zq(self.VVbxr9())
   target = FFOE3h(target)
   linkName = FFtnj1(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF77SS(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFB8Nz(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF5jVY(self, BF(self.VV2Sqo, target, link), "Create Soft Link ?\n\n%s" % txt, VVQk5i=True)
 def VV2Sqo(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVB6fx)
  result = FFkd4T(cmd)
  if result == "Successful" : FFWB0Q(self, result)
  else      : FFB8Nz(self, result)
 def VVHhvj(self, path, selFile):
  lastPart = FFtnj1(path)
  FFs37j(self, BF(self.VVJDxx, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVJDxx(self, path, selFile, VVSRUl):
  if VVSRUl:
   parent = FFO4Nw(path, True)
   if os.path.isdir(path):
    path = FFOE3h(path)
   newName = parent + VVSRUl
   cmd = "mv '%s' '%s' %s" % (path, newName, VVB6fx)
   if VVSRUl:
    if selFile != VVSRUl:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF5jVY(self, BF(self.VVaiDc, cmd), message, title="Rename file?")
    else:
     FFB8Nz(self, "Cannot use same name!", title="Rename")
 def VVaiDc(self, cmd):
  result = FFkd4T(cmd)
  if "Fail" in result:
   FFB8Nz(self, result)
  self.VVFse8()
 def VV5hnv(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVUb5P, title, preserve)
      , VVLUmk = BF(self.VV68pr, title))
 def VVUb5P(self, title, preserve, VVVRSv):
  totSel = self["myMenu"].VVnm74()
  totOk = totFail = 0
  VVVRSv.VVWtjR(totSel)
  VVVRSv.VVPpbS = ["", totSel, totOk, totFail, ""]
  VVVRSv.VVIQXG("Prepareing targz file")
  curDir = self["myMenu"].VVamCY()
  lastPart = FFtnj1(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVVRSv or VVVRSv.isCancelled:
      return
     if row[2][6]:
      VVVRSv.VVBQzv(1)
      name  = FFOE3h(row[0][0])
      lastPath = FFtnj1(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVVRSv:
       VVVRSv.VVPpbS = [outF, totSel, totOk, totFail, path]
       VVVRSv.VVzj1d(totOk, lastPath)
  except:
   totFail += 1
   if VVVRSv:
    VVVRSv.VVPpbS = [outF, totSel, totOk, totFail, path]
 def VV68pr(self, title, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVPpbS
  txt  = "%s:\n%s\n\n"   % (FFwXwL("Output File", VVfPTB), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFwXwL("Failed\t: %d\n" % totFail, VVdSiQ)
  if not VVVUTO: txt += "%s\n%s" % (FFwXwL("\nCancelled while copying:", VVdSiQ), path)
  FF3nHt(self, txt, title=title)
  self.VVFse8()
 def VVaHRj(self, isMove):
  self.session.openWithCallback(BF(self.VV1RBj, isMove), BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=self["myMenu"].VVamCY(), VV5Ab4="Move to here" if isMove else "Paste here"))
 def VV1RBj(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVyoAk, title, action, isMove, newPath)
       , VVLUmk = BF(self.VVLXUQ, title, action, isMove, newPath))
 def VVyoAk(self, title, action, isMove, newPath, VVVRSv):
  curDir = self["myMenu"].VVamCY()
  totOk = totFail = 0
  totSel = self["myMenu"].VVnm74()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVVRSv.VVWtjR(totSel)
  VVVRSv.VVPpbS = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVVRSv or VVVRSv.isCancelled:
    return
   if row[2][6]:
    VVVRSv.VVBQzv(1)
    VVVRSv.VVR8fR(action, totOk, FFtnj1(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFtnj1(path)
    if os.path.isdir(path): path = FFOE3h(path)
    dest = os.path.join(newPath, lastPart)
    if FFcZm9("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVVRSv:
     VVVRSv.VVPpbS = [totSel, totOk, totFail, path]
     VVVRSv.VVR8fR(action, totOk, FFtnj1(row[0][0]))
 def VVLXUQ(self, title, action, isMove, newPath, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVPpbS
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFwXwL("Failed\t: %d\n" % totFail, VVdSiQ)
  if not VVVUTO: txt += "%s\n%s" % (FFwXwL("\nCancelled while copying:", VVdSiQ), path)
  FF3nHt(self, txt, title=title)
  self.VVFse8()
 def VVh70H(self):
  tot = self["myMenu"].VVnm74()
  FF5jVY(self, BF(FFuMBP, self, self.VVfFY5, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFW43m(tot)), title="Delete Selection")
 def VVfFY5(self):
  path = self["myMenu"].VVamCY()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFjbFj(os.path.join(path, row[0][0]))
  FFM3N1(self)
  self.VVFse8()
 def VVPDCe(self, path, isMove):
  self.session.openWithCallback(BF(self.VVfhVv, isMove, path), BF(CCf82q, mode=CCf82q.VVa1qF, VVQzCM=FFO4Nw(path, False), VV5Ab4="Move to here" if isMove else "Paste here"))
 def VVfhVv(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFOE3h(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFOE3h(src)
  dst = os.path.join(dst, FFtnj1(src))
  if src == dst:
   FFB8Nz(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FF5jVY(self, BF(self.VVcoAQ, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FF5jVY(self, BF(self.VVcoAQ, prams), "Overwrite Destination Files", title=title)
  else         : self.VVcoAQ(prams)
 def VVcoAQ(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCf82q.VVAl76(src) == CCf82q.VVAl76(dst):
   FFuMBP(self, BF(self.VV8Gxg, prams), title="Moving %s ..." % srcSubj)
  else:
   FFuMBP(self, BF(self.VV2Au5, prams), title="Calculating Size ...")
 def VV8Gxg(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFkd4T("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVFse8()
  else:
   FFB8Nz(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VV2Au5(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFoQQd(src)
  else  : size = FFS0NV(src)
  if size > -1:
   self.session.open(CCZyfd, barTheme=CCZyfd.VVL0BW, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVW6lv, prams, size)
       , VVLUmk = BF(self.VVigrY, prams))
  else:
   FFB8Nz(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVW6lv(self, prams, size, VVVRSv):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVVRSv.VVWtjR(size)
  VVVRSv.VVPpbS = ("", "", False)
  def VVlfuJ(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFZ5Mj(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVVRSv or VVVRSv.isCancelled:
        VVVRSv.VVPpbS = (srcFile, "", True)
        FFZ5Mj(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVVRSv.VVBQzv(len(data))
       except Exception as e:
        VVVRSv.VVPpbS = (srcFile, str(e), False)
        FFZ5Mj(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFZ5Mj(srcFile)
   return True
  if isFile:
   tot = 1
   VVlfuJ(src, dst)
  else:
   VVVRSv.VVIQXG("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFEwyA(src)
   if not VVVRSv or VVVRSv.isCancelled:
    VVVRSv.VVPpbS = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVVRSv.VVPpbS = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVVRSv.VVIQXG("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVlfuJ(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFcZm9("rm -fr '%s'" % Dir)
   if isMove:
    FFcZm9("rm -fr '%s'" % src)
 def VVigrY(self, prams, VVVUTO, VVPpbS, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVPpbS
  if err:
   FFB8Nz(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFM3N1(self, "Canelled", 1000)
   else  : FFB8Nz(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFM3N1(self, "Done", 1500, isGrn=True)
  if VVVUTO and isMove:
   self.VVFse8()
 def VV8muC(self, path, fileName):
  path = FFOE3h(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF5jVY(self, BF(FFuMBP, self, BF(self.VVsF0T, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVsF0T(self, path):
  FFjbFj(path)
  FFM3N1(self)
  self.VVFse8()
 def VVMFSd(self, path, isFile):
  dirName = FF77SS(os.path.dirname(path))
  if isFile : objName, VVSRUl = "File"  , self.edited_newFile
  else  : objName, VVSRUl = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFs37j(self, BF(self.VVW1jY, dirName, isFile, title), title=title, defaultText=VVSRUl, message="Enter %s Name:" % objName)
 def VVW1jY(self, dirName, isFile, title, VVSRUl):
  if VVSRUl:
   if isFile : self.edited_newFile = VVSRUl
   else  : self.edited_newDir  = VVSRUl
   path = dirName + VVSRUl
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVB6fx)
    else  : cmd = "mkdir '%s' %s" % (path, VVB6fx)
    result = FFkd4T(cmd)
    if "Fail" in result:
     FFB8Nz(self, result)
    self.VVFse8()
   else:
    FFB8Nz(self, "Name already exists !\n\n%s" % path, title)
 def VVnDJT(self, path, selFile):
  c1, c2, c3 = VVuj5g, VVdVoc, VVHH6F
  VVhIDJ = []
  VVhIDJ.append((c1 + "List Package Files"         , "VVavV7"     ))
  VVhIDJ.append((c1 + "Package Information"         , "VVtffn"     ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Install Package"          , "VVO7Ld_CheckVersion" ))
  VVhIDJ.append((c2 + "Install Package (force reinstall)"     , "VVO7Ld_ForceReinstall" ))
  VVhIDJ.append((c2 + "Install Package (force overwrite)"     , "VVO7Ld_ForceOverwrite" ))
  VVhIDJ.append((c2 + "Install Package (force downgrade)"     , "VVO7Ld_ForceDowngrade" ))
  VVhIDJ.append((c2 + "Install Package (ignore failed dependencies)"  , "VVO7Ld_IgnoreDepends" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c3 + "Remove Related Package"        , "VVltXX_ExistingPackage" ))
  VVhIDJ.append((c3 + "Remove Related Package (force remove)"    , "VVltXX_ForceRemove"  ))
  VVhIDJ.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVltXX_IgnoreDepends" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Generate Feed Listing Info."        , "VVnMXE"    ))
  VVhIDJ.append(("Extract Files"           , "VV4DLP"     ))
  VVhIDJ.append(("Unbuild Package"           , "VVhHp6"     ))
  FFRHhp(self, BF(self.VV8QY2, path, selFile), VVhIDJ=VVhIDJ)
 def VV8QY2(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVavV7"      : self.VVavV7(path, selFile)
   elif item == "VVtffn"      : self.VVtffn(path)
   elif item == "VVO7Ld_CheckVersion"  : self.VVO7Ld(path, selFile, VVTdap     )
   elif item == "VVO7Ld_ForceReinstall" : self.VVO7Ld(path, selFile, VVq2DR )
   elif item == "VVO7Ld_ForceOverwrite" : self.VVO7Ld(path, selFile, VVsUET )
   elif item == "VVO7Ld_ForceDowngrade" : self.VVO7Ld(path, selFile, VVitUq )
   elif item == "VVO7Ld_IgnoreDepends" : self.VVO7Ld(path, selFile, VVnSnN )
   elif item == "VVltXX_ExistingPackage" : self.VVltXX(path, selFile, VVdRQL     )
   elif item == "VVltXX_ForceRemove"  : self.VVltXX(path, selFile, VVSwkt  )
   elif item == "VVltXX_IgnoreDepends"  : self.VVltXX(path, selFile, VVTZQY )
   elif item == "VVnMXE"     : self.VVnMXE(path, selFile)
   elif item == "VV4DLP"     : self.VV4DLP(path, selFile)
   elif item == "VVhHp6"     : self.VVhHp6(path, selFile)
 def VVavV7(self, path, selFile):
  if FFBf4e("ar") : cmd = "allOK='1';"
  else    : cmd  = FFGFBz()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFzco6(self, cmd, VVE46B=self.VVFse8)
 def VVnMXE(self, path, selFile):
  if CCxLZd.VVbUuk(self):
   txt, mTime = CCxLZd.VVrPIq(path)
   pFile = "%s-Packages-File.txt" % path
   tFile = "%s-Packages.stamps.txt" % path
   with open(pFile, "w") as pF: pF.write("%s\n" % txt)
   with open(tFile, "w") as tF: tF.write("%s\n" % mTime)
   self.VVFse8()
   txt  = "Result files:\n\n"
   txt += "%s\n\n" % os.path.basename(pFile)
   txt += "%s" % os.path.basename(tFile)
   FF3nHt(self, txt)
 def VV4DLP(self, path, selFile):
  dest  = FFO4Nw(path, True) + selFile[:-4]
  cmd  =  FFGFBz()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFUGBP("mkdir '%s'" % dest)
  cmd +=    FFUGBP("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFw0WV(dest, VVfPTB))
  cmd += "fi;"
  FFFPZ4(self, cmd, VVE46B=self.VVFse8)
 def VVhHp6(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVSbtQ = os.path.splitext(path)[0]
  else        : VVSbtQ = path + "_"
  if path.endswith(".deb")   : VVMvBL = "DEBIAN"
  else        : VVMvBL = "CONTROL"
  cmd  = FFGFBz()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVSbtQ
  cmd += "  mkdir '%s';"      % VVSbtQ
  cmd += "  CONTPATH='%s/%s';"    % (VVSbtQ, VVMvBL)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVSbtQ
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVSbtQ, VVSbtQ)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVSbtQ
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVSbtQ, VVSbtQ)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVSbtQ
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVSbtQ
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVSbtQ, FFw0WV(VVSbtQ, VVfPTB))
  cmd += "fi;"
  FFFPZ4(self, cmd, VVE46B=self.VVFse8)
 def VVtffn(self, path):
  listCmd  = FF2wdN(VVEidq, "")
  infoCmd  = FFyOYr(VVREjx , "")
  filesCmd = FFyOYr(VVEH2u, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFXA2w(VVqZDD)
   notInst = "Package not installed."
   cmd  = FFYaeB("File Info", VVqZDD)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFYaeB("System Info", VVqZDD)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFw0WV(notInst, VVdSiQ))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFYaeB("Related Files", VVqZDD)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF1Ubx(self, cmd)
  else:
   FF4L5V(self)
 def VVO7Ld(self, path, selFile, cmdOpt):
  cmd = FFyOYr(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF5jVY(self, BF(FFFPZ4, self, cmd, VVE46B=FF33DL), "Install Package ?\n\n%s" % selFile)
  else:
   FF4L5V(self)
 def VVltXX(self, path, selFile, cmdOpt):
  listCmd  = FF2wdN(VVEidq, "")
  infoCmd  = FFyOYr(VVREjx, "")
  instRemCmd = FFyOYr(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFw0WV(errTxt, VVdSiQ))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFw0WV(cannotTxt, VVdSiQ))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFw0WV(tryTxt, VVdSiQ))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF5jVY(self, BF(FFFPZ4, self, cmd, VVE46B=FF33DL), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF4L5V(self)
 def VVe4S8(self, path):
  hostName = FFkd4T("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVfw0k(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVhIDJ = []
  VVhIDJ.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVhIDJ.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVhIDJ.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVhIDJ.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVhIDJ.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVhIDJ.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVhIDJ.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVhIDJ.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVhIDJ.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVhIDJ.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFRHhp(self, BF(self.VVmvtW, path, isDir, title), VVhIDJ=VVhIDJ, title=title, VVl9AY=c1, VVLICL=c2)
 def VVmvtW(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVOUvW(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVOUvW(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVOUvW(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVOUvW(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVOUvW(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVOUvW(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVOUvW(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVOUvW(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVOUvW(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVOUvW(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VV3csp(path, False)
   elif item == "convertDirToDeb" : self.VV3csp(path, True)
 def VV3csp(self, path, VVcMDF):
  self.session.openWithCallback(self.VVFse8, BF(CCo3lT, path=path, VVcMDF=VVcMDF))
 def VVOUvW(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFO4Nw(path, True)
  lastPart = FFtnj1(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFJfZ1("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFJfZ1("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFJfZ1("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFUGBP("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFw0WV(failed, VVeCLm))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFw0WV(srcTxt, VVEhqe))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFw0WV("Output", VVfPTB))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFw0WV(failed, VVvrDy))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFzco6(self, cmd, VVE46B=self.VVFse8, title=title)
 def VVQOij(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCf82q.VVIyXe(FFO4Nw(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCJEC1(self, self, title, BF(self.VVTFzc, pathLst))
 def VVTFzc(self, pathLst):
  return CCJEC1.VVaU4W(pathLst)
 def VVn9fu(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVvwJ2, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF5jVY(self, BF(FFuMBP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFuMBP(self, fnc, title=txt)
  else:
   FFB8Nz(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVvwJ2(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF3nHt(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVFse8()
  else:
   FFZ5Mj(tarPath)
   FFB8Nz(self, "Error while converting.", title=title)
 def VVhLAa(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VV0mVy, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF5jVY(self, BF(FFuMBP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFuMBP(self, fnc, title=txt)
  else:
   FFB8Nz(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VV0mVy(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF3nHt(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVFse8()
  else:
   FFZ5Mj(zipPath)
   FFB8Nz(self, "Error while converting.", title=title)
 def VVZQzr(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF77SS(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFcZm9("rm -f '%s' '%s'" % (m1v, mvi))
  if FFcZm9("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFcZm9("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVFse8()
   FFWB0Q(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFB8Nz(self, "Cannot convert this file !", title=title)
 def VVD1gB(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCTdjW.VVJwSu()
  if pathExists(pPath):
   if CC67Fj.VVoxRi(self, title, False, cbFnc=BF(self.VVD1gB, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVhIDJ = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVhIDJ.append(("%d x %d" % (item), item))
    VVW4TT = self.VVvIuf
    VVzwta = ("Stretch", BF(self.VVoz4s, title, path, picon))
    VVCarR = FFRHhp(self, BF(self.VVpaSn, title, path, picon, False), VVhIDJ=VVhIDJ, width=700, title='PIcon Max. Size', VVW4TT=VVW4TT, VVzwta=VVzwta, barText="OK = Fit within size")
    VVCarR.VVflXp(3)
  else:
   FFB8Nz(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVoz4s(self, title, path, picon, selectionObj, item):
  self.VVpaSn(title, path, picon, True, item)
  selectionObj.cancel()
 def VVpaSn(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFcAqb(self, fncMode=CCscAN.VVOJRT)
   except Exception as e:
    FFB8Nz(self, "Image Processing error:\n\n%s" % e)
 def VVvIuf(self, VVCarR, txt, ref, ndx):
  FFYqxx(self, "_help_resize", "Picture File Resizing")
 def VVhHYn(self, path):
  FFRHhp(self, BF(self.VVFOl0, path), VVhIDJ=CC8Yh1.VVgMAZ(), width=650, title="Select Player", VVl9AY="#11220000", VVLICL="#11220000")
 def VVFOl0(self, path, rType=None):
  if rType:
   FFuMBP(self, BF(self.VV8VtC, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VV8VtC(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCqLbA.VVZoRN(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVs3Cw(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF77SS(fDir), fName
  return "", "", ""
 @staticmethod
 def VVb2sA(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVHPLs(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVeeDD(size, mode=0):
  txt = CCf82q.VVwxf0(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVwxf0(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVr1AP(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVg9pn(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFB8Nz(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVcLrQ():
  tDict = CCuvev.VVO8mQ()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVIyXe(path):
  lst = []
  for ext in CCf82q.VVcLrQ():
   lst.extend(FFjT7E(path, "*.%s" % ext))
  return sorted(lst, key=FF6Bhf(FFrOKA))
 @staticmethod
 def VVLF8C(path):
  return FFcZm9("tar -tzf '%s'" % path)
 @staticmethod
 def VVAl76(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVIxYK(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVqTJi:
   return VVqTJi
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCuvev(MenuList):
 VVkWH0   = 0
 VVoRlh   = 1
 VVa4kw   = 2
 VVH2vy   = 3
 VV5IYE   = 4
 VVTpiS   = 5
 VVE03A   = 6
 VVKEsW   = 7
 VVb1Zs   = "<List of Storage Devices>"
 VVGrI2  = "<Parent Directory>"
 VVe7tP   = 0
 VV7lGo   = 1
 VVYF58 = 2
 VVMUZq  = 3
 VV9lEs   = 4
 VVyygG   = 5
 FILE_TYPE_LINK   = 6
 VVMFVb  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VV67Mk=False, directory="/", VVeD4B=True, VV95sQ=True, VVeIGZ=True, VVFJ12=None, VVXmkC=False, VVqije=False, VVUZ9z=False, isTop=False, VV9j36=None, VVsRxY=1000, VVNWWl=30, VV97fw=30):
  MenuList.__init__(self, list, VV67Mk, eListboxPythonMultiContent)
  self.VVeD4B  = VVeD4B
  self.VV95sQ    = VV95sQ
  self.VVeIGZ  = VVeIGZ
  self.VVFJ12  = VVFJ12
  self.VVXmkC   = VVXmkC
  self.VVqije   = VVqije or []
  self.VVUZ9z   = VVUZ9z or []
  self.isTop     = isTop
  self.additional_extensions = VV9j36
  self.VVsRxY    = VVsRxY
  self.VVNWWl    = VVNWWl
  self.VV97fw    = VV97fw
  self.EXTENSIONS    = CCuvev.VVO8mQ()
  self.VVQHDq   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFwQZC("#11ff4444")
  self.l.setFont(0, gFont(VVa2lu, self.VVNWWl))
  self.l.setItemHeight(self.VV97fw)
  self.png_mem   = CCuvev.VVddI8("mem")
  self.png_usb   = CCuvev.VVddI8("usb")
  self.png_fil   = CCuvev.VVddI8("fil")
  self.png_dir   = CCuvev.VVddI8("dir")
  self.png_dirup   = CCuvev.VVddI8("dirup")
  self.png_srv   = CCuvev.VVddI8("srv")
  self.png_slwfil   = CCuvev.VVddI8("slwfil")
  self.png_slbfil   = CCuvev.VVddI8("slbfil")
  self.png_slwdir   = CCuvev.VVddI8("slwdir")
  self.VVVn0N()
  self.VVgmjU(directory)
 @staticmethod
 def VVddI8(category):
  return LoadPixmap("%s%s.png" % (VVobIL, category), getDesktop(0))
 @staticmethod
 def VVO8mQ():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"p7z":("7z"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVkEUH(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFOE3h(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFwXwL(" -> " , VVqZDD) + FFwXwL(os.readlink(path), VVfPTB)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV97fw + 10, 0, self.VVsRxY, self.VV97fw, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCajLx.VVG9jM(0, 2, self.VV97fw-4, self.VV97fw-4, png))
  return tableRow
 def VVOvsD(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVVn0N(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVuAl9(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVmTob(self, file):
  if os.path.realpath(file) == file:
   return self.VVuAl9(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVuAl9(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVuAl9(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVZsl9(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVMBKb(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVybOo(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVMBKb(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVMBKb(self, row, bg):
  if self.VVBR6g(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVBR6g(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVyygG, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VV9lEs:
    if   VVvct2           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVSGBf(self):
  return self.VVBR6g(self.list[self.l.getCurrentSelectionIndex()])
 def VVnm74(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVIwP2(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVgmjU(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVeIGZ:
    self.current_mountpoint = self.VVmTob(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVeIGZ:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVUZ9z and not self.VVIwP2(path, self.VVqije):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVkEUH(name=p.description, absolute=path, isDir=True, typ=self.VVe7tP, png=png))
    path = "/"
    if path not in self.VVUZ9z and not self.VVIwP2(path, self.VVqije):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVkEUH(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VV7lGo, png=self.png_mem))
  elif self.VVXmkC:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVQHDq = eServiceCenter.getInstance()
   list = VVQHDq.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVeD4B and not self.isTop:
   if directory == self.current_mountpoint and self.VVeIGZ:
    self.list.append(self.VVkEUH(name=self.VVb1Zs, absolute=None, isDir=True, typ=self.VVYF58, png=self.png_dirup))
   elif (directory != "/") and not (self.VVUZ9z and self.VVuAl9(directory) in self.VVUZ9z):
    self.list.append(self.VVkEUH(name=self.VVGrI2, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVMUZq, png=self.png_dirup))
  if self.VVeD4B:
   for x in directories:
    if not (self.VVUZ9z and self.VVuAl9(x) in self.VVUZ9z) and not self.VVIwP2(x, self.VVqije):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVkEUH(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFOE3h(x)) else self.VV9lEs, png=png))
  if self.VV95sQ:
   for x in files:
    if self.VVXmkC:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFwXwL(" -> " , VVqZDD) + FFwXwL(target, VVfPTB)
       else:
        png = self.png_slbfil
        name += FFwXwL(" -> " , VVqZDD) + FFwXwL(target, VVvrDy)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVOvsD(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVobIL, category))
    if (self.VVFJ12 is None) or iCompile(self.VVFJ12[0], flags=self.VVFJ12[1]).search(path):
     self.list.append(self.VVkEUH(name=name, absolute=x , isDir=False, typ=self.VVyygG, png=png))
  if self.VVeIGZ and len(self.list) == 0:
   self.list.append(self.VVkEUH(name=FFwXwL("No USB connected", VVlrJC), absolute=None, isDir=False, typ=self.VVMFVb, png=self.png_usb))
  self.l.setList(self.list)
  self.VVFBMp()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVamCY(self):
  return self.current_directory
 def VVLJLY(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVz4xG(self):
  return self.VVIHT8() and self.VVamCY()
 def VVIHT8(self):
  return self.list[0][1][7] in (self.VVb1Zs, self.VVGrI2)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVgmjU(self.getSelection()[0], self.current_directory)
 def VVIvnh(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVONwx)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVONwx)
 def VVONwx(self, action, device):
  self.VVVn0N()
  if self.current_directory is None:
   self.VVuyOr()
 def VVuyOr(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVgmjU(self.current_directory, self.VVIvnh())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVRd7c(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVkWH0 : nameAlpMode, nameAlpTxt = self.VVoRlh, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVkWH0, sAZ
  if mode == self.VVa4kw : nameNumMode, nameNumTxt = self.VVH2vy, s90
  else       : nameNumMode, nameNumTxt = self.VVa4kw, s09
  if mode == self.VV5IYE : dateMode, dateTxt = self.VVTpiS, sON
  else       : dateMode, dateTxt = self.VV5IYE, sNO
  if mode == self.VVE03A : typeMode, typeTxt = self.VVKEsW, sZA
  else       : typeMode, typeTxt = self.VVE03A, sAZ
  if   mode in (self.VVkWH0, self.VVoRlh): txt = "Name (%s)" % (sAZ if mode == self.VVkWH0 else sZA)
  elif mode in (self.VVa4kw, self.VVH2vy): txt = "Name (%s)" % (s09 if mode == self.VVkWH0 else s90)
  elif mode in (self.VV5IYE, self.VVTpiS): txt = "Date (%s)" % (sNO if mode == self.VV5IYE else sON)
  elif mode in (self.VVE03A, self.VVKEsW): txt = "Type (%s)" % (sAZ if mode == self.VVE03A else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVFBMp(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFsMp0(CFG.browserSortMode, mode)
   FFsMp0(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVIHT8() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVkWH0, self.VVoRlh):
    rev = True if mode == self.VVoRlh else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVa4kw, self.VVH2vy):
    rev = True if mode == self.VVH2vy else False
    self.list = sorted(self.list[item0:], key=FF6Bhf(BF(self.VVMzdL, isMix, rev)), reverse=rev)
   elif mode in (self.VV5IYE, self.VVTpiS):
    rev = True if mode == self.VVTpiS else False
    self.list = sorted(self.list[item0:], key=FF6Bhf(BF(self.VV9sre, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVKEsW else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVMzdL(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFrOKA(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFh6kh(dir2, dir1) or FFrOKA(name1, name2)
 def VV9sre(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFh6kh(stat2.st_ctime, stat1.st_ctime)
    else : return FFh6kh(dir2, dir1) or FFh6kh(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CC6wQD(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFMkht(VVZfrj, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVFWkP   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVZLdX(defFG, "#00FFFFFF")
  self.defBG   = self.VVZLdX(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFTlW1(self, self.Title)
  self["keyRed"].show()
  FFMz2e(self["keyGreen"] , "< > Transp.")
  FFMz2e(self["keyYellow"], "Foreground")
  FFMz2e(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVyASM,
  {
   "ok"   : self.VVsqVY     ,
   "green"   : self.VVsqVY     ,
   "yellow"  : BF(self.VVbdsq, False)  ,
   "blue"   : BF(self.VVbdsq, True)  ,
   "up"   : self.VVUREY       ,
   "down"   : self.VVrBVj      ,
   "left"   : self.VV2KSP      ,
   "right"   : self.VVVV8y      ,
   "last"   : BF(self.VVS0n6, -5) ,
   "next"   : BF(self.VVS0n6, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVtpg1)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFOrd9(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFOrd9(self["keyRed"] , c)
  FFOrd9(self["keyGreen"] , c)
  self.VV8CvZ()
  self.VVXDiN()
  FFqypJ(self["myColorTst"], self.defFG)
  FFOrd9(self["myColorTst"], self.defBG)
 def VVZLdX(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVXDiN(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVGSWt(0, 0)
     return
 def VVsqVY(self):
  self.close(self.defFG, self.defBG)
 def VVUREY(self): self.VVGSWt(-1, 0)
 def VVrBVj(self): self.VVGSWt(1, 0)
 def VV2KSP(self): self.VVGSWt(0, -1)
 def VVVV8y(self): self.VVGSWt(0, 1)
 def VVGSWt(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVoi7u()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVKtjX()
 def VV8CvZ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVKtjX(self):
  color = self.VVoi7u()
  if self.isBgMode: FFOrd9(self["myColorTst"], color)
  else   : FFqypJ(self["myColorTst"], color)
 def VVbdsq(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VV8CvZ()
   self.VVXDiN()
 def VVS0n6(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVGSWt(0, 0)
 def VVMBgv(self):
  return hex(self.transp)[2:].zfill(2)
 def VVoi7u(self):
  return ("#%s%s" % (self.VVMBgv(), self.colors[self.curRow][self.curCol])).upper()
class CCyP4s(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFMkht(VVujZS, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFTlW1(self, title="%s%s%s" % (self.Title, " " * 10, FFwXwL("Change values with Up , Down, < , 0 , >", VVlrJC)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVyASM,
  {
   "ok"  : self.VVYfT9      ,
   "cancel" : self.VVslRd      ,
   "info"  : self.VV10h8    ,
   "red"  : self.VVTHgo  ,
   "green"  : self.VVu8RD   ,
   "yellow" : BF(self.VV7Kxb, 0)  ,
   "blue"  : self.VVp7Wp    ,
   "menu"  : self.VVP5O8      ,
   "left"  : self.VV2KSP      ,
   "right"  : self.VVVV8y      ,
   "last"  : self.VVualr     ,
   "next"  : self.VVxq2P     ,
   "0"   : self.VV8NQL    ,
   "up"  : self.VVUREY       ,
   "down"  : self.VVrBVj      ,
   "pageUp" : BF(self.VVQcEx, True) ,
   "pageDown" : BF(self.VVQcEx, False) ,
   "chanUp" : BF(self.VVQcEx, True) ,
   "chanDown" : BF(self.VVQcEx, False) ,
   "play"  : BF(self.VV01EO, "pause")  ,
   "pause"  : BF(self.VV01EO, "pause")  ,
   "playPause" : BF(self.VV01EO, "pause")  ,
   "stop"  : BF(self.VV01EO, "pause")  ,
   "audio"  : BF(self.VV01EO, "audio")  ,
   "subtitle" : BF(self.VV01EO, "subtitle") ,
   "rewind" : BF(self.VV01EO, "rewind" ) ,
   "forward" : BF(self.VV01EO, "forward" ) ,
   "rewindDm" : BF(self.VV01EO, "rewindDm") ,
   "forwardDm" : BF(self.VV01EO, "forwardDm")
  }, -1)
  self.VVG9RE()
  self.onShown.append(self.VVtpg1)
  self.onClose.append(self.VVJtGP)
 def VVG9RE(self):
  lst = []
  for fil in FFjT7E(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVgqhc:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVtpg1(self):
  self.onShown.remove(self.VVtpg1)
  FF3wB4(self)
  FFfgOw(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVeTf4()
  self.VV5Zmb()
  self.VV9Rqm()
 def VVJtGP(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVZKum(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFOrd9(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VV546E()
 def VVeTf4(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFOrd9(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVYfT9(self):
  if self.settingShown:
   confItem = self.VVxPyH()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVhIDJ = []
   if isinstance(lst[0], tuple): VVhIDJ = [(x[1], x[0]) for x in lst]
   else      : VVhIDJ = [(x, x) for x in lst]
   VVCarR = FFRHhp(self, self.VVf1p9, VVhIDJ=VVhIDJ, width=700, title=title, VVl9AY="#33221111", VVLICL="#33110011")
   VVCarR.VVjcmp(confItem.getText())
  else:
   self.close("subtExit")
 def VVf1p9(self, item=None):
  if item:
   self.VVxPyH()[self.CursorPos].setValue(item)
   self.VV546E()
   self.VV5Zmb()
   self.VVLqRd(True)
 def VVslRd(self):
  for confItem in self.VVxPyH():
   if confItem.isChanged():
    FF5jVY(self, BF(self.VVTi3I, cbFnc=self.VV5TmV), "Save Changes ?", callBack_No=self.VVGRPd, title=self.Title)
    break
  else:
   self.VV5TmV()
 def VV5TmV(self):
   if self.settingShown: self.VVeTf4()
   else    : self.close("subtExit")
 def VVP5O8(self):
  if self.settingShown: self.VV7Qkn()
  else    : self.VVZKum()
 def VV2KSP(self): self.VVsyeO(-1)
 def VVVV8y(self): self.VVsyeO(1)
 def VVsyeO(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVoGqT()
   if pos == -1: ndx = self.VVh2OS(posVal)
   else  : ndx = self.VVFDBw(posVal)
   if   ndx < 0      : FFM3N1(self, "Not found" , 500)
   elif ndx == 0      : FFM3N1(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFM3N1(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVCd52(frmSec)
    if allow:
     self.VV7Kxb(delay, True)
     self.VVLqRd(force=True)
     CCwMZZ(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFM3N1(self, "Delay out of range", 800)
 def VVQcEx(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV01EO(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVualr(self) : self.VVS3Xm(5)
 def VVxq2P(self) : self.VVS3Xm(6)
 def VV8NQL(self) : self.VVS3Xm(-1)
 def VVUREY(self):
  if self.settingShown: self.VVS3Xm(1)
  else    : self.VVQcEx(True)
 def VVrBVj(self):
  if self.settingShown: self.VVS3Xm(0)
  else    : self.VVQcEx(False)
 def VVS3Xm(self, direction):
  if self.settingShown:
   confItem = self.VVxPyH()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VV546E()
   self.VV5Zmb()
   self.VVLqRd(True)
 def VVxPyH(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVGRPd(self):
  for confItem in self.VVxPyH(): confItem.cancel()
  self.VV546E()
  self.VV5Zmb()
  self.VVeTf4()
 def VVTHgo(self):
  if self.settingShown:
   FF5jVY(self, self.VViKv9, "Reset Subtitle Settings to default ?", title=self.Title)
 def VViKv9(self):
  for confItem in self.VVxPyH(): confItem.setValue(confItem.default)
  self.VVTi3I()
  self.VV546E()
  self.VV5Zmb()
 def VV7Kxb(self, delay, force=False):
  if self.settingShown or force:
   FFsMp0(CFG.subtDelaySec, delay)
   self.VVHhSo()
   self.VV546E()
   self.VV5Zmb()
   if self.settingShown:
    FFM3N1(self, 'Reset to "0"', 800, isGrn=True)
 def VVu8RD(self):
  if self.settingShown:
   self.VVTi3I()
   self.VVeTf4()
 def VVTi3I(self, cbFnc=None):
  for confItem in self.VVxPyH(): confItem.save()
  configfile.save()
  self.VVHhSo()
  FFM3N1(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VV546E(self):
  cfgLst = self.VVxPyH()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VV5Zmb(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFOTGs(path, fnt, isRepl=1)
  else:
   fnt = VVa2lu
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFdPXt(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFqypJ(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFOrd9(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFYlXF(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFdPXt(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFfZ8G()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFYyVW(self, winW, winH)
 def VV10h8(self):
  sp = "    "
  txt  = "%s\n"   % FFwXwL("Subtitle File:", VVdVoc)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFwXwL("Subtitle Settings:", VVdVoc)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVoGqT()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFdy8f(frmSec1)
   time2 = FFdy8f(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFwXwL("Timing:", VVdVoc)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFdy8f(durVal)
   txt += sp + "Progress\t: %s\n" % FFdy8f(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFwXwL("Subtitle end reached.", VVeCLm)
  FF3nHt(self, txt, title="Current Subtitle")
 def VV9Rqm(self, path="", delay=0, enc=""):
  FFuMBP(self, BF(self.VVwj7e, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVwj7e(self, path="", delay=0, enc=""):
  FFM3N1(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVY7ud(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VV546E()
     self.VVmvdi()
   else:
    path, delay, enc = CCyP4s.VVj7Xi(self)
    if path:
     self.VV9Rqm(path=path, delay=delay, enc=enc)
    else:
     self.VV7Qkn()
  except:
   pass
 def VVmvdi(self):
  posVal, durVal = self.VVoGqT()
  if self.VVZHZ6(posVal):
   return
  CCyP4s.VVuJdx(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVLqRd)
  except:
   self.timerUpdate.callback.append(self.VVLqRd)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVB8D3)
  except:
   self.timerEndText.callback.append(self.VVB8D3)
  FFM3N1(self, "Subtitle started", 700, isGrn=True)
 def VVZHZ6(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCyP4s.VVPxM7(self)
   FFZ5Mj(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV7Qkn(self):
  c1, c2, c3, c4, c5 = "", VVdVoc, VVmvsU, VVHH6F, VVeCLm
  VVhIDJ = []
  VVhIDJ.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVhIDJ.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVhIDJ.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVhIDJ.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append(("Help (Keys)"        , "help"  ))
  FFRHhp(self, self.VVC75C, VVhIDJ=VVhIDJ, width=700, title='Find Subtitle ".srt" File', VVl9AY="#33221111", VVLICL="#33110011")
 def VVC75C(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVPuPr(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVPuPr(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVph6Y, BF(CCf82q, patternMode="srt", VVQzCM=sDir))
   elif item.startswith("sugSrt") : self.VVPuPr(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFuMBP(self, BF(CCbony.VVjI7F, self, self.lastSubtFile, self.VV3Hhr, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFM3N1(self, "SRT File error", 1000)
   elif item == "disab":
    FFZ5Mj(CCyP4s.VVPxM7(self))
    self.close("subtExit")
   elif item == "help"    : FFYqxx(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VV3Hhr(self, item=None):
  if item:
   FFuMBP(self, BF(self.VV9Rqm, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVph6Y(self, path):
  if path:
   FFsMp0(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VV9Rqm(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVPuPr(self, defSrt="", mode=0, coeff=0.25):
  FFuMBP(self, BF(self.VVNnbQ, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVNnbQ(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCyP4s.VVMmvS(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFpNiE('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FF9R5Y(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VV1vPP(srtList, coeff)
     if err:
      if self.settingShown: FFkqUz(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVkNlM = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF77SS(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVkNlM.append((fName, Dir))
   VVlUqf  = ("Select"    , self.VVoyyS     , [])
   VVPEsb = self.VVkCHo
   VVJEWY = (""     , self.VVJ4w6       , [])
   VVNBO3 = (""     , BF(self.VVlJ9W, defSrt, False) , [])
   VVlrMb = ("Find Current File" , BF(self.VVlJ9W, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVN1SU=widths, VVNWWl=28, VVlUqf=VVlUqf, VVPEsb=VVPEsb, VVJEWY=VVJEWY, VVNBO3=VVNBO3, VVlrMb=VVlrMb, lastFindConfigObj=CFG.lastFindSubtitle
     , VVl9AY="#11002222", VVLICL="#33001111", VVHZxf="#33001111", VVgLJ3="#11ffff00", VVSzMt="#11445544", VVvy9F="#22222222", VVRt6l="#11002233")
  elif self.settingShown : FFkqUz(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVkCHo(self, VVhqv2):
  VVhqv2.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVJ4w6(self, VVhqv2, title, txt, colList):
  fName, Dir = colList
  FF3nHt(VVhqv2, "%s\n\n%s%s" % (FFwXwL("Path:", VVdVoc), Dir, fName), title=title)
 def VVlJ9W(self, path, VVzp4h, VVhqv2, title, txt, colList):
  for ndx, row in enumerate(VVhqv2.VVOazu()):
   if path == row[1].strip() + row[0].strip():
    VVhqv2.VVj43f(ndx)
    break
  else:
   if VVzp4h:
    FFM3N1(VVhqv2, "Not in list !", 1000)
 def VVoyyS(self, VVhqv2, title, txt, colList):
  VVhqv2.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VV9Rqm(path=path)
 def VV1vPP(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCwOKQ.VVyJ62(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCwOKQ.VVv1nQ(evName, "en")[0] or evName
   lst, err = CCyP4s.VV2exh(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVY7ud(self, path, enc=None):
  if enc and CCbony.VVwQZq(path, enc)      : enc = enc
  elif CCbony.VVwQZq(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFoQQd(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF9z80(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVCQ2X(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVGJ7Y(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVHhSo()
  return subtList, ""
 def VVGJ7Y(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVCQ2X(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVHhSo(self):
  path = CCyP4s.VVPxM7(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVLqRd(self, force=False):
  posVal, durVal = self.VVoGqT()
  if self.VVZHZ6(posVal):
   return
  curIndex = self.VVD1KW(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVB8D3()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFqypJ(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVoGqT(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqLbA.VVCqHv(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCwOKQ.VVyJ62(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVD1KW(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVh2OS(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVFDBw(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVB8D3(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFqypJ(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVp7Wp(self):
  FFuMBP(self, self.VVeYoz, title="Loading Lines ...")
 def VVeYoz(self):
  VVkNlM = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVkNlM.append((cap, FFdy8f(frm), str(frm), firstLine))
  if VVkNlM:
   title = "Select Current Subtitle Line"
   VVNgbt  = self.VVb3Ax
   VVPEsb = self.VVF6CF
   VVlUqf  = ("Select"   , self.VVqytc , [title])
   VVlrMb = ("Current Line" , self.VVRhZM , [True])
   VVkGmL = ("Reset Delay" , self.VV4p1w , [])
   VV1FeB = ("New Delay"  , self.VV0QZ8   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVrLHE  = (CENTER , CENTER, CENTER , LEFT    )
   VVhqv2 = FFNCSP(self, None, title=title, header=header, VVFWkP=VVkNlM, VVrLHE=VVrLHE, VVN1SU=widths, VVNWWl=28, VVNgbt=VVNgbt, VVPEsb=VVPEsb, VVlUqf=VVlUqf, VVlrMb=VVlrMb, VVkGmL=VVkGmL, VV1FeB=VV1FeB
          , VVl9AY="#33002222", VVLICL="#33001111", VVHZxf="#33110011", VVgLJ3="#11ffff00", VVSzMt="#0a334455", VVvy9F="#22222222", VVRt6l="#33002233")
  else:
   FFkqUz(self, "Cannot read lines !", 2000)
 def VVb3Ax(self, VVhqv2):
  self.subtLinesTable = VVhqv2
  if CFG.subtDelaySec.getValue():
   VVhqv2["keyYellow"].show()
   VVhqv2["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVhqv2["keyYellow"].hide()
  VVhqv2["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFOrd9(VVhqv2["keyBlue"], "#22222222")
  VVhqv2.VVAuRJ(BF(self.VVFreP, VVhqv2))
  self.VVRhZM(VVhqv2, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVJz8H)
  except:
   self.timerSubtLines.callback.append(self.VVJz8H)
  self.timerSubtLines.start(1000, False)
 def VVF6CF(self, VVhqv2):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVhqv2.cancel()
 def VVJz8H(self):
  if self.subtLinesTable:
   VVhqv2 = self.subtLinesTable
   posVal, durVal = self.VVoGqT()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVD1KW(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVhqv2.VVregv(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVhqv2.VVjqpY(self.subtLinesTableNdx, row)
     row = VVhqv2.VVregv(curIndex)
     row[0] = color + row[0]
     VVhqv2.VVjqpY(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVqytc(self, VVhqv2, Title):
  delay, color, allow = self.VVzPgQ(VVhqv2)
  if allow:
   self.VVF6CF(VVhqv2)
   self.VV7Kxb(delay, True)
  else:
   FFM3N1(VVhqv2, "Delay out of range", 1500)
 def VVRhZM(self, VVhqv2, VVzp4h, onlyColor=False):
  if VVhqv2:
   posVal, durVal = self.VVoGqT()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVD1KW(posVal)
    if curIndex > -1:
     VVhqv2.VVj43f(curIndex)
    else:
     ndx = self.VVh2OS(posVal)
     if ndx > -1:
      VVhqv2.VVj43f(ndx)
 def VV4p1w(self, VVhqv2, title, txt, colList):
  if VVhqv2["keyYellow"].getVisible():
   self.VV7Kxb(0, True)
   VVhqv2["keyYellow"].hide()
   self.VVRhZM(VVhqv2, False)
 def VVFreP(self, VVhqv2):
  delay, color, allow = self.VVzPgQ(VVhqv2)
  VVhqv2["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVzPgQ(self, VVhqv2):
  lineTime = float(VVhqv2.VVHMjy()[2].strip())
  return self.VVCd52(lineTime)
 def VVCd52(self, lineTime):
  posVal, durVal = self.VVoGqT()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVuj5g
   else     : allow, color = False, VVeCLm
   delay = FFYuUY(val, -600, 600)
  return delay, color, allow
 def VV0QZ8(self, VVhqv2, title, txt, colList):
  pass
 @staticmethod
 def VVx18n(SELF):
  path, delay, enc = CCyP4s.VVj7Xi(SELF)
  return True if path else False
 @staticmethod
 def VVj7Xi(SELF):
  path, delay, enc = CCyP4s.VVOKxl(SELF)
  if not path:
   path = CCyP4s.VVnGqm(SELF)
  return path, delay, enc
 @staticmethod
 def VVOKxl(SELF):
  srtCfgPath = CCyP4s.VVPxM7(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF9z80(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVPxM7(SELF):
  fPath, fDir, fName = CCf82q.VVs3Cw(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCwOKQ.VVyJ62(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFWctZ(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVnGqm(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCf82q.VVs3Cw(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCyP4s.VVMmvS(SELF)
    bLst, err = CCyP4s.VV2exh(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVMmvS(SELF):
  fPath, fDir, fName = CCf82q.VVs3Cw(SELF)
  if pathExists(fDir):
   files = FFjT7E(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VV2exh(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VViLWu():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVuJdx(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCyP4s.VVFDee()
 @staticmethod
 def VVFDee():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CC7rq1(ScrollLabel):
 def __init__(self, parentSELF, text="", VV9A2b=True):
  ScrollLabel.__init__(self, text)
  self.VV9A2b   = VV9A2b
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VV6TZX  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVNWWl    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVyASM,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VV1RCH ,
   "green"   : self.VVgU0x ,
   "yellow"  : self.VV8mVR ,
   "blue"   : self.VVO4nm ,
   "up"   : self.VVn9SE   ,
   "down"   : self.VV7l89  ,
   "left"   : self.VVn9SE   ,
   "right"   : self.VV7l89  ,
   "last"   : BF(self.VVPnew, 0) ,
   "0"    : BF(self.VVPnew, 1) ,
   "next"   : BF(self.VVPnew, 2) ,
   "pageUp"  : self.VVF2Jw   ,
   "chanUp"  : self.VVF2Jw   ,
   "pageDown"  : self.VVwbOx   ,
   "chanDown"  : self.VVwbOx
  }, -1)
 def VVsOYo(self, isResizable=True, VVfTAX=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFqypJ(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFOrd9(self.parentSELF["keyRedTop"], "#113A5365")
  FF3wB4(self.parentSELF, True)
  self.isResizable = isResizable
  if VVfTAX:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVNWWl  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFOrd9(self, color)
 def VVdzKe(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VV97fw  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VV97fw)
  margin   = int(VV97fw / 6)
  self.pageHeight = int(self.pageLines * VV97fw)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV6TZX - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVO5CV()
 def VVn9SE(self):
  if self.VV6TZX > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VV7l89(self):
  if self.VV6TZX > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVF2Jw(self):
  self.setPos(0)
 def VVwbOx(self):
  self.setPos(self.VV6TZX-self.pageHeight)
 def VVOfpM(self):
  return self.VV6TZX <= self.pageHeight or self.curPos == self.VV6TZX - self.pageHeight
 def getText(self):
  return self.message
 def VVO5CV(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV6TZX, 3))
   start = int((100 - vis) * self.curPos / (self.VV6TZX - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVCqdo=VVDdVy):
  old_VVOfpM = self.VVOfpM()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VV6TZX = self.long_text.calculateSize().height()
   if self.VV9A2b and self.VV6TZX > self.pageHeight:
    self.scrollbar.show()
    self.VVO5CV()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VV6TZX))
    self.VV6TZX = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VV6TZX))
   else:
    self.scrollbar.hide()
   if   VVCqdo == VVEPk2: self.setPos(0)
   elif VVCqdo == VVevDz : self.VVwbOx()
   elif old_VVOfpM    : self.VVwbOx()
 def appendText(self, text, VVCqdo=VVevDz):
  self.setText(self.message + str(text), VVCqdo=VVCqdo)
 def VV8mVR(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV19Rp(size)
 def VVO4nm(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV19Rp(size)
 def VVgU0x(self):
  self.VV19Rp(self.VVNWWl)
 def VV19Rp(self, VVNWWl):
  self.long_text.setFont(gFont(self.fontFamily, VVNWWl))
  self.setText(self.message, VVCqdo=VVDdVy)
  self.VVjhj8()
 def VVPnew(self, align):
  self.long_text.setHAlign(align)
 def VV1RCH(self):
  VVhIDJ = []
  VVhIDJ.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Align Left" , "left" ))
  VVhIDJ.append(("Align Center" , "center" ))
  VVhIDJ.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVhIDJ.append(VVuAtK)
   VVhIDJ.append((FFwXwL("Save to File", VVdVoc), "save"))
  VVhIDJ.append(VVuAtK)
  VVhIDJ.append(("Keys (Shortcuts)", "help"))
  FFRHhp(self.parentSELF, self.VVHGff, VVhIDJ=VVhIDJ, title="Text Option", width=500)
 def VVHGff(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVPnew(0)
   elif item == "center" : self.VVPnew(1)
   elif item == "right" : self.VVPnew(2)
   elif item == "save"  : self.VVZUYS()
   elif item == "help"  : FFYqxx(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVZUYS(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF77SS(expPath), self.outputFileToSave, FFERmH())
   with open(outF, "w") as f:
    f.write(FFpdHF(self.message))
   FFWB0Q(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFB8Nz(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVjhj8(self, minHeight=0):
  if self.isResizable:
   VV97fw = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VV97fw * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VV6TZX < self.pageHeight:
    textH = max(textH, self.VV6TZX)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
