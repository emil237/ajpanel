import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVAgrE   = "v8.6.2"
VVUalC    = "01-03-2023"
EASY_MODE    = 0
VVqdPy   = 0
VVu2Z1   = 0
VV0xPn  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVydp3  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVbRSD    = "/media/usb/"
VVb1MY    = "/usr/share/enigma2/picon/"
VVboSE = "/etc/enigma2/blacklist"
VVPxkP   = "/etc/enigma2/"
VVGEIo   = "AJPan"
VVCAF9  = "AUTO FIND"
VVvCGo  = "Custom"
VVEJzO  = None
VVM8pl    = ""
VVI9QA = "Regular"
VVe85a = "Fixed"
VVzmhg  = "AJP_Main"
VVdir1 = "AJP_Terminal"
VV28ZM = "AJP_System"
VVbeZc  = VVI9QA
VVW2jY    = ""
VViDgN   = " && echo 'Successful' || echo 'Failed!'"
VVwyjo  = "Cannot continue (No Enough Memory) !"
VVO3mz  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVQZ4P  = "utf8"
VVVvw4    = ("-" * 100, )
SEP      = "-" * 80
VVLt64  = False
VVFBr8  = False
VV3sDt     = 0
VVERBh    = 1
VVsOWG    = 2
VVwoLN   = 3
VVGJSr    = 4
VVBAUc    = 5
VVgJDM = 6
VVtrva = 7
VVxNYT  = 8
VVHAru   = 9
VVO5KY  = 10
VVY1SD  = 11
VVMc7q = 12
VV6ZL1 = 13
VV8XWP = 14
VVKY6h  = 15
VVytm4    = 16
VVEAg6   = 17
VVA3ui   = 18
VV2Ev8    = 19
VVHYPd    = 20
VVzuks  = 21
VVDZ6a    = 22
VVLTYB   = 0
VVFlog   = 1
VV8u5W   = 2
def FFlxZo():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVbeZc
  if VVzmhg in lst and CFG.fontPathMain.getValue(): VVbeZc = VVzmhg
  else               : VVbeZc = VVI9QA
  return lst
 else:
  return [VVI9QA]
def FFdhDJ(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVQZ4P)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVCAF9, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelection(default=2, choices=[(x, str(x)) for x in range(1, 6, 1)])
CFG.PIconsPath     = ConfigDirectory(default=VVb1MY, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVbRSD, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVbeZc, choices=[(x,  x) for x in FFlxZo()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFsYF3():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVBdNY  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVTmrp = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVBdNY  : return 0
  elif VVTmrp : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVY4t9 = FFsYF3()
VVX5FP = VVi1yn = VVEWKM = VVIZs4 = VVqDXM = VVljbY = VVFb7H = VVbtEO = VVhmJa = VVI2ZY = VVde5r = VVQzZA = VVi9VJ = VVh9Nn = VVB56o = VVqIxN = ""
def FFn6hl()  : FFMxTj(FF4WJF())
def FFkY98()  : FFMxTj(FFGKKo())
def FFAfQ5(tDict): FFMxTj(iDumps(tDict, indent=4, sort_keys=True))
def FFs7j6(*args): FFiOuH(True, True, *args)
def FFMxTj(*args) : FFiOuH(True , False , *args)
def FFuQY9(*args): FFiOuH(False, False, *args)
def FFiOuH(addSep=True, isArray=True, *args):
 if VVqdPy:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFb4e5(fnc):
 def VVNyNj(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFMxTj(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVNyNj
def FFeNKl(*args):
 if VVqdPy:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFuQY9("Added to : %s" % path)
def FFZuXb(txt, isAppend=True, ignoreErr=False):
 if VVqdPy:
  tm = FFmMUB()
  err = ""
  if not ignoreErr:
   err = FFGKKo()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFMxTj(err)
  FFMxTj("Output Log File : %s" % fileName)
def FFGKKo():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFmMUB()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FF4WJF():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVsoB3 = 0
def FFTJlj():
 global VVsoB3
 VVsoB3 = iTime()
def FFszMi(txt=""):
 FFMxTj(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVsoB3)).rstrip("0"), txt))
VVK4b7 = []
def FFqLYS(win):
 global VVK4b7
 if not win in VVK4b7:
  VVK4b7.append(win)
def FFSv8C(*args):
 global VVK4b7
 for win in VVK4b7:
  try:
   win.close()
  except:
   pass
 VVK4b7 = []
def FFWffk():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV5WKm = FFWffk()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFA4Qu()    : return PluginDescriptor(fnc=FFHEWn, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFX5Ub()      : return getDescriptor(FFDYmb , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFXf1W()     : return getDescriptor(FFrgOM  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFRSvt()  : return getDescriptor(FFPy98, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFighl() : return getDescriptor(FFcjzw , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFcGKT()  : return getDescriptor(FF7ME9 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFWtIO()  : return getDescriptor(FFJoqs  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFHRuD()      : return getDescriptor(FFeNwF, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFXf1W() , FFX5Ub() , FFA4Qu() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFRSvt())
  result.append(FFighl())
  result.append(FFcGKT())
  result.append(FFWtIO())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFHRuD())
 return result
def FFHEWn(reason, **kwargs):
 if reason == 0:
  CCwex4.VVk6qa()
  if "session" in kwargs:
   session = kwargs["session"]
   FF0J73(session)
   CCWpkN(session)
def FFDYmb(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFrgOM, PLUGIN_NAME, 45)]
 else:
  return []
def FFrgOM(session, **kwargs):
 session.open(Main_Menu)
def FFPy98(session, **kwargs):
 session.open(CCNmp1)
def FFcjzw(session, **kwargs):
 session.open(CCXyjP)
def FF7ME9(session, **kwargs):
 CCXYrc.VVRGWe(session)
def FFJoqs(session, **kwargs):
 FFtWxv(session, reopen=True)
def FFeNwF(session, **kwargs):
 session.open(CCUr80, fncMode=CCUr80.VV26qy)
def FFDKDt():
 FFGXJw(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFRSvt(), FFighl(), FFcGKT(), FFWtIO() ])
 FFGXJw(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFHRuD() ])
def FFGXJw(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FF0J73(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFK6fJ, session, "lok")
 hk.actions["longCancel"]= BF(FFK6fJ, session, "lesc")
 hk.actions["longRed"] = BF(FFK6fJ, session, "lred")
 for k in (CCzEE9.VV7NcD, CCzEE9.VV3OIz, CCzEE9.VVeZKN):
  hk.actions[k] = BF(CCzEE9.VVIVlm, session, k)
def FFK6fJ(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCQXsN.VVqYKv:
    CCQXsN.VVqYKv.close()
   if not CCXYrc.VVvQtf:
    CCXYrc.VVRGWe(session)
  except:
   pass
def FFE6Br(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FF3tZI(SELF, title="", addLabel=False, addScrollLabel=False, VVZ4NM=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFFBSc()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VV4S08 = eTimer()
 try: SELF.VVkrDN = SELF.VV4S08.timeout.connect(BF(FFgLMQ, SELF))
 except: SELF.VV4S08.callback.append(BF(FFgLMQ, SELF))
 SELF.onClose.append(SELF.VV4S08.stop)
 FFgLMQ(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCTyJ1(SELF)
 if VVZ4NM:
  SELF["myMenu"] = MenuList(VVZ4NM)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VV4SyA ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFLPhw(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFnpaR, SELF, "0"),
  "1" : BF(FFnpaR, SELF, "1"),
  "2" : BF(FFnpaR, SELF, "2"),
  "3" : BF(FFnpaR, SELF, "3"),
  "4" : BF(FFnpaR, SELF, "4"),
  "5" : BF(FFnpaR, SELF, "5"),
  "6" : BF(FFnpaR, SELF, "6"),
  "7" : BF(FFnpaR, SELF, "7"),
  "8" : BF(FFnpaR, SELF, "8"),
  "9" : BF(FFnpaR, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFawXM, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFnpaR(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVqIxN:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVqIxN + SELF.keyPressed + VVi1yn)
    txt = VVi1yn + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF7BjW(SELF, txt)
def FFawXM(SELF, tableObj, colNum, isMenu):
 FF7BjW(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFhc8v(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVcLR7(i)
     else  : SELF.VVpxIX(i)
     break
 except:
  pass
def FFFBSc():
 return ("  %s" % VVW2jY)
def FFTvkX(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFhc8v(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFYkgg(color):
 return parseColor(color).argb()
def FFDUax(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFIznG(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFtvBS(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFVW8g(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVqIxN)
 else:
  return ""
def FF437T(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVqIxN)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFNr4J(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVqIxN
def FFsa3j(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFVW8g(SEP, VVde5r))
 else : return "echo -e '%s';" % SEP
def FF0CQw(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFNr4J(title, color)
def FF4VOV(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFmi7L(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFdw1m(fncCB):
 tCons = CC0afB()
 tCons.ePopen(":", BF(FFh69i, fncCB))
def FFh69i(fncCB, result, retval):
 fncCB()
def FF1QiT(SELF, fnc, title="Processing ...", clearMsg=True):
 FF7BjW(SELF, title)
 tCons = CC0afB()
 tCons.ePopen(":", BF(FF3NKY, SELF, fnc, clearMsg))
def FF3NKY(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF7BjW(SELF)
def FFcLfl(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVwyjo
  else       : return ""
def FFtLFA(cmd):
 txt = FFcLfl(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FF0hBQ(cmd):
 lines = FFtLFA(cmd)
 if lines: return lines[0]
 else : return ""
def FFw8g8(SELF, cmd):
 lines = FFtLFA(cmd)
 VVJIKO = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVJIKO.append((key, val))
  elif line:
   VVJIKO.append((line, ""))
 if VVJIKO:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFW2Tv(SELF, None, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=28)
 else:
  FFftfY(SELF, cmd)
def FFKiof(cmd):
 return os.system(FFyMLY(cmd)) == 0
def FFuxno(cmd):
 return os.system(FFPg54(cmd)) == 0
def FFyMLY(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFPg54(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFftfY(    SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVbnXV=True, VVgcXL=VVFlog, **kwargs)
def FFC7Cq(  SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, **kwargs)
def FFA10e(   SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVoG0G=True, VV1Mhm=True, VVgcXL=VVFlog, **kwargs)
def FFfDBJ(  SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVoG0G=True, VV1Mhm=True, VVgcXL=VV8u5W, **kwargs)
def FFxjL4(  SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVmI01=True , **kwargs)
def FFKn3Y(  session, cmd, **kwargs):      session.open(CCOBbu, VVAq5S=cmd, VVmI01=True , **kwargs)
def FFvlcP( SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVm3aA=True   , **kwargs)
def FFc045( SELF, cmd, **kwargs): SELF.session.open(CCOBbu, VVAq5S=cmd, VVchSg=True  , **kwargs)
def FF4wzI(cmd):
 return FFKiof("which %s" % cmd)
def FFoJDA():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FF0hBQ(cmd)
def FFhDaE(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VV1LmT     = 0
VVphAw      = 1
VVWjcv   = 2
VVCfAq   = 3
VVsD89      = 4
VVEQtj      = 5
VVS7Xr     = 6
VVTCqL     = 7
VVLJqS     = 8
VV5fye = 9
VVYeKx = 10
VVcuwj = 11
VVhGyM  = 12
VVhXK7     = 13
VVZceH  = 14
VV0gcx  = 15
def FF8xxa(parmNum, grepTxt):
 if   parmNum == VV1LmT  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVphAw   : param = ["list"   , "apt list"    ]
 elif parmNum == VVWjcv: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVCfAq: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFoJDA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF2pmn(parmNum, package):
 if   parmNum == VVsD89      : param = ["info"      , "apt show"         ]
 elif parmNum == VVEQtj      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVS7Xr     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVTCqL     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVLJqS     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VV5fye : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVYeKx : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVcuwj : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVhGyM  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVhXK7     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVZceH  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV0gcx  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFoJDA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFib1Q():
 result = FF0hBQ("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FF2pmn(VVLJqS, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFyMLY("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFyMLY("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFVW8g(failed1, VVde5r))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFVW8g(failed2, VVde5r))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFVW8g(failed3, VVEWKM))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF6Lzl(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF2pmn(VVLJqS , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFyMLY("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFVW8g(failed1, VVde5r))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFVW8g(failed2, VVEWKM))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFBRKz(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CC9SOR.VVSrYP()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFMA9m(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFBRKz(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFRva2(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFPebg(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFBRKz(path, maxSize=maxSize, encLst=encLst)
  if lines: FFXEvX(SELF, lines, title=title, VVgcXL=VVFlog, width=1600, height=1000, titleFontSize=30)
  else : FFoJHK(SELF, path, title=title)
 else:
  FF7Hmv(SELF, path, title)
def FFC2xZ(SELF, fName, title):
 path = VVrRM9 + fName
 if fileExists(path):
  txt = FFBRKz(path)
  txt = txt.replace("#W#", VVqIxN)
  txt = txt.replace("#Y#", VVQzZA)
  txt = txt.replace("#G#", VVi1yn)
  txt = txt.replace("#C#", VVi9VJ)
  txt = txt.replace("#P#", VVqDXM)
  FFXEvX(SELF, txt, title=title)
 else:
  FF7Hmv(SELF, path, title)
def FFVpah(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFabdw(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFSiyE(parent)
 else    : return FFliS8(parent)
def FFRa3J(path):
 return os.path.basename(os.path.normpath(path))
def FFxuJG(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFPebg(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFkmyW(path):
 path = FFliS8(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFoEhk(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFPgYE(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFfhv3(path):
 try: os.remove(path)
 except: pass
def FFg7n1(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFQQBK(path):
 return FFKiof("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFKtq8(path):
 return FFKiof("cp -f '%s' '%s.bak'" % (path, path))
def FFSiyE(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFliS8(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFDPUB():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VV0xPn)
 paths.append(VV0xPn.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFVpah(ba)
 for p in list:
  p = ba + p + VV0xPn
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVGEIo, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VV0xPn, VVGEIo , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVBOse, VVrRM9 = FFDPUB()
def FFWhqi():
 def VVvrGQ(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VV79dT   = VVvrGQ(CFG.backupPath, CCVmVV.VVKPy4())
 VVFiqn   = VVvrGQ(CFG.downloadedPackagesPath, t)
 VVmSC9  = VVvrGQ(CFG.exportedTablesPath, t)
 VVGPhp  = VVvrGQ(CFG.exportedPIconsPath, t)
 VVmaRt   = VVvrGQ(CFG.packageOutputPath, t)
 global VVbRSD
 VVbRSD = FFSiyE(CFG.backupPath.getValue())
 if VV79dT or VVmaRt or VVFiqn or VVmSC9 or VVGPhp or oldMovieDownloadPath:
  configfile.save()
 return VV79dT, VVmaRt, VVFiqn, VVmSC9, VVGPhp, oldMovieDownloadPath
def FFHdqb(path):
 path = FFliS8(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFQMId(SELF, pathList, tarFileName, addTimeStamp=True):
 VVDpqo = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVDpqo.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVDpqo.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVDpqo.append(path)
 if not VVDpqo:
  FF0eUf(SELF, "Files not found!")
 elif not pathExists(VVbRSD):
  FF0eUf(SELF, "Path not found!\n\n%s" % VVbRSD)
 else:
  VVJFYp = FFSiyE(VVbRSD)
  tarFileName = "%s%s" % (VVJFYp, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFXJI8())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVDpqo:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFVW8g(tarFileName, VVhmJa))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFVW8g(failed, VVhmJa))
  cmd += "fi;"
  cmd +=  sep
  FFC7Cq(SELF, cmd)
def FFBjfS(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFQKHn(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFQKHn(SELF["keyInfo"], "info")
def FFQKHn(barObj, fName):
 path = "%s%s%s" % (VVrRM9, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFwEqh(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FF8TFY(satNum)
  return satName
def FF8TFY(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFAVEM(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFwEqh(val)
  else  : sat = FF8TFY(val)
 return sat
def FFmcAD(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFwEqh(num)
 except:
  pass
 return sat
def FFH5tp(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFAJK0(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFQKi3(info, iServiceInformation.sServiceref)
   prov = FFQKi3(info, iServiceInformation.sProvider)
   state = str(FFQKi3(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFBV7X(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFsUIS(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFQKi3(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFqmmY(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFmmIM(refCode):
 info = FFdLDb(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFkO4T(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFNsY4(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFdLDb(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV8MQ7 = eServiceCenter.getInstance()
  if VV8MQ7:
   info = VV8MQ7.info(service)
 return info
def FFzGKI(SELF, refCode, VVEwyq=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFsUIS(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCqj56()
  if pr.VVxcLl(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVBQZ0(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFzx2D(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVEwyq:
   FFwBZC(SELF, isFromSession)
 try:
  VVbIOb = InfoBar.instance
  if VVbIOb:
   VVWuh1 = VVbIOb.servicelist
   if VVWuh1:
    servRef = eServiceReference(refCode)
    VVWuh1.saveChannel(servRef)
 except:
  pass
def FFzx2D(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCqj56()
    if pr.VVxcLl(refCode, chName, decodedUrl, iptvRef):
     pr.VVBQZ0(SELF, isFromSession)
def FFBV7X(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FF98yX(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFXFl9(url): return FFeEbK(url) or FFHIEC(url)
def FFeEbK(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFHIEC(url): return any(x in url for x in ("/series/", "mode=series"))
def FFsUIS(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FF6s8T(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF6s8T(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFVH3K(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFgvTB(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFO3Nz(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF4Ay2(txt):
 try:
  return FFgvTB(FFO3Nz(txt)) == txt
 except:
  return False
def FFFDtI(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFSiyE(newPath), patt))
def FFwBZC(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCXYrc.VVRGWe(session)
 else      : FFtWxv(session, reopen=True)
def FFtWxv(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFtWxv, session), CCQXsN)
  except:
   try:
    FFsrNe(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FF5gv6(refCode):
 tp = CCwj2W()
 if tp.VVp6aW(refCode) : return True
 else        : return False
def FFckWq(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFwnFB(True)
     return True
 return False
def FFwnFB(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FF91so()
def FF91so():
 VVbIOb = InfoBar.instance
 if VVbIOb:
  VVWuh1 = VVbIOb.servicelist
  if VVWuh1:
   VVWuh1.setMode()
def FFNTAQ(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV8MQ7 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV8MQ7.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFlozs():
 VVaaQZ = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVlwSV = list(VVaaQZ)
 return VVlwSV, VVaaQZ
def FFZ1wQ():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFrtVw(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFmWOg(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFKMpI():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFXJI8():
 return FFKMpI().replace(" ", "_").replace("-", "").replace(":", "")
def FFaFw5(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFmMUB():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFacHF(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCXyjP.VVcPlk(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCXyjP.VVafKo(fName)
     phpFile = tmpDir + fName + ext
     FFKiof("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFaPm7(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FF1OOs(num):
 return "s" if num > 1 else ""
def FF6FFy(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFvWYU(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFIi1s(a, b):
 return (a > b) - (a < b)
def FFaQHk(a, b):
 def VVOGjo(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVOGjo(a)
 b = VVOGjo(b)
 return (a > b) - (a < b)
def FFl2yM(mycmp):
 class CCsczt(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCsczt
def FFH1Ib(SELF, message, title="", VVtCUJ=None):
 SELF.session.openWithCallback(VVtCUJ, CCAMA3, title=title, message=message, VVTarI=True)
def FFXEvX(SELF, message, title="", VVgcXL=VVFlog, VVtCUJ=None, **kwargs):
 SELF.session.openWithCallback(VVtCUJ, CCAMA3, title=title, message=message, VVgcXL=VVgcXL, **kwargs)
def FF0eUf(SELF, message, title="")  : FFsrNe(SELF.session, message, title)
def FF7Hmv(SELF, path, title="") : FFsrNe(SELF.session, "File not found !\n\n%s" % path, title)
def FFoJHK(SELF, path, title="") : FFsrNe(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFPXac(SELF, title="")  : FFsrNe(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFsrNe(session, message, title="") : session.open(BF(CCFtJi, title=title, message=message))
def FFFMZg(SELF, VVtCUJ, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVtCUJ, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVtCUJ, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF0eUf(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF4s3j(SELF, callBack_Yes, VV6LqR, callBack_No=None, title="", VViggQ=False, VVsXR5=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFFBao, callBack_Yes, callBack_No)
         , BF(CCVDHz, title=title, VV6LqR=VV6LqR, VVsXR5=VVsXR5, VViggQ=VViggQ))
def FFFBao(callBack_Yes, callBack_No, FF4s3jed):
 if FF4s3jed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF7BjW(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFIznG(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VV4S08.start(timeout, True)
  except: pass
 else: FFgLMQ(SELF)
def FFVyvQ(*kargs, **kwargs):
 FFdw1m(BF(FF7BjW, *kargs, **kwargs))
def FFgLMQ(SELF):
 try:
  SELF.VV4S08.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFXZrK(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFW2Tv(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCWhQY, **kwargs))
  else   : win = SELF.session.open(BF(CCWhQY, **kwargs))
  FFqLYS(win)
  return win
 except:
  return None
def FFLMiy(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCfVwq, **kwargs))
 FFqLYS(win)
 return win
def FF2YB6(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FF1giv(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFGNa7(SELF, **kwargs):
 SELF.session.open(CCUr80, **kwargs)
def FFxlor(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFmOW7(SELF[name], "#000000", 3)
  except:
   pass
def FFmOW7(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFxf4g(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVbeZc, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFxUTp(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFxf4g(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFrdtL(SELF, winSize.width(), winSize.height())
def FFrdtL(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFeubS():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFhoFB(VVsgYf):
 screenSize  = FFeubS()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVsgYf)
 return bodyFontSize
def FFyUJL(VVsgYf, extraSpace):
 font = gFont(VVbeZc, VVsgYf)
 VV12Gz = fontRenderClass.getInstance().getLineHeight(font) or (VVsgYf * 1.25)
 return int(VV12Gz + VV12Gz * extraSpace)
def FFWbv3(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFeubS()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVbeZc, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFyUJL(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVbeZc, titleFontSize, alignLeftCenter)
 if winType in (VV3sDt, VVERBh):
  if winType == VVERBh : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVzuks:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVHYPd:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVbeZc, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVytm4:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFH1IbL = b2Left2 + timeW + marginLeft
  FFH1IbW = b2Left3 - marginLeft - FFH1IbL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFH1IbL , b2Top, FFH1IbW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVEAg6:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVGJSr:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVsOWG:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVwoLN:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVbeZc, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVbeZc, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVO5KY:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVbeZc, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVA3ui:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVbeZc, fontH, alignCenter)
 elif winType in (VVY1SD, VVMc7q, VV6ZL1, VV8XWP, VVKY6h):
  if   winType == VVY1SD  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVMc7q : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VV6ZL1 : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VV8XWP : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVY1SD:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVbeZc, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVbeZc, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVbeZc, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVbeZc, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVbeZc, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVbeZc, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVbeZc, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VV2Ev8:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVBAUc:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVtrva : align = alignLeftCenter
  elif winType == VVgJDM : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVHAru:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVbeZc
  if usefixedFont and winType == VVgJDM:
   fLst = FFlxZo()
   if   VVdir1 in fLst and CFG.fontPathTerm.getValue(): fontName = VVdir1
   elif VVe85a in fLst         : fontName = VVe85a
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVsgYf = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVbeZc, VVsgYf, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVbeZc, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVO3mz[i], VVbeZc, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVgJDM:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVO3mz[i], VVbeZc, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVFUnD = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVAgrE)
  VVZ4NM = []
  if VVu2Z1:
   VVZ4NM.append(("-- MY TEST --", "myTest" ))
  VVZ4NM.append(("File Manager"  , "fMan" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("IPTV"    , "iptv" ))
  VVZ4NM.append(("Movies Browser" , "movie" ))
  VVZ4NM.append(("Services/Channels", "chan" ))
  VVZ4NM.append(("PIcons"   , "picon" ))
  VVZ4NM.append(("EPG"    , "epg"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Terminal"   , "term" ))
  VVZ4NM.append(("SoftCam"   , "soft" ))
  VVZ4NM.append(("Plugins"   , "plug" ))
  VVZ4NM.append(("Backup & Restore" , "bakup" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Date/Time"  , "date" ))
  VVZ4NM.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVZ4NM):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVZ4NM[ndx] = tuple(item)
  FF3tZI(self, title=self.Title, VVZ4NM=VVZ4NM)
  FFTvkX(self["keyRed"] , "Exit")
  FFTvkX(self["keyGreen"] , "Settings")
  FFTvkX(self["keyYellow"], "Dev. Info.")
  FFTvkX(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VV3NrW      ,
   "yellow": self.VVAlkI      ,
   "blue" : self.VVPFQi     ,
   "info" : BF(FF1QiT, self, self.VVxzrD) ,
   "text" : self.VVyfj1      ,
   "menu" : self.VV62m7    ,
   "0"  : BF(self.VVFy9M, 0)   ,
   "1"  : BF(self.VVmPyu, "fMan")   ,
   "2"  : BF(self.VVmPyu, "iptv")   ,
   "3"  : BF(self.VVmPyu, "movie")   ,
   "4"  : BF(self.VVmPyu, "chan")   ,
   "5"  : BF(self.VVmPyu, "picon")   ,
   "6"  : BF(self.VVmPyu, "epg")   ,
   "7"  : BF(self.VVmPyu, "term")   ,
   "8"  : BF(self.VVmPyu, "soft")   ,
   "9"  : BF(self.VVmPyu, "plug")   ,
   "last" : BF(self.VVmPyu, "bakup")   ,
   "next" : BF(self.VVmPyu, "date")
  })
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
  global VVLt64, VVFBr8, VVAenP
  VVLt64 = VVFBr8 = False
  VVAenP = True
 def VV4SyA(self):
  self.VVmPyu(self["myMenu"].l.getCurrentSelection()[1])
 def VVmPyu(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVW2jY
   VVW2jY = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVQ27J()
   elif item == "fMan"  : self.session.open(CCNmp1)
   elif item == "iptv"  : self.session.open(CCXyjP)
   elif item == "movie" : FF1QiT(self, BF(CCzqWx.VVcvPi, self))
   elif item == "chan"  : self.session.open(CCtCGd)
   elif item == "picon" : self.VVJE3Y()
   elif item == "epg"  : self.session.open(CCh6kb)
   elif item == "term"  : self.session.open(CCuyLa)
   elif item == "soft"  : self.session.open(CCAwAg)
   elif item == "plug"  : self.session.open(CC5jmY)
   elif item == "bakup" : self.session.open(CCmjM9)
   elif item == "date"  : self.session.open(CCiBWK)
   elif item == "net"  : self.session.open(CCS5CT)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
  FFxlor(self)
  FFBjfS(self)
  VV79dT, VVmaRt, VVFiqn, VVmSC9, VVGPhp, oldMovieDownloadPath = FFWhqi()
  if VV79dT or VVmaRt or VVFiqn or VVmSC9 or VVGPhp or oldMovieDownloadPath:
   VVOb1w = lambda path, subj: "%s:\n%s\n\n" % (subj, FFNr4J(path, VVIZs4)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVOb1w(VV79dT   , "Backup/Restore Path"    )
   txt += VVOb1w(VVmaRt  , "Created Package Files (IPK/DEB)" )
   txt += VVOb1w(VVFiqn  , "Download Packages (from feeds)" )
   txt += VVOb1w(VVmSC9 , "Exported Tables"     )
   txt += VVOb1w(VVGPhp , "Exported PIcons"     )
   txt += VVOb1w(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFXEvX(self, txt, title="Settings Paths")
  self.VV70Zo()
  if (EASY_MODE or VVqdPy or VVu2Z1):
   FFIznG(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF7BjW(self, "Welcome", 300)
  FFdw1m(self.VVHBUd)
 def VVHBUd(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCVmVV.VVxe2j()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFKiof("rm -f /tmp/ajp_*")
  global VVLt64, VVFBr8, VVAenP
  VVLt64 = VVFBr8 = False
  del VVAenP
 def VVFy9M(self, digit):
  self.VVFUnD += str(digit)
  ln = len(self.VVFUnD)
  global VVLt64
  if ln == 4:
   if self.VVFUnD == "0" * ln:
    VVLt64 = True
    FFIznG(self["myTitle"], "#11805040")
   else:
    self.VVFUnD = "x"
 def VVyfj1(self):
  self.VVFUnD += "t"
  if self.VVFUnD == "0" * 4 + "t" * 2:
   global VVFBr8
   VVFBr8 = True
   FFIznG(self["myTitle"], "#dd5588")
 def VVJE3Y(self):
  found = False
  pPath = CCk0vb.VVJcyT()
  if pathExists(pPath):
   for fName, fType in CCk0vb.VV3bRT(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCk0vb)
  else:
   VVZ4NM = []
   VVZ4NM.append(("PIcons Tools" , "CCk0vb" ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(CCk0vb.VVq2PE())
   VVZ4NM.append(VVVvw4)
   VVZ4NM += CCk0vb.VVonKv()
   FFLMiy(self, self.VVrYw2, VVZ4NM=VVZ4NM)
 def VVrYw2(self, item=None):
  if item:
   if   item == "CCk0vb"   : self.session.open(CCk0vb)
   elif item == "VV18Y5"  : CCk0vb.VV18Y5(self)
   elif item == "VVTPz8"  : CCk0vb.VVTPz8(self)
   elif item == "findPiconBrokenSymLinks" : CCk0vb.VV5Dq3(self, True)
   elif item == "FindAllBrokenSymLinks" : CCk0vb.VV5Dq3(self, False)
 def VVxzrD(self):
  changeLogFile = VVrRM9 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFMA9m(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFNr4J("\n%s\n%s\n%s" % (SEP, line, SEP), VVde5r, VVqIxN)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFNr4J(line, VVi1yn, VVqIxN)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFXEvX(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVAgrE, PLUGIN_DESCRIPTION), VVsgYf=28, width=1600, height=1000, VVfKIv="#11000011")
 def VV62m7(self):
  VVZ4NM = []
  VVZ4NM.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Keys Help"     , "hlp" ))
  FFLMiy(self, self.VVVzlh, VVZ4NM=VVZ4NM, width=650, title="Options")
 def VVVzlh(self, item=None):
  if item:
   if   item == "libr" : FF1QiT(self, BF(self.VV6KpW))
   elif item == "hlp" : FFC2xZ(self, "_help_main", "Main Page (Keys Help)")
 def VV3NrW(self) : self.session.open(CCVmVV)
 def VVAlkI(self) : self.session.open(CCo4WP)
 def VVPFQi(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVI2ZY, VVIZs4, VVQzZA, VVljbY
  VVZ4NM = []
  VVZ4NM.append((c1 + "Change Title Colors"   , "title"  ))
  VVZ4NM.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVZ4NM.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVZ4NM.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVZ4NM.append((c2 + "Reset Colors"    , "resetColor" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVZ4NM.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c4 + "Change System Font"    , "sysFont"  ))
  FFLMiy(self, BF(self.VVLsW2, title), VVZ4NM=VVZ4NM, width=600, title=title)
 def VVLsW2(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV8yI5()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVUOmi, tDict, item), CCfckU, defFG=fg, defBG=bg)
   elif item == "resetColor" : FF4s3j(self, self.VVTjIG, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVgxIb(VVzmhg  )
   elif item == "termFont"  : self.VVgxIb(VVdir1)
   elif item == "sysFont"  : self.VVgxIb(VV28ZM  )
 def VV6KpW(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVJIKO, pkgs = self.VVA3dJ()
  VV8lmg = ("Install", BF(self.VVATCZ, title, pkgs)  , [])
  VVUpMt  = ("Update Sys. Packages", self.VVDYSb , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVXdZ9 = (LEFT  , CENTER , LEFT  )
  VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, width=1350, VV8lmg=VV8lmg, VVUpMt=VVUpMt, VVIWfT="#00ffffaa", VVEIfy=1)
 def VVATCZ(self, Title, pkgs, VVSuUg, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VV53HZ, VVSuUg)
   item = colList[0]
   if   item == "requests" : CCHRwQ.VV3TtN(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCzEE9.VVTmbu(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFxjL4(self, FFib1Q(), VVgmlB=cbFnc)
   elif item in pkgs  : FFxjL4(self, FF6Lzl(item, item, item.capitalize()), VVgmlB=cbFnc)
  else:
   FF7BjW(VVSuUg, "Already installed.", 700, isGrn=True)
 def VVDYSb(self, VVSuUg, title, txt, colList):
  CC5jmY.VVyBGu(self)
 def VV53HZ(self, VVSuUg):
  VVJIKO, pkgs = self.VVA3dJ()
  VVSuUg.VVgAJR(VVJIKO[VVSuUg.VVZ2t7()])
 def VVA3dJ(self):
  tDict = {}
  path = VVrRM9 + "_sup_lib"
  if fileExists(path):
   for line in FFMA9m(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVOb1w(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFNr4J("Installed", VVhmJa), txt)
   else : return (lib, FFNr4J("Not installed", VVEWKM), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVJIKO = []
  VVJIKO.append(VVOb1w("requests", CCHRwQ.VV3TtN(self, install=False)))
  VVJIKO.append(VVOb1w("Imaging" , CCzEE9.VVTmbu(self, "", False, install=False)))
  VVJIKO.append(VVOb1w("ar"   , FFKiof("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVJIKO.append(VVOb1w(item, FF4wzI(item)))
  VVJIKO.sort(key=lambda x: x[0].lower())
  return VVJIKO, pkgs
 def VVEWDQ(self):
  return VVbRSD + "ajpanel_colors"
 def VV8yI5(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVEWDQ()
  if fileExists(p):
   txt = FFBRKz(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVUOmi(self, tDict, item, fg, bg):
  if fg:
   self.VVthO5(item, fg)
   self.VVrrrl(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVJByX(tDict)
 def VVJByX(self, tDict):
   p = self.VVEWDQ()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVthO5(self, item, fg):
  if   item == "title" : FFDUax(self["myTitle"], fg)
  elif item == "body"  :
   FFDUax(self["myMenu"], fg)
   FFDUax(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFDUax(self[item], fg)
 def VVrrrl(self, item, bg):
  if   item == "title" : FFIznG(self["myTitle"], bg)
  elif item == "body"  :
   FFIznG(self["myMenu"], bg)
   FFIznG(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFIznG(self["myBar"], bg)
 def VVTjIG(self):
  FFKiof("rm '%s'" % self.VVEWDQ())
  self.close()
 def VV70Zo(self):
  tDict = self.VV8yI5()
  for item in ("title", "body", "cursor", "bar"):
   self.VVJg6Z(tDict, item)
 def VVJg6Z(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVthO5(name, fg)
  if bg: self.VVrrrl(name, bg)
 def VVgxIb(self, which):
  if   which == VVzmhg  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVdir1 : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VV28ZM  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCJdlC.VVpGVK(self, "Change %s Font" % title, defFnt, rest, BF(self.VVX4PP, which))
 def VVX4PP(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVzmhg  : FFE6Br(CFG.fontPathMain, path)
   elif which == VVdir1: FFE6Br(CFG.fontPathTerm, path)
   elif which == VV28ZM  : FFE6Br(CFG.fontPathSys , path)
   err = Main_Menu.VVkel5(which)
   if err          : FF0eUf(self, err, title=title)
   elif which == VVzmhg   : self.close()
   elif which == VVdir1  : FF7BjW(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VV28ZM and path: FF7BjW(self, "System font applied", 1500, isGrn=True)
   elif which == VV28ZM   : FF4s3j(self, BF(Main_Menu.VVm3aA, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVm3aA(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVkel5(name):
  if   name == VVzmhg : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVdir1: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VV28ZM : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFlxZo()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VV28ZM:
   nameLst = []
   for nm in FFlxZo():
    if not nm in (VVzmhg, VVdir1):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFdhDJ(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFlxZo()
  else    : return "Could not add font"
 def VVQ27J(self):
  CCXYrc.VVRGWe(self.session)
class CCS5CT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVbRSD, "ajpanel_network")
  c1, c2 = VVQzZA, VVI2ZY
  VVZ4NM = []
  VVZ4NM.append((c1 + "Network Devices"     , "dev" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Network Scanner (ping)"    , "ping"))
  VVZ4NM.append(("Port Scanner (scan for famous ports)" , "port"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Check Internet Connection"  , "intr"))
  FF3tZI(self, title="Network Tools", VVZ4NM=VVZ4NM)
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FF1QiT(self, self.VVUtyM, title="REading Devices ...")
  elif item == "ping" : FF1QiT(self, self.VVw4i9, title="Scanning ...")
  elif item == "port" : CCoB4g.VVefqN(self, self.VValOG, title="Select host to scan")
  elif item == "intr" : self.session.open(CC2wds)
 def VVUtyM(self, canCencel=False):
  title = "Network Devices"
  VVJIKO = self.VVknmQ()
  if VVJIKO:
   bg = "#0a223333"
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVQLDs = BF(self.VVjvnE, canCencel)
   VVFJkn  = ("Start FTP"   , self.VVocIU    , [])
   VV0RwZ = ("Entry Options"  , self.VVCaJB  , [])
   VVUpMt = ("Scan for Devices" , self.VVG3y1 , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVXdZ9 = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, width=1500, height=900, VVQT0l=widths, VVsgYf=28, VVFJkn=VVFJkn, VVQLDs=VVQLDs, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt
       , VVrEme=bg, VVRBt6=bg, VVfKIv=bg, VVIWfT="#11ffff00", VV6z2K="#11220000", VV7JIr="#00333333", VVpBpY="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVSuUg.VVpxIX(ndx)
  else:
   FF4s3j(self, BF(FF1QiT, self, BF(self.VVd7RK, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVjvnE, canCencel), title=title)
 def VVCaJB(self, VVSuUg, title, txt, colList):
  VVZ4NM = []
  VVZ4NM.append(("Change Username"   , "user"))
  VVZ4NM.append(("Change Password"   , "pass"))
  VVZ4NM.append(("Change Remarks"   , "rem"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Remove Selected Server" , "del"))
  FFLMiy(self, BF(self.VVafkw, VVSuUg), VVZ4NM=VVZ4NM, title="Entry Options")
 def VVafkw(self, VVSuUg, item=None):
  if item:
   if   item == "user" : self.VV9YLY("u", VVSuUg)
   elif item == "pass" : self.VV9YLY("p", VVSuUg)
   elif item == "rem" : self.VV9YLY("r", VVSuUg)
   elif item == "del" : FF4s3j(self, BF(FF1QiT, self, BF(self.VV0Z3o, VVSuUg), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVjvnE(self, canCencel, VVSuUg=None):
  if VVSuUg: VVSuUg.cancel()
  if canCencel : self.close()
 def VVocIU(self, VVSuUg, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFE6Br(CFG.lastNetworkDevice, VVSuUg.VVZ2t7())
  self.session.openWithCallback(BF(self.VVShyG, entry, VVSuUg), CCWpN2, entry)
 def VVShyG(self, entry, VVSuUg, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVJqJ5("d", newPath, ip, u, p, path, rem)
    self.VVrjiO(VVSuUg)
 def VVG3y1(self, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVd7RK, mainTableInst=VVSuUg), title="Scanning Network ...")
 def VVd7RK(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCoB4g.VVH9IL(CCoB4g.VVSqlV)
  if err:
   FF0eUf(self, err, title=title)
   return
  telLst, err = CCoB4g.VVH9IL(CCoB4g.VVQRci)
  if err:
   FF0eUf(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVU0id(p1, p2): return FFaQHk(p1[0], p2[0])
   lst.sort(key=FFl2yM(VVU0id))
   bg = "#0a202020"
   VVQLDs = BF(self.VVjvnE, canCencel)
   VVFJkn  = ("Add to Devices" , BF(self.VVgJLy, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVXdZ9 = (LEFT   , CENTER   , CENTER  )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=lst, VVXdZ9=VVXdZ9, VVQT0l=widths, width=1200, VVsgYf=30, VVFJkn=VVFJkn, VVQLDs=VVQLDs, VVEIfy=2
     , VVrEme=bg, VVRBt6=bg, VVfKIv=bg, VV6z2K="#0a225555", VVpBpY="#11403040")
  else:
   FF0eUf(self, "No devices found !", title=title)
 def VVw4i9(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCoB4g.VVH9IL(-1)
  if err:
   FF0eUf(self, err, title=title)
  elif lst:
   def VVU0id(p1, p2): return FFaQHk(p1[0], p2[0])
   lst.sort(key=FFl2yM(VVU0id))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVXdZ9 = (LEFT   , LEFT   )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=lst, VVXdZ9=VVXdZ9, VVQT0l=widths, width=1000, height=700, VVsgYf=30
     , VVrEme=bg, VVRBt6=bg, VVfKIv=bg, VV6z2K="#0a225555", VVpBpY="#11403040")
  else:
   FF0eUf(self, "Network scanning failed !", title=title)
 def VValOG(self, ip=None):
  if ip:
   FF1QiT(self, BF(self.VVyRY1, ip), title="Scanning %s" % ip)
 def VVyRY1(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCoB4g.VVdzOM(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCoB4g.VVuQB5(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFXEvX(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVknmQ(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFBRKz(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVU0id(p1, p2): return FFaQHk(p1[0], p2[0])
  tLst.sort(key=FFl2yM(VVU0id))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVknmQ(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFBRKz(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVU0id(p1, p2): return FFaQHk(p1[0], p2[0])
  tLst.sort(key=FFl2yM(VVU0id))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVgJLy(self, mainTableInst, canCencel, VVSuUg, title, txt, colList):
  ip, mac, typ = VVSuUg.VVTuTs(VVSuUg.VVZ2t7())
  if "Own" in ip:
   FF7BjW(VVSuUg, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVknmQ():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFg7n1(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVgM6K(ip, u, p, path, rem))
   if mainTableInst: self.VVrjiO(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVUtyM(canCencel)
   VVSuUg.cancel()
 def VVgM6K(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VV0Z3o(self, VVSuUg):
  num, ip, u, p, path, rem = VVSuUg.VVTuTs(VVSuUg.VVZ2t7())
  lst = self.VVknmQ()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVgM6K(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVrjiO(VVSuUg)
  else:
   VVSuUg.cancel()
 def VV9YLY(self, col, VVSuUg):
  num, ip, u, p, path, rem = VVSuUg.VVTuTs(VVSuUg.VVZ2t7())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFFMZg(self, BF(self.VV4t8b, col, orig, VVSuUg, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VV4t8b(self, col, orig, VVSuUg, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FF7BjW(VVSuUg, "No change", 1500)
   elif not newTxt and col == "u":
    FF7BjW(VVSuUg, "No user !", 2000)
   else:
    self.VVJqJ5(col, newTxt, ip, u, p, path, rem)
    self.VVrjiO(VVSuUg)
 def VVJqJ5(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVknmQ()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVgM6K(ip1, u1, p1, path1, rem1))
 def VVrjiO(self, VVSuUg, newEntry=None):
  VVJIKO = self.VVknmQ()
  if VVJIKO : VVSuUg.VVuO1Y(VVJIKO, tableRefreshCB=BF(self.VVdYd0, newEntry))
  else  : VVSuUg.cancel()
 def VVdYd0(self, newEntry, VVSuUg, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVSuUg.VVOxLE()):
    if row[1:] == newEntry:
     VVSuUg.VVpxIX(ndx)
 def VVjvnE(self, canCencel, VVSuUg=None):
  if VVSuUg: VVSuUg.cancel()
  if canCencel : self.close()
class CCoB4g():
 VVSqlV = 21
 VVQRci = 23
 def __init__(self):
  self.VVKAmr()
 def VVKAmr(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVTkCc(self, ip, User, Pass, timeout=5):
  myIp = CCoB4g.VVduGU()
  if ip != myIp:
   if CCoB4g.VVuQB5(ip, CCoB4g.VVSqlV):
    self.VVKAmr()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VV9xUv(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVTsOJ(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVq3af(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVTsOJ()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVyu9g(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVoMoo(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVkCD5(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVh8GA(self):
  try: return self.ftp.pwd()
  except: return ""
 def VV1PLp(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVh8GA()
   if self.VVkCD5(path) : typ = "d"
   else      : typ = "b"
   self.VVkCD5(curDir)
   return typ
 def VV0MxB(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVkCD5(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVJ2Ia(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVYHoO(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVzy06(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVvRHN(self, remFile, locFile="", maxSz=10000000):
  sz = self.VV0MxB(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFfhv3(locFile)
   return "", sz, str(e)
 def VVG0hj(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVKAmr()
 @staticmethod
 def VVh5hv():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVduGU():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVlp02():
  myIp = CCoB4g.VVduGU()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVLrfr():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FF0hBQ("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVQYdY(port=-1):
  lst = []
  def VV7TKp(ip):
   if port > -1: ok = CCoB4g.VVuQB5(ip, port)
   else  : ok = CCoB4g.VVdzOM(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCoB4g.VVlp02()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VV7TKp, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVH9IL(port):
  myIp = CCoB4g.VVduGU()
  myGw = CCoB4g.VVLrfr()
  tDict = { myIp: CCoB4g.VVh5hv() }
  devLst, err = CCoB4g.VVQYdY(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFcLfl("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVQzZA
    elif key == myGw: txt = " %s Gateway" % VVQzZA
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVdzOM(ip):
  return FFKiof("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVuQB5(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVKCNt(ip="1.1.1.1", timeout=1):
  if CCoB4g.VVuQB5(ip, 53, timeout):
   return True
  if CCoB4g.VVdzOM(ip):
   return True
  return FFKiof("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVefqN(SELF, okFnc, title):
  baseIp = CCoB4g.VVlp02()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFLMiy(SELF, okFnc, VVZ4NM=lst, width=600, title=title, VVrEme="#222222", VVRBt6="#222222")
class CCWpN2(Screen, CCoB4g):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVsgYf  = self.skinParam["bodyFontSize"]
  self.VV12Gz  = self.skinParam["bodyLineH"]
  self.VVeaGH  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCid1U.VVMo7M("fil")
  self.png_dir  = CCid1U.VVMo7M("dir")
  self.png_dirup  = CCid1U.VVMo7M("dirup")
  self.png_slwfil  = CCid1U.VVMo7M("slwfil")
  self.png_slbfil  = CCid1U.VVMo7M("slbfil")
  self.png_slwdir  = CCid1U.VVMo7M("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCoB4g.__init__(self)
  VVZ4NM = [("Item-%d" % x,) for x in range(50)]
  FF3tZI(self, title=self.Title, VVZ4NM=VVZ4NM)
  FFTvkX(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVZ4NM, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVbeZc, self.VVsgYf))
  self["myMenu"].l.setItemHeight(self.VV12Gz)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVGj7j, True) ,
   "ok" : self.VV4SyA    ,
   "cancel": self.VVGj7j    ,
   "menu" : self.VVGRP9   ,
   "info" : self.VVuT09  ,
   "pageUp": self.VVQhcT    ,
   "chanUp": self.VVQhcT
  })
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV3RBW)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
  FFxlor(self)
  FFBjfS(self)
  FFIznG(self["keyBlue"], "#11333333")
  FF1QiT(self, self.VV3csK, title="Connecting ...")
 def VV3csK(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVTkCc(ip, u, p)
  if err:
   FF0eUf(self, err, title=self.Title)
   FFTvkX(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFTvkX(self["keyBlue"], self.ftpIp)
   if not self.VVkCD5(path):
    path = "/"
   self.VVrq0Q(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVTsOJ():
   self.VVG0hj()
 def VV4SyA(self):
  if self.VVinOu():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVrq0Q(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVQhcT()
    else         : self.VVUruQ(os.path.join(self.curDir, name))
 def VVGj7j(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVQhcT()
 def VVinOu(self):
  if self.VVTsOJ():
   return True
  else:
   FF0eUf(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVUruQ(self, path):
  cat = self.VVYoWT(path)
  if cat in ("pic"):
   FF1QiT(self, BF(self.VVFIXp, path))
  elif cat in ("mov", "mus"):
   if CCXyjP.VVGxMM("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FF1QiT(self, BF(CCNmp1.VVcIM8, self, url, rType=rType), title="Playing Media ...")
 def VVFIXp(self, path):
  locFile, size, err = self.VVvRHN(path)
  if err: FF0eUf(self, err, title="View Picture File")
  else  : CCWJhm.VVpAVI(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFfhv3))
 def VV3RBW(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCid1U.VVl1SS else sel[0][0])
  else  : title=  VVEWKM + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVQhcT(self):
  if self.VVinOu():
   lastPart = FFRa3J(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVrq0Q(parentDir, lastPart, "d")
 def VVrq0Q(self, Dir, moveTo="", moveToType=""):
  FF1QiT(self, BF(self.VViF3l, Dir, moveTo, moveToType))
 def VViF3l(self, Dir, moveTo, moveToType):
  files, err = self.VVoMoo(Dir, isLong=True)
  self.curDir = self.VVh8GA() or "/"
  self.VVugUT(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVugUT(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVi39W(CCid1U.VVl1SS, CCid1U.VVl1SS, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VV1PLp(target)
    color = VVEWKM if targetState == "b" else VVhmJa
    origName = name + VVde5r + linkSep + color + " "+ target
   self.list.append(self.VVi39W(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVi39W(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVYoWT(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVrRM9, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCid1U.VVl1SS: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV12Gz + 10, 0, self.VVeaGH, self.VV12Gz, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VV5WKm: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV12Gz-4, self.VV12Gz-4, png, None, None, VV5WKm))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV12Gz-4, self.VV12Gz-4, png, None, None))
  return tableRow
 def VVYoWT(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCid1U.VVyaUp().items():
    if ext in lst:
     return cat
  return ""
 def VVGRP9(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCid1U.VVl1SS
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVjaYc(titl, ref, chk, color=""):
   if chk: return VVZ4NM.append((color + titl, ref))
   else  : return VVZ4NM.append((titl, ))
  VVZ4NM = []
  VVjaYc("Properties", "VVuT09", not isTop)
  c = VVQzZA
  VVZ4NM.append(VVVvw4)
  VVjaYc("Download Selected File ..."    , "FFacHFFromServer", isFile, c)
  VVjaYc("Upload a Local File to Remote Server ...", "VV46oT" , True  , c)
  VVZ4NM.append(VVVvw4)
  VVjaYc("Create new directory", "VV6gPz", True)
  VVjaYc("Rename", "VVkXpj", not isTop)
  VVjaYc("DELETE", "VVmeLv", not isTop, VVqDXM)
  VVZ4NM.append(VVVvw4)
  VVjaYc("FTP Server Information", "VVrW3b", True)
  VVZ4NM.append(VVVvw4)
  VVjaYc("Refresh File List", "refresh", True)
  FFLMiy(self, self.VVtaWz, VVZ4NM=VVZ4NM, title="Options")
 def VVtaWz(self, item=None):
  if item:
   if   item == "VVuT09"     : self.VVuT09()
   elif item == "FFacHFFromServer"   : self.FFacHFFromServer()
   elif item == "VV46oT"   : self.VV46oT()
   elif item == "VV6gPz"   : self.VV6gPz()
   elif item == "VVkXpj"   : self.VVkXpj()
   elif item == "VVmeLv"   : self.VVmeLv()
   elif item == "VVrW3b"    : self.VVrW3b()
   elif item == "refresh"and self.VVinOu() : self.VVrq0Q(self.curDir)
 def VVuT09(self):
  if self.VVinOu():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFNr4J("Path", VVQzZA), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VV0MxB(path)
    if sz > -1: txt += "Size\t: %s" % CCNmp1.VV3y2b(sz)
   else:
    txt = "Nothing selected"
   FFXEvX(self, txt, title="Properties")
 def VVrW3b(self):
  if self.VVinOu():
   Sys  = self.VV9xUv() or " -"
   txt = "%s\n  %s\n\n" % (FFNr4J("System:", VVQzZA), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVyu9g() or " -"
   txt += "%s\n" % (FFNr4J("Status:", VVQzZA))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFXEvX(self, txt, title="FTP Server Information")
 def VV6gPz(self, name=""):
  if self.VVinOu():
   title = "Add New Directory"
   FFFMZg(self, BF(self.VVdZeN, title), defaultText=name, title=title, message="Enter Directory name")
 def VVdZeN(self, title, name):
  if name and name.strip():
   if self.VVJ2Ia(name) : self.VVrq0Q(self.curDir, name, "d")
   else     : FF0eUf(self, "Failed to create : %s" % name, title)
 def VVkXpj(self):
  if self.VVinOu():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFFMZg(self, BF(self.VVsWIx, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVsWIx(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVzy06(name, newName.strip()) : self.VVrq0Q(self.curDir, newName, flag)
   else          : FF0eUf(self, "Failed to rename to : %s" % newName, title)
 def VVmeLv(self):
  if self.VVinOu():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FF4s3j(self, BF(FF1QiT, self, BF(self.VVdPsk, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVdPsk(self, name, flag):
  if self.VVYHoO(name, flag) : self.VVrq0Q(self.curDir)
  else         : FF0eUf(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFacHFFromServer(self):
  if self.VVinOu():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VV0MxB(remFile)
    if size == -1:
     FF0eUf(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVbRSD
     self.session.openWithCallback(BF(self.VVCxVZ, title, remFile, name, size), BF(CCNmp1, mode=CCNmp1.VVLQAF, VVm4ou="Download here", VVxAst=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVCxVZ(self, title, remFile, name, size, locPath):
  if locPath:
   FFE6Br(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVSv1u, remFile, size, locFile)
       , VVtCUJ = BF(self.VV1lfC, remFile, size, locFile))
 def VVSv1u(self, remFile, size, locFile, VVx2mk):
  VVx2mk.VVSJhE(size)
  VVx2mk.VVgnkU = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVSFtt(data):
     if not VVx2mk or VVx2mk.isCancelled:
      return
     locFileObj.write(data)
     VVx2mk.VVr1vN(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVSFtt)
   except Exception as e:
    VVx2mk.VVgnkU = str(e)
 def VV1lfC(self, remFile, size, locFile, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVgnkU:
   FF0eUf(self, "%s\n\nftp:/%s" % (VVgnkU, remFile), title="Download Error")
   delF = True
  elif not VVGvWA:
   FF0eUf(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFPebg(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFH1Ib(self, txt, title=title)
   else:
    FF0eUf(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFfhv3(locFile)
 def VV46oT(self):
  if self.VVinOu():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVbRSD
   self.session.openWithCallback(self.VVKeHS, BF(CCNmp1, VVm4ou="Upload selected file", VVxAst=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVKeHS(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFE6Br(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFPebg(locFile)
   if size == -1:
    FF0eUf(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVSisg, locFile, size, remFile)
        , VVtCUJ = BF(self.VVAfiR, locFile, size, remFile))
 def VVSisg(self, locFile, size, remFile, VVx2mk):
  VVx2mk.VVSJhE(size)
  VVx2mk.VVgnkU = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVUQlr(data):
     if not VVx2mk or VVx2mk.isCancelled:
      VVx2mk.VVgnkU = "Upload cancelled"
      locFileObj.close()
      return
     VVx2mk.VVr1vN(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVUQlr)
   except Exception as e:
    VVx2mk.VVgnkU = VVx2mk.VVgnkU or str(e)
 def VVAfiR(self, locFile, size, remFile, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVGvWA:
   if size == FFPebg(locFile) : FFH1Ib(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVgnkU : err = "%s\n\n%s" % (VVgnkU, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FF0eUf(self, err, title=title)
   self.VVq3af()
   self.VVYHoO(remFile, "")
  self.VVrq0Q(self.curDir)
class CCzEE9():
 VV7NcD  = "all"
 VV3OIz = "vid"
 VVeZKN  = "osd"
 @staticmethod
 def VVIVlm(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FF4wzI("grab"):
    winShown = session.current_dialog.shown
    if k == CCzEE9.VV3OIz and winShown: session.current_dialog.hide()
    FFdw1m(BF(CCzEE9.VVNbJI, title, session, k, winShown))
   else:
    FFsrNe(session, "No Grab command !", title=title)
 @staticmethod
 def VVNbJI(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCzEE9.VVeZKN:
   if not winShown:
    FFsrNe(session, "No Window to capture !", title=title)
    return
   if not CCzEE9.VVTmbu(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCzEE9.VVTBnb(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFsrNe(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFSiyE(CFG.exportedPIconsPath.getValue()), fTitle, FFXJI8(), ext)
  ok = FFuxno("grab -q -s %s > '%s'" % (typ, path))
  if k == CCzEE9.VV3OIz and winShown:
   session.current_dialog.show()
  elif k == CCzEE9.VVeZKN:
   ok = CCzEE9.VVdXK6(path, x, y, w, h)
   if not ok:
    FFfhv3(path)
    FFsrNe(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCWJhm, title=path, VV52TG=path))
  else      : FFsrNe(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVTmbu(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FF4s3j(SELF, BF(CCzEE9.VVQ4jV, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVQ4jV(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFKn3Y, VVgmlB=cbFnc)
  else    : fnc = BF(FFxjL4 , VVgmlB=cbFnc)
  fnc(SELF, FF2pmn(VVLJqS, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVTBnb(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVdXK6(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFeubS()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFvWYU(x , 0, scrW, 0, w)
     y  = FFvWYU(y , 0, scrH, 0, h)
     x1 = FFvWYU(x1, 0, scrW, 0, w)
     y1 = FFvWYU(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVf8dM(path):
  size = FFPebg(path)
  sizeTxt = CCNmp1.VV3y2b(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCJdlC(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFNr4J(" (Requires GUI Restart)", VVljbY) if withRestart else ""
  VVZ4NM = []
  for path in self.fontsList:
   VVZ4NM.append((os.path.splitext(os.path.basename(path))[0], path))
  VVZ4NM.sort(key=lambda x: x[0].lower())
  VVZ4NM.insert(0, VVVvw4)
  VVZ4NM.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVZ4NM):
    if len(item) == 2 and item[1] == self.defFnt:
     VVZ4NM[ndx] = (VVhmJa + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVZ4NM[curIndex] = (VVhmJa + VVZ4NM[curIndex][0], VVZ4NM[curIndex][1])
  FF3tZI(self, VVZ4NM=VVZ4NM, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
  self["myMenu"].onSelectionChanged.append(self.VV9KZd)
  self["myBar"].setText(self.VVdDXn())
  self["myBar"].instance.setHAlign(1)
  self.VV9KZd()
 def VV4SyA(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV9KZd(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFdhDJ(path, fnt, isRepl=1)
  else:
   fnt = VVI9QA
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVdDXn(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVpGVK(SELF, title, defFnt, rest, VVtCUJ):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFFDtI(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVtCUJ, CCJdlC, title, fontsList, defFnt, rest)
  else  : FF0eUf(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CChb92(Screen):
 def __init__(self, session, path, VVZ4NM, title):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FF3tZI(self, VVZ4NM=VVZ4NM, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4SyA   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VV1zUm,
   "chanUp" : self.VV1zUm,
   "pageDown" : self.VV3jTM ,
   "chanDown" : self.VV3jTM ,
  }, -1)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
  FFIznG(self["myLabelFrm"], "#11110000")
  FFIznG(self["myLabelTit"], "#11663322")
  FFIznG(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VV2mDr)
  self.VV2mDr()
 def VV2mDr(self):
  if fileExists(self.path): txt = FFBRKz(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VV4SyA(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV1zUm(self) : self["myMenu"].moveToIndex(0)
 def VV3jTM(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC9SOR():
 @staticmethod
 def VVSrYP():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV5YuK(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFW2Tv(SELF, None, VVDpqo=lst, VVsgYf=30, VVEIfy=1)
 @staticmethod
 def VVarly(path, SELF=None):
  for enc in CC9SOR.VVSrYP():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF0eUf(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVuRGF(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVJOY4(SELF, path, cbFnc, curEnc=VVQZ4P, title="Select Encoding"):
  lst = CC9SOR.VV7OQi(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CChb92, path, lst, title)
 @staticmethod
 def VVvkzS(SELF, cbFnc, curEnc=VVQZ4P, title="Select Encoding"):
  lst = CC9SOR.VV7OQi(SELF, "", "")
  if lst:
   FFLMiy(SELF, cbFnc, title=title, VVZ4NM=lst, width=1000, height=1000, VVrEme="#22220000", VVRBt6="#22220000", VV9pbf=True)
 @staticmethod
 def VV7OQi(SELF, path, curEnc):
  lst = CC9SOR.VVSSlz(path)
  if lst:
   VVZ4NM = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVhmJa
    elif enc == VVQZ4P: c = VVde5r
    else      : c = ""
    VVZ4NM.append((c + txt, enc))
   return VVZ4NM
  else:
   FFVyvQ(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVSSlz(path=""):
  encLst = []
  cPath = VVrRM9 + "_sup_codecs"
  if fileExists(cPath):
   lines = FFMA9m(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CC9SOR.VVSrYP())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCo4WP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZ4NM = []
  VVZ4NM.append(("Settings File"   , "SettingsFile"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Box Info"     , "VVQd2Z"   ))
  VVZ4NM.append(("Tuners Info"    , "VVnwEF"  ))
  VVZ4NM.append(("Python Version"   , "VVzWrE"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Screen Size"    , "ScreenSize"   ))
  VVZ4NM.append(("Language/Locale"   , "Locale"    ))
  VVZ4NM.append(("Processor"    , "Processor"   ))
  VVZ4NM.append(("Operating System"   , "OperatingSystem"  ))
  VVZ4NM.append(("Drivers"     , "drivers"    ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("System Users"    , "SystemUsers"   ))
  VVZ4NM.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVZ4NM.append(("Uptime"     , "Uptime"    ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Host Name"    , "HostName"   ))
  VVZ4NM.append(("MAC Address"    , "MACAddress"   ))
  VVZ4NM.append(("Network Configuration" , "NetworkConfiguration"))
  VVZ4NM.append(("Network Status"   , "NetworkStatus"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Disk Usage"    , "VVXwly"   ))
  VVZ4NM.append(("Mount Points"    , "MountPoints"   ))
  VVZ4NM.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVZ4NM.append(("USB Devices"    , "USB_Devices"   ))
  VVZ4NM.append(("List Block-Devices"  , "listBlockDevices" ))
  VVZ4NM.append(("Directory Size"   , "DirectorySize"  ))
  VVZ4NM.append(("Memory"     , "Memory"    ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVZ4NM.append(("Running Processes"  , "RunningProcesses" ))
  VVZ4NM.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FF3tZI(self, VVZ4NM=VVZ4NM, title="Device Information")
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCKfSe)
   elif item == "VVQd2Z"   : self.VVQd2Z()
   elif item == "VVnwEF"  : self.VVnwEF()
   elif item == "VVzWrE"  : self.VVzWrE()
   elif item == "ScreenSize"   : FFXEvX(self, "Width\t: %s\nHeight\t: %s" % (FFeubS()[0], FFeubS()[1]))
   elif item == "Locale"    : CC9SOR.VV5YuK(self)
   elif item == "Processor"   : self.VV6CLE()
   elif item == "OperatingSystem"  : FFftfY(self, "uname -a")
   elif item == "drivers"    : self.VVJ5Qa()
   elif item == "SystemUsers"   : FFftfY(self, "id")
   elif item == "LoggedInUsers"  : FFftfY(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFftfY(self, "uptime")
   elif item == "HostName"    : FFftfY(self, "hostname")
   elif item == "MACAddress"   : self.VVwPwb()
   elif item == "NetworkConfiguration" : FFftfY(self, "ifconfig %s %s" % (FFVW8g("HWaddr", VVB56o), FFVW8g("addr:", VVde5r)))
   elif item == "NetworkStatus"  : FFftfY(self, "netstat -tulpn", VVsgYf=24, consFont=True)
   elif item == "VVXwly"   : self.VVXwly()
   elif item == "MountPoints"   : FFftfY(self, "mount %s" % (FFVW8g(" on ", VVde5r)))
   elif item == "FileSystemTable"  : FFftfY(self, "cat /etc/fstab", VVsgYf=24, consFont=True)
   elif item == "USB_Devices"   : FFftfY(self, "lsusb")
   elif item == "listBlockDevices"  : FFftfY(self, "blkid")
   elif item == "DirectorySize"  : FFftfY(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVwSJD="Reading size ...")
   elif item == "Memory"    : FFftfY(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VV2K6T()
   elif item == "RunningProcesses"  : FFftfY(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFftfY(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVObch()
   else        : self.close()
 def VVwPwb(self):
  res = FFcLfl("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFXEvX(self, txt)
  else:
   FFftfY(self, "ip link")
 def VVsiqR(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFtLFA(cmd)
  return lines
 def VVwHeB(self, lines, headerRepl, widths, VVXdZ9):
  VVJIKO = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVJIKO.append(parts)
  if VVJIKO and len(header) == len(widths):
   VVJIKO.sort(key=lambda x: x[0].lower())
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VVEIfy=1)
   return True
  else:
   return False
 def VVXwly(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFcLfl(cmd)
  if not "invalid option" in txt:
   lines  = self.VVsiqR(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVXdZ9 = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVwHeB(lines, headerRepl, widths, VVXdZ9)
  else:
   cmd = "df -h"
   lines  = self.VVsiqR(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVXdZ9 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVwHeB(lines, headerRepl, widths, VVXdZ9)
  if not allOK:
   lines = FFtLFA(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFliS8(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVhmJa:
     note = "\n%s" % FFNr4J("Green = Mounted Partitions", VVhmJa)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVde5r
     elif line.endswith(mountList) : color = VVhmJa
     else       : color = VVi1yn
     txt += FFNr4J(line, color) + "\n"
    FFXEvX(self, txt + note)
   else:
    FF0eUf(self, "Not data from system !")
 def VV2K6T(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVsiqR(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVXdZ9 = (LEFT , CENTER, LEFT )
  allOK = self.VVwHeB(lines, headerRepl, widths, VVXdZ9)
  if not allOK:
   FFftfY(self, cmd)
 def VVJ5Qa(self):
  cmd = FF8xxa(VVWjcv, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFftfY(self, cmd)
  else : FFPXac(self)
 def VV6CLE(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFftfY(self, cmd)
 def VVObch(self):
  cmd = FF8xxa(VVphAw, "| grep secondstage")
  if cmd : FFftfY(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFPXac(self)
 def VVQd2Z(self):
  c = VVhmJa
  VVDpqo = []
  VVDpqo.append((FFNr4J("Box Type"  , c), FFNr4J(self.VVWBgv("boxtype").upper(), c)))
  VVDpqo.append((FFNr4J("Board Version", c), FFNr4J(self.VVWBgv("board_revision") , c)))
  VVDpqo.append((FFNr4J("Chipset"  , c), FFNr4J(self.VVWBgv("chipset")  , c)))
  VVDpqo.append((FFNr4J("S/N"   , c), FFNr4J(self.VVWBgv("sn")    , c)))
  VVDpqo.append((FFNr4J("Version"  , c), FFNr4J(self.VVWBgv("version")  , c)))
  VVuFBu   = []
  VVGLRw = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVGLRw = SystemInfo[key]
     else:
      VVuFBu.append((FFNr4J(str(key), VVi9VJ), FFNr4J(str(SystemInfo[key]), VVi9VJ)))
  except:
   pass
  if VVGLRw:
   VVMkzb = self.VVxKWX(VVGLRw)
   if VVMkzb:
    VVMkzb.sort(key=lambda x: x[0].lower())
    VVDpqo += VVMkzb
  if VVuFBu:
   VVuFBu.sort(key=lambda x: x[0].lower())
   VVDpqo += VVuFBu
  if VVDpqo:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFW2Tv(self, None, header=header, VVDpqo=VVDpqo, VVQT0l=widths, VVsgYf=28, VVEIfy=1)
  else:
   FFXEvX(self, "Could not read info!")
 def VVWBgv(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFMA9m(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVxKWX(self, mbDict):
  try:
   mbList = list(mbDict)
   VVDpqo = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVDpqo.append((FFNr4J(subject, VVde5r), FFNr4J(value, VVde5r)))
  except:
   pass
  return VVDpqo
 def VVnwEF(self):
  txt = self.VVMzvE("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVMzvE("/proc/bus/nim_sockets")
  if not txt: txt = self.VV2dgE()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFXEvX(self, txt)
 def VV2dgE(self):
  txt = ""
  VVOb1w = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVOb1w("Slot Name" , slot.getSlotName())
     txt += FFNr4J(slotName, VVde5r)
     txt += VVOb1w("Description"  , slot.getFullDescription())
     txt += VVOb1w("Frontend ID"  , slot.frontend_id)
     txt += VVOb1w("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVMzvE(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFMA9m(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFNr4J(line, VVde5r)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVzWrE(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFXEvX(self, txt)
 @staticmethod
 def VVz2h4():
  def VVOb1w(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVOb1w(v,0), "/etc/issue.net": VVOb1w(v,1), "/etc/image-version": VVOb1w(v,2)}
  for p1, d in v.items():
   img = CCo4WP.VV3FjT(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVOb1w(v,0), p + "Plugins/": VVOb1w(v,1), VVydp3: VVOb1w(v,2), VV0xPn: VVOb1w(v,3)}
  for p1, d in v.items():
   img = CCo4WP.VV37jX(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV3FjT(path, d):
  if fileExists(path):
   txt = FFBRKz(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VV37jX(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCKfSe(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZ4NM = []
  VVZ4NM.append(("Settings (All)"   , "Settings_All"   ))
  VVZ4NM.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVZ4NM.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVZ4NM.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVZ4NM.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVZ4NM.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVZ4NM.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVFBr8:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVZ4NM.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVPxkP
   grep = " | grep "
   if   item == "Settings_All"   : FFftfY(self, cmd)
   elif item == "Settings_HotKeys"  : FFftfY(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFftfY(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFftfY(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFftfY(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFftfY(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFftfY(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFftfY(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFftfY(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCAwAg(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV3GR8, VVQXf7, VVnSWi, camCommand = CCAwAg.VVCFQG()
  self.VVQXf7 = VVQXf7
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVQXf7:
   c = VVI2ZY if VVnSWi else VVh9Nn
   if   "oscam" in VVQXf7 : camName, oC = "OSCam", c
   elif "ncam"  in VVQXf7 : camName, nC = "NCam" , c
  VVZ4NM = []
  VVZ4NM.append(("OSCam Files" , "OSCamFiles" ))
  VVZ4NM.append(("NCam Files" , "NCamFiles" ))
  VVZ4NM.append(("CCcam Files" , "CCcamFiles" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((VVQzZA + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVhVNw" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVZ4NM.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVZ4NM.append(VVVvw4)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVZ4NM.append(FF1giv(txt, "camInfo", VVQXf7, c))
  VVZ4NM.append(VVVvw4)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVQXf7:
   for item in camLst: VVZ4NM.append(item)
  else:
   for item in camLst: VVZ4NM.append((item[0], ))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCwmfP, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCwmfP, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCwmfP, "cccam"))
   elif item == "VVhVNw" : self.VVhVNw()
   elif item == "OSCamReaders"  : self.VVSzk0("os")
   elif item == "NSCamReaders"  : self.VVSzk0("n")
   elif item == "camInfo"   : FFw8g8(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCAwAg.VV3Wu5(self.session, CC9rk7.VVVYCp)
   elif item == "camLiveReaders" : CCAwAg.VV3Wu5(self.session, CC9rk7.VVatae)
   elif item == "camLiveLog"  : CCAwAg.VV3Wu5(self.session, CC9rk7.VVEymg)
   else       : self.close()
 def VVhVNw(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVbRSD, FFXJI8())
  if fileExists(path):
   lines = FFMA9m("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVOb1w = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVOb1w("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVOb1w("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVOb1w("protocol"   , "cccam"))
      f.write(VVOb1w("device"    , "%s,%s" % (host, port)))
      f.write(VVOb1w("user"    , User))
      f.write(VVOb1w("password"   , Pass))
      f.write(VVOb1w("fallback"   , "1"))
      f.write(VVOb1w("group"    , "64"))
      f.write(VVOb1w("cccversion"   , "2.3.2"))
      f.write(VVOb1w("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFH1Ib(self, "Output = %d Reader%s in:\n\n%s" % (tot, FF1OOs(tot), outFile))
   else:
    FF7BjW(self, "No valid CCcam lines", 1500)
  else:
   FF7BjW(self, "%s not found" % path, 1500)
 def VVSzk0(self, camPrefix):
  VVJIKO = self.VVl6Gx(camPrefix)
  if VVJIKO:
   VVJIKO.sort(key=lambda x: int(x[0]))
   if self.VVQXf7 and self.VVQXf7.startswith(camPrefix):
    VV8lmg = ("Toggle State", self.VVuzFc, [camPrefix], "Changing State ...")
   else:
    VV8lmg = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVXdZ9  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VV8lmg=VV8lmg, VVROQm=True)
 def VVl6Gx(self, camPrefix):
  readersFile = self.VV3GR8 + camPrefix + "cam.server"
  VVJIKO = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFMA9m(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVJIKO.append((str(len(VVJIKO) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVJIKO:
    FF0eUf(self, "No readers found !")
  else:
   FF7Hmv(self, readersFile)
  return VVJIKO
 def VVuzFc(self, VVSuUg, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV3GR8, camPrefix)
  readerState  = VVSuUg.VVbc1J(1)
  readerLabel  = VVSuUg.VVbc1J(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCAwAg.VVCBNl(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVSuUg.VVTVqz()
    FF0eUf(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVJIKO = self.VVl6Gx(camPrefix)
   if VVJIKO:
    VVSuUg.VVuO1Y(VVJIKO)
  else:
   VVSuUg.VVTVqz()
 @staticmethod
 def VVCBNl(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFMA9m(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF0eUf(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF0eUf(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF7Hmv(SELF, confFile)
   return None
  if not iRequest:
   FF0eUf(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCAwAg.VVswc9(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FF0eUf(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVswc9(SELF):
  if iElem:
   return True
  else:
   FF0eUf(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VV3Wu5(session, VVZnxN):
  VV3GR8, VVQXf7, VVnSWi, camCommand = CCAwAg.VVCFQG()
  if VVQXf7:
   runLog = False
   if   VVZnxN == CC9rk7.VVVYCp : runLog = True
   elif VVZnxN == CC9rk7.VVatae : runLog = True
   elif not VVnSWi          : FFsrNe(session, message="SoftCam not started yet!")
   elif fileExists(VVnSWi)        : runLog = True
   else             : FFsrNe(session, message="File not found !\n\n%s" % VVnSWi)
   if runLog:
    session.open(BF(CC9rk7, VV3GR8=VV3GR8, VVQXf7=VVQXf7, VVnSWi=VVnSWi, VVZnxN=VVZnxN))
  else:
   FFsrNe(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVCFQG():
  VV3GR8 = "/etc/tuxbox/config/"
  VVQXf7 = None
  VVnSWi  = None
  camCommand = FF0hBQ("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVQXf7 = "oscam"
   elif camCmd.startswith("ncam") : VVQXf7 = "ncam"
  if VVQXf7:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFBRKz(path), IGNORECASE)
     if span:
      VV3GR8 = FFSiyE(span.group(1))
      break
   else:
    path = FF0hBQ(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFSiyE(path)
    if pathExists(path):
     VV3GR8 = path
   tFile = FFSiyE(VV3GR8) + VVQXf7 + ".conf"
   tFile = FF0hBQ("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVnSWi = tFile
  return VV3GR8, VVQXf7, VVnSWi, camCommand
class CCwmfP(Screen):
 def __init__(self, VVm0E7, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV3GR8, VVQXf7, VVnSWi, camCommand = CCAwAg.VVCFQG()
  if   VVm0E7 == "ncam" : self.prefix = "n"
  elif VVm0E7 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVZ4NM = []
  if self.prefix == "":
   VVZ4NM.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVZ4NM.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVZ4NM.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVZ4NM.append(("constant.cw"         , "x_constant_cw" ))
   VVZ4NM.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVZ4NM.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVZ4NM.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVZ4NM.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVZ4NM.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVZ4NM.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVZ4NM.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVZ4NM.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVZ4NM.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVZ4NM.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVZ4NM.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFRva2(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFRva2(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFRva2(self, self.VV3GR8 + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFRva2(self, self.VV3GR8 + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVO69C("cam.ccache")
   elif item == "x_cam_conf"  : self.VVO69C("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVO69C("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVO69C("cam.provid")
   elif item == "x_cam_server"  : self.VVO69C("cam.server")
   elif item == "x_cam_services" : self.VVO69C("cam.services")
   elif item == "x_cam_srvid2"  : self.VVO69C("cam.srvid2")
   elif item == "x_cam_user"  : self.VVO69C("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVrTYv()
   elif item == "x_CCcam_cfg"  : FFRva2(self, self.VV3GR8 + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFRva2(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFRva2(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFRva2(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVO69C(self, fileName):
  FFRva2(self, self.VV3GR8 + self.prefix + fileName)
 def VVrTYv(self):
  path = self.VV3GR8 + "SoftCam.Key"
  if fileExists(path) : FFRva2(self, path)
  else    : FFRva2(self, path.replace(".Key", ".key"))
class CC9rk7(Screen):
 VVVYCp  = 0
 VVatae = 1
 VVEymg = 2
 def __init__(self, session, VV3GR8="", VVQXf7="", VVnSWi="", VVZnxN=VVVYCp):
  self.skin, self.skinParam = FFWbv3(VVgJDM, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVnSWi   = VVnSWi
  self.VVZnxN  = VVZnxN
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV3GR8 + VVQXf7 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVQXf7 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV3GR8, self.camPrefix)
  if self.VVZnxN == self.VVVYCp:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVZnxN == self.VVatae:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF3tZI(self, self.Title, addScrollLabel=True)
  FFTvkX(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV6P4Z
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self["myLabel"].VVILcs(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFxlor(self)
  self.VV6P4Z()
 def onExit(self):
  self.timer.stop()
 def VVQBUC(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVyg2m)
  except:
   self.timer.callback.append(self.VVyg2m)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF7BjW(self, "Started", 1000)
 def VVqRiv(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVyg2m)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF7BjW(self, "Stopped", 1000)
 def VV6P4Z(self):
  if self.timerRunning:
   self.VVqRiv()
  else:
   self.VVQBUC()
   if self.VVZnxN == self.VVVYCp or self.VVZnxN == self.VVatae:
    if self.VVZnxN == self.VVVYCp : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCAwAg.VVCBNl(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFdw1m(self.VVgcBu)
    else:
     self.close()
   else:
    self.VVa3Zr()
 def VVyg2m(self):
  if self.timerRunning:
   if   self.VVZnxN == self.VVVYCp : self.VVcyYF()
   elif self.VVZnxN == self.VVatae : self.VVcyYF()
   else            : self.VVa3Zr()
 def VVa3Zr(self):
  if fileExists(self.VVnSWi):
   fTime = FFmWOg(os.path.getmtime(self.VVnSWi))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV0mhD(), VVgcXL=VV8u5W)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVnSWi)
 def VVgcBu(self):
  self.VVcyYF()
 def VVcyYF(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFNr4J("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVqDXM))
   self.camWebIfErrorFound = True
   self.VVqRiv()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVZnxN == self.VVVYCp : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFNr4J("Error while parsing data elements !\n\nError = %s" % str(e), VVEWKM)
   self.camWebIfErrorFound = True
   self.VVqRiv()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVVVgK(root)
  self["myLabel"].setText(txt, VVgcXL=VV8u5W)
  self["myBar"].setText("Last Update : %s" % FFKMpI())
 def VVVVgK(self, rootElement):
  def VVOb1w(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVZnxN == self.VVVYCp:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFNr4J(status, VVhmJa)
    else          : status = FFNr4J(status, VVEWKM)
    txt += SEP + "\n"
    txt += VVOb1w("Name"  , name)
    txt += VVOb1w("Description" , desc)
    txt += VVOb1w("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVOb1w("Protocol" , protocol)
    txt += VVOb1w("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFNr4J("Yes", VVhmJa)
    else    : enabTxt = FFNr4J("No", VVEWKM)
    txt += SEP + "\n"
    txt += VVOb1w("Label"  , label)
    txt += VVOb1w("Protocol" , protocol)
    txt += VVOb1w("Enabled" , enabTxt)
  return txt
 def VV0mhD(self):
  lines = FFtLFA("tail -n %d %s" % (100, self.VVnSWi))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVljbY + line[:19] + VVi1yn + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVFb7H + "WebIf" + VVi1yn)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVi9VJ + h1 + h2 + VVi1yn + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVhmJa + span.group(2) + VVQzZA + span.group(3) + VVi1yn + span.group(4)
    line = self.VVYCPl(line, VVQzZA, ("(webif)", ))
    line = self.VVYCPl(line, VVQzZA, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVYCPl(line, VVhmJa, ("OSCam", "NCam", "log switched"))
    line = self.VVYCPl(line, VVIZs4, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVde5r + line[ndx + 3:] + VVi1yn
   elif line.startswith("----") or ">>" in line:
    line = FFNr4J(line, VVqIxN)
   txt += line + "\n"
  return txt
 def VVYCPl(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVi1yn + t3
  return line
class CCmjM9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVZ4NM = []
  VVZ4NM.append(("Backup Channels"    , "VVXxRy"   ))
  VVZ4NM.append(("Restore Channels"    , "Restore_Channels"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Backup SoftCAM Files"   , "VVWAYX" ))
  VVZ4NM.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVZ4NM.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVZ4NM.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Backup Network Settings"  , "VVuVL5"   ))
  VVZ4NM.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVFBr8:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((VVqDXM + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVpmkp"   ))
   VVZ4NM.append((VVhmJa + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVUalC), "createMyIpk"   ))
   VVZ4NM.append((VVhmJa + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVUalC), "createMyDeb"   ))
   VVZ4NM.append((VVi9VJ + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVZ4NM.append((VVi9VJ + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVm7v6" ))
   VVZ4NM.append((VVi9VJ + "Show Windows Stats"           , "VVpLjv" ))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVXxRy"    : self.VVXxRy()
   elif item == "Restore_Channels"    : self.VVjo0a("channels_backup*.tar.gz", self.VVlYeM, isChan=True)
   elif item == "VVWAYX"   : self.VVWAYX()
   elif item == "Restore_SoftCAM_Files"  : self.VVjo0a("softcam_backup*.tar.gz", self.VVHosm)
   elif item == "Backup_TunerDiSEqC"   : self.VVunaZ("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVjo0a("tuner_backup*.backup", BF(self.VVtyA6, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVunaZ("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVjo0a("hotkey_*backup*.backup", BF(self.VVtyA6, "misc"))
   elif item == "VVuVL5"    : self.VVuVL5()
   elif item == "Restore_Network"    : self.VVjo0a("network_backup*.tar.gz", self.VViDW0)
   elif item == "VVpmkp"     : FF4s3j(self, BF(FF1QiT, self, BF(CCmjM9.VVpmkp, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVV6bl(False)
   elif item == "createMyDeb"     : self.VVV6bl(True)
   elif item == "createMyTar"     : self.VVOgHw()
   elif item == "VVm7v6"   : self.VVm7v6()
   elif item == "VVpLjv"    : CCmjM9.VVpLjv(self)
 @staticmethod
 def VVTFUG(SELF):
  OBF_Path = VVBOse + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FF7Hmv(SELF, OBF_Path)
   return None
 @staticmethod
 def VVpLjv(SELF):
  obf = CCmjM9.VVTFUG(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFXEvX(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVpmkp(SELF):
  obf = CCmjM9.VVTFUG(SELF)
  if obf:
   txt, err = obf.fixCode(VVBOse, VVAgrE, VVUalC)
   if err : FF0eUf(SELF, err)
   else : FFXEvX(SELF, txt)
 def VVV6bl(self, VVqmRU):
  OBF_Path = VVBOse + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF0eUf(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFKiof("rm -f %s__pycache__/" % VVBOse)
  FFKiof("mv -f '%smain.py' '%s'" % (VVBOse, OBF_Path))
  FFKiof("mv -f '%splugin.py' '%s'" % (VVBOse, OBF_Path))
  FFKiof("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVBOse))
  self.session.openWithCallback(self.VVxANy, BF(CCCLco, path=VVBOse, VVqmRU=VVqmRU))
 def VVxANy(self):
  FFKiof("mv -f %s %s" % (VVBOse + "OBF/main.py" , VVBOse))
  FFKiof("mv -f %s %s" % (VVBOse + "OBF/plugin.py", VVBOse))
 def VVm7v6(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF0eUf(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF0eUf(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVdQGe("%s*.list" % path)
  if err:
   FF7Hmv(self, path + "*.list")
   return
  srcF, err = self.VVdQGe("%s*main_final.py" % path)
  if err:
   FF7Hmv(self, path + "*.final.py")
   return
  VVDpqo = []
  for f in files:
   f = os.path.basename(f)
   VVDpqo.append((f, f))
  FFLMiy(self, BF(self.VVDkV4, path, codF, srcF), VVZ4NM=VVDpqo)
 def VVDkV4(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF7Hmv(self, logF)
   else     : FF1QiT(self, BF(self.VVCUDw, logF, codF, srcF))
 def VVCUDw(self, logF, codF, srcF):
  lst  = []
  lines = FFMA9m(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF0eUf(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVLNNe(lst, logF, newLogF)
  totSrc  = self.VVLNNe(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFXEvX(self, txt)
 def VVdQGe(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVLNNe(self, lst, f1, f2):
  txt = FFBRKz(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVOgHw(self):
  VVDpqo = []
  VVDpqo.append("%s%s" % (VVBOse, "*.py"))
  VVDpqo.append("%s%s" % (VVBOse, "*.png"))
  VVDpqo.append("%s%s" % (VVBOse, "*.xml"))
  VVDpqo.append("%s"  % (VVrRM9))
  FFQMId(self, VVDpqo, "%s_%s" % (PLUGIN_NAME, VVAgrE), addTimeStamp=False)
 def VVXxRy(self):
  path1 = VVPxkP
  path2 = "/etc/tuxbox/"
  VVDpqo = []
  VVDpqo.append("%s%s" % (path1, "*.tv"))
  VVDpqo.append("%s%s" % (path1, "*.radio"))
  VVDpqo.append("%s%s" % (path1, "*list"))
  VVDpqo.append("%s%s" % (path1, "lamedb*"))
  VVDpqo.append("%s%s" % (path2, "*.xml"))
  FFQMId(self, VVDpqo, self.VVdRlL("channels_backup"), addTimeStamp=True)
 def VVWAYX(self):
  VVDpqo = []
  VVDpqo.append("/etc/tuxbox/config/")
  VVDpqo.append("/usr/keys/")
  VVDpqo.append("/usr/scam/")
  VVDpqo.append("/etc/CCcam.cfg")
  FFQMId(self, VVDpqo, self.VVdRlL("softcam_backup"), addTimeStamp=True)
 def VVuVL5(self):
  VVDpqo = []
  VVDpqo.append("/etc/hostname")
  VVDpqo.append("/etc/default_gw")
  VVDpqo.append("/etc/resolv.conf")
  VVDpqo.append("/etc/wpa_supplicant*.conf")
  VVDpqo.append("/etc/network/interfaces")
  VVDpqo.append("%snameserversdns.conf" % VVPxkP)
  FFQMId(self, VVDpqo, self.VVdRlL("network_backup"), addTimeStamp=True)
 def VVdRlL(self, fName):
  img = CCo4WP.VVz2h4()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVlYeM(self, fileName=None):
  if fileName:
   FF4s3j(self, BF(FF1QiT, self, BF(self.VVlzNt, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVlzNt(self, fileName):
  path = "%s%s" % (VVbRSD, fileName)
  if fileExists(path):
   if CCNmp1.VVHXvz(path):
    VVCBDF , VVkuAN = CCtCGd.VVbblq()
    VVAyJq, VV1jhb = CCtCGd.VVtNQv()
    cmd  = FFyMLY("cd %s" % VVPxkP)
    cmd += FFyMLY("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVkuAN, VV1jhb))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFKiof(cmd)
    FFwnFB()
    if ok: FFH1Ib(self, "Channels Restored.")
    else : FF0eUf(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FF0eUf(self, "Invalid tar file:\n\n%s" % path)
  else:
   FF7Hmv(self, path)
 def VVHosm(self, fileName=None):
  if fileName:
   FF4s3j(self, BF(self.VVgeIp, fileName), "Overwrite SoftCAM files ?")
 def VVgeIp(self, fileName):
  fileName = "%s%s" % (VVbRSD, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FFfDBJ(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFVW8g(note, VVde5r), sep))
  else:
   FF7Hmv(self, fileName)
 def VViDW0(self, fileName=None):
  if fileName:
   FF4s3j(self, BF(self.VVj3WC, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVj3WC(self, fileName):
  fileName = "%s%s" % (VVbRSD, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFxjL4(self,  cmd)
  else:
   FF7Hmv(self, fileName)
 def VVjo0a(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFFBSc()
  if pathExists(VVbRSD):
   myFiles = FFFDtI(VVbRSD, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVDpqo = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVDpqo.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVWjWA = ("Sat. List", self.VVNUv3)
    elif isChan and iTar: VVWjWA = ("Bouquets Importer", CCWYnG.VVBln1)
    else    : VVWjWA = None
    FFLMiy(self, callBackFunction, title=title, width=1200, VVZ4NM=VVDpqo, VVWjWA=VVWjWA, VVpQam=VVbRSD)
   else:
    FF0eUf(self, "No files found in:\n\n%s" % VVbRSD, title)
  else:
   FF0eUf(self, "Path not found:\n\n%s" % VVbRSD, title)
 def VVunaZ(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVPxkP
  tCons = CC0afB()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVrw24, filePrefix))
 def VVrw24(self, filePrefix, result, retval):
  title = FFFBSc()
  if pathExists(VVbRSD):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF0eUf(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVbRSD, filePrefix, self.VVdRlL(""), FFXJI8())
    try:
     VVDpqo = str(result.strip()).split()
     if VVDpqo:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVDpqo:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFNr4J(fName, VVde5r), SEP)
       FFXEvX(self, txt, title=title, VVgcXL=VV8u5W)
      else:
       FF0eUf(self, "File creation failed!", title)
     else:
      FF0eUf(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFKiof("rm %s" % fName)
     FF0eUf(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFKiof("rm %s" % fName)
     FF0eUf(self, "Error while writing file.")
  else:
   FF0eUf(self, "Path not found:\n\n%s" % VVbRSD, title)
 def VVtyA6(self, mode, path=None):
  if path:
   path = "%s%s" % (VVbRSD, path)
   if fileExists(path):
    lines = FFMA9m(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FF4s3j(self, BF(self.VV0stl, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFoJHK(self, path, title=FFFBSc())
   else:
    FF7Hmv(self, path)
 def VV0stl(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVAq5S = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVAq5S.append("echo -e 'Reading current settings ...'")
  VVAq5S.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVAq5S.append("echo -e 'Preparing new settings ...'")
  VVAq5S.append(settingsLines)
  VVAq5S.append("echo -e 'Applying new settings ...'")
  VVAq5S.append("mv -f %s %s" % (tFile, sFile))
  FFc045(self, VVAq5S)
 def VVNUv3(self, VVMD9SObj, path):
  if not path:
   return
  path = VVbRSD + path
  if not fileExists(path):
   FF7Hmv(self, path)
   return
  txt = FFBRKz(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFwEqh(item[1]))
   FFXEvX(self, txt, title="Satellites List")
  else:
   FF0eUf(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCWYnG():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVBln1(SELF, fName):
  bi = CCWYnG(SELF)
  bi.instance = bi
  bi.VVCh74(SELF, fName)
 @staticmethod
 def VVa6Ob(SELF):
  bi = CCWYnG(SELF)
  bi.instance = bi
  bi.VVdSvl()
 def VVCh74(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVbRSD + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF1QiT(waitObg, self.VVBKlH, title="Reading bouquets ...")
  else      : self.VVE82Q(self.filePath)
 def VV9Jog(self, txt) : FF0eUf(self.SELF, txt, title=self.Title)
 def VVR9V4(self, txt)  : FF7BjW(self, txt, 1500)
 def VVE82Q(self, path) : FF7Hmv(self.SELF, path, title=self.Title)
 def VVdSvl(self):
  if pathExists(VVbRSD):
   lst = FFFDtI(VVbRSD, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVroQ0())
   if len(lst) > 0:
    VVZ4NM = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFNr4J(item, VVQzZA) if item.endswith(".zip") else item
     VVZ4NM.append((txt, item))
    VVZ4NM.sort(key=lambda x: x[1].lower())
    VVsd1c = self.VVyAkE
    FFLMiy(self.SELF, self.VV5QV4, minRows=3, title=self.Title, width=1200, VVZ4NM=VVZ4NM, VVsd1c=VVsd1c, VVpQam=VVbRSD, VVrEme="#22111111", VVRBt6="#22111111")
   else:
    self.VV9Jog("No valid backup files found in:\n\n%s" % VVbRSD)
  else:
   self.VV9Jog("Backup Directory not found:\n\n%s" % VVbRSD)
 def VVyAkE(self, item=None):
  if item:
   VVKicw, txt, fName, ndx = item
   self.VVCh74(VVKicw, fName)
 def VV5QV4(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVroQ0(self):
  files = FFFDtI(VVbRSD, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVBKlH(self):
  lines, err = CCWYnG.VVJWoK(self.filePath, "bouquets.tv")
  if err:
   self.VV9Jog(err)
   return
  bTvSortLst  = self.VV4K45(lines)
  lines, err = CCWYnG.VVJWoK(self.filePath, "bouquets.radio")
  if err:
   self.VV9Jog(err)
   return
  bRadSortLst = self.VV4K45(lines)
  VVJIKO = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVplR7(f, mode, len(VVJIKO), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVJIKO.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVplR7(f, mode, len(VVJIKO), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVplR7(f, mode, len(VVJIKO), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVJIKO.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVplR7(f, mode, len(VVJIKO), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVJIKO:
   VVJIKO.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVJIKO): VVJIKO[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVJIKO):
     if key == os.path.basename(row[9]):
      VVJIKO = VVJIKO[:ndx+1] + lst + VVJIKO[ndx+1:]
      break
   for ndx, item in enumerate(VVJIKO): VVJIKO[ndx][0] = str(ndx + 1)
   VVfKIv = "#11000600"
   VVFJkn  = ("Show Services" , self.VV5ksT  , [], "Reading ..." )
   VVU95Y = (""    , self.VVKqVn, [])
   VV0RwZ = ("Options"  , self.VVDOaL, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVXdZ9  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFW2Tv(self.SELF, None, title=self.Title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=24, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV0RwZ=VV0RwZ, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVrEme=VVfKIv, VVRBt6=VVfKIv, VVfKIv=VVfKIv, VV6z2K="#00004455", VV7JIr="#0a282828")
  else:
   self.VV9Jog("No valid bouquets in:\n\n%s" % self.filePath)
 def VV4K45(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVKqVn(self, VVSuUg, title, txt, colList):
  FFXEvX(self.SELF, FFhc8v(txt), title=title)
 def VVDOaL(self, VVSuUg, title, txt, colList):
  mSel = CCIjyQ(self.SELF, VVSuUg)
  if VVSuUg.VVJZs5:
   totSel = VVSuUg.VVv1D2()
   if totSel: VVZ4NM = [("Import %s Bouquet%s" % (FFNr4J(str(totSel), VVhmJa), FF1OOs(totSel)), "imp")]
   else  : VVZ4NM = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFNr4J(bName, VVhmJa)
   VVZ4NM = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF1QiT, VVSuUg, BF(CCWYnG.VVwEZM, self.SELF, VVSuUg, self.filePath))}
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 def VV5ksT(self, VVSuUg, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCWYnG.VVJWoK(self.filePath, "lamedb")
   if err:
    self.VV9Jog(err)
    return
   dbServLst = CCtCGd.VVGHky(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVSuUg.VVU4OP()
   lines, err = CCWYnG.VVJWoK(self.filePath, os.path.basename(fName))
   if err:
    self.VV9Jog(err)
    return
   VVJIKO = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVJIKO.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVJIKO.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVJIKO.append((span.group(1).strip() or "-", "Stream Relay" if FF98yX(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVJIKO.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVJIKO.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCtCGd.VVg3Dt(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVJIKO.append((name.strip() or "-", FFAVEM(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVJIKO):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCWYnG.VVJWoK(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVJIKO[ndx] = (bName, descr)
   if VVJIKO:
    VVfKIv = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVXdZ9 = (LEFT  , CENTER)
    FFW2Tv(self.SELF, None, title="Services in : %s" % bName, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VVrEme=VVfKIv, VVRBt6=VVfKIv, VVfKIv=VVfKIv, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FF7BjW(VVSuUg, err, 1500)
  else : VVSuUg.VVTVqz()
 def VVplR7(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VV9Jog("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FF98yX(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV5jhO(var):
   return str(var) if var else VVX5FP + str(var)
  totItem = VVde5r + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVqDXM   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVQzZA, "Sub-B."
  else  : bColor, totBnb = ""      , VV5jhO(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV5jhO(totDVB), VV5jhO(totIptv), VV5jhO(totSRelay), VV5jhO(totLoc), VV5jhO(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVwEZM(SELF, VVSuUg, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVPxkP + "bouquets.tv"
  radBouquetFile = VVPxkP + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FF7Hmv(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FF7Hmv(SELF, radBouquetFile, title=title)
   return
  isMulti = VVSuUg.VVJZs5
  if isMulti : rows = VVSuUg.VVNKQi()
  else  : rows = [VVSuUg.VVU4OP()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FF0eUf(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFhc8v(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFhc8v(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVPxkP + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVPxkP + newFile
    CCWYnG.VV9ehV(archPath, fName, VVPxkP, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFg7n1(tvBouquetFile)
   FFg7n1(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCWYnG.VVHo2p(SELF, archPath, bList)
   FFwnFB()
  txt  = FFNr4J("Added:\n", VVQzZA)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFNr4J("Imported to lamedab:\n", VVQzZA)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFNr4J("Missing from archived lamedb:\n", VVqDXM)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFXEvX(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVHo2p(SELF, archPath, bList):
  VVCBDF, err = CCtCGd.VVzI2O(SELF, VV8wkm=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCtCGd.VVMeRF(VVCBDF, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFMA9m(VVPxkP + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCtCGd.VVg3Dt(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCtCGd.VVpp11(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCWYnG.VVk3To(archPath, dbName)
   CCWYnG.VV9ehV(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCtCGd.VVMeRF(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCtCGd.VVMeRF(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCtCGd.VVMeRF(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCtCGd.VVMeRF(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFfhv3(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVCBDF + ".tmp"
   lines   = FFMA9m(VVCBDF)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFKiof("mv -f '%s' '%s'" % (tmpDbFile, VVCBDF))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVlkyZ(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVk3To(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VV9ehV(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVJWoK(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCoJff():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVMPqs()
 def VVMPqs(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVIcom(self):
  FF1QiT(self, self.VVkOUB)
 def VVkOUB(self):
  if pathExists(self.projMainPath):
   lst = FFVpah(self.projMainPath)
   VVZ4NM = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVZ4NM.append((prName, prName))
   if VVZ4NM:
    VVZ4NM.sort(key=lambda x: x[1].lower())
    VVsd1c = self.VVTSP0
    VVWjWA = ("Add new project", self.VVLJaJ)
    VVcrQj= ("Delete Project" , self.VVvczd)
    self.projMenu = FFLMiy(self, None, VVZ4NM=VVZ4NM, width=1100, VVsd1c=VVsd1c, VVWjWA=VVWjWA, VVcrQj=VVcrQj, minRows=5, VVrEme="#22111133", VVRBt6="#22111133")
   else:
    FF4s3j(self, self.VVx7yq, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VV8suF("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVx7yq(self)    : FF1QiT(self, BF(self.VVL3qY))
 def VVLJaJ(self, VVKicw, item) : FF1QiT(self.projMenu, BF(self.VVL3qY))
 def VVL3qY(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVcFZS(name)
 def VVcFZS(self, name, cbFnc=None):
  FFFMZg(self, cbFnc or self.VVyAY4, defaultText=name, title="New Project Name", message="Enter project name")
 def VVyAY4(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FF4s3j(self, BF(self.VVcFZS, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFxuJG(path)
    if err:
     self.VV8suF("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVRR5n((item, item), isSort=True)
     else   : self.VVIcom()
 def VVvczd(self, VVKicw, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFPgYE(path)
    FF4s3j(self, BF(self.VVBPDi, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVBPDi(self, path):
  if FFKiof("rm -rf '%s'" % path):
   self.projMenu.VVUe1j()
 def VVTSP0(self, item=None):
  if item:
   VVKicw, txt, Dir, ndx = item
   self.VVMPqs()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVrRM9
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFMA9m(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFKMpI()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVGcS8()
   else      : self.VV8suF("Cannot create project file:\n\n%s" % self.projFile)
 def VVGcS8(self, VVKicw=None, jmpDict=None):
  FF1QiT(VVKicw or self.projTable or self, BF(self.VVilPZ, jmpDict))
 def VVilPZ(self, jmpDict):
  self.VVMPqs()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFMA9m(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVePjf(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VV8suF('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFPebg(path)
    if sz > -1: size = CCNmp1.VV3y2b(sz, mode=4)
    else   : size = FFNr4J("Size error", VVqDXM)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFMA9m(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVJ46j(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVNSTR(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFNr4J("Unknown value", VVqDXM), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFNr4J(rem, VVqDXM), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVJIKO = pkgRows
  VVJIKO.extend(actnRows)
  VVJIKO.extend(ctrlRows)
  VVJIKO.extend(fileRows)
  VVJIKO.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVJIKO):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFNr4J("Valid", VVhmJa), " ... " + Remarks if Remarks else "")
    VVJIKO[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVuO1Y(VVJIKO, tableRefreshCB=BF(self.VVuvwK, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVU95Y = (""     , self.VV3RQx   , [])
   menuButtonFnc = (""     , self.VVEOZo   , [])
   VVdvf0 = ("Create Package"  , self.VVaCkb , [])
   VV0RwZ = ("Post Install Action", self.VVxvAM, [])
   VVUpMt = ("Edit File"   , self.VVvihA  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVXdZ9 = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, width=1850, height=1040, VVsgYf=26, VVU95Y=VVU95Y, menuButtonFnc=menuButtonFnc, VVdvf0=VVdvf0, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, searchCol=2
         , VVrEme=bg, VVRBt6=bg, VVfKIv=bg, VV6z2K="#00664411", VV7JIr="#00444444", VVpBpY="#08442211")
   self.projTable.VV9XZ7(self.VVijGF)
   self.VVijGF()
 def VVuvwK(self, jmpDict, VVSuUg, title, txt, colList):
  self.projTable.VVeEhA(jmpDict)
 def VVijGF(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVU4OP()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVePjf(self, line):
  def VV7TKp(patt, val, Len):
   if len(val) < Len   : return FFNr4J("Length error" , VVqDXM)
   elif not iMatch(patt, val) : return FFNr4J("Invalid format" , VVqDXM)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VV7TKp(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VV7TKp(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVJ46j(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFkmyW(path)
  path = FFliS8(path)
  c = VVqDXM
  if   typ == "Mount" : rem = FFNr4J("Not allowed", c)
  elif not typ  : rem = FFNr4J("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFNr4J("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFoEhk(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFkmyW(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFNr4J("Not allowed", c)
     elif targetType == "Directory" : sz = FFoEhk(targetPath)
     elif targetType == "File"  : sz = FFPebg(targetPath)
     else       : sz, rem = FFPebg(path), FFNr4J("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFPebg(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCNmp1.VV3y2b(sz, mode=4)
     else:
      size = FFNr4J("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVNSTR(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVvihA(self, VVSuUg, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCC9Tv(self, path, VVtCUJ=self.VV0TEZ, curRowNum=lineNdx)
  else    : FF7Hmv(self, path)
 def VV0TEZ(self, fileChanged):
  if fileChanged:
   self.VVGcS8()
 def VV8suF(self, txt):
  FF0eUf(self, txt, title=self.projTitle)
 def VV3RQx(self, VVSuUg, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVQzZA
  s  = FF0CQw("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FF0CQw("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCNmp1.VV3y2b(self.projFilesSize))
  FFXEvX(self, s, title="Project Info", width=1600)
 def VVEOZo(self, VVSuUg, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVI2ZY, VVh9Nn, VVQzZA
  VVZ4NM = []
  VVZ4NM.append((c1 + "Add Resource File"  , "addFile" ))
  VVZ4NM.append((c1 + "Add Resource Directory" , "addDir" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Package Name"   , "pkgNam" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Add Dependency"   , "addDep" ))
  VVZ4NM.append((c2 + "Remove Dependency"  , "delDep" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVZ4NM.append(FF1giv('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(FF1giv("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVqDXM))
  FFLMiy(self, self.VV5OB7, VVZ4NM=VVZ4NM, width=1050, title="Options", VVrEme="#11001122", VVRBt6="#11001122")
 def VV5OB7(self, item=None):
  if item:
   if   item == "addFile" : self.VV6Hf6(False)
   elif item == "addDir" : self.VV6Hf6(True)
   elif item == "pkgNam" : self.VVTkho()
   elif item == "addDep" : FF1QiT(self.projTable, self.VVeUuZ)
   elif item == "delDep" : self.VVeNzd()
   elif item == "ctrlFMan" : self.VVBPWy()
   elif item == "ctrlImprt": FF1QiT(self.projTable, self.VV0mI5)
   elif item == "ctrlUndo" : self.VVI8da()
   elif item == "delRow" : self.VVFrcp()
 def VV6Hf6(self, isDir):
  Dir = FFabdw(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVn0IC, BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=Dir))
  else : self.session.openWithCallback(self.VVn0IC, BF(CCNmp1, patternMode="all", VVxAst=Dir))
 def VVn0IC(self, path):
  if path:
   FFE6Br(CFG.lastPkgProjDir, path)
   self.VV4Q1R(path, 2)
 def VVBPWy(self):
  Dir = FFabdw(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVneUP, BF(CCNmp1, patternMode="pkgCtrl", VVxAst=Dir))
 def VVneUP(self, path):
  if path:
   FFE6Br(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFKiof("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVGcS8()
    self.projTable.VVeEhA({1:"Script", 2:fName})
 def VV0mI5(self):
  cmd = FF8xxa(VVWjcv, "")
  if not cmd:
   FFPXac(self)
   return
  lst = FFtLFA(cmd)
  if lst:
   err = CCNmp1.VVUj2E(lst, fromFind=False)
   if err:
    self.VV8suF(err)
    return
   lst.sort()
   VVJIKO = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVJIKO.append(("", span.group(1), span.group(2)))
   if VVJIKO:
    VV8lmg = ("Import 'control' data", self.VV0die, [])
    VV0RwZ = ("Package Info.", self.VV8gsf     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=30, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVSboA=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVrEme="#22110011", VVRBt6="#22191111", VVfKIv="#22191111", VV6z2K="#00003030", VV7JIr="#00333333")
   else:
    self.VV8suF("Cannot process installed packages !")
  else:
   self.VV8suF("Cannot read installed packages !")
 def VVI8da(self):
  if FFKiof("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVGcS8(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VV8suF("Process Failed !")
 def VV0die(self, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVkjOU, VVSuUg, colList[1]))
 def VVkjOU(self, VVSuUg, pkg):
  lines = []
  for line in FFtLFA(FF2pmn(VVsD89, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FF4s3j(self, BF(self.VVRFyW, VVSuUg, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VV8suF("Cannot import from this package:\n\n%s" % pkg)
 def VVRFyW(self, VVSuUg, lines):
  VVSuUg.cancel()
  FFKtq8(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVGcS8(jmpDict={1:"Control", 2:"Package"})
 def VVFrcp(self):
  lineNum = int(self.projTable.VVU4OP()[0]) + 1
  FFKiof("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVGcS8()
 def VV4Q1R(self, line, jmp):
  if fileExists(self.projFile):
   FFKtq8(self.projFile)
   FFg7n1(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVGcS8(jmpDict=jmpDict)
  else:
   FF7Hmv(self, self.projFile, title=self.projTitle)
 def VVxvAM(self, VVSuUg, title, txt, colList):
  VVZ4NM = []
  VVZ4NM.append(FF1giv("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVZ4NM.append(FF1giv("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVZ4NM.append(FF1giv("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(FF1giv("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVZ4NM.append(FF1giv("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVZ4NM.append(FF1giv("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFLMiy(self, self.VVgkF5, VVZ4NM=VVZ4NM, title="Action (after the package is installed/removed)")
 def VVgkF5(self, item=None):
  if item:
   if   item == "instNon" : self.VVN2Ts("postinst", 0)
   elif item == "instRes" : self.VVN2Ts("postinst", 1)
   elif item == "instReb" : self.VVN2Ts("postinst", 2)
   elif item == "rmNon" : self.VVN2Ts("postrm", 0)
   elif item == "rmRes" : self.VVN2Ts("postrm", 1)
   elif item == "rmReb" : self.VVN2Ts("postrm", 2)
 def VVN2Ts(self, subj, val):
  if fileExists(self.projFile):
   lines = FFMA9m(self.projFile)
   FFKtq8(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VV4Q1R("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVGcS8()
 def VVTkho(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVZ4NM = []
  VVZ4NM.append((pkg, pkg))
  VVZ4NM.append(VVVvw4)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVQzZA if name == self.projPkg else ""
    VVZ4NM.append((c + name, name))
   else:
    VVZ4NM.append(VVVvw4)
  FFLMiy(self, self.VVYMsV, VVZ4NM=VVZ4NM, title="Package Name")
 def VVYMsV(self, item=None):
  if item:
   self.VVSSt2("Package", item)
 def VVeUuZ(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVZ4NM = []
   for item in lst: VVZ4NM.append((item, item))
   VVZ4NM.sort(key=lambda x: x[0].lower())
   VVKicw = FFLMiy(self, self.VV7gjb, VVZ4NM=VVZ4NM, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVKicw.VVEfNd(self.projLastDepends)
  else:
   self.VV8suF("Cannot read dependencies list !")
 def VV7gjb(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFMA9m(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVSSt2("Depends", ", ".join(lst))
   else:
    FF7BjW(self.projTable, "Already added", 1500)
    self.projTable.VVeEhA({1:"Control", 2:"Depends"})
 def VVeNzd(self):
  lst = []
  for row in self.projTable.VVOxLE():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVZ4NM = []
   for item in lst: VVZ4NM.append((item, item))
   FFLMiy(self, BF(self.VVDBCz, lst), VVZ4NM=VVZ4NM, title="Remove Dependency")
  else:
   self.VV8suF("No dependencies to remove !")
 def VVDBCz(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVSSt2("Depends", ", ".join(lst))
   else:
    FFKiof("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVGcS8()
 def VVSSt2(self, subj, val):
  lines = FFMA9m(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVGcS8(jmpDict={1:"Control", 2:subj})
 def VVaCkb(self, VVSuUg, title, txt, colList):
  VVZ4NM = []
  VVZ4NM.append(("Create .ipk"  , "ipk"))
  VVZ4NM.append(("Create .deb"  , "deb"))
  VVZ4NM.append(("Create .tar.gz" , "tar"))
  FFLMiy(self, self.VVwwej, VVZ4NM=VVZ4NM, width=500, title=self.projTitle)
 def VVwwej(self, item=None):
  if item:
   FF1QiT(self.projTable, BF(self.VVGSSK, item))
 def VVGSSK(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VV8suF("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVqmRU, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVqmRU, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VV8suF(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFyMLY("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFVW8g(result  , VVhmJa))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFVW8g(failed, VVEWKM))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFyMLY("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVOxLE()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFxjL4(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFKiof(cmd) or not pathExists(ctrlDir):
   VV8suF(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VV7TKp(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFKiof("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VV7TKp(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFg7n1(dstF)
   FFKiof("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFib1Q()
  if VVqmRU:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF6Lzl("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFxjL4(self, cmd)
class CC5jmY(Screen, CCoJff):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCoJff.__init__(self)
  c1, c2, c3, c4 = VVI2ZY, VVh9Nn, VVljbY, VVQzZA
  VVZ4NM = []
  VVZ4NM.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c3 + "Remove Packages (show all)"     , "VVZXVasAll"  ))
  VVZ4NM.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Update Packages List from Feed"    , "VVyBGu"  ))
  VVZ4NM.append((c2 + "Upgradable Packages"       , "VVkWPU" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Packaging Tool"         , "VVbs36"   ))
  VVZ4NM.append(("Active Feeds"          , "VVqRMr"   ))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCMocy.VVyQeg(self)
   elif item == "downloadInstallPackages"  : FF1QiT(self, BF(self.VV3yBG, 0, ""))
   elif item == "VVZXVasAll"   : FF1QiT(self, BF(self.VV3yBG, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF1QiT(self, BF(self.VV3yBG, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVyBGu"   : CC5jmY.VVyBGu(self)
   elif item == "VVkWPU"  : FF1QiT(self, self.VVkWPU)
   elif item == "packageCreator"    : self.VVIcom()
   elif item == "VVbs36"    : self.VVbs36()
   elif item == "VVqRMr"    : FF1QiT(self, self.VVqRMr)
   else          : self.close()
 def VVqRMr(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVJIKO = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVJIKO.append((os.path.basename(path), str(tot)))
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVXdZ9 = (LEFT  , CENTER )
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, width=1000, VVsgYf=26, VVEIfy=2)
  else:
   self.VV8suF("Cannot read packages list !")
 def VVkWPU(self, VVSuUg=None):
  lst = FFtLFA(FF8xxa(VVCfAq, ""))
  VVJIKO = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVJIKO.append((str(len(VVJIKO) + 1), pkg, curV, newVer))
   if VVJIKO:
    if VVSuUg:
     VVSuUg.VVuO1Y(VVJIKO, VV8SPjMsg=True)
    else:
     bg = "#00221111"
     VV8lmg = ("Upgrade", self.VV87ak   , [])
     VV0RwZ = ("Package Info.", self.VV8gsf , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVXdZ9 = (CENTER , LEFT  , LEFT  , LEFT   )
     FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, width=1700, VVsgYf=26, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVROQm=True, VVOPrI=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVrEme=bg, VVRBt6=bg, VVfKIv=bg, VVIWfT="#00ffff55", VV6z2K="#00003040")
  if not VVJIKO:
   FFVyvQ(self, "Nothing to upgrade", 1500)
   if VVSuUg: VVSuUg.cancel()
 def VV87ak(self, VVSuUg, title, txt, colList):
  pkg = colList[1]
  cmd = FF2pmn(VVLJqS, pkg)
  if cmd : FFxjL4(self, cmd, title="Installing : %s" % pkg, VVgmlB=BF(self.VVkWPU, VVSuUg))
  else : FFPXac(SELF)
 def VVbs36(self):
  pkg = FFoJDA()
  aptT = "apt - Advanced Package Tool" if FF4wzI("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFH1Ib(self, txt or "No packaging tools found!")
 def VV3yBG(self, mode, grep, VVSuUg=None, title=""):
  if   mode == 0: cmd = FF8xxa(VVphAw    , grep)
  elif mode == 1: cmd = FF8xxa(VVWjcv , grep)
  elif mode == 2: cmd = FF8xxa(VVWjcv , grep)
  if not cmd:
   FFPXac(self)
   return
  VVJIKO = FFtLFA(cmd)
  if VVJIKO:
   err = CCNmp1.VVUj2E(VVJIKO, fromFind=False)
   if err:
    FF0eUf(self, err)
    return
  else:
   if VVSuUg: VVSuUg.VVTVqz()
   FF0eUf(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVDpqo  = []
  for item in VVJIKO:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVDpqo.append((name, package, version))
  if mode > 0:
   extensions = FFtLFA("ls %s -l | grep '^d' | awk '{print $9}'" % VV0xPn)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVDpqo:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVGEIo: name += "el"
      VVDpqo.append((name, VV0xPn + item, "-"))
   systemPlugins = FFtLFA("ls %s -l | grep '^d' | awk '{print $9}'" % VVydp3)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVDpqo:
      if item.lower() == row[0].lower():
       break
     else:
      VVDpqo.append((item, VVydp3 + item, "-"))
  if not VVDpqo:
   FF0eUf(self, "No packages found!")
   return
  if VVSuUg:
   VVDpqo.sort(key=lambda x: x[0].lower())
   VVSuUg.VVuO1Y(VVDpqo, title)
  else:
   widths = (20, 50, 30)
   VV8lmg = None
   VVUpMt = None
   if mode == 0:
    VVdvf0 = ("Install" , self.VVhb3s   , [])
    VV8lmg = ("Download" , self.VVE0P6   , [])
    VVUpMt = ("Filter"  , self.VVtp2P , [])
   elif mode == 1:
    VVdvf0 = ("Uninstall", self.VVZXVa, [])
   elif mode == 2:
    VVdvf0 = ("Uninstall", self.VVZXVa, [])
    widths= (18, 57, 25)
   VVDpqo.sort(key=lambda x: x[0].lower())
   VV0RwZ = ("Package Info.", self.VV8gsf, [])
   header   = ("Name" ,"Package" , "Version" )
   FFW2Tv(self, None, header=header, VVDpqo=VVDpqo, VVQT0l=widths, VVsgYf=28, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVSboA=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVrEme="#22110011", VVRBt6="#22191111", VVfKIv="#22191111", VV6z2K="#00003030", VV7JIr="#00333333")
 def VV8gsf(self, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVqTZ7, VVSuUg, colList[1]))
 def VVqTZ7(self, VVSuUg, pkg):
  if pathExists(pkg):
   pkg, err = CC5jmY.VVTUyZ(pkg)
   if err:
    FFVyvQ(VVSuUg, err, 1000)
    return
  CC5jmY.VVC4i6(self, pkg)
 def VVtp2P(self, VVSuUg, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVZ4NM = []
  VVZ4NM.append(("All Packages", "all"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVZ4NM.append(VVVvw4)
  for word in words:
   VVZ4NM.append((word, word))
  FFLMiy(self, BF(self.VVHuBo, VVSuUg), VVZ4NM=VVZ4NM, title="Select Filter")
 def VVHuBo(self, VVSuUg, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF1QiT(VVSuUg, BF(self.VV3yBG, 0, grep, VVSuUg, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVZXVa(self, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVzDkh, VVSuUg, colList[1]))
 def VVzDkh(self, VVSuUg, package):
  if pathExists(package):
   pkg, err = CC5jmY.VVTUyZ(package)
   if pkg:
    package = pkg
  if package.startswith((VV0xPn, VVydp3)):
   FF4s3j(self, BF(self.VVN7qc, VVSuUg, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVZ4NM = []
   VVZ4NM.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVZ4NM.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVZ4NM.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFLMiy(self, BF(self.VVvo4P, VVSuUg, package), VVZ4NM=VVZ4NM)
 def VVN7qc(self, VVSuUg, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VViDgN)
  FFxjL4(self, cmd, VVgmlB=BF(self.VVNChi, VVSuUg))
 def VVvo4P(self, VVSuUg, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVhXK7
   elif item == "remove_ForceRemove"  : cmdOpt = VVZceH
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV0gcx
   FF4s3j(self, BF(self.VVPJvS, VVSuUg, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVPJvS(self, VVSuUg, package, cmdOpt):
  self.lastSelectedRow = VVSuUg.VVZ2t7()
  cmd = FF2pmn(cmdOpt, package)
  if cmd : FFxjL4(self, cmd, VVgmlB=BF(self.VVNChi, VVSuUg))
  else : FFPXac(self)
 def VVNChi(self, VVSuUg):
  VVSuUg.cancel()
  FFZ1wQ()
 def VVhb3s(self, VVSuUg, title, txt, colList):
  package  = colList[1]
  VVZ4NM = []
  VVZ4NM.append(("Install Package"        , "install_CheckVersion" ))
  VVZ4NM.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVZ4NM.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVZ4NM.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVZ4NM.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFLMiy(self, BF(self.VVFyor, package), VVZ4NM=VVZ4NM)
 def VVFyor(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVLJqS
   elif item == "install_ForceReinstall" : cmdOpt = VV5fye
   elif item == "install_ForceOverwrite" : cmdOpt = VVYeKx
   elif item == "install_ForceDowngrade" : cmdOpt = VVcuwj
   elif item == "install_IgnoreDepends" : cmdOpt = VVhGyM
   FF4s3j(self, BF(self.VV5j0c, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV5j0c(self, package, cmdOpt):
  cmd = FF2pmn(cmdOpt, package)
  if cmd : FFxjL4(self, cmd, VVgmlB=FFZ1wQ, checkNetAccess=True)
  else : FFPXac(self)
 def VVE0P6(self, VVSuUg, title, txt, colList):
  package  = colList[1]
  FF4s3j(self, BF(self.VVu9Ho, package), "Download Package ?\n\n%s" % package)
 def VVu9Ho(self, package):
  if CCoB4g.VVKCNt():
   cmd = FF2pmn(VVTCqL, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFVW8g(success, VVhmJa))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFVW8g(fail, VVEWKM))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFxjL4(self, cmd, VVa1fh=[VVEWKM, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFPXac(self)
  else:
   FF0eUf(self, "No internet connection !")
 @staticmethod
 def VVyBGu(SELF):
  cmd = FF8xxa(VV1LmT, "")
  if cmd : FFxjL4(SELF, cmd, checkNetAccess=True)
  else : FFPXac(SELF)
 @staticmethod
 def VVTUyZ(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFtLFA(FF2pmn(VVS7Xr, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVC4i6(SELF, package, title=""):
  title = title or package
  infoCmd  = FF2pmn(VVsD89, package)
  filesCmd = FF2pmn(VVEQtj, package)
  listInstCmd = FF8xxa(VVWjcv, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFsa3j(VVde5r)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFVW8g(notInst, VVqDXM))
   cmd += "else "
   cmd +=   FF437T("System Info", VVde5r)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF437T("Related Files", VVde5r)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFA10e(SELF, cmd, title=title)
  else:
   FFPXac(SELF, title=title)
class CC4MwO():
 def VVZVXV(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVz28E()
 def VVz28E(self):
  files = FFFDtI(VVbRSD, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVZ4NM = []
   for fil in files:
    VVZ4NM.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVrEme, VVRBt6 = "#22221133", "#22221133"
   else    : VVrEme, VVRBt6 = "#22003344", "#22002233"
   VVWjWA  = ("Add new File", self.VVMGCq)
   FFLMiy(self, self.VVsQuQ, VVZ4NM=VVZ4NM, width=1100, VVWjWA=VVWjWA, VVpQam="", minRows=4, VVrEme=VVrEme, VVRBt6=VVRBt6)
  else:
   FF4s3j(self, self.VVXmbE, "No files found.\n\nCreate a new file ?")
 def VVXmbE(self):
  path = self.VV9Zqy()
  if fileExists(path) : self.VVz28E()
  else    : FF7BjW(self, "Cannot create file", 1500)
 def VVMGCq(self, VVKicw, path):
  path = self.VV9Zqy()
  VVKicw.VVRR5n((os.path.basename(path), path), isSort=True)
 def VV9Zqy(self):
  path = "%s%s%s.xml" % (VVbRSD, self.shareFilePrefix, FFXJI8())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVsQuQ(self, path=None):
  if path:
   FF1QiT(self, BF(self.VVDbbA, path))
 def VVDbbA(self, path):
  if not fileExists(path):
   FF7Hmv(self, path)
   return
  elif not CCNmp1.VV1wzQ(self, path, FFFBSc()):
   return
  else:
   self.shareFilePath = path
  if not CCAwAg.VVswc9(self):
   return
  tree = CCtCGd.VVxYpq(self, self.shareFilePath)
  if not tree:
   return
  refLst = CC8DHP.VVP5t5()
  def VVOb1w(refCode):
   if   FF5gv6(refCode): return FFNr4J("DVB", VVI2ZY)
   elif refCode in refLst     : return FFNr4J("IPTV", VVI2ZY)
   else         : return ""
  VVJIKO= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVrWNN(ch)
   if ok:
    srcTxt = VVOb1w(srcRef)
    dstTxt = VVOb1w(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVJIKO:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVJIKO.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVJIKO:
   if self.shareIsRef : VVrEme, VVRBt6, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVrEme, VVRBt6, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVHEpO = (""    , BF(self.VVKURI, dupl), [])
   VVU95Y = (""    , self.VVhTjJ    , [])
   VVdvf0 = ("Delete Entry" , self.VVDch7   , [])
   VV8lmg = ("Add Entry"  , self.VVB8lE   , [])
   VV0RwZ = (optTxt   , self.VVkp1i  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVXdZ9 = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVSuUg = FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=24, VVHEpO=VVHEpO, VVU95Y=VVU95Y, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVROQm=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVRBt6, VV6z2K="#0a000000")
  else:
   FF0eUf(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVKURI(self, dupl, VVSuUg, title, txt, colList):
  if dupl:
   VVSuUg.VVDnVh("Skipped %d duplicate%s" % (dupl, FF1OOs(dupl)), 2000)
 def VVhTjJ(self, VVSuUg, title, txt, colList):
  def VVOb1w(key, val): return "%s\t: %s\n" % (key, val or FFNr4J("?", VVIZs4))
  Keys = VVSuUg.VVXmTk()
  Vals = VVSuUg.VVU4OP()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVOb1w(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVhmJa, VVIZs4
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFXEvX(self, txt + txt1, title=title)
 def VVrWNN(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVDch7(self, VVSuUg, title, txt, colList):
  if VVSuUg.VVZ2t7() == 0 and VVSuUg.VVmUCw() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FF4s3j(self, BF(self.VVdLZ2, isLast, VVSuUg), ques)
 def VVdLZ2(self, isLast, VVSuUg):
  if isLast:
   FFfhv3(self.shareFilePath)
   VVSuUg.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVSuUg.VVU4OP()
   if self.VVU9GU(srcName, srcRef, dstName, dstRef):
    VVSuUg.VVeH2a()
    VVSuUg.VV8yZR()
    FF7BjW(VVSuUg, "Deleted", 500, isGrn=True)
   else:
    FF7BjW(VVSuUg, "Cannot delete from file", 2000)
 def VVB8lE(self, VVSuUg, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVOsd3(VVSuUg, isDvb=True)
  else    : self.VVsjFe(VVSuUg, "Source Channel", "#22003344", "#22002233")
 def VVsjFe(self, mainTableInst, title, VVrEme, VVRBt6):
  FFLMiy(self, BF(self.VVeWo1, mainTableInst, title), VVZ4NM=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVrEme=VVrEme, VVRBt6=VVRBt6)
 def VVeWo1(self, mainTableInst, title, item=None):
  if item:
   FF1QiT(mainTableInst, BF(self.VVg2Wf, mainTableInst, title, item), clearMsg=False)
 def VVg2Wf(self, mainTableInst, title, item):
  FF7BjW(mainTableInst)
  if item == "DVB": self.VVOsd3(mainTableInst, isDvb=True)
  else   : self.VVOsd3(mainTableInst, isDvb=False)
 def VV80OR(self, mainTableInst, chType, VVSuUg, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVSuUg.VVZ2t7()
  if   chType == "DVB" : FFE6Br(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFE6Br(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVOxLE()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FF0eUf(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV1OLS(srcName, srcRef, dstName, dstRef):
      mainTableInst.VV9lFe((str(mainTableInst.VVmUCw() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FF7BjW(mainTableInst, "Added", 500, isGrn=True)
     else:
      FF7BjW(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FF7BjW(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVOsd3(mainTableInst, isDvb=False)
   else    : FFdw1m(BF(self.VVsjFe, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVSuUg.cancel()
 def VVpgJq(self, item, VVSuUg, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVSuUg.VVpxIX(ndx)
 def VVOsd3(self, VVSuUg, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VV80OR, VVSuUg, typ)
  doneFnc = BF(self.VVpgJq, typ)
  if isDvb: CC4MwO.VVXVyy(VVSuUg , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CC4MwO.VVz71F(VVSuUg, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVXVyy(SELF, title, okFnc, doneFnc=None):
  FF1QiT(SELF, BF(CC4MwO.VVbe3n, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVbe3n(SELF, title, okFnc, doneFnc=None):
  VVJIKO, err = CCtCGd.VVUq9T(SELF, CCtCGd.VVw2fb)
  if VVJIKO:
   color = "#0a000022"
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVFJkn = ("Select" , okFnc, [])
   VVHEpO= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVXdZ9 = (LEFT  , LEFT  , CENTER, LEFT    )
   FFW2Tv(SELF, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVrEme=color, VVRBt6=color, VVfKIv=color, VVFJkn=VVFJkn, VVHEpO=VVHEpO, lastFindConfigObj=CFG.lastFindServices)
  else:
   FF0eUf(SELF, "No DVB Services !")
 @staticmethod
 def VVz71F(SELF, title, okFnc, doneFnc=None):
  FF1QiT(SELF, BF(CC4MwO.VVawpv, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVawpv(SELF, title, okFnc, doneFnc=None):
  VVJIKO = CC4MwO.VVIu94()
  if VVJIKO:
   color = "#0a112211"
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVFJkn = ("Select" , okFnc, [])
   VVHEpO= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFW2Tv(SELF, None, title=title, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=26, VVrEme=color, VVRBt6=color, VVfKIv=color, VVFJkn=VVFJkn, VVHEpO=VVHEpO, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF0eUf(SELF, "No IPTV Services !")
 @staticmethod
 def VVIu94():
  VVJIKO = []
  files  = CCXyjP.VVpx1z()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFBRKz(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVkhQ1 = span.group(1)
    else : VVkhQ1 = ""
    VVkhQ1_lCase = VVkhQ1.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVJIKO.append((chName, VVkhQ1, url, refCode))
  return VVJIKO
 def VV1OLS(self, srcName, srcRef, dstName, dstRef):
  tree = CCtCGd.VVxYpq(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVac82(tree, root)
  return True
 def VVU9GU(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCtCGd.VVxYpq(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVrWNN(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVac82(tree, root)
  return found
 def VVac82(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCtCGd.VVv5Nu(xmlTxt)
  parser = CCtCGd.CCWy23()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVkp1i(self, VVSuUg, title, txt, colList):
  if self.onlyEpg:
   self.VVSM3H(VVSuUg, "epg")
  else:
   if self.shareIsRef:
    FF4s3j(self, BF(FF1QiT, VVSuUg, BF(self.VVDvZu, VVSuUg)), "Copy all References from Source to Destination ?")
   else:
    VVZ4NM = []
    VVZ4NM.append(("Copy EPG\t (All List)" , "epg"  ))
    VVZ4NM.append(("Copy Picons\t (All List)" , "picon" ))
    FFLMiy(self, BF(self.VVSM3H, VVSuUg), VVZ4NM=VVZ4NM, width=1000)
 def VVSM3H(self, VVSuUg, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVp4Q4  , "EPG"
   elif item == "picon": fnc, txt = self.VV98KN , "PIcons"
   title = "Copy %s" % txt
   tot   = VVSuUg.VVmUCw()
   FF4s3j(self, BF(FF1QiT, VVSuUg, BF(fnc, VVSuUg, title)), "Overwrite %s for %d Service%s ?" % (FFNr4J(txt, VVde5r), tot, FF1OOs(tot)), title=title)
 def VVDvZu(self, VVSuUg):
  files = CCXyjP.VVpx1z()
  totChange = 0
  if files:
   for path in files:
    txt = FFBRKz(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVSuUg.VVOxLE():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFwnFB()
  tot = VVSuUg.VVmUCw()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFXEvX(self, txt)
 def VV98KN(self, VVSuUg, title):
  if not iCopyfile:
   FF0eUf(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCk0vb.VVJcyT()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVSuUg.VVOxLE():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVSuUg.VVmUCw()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFXEvX(self, txt, title=title)
 def VVp4Q4(self, VVSuUg, title):
  txt, err = CCh6kb.VVH9Ls(VVSuUg, title)
  if err : FF0eUf(self, err, title=title)
  else : FFXEvX(self, txt, title=title)
 class CCWy23(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVxYpq(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCtCGd.CCWy23())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFNr4J("XML Parse Error in:", VVIZs4), path)
   txt += "%s\n%s\n\n" % (FFNr4J("Error:", VVIZs4), str(e))
   FFXEvX(SELF, txt, VVfKIv="#11220000", title=title)
   return None
 @staticmethod
 def VVv5Nu(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCh6kb(Screen, CC4MwO):
 VVaeGy  = "BDTSE"
 VVsfGC   = "save"
 VV2jmL   = "load"
 VVFyXQ  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCh6kb.VVQUOy()
  qUrl, iptvRef = CCXyjP.VVCUER(self)
  VVZ4NM = []
  VVZ4NM.append((VVI2ZY + "Cache File Info." , "inf"))
  VVZ4NM.append(VVVvw4)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVZ4NM.append(FF1giv("Save EPG to File%s" % fTxt , self.VVsfGC, valid))
  VVZ4NM.append(FF1giv("Load EPG from File%s" % fTxt , self.VV2jmL, valid))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((VVqDXM + "Delete EPG (from RAM only)", self.VVFyXQ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(FF1giv("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVZ4NM.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Translate Current Channel EPG %s(Experimental)" % VVqDXM, "VVFyUY"))
  FF3tZI(self, VVZ4NM=VVZ4NM)
  self.onShown.append(self.VV7StE)
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVD0pV()
   elif item in (self.VVsfGC, self.VV2jmL, self.VVFyXQ):
    reset = item == self.VV2jmL
    FF4s3j(self, BF(FF1QiT, self, BF(self.VVqJGm, item, reset)), VV6LqR="Continue ?")
   elif item == "refreshIptvEPG"  : CCXyjP.VVqiED(self)
   elif item == "VVFyUY" : self.VVFyUY()
   elif item == "copyEpg"    : self.VVZVXV(False, onlyEpg=True)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VVqJGm(self, act, reset=False):
  ok = CCh6kb.VVbiCP(act)
  if ok:
   if reset:
    CCh6kb.VVX7db(self)
   FFH1Ib(self, "Done")
  else:
   FFH1Ib(self, "Failed!")
 def VVD0pV(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCh6kb.VVQUOy()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFNr4J("File not found (check System EPG settings).", VVqDXM))
   FFXEvX(self, txt, title=title)
  else:
   FF0eUf(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVD6Ye():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVFyUY(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVFJkn  = (""  , BF(self.VVMiDx, title, True) , [])
  VV8lmg = ("Start" , BF(self.VVMiDx, title, False), [])
  VVUpMt = ("Change Language", self.VVV0rg      , [])
  widths  = (70 , 30)
  VVXdZ9 = (LEFT , CENTER)
  FFW2Tv(self, None, title=title, VVDpqo=self.VVWJ6r(), VVXdZ9=VVXdZ9, VVQT0l=widths, width=1200, vMargin=20, VVsgYf=30, VVFJkn=VVFJkn, VV8lmg=VV8lmg, VVUpMt=VVUpMt, VVEIfy=2
    , VVrEme="#11201010", VVRBt6=bg, VVfKIv=bg, VV6z2K="#00004455", VV7JIr=bg)
 def VVWJ6r(self):
  Def, ch = "DISABLED", dict(CCh6kb.VVD6Ye())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVDpqo = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVDpqo
 def VVV0rg(self, VVSuUg, title, txt, colList):
  ndx = VVSuUg.VVZ2t7()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCVmVV.VV0AtB(self, confItem, title, lst=CCh6kb.VVD6Ye(), cbFnc=BF(self.VVkj0Y, VVSuUg), isSave=True)
 def VVkj0Y(self, VVSuUg):
  for ndx, row in enumerate(self.VVWJ6r()):
   VVSuUg.VVghZJ(ndx, row)
 def VVMiDx(self, Title, isAsk, VVSuUg, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FF7BjW(VVSuUg, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
   refCode, evList, err = CCh6kb.VVwlWj(refCode)
   fnc = BF(self.VVhwvq, Title, refCode, evList, VVSuUg)
   if   err : FF0eUf(self, err, title=Title)
   elif isAsk : FF4s3j(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVhwvq(self, title, refCode, evList, VVSuUg):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVOTkJ, evList)
      , VVtCUJ = BF(self.VVqkV0, title, refCode))
  VVSuUg.cancel()
 def VVOTkJ(self, evList, VVx2mk):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVx2mk.VVSJhE(totEv)
  VVx2mk.VVgnkU = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCh6kb.VVsdp5(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1)
   VVx2mk.VVC4ZF(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVx2mk.VVgnkU = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVqkV0(self, title, refCode, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVgnkU
  if newLst: totEv, totOK = CCh6kb.VVpizh(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCh6kb.VVB7El()
   CCh6kb.VVX7db(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFXEvX(self, txt, title=title)
 @staticmethod
 def VVsdp5(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVOb1w(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCh6kb.VVFfoF(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVOb1w, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVFfoF(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFVH3K(txt))
   txt, err = CCXyjP.VVmPHt(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FF6s8T(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCh6kb.VVt67Q(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVQUOy():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFPebg(path)
   szTxt = CCNmp1.VV3y2b(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVKIBl():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVB7El(): CCh6kb.VVbiCP(CCh6kb.VVsfGC)
 @staticmethod
 def VVbiCP(act):
  ec, inst = CCh6kb.VVKIBl()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVX7db(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVwlWj(refCode):
  ec, inst = CCh6kb.VVKIBl()
  if inst:
   try:
    evList = inst.lookupEvent([CCh6kb.VVaeGy, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVpizh(refCode, events, longDescDays=0):
  ec, inst = CCh6kb.VVKIBl()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVTCNl(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCh6kb.VVKIBl()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCh6kb.VVbG6z(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCUr80.CCh6kb(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVbG6z(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCh6kb.VV62Ks(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VV0L0f(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCh6kb.VVKIBl()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCh6kb.VVbG6z(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFmWOg(evTime)
       evEndTxt  = FFmWOg(evEnd)
       evDurTxt  = FFaFw5(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFaFw5(evPos)
        evRem = evEnd - now
        evRemTxt = FFaFw5(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFaFw5(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VV62Ks(event):
  genre = PR = ""
  try:
   genre  = CCh6kb.VVmohw(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCh6kb.VVuTnA(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVuTnA(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVmohw(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCh6kb.VVXOx8()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVXOx8():
  path = VVrRM9 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFBRKz(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFBRKz(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVH9Ls(VVSuUg, title):
  ec, inst = CCh6kb.VVKIBl()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVSuUg.VVOxLE():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCh6kb.VVaeGy, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCh6kb.VVpizh(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCh6kb.VVB7El()
  txt  = "Services\t: %d\n"  % VVSuUg.VVmUCw()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVblpy(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCh6kb.VVq93J(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCh6kb.VVq93J(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCh6kb.VVq93J(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVq93J(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCh6kb.VVbG6z(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCh6kb.VVsdp5(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFNr4J(evName, VVQzZA)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFNr4J(evNameTransl, VVQzZA))
    if evTime           : txt += "Start Time\t: %s\n" % FFmWOg(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFmWOg(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFaFw5(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFaFw5(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFaFw5(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFNr4J(evShort, VVh9Nn)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFNr4J(evDesc , VVh9Nn)
    if txt:
     txt = FFNr4J("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVQzZA) + txt
  return txt
 @staticmethod
 def VVt67Q(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCtCGd(Screen, CC4MwO):
 VVRBgN  = 0
 VVuZmX = 1
 VV7V9F  = 2
 VVC9L3  = 3
 VVXuY8 = 4
 VVPk5I = 5
 VVxb54 = 6
 VVw2fb   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVVDtp = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVZ4NM = self.VVGG6n()
  FF3tZI(self, VVZ4NM=VVZ4NM, title="Services/Channels")
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self["myMenu"].setList(self.VVGG6n())
  FF4VOV(self["myMenu"])
  FFxUTp(self)
 def VVGG6n(self):
  VVZ4NM = []
  c = VVI2ZY
  VVZ4NM.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVZ4NM.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVZ4NM.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVZ4NM.append(VVVvw4)
  c = VVQzZA
  VVZ4NM.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVZ4NM.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVZ4NM.append((VVIZs4 + "More tables ..."     , "VVVwrD"    ))
  c = VVh9Nn
  VVZ4NM.append(VVVvw4)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVZ4NM.append((c + txt          , "VVa6Ob"  ))
  else : VVZ4NM.append((txt           ,          ))
  VVZ4NM.append((c + 'Export Services to "channels.xml"'    , "VV5iLB"      ))
  VVZ4NM.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVljbY
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVZ4NM.append((c + "Invalid Services Cleaner"       , "VVOilE"    ))
  c = VVljbY
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c + "Delete Channels with no names"     , "VVWWmt"    ))
  VVZ4NM.append((c + "Delete Empty Bouquets"       , "VV2WaQ"     ))
  VVZ4NM.append(VVVvw4)
  VVCBDF, VVkuAN = CCtCGd.VVbblq()
  if fileExists(VVCBDF):
   enab = fileExists(VVkuAN)
   if enab: VVZ4NM.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVZ4NM.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVZ4NM.append(("Reset Parental Control Settings"      , "VV0Et6"    ))
  VVZ4NM.append(("Reload Channels and Bouquets"       , "VVvpI4"      ))
  return VVZ4NM
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCXYrc.VVRGWe(self.session)
   elif item == "openSignal"       : FFtWxv(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFGNa7(self, fncMode=CCUr80.VV26qy)
   elif item == "lameDB_allChannels_with_refCode"  : FF1QiT(self, self.VVUZHb)
   elif item == "lameDB_allChannels_with_tranaponder" : FF1QiT(self, self.VV5eF7)
   elif item == "VVVwrD"     : self.VVVwrD()
   elif item == "VVa6Ob"  : CCWYnG.VVa6Ob(self)
   elif item == "VV5iLB"      : self.VV5iLB()
   elif item == "copyEpgPicons"      : self.VVZVXV(False)
   elif item == "SatellitesCleaner"     : FF1QiT(self, self.FF1QiT_SatellitesCleaner)
   elif item == "VVOilE"    : FF1QiT(self, BF(self.VVOilE))
   elif item == "VVWWmt"    : FF1QiT(self, self.VVWWmt)
   elif item == "VV2WaQ"     : self.VV2WaQ(self)
   elif item == "enableHiddenChannels"     : self.VVOchD(True)
   elif item == "disableHiddenChannels"    : self.VVOchD(False)
   elif item == "VV0Et6"    : FF4s3j(self, self.VV0Et6, "Reset and Restart ?")
   elif item == "VVvpI4"      : FF1QiT(self, BF(CCtCGd.VVvpI4, self))
 def VVVwrD(self):
  VVZ4NM = []
  VVZ4NM.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVZ4NM.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVZ4NM.append(("Services with PIcons for the System"  , "VVWbMc"    ))
  VVZ4NM.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVZ4NM.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFLMiy(self, self.VVKFMT, VVZ4NM=VVZ4NM, title="Service Information", VV9pbf=True)
 def VVKFMT(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF1QiT(self, BF(self.VV639A, title))
   elif ref == "parentalControlChannels"   : FF1QiT(self, BF(self.VVrOUA, title))
   elif ref == "showHiddenChannels"    : FF1QiT(self, BF(self.VV6TPK, title))
   elif ref == "VVWbMc"    : FF1QiT(self, BF(self.VVAFwo, title))
   elif ref == "servicesWithMissingPIcons"   : FF1QiT(self, BF(self.VVSEg8, title))
   elif ref == "TranspondersStats"     : FF1QiT(self, BF(self.VVQFL0, title))
   elif ref == "SatellitesXmlStats"    : FF1QiT(self, BF(self.VVsbwT, title))
 def VV5iLB(self):
  VVZ4NM = []
  VVZ4NM.append(("All DVB-S/C/T Services", "all"))
  VVZ4NM.extend(CC8DHP.VVk6Tg())
  FFLMiy(self, self.VVeOXU, VVZ4NM=VVZ4NM, title="", VV9pbf=True)
 def VVeOXU(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCtCGd.VVb4PL("1:7:")
   else   : lst = FFNTAQ(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFAVEM(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FF98yX(r)  : sat = "Stream Relay"
       elif FFBV7X(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFSiyE(CFG.exportedTablesPath.getValue()), FFXJI8())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFH1Ib(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FF7BjW(self, "No Services found !", 1500)
 @staticmethod
 def VVvpI4(SELF):
  FFwnFB()
  FFH1Ib(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVUZHb(self):
  self.VVVDtp = None
  self.lastfilterUsed  = None
  self.filterObj   = CCC0Pu(self)
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VVRBgN)
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVFJkn  = ("Zap"   , self.VVXYKj     , [])
   VVU95Y = (""    , self.VVwSot   , [])
   VV0RwZ = ("Options"  , self.VVuiNk , [])
   VV8lmg = ("Current Service", self.VVmvZj , [])
   VVUpMt = ("Filter"   , self.VVMpew  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVXdZ9  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindServices)
 def VV5eF7(self):
  self.VVVDtp = None
  self.lastfilterUsed  = None
  self.filterObj   = CCC0Pu(self)
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VVuZmX)
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVFJkn  = ("Zap"   , self.VVXYKj      , [])
   VVU95Y = (""    , self.VVwSot    , [])
   VV8lmg = ("Current Service", self.VVmvZj  , [])
   VV0RwZ = ("Options"  , self.VV1BL4 , [])
   VVUpMt = ("Filter"   , self.VVakrc  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVXdZ9  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindServices)
 def VVuiNk(self, VVSuUg, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCIjyQ(self, VVSuUg)
  VVZ4NM = []
  isMulti = VVSuUg.VVJZs5
  if isMulti:
   refCodeList = VVSuUg.VVzBF6(3)
   if refCodeList:
    VVZ4NM.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVZ4NM.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVZ4NM.append(VVVvw4)
    VVZ4NM.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVZ4NM.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVZ4NM.append(VVVvw4)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVZ4NM.append((txt1, "parentalControl_add" ))
    VVZ4NM.append((txt2,        ))
   else:
    VVZ4NM.append((txt1,       ))
    VVZ4NM.append((txt2, "parentalControl_remove" ))
   VVZ4NM.append(VVVvw4)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVZ4NM.append((txt1, "hiddenServices_add"  ))
    VVZ4NM.append((txt2,       ))
   else:
    VVZ4NM.append((txt1,        ))
    VVZ4NM.append((txt2, "hiddenServices_remove" ))
   VVZ4NM.append(VVVvw4)
  cbFncDict = { "parentalControl_add"   : BF(self.VVCud2, VVSuUg, refCode, True)
     , "parentalControl_remove"  : BF(self.VVCud2, VVSuUg, refCode, False)
     , "hiddenServices_add"   : BF(self.VVMtd0, VVSuUg, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVMtd0, VVSuUg, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVBSZX, VVSuUg, True)
     , "parentalControl_sel_remove" : BF(self.VVBSZX, VVSuUg, False)
     , "hiddenServices_sel_add"  : BF(self.VVrn5n, VVSuUg, True)
     , "hiddenServices_sel_remove" : BF(self.VVrn5n, VVSuUg, False)
     }
  VVZ4NM1, cbFncDict1 = CCtCGd.VVthzb(self, VVSuUg, servName, 3)
  VVZ4NM.extend(VVZ4NM1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 def VV1BL4(self, VVSuUg, title, txt, colList):
  servName = colList[0]
  mSel = CCIjyQ(self, VVSuUg)
  VVZ4NM, cbFncDict = CCtCGd.VVthzb(self, VVSuUg, servName, 3)
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 @staticmethod
 def VVthzb(SELF, VVSuUg, servName, refCodeCol):
  tot = VVSuUg.VVv1D2()
  if tot > 0:
   sTxt = FFNr4J("%d Service%s" % (tot, FF1OOs(tot)), VVQzZA)
   VVZ4NM = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFhc8v(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFNr4J(servName, VVQzZA)
   VVZ4NM = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCtCGd.VVukJb, SELF, VVSuUg, refCodeCol, True)
     , "addToBouquet_one" : BF(CCtCGd.VVukJb, SELF, VVSuUg, refCodeCol, False)
     }
  return VVZ4NM, cbFncDict
 @staticmethod
 def VVukJb(SELF, VVSuUg, refCodeCol, isMulti):
  picker = CC8DHP(SELF, VVSuUg, "Add to Bouquet", BF(CCtCGd.VVEfmv, VVSuUg, refCodeCol, isMulti))
 @staticmethod
 def VVEfmv(VVSuUg, refCodeCol, isMulti):
  if isMulti : refCodeList = VVSuUg.VVzBF6(refCodeCol)
  else  : refCodeList = [VVSuUg.VVU4OP()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVCud2(self, VVSuUg, refCode, isAddToBlackList):
  VVSuUg.VVXBxd("Processing ...")
  FFdw1m(BF(self.VVABPb, VVSuUg, [refCode], isAddToBlackList))
 def VVBSZX(self, VVSuUg, isAddToBlackList):
  refCodeList = VVSuUg.VVzBF6(3)
  if not refCodeList:
   FF0eUf(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVSuUg.VVXBxd("Processing ...")
  FFdw1m(BF(self.VVABPb, VVSuUg, refCodeList, isAddToBlackList))
 def VVABPb(self, VVSuUg, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVboSE, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVboSE):
   lines = FFMA9m(VVboSE)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVboSE, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVSuUg.VVJZs5
   if isMulti:
    self.VVe8zB(VVSuUg, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV0Dnf(VVSuUg, refCode)
    VVSuUg.VVTVqz()
  else:
   VVSuUg.VVDnVh("No changes")
 def VVMtd0(self, VVSuUg, refCode, isHide):
  title = "Change Hidden State"
  if FF5gv6(refCode):
   VVSuUg.VVXBxd("Processing ...")
   ret = FFckWq(refCode, isHide)
   if ret : FF1QiT(self, BF(self.VV0Dnf, VVSuUg, refCode))
   else : FF0eUf(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF0eUf(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV0Dnf(self, VVSuUg, refCode):
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VVRBgN, VV5yE7=[3, [refCode], False])
  done = False
  if VVJIKO:
   data = VVJIKO[0]
   if data[3] == refCode:
    done = VVSuUg.VVgAJR(data)
  if not done:
   self.VVuTgu(VVSuUg, VVSuUg.VVdoWv(), self.VVRBgN)
  VVSuUg.VVTVqz()
 def VVe8zB(self, VVSuUg, totRefCodes):
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VVRBgN, VV5yE7=self.VVVDtp)
  VVSuUg.VVuO1Y(VVJIKO)
  VVSuUg.VVcNsR(False)
  VVSuUg.VVDnVh("%d Processed" % totRefCodes)
 def VVrn5n(self, VVSuUg, isHide):
  refCodeList = VVSuUg.VVzBF6(3)
  if not refCodeList:
   FF0eUf(self, "Nothing selected", title="Change Hidden State")
   return
  VVSuUg.VVXBxd("Processing ...")
  FFdw1m(BF(self.VVKVsb, VVSuUg, refCodeList, isHide))
 def VVKVsb(self, VVSuUg, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFckWq(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFwnFB(True)
   self.VVe8zB(VVSuUg, len(refCodeList))
  else:
   VVSuUg.VVDnVh("No changes")
 def VVMpew(self, VVSuUg, title, txt, colList):
  inFilterFnc = BF(self.VVCFjZ, VVSuUg) if self.VVVDtp else None
  self.filterObj.VVdN1H(1, VVSuUg, 2, BF(self.VVc4kR, VVSuUg), inFilterFnc=inFilterFnc)
 def VVc4kR(self, VVSuUg, item):
  self.VVudeK(VVSuUg, False, item, 2, self.VVRBgN)
 def VVCFjZ(self, VVSuUg, VVKicw, item):
  self.VVudeK(VVSuUg, True, item, 2, self.VVRBgN)
 def VVakrc(self, VVSuUg, title, txt, colList):
  inFilterFnc = BF(self.VVfcxy, VVSuUg) if self.VVVDtp else None
  self.filterObj.VVdN1H(2, VVSuUg, 4, BF(self.VVxsk9, VVSuUg), inFilterFnc=inFilterFnc)
 def VVxsk9(self, VVSuUg, item):
  self.VVudeK(VVSuUg, False, item, 4, self.VVuZmX)
 def VVfcxy(self, VVSuUg, VVKicw, item):
  self.VVudeK(VVSuUg, True, item, 4, self.VVuZmX)
 def VV3AgL(self, VVSuUg, title, txt, colList):
  inFilterFnc = BF(self.VVcLPJ, VVSuUg) if self.VVVDtp else None
  self.filterObj.VVdN1H(0, VVSuUg, 4, BF(self.VVdXWB, VVSuUg), inFilterFnc=inFilterFnc)
 def VVdXWB(self, VVSuUg, item):
  self.VVudeK(VVSuUg, False, item, 4, self.VV7V9F)
 def VVcLPJ(self, VVSuUg, VVKicw, item):
  self.VVudeK(VVSuUg, True, item, 4, self.VV7V9F)
 def VVudeK(self, VVSuUg, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVSuUg.VVbc1J(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVVDtp = None
  else:
   words, asPrefix = CCC0Pu.VVUzJV(words)
   self.VVVDtp = [col, words, asPrefix]
  if words: FF1QiT(VVSuUg, BF(self.VVuTgu, VVSuUg, title, mode), clearMsg=False)
  else : FF7BjW(VVSuUg, "Incorrect filter", 2000)
 def VVuTgu(self, VVSuUg, title, mode):
  VVJIKO, err = CCtCGd.VVUq9T(self, mode, VV5yE7=self.VVVDtp, VVPsD9=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVSuUg.VVOxLE():
    try:
     ndx = VVJIKO.index(tuple(list(map(str.strip, row))))
     lst.append(VVJIKO[ndx])
    except:
     pass
   VVJIKO = lst
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVSuUg.VVuO1Y(VVJIKO, title, VV8SPjMsg=True)
  else:
   FF7BjW(VVSuUg, "Not found!", 1500)
 def VVADiR(self, title, VVDpqo, VVFJkn=None, VVU95Y=None, VVdvf0=None, VV8lmg=None, VV0RwZ=None, VVUpMt=None):
  VV8lmg = ("Current Service", self.VVmvZj, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVXdZ9 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFW2Tv(self, None, title=title, header=header, VVDpqo=VVDpqo, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindServices)
 def VVmvZj(self, VVSuUg, title, txt, colList):
  self.VVMmvt(VVSuUg)
 def VVGk7O(self, VVSuUg, title, txt, colList):
  self.VVMmvt(VVSuUg, True)
 def VVMmvt(self, VVSuUg, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVSuUg.VVeEhA(colDict, VVR9V4=True)
   else:
    VVSuUg.VVJnOe(3, refCode, True)
   return
  FF0eUf(self, "Cannot read current Reference Code !")
 def VV639A(self, title):
  self.VVVDtp = None
  self.lastfilterUsed  = None
  self.filterObj   = CCC0Pu(self)
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VV7V9F)
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVU95Y = (""    , self.VVwyz8 , []      )
   VV8lmg = ("Current Service", self.VVGk7O  , []      )
   VVUpMt = ("Filter"   , self.VV3AgL   , [], "Loading Filters ..." )
   VVFJkn  = ("Zap"   , self.VVes9l      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVXdZ9  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV8lmg=VV8lmg, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindServices)
 def VVwyz8(self, VVSuUg, title, txt, colList):
  refCode  = self.VVkSc6(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFGNa7(self, fncMode=CCUr80.VVLztP, refCode=refCode, chName=chName, text=txt)
 def VVes9l(self, VVSuUg, title, txt, colList):
  refCode = self.VVkSc6(colList)
  FFzGKI(self, refCode)
 def VVXYKj(self, VVSuUg, title, txt, colList):
  FFzGKI(self, colList[3])
 def VVkSc6(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVMeRF(VVCBDF, mode=0):
  lines = FFMA9m(VVCBDF, encLst=["UTF-8"])
  return CCtCGd.VVGHky(lines, mode)
 @staticmethod
 def VVGHky(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVUq9T(SELF, mode, VV5yE7=None, VVPsD9=True, VV8wkm=True):
  VVCBDF, err = CCtCGd.VVzI2O(SELF, VV8wkm)
  if err:
   return None, err
  asPrefix = False
  if VV5yE7:
   filterCol = VV5yE7[0]
   filterWords = VV5yE7[1]
   asPrefix = VV5yE7[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCtCGd.VVRBgN:
   blackList = None
   if fileExists(VVboSE):
    blackList = FFMA9m(VVboSE)
    if blackList:
     blackList = set(blackList)
  elif mode == CCtCGd.VVuZmX:
   tp = CCwj2W()
  VVlwSV, VVaaQZ = FFlozs()
  if mode in (CCtCGd.VVPk5I, CCtCGd.VVxb54):
   VVJIKO = {}
  else:
   VVJIKO = []
  tagFound = False
  with ioOpen(VVCBDF, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FF8TFY(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCtCGd.VV7V9F:
       if sTypeInt in VVlwSV:
        STYPE = VVaaQZ[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVJIKO.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVJIKO.append(tRow)
       else:
        VVJIKO.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCtCGd.VVw2fb:
        VVJIKO.append((chName, chProv, sat, refCode))
       elif mode == CCtCGd.VVPk5I:
        VVJIKO[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCtCGd.VVxb54:
        VVJIKO[chName] = refCode
       elif mode == CCtCGd.VVRBgN:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJIKO.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJIKO.append(tRow)
        else:
         VVJIKO.append(tRow)
       elif mode == CCtCGd.VVuZmX:
        if sTypeInt in VVlwSV:
         STYPE = VVaaQZ[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVJ5hP(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJIKO.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJIKO.append(tRow)
        else:
         VVJIKO.append(tRow)
       elif mode == CCtCGd.VVC9L3:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVJIKO.append((chName, chProv, sat, refCode))
       elif mode == CCtCGd.VVXuY8:
        VVJIKO.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVJIKO and VVPsD9:
   FF0eUf(SELF, "No services found!")
  return VVJIKO, ""
 def VVrOUA(self, title):
  if fileExists(VVboSE):
   lines = FFMA9m(VVboSE)
   if lines:
    newRows = []
    VVJIKO, err = CCtCGd.VVUq9T(self, self.VVXuY8)
    if VVJIKO:
     lines = set(lines)
     for item in VVJIKO:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVJIKO = newRows
      VVJIKO.sort(key=lambda x: x[0].lower())
      VVU95Y = ("", self.VVwSot, [])
      VVFJkn = ("Zap", self.VVXYKj, [])
      self.VVADiR(title, VVJIKO, VVFJkn=VVFJkn, VVU95Y=VVU95Y)
     else:
      FFXEvX(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVJIKO)))
   else:
    FFH1Ib(self, "No active Parental Control services.", FFFBSc())
  else:
   FF7Hmv(self, VVboSE)
 def VV6TPK(self, title):
  VVJIKO, err = CCtCGd.VVUq9T(self, self.VVC9L3)
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVU95Y = ("" , self.VVwSot, [])
   VVFJkn  = ("Zap", self.VVXYKj, [])
   self.VVADiR(title, VVJIKO, VVFJkn=VVFJkn, VVU95Y=VVU95Y)
  elif err:
   pass
  else:
   FFH1Ib(self, "No hidden services.", FFFBSc())
 def VVOilE(self):
  title = "Services unused in Tuner Configuration"
  VVCBDF, err = CCtCGd.VVzI2O(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCtCGd.VVHZ5U()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVkeI0(str(item[0]))
    nsLst.add(ns)
  sysLst = CCtCGd.VVb4PL("1:7:")
  tpLst  = CCtCGd.VVMeRF(VVCBDF, mode=1)
  VVJIKO = []
  for refCode, chName in sysLst:
   servID = CCtCGd.VVg3Dt(refCode)
   tpID = CCtCGd.VVpp11(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVJIKO.append((chName, FFAVEM(refCode, False), refCode, servID))
  if VVJIKO:
   VVJIKO.sort(key=lambda x: x[0].lower())
   VV0RwZ = ("Options"   , BF(self.VVEfaD, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVXdZ9  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VV0RwZ=VV0RwZ, VVrEme="#0a001122", VVRBt6="#0a001122", VVfKIv="#0a001122", VV6z2K="#00004455", VV7JIr="#0a333333", VVpBpY="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFH1Ib(self, "No invalid service found !", title=title)
 def VVEfaD(self, Title, VVSuUg, title, txt, colList):
  mSel = CCIjyQ(self, VVSuUg)
  isMulti = VVSuUg.VVJZs5
  if isMulti : txt = "Remove %s Services" % FFNr4J(str(VVSuUg.VVv1D2()), VVIZs4)
  else  : txt = "Remove : %s" % FFNr4J(VVSuUg.VVU4OP()[0], VVIZs4)
  VVZ4NM = [(txt, "del")]
  cbFncDict = {"del": BF(FF1QiT, VVSuUg, BF(self.VVjY50, VVSuUg, Title))}
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 def VVjY50(self, VVSuUg, title):
  VVCBDF, err = CCtCGd.VVzI2O(self, title=title)
  if err:
   return
  isMulti = VVSuUg.VVJZs5
  skipLst = []
  if isMulti : skipLst = VVSuUg.VVzBF6(3)
  else  : skipLst = [VVSuUg.VVU4OP()[3]]
  tpLst = CCtCGd.VVMeRF(VVCBDF, mode=0)
  servLst = CCtCGd.VVMeRF(VVCBDF, mode=10)
  tmpDbFile = VVCBDF + ".tmp"
  lines   = FFMA9m(VVCBDF)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFKiof("mv -f '%s' '%s'" % (tmpDbFile, VVCBDF))
  VVJIKO = []
  for row in VVSuUg.VVOxLE():
   if not row[3] in skipLst:
    VVJIKO.append(row)
  FFwnFB()
  FFXEvX(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVJIKO:
   VVSuUg.VVuO1Y(VVJIKO, title)
   VVSuUg.VVcNsR(False)
  else:
   VVSuUg.cancel()
 def VVQFL0(self, title):
  VVCBDF, err = CCtCGd.VVzI2O(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV29Jd(VVCBDF)
  txt = FFNr4J("Total Transponders:\n\n", VVi9VJ)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFNr4J("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVi9VJ)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFH5tp(item), satList.count(item))
  FFXEvX(self, txt, title)
 def VV29Jd(self, VVCBDF):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVCBDF, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVsbwT(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FF7Hmv(self, path, title=title)
   return
  elif not CCNmp1.VV1wzQ(self, path, title):
   return
  if not CCAwAg.VVswc9(self):
   return
  tree = CCtCGd.VVxYpq(self, path, title=title)
  if not tree:
   return
  VVJIKO = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FF8TFY(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVJIKO.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVJIKO:
   VVJIKO.sort(key=lambda x: int(x[1]))
   VV8lmg = ("Current Satellite", BF(self.VV33nQ, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVXdZ9  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=25, VVOPrI=1, VV8lmg=VV8lmg, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF0eUf(self, "No data found !", title=title)
 def VV33nQ(self, satCol, VVSuUg, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  sat = FFAVEM(refCode, False)
  for ndx, row in enumerate(VVSuUg.VVOxLE()):
   if sat == row[satCol].strip():
    VVSuUg.VVpxIX(ndx)
    break
  else:
   FF7BjW(VVSuUg, "No listed !", 1500)
 def FF1QiT_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FF0eUf(self, "No Satellites found !")
   return
  usedSats = CCtCGd.VVHZ5U()
  VVJIKO = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVJIKO.append((sat[1], posTxt, FF8TFY(sat[0]), tuners, str(posVal)))
  if VVJIKO:
   VVfKIv = "#11222222"
   VVJIKO.sort(key=lambda x: int(x[1]))
   VV8lmg = ("Current Satellite" , BF(self.VV33nQ, 2) , [])
   VV0RwZ = ("Options"   , self.VVRK2H  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVXdZ9  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVrEme=VVfKIv, VVRBt6=VVfKIv, VVfKIv=VVfKIv, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF0eUf(self, "No data found !")
 def VVRK2H(self, VVSuUg, title, txt, colList):
  mSel = CCIjyQ(self, VVSuUg)
  isMulti = VVSuUg.VVJZs5
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFNr4J(str(VVSuUg.VVv1D2()), VVIZs4)
  else  : txt = "Remove ALL Services on : %s" % FFNr4J(VVSuUg.VVU4OP()[0], VVIZs4)
  VVZ4NM = []
  VVZ4NM.append((txt, "deleteSat"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Delete Empty Bouquets", "VV2WaQ"))
  cbFncDict = { "deleteSat"   : BF(FF1QiT, VVSuUg, BF(self.VVOh1v, VVSuUg))
     , "VV2WaQ" : BF(self.VV2WaQ, VVSuUg)
     }
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 def VVOh1v(self, VVSuUg):
  posLst = []
  isMulti = VVSuUg.VVJZs5
  posLst = []
  if isMulti : posLst = VVSuUg.VVzBF6(4)
  else  : posLst = [VVSuUg.VVU4OP()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVkeI0(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVY1zH(nsLst)
  FFwnFB(True)
  FFXEvX(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VV2WaQ(self, winObj):
  title = "Delete Empty Bouquets"
  FF4s3j(self, BF(FF1QiT, winObj, BF(self.VVbg1e, title)), "Delete bouquets with no services ?", title=title)
 def VVbg1e(self, title):
  bList = CC8DHP.VVQWdi()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CC8DHP.VVJa7M(bRef)
    bPath = VVPxkP + bFile
    FFfhv3(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVPxkP + fil
     if fileExists(path):
      lines = FFMA9m(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFwnFB(True)
  if bNames: txt = "%s\n\n%s" % (FFNr4J("Deleted Bouquets:", VVQzZA), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFXEvX(self, txt, title=title)
 def VVkeI0(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVY1zH(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVPxkP)
  for srcF in files:
   if fileExists(srcF):
    lines = FFMA9m(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFkO4T(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVAFwo(self, title)   : self.VVWbMc(title, True)
 def VVSEg8(self, title) : self.VVWbMc(title, False)
 def VVWbMc(self, title, isWithPIcons):
  piconsPath = CCk0vb.VVJcyT()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCk0vb.VV3bRT(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVJIKO, err = CCtCGd.VVUq9T(self, self.VVXuY8)
    if VVJIKO:
     channels = []
     for (chName, chProv, sat, refCode) in VVJIKO:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFNsY4(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVJIKO)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVOb1w(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVOb1w("PIcons Path"  , piconsPath)
     txt += VVOb1w("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVOb1w("Total services" , totalServices)
     txt += VVOb1w("With PIcons"  , totalWithPIcons)
     txt += VVOb1w("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFXEvX(self, txt)
     else:
      VVU95Y     = (""      , self.VVwSot , [])
      if isWithPIcons : VVUpMt = ("Export Current PIcon", self.VVZmqy  , [])
      else   : VVUpMt = None
      VV0RwZ     = ("Statistics", FFXEvX, [txt])
      VVFJkn      = ("Zap", self.VVXYKj, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVADiR(title, channels, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt)
   else:
    FF0eUf(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF0eUf(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVwSot(self, VVSuUg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFGNa7(self, fncMode=CCUr80.VVLztP, refCode=refCode, chName=chName, text=txt)
 def VVZmqy(self, VVSuUg, title, txt, colList):
  png, path = CCk0vb.VVZQ0A(colList[3], colList[0])
  if path:
   CCk0vb.VVqCTE(self, png, path)
 @staticmethod
 def VVbblq():
  VVCBDF  = "%slamedb" % VVPxkP
  VVkuAN = "%slamedb.disabled" % VVPxkP
  return VVCBDF, VVkuAN
 @staticmethod
 def VVtNQv():
  VVAyJq  = "%slamedb5" % VVPxkP
  VV1jhb = "%slamedb5.disabled" % VVPxkP
  return VVAyJq, VV1jhb
 def VVOchD(self, isEnable):
  VVCBDF, VVkuAN = CCtCGd.VVbblq()
  if isEnable and not fileExists(VVkuAN):
   FFH1Ib(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVCBDF):
   FF0eUf(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF4s3j(self, BF(self.VVuP3a, isEnable), "%s Hidden Channels ?" % word)
 def VVuP3a(self, isEnable):
  VVCBDF , VVkuAN = CCtCGd.VVbblq()
  VVAyJq, VV1jhb = CCtCGd.VVtNQv()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVkuAN, VVkuAN, VVCBDF)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV1jhb, VV1jhb, VVAyJq)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVCBDF  , VVCBDF , VVkuAN)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVAyJq , VVAyJq, VV1jhb)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVkuAN, VVCBDF )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV1jhb, VVAyJq)
  ok = FFKiof(cmd)
  FFwnFB()
  if ok: FFH1Ib(self, "Hidden List %s" % word)
  else : FF0eUf(self, "Error while restoring:\n\n%s" % fileName)
 def VV0Et6(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVPxkP
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVPxkP
  FFc045(self, cmd)
 def VVWWmt(self):
  VVCBDF, err = CCtCGd.VVzI2O(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFfhv3(tmpFile)
  totChan = totRemoved = 0
  lines = FFMA9m(VVCBDF, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FF4s3j(self, BF(FF1QiT, self, BF(self.VVUEEA, tmpFile, VVCBDF, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FF1OOs(totRemoved), totChan, FF1OOs(totChan))
      , callBack_No=BF(self.VVUAGM, tmpFile))
  else:
   FFXEvX(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVUEEA(self, tmpFile, VVCBDF, totRemoved, totChan):
  FFKiof("mv -f '%s' '%s'" % (tmpFile, VVCBDF))
  FFwnFB()
  FFXEvX(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVUAGM(self, tmpFile):
  FFfhv3(tmpFile)
 @staticmethod
 def VVzI2O(SELF, VV8wkm=True, title=""):
  VVCBDF, VVkuAN = CCtCGd.VVbblq()
  if   not fileExists(VVCBDF)       : err = "File not found !\n\n%s" % VVCBDF
  elif not CCNmp1.VV1wzQ(SELF, VVCBDF) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VV8wkm:
   FF0eUf(SELF, err, title=title)
  return VVCBDF, err
 @staticmethod
 def VVpp11(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVg3Dt(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVb4PL(servTypes):
  VV8MQ7  = eServiceCenter.getInstance()
  VV8JBG   = '%s ORDER BY name' % servTypes
  VV8Z1B   = eServiceReference(VV8JBG)
  VVUKB2 = VV8MQ7.list(VV8Z1B)
  if VVUKB2: return VVUKB2.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVHZ5U():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCUr80(Screen):
 VV26qy  = 0
 VVRUYK   = 1
 VVcEdv   = 2
 VVLztP    = 3
 VVinKd    = 4
 VV1Fdu   = 5
 VVfGLr   = 6
 VVzrvO    = 7
 VVUJsd   = 8
 VVc5Nc   = 9
 VVlBiQ   = 10
 VV9TGy   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFWbv3(VVgJDM, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV26qy)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFNr4J("%s\n", VVX5FP) % SEP
  self.picViewer  = None
  FF3tZI(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVA22M })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self["myLabel"].VVILcs(outputFileToSave="chann_info")
  if   self.fncMode == self.VV26qy : fnc = self.VVZnsJ
  elif self.fncMode == self.VVRUYK  : fnc = self.VVZnsJ
  elif self.fncMode == self.VVcEdv  : fnc = self.VVZnsJ
  elif self.fncMode == self.VVLztP  : fnc = self.VVuiU0
  elif self.fncMode == self.VVinKd  : fnc = self.VVUsn8
  elif self.fncMode == self.VV1Fdu  : fnc = self.VVbVK5
  elif self.fncMode == self.VVfGLr  : fnc = self.VVj9hM
  elif self.fncMode == self.VVzrvO  : fnc = self.VVbGq3
  elif self.fncMode == self.VVUJsd  : fnc = self.VVngVU
  elif self.fncMode == self.VVc5Nc : fnc = self.VVpwWV
  elif self.fncMode == self.VVlBiQ  : fnc = self.VV7ckP
  elif self.fncMode == self.VV9TGy : fnc = self.VVryqI
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVxeK7()
  FFdw1m(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVQh8r()
 def VVHuoA(self, err):
  self["myLabel"].setText(err)
  FFIznG(self["myTitle"], "#22200000")
  FFIznG(self["myBody"], "#22200000")
  self["myLabel"].VVPUkd("#22200000")
  self["myLabel"].VVxeK7()
 def VVZnsJ(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  self.refCode = refCode
  self.VVXtLw(chName)
 def VVuiU0(self):
  self.VVXtLw(self.chName)
 def VVUsn8(self):
  self.VVXtLw(self.chName)
 def VVbVK5(self):
  self.VVXtLw(self.chName)
 def VVj9hM(self):
  self.VVXtLw("Picon Info")
 def VVbGq3(self):
  self.VVXtLw(self.chName)
 def VVngVU(self):
  self.VVXtLw(self.chName)
 def VVpwWV(self):
  self.VVXtLw(self.chName)
 def VV7ckP(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFO3Nz(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VV0htI(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVXtLw(self.chName)
 def VVryqI(self):
  self.VVXtLw(self.chName)
 def VVXtLw(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFAJK0(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV6W12(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFNr4J(self.VVsmqJ(tUrl), VVi1yn)
  if not self.epg:
   epg = CCh6kb.VVblpy(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV2OFT(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCk0vb.VVZQ0A(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV2OFT(path)
  self.VVE2Yk()
  self.VVhaNJ(decodedUrl)
  self["myLabel"].setText(self.text or "   No active service", VVgcXL=VVFlog)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVxeK7(minHeight=minH)
 def VVhaNJ(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFBV7X(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVuETM(FF6s8T(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCyb9m.VVz6iF(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCyb9m.VVz6iF(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FF0CQw("EPG:", VVQzZA) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVE2Yk()
 def VVE2Yk(self):
  if not self.piconShown and self.picUrl:
   path, err = FFacHF(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV2OFT(path)
    if self.piconShown and self.refCode:
     self.VV2JAO(path, self.refCode)
 def VV2JAO(self, path, refCode):
  if path and fileExists(path) and FF4wzI("ffmpeg"):
   pPath = CCk0vb.VVJcyT()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCUr80.VV293l(path)
    cmd += FFyMLY("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFKiof(cmd)
 def VV2OFT(self, path):
  if path and fileExists(path):
   err, w, h = self.VV3BCW(path)
   if not err:
    if h > w:
     self.VVPhl7(self["myPicF"], w, h, True)
     self.VVPhl7(self["myPicB"], w, h, False)
     self.VVPhl7(self["myPic"] , w, h, False)
   self.picViewer = CC0tiy.VVu63j(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVPhl7(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV3BCW(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF0hBQ(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV6W12(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFNr4J(chName, VVQzZA)
  txt += self.VVOb1w(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFNr4J(state, VVqDXM)
   txt += "State\t: %s\n" % state
  w = FFQKi3(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFQKi3(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV9N0g(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVOb1w(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVOb1w(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVOb1w(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVYbQW()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVteuO()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCUr80.VV8xmm(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFNr4J("Stream-Relay" if FF98yX(decodedUrl) else "IPTV", VVi9VJ)
   txt += self.VVSk1I(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVyrZ7(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCwj2W()
    tpTxt, namespace = tp.VVGEMY(refCode)
    if tpTxt:
     txt += FFNr4J("Tuner:\n", VVQzZA)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFNr4J("Codes:\n", VVQzZA)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVOb1w(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVOb1w(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVOb1w(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVOb1w(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVOb1w(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVOb1w(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVOb1w(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVOb1w(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVOb1w(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV9N0g(info):
  if info:
   aspect = FFQKi3(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVOb1w(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFQKi3(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVlIpZ(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVlIpZ(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVYbQW(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVteuO(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVyrZ7(self, refCode, iptvRef, chName):
  refCode = FFqmmY(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFBRKz(VVPxkP + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFBRKz(VVPxkP + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVDpqo = []
  tmpRefCode = FF6s8T(refCode)
  for item in fList:
   path = VVPxkP + item
   if fileExists(path):
    txt = FFBRKz(path)
    if tmpRefCode in FF6s8T(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVDpqo.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVDpqo:
   if len(VVDpqo) == 1:
    txt += "%s\t: %s%s\n" % (FFNr4J("Bouquet", VVQzZA), VVDpqo[0][0], " (%s)" % VVDpqo[0][1] if VVLt64 else "")
   else:
    txt += FFNr4J("Bouquets:\n", VVQzZA)
    for ndx, item in enumerate(VVDpqo):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVLt64 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVSk1I(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFsUIS(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCyb9m()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFNr4J("URL:", VVi9VJ) + "\n%s\n" % self.VVsmqJ(decodedUrl)
  else:
   txt = "\n"
   txt += FFNr4J("Reference:", VVi9VJ) + "\n%s\n" % refCode
  return txt
 def VVsmqJ(self, url):
  if not FF98yX(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVFBr8:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FF6s8T(url)
 def VVuETM(self, decodedUrl):
  if not CCoB4g.VVKCNt():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCXyjP.VVmPHt(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VV8QOM(tDict)
   elif uType == "movie" : epg, picUrl = CCUr80.VVihEd(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VV8QOM(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCXyjP.VVCv0w(item, "title"    , is_base64=True )
     lang    = CCXyjP.VVCv0w(item, "lang"         ).upper()
     description   = CCXyjP.VVCv0w(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCXyjP.VVCv0w(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCXyjP.VVCv0w(item, "start_timestamp"      )
     stop_timestamp  = CCXyjP.VVCv0w(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCXyjP.VVCv0w(item, "stop_timestamp"       )
     now_playing   = CCXyjP.VVCv0w(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVqIxN, ""
      else     : color, txt = VVqDXM , "    (CURRENT EVENT)"
      epg += FFNr4J("_" * 32 + "\n", VVX5FP)
      epg += FFNr4J("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFNr4J(description, VVi1yn)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCh6kb.VVpizh(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVihEd(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCXyjP.VVCv0w(item, "movie_image" )
    genre  = CCXyjP.VVCv0w(item, "genre"   ) or "-"
    plot  = CCXyjP.VVCv0w(item, "plot"   ) or "-"
    country  = CCXyjP.VVCv0w(item, "country"  ) or "-"
    actors  = CCXyjP.VVCv0w(item, "actors"   ) or "-"
    cast  = CCXyjP.VVCv0w(item, "cast"   ) or "-"
    rating  = CCXyjP.VVCv0w(item, "rating"   ) or "-"
    director = CCXyjP.VVCv0w(item, "director"  ) or "-"
    releasedate = CCXyjP.VVCv0w(item, "releasedate" ) or "-"
    duration = CCXyjP.VVCv0w(item, "duration"  ) or "-"
    try:
     lang = CCXyjP.VVCv0w(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFNr4J(cast if cast != "-" else actors, VVi1yn)
    epg += "Plot:\n%s"    % FFNr4J(plot, VVi1yn)
   except:
    pass
  return epg, movie_image
 def VVA22M(self):
  if VVFBr8:
   def VVOb1w(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVOb1w(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCyb9m()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVOb1w(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FF7BjW(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVuIxl(SELF):
  if not CCHRwQ.VV3TtN(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF)
  err = url =  fSize = resumable = ""
  if FFXFl9(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCyb9m.VVbTF5(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCyb9m.VVANoN(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FF0eUf(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCNmp1.VV3y2b(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFNr4J(" (M3U/M3U8 File)", VVi1yn)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCVzxd.VVJOeJ(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV5jhO(subj, val):
   return "%s\n%s\n\n" % (FFNr4J("%s:" % subj, VVQzZA), val)
  title = "File Size"
  txt  = VV5jhO(title , fSize or "?")
  txt += VV5jhO("Name" , chName)
  txt += VV5jhO("URL" , url)
  if resumable: txt += VV5jhO("Supports Download-Resume", resumable)
  if err  : txt += FFNr4J("Error:\n", VVqDXM) + err
  FFXEvX(SELF, txt, title=title)
 @staticmethod
 def VV8xmm(SELF):
  fPath, fDir, fName = CCNmp1.VVORqp(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VV293l(path):
  return FFyMLY("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVzm63(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCk0vb.VVJcyT() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVOv7T(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFBV7X(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFkO4T(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCyb9m():
 def __init__(self):
  self.VVe7X0()
  self.VVV9Sr    = ""
  self.VVYmIy   = "#f#11ffffaa#User"
  self.VVHJaj   = "#f#11aaffff#Server"
 def VVe7X0(self):
  self.VVxyZC   = ""
  self.VVo4zE    = ""
  self.VV7KQB   = ""
  self.VV5JXA = ""
  self.VVnb56  = ""
  self.VVjAKD = 0
 def VVKjpf(self, url, mac, ph1="", VVR9V4=True):
  self.VVe7X0()
  self.VVV9Sr = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVpcri(url)
  if not host:
   if VVR9V4:
    self.VV9Jog("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVqucR(mac)
  if not host:
   if VVR9V4:
    self.VV9Jog("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVxyZC = host
  self.VVo4zE  = mac
  return True
 def VV9g6g(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVV9Sr, "")
 def VVpcri(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVqucR(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVl7qc(self):
  res, err = self.VVZdkh(self.VVX8oP())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVxyZC.endswith("/c"):
    self.VVxyZC = self.VVxyZC[:-2]
    res, err = self.VVZdkh(self.VVX8oP())
   elif self.VVxyZC.endswith("/stalker_portal"):
    self.VVxyZC = self.VVxyZC[:-15]
    res, err = self.VVZdkh(self.VVX8oP())
   else:
    self.VVxyZC += "/c"
    res, err = self.VVZdkh(self.VVX8oP())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCXyjP.VVCv0w(tDict["js"], "token")
    rand  = CCXyjP.VVCv0w(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VV03Hv(self, VVR9V4=True):
  if not self.VVV9Sr:
   self.VV0qBe()
  err = blkMsg = FFH1IbTxt = ""
  try:
   token, rand, err = self.VVl7qc()
   if token:
    self.VV7KQB = token
    self.VV5JXA = rand
    if rand:
     self.VVjAKD = 2
    prof, retTxt = self.VVqqR1(True)
    if prof:
     self.VVnb56 = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVjAKD = 3
      prof, retTxt = self.VVqqR1(False)
      if retTxt:
       self.VVnb56 = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFH1IbTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFH1IbTxt: tErr += "\n%s" % FFH1IbTxt
  if VVR9V4:
   self.VV9Jog(tErr)
  return "", "", tErr
 def VV0qBe(self):
  try:
   import requests
   url = self.VVfS2S()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCyb9m.VVANoN(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCyb9m.VVANoN(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVxyZC = url
       self.VVV9Sr = span.group(1)
       return
  except:
   pass
  self.VVV9Sr = "/server/load.php"
 def VVfS2S(self):
  url = self.VVxyZC.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVWROM(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVZdkh("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVZdkh("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVqqR1(self, capMac):
  res, err = self.VVZdkh(self.VVUGCe(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCXyjP.VVCv0w(tDict["js"], "block_%s" % word)
    FFH1IbTxt = CCXyjP.VVCv0w(tDict["js"], word)
    return tDict, FFH1IbTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVUGCe(self, capMac):
  param = ""
  if self.VVnb56 or self.VV5JXA:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVo4zE.upper() if capMac else self.VVo4zE.lower(), self.VV5JXA))
  return self.VVjjjo() + "type=stb&action=get_profile" + param
 exec(FFO3Nz("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVBSQy(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVs58U()
  if len(rows) < 10:
   rows = self.VVEcU7()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVxyZC ))
   rows.append(("MAC (from URL)" , self.VVo4zE ))
   rows.append(("Token"   , self.VV7KQB ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVYmIy  , "MAC" , self.VVo4zE ))
   rows.append(("2", self.VVHJaj, "Host" , self.VVxyZC ))
   rows.append(("2", self.VVHJaj, "Token" , self.VV7KQB ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVrWGv(self, isPhp=True, VVR9V4=False):
  token, profile, tErr = self.VV03Hv(VVR9V4)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVoc0O()
  res, err = self.VVZdkh(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCXyjP.VVCv0w(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFVH3K(span.group(2))
     pass1 = FFVH3K(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVs58U(self):
  m3u_Url, host, user1, pass1, err = self.VVrWGv()
  rows = []
  if m3u_Url:
   res, err = self.VVZdkh(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFmWOg(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVYmIy, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFmWOg(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVHJaj, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVEcU7(self):
  token, profile, tErr = self.VV03Hv()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF4Ay2(val): val = FFO3Nz(val.decode("UTF-8"))
     else     : val = self.VVo4zE
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFmWOg(int(parts[1]))
      if parts[2] : ends = FFmWOg(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFmWOg(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV0htI(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VV03Hv(VVR9V4=False)
  if not token:
   return ""
  crLinkUrl = self.VVY9Lo(mode, chCm, epNum, epId)
  res, err = self.VVZdkh(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCXyjP.VVCv0w(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVjjjo(self):
  return self.VVxyZC + self.VVV9Sr + "?"
 def VVX8oP(self):
  return self.VVjjjo() + "type=stb&action=handshake&token=&mac=%s" % self.VVo4zE
 def VVHMh5(self, mode):
  url = self.VVjjjo() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVfQgI(self, catID):
  return self.VVjjjo() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVgLT9(self, mode, catID, page):
  url = self.VVjjjo() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVGvcq(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVjjjo() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVC4un(self, stID):
  return self.VVjjjo() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVY9Lo(self, mode, chCm, serCode, serId):
  url = self.VVjjjo() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVoc0O(self):
  return self.VVjjjo() + "type=itv&action=create_link"
 def VVJxQi(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVWUPj(catID, stID, chNum)
  query = self.VV8S7Z(mode, self.VV9g6g(), FFgvTB(host), FFgvTB(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV8S7Z(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVbuBi(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VV8S7Z(mode, ph1, host, mac, epNum, epId, FFVH3K(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFO3Nz(host)
  mac   = FFO3Nz(mac)
  valid = False
  if self.VVpcri(playHost) and self.VVpcri(host) and self.VVpcri(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVZdkh(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCyb9m.VVANoN()
   if self.VV7KQB:
    headers["Authorization"] = "Bearer %s" % self.VV7KQB
   if useCookies : cookies = {"mac": self.VVo4zE, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVLT2J(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCyb9m.VVANoN(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVANoN():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VV9Jog(self, err, title="Portal Browser"):
  FF0eUf(self, str(err), title=title)
 def VVk6fD(self, mode):
  if   mode in ("itv"  , CCXyjP.VVQNZo , CCXyjP.VVTtCS)  : return "Live"
  elif mode in ("vod"  , CCXyjP.VVshXk , CCXyjP.VVmoqv)  : return "VOD"
  elif mode in ("series" , CCXyjP.VVw4lF , CCXyjP.VVoBR2) : return "Series"
  else                          : return "IPTV"
 def VVuBbU(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVk6fD(mode), FFNr4J(searchName, VVi1yn))
 def VVbYdd(self, catchup=False):
  VVZ4NM = []
  VVZ4NM.append(("Live"    , "live"  ))
  VVZ4NM.append(("VOD"    , "vod"   ))
  VVZ4NM.append(("Series"   , "series"  ))
  if catchup:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Catch-up TV" , "catchup"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Account Info." , "accountInfo" ))
  return VVZ4NM
 @staticmethod
 def VVuQpK(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCyb9m()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
  if valid:
   ok = p.VVKjpf(host, mac, ph1, VVR9V4=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVrWGv(isPhp=False, VVR9V4=False)
    streamId = CCyb9m.VVTlI0(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVTlI0(decodedUrl):
  p = CCyb9m()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFO3Nz(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVbTF5(decodedUrl):
  p = CCyb9m()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
  if valid:
   if CCyb9m.VVsfJ9(chCm):
    return FF6s8T(chCm)
   else:
    ok = p.VVKjpf(host, mac, ph1, VVR9V4=False)
    if ok:
     try:
      chUrl = p.VV0htI(mode, chCm, epNum, epId)
      return FF6s8T(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVsfJ9(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVz6iF(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCyb9m()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(decodedUrl)
   if valid:
    if not stID:
     stID = CCyb9m.VVTlI0(decodedUrl)
    if stID:
     if p.VVKjpf(host, mac, ph1, VVR9V4=False):
      token, profile, tErr = p.VV03Hv(VVR9V4=False)
      if token:
       res, err = p.VVZdkh(p.VVC4un(stID))
       if res:
        epg, err = CCyb9m.VVkDqq(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCyb9m.VVkDqq(res.text, retLst=True)
         if pList:
          totEv, totOK = CCh6kb.VVpizh(refCode, pList)
  return epg, err
 @staticmethod
 def VVkDqq(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCXyjP.VVCv0w(item, "actor"       )
    category   = CCXyjP.VVCv0w(item, "category"      )
    descr    = CCXyjP.VVCv0w(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCXyjP.VVCv0w(item, "director"      )
    name    = CCXyjP.VVCv0w(item, "name"   , is_base64=True)
    start_timestamp  = CCXyjP.VVCv0w(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCXyjP.VVCv0w(item, "start_timestamp"    )
    stop_timestamp  = CCXyjP.VVCv0w(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCXyjP.VVCv0w(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFNr4J("    (CURRENT EVENT)", VVI2ZY)
     except:
      pass
     if not skip:
      epg += FFNr4J("_" * 32 + "\n", VVX5FP)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFNr4J(name, VVQzZA)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFNr4J(descr , VVi1yn) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFNr4J(category, VVi1yn) if category else ""
      epg += "Actors:\n%s\n"  % FFNr4J(actor , VVi1yn) if actor else ""
      epg += "Director:\n%s\n" % FFNr4J(director, VVi1yn) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCqj56(CCyb9m):
 def __init__(self):
  CCyb9m.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVxcLl(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVbuBi(decodedUrl)
  if valid:
   if self.VVKjpf(host, mac, ph1, VVR9V4=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVBQZ0(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFO3Nz(self.chCm[3:])
  else:
   try:
    chUrl = self.VV0htI(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCyb9m.VVsfJ9(self.chCm):
   chUrl = FF6s8T(self.chCm)
   chUrl = FFVH3K(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VV3Wwt(chUrl)
  bPath = CC8DHP.VVstve()
  if newIptvRef:
   if passedSELF:
    FFzGKI(passedSELF, newIptvRef, VVEwyq=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFzGKI(self, newIptvRef, VVEwyq=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVBMnE(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VV3Wwt(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVBMnE(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FFMA9m(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFwnFB()
class CCWpkN(CCqj56):
 def __init__(self, passedSession):
  CCqj56.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVkel5(VVzmhg  )
  Main_Menu.VVkel5(VVdir1)
  Main_Menu.VVkel5(VV28ZM  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVQEWx, iPlayableService.evEOF: self.VVqmoR, iPlayableService.evEnd: self.VVG3Xm})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVAUDw)
  except:
   self.timer2.callback.append(self.VVAUDw)
  self.timer2.start(3000, False)
  self.VVAUDw()
 def VVAUDw(self):
  if not CFG.downloadMonitor.getValue():
   self.VVPDb4()
   return
  lst = CCVzxd.VVwvG0()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFPebg(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCVzxd.VVk8nH(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCZCdI.VVlJTg(self.passedSession, txt, 30)
   else    : CCZCdI.VVXPKH(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVPDb4()
 def VVPDb4(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVQEWx(self):
  self.startTime = iTime()
 def VVqmoR(self):
  global VVZesR
  VVZesR = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFXFl9(decodedUrl):
     self.isFromEOF = True
     CCZCdI(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVG3Xm(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVPNpC)
  except:
   self.timer1.callback.append(self.VVPNpC)
  self.timer1.start(100, True)
 def VVPNpC(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVxcLl(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCXYrc.VVvQtf:
       self.isFromEOF = False
       self.VVBQZ0(self.passedSession, isFromSession=True)
class CC939I():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F](.+)")
  self.prefixRemoveList = self.VV4iVc(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VV4iVc(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VV4iVc(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVrRM9, VVbRSD):
    path += fName
    if fileExists(path):
     for line in FFMA9m(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVlWTJ(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCXyjP.VViSZy(name):
   return CCXyjP.VVwDIq(name)
  return self.VVAd6h(name)
 def VVAd6h(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVsZyp(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVAd6h(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVP8y8(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVbuji(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVhCny(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCHRwQ(CCyb9m):
 def __init__(self):
  self.curPortalCatId = ""
  CCyb9m.__init__(self)
 def VV8DgG(self):
  if CCHRwQ.VV3TtN(self):
   FF1QiT(self, BF(self.VVXvdf, 2), title="Searching ...")
 def VV29vw(self, winSession, url, mac):
  self.curUrl = url
  if CCHRwQ.VV3TtN(self):
   if self.VVKjpf(url, mac):
    FF1QiT(winSession, self.VVIRkw, title="Checking Server ...")
   else:
    FF0eUf(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVw4hM(self, item=None):
  if item:
   VVKicw, txt, path, ndx = item
   enc = CC9SOR.VVarly(path, self)
   if enc == -1:
    return
   self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVxuOD, path, enc)
       , VVtCUJ = BF(self.VVh5M8, VVKicw, path))
 def VVxuOD(self, path, enc, VVx2mk):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVx2mk.VVSJhE(totLines)
  VVx2mk.VVgnkU = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVx2mk or VVx2mk.isCancelled:
     return
    VVx2mk.VVr1vN(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVpcri(url)
     mac  = self.VVqucR(mac)
     if host and mac and VVx2mk:
      VVx2mk.VVgnkU.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVpcri(url)
      mac  = self.VVqucR(mac)
      if host and mac and not mac.startswith("AC") and VVx2mk:
       VVx2mk.VVgnkU.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVh5M8(self, VVKicw, path, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVgnkU:
   VVdvf0  = ("Home Menu"  , FFSv8C            , [])
   VV0RwZ = ("Edit File"  , BF(self.VVVVNP, path)       , [])
   VV8lmg = ("M3U Options" , self.VVpN8N         , [])
   VVUpMt = ("Check & Filter" , BF(self.VVBZug, VVKicw, path), [])
   VVFJkn  = ("Select"   , self.VVaR5K      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVXdZ9  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVgnkU, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVrEme="#0a001122", VVRBt6="#0a001122", VVfKIv="#0a001122", VV6z2K="#00004455", VV7JIr="#0a333333", VVpBpY="#11331100", VVROQm=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVGvWA:
    FF7BjW(VVSuUg, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVGvWA:
    FF0eUf(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVpN8N(self, VVSuUg, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVZ4NM = []
  VVZ4NM.append(("Browse as M3U"  , "browse"))
  VVZ4NM.append(("Download M3U File" , "downld"))
  FFLMiy(self, BF(self.VVseOY, VVSuUg, host, mac), title=title, VVZ4NM=VVZ4NM, width=600, VV9pbf=True)
 def VVseOY(self, VVSuUg, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF1QiT(VVSuUg, BF(self.VVk6t2, VVSuUg, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FF4s3j(self, BF(FF1QiT, VVSuUg, BF(self.VVk6t2, VVSuUg, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVk6t2(self, VVSuUg, title, host, mac, item):
  p = CCyb9m()
  m3u_Url = ""
  ok = p.VVKjpf(host, mac, VVR9V4=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVrWGv(VVR9V4=False)
  if m3u_Url:
   if   item == "browse": self.VVCppJ(title, m3u_Url)
   elif item == "downld": self.VVGQI8(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FF0eUf(self, err or "No response from Server !", title=title)
 def VVaR5K(self, VVSuUg, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV29vw(VVSuUg, url, mac)
 def VVVVNP(self, path, VVSuUg, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCC9Tv(self, path, VVtCUJ=BF(self.VVyvIS, VVSuUg), curRowNum=rowNum)
  else    : FF7Hmv(self, path)
 def VVBZug(self, VVKicw, path, VVSuUg, title, txt, colList):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVah19, VVSuUg)
      , VVtCUJ = BF(self.VVD2xn, VVKicw, VVSuUg, path))
 def VVah19(self, VVSuUg, VVx2mk):
  VVx2mk.VVgnkU = []
  VVx2mk.VVSJhE(VVSuUg.VVmUCw())
  for row in VVSuUg.VVOxLE():
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVKjpf(host, mac, VVR9V4=False):
    token, profile, tErr = self.VV03Hv(VVR9V4=False)
    if token and VVx2mk and not VVx2mk.isCancelled:
     res, err = self.VVZdkh(self.VVHMh5("itv"))
     if res and VVx2mk and not VVx2mk.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVx2mk.VVr1vN(0, showFound=True)
       VVx2mk.VVgnkU.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVx2mk:
    return
 def VVD2xn(self, VVKicw, VVSuUg, path, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVgnkU:
   VVSuUg.close()
   VVKicw.close()
   newPath = "%s_OK_%s.txt" % (path, FFXJI8())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVgnkU:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFNr4J(str(threadCounter), VVqDXM)
    skipped = FFNr4J(str(threadTotal - threadCounter), VVqDXM)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVgnkU)
   txt += "%s\n\n%s"    %  (FFNr4J("Result File:", VVQzZA), newPath)
   FFXEvX(self, txt, title="Accessible Portals")
  elif VVGvWA:
   FF0eUf(self, "No portal access found !", title="Accessible Portals")
 def VVLQCH(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFO3Nz(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVIRkw(self):
  token, profile, tErr = self.VV03Hv()
  if token:
   dots = "." * self.VVjAKD
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VV9g6g(), "")
   dots += "*" if not self.VVxyZC == self.curUrl else ""
   VVZ4NM  = self.VVbYdd()
   VVsd1c = self.VVbHKi
   VVsk8Y = self.VVH53C
   VV6rAJ = ("Home Menu", FFSv8C)
   VVcrQj= ("Add to Menu", BF(CCXyjP.VVoEwj, self, True, self.VVxyZC + "\t" + self.VVo4zE))
   VVs32w = ("Bookmark Server", BF(CCXyjP.VVNEFe, self, True, self.VVxyZC + "\t" + self.VVo4zE))
   VVKicw = FFLMiy(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVo4zE, dots), VVZ4NM=VVZ4NM, VVsd1c=VVsd1c, VVsk8Y=VVsk8Y, VV6rAJ=VV6rAJ, VVcrQj=VVcrQj, VVs32w=VVs32w)
   self.VVLdQk(VVKicw)
 def VVbHKi(self, item=None):
  if item:
   VVKicw, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF1QiT(VVKicw, BF(self.VV0sZ9, mode), title="Reading Categories ...")
   else : FF1QiT(VVKicw, BF(self.VVvcS7, VVKicw, title), title="Reading Account ...")
 def VVvcS7(self, VVKicw, title, forceMoreInfo=False):
  rows, totCols = self.VVBSQy(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVo4zE)
  VVdvf0  = ("Home Menu" , FFSv8C           , [])
  VV8lmg  = None
  if VVFBr8:
   VV8lmg = ("Get JS"  , BF(self.VVTE8H, self.VVfS2S()) , [])
  if totCols == 2:
   VVUpMt = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVUpMt = ("More Info.", BF(self.VVrQv5, VVKicw)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFW2Tv(self, None, title=title, width=1200, header=header, VVDpqo=rows, VVQT0l=widths, VVsgYf=26, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VVUpMt=VVUpMt, VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000", searchCol=searchCol)
 def VVTE8H(self, url, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVxC7z, url), title="Getting JS ...")
 def VVxC7z(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVo4zE)
  ver, err = self.VVWROM(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVWROM(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFXEvX(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVrQv5(self, VVKicw, VVSuUg, title, txt, colList):
  VVSuUg.cancel()
  FF1QiT(VVKicw, BF(self.VVvcS7, VVKicw, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV0sZ9(self, mode):
  token, profile, tErr = self.VV03Hv()
  if not token:
   return
  res, err = self.VVZdkh(self.VVHMh5(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCXyjP.VVCv0w(item, "id"       )
      Title  = CCXyjP.VVCv0w(item, "title"      )
      censored = CCXyjP.VVCv0w(item, "censored"     )
      Title = self.VVP8y8(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVLt64:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVk6fD(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH(mode)
   mName = self.VVk6fD(mode)
   VVHEpO  = (""     , BF(self.VVwHxi, mode), [])
   VVFJkn   = ("Show List"   , BF(self.VVAKqB, mode)   , [])
   VVdvf0  = ("Home Menu"   , FFSv8C        , [])
   if mode in ("vod", "series"):
    VV0RwZ = ("Find in %s" % mName , BF(self.VVKggV, mode, False), [])
    VVUpMt = ("Find in Selected" , BF(self.VVKggV, mode, True) , [])
   else:
    VV0RwZ = None
    VVUpMt = None
   header   = None
   widths   = (100   , 0  )
   FFW2Tv(self, None, title=title, width=1200, header=header, VVDpqo=list, VVQT0l=widths, VVsgYf=30, VVdvf0=VVdvf0, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVHEpO=VVHEpO, VVFJkn=VVFJkn, VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVnb56:
     txt += "\n\n( %s )" % self.VVnb56
   else:
    txt = "Could not get Categories from server!"
   FF0eUf(self, txt, title=title)
 def VVa7ol(self, mode, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VV0ycD, mode, VVSuUg, title, txt, colList), title="Downloading ...")
 def VV0ycD(self, mode, VVSuUg, title, txt, colList):
  token, profile, tErr = self.VV03Hv()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVZdkh(self.VVfQgI(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCXyjP.VVCv0w(item, "id"    )
      actors   = CCXyjP.VVCv0w(item, "actors"   )
      added   = CCXyjP.VVCv0w(item, "added"   )
      age    = CCXyjP.VVCv0w(item, "age"   )
      category_id  = CCXyjP.VVCv0w(item, "category_id" )
      description  = CCXyjP.VVCv0w(item, "description" )
      director  = CCXyjP.VVCv0w(item, "director"  )
      genres_str  = CCXyjP.VVCv0w(item, "genres_str"  )
      name   = CCXyjP.VVCv0w(item, "name"   )
      path   = CCXyjP.VVCv0w(item, "path"   )
      screenshot_uri = CCXyjP.VVCv0w(item, "screenshot_uri" )
      series   = CCXyjP.VVCv0w(item, "series"   )
      cmd    = CCXyjP.VVCv0w(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVHEpO = (""     , BF(self.VVcezx, mode, True)  , [])
   VVFJkn  = ("Play"    , BF(self.VVEnV8, mode)       , [])
   VVU95Y = (""     , BF(self.VVt62C, mode)     , [])
   VVdvf0 = ("Home Menu"   , FFSv8C            , [])
   VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, "sp", seriesName) , [])
   VV0RwZ = ("Options"   , BF(self.VV8f4T, "pEp", mode, seriesName) , [])
   VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVXdZ9  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFW2Tv(self, None, title=seriesName, width=1200, header=header, VVDpqo=list, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVHEpO=VVHEpO, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindIptv, VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000")
  else:
   FF0eUf(self, "Could not get Episodes from server!", title=seriesName)
 def VVKggV(self, mode, searchInCat, VVSuUg, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVZ4NM = []
  VVZ4NM.append(("Keyboard"  , "manualEntry"))
  VVZ4NM.append(("From Filter" , "fromFilter"))
  FFLMiy(self, BF(self.VVOOGy, VVSuUg, mode, searchCatId), title="Input Type", VVZ4NM=VVZ4NM, width=400)
 def VVOOGy(self, VVSuUg, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFFMZg(self, BF(self.VVZ0vA, VVSuUg, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCC0Pu(self)
    filterObj.VVX9no(BF(self.VVZ0vA, VVSuUg, mode, searchCatId))
 def VVZ0vA(self, VVSuUg, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFE6Br(CFG.lastFindIptv, searchName)
   title = self.VVuBbU(mode, searchName)
   if "," in searchName : FF0eUf(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FF0eUf(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVbuji([searchName]):
     FF0eUf(self, self.VVhCny(), title=title)
    else:
     self.VVf3NF(mode, searchName, "", searchName, searchCatId)
 def VVAKqB(self, mode, VVSuUg, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVf3NF(mode, bName, catID, "", "")
 def VVf3NF(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVFT36, mode, bName, catID, searchName, searchCatId)
      , VVtCUJ = BF(self.VV4LaF, mode, bName, catID, searchName, searchCatId))
 def VV4LaF(self, mode, bName, catID, searchName, searchCatId, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVuBbU(mode, searchName)
  else   : title = "%s : %s" % (self.VVk6fD(mode), bName)
  if VVgnkU:
   VV8lmg = None
   VV0RwZ = None
   if mode == "series":
    VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH("series2")
    VVFJkn  = ("Episodes"   , BF(self.VVa7ol, mode)           , [])
   else:
    VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH("")
    VVFJkn  = ("Play"    , BF(self.VVEnV8, mode)           , [])
    VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, "vp" if mode == "vod" else "", "") , [])
    VV0RwZ = ("Options"   , BF(self.VV8f4T, "pCh", mode, bName)      , [])
   VVHEpO = (""      , BF(self.VVcezx, mode, False)      , [])
   VVU95Y = (""      , BF(self.VVy1u5, mode)         , [])
   VVdvf0 = ("Home Menu"    , FFSv8C                , [])
   VVUpMt = ("Posters Mode"   , BF(self.VV0r0F, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVXdZ9  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVgnkU, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindIptv, VVFJkn=VVFJkn, VVHEpO=VVHEpO, VVU95Y=VVU95Y, VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K, VVROQm=True, searchCol=1)
   if not VVGvWA:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVSuUg.VVcL6X(VVSuUg.VVdoWv() + tot)
    if threadErr: FF7BjW(VVSuUg, "Error while reading !", 2000)
    else  : FF7BjW(VVSuUg, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF0eUf(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF0eUf(self, "Could not get list from server !", title=title)
 def VVy1u5(self, mode, VVSuUg, title, txt, colList):
  ttl = lambda x, y: "%s\n%s\n\n" % (FFNr4J(x, VVQzZA), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFGNa7(self, fncMode=CCUr80.VV9TGy, portalHost=self.VVxyZC, portalMac=self.VVo4zE, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV1YnB(mode, VVSuUg, title, txt, colList)
 def VVt62C(self, mode, VVSuUg, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFNr4J(colList[10], VVi1yn)
  txt += "Description:\n%s" % FFNr4J(colList[11], VVi1yn)
  self.VV1YnB(mode, VVSuUg, title, txt, colList)
 def VV1YnB(self, mode, VVSuUg, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, colList)
  refCode, chUrl = self.VVJxQi(self.VVxyZC, self.VVo4zE, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFGNa7(self, fncMode=CCUr80.VVlBiQ, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVFT36(self, mode, bName, catID, searchName, searchCatId, VVx2mk):
  try:
   token, profile, tErr = self.VV03Hv()
   if not token:
    return
   if VVx2mk.isCancelled:
    return
   VVx2mk.VVgnkU, total_items, max_page_items, err = self.VVkNF7(mode, catID, 1, 1, searchName, searchCatId)
   if VVx2mk.isCancelled:
    return
   if VVx2mk.VVgnkU and total_items > -1 and max_page_items > -1:
    VVx2mk.VVSJhE(total_items)
    VVx2mk.VVr1vN(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVx2mk.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVkNF7(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVx2mk.VVlpyV()
     if VVx2mk.isCancelled:
      return
     if list:
      VVx2mk.VVgnkU += list
      VVx2mk.VVr1vN(len(list), True)
  except:
   pass
 def VVkNF7(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVGvcq(mode, searchName, searchCatId, page)
  else   : url = self.VVgLT9(mode, catID, page)
  res, err = self.VVZdkh(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVV3Ey(CCXyjP.VVCv0w(item, "total_items" ))
     max_page_items = self.VVV3Ey(CCXyjP.VVCv0w(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCXyjP.VVCv0w(item, "id"    )
      name   = CCXyjP.VVCv0w(item, "name"   )
      o_name   = CCXyjP.VVCv0w(item, "o_name"   )
      category_id  = CCXyjP.VVCv0w(item, "category_id" )
      tv_genre_id  = CCXyjP.VVCv0w(item, "tv_genre_id" )
      number   = CCXyjP.VVCv0w(item, "number"   ) or str(counter)
      logo   = CCXyjP.VVCv0w(item, "logo"   )
      screenshot_uri = CCXyjP.VVCv0w(item, "screenshot_uri" )
      pic    = CCXyjP.VVCv0w(item, "pic"   )
      cmd    = CCXyjP.VVCv0w(item, "cmd"   )
      censored  = CCXyjP.VVCv0w(item, "censored"  )
      genres_str  = CCXyjP.VVCv0w(item, "genres_str"  )
      curPlay   = CCXyjP.VVCv0w(item, "cur_playing" )
      actors   = CCXyjP.VVCv0w(item, "actors"   )
      descr   = CCXyjP.VVCv0w(item, "description" )
      director  = CCXyjP.VVCv0w(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFgvTB(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVxyZC + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVlWTJ(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVV3Ey(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVEnV8(self, mode, VVSuUg, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, colList)
  refCode, chUrl = self.VVJxQi(self.VVxyZC, self.VVo4zE, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VViSZy(chName):
   FF7BjW(VVSuUg, "This is a marker!", 300)
  else:
   FF1QiT(VVSuUg, BF(self.VVjXO4, mode, VVSuUg, chUrl), title="Playing ...")
 def VVjXO4(self, mode, VVSuUg, chUrl):
  FFzGKI(self, chUrl, VVEwyq=False)
  CCXYrc.VVRGWe(self.session, iptvTableParams=(self, VVSuUg, mode))
 def VVFqFt(self, mode, VVSuUg, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, colList)
  refCode, chUrl = self.VVJxQi(self.VVxyZC, self.VVo4zE, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVmg6D(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV3TtN(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVZ4NM = []
    VVZ4NM.append((title        , "inst" ))
    VVZ4NM.append(("Update Packages then %s" % title , "updInst" ))
    FFLMiy(SELF, BF(CCHRwQ.VVBqx4, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVZ4NM=VVZ4NM)
   return False
 @staticmethod
 def VVBqx4(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FF8xxa(VV1LmT, "")
   if cmdUpd:
    cmdInst = FF2pmn(VVLJqS, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFxjL4(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVgmlB=cbFnc)
   else:
    FFPXac(SELF)
 def VVFrZw(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVbuBi(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVLdQk(self, VVKicw):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVFrZw()
  if all((curMode, curHost, curCat)) and curHost == self.VVxyZC:
   VVKicw.VVcLR7({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVwHxi(self, mode, VVSuUg, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVFrZw()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVxyZC:
   VVSuUg.VVeEhA({1:curCat})
 def VVcezx(self, mode, isEp, VVSuUg, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVFrZw()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVxyZC:
   if mode in ("itv", "vod"):
    VVSuUg.VVeEhA({2:curStID})
   else: #series
    if isEp:
     VVSuUg.VVeEhA({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVSuUg.VVeEhA({2:ser2})
     if not ok: VVSuUg.VVeEhA({2:ser1})
class CCXyjP(Screen, CCHRwQ, CC939I, CC4MwO):
 VV4OUR    = 0
 VVLteC    = 1
 VVDXiJ    = 2
 VVcQee    = 3
 VVKEu3     = 4
 VVag60     = 5
 VVtZ7u     = 6
 VV7vbS     = 7
 VVHtTY     = 8
 VVLRvE     = 9
 VVSq3A      = 10
 VV7tJL     = 11
 VVKkeX     = 12
 VVxfkW     = 13
 VVc954     = 14
 VVcuWr      = 15
 VV0SyM      = 16
 VVir0M      = 17
 VVuFp1      = 18
 VV8cOI      = 19
 VVu07k    = 0
 VVQNZo   = 1
 VVshXk   = 2
 VVw4lF   = 3
 VVHzHe  = 4
 VV6mU6  = 5
 VVTtCS   = 6
 VVmoqv   = 7
 VVoBR2  = 8
 VVF2dq  = 9
 VVFYqE  = 10
 VVUPsA = 0
 VVkUjm = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVSuUg    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVZMH2Data    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCXyjP.VVpx1z(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCHRwQ.__init__(self)
  CC939I.__init__(self)
  VVZ4NM = self.VVGG6n()
  FF3tZI(self, title="IPTV", VVZ4NM=VVZ4NM)
  self["myActionMap"].actions.update({
   "menu" : self.VVmFqv
  })
  self["myMenu"].onSelectionChanged.append(self.VV1P63)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
  global VVEbPR
  VVEbPR = True
 def VV7StE(self):
  self["myMenu"].setList(self.VVGG6n())
  FFxUTp(self)
  FFBjfS(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FF4VOV(self["myMenu"])
   FFqLYS(self)
   if self.m3uOrM3u8File:
    self.VVWehy(self.m3uOrM3u8File)
   else:
    self.VVzxMJ()
 def VVzxMJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  global VVEbPR
  del VVEbPR
 def VV1P63(self):
  if self["myMenu"].getCurrent()[1] in ("VVJm1V", "VVcpxcPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVmFqv(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVcpxcPortal" : confItem = CFG.favServerPortal
   elif item == "VVJm1V" : confItem = CFG.favServerPlaylist
   else         : return
   FF4s3j(self, BF(self.VVvkV2, confItem), 'Remove from menu ?', title=title)
 def VVvkV2(self, confItem):
  FFE6Br(confItem, "")
  self.VV7StE()
 def VVGG6n(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVljbY
  VVZ4NM = []
  if isFav1: VVZ4NM.append((c +  "Favourite Playlist Server"   , "VVJm1V" ))
  if isFav2: VVZ4NM.append((c +  "Favourite Portal Server"    , "VVcpxcPortal" ))
  VVZ4NM.append(("IPTV Server Browser (from Playlists)"     , "VVZMH2_fromPlayList" ))
  VVZ4NM.append(("IPTV Server Browser (from Portal List)"    , "VVZMH2_fromMac"  ))
  VVZ4NM.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVZMH2_fromM3u"  ))
  qUrl, iptvRef = CCXyjP.VVCUER(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVZ4NM.append(FF1giv("IPTV Server Browser (from Current Channel)", "VVZMH2_fromCurrChan", fromCurCond))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("M3U/M3U8 File Browser"        , "VVPxjt"   ))
  if self.iptvFileAvailable:
   VVZ4NM.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(FF1giv("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVZ4NM.append(FF1giv("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVZ4NM.append(VVVvw4)
   c1, c2 = VVh9Nn, VVQzZA
   t1 = FFNr4J("auto-match names", VVljbY)
   t2 = FFNr4J("from xml file"  , VVljbY)
   VVZ4NM.append((c1 + "Count Available IPTV Channels"    , "VVNM3L"    ))
   VVZ4NM.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVZ4NM.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVb8Ov" ))
   VVZ4NM.append((VVIZs4 + "More Reference Tools ..."  , "VVEOoz"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Reload Channels and Bouquets"       , "VVvpI4"   ))
  VVZ4NM.append(VVVvw4)
  if not CCVzxd.VVG9lY():
   VVZ4NM.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVZ4NM.append(("Download Manager ... No downloads"    ,       ))
  return VVZ4NM
 def VVmPyu(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVXm9f"   : self.VVXm9f()
   elif item == "VVeW1o" : FF4s3j(self, self.VVeW1o, "Change Current List References to Unique Codes ?")
   elif item == "VVpnBG_rows" : FF4s3j(self, BF(FF1QiT, self.VVSuUg, self.VVpnBG), "Change Current List References to Identical Codes ?")
   elif item == "VVP6LC"   : self.VVP6LC(tTitle)
   elif item == "VVAJFg"   : self.VVAJFg(tTitle)
   elif item == "VVJm1V" : self.VVcpxc(False)
   elif item == "VVcpxcPortal" : self.VVcpxc(True)
   elif item == "VVZMH2_fromPlayList" : FF1QiT(self, BF(self.VVXvdf, 1), title=title)
   elif item == "VVZMH2_fromM3u"  : FF1QiT(self, BF(self.VVeoHc, CCXyjP.VVUPsA), title=title)
   elif item == "VVZMH2_fromMac"  : self.VV8DgG()
   elif item == "VVZMH2_fromCurrChan" : self.VVAytx()
   elif item == "VVPxjt"   : self.VVPxjt()
   elif item == "iptvTable_all"   : FF1QiT(self, BF(self.VV1Ldp, self.VV4OUR), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCXyjP.VVqiED(self)
   elif item == "refreshIptvPicons"  : self.VVBdBm()
   elif item == "VVNM3L"    : FF1QiT(self, self.VVNM3L)
   elif item == "copyEpgPicons"   : self.VVZVXV(False)
   elif item == "renumIptvRef_fromFile" : self.VVZVXV(True)
   elif item == "VVb8Ov" : FF4s3j(self, BF(FF1QiT, self, self.VVb8Ov), VV6LqR="Continue ?")
   elif item == "VVEOoz"    : self.VVEOoz()
   elif item == "VVvpI4"   : FF1QiT(self, BF(CCtCGd.VVvpI4, self))
   elif item == "dload_stat"    : CCVzxd.VVwpH0(self)
 def VVPxjt(self):
  if CCHRwQ.VV3TtN(self):
   FF1QiT(self, BF(self.VVeoHc, CCXyjP.VVkUjm), title="Searching ...")
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVmPyu(item)
 def VV1Ldp(self, mode):
  VVJIKO = self.VV5e1N(mode)
  if VVJIKO:
   VV8lmg = ("Current Service", self.VVWRJ3 , [])
   VV0RwZ = ("Options"  , self.VVSLoQ   , [])
   VVUpMt = ("Filter"   , self.VV5IvU   , [])
   VVFJkn  = ("Play"   , BF(self.VVfKQh)  , [])
   VVU95Y = (""    , self.VVWnBk    , [])
   VVHEpO = (""    , self.VVhgdP     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVXdZ9  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFW2Tv(self, None, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26
     , VVFJkn=VVFJkn, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVU95Y=VVU95Y, VVHEpO=VVHEpO
     , VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000", VVROQm=True, searchCol=1)
  else:
   if mode == self.VVLRvE: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF0eUf(self, err)
 def VVhgdP(self, VVSuUg, title, txt, colList):
  self.VVSuUg = VVSuUg
 def VVSLoQ(self, VVSuUg, title, txt, colList):
  VVZ4NM = []
  VVZ4NM.append(("Add Current List to a New Bouquet"    , "VVXm9f"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Current List References to Unique Codes" , "VVeW1o"))
  VVZ4NM.append(("Change Current List References to Identical Codes", "VVpnBG_rows" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Share Reference with DVB Service (manual entry)" , "VVP6LC"   ))
  VVZ4NM.append(("Share Reference with DVB Service (auto-find)"  , "VVAJFg"   ))
  FFLMiy(self, self.VVmPyu, title="IPTV Tools", VVZ4NM=VVZ4NM)
 def VV5IvU(self, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VV4FGd, VVSuUg))
 def VV4FGd(self, VVSuUg):
  VVZ4NM = []
  VVZ4NM.append(("All"         , "all"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Prefix of Selected Channel"   , "sameName" ))
  VVZ4NM.append(("Suggest Words from Selected Channel" , "partName" ))
  VVZ4NM.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVZ4NM.append(("Duplicate References"     , "depRef"  ))
  VVZ4NM.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVZ4NM.append(("Stream Relay"       , "SRelay"  ))
  VVZ4NM.append(FF2YB6("Category"))
  VVZ4NM.append(("Live TV"        , "live"  ))
  VVZ4NM.append(("VOD"         , "vod"   ))
  VVZ4NM.append(("Series"        , "series"  ))
  VVZ4NM.append(("Uncategorised"      , "uncat"  ))
  VVZ4NM.append(FF2YB6("Media"))
  VVZ4NM.append(("Video"        , "video"  ))
  VVZ4NM.append(("Audio"        , "audio"  ))
  VVZ4NM.append(FF2YB6("File Type"))
  VVZ4NM.append(("MKV"         , "MKV"   ))
  VVZ4NM.append(("MP4"         , "MP4"   ))
  VVZ4NM.append(("MP3"         , "MP3"   ))
  VVZ4NM.append(("AVI"         , "AVI"   ))
  VVZ4NM.append(("FLV"         , "FLV"   ))
  VVZ4NM.extend(CC8DHP.VVk6Tg(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVucVM, VVSuUg) if VVSuUg.VVdoWv().startswith("IPTV Filter ") else None
  filterObj = CCC0Pu(self)
  filterObj.VVfcDX(VVZ4NM, VVZ4NM, BF(self.VVurNU, VVSuUg, False), inFilterFnc=inFilterFnc)
 def VVucVM(self, VVSuUg, VVKicw, item):
  self.VVurNU(VVSuUg, True, item)
 def VVurNU(self, VVSuUg, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVSuUg.VVbc1J(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV4OUR , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVLteC , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVDXiJ , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVcQee , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVtZ7u  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV7vbS  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVHtTY  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVLRvE  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVSq3A   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV7tJL  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVKkeX  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVxfkW  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVc954  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVcuWr   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV0SyM   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVir0M   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVuFp1   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV8cOI   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVKEu3  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVag60  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVDXiJ:
   VVZ4NM = []
   chName = VVSuUg.VVbc1J(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVZ4NM.append((item, item))
    if not VVZ4NM and chName:
     VVZ4NM.append((chName, chName))
    FFLMiy(self, BF(self.VVSGfE, title), title="Words from Current Selection", VVZ4NM=VVZ4NM)
   else:
    VVSuUg.VVDnVh("Invalid Channel Name")
  else:
   words, asPrefix = CCC0Pu.VVUzJV(words)
   if not words and mode in (self.VVKEu3, self.VVag60):
    FF7BjW(self.VVSuUg, "Incorrect filter", 2000)
   else:
    FF1QiT(self.VVSuUg, BF(self.VVQXJK, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVSGfE(self, title, word=None):
  if word:
   words = [word.lower()]
   FF1QiT(self.VVSuUg, BF(self.VVQXJK, self.VVDXiJ, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVwDIq(txt):
  return "#f#11ffff00#" + txt
 def VVQXJK(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVJIKO = self.VVpgcd(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVJIKO = self.VV5e1N(mode=mode, words=words, asPrefix=asPrefix)
  if VVJIKO : self.VVSuUg.VVuO1Y(VVJIKO, title)
  else  : self.VVSuUg.VVDnVh("Not found")
 def VVpgcd(self, mode=0, words=None, asPrefix=False):
  VVJIKO = []
  for row in self.VVSuUg.VVOxLE():
   row = list(map(str.strip, row))
   chNum, chName, VVkhQ1, chType, refCode, url = row
   if self.VVVnEt(mode, refCode, FF6s8T(url).lower(), chName, words, VVkhQ1.lower(), asPrefix):
    VVJIKO.append(row)
  VVJIKO = self.VV3VFc(mode, VVJIKO)
  return VVJIKO
 def VV5e1N(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVJIKO = []
  files = CCXyjP.VVpx1z()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFBRKz(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVkhQ1 = span.group(1)
    else : VVkhQ1 = ""
    VVkhQ1_lCase = VVkhQ1.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VViSZy(chName): chNameMod = self.VVwDIq(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVkhQ1, chType + (" SRel" if FF98yX(url) else ""), refCode, url)
     if self.VVVnEt(mode, refCode, FF6s8T(url).lower(), chName, words, VVkhQ1_lCase, asPrefix):
      VVJIKO.append(row)
      chNum += 1
  VVJIKO = self.VV3VFc(mode, VVJIKO)
  return VVJIKO
 def VV3VFc(self, mode, VVJIKO):
  newRows = []
  if VVJIKO and mode == self.VVtZ7u:
   counted  = iCounter(elem[4] for elem in VVJIKO)
   for item in VVJIKO:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVJIKO
 def VVVnEt(self, mode, refCode, tUrl, chName, words, VVkhQ1_lCase, asPrefix):
  if   mode == self.VV4OUR : return True
  elif mode == self.VVtZ7u : return True
  elif mode == self.VV7vbS  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVHtTY : return FF98yX(tUrl)
  elif mode == self.VVxfkW  : return CCXyjP.VVcPlk(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVc954  : return CCXyjP.VVcPlk(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVLRvE  : return CCXyjP.VVcPlk(tUrl, compareType="live")
  elif mode == self.VVSq3A  : return CCXyjP.VVcPlk(tUrl, compareType="movie")
  elif mode == self.VV7tJL : return CCXyjP.VVcPlk(tUrl, compareType="series")
  elif mode == self.VVKkeX  : return CCXyjP.VVcPlk(tUrl, compareType="")
  elif mode == self.VVcuWr  : return CCXyjP.VVcPlk(tUrl, compareExt="mkv")
  elif mode == self.VV0SyM  : return CCXyjP.VVcPlk(tUrl, compareExt="mp4")
  elif mode == self.VVir0M  : return CCXyjP.VVcPlk(tUrl, compareExt="mp3")
  elif mode == self.VVuFp1  : return CCXyjP.VVcPlk(tUrl, compareExt="avi")
  elif mode == self.VV8cOI  : return CCXyjP.VVcPlk(tUrl, compareExt="flv")
  elif mode == self.VVLteC: return chName.lower().startswith(words[0])
  elif mode == self.VVDXiJ: return words[0] in chName.lower()
  elif mode == self.VVcQee: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVKEu3 : return words[0] == VVkhQ1_lCase
  elif mode == self.VVag60 :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVXm9f(self):
  picker = CC8DHP(self, self.VVSuUg, "Add to Bouquet", self.VVMhfa)
 def VVMhfa(self):
  chUrlLst = []
  for row in self.VVSuUg.VVOxLE():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVEOoz(self):
  t1 = FFNr4J("Bouquet" , VVQzZA)
  t2 = FFNr4J("ALL"  , VVIZs4)
  t3 = FFNr4J("Unique"  , VVh9Nn)
  t4 = FFNr4J("Identical" , VVljbY)
  VVZ4NM = []
  VVZ4NM.append((VVI2ZY + "Check System Acceptable Reference Types", "VVjQXt"))
  VVZ4NM.append(FF1giv("Check Reference Codes Format", "VVxNPb", self.iptvFileAvailable, VVI2ZY))
  VVZ4NM.append(VVVvw4)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVZ4NM.append((txt % t1, "VVDwd0" ))
  VVZ4NM.append((txt % t2, "VVJysh_all"  ))
  VVZ4NM.append(VVVvw4)
  txt = "Change %s References to %s Codes .."
  VVZ4NM.append((txt % (t1, t3), "VVZSSZ" ))
  VVZ4NM.append((txt % (t2, t3), "VVc4yj"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change %s References to %s Codes" % (t2, t4) , "VVpnBG_all"))
  VVsd1c = self.VVH2qt
  FFLMiy(self, None, width=1150, title="IPTV Reference Tools", VVZ4NM=VVZ4NM, VVsd1c=VVsd1c, VVrEme="#22002233", VVRBt6="#22001122")
 def VVH2qt(self, item=None):
  if item:
   ques = "Continue ?"
   VVKicw, txt, item, ndx = item
   if   item == "VVjQXt"    : FF1QiT(VVKicw, self.VVjQXt)
   elif item == "VVxNPb"     : FF1QiT(VVKicw, self.VVxNPb)
   elif item == "VVDwd0" : self.VVCpfw(VVKicw, self.VViG05)
   elif item == "VVJysh_all"  : self.VViG05(VVKicw, None, None)
   elif item == "VVZSSZ" : self.VVZSSZ(VVKicw, txt)
   elif item == "VVc4yj"  : FF4s3j(self, BF(self.VVc4yj , VVKicw, txt), title=txt, VV6LqR=ques)
   elif item == "VVpnBG_all"  : FF4s3j(self, BF(FF1QiT, VVKicw, self.VVpnBG), title=txt, VV6LqR=ques)
 def VViG05(self, VVKicw, bName, bPath):
  VVZ4NM = []
  for rt in CCXyjP.VV7EIo():
   VVZ4NM.append(("%s\t ... %s" % (rt, CCXyjP.VVBY0S(rt)), rt))
  FFLMiy(self, BF(self.VVga6h, VVKicw, bName, bPath), VVZ4NM=VVZ4NM, width=800, title="Change Reference Types to:")
 def VVga6h(self, VVKicw, bName, bPath, rType=None):
  if rType:
   self.VVLJti(VVKicw, bName, bPath, rType)
 def VVCpfw(self, VVKicw, fnc):
  VVZ4NM = CC8DHP.VVk6Tg()
  if VVZ4NM:
   FFLMiy(self, BF(self.VVxr9L, VVKicw, fnc), VVZ4NM=VVZ4NM, title="IPTV Bouquets", VV9pbf=True)
  else:
   FF7BjW(VVKicw, "No bouquets Found !", 1500)
 def VVxr9L(self, VVKicw, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVPxkP + span.group(1)
    if fileExists(bPath): fnc(VVKicw, bName, bPath)
    else    : FF7BjW(VVKicw, "Bouquet file not found!", 2000)
   else:
    FF7BjW(VVKicw, "Cannot process bouquet !", 2000)
 def VVLJti(self, VVKicw, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFNr4J(bName, VVde5r)
  else : title = "Change for %s" % FFNr4J("All IPTV Services", VVde5r)
  FF4s3j(self, BF(FF1QiT, VVKicw, BF(self.VVpi7Z, VVKicw, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFNr4J(rType, VVde5r), title=title)
 def VVpi7Z(self, VVKicw, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCXyjP.VVpx1z()
  if files:
   newRType = rType + ":"
   piconPath = CCk0vb.VVJcyT()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCNmp1.VV1wzQ(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FF0eUf(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFKiof("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFKiof(cmd)
  self.VVo8Fs(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVNM3L(self):
  totFiles = 0
  files  = CCXyjP.VVpx1z()
  if files:
   totFiles = len(files)
  totChans = 0
  VVJIKO = self.VV5e1N()
  if VVJIKO:
   totChans = len(VVJIKO)
  FFXEvX(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVxNPb(self):
  files = CCXyjP.VVpx1z()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFBRKz(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVhmJa
   else    : color = VVqDXM
   totInvalid = FFNr4J(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFNr4J("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFXEvX(self, txt, title="Check IPTV References")
 def VVjQXt(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCXyjP.VV7EIo()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC8DHP.VV8Ndw(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVrURN = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVrURN:
   VV5KXr = FFNTAQ(VVrURN)
   if VV5KXr:
    for service in VV5KXr:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVPxkP + userBName
  bFile = VVPxkP + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFyMLY("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFyMLY("rm -f '%s'" % path)
  FFKiof(cmd)
  FFwnFB()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVhmJa
    else     : res, color = "No" , VVqDXM
    pl = CCXyjP.VVBY0S(item)
    txt += "    %s\t: %s%s\n" % (item, FFNr4J(res, color), FFNr4J("\t... %s" % pl, VVi1yn) if pl else "")
   FFXEvX(self, txt, title=title)
  else:
   txt = FF0eUf(self, "Could not complete the test on your system!", title=title)
 def VVb8Ov(self):
  VVRxU0, err = CCtCGd.VVUq9T(self, CCtCGd.VVxb54)
  if VVRxU0:
   totChannels = 0
   totChange = 0
   for path in CCXyjP.VVpx1z():
    toSave = False
    txt = FFBRKz(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVRxU0.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVo8Fs(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF0eUf(self, 'No channels in "lamedb" !')
 def VVc4yj(self, VVKicw, title):
  bFiles = CCXyjP.VVpx1z()
  if bFiles: self.VVoSFD(bFiles, title)
  else  : FF7BjW(VVKicw, "No bouquets files !", 1500)
 def VVZSSZ(self, VVKicw, title):
  self.VVCpfw(VVKicw, BF(self.VVQl2C, title))
 def VVQl2C(self, title, VVKicw, bName, bPath):
  self.VVoSFD([bPath], title)
 def VVoSFD(self, bFiles, title):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVzrfO, bFiles)
      , VVtCUJ = BF(self.VVOahy, title))
 def VVzrfO(self, bFiles, VVx2mk):
  VVx2mk.VVgnkU = ""
  VVx2mk.VVA9ka("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFMA9m(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVx2mk or VVx2mk.isCancelled:
   return
  elif not totLines:
   VVx2mk.VVgnkU = "No IPTV Services !"
   return
  else:
   VVx2mk.VVSJhE(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVx2mk or VVx2mk.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFMA9m(path)
    for ndx, line in enumerate(lines):
     if not VVx2mk or VVx2mk.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVx2mk:
       VVx2mk.VVA9ka("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVx2mk:
       VVx2mk.VVr1vN(1)
      refCode, startId, startNS = CC8DHP.VVFxvn(rType, CC8DHP.VVb1in, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVx2mk:
        VVx2mk.VVgnkU = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVOahy(self, title, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVgnkU:
   txt += "\n\n%s\n%s" % (FFNr4J("Ended with Error:", VVqDXM), VVgnkU)
  self.VVo8Fs(True, title, txt)
 def VVeW1o(self):
  bFiles = CCXyjP.VVpx1z()
  if not bFiles:
   FF7BjW(self.VVSuUg, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVSuUg.VVOxLE():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FF7BjW(self.VVSuUg, "Cannot read list", 1500)
   return
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVbxcS, bFiles, tableRefList)
      , VVtCUJ = BF(self.VVOahy, "Change Current List References to Unique Codes"))
 def VVbxcS(self, bFiles, tableRefList, VVx2mk):
  VVx2mk.VVgnkU = ""
  VVx2mk.VVA9ka("Reading System References ...")
  refLst = CC8DHP.VVsrGs(CC8DHP.VVb1in, stripRType=True)
  if not VVx2mk or VVx2mk.isCancelled:
   return
  VVx2mk.VVSJhE(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVx2mk or VVx2mk.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFBRKz(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVx2mk or VVx2mk.isCancelled:
     return
    VVx2mk.VVA9ka("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVx2mk or VVx2mk.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVx2mk.VVr1vN(1)
      refCode, startId, startNS = CC8DHP.VVFxvn(rType, CC8DHP.VVb1in, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVx2mk:
        VVx2mk.VVgnkU = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVpnBG(self):
  list = None
  if self.VVSuUg:
   list = []
   for row in self.VVSuUg.VVOxLE():
    list.append(row[4] + row[5])
  files = CCXyjP.VVpx1z()
  totChange = 0
  if files:
   for path in files:
    lines = FFMA9m(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVo8Fs(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVo8Fs(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFwnFB()
   if refreshTable and self.VVSuUg:
    VVJIKO = self.VV5e1N()
    if VVJIKO and self.VVSuUg:
     self.VVSuUg.VVuO1Y(VVJIKO, self.tableTitle)
     self.VVSuUg.VVDnVh(txt)
   FFXEvX(self, txt, title=title)
  else:
   FFH1Ib(self, "No changes.")
 @staticmethod
 def VVpx1z(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVPxkP + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFBRKz(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVWnBk(self, VVSuUg, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FF6s8T(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFGNa7(self, fncMode=CCUr80.VVzrvO, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVcyzJ(self, VVSuUg, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVfKQh(self, VVSuUg, title, txt, colList):
  chName, chUrl = self.VVcyzJ(VVSuUg, colList)
  self.VVShYZ(VVSuUg, chName, chUrl, "localIptv")
 def VVZO8i(self, mode, VVSuUg, colList):
  chName, chUrl, picUrl, refCode = self.VVUyj3(mode, colList)
  return chName, chUrl
 def VVzgJw(self, mode, VVSuUg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVUyj3(mode, colList)
  self.VVShYZ(VVSuUg, chName, chUrl, mode)
 def VVShYZ(self, VVSuUg, chName, chUrl, playerFlag):
  chName = FFhc8v(chName)
  if self.VViSZy(chName):
   FF7BjW(VVSuUg, "This is a marker!", 300)
  else:
   FF1QiT(VVSuUg, BF(self.VV6U84, VVSuUg, chUrl, playerFlag), title="Playing ...")
 def VV6U84(self, VVSuUg, chUrl, playerFlag):
  FFzGKI(self, chUrl, VVEwyq=False)
  CCXYrc.VVRGWe(self.session, iptvTableParams=(self, VVSuUg, playerFlag))
 @staticmethod
 def VViSZy(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVWRJ3(self, VVSuUg, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if refCode:
   url1 = FF6s8T(origUrl.strip())
   for ndx, row in enumerate(VVSuUg.VVOxLE()):
    if refCode in row[4]:
     tableRow = FF6s8T(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVSuUg.VVpxIX(ndx)
      break
   else:
    FF7BjW(VVSuUg, "No found", 1000)
 def VVeoHc(self, m3uMode):
  lines = self.VVxVXf(3)
  if lines:
   lines.sort()
   VVZ4NM = []
   for line in lines:
    VVZ4NM.append((line, line))
   if m3uMode == CCXyjP.VVUPsA:
    title = "Browse Server from M3U URLs"
    VVs32w = ("All to Playlist", self.VVR1EE)
   else:
    title = "M3U/M3U8 File Browser"
    VVs32w = None
   VVsd1c = BF(self.VV2Gar, m3uMode, title)
   VVsk8Y = self.VVGn4V
   FFLMiy(self, None, title=title, VVZ4NM=VVZ4NM, width=1200, VVsd1c=VVsd1c, VVsk8Y=VVsk8Y, VVpQam="", VVs32w=VVs32w, VVrEme="#11221122", VVRBt6="#11221122")
 def VV2Gar(self, m3uMode, title, item=None):
  if item:
   VVKicw, txt, path, ndx = item
   if m3uMode == CCXyjP.VVUPsA:
    FF1QiT(VVKicw, BF(self.VVOnLO, title, path))
   else:
    FF1QiT(VVKicw, BF(self.VVWehy, path))
 def VVWehy(self, path, m3uFilterParam=None, VVSuUg=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFBRKz(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVOh99(propLine, "group-title") or "-"
   if not group == "-" and self.VVP8y8(group):
    if not chName or self.VVlWTJ(chName):
     if self.VVVnEt(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVJIKO = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVJIKO.append((name, str(tot), name))
    totAll += tot
   VVJIKO.sort(key=lambda x: x[0].lower())
   VVJIKO.insert(0, ("ALL", str(totAll), ""))
  if VVJIKO:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVSuUg:
    VVSuUg.VVuO1Y(VVJIKO, newTitle=title, VV8SPjMsg=True)
   else:
    VVQLDs = self.VVvVsc
    VVFJkn  = ("Select" , BF(self.VVG4o1, path, m3uFilterParam)  , [])
    VVUpMt = ("Filter" , BF(self.VVTIlo, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVXdZ9  = (LEFT  , CENTER , LEFT )
    FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, width= 1400, height= 1000, VVsgYf=28, VVFJkn=VVFJkn, VVUpMt=VVUpMt, VVQLDs=VVQLDs, lastFindConfigObj=CFG.lastFindIptv
      , VVrEme="#11110022", VVRBt6="#11110022", VVfKIv="#11110022", VV6z2K="#00444400")
  elif VVSuUg:
   FFVyvQ(VVSuUg, "Not found !", 1500)
  else:
   self.VV4YkU(FFBRKz(path), "", m3uFilterParam)
 def VVG4o1(self, path, m3uFilterParam, VVSuUg, title, txt, colList):
  self.VV4YkU(FFBRKz(path), colList[2], m3uFilterParam)
 def VVTIlo(self, path, m3uFilterParam, VVSuUg, title, txt, colList):
  VVZ4NM = []
  VVZ4NM.append(("All"      , "all"  ))
  VVZ4NM.append(FF2YB6("Category"))
  VVZ4NM.append(("Live TV"     , "live" ))
  VVZ4NM.append(("VOD"      , "vod"  ))
  VVZ4NM.append(("Series"     , "series" ))
  VVZ4NM.append(("Uncategorised"   , "uncat" ))
  VVZ4NM.append(FF2YB6("Media"))
  VVZ4NM.append(("Video"     , "video" ))
  VVZ4NM.append(("Audio"     , "audio" ))
  VVZ4NM.append(FF2YB6("File Type"))
  VVZ4NM.append(("MKV"      , "MKV"  ))
  VVZ4NM.append(("MP4"      , "MP4"  ))
  VVZ4NM.append(("MP3"      , "MP3"  ))
  VVZ4NM.append(("AVI"      , "AVI"  ))
  VVZ4NM.append(("FLV"      , "FLV"  ))
  filterObj = CCC0Pu(self, VVrEme="#11332244", VVRBt6="#11222244")
  filterObj.VVfcDX(VVZ4NM, [], BF(self.VVz6YC, VVSuUg, path), inFilterFnc=None)
 def VVz6YC(self, VVSuUg, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV4OUR , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVLRvE  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVSq3A  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VV7tJL  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVKkeX  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVxfkW  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVc954  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVcuWr  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VV0SyM  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVir0M  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVuFp1  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VV8cOI  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVag60  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCC0Pu.VVUzJV(words)
   if not mode == self.VV4OUR:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFNr4J(fTitle, VVi1yn)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF1QiT(VVSuUg, BF(self.VVWehy, path, m3uFilterParam, VVSuUg), title="Filtering ...")
 def VV4YkU(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVUHXh, lst, filterGroup, m3uFilterParam)
       , VVtCUJ = BF(self.VVtSPH, title, bName))
  else:
   self.VVbmJh("No valid lines found !", title)
 def VVUHXh(self, lst, filterGroup, m3uFilterParam, VVx2mk):
  VVx2mk.VVgnkU = []
  VVx2mk.VVSJhE(len(lst))
  num = 0
  for cols in lst:
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVOh99(propLine, "group-title") or "-"
   picon = self.VVOh99(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVP8y8(group) : skip = True
    elif chName and not self.VVlWTJ(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVVnEt(mode, "", FF6s8T(url).lower(), chName, words, "", asPrefix)
    if not skip and VVx2mk:
     num += 1
     VVx2mk.VVgnkU.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVtSPH(self, title, bName, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVgnkU:
   VVQLDs = self.VVvVsc
   VVFJkn  = ("Select"   , BF(self.VVJf65, title)   , [])
   VVU95Y = (""    , self.VV2rGc        , [])
   VV8lmg = ("Download PIcons", self.VVx1uo       , [])
   VV0RwZ = ("Options"  , BF(self.VV8f4T, "m3Ch", "", bName) , [])
   VVUpMt = ("Posters Mode" , BF(self.VV0r0F, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVXdZ9  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVgnkU, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VVFJkn=VVFJkn, VVQLDs=VVQLDs, VVU95Y=VVU95Y, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindIptv, VVROQm=True, searchCol=1
     , VVrEme="#0a00192B", VVRBt6="#0a00192B", VVfKIv="#0a00192B", VV6z2K="#00000000")
  else:
   self.VVbmJh("Not found !", title)
 def VVx1uo(self, VVSuUg, title, txt, colList):
  self.VVNUeI(VVSuUg, "m3u/m3u8")
 def VV68gU(self, rowNum, url, chName):
  refCode = self.VVPqZI(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFVH3K(url), chName)
  return chUrl
 def VVPqZI(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVWUPj(catID, stID, chNum)
  return refCode
 def VVOh99(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVJf65(self, Title, VVSuUg, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF1QiT(VVSuUg, BF(self.VVpP37, Title, VVSuUg, colList), title="Checking Server ...")
  else:
   self.VVbQsj(VVSuUg, url, chName)
 def VVpP37(self, title, VVSuUg, colList):
  if not CCHRwQ.VV3TtN(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCyb9m.VVLT2J(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVZ4NM = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCXyjP.VVheql(url, fPath)
     VVZ4NM.append((resol, fullUrl))
    if VVZ4NM:
     if len(VVZ4NM) > 1:
      FFLMiy(self, BF(self.VVWqF9, VVSuUg, chName), VVZ4NM=VVZ4NM, title="Resolution", VV9pbf=True, VVmNi5=True)
     else:
      self.VVbQsj(VVSuUg, VVZ4NM[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVbQsj(VVSuUg, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCXyjP.VVheql(url, span.group(1))
       self.VVbQsj(VVSuUg, fullUrl, chName)
      else:
       self.VV9Jog("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV4YkU(txt, filterGroup="")
      return
    self.VVbQsj(VVSuUg, url, chName)
   else:
    self.VVbmJh("Cannot process this channel !", title)
  else:
   self.VVbmJh(err, title)
 def VVWqF9(self, VVSuUg, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVbQsj(VVSuUg, resolUrl, chName)
 def VVbQsj(self, VVSuUg, url, chName):
  FF1QiT(VVSuUg, BF(self.VVB2Mb, VVSuUg, url, chName), title="Playing ...")
 def VVB2Mb(self, VVSuUg, url, chName):
  chUrl = self.VV68gU(VVSuUg.VVZ2t7(), url, chName)
  FFzGKI(self, chUrl, VVEwyq=False)
  CCXYrc.VVRGWe(self.session, iptvTableParams=(self, VVSuUg, "m3u/m3u8"))
 def VVMHfZ(self, VVSuUg, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV68gU(VVSuUg.VVZ2t7(), url, chName)
  return chName, chUrl
 def VV2rGc(self, VVSuUg, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFGNa7(self, fncMode=CCUr80.VVzrvO, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVbmJh(self, err, title):
  FF0eUf(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVvVsc(self, VVSuUg):
  if self.m3uOrM3u8File:
   self.close()
  VVSuUg.cancel()
 def VVR1EE(self, VVMD9SObj, item=None):
  FF1QiT(VVMD9SObj, BF(self.VVolzU, VVMD9SObj, item))
 def VVolzU(self, VVMD9SObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVMD9SObj.VVZ4NM):
    path = item[1]
    if fileExists(path):
     enc = CC9SOR.VVarly(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCXyjP.VV9BnK(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCXyjP.VVU2YN()
    pListF = "%sPlaylist_%s.txt" % (path, FFXJI8())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVMD9SObj.VVZ4NM)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFXEvX(self, txt, title=title)
   else:
    FF0eUf(self, "Could not obtain URLs from this file list !", title=title)
 def VVXvdf(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VV8CAG
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVw4hM
  lines = self.VVxVXf(mode)
  if lines:
   lines.sort()
   VVZ4NM = []
   for line in lines:
    VVZ4NM.append((FFNr4J(line, VVQzZA) if "Bookmarks" in line else line, line))
   VVsk8Y = self.VVGn4V
   FFLMiy(self, None, title=title, VVZ4NM=VVZ4NM, width=1200, VVsd1c=okFnc, VVsk8Y=VVsk8Y, VVpQam="")
 def VVGn4V(self, VVKicw, txt, ref, ndx):
  txt = ref
  sz = FFPebg(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCNmp1.VV3y2b(sz)
  FFXEvX(self, txt, title="File Path")
 def VV8CAG(self, item=None):
  if item:
   VVKicw, txt, path, ndx = item
   FF1QiT(VVKicw, BF(self.VVsNIt, VVKicw, path), title="Processing File ...")
 def VVsNIt(self, VVLUcq, path):
  enc = CC9SOR.VVarly(path, self)
  if enc == -1:
   return
  VVJIKO = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFSiyE(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXyjP.VVPSI9(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVJIKO:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVJIKO.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVJIKO:
   title = "Playlist File : %s" % os.path.basename(path)
   VVFJkn  = ("Start"    , BF(self.VVMMgK, "Playlist File")      , [])
   VVdvf0 = ("Home Menu"   , FFSv8C             , [])
   VV8lmg = ("Download M3U File" , self.VVVe5K         , [])
   VV0RwZ = ("Edit File"   , BF(self.VVXCg0, path)        , [])
   VVUpMt = ("Check & Filter"  , BF(self.VVKQ2p, VVLUcq, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVXdZ9  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVdvf0=VVdvf0, VVUpMt=VVUpMt, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVrEme="#11001116", VVRBt6="#11001116", VVfKIv="#11001116", VV6z2K="#00003635", VV7JIr="#0a333333", VVpBpY="#11331100", VVROQm=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FF0eUf(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVVe5K(self, VVSuUg, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FF4s3j(self, BF(FF1QiT, VVSuUg, BF(self.VVGQI8, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVGQI8(self, title, url):
  path, err = FFacHF(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF0eUf(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFBRKz(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFfhv3(path)
    FF0eUf(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFfhv3(path)
    FF0eUf(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCXyjP.VVU2YN() + fName
    FFKiof("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFH1Ib(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF0eUf(self, "Could not download the M3U file!", title=errTitle)
 def VVMMgK(self, Title, VVSuUg, title, txt, colList):
  url = colList[6]
  FF1QiT(VVSuUg, BF(self.VVCppJ, Title, url), title="Checking Server ...")
 def VVXCg0(self, path, VVSuUg, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCC9Tv(self, path, VVtCUJ=BF(self.VVyvIS, VVSuUg), curRowNum=rowNum)
  else    : FF7Hmv(self, path)
 def VVyvIS(self, VVSuUg, fileChanged):
  if fileChanged:
   VVSuUg.cancel()
 def VVP6LC(self, title):
  curChName = self.VVSuUg.VVbc1J(1)
  FFFMZg(self, BF(self.VVD11G, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVD11G(self, title, name):
  if name:
   VVRxU0, err = CCtCGd.VVUq9T(self, CCtCGd.VVXuY8, VVPsD9=False, VV8wkm=False)
   list = []
   if VVRxU0:
    name = self.VVsZyp(name)
    ratio = "1"
    for item in VVRxU0:
     if name in item[0].lower():
      list.append((item[0], FFmcAD(item[2]), item[3], ratio))
   if list : self.VVXHZf(list, title)
   else : FF0eUf(self, "Not found:\n\n%s" % name, title=title)
 def VVAJFg(self, title):
  curChName = self.VVSuUg.VVbc1J(1)
  self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVko9l
      , VVtCUJ = BF(self.VVkNLF, title, curChName))
 def VVko9l(self, VVx2mk):
  curChName = self.VVSuUg.VVbc1J(1)
  VVRxU0, err = CCtCGd.VVUq9T(self, CCtCGd.VVPk5I, VVPsD9=False, VV8wkm=False)
  if not VVRxU0 or not VVx2mk or VVx2mk.isCancelled:
   return
  VVx2mk.VVgnkU = []
  VVx2mk.VVSJhE(len(VVRxU0))
  curCh = self.VVsZyp(curChName)
  for refCode in VVRxU0:
   chName, sat, inDB = VVRxU0.get(refCode, ("", "", 0))
   ratio = CCk0vb.VVNY6A(chName.lower(), curCh)
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1, True)
   if VVx2mk and ratio > 50:
    VVx2mk.VVgnkU.append((chName, FFmcAD(sat), refCode.replace("_", ":"), str(ratio)))
 def VVkNLF(self, title, curChName, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVgnkU: self.VVXHZf(VVgnkU, title)
  elif VVGvWA: FF0eUf(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVXHZf(self, VVJIKO, title):
  curChName = self.VVSuUg.VVbc1J(1)
  VVoLlM = self.VVSuUg.VVbc1J(4)
  curUrl  = self.VVSuUg.VVbc1J(5)
  VVJIKO.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVFJkn  = ("Share Sat/C/T Ref.", BF(self.VV52Z7, title, curChName, VVoLlM, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVrEme="#0a00112B", VVRBt6="#0a001126", VVfKIv="#0a001126", VV6z2K="#00000000")
 def VV52Z7(self, newtitle, curChName, VVoLlM, curUrl, VVSuUg, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVoLlM, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF4s3j(self.VVSuUg, BF(FF1QiT, self.VVSuUg, BF(self.VVBUEB, VVSuUg, data)), ques, title=newtitle, VViggQ=True)
 def VVBUEB(self, VVSuUg, data):
  VVSuUg.cancel()
  title, curChName, VVoLlM, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVoLlM = VVoLlM.strip()
  newRefCode = newRefCode.strip()
  if not VVoLlM.endswith(":") : VVoLlM += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVoLlM, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVoLlM + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCXyjP.VVpx1z():
    txt = FFBRKz(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFwnFB()
    newRow = []
    for i in range(6):
     newRow.append(self.VVSuUg.VVbc1J(i))
    newRow[4] = newRefCode
    done = self.VVSuUg.VVgAJR(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFdw1m(BF(FFH1Ib , self, resTxt, title=title))
  elif resErr: FFdw1m(BF(FF0eUf, self, resErr, title=title))
 def VVKQ2p(self, VVLUcq, path, VVSuUg, title, txt, colList):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVBqeL, VVSuUg)
      , VVtCUJ = BF(self.VVpiFY, VVLUcq, path, VVSuUg))
 def VVBqeL(self, VVSuUg, VVx2mk):
  VVx2mk.VVSJhE(VVSuUg.VVdq0g())
  VVx2mk.VVgnkU = []
  for row in VVSuUg.VVOxLE():
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1, True)
   qUrl = self.VVCM1C(self.VVu07k, row[6])
   txt, err = self.VVmPHt(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVCv0w(item, "auth") == "0":
       VVx2mk.VVgnkU.append(qUrl)
    except:
     pass
 def VVpiFY(self, VVLUcq, path, VVSuUg, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVGvWA:
   list = VVgnkU
   title = "Authorized Servers"
   if list:
    totChk = VVSuUg.VVdq0g()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFXJI8()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVXvdf(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFNr4J(str(totAuth), VVhmJa)
     txt += "%s\n\n%s"    %  (FFNr4J("Result File:", VVQzZA), newPath)
     FFXEvX(self, txt, title=title)
     VVSuUg.close()
     VVLUcq.close()
    else:
     FFH1Ib(self, "All URLs are authorized.", title=title)
   else:
    FF0eUf(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVmPHt(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVPSI9(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVcPlk(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCid1U.VVyaUp()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVicib(decodedUrl):
  return CCXyjP.VVcPlk(decodedUrl, justRetDotExt=True)
 def VVCM1C(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVPSI9(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVu07k   : return "%s"            % url
  elif mode == self.VVQNZo   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVshXk   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVw4lF  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVHzHe  : return "%s&action=get_live_categories"     % url
  elif mode == self.VV6mU6 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVTtCS   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVmoqv    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVoBR2  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVFYqE : return "%s&action=get_live_streams"      % url
  elif mode == self.VVF2dq  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVCv0w(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFmWOg(int(val))
    elif is_base64 : val = FFO3Nz(val)
    elif isToHHMMSS : val = FFaFw5(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVOnLO(self, title, path):
  if fileExists(path):
   enc = CC9SOR.VVarly(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCXyjP.VV9BnK(line)
     if qUrl:
      break
   if qUrl : self.VVCppJ(title, qUrl)
   else : FF0eUf(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF0eUf(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVAytx(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCXyjP.VVCUER(self)
  if qUrl or "chCode" in iptvRef:
   p = CCyb9m()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVbuBi(iptvRef)
   if valid:
    self.VV29vw(self, host, mac)
    return
   elif qUrl:
    FF1QiT(self, BF(self.VVCppJ, title, qUrl), title="Checking Server ...")
    return
  FF0eUf(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVCUER(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF)
  qUrl = CCXyjP.VV9BnK(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VV9BnK(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVCppJ(self, title, url):
  self.curUrl = url
  self.VVZMH2Data = {}
  qUrl = self.VVCM1C(self.VVu07k, url)
  txt, err = self.VVmPHt(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVZMH2Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVZMH2Data["username"    ] = self.VVCv0w(item, "username"        )
    self.VVZMH2Data["password"    ] = self.VVCv0w(item, "password"        )
    self.VVZMH2Data["message"    ] = self.VVCv0w(item, "message"        )
    self.VVZMH2Data["auth"     ] = self.VVCv0w(item, "auth"         )
    self.VVZMH2Data["status"    ] = self.VVCv0w(item, "status"        )
    self.VVZMH2Data["exp_date"    ] = self.VVCv0w(item, "exp_date"    , isDate=True )
    self.VVZMH2Data["is_trial"    ] = self.VVCv0w(item, "is_trial"        )
    self.VVZMH2Data["active_cons"   ] = self.VVCv0w(item, "active_cons"       )
    self.VVZMH2Data["created_at"   ] = self.VVCv0w(item, "created_at"   , isDate=True )
    self.VVZMH2Data["max_connections"  ] = self.VVCv0w(item, "max_connections"      )
    self.VVZMH2Data["allowed_output_formats"] = self.VVCv0w(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVZMH2Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVZMH2Data["url"    ] = self.VVCv0w(item, "url"        )
    self.VVZMH2Data["port"    ] = self.VVCv0w(item, "port"        )
    self.VVZMH2Data["https_port"  ] = self.VVCv0w(item, "https_port"      )
    self.VVZMH2Data["server_protocol" ] = self.VVCv0w(item, "server_protocol"     )
    self.VVZMH2Data["rtmp_port"   ] = self.VVCv0w(item, "rtmp_port"       )
    self.VVZMH2Data["timezone"   ] = self.VVCv0w(item, "timezone"       )
    self.VVZMH2Data["timestamp_now"  ] = self.VVCv0w(item, "timestamp_now"  , isDate=True )
    self.VVZMH2Data["time_now"   ] = self.VVCv0w(item, "time_now"       )
    VVZ4NM  = self.VVbYdd(True)
    VVsd1c = self.VVkgSl
    VVsk8Y = self.VVH53C
    VV6rAJ = ("Home Menu", FFSv8C)
    VVcrQj= ("Add to Menu", BF(CCXyjP.VVoEwj, self, False, self.VVZMH2Data["playListURL"]))
    VVs32w = ("Bookmark Server", BF(CCXyjP.VVNEFe, self, False, self.VVZMH2Data["playListURL"]))
    FFLMiy(self, None, title="IPTV Server Resources", VVZ4NM=VVZ4NM, VVsd1c=VVsd1c, VVsk8Y=VVsk8Y, VV6rAJ=VV6rAJ, VVcrQj=VVcrQj, VVs32w=VVs32w)
   else:
    err = "Could not get data from server !"
  if err:
   FF0eUf(self, err, title=title)
  FF7BjW(self)
 def VVkgSl(self, item=None):
  if item:
   VVKicw, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF1QiT(VVKicw, BF(self.VVETfQ, self.VVQNZo  , title=title), title=wTxt)
   elif ref == "vod"   : FF1QiT(VVKicw, BF(self.VVETfQ, self.VVshXk  , title=title), title=wTxt)
   elif ref == "series"  : FF1QiT(VVKicw, BF(self.VVETfQ, self.VVw4lF , title=title), title=wTxt)
   elif ref == "catchup"  : FF1QiT(VVKicw, BF(self.VVETfQ, self.VVHzHe , title=title), title=wTxt)
   elif ref == "accountInfo" : FF1QiT(VVKicw, BF(self.VVxWNs           , title=title), title=wTxt)
 def VVH53C(self, VVKicw, txt, ref, ndx):
  FF1QiT(VVKicw, self.VV5HiX)
 def VV5HiX(self):
  txt = self.curUrl
  if VVFBr8:
   ver, err = self.VVWROM(self.VVfS2S())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVxyZC
   txt += "PHP\t: %s\n"  % self.VVV9Sr
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVjAKD, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFXEvX(self, txt, title="Current Server URL")
 def VVxWNs(self, title):
  rows = []
  for key, val in self.VVZMH2Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVHJaj
   else:
    num, part = "1", self.VVYmIy
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVdvf0  = ("Home Menu", FFSv8C, [])
  VV8lmg  = None
  if VVFBr8:
   VV8lmg = ("Get JS" , BF(self.VVTE8H, "/".join(self.VVZMH2Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFW2Tv(self, None, title=title, width=1200, header=header, VVDpqo=rows, VVQT0l=widths, VVsgYf=26, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000", searchCol=2)
 def VV4BUW(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVTtCS, self.VVF2dq):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVCv0w(item, "num"         )
      name     = self.VVCv0w(item, "name"        )
      stream_id    = self.VVCv0w(item, "stream_id"       )
      stream_icon    = self.VVCv0w(item, "stream_icon"       )
      epg_channel_id   = self.VVCv0w(item, "epg_channel_id"      )
      added     = self.VVCv0w(item, "added"    , isDate=True )
      is_adult    = self.VVCv0w(item, "is_adult"       )
      category_id    = self.VVCv0w(item, "category_id"       )
      tv_archive    = self.VVCv0w(item, "tv_archive"       )
      direct_source   = self.VVCv0w(item, "direct_source"      )
      tv_archive_duration  = self.VVCv0w(item, "tv_archive_duration"     )
      name = self.VVlWTJ(name, is_adult)
      if name:
       if mode == self.VVTtCS or mode == self.VVF2dq and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVmoqv:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVCv0w(item, "num"         )
      name    = self.VVCv0w(item, "name"        )
      stream_id   = self.VVCv0w(item, "stream_id"       )
      stream_icon   = self.VVCv0w(item, "stream_icon"       )
      added    = self.VVCv0w(item, "added"    , isDate=True )
      is_adult   = self.VVCv0w(item, "is_adult"       )
      category_id   = self.VVCv0w(item, "category_id"       )
      container_extension = self.VVCv0w(item, "container_extension"     ) or "mp4"
      name = self.VVlWTJ(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVoBR2:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVCv0w(item, "num"        )
      name    = self.VVCv0w(item, "name"       )
      series_id   = self.VVCv0w(item, "series_id"      )
      cover    = self.VVCv0w(item, "cover"       )
      genre    = self.VVCv0w(item, "genre"       )
      episode_run_time = self.VVCv0w(item, "episode_run_time"    )
      category_id   = self.VVCv0w(item, "category_id"      )
      container_extension = self.VVCv0w(item, "container_extension"    ) or "mp4"
      name = self.VVlWTJ(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVETfQ(self, mode, title):
  cList, err = self.VVpncQ(mode)
  if cList and mode == self.VVHzHe:
   cList = self.VVDPnU(cList)
  if err:
   FF0eUf(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH(mode)
   mName = self.VVk6fD(mode)
   if   mode == self.VVQNZo  : fMode = self.VVTtCS
   elif mode == self.VVshXk  : fMode = self.VVmoqv
   elif mode == self.VVw4lF : fMode = self.VVoBR2
   elif mode == self.VVHzHe : fMode = self.VVF2dq
   if mode == self.VVHzHe:
    VV0RwZ = None
    VVUpMt = None
   else:
    VV0RwZ = ("Find in %s" % mName , BF(self.VV8HcM, fMode, True) , [])
    VVUpMt = ("Find in Selected" , BF(self.VV8HcM, fMode, False) , [])
   VVFJkn   = ("Show List"   , BF(self.VVxwHq, mode)  , [])
   VVdvf0  = ("Home Menu"   , FFSv8C         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFW2Tv(self, None, title=title, width=1200, header=header, VVDpqo=cList, VVQT0l=widths, VVsgYf=30, VVdvf0=VVdvf0, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVFJkn=VVFJkn, VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF0eUf(self, "No list from server !", title=title)
  FF7BjW(self)
 def VVpncQ(self, mode):
  qUrl  = self.VVCM1C(mode, self.VVZMH2Data["playListURL"])
  txt, err = self.VVmPHt(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVCv0w(item, "category_id"  )
     category_name = self.VVCv0w(item, "category_name" )
     parent_id  = self.VVCv0w(item, "parent_id"  )
     category_name = self.VVP8y8(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVDPnU(self, catList):
  mode  = self.VVF2dq
  qUrl  = self.VVCM1C(mode, self.VVZMH2Data["playListURL"])
  txt, err = self.VVmPHt(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV4BUW(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVxwHq(self, mode, VVSuUg, title, txt, colList):
  title = colList[1]
  FF1QiT(VVSuUg, BF(self.VVrUpG, mode, VVSuUg, title, txt, colList), title="Downloading ...")
 def VVrUpG(self, mode, VVSuUg, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVk6fD(mode) + " : "+ bName
  if   mode == self.VVQNZo  : mode = self.VVTtCS
  elif mode == self.VVshXk  : mode = self.VVmoqv
  elif mode == self.VVw4lF : mode = self.VVoBR2
  elif mode == self.VVHzHe : mode = self.VVF2dq
  qUrl  = self.VVCM1C(mode, self.VVZMH2Data["playListURL"], catID)
  txt, err = self.VVmPHt(qUrl)
  list  = []
  if not err and mode in (self.VVTtCS, self.VVmoqv, self.VVoBR2, self.VVF2dq):
   list, err = self.VV4BUW(mode, txt)
  if err:
   FF0eUf(self, err, title=title)
  elif list:
   VVdvf0  = ("Home Menu"   , FFSv8C            , [])
   if mode in (self.VVTtCS, self.VVF2dq):
    VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH(mode)
    VVU95Y = (""     , BF(self.VVYvr5, mode)      , [])
    VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, "", "")   , [])
    VV0RwZ = ("Options"   , BF(self.VV8f4T, "lv", mode, bName)   , [])
    VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, False)     , [])
    if mode == self.VVTtCS:
     VVFJkn = ("Play"    , BF(self.VVzgJw, mode)       , [])
    else:
     VVFJkn = ("Programs"   , BF(self.VVHJON, mode, bName) , [])
   elif mode == self.VVmoqv:
    VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH(mode)
    VVFJkn  = ("Play"    , BF(self.VVzgJw, mode)       , [])
    VVU95Y = (""     , BF(self.VVYvr5, mode)      , [])
    VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, "v", "")   , [])
    VV0RwZ = ("Options"   , BF(self.VV8f4T, "v", mode, bName)   , [])
    VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, False)     , [])
   elif mode == self.VVoBR2:
    VVrEme, VVRBt6, VVfKIv, VV6z2K = self.VVysIH("series2")
    VVFJkn  = ("Show Seasons"  , BF(self.VVV3Au, mode)       , [])
    VVU95Y = (""     , BF(self.VVFUXh, mode)     , [])
    VV8lmg = None
    VV0RwZ = None
    VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, True)      , [])
   header, widths, VVXdZ9 = self.VVdEyH(mode)
   FFW2Tv(self, None, title=title, header=header, VVDpqo=list, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindIptv, VVU95Y=VVU95Y, VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K, VVROQm=True, searchCol=1)
  else:
   FF0eUf(self, "No Channels found !", title=title)
  FF7BjW(self)
 def VVdEyH(self, mode):
  if mode in (self.VVTtCS, self.VVF2dq):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVXdZ9  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVmoqv:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVXdZ9  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVoBR2:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVXdZ9  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVXdZ9
 def VVHJON(self, mode, bName, VVSuUg, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVZMH2Data["playListURL"]
  ok_fnc  = BF(self.VV5vQ6, hostUrl, chName, catId, streamId)
  FF1QiT(VVSuUg, BF(CCXyjP.VVosC7, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV5vQ6(self, chUrl, chName, catId, streamId, VVSuUg, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXyjP.VVPSI9(chUrl)
   chNum = "333"
   refCode = CCXyjP.VVWUPj(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFzGKI(self, chUrl, VVEwyq=False)
   CCXYrc.VVRGWe(self.session)
  else:
   FF0eUf(self, "Incorrect Timestamp", pTitle)
 def VVV3Au(self, mode, VVSuUg, title, txt, colList):
  title = colList[1]
  FF1QiT(VVSuUg, BF(self.VVgrC8, mode, VVSuUg, title, txt, colList), title="Downloading ...")
 def VVgrC8(self, mode, VVSuUg, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVCM1C(self.VV6mU6, self.VVZMH2Data["playListURL"], series_id)
  txt, err = self.VVmPHt(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVCv0w(tDict["info"], "name"   )
      category_id = self.VVCv0w(tDict["info"], "category_id" )
      icon  = self.VVCv0w(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVCv0w(EP, "id"     )
        episode_num   = self.VVCv0w(EP, "episode_num"   )
        epTitle    = self.VVCv0w(EP, "title"     )
        container_extension = self.VVCv0w(EP, "container_extension" )
        seasonNum   = self.VVCv0w(EP, "season"    )
        epTitle = self.VVlWTJ(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF0eUf(self, err, title=title)
  elif list:
   VVdvf0 = ("Home Menu"   , FFSv8C          , [])
   VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, "s", title), [])
   VV0RwZ = ("Options"   , BF(self.VV8f4T, "s", mode, title) , [])
   VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, False)   , [])
   VVU95Y = (""     , BF(self.VVYvr5, mode)    , [])
   VVFJkn  = ("Play"    , BF(self.VVzgJw, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVXdZ9  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFW2Tv(self, None, title=title, header=header, VVDpqo=list, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, lastFindConfigObj=CFG.lastFindIptv, VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000")
  else:
   FF0eUf(self, "No Channels found !", title=title)
  FF7BjW(self)
 def VV8HcM(self, mode, isAll, VVSuUg, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVZ4NM = []
  VVZ4NM.append(("Keyboard"  , "manualEntry"))
  VVZ4NM.append(("From Filter" , "fromFilter"))
  FFLMiy(self, BF(self.VVl561, VVSuUg, mode, onlyCatID), title="Input Type", VVZ4NM=VVZ4NM, width=400)
 def VVl561(self, VVSuUg, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFFMZg(self, BF(self.VVBu8B, VVSuUg, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCC0Pu(self)
    filterObj.VVX9no(BF(self.VVBu8B, VVSuUg, mode, onlyCatID))
 def VVBu8B(self, VVSuUg, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFE6Br(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCC0Pu.VVUzJV(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FF0eUf(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FF0eUf(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVbuji(words):
      FF0eUf(self, self.VVhCny(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVpctw, VVSuUg, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVtCUJ = BF(self.VVapW6, mode, toFind, title))
   if not words:
    FF7BjW(VVSuUg, "Nothing to find !", 1500)
 def VVpctw(self, VVSuUg, mode, onlyCatID, title, words, toFind, asPrefix, VVx2mk):
  VVx2mk.VVSJhE(VVSuUg.VVmUCw() if onlyCatID is None else 1)
  VVx2mk.VVgnkU = []
  for row in VVSuUg.VVOxLE():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVr1vN(1)
   VVx2mk.VVz7WV(catName)
   qUrl  = self.VVCM1C(mode, self.VVZMH2Data["playListURL"], catID)
   txt, err = self.VVmPHt(qUrl)
   if not err:
    tList, err = self.VV4BUW(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVlWTJ(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVx2mk or VVx2mk.isCancelled:
        return
       VVx2mk.VVgnkU.append(item)
       VVx2mk.VVz7WV(catName)
 def VVapW6(self, mode, toFind, title, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVgnkU:
   title = self.VVuBbU(mode, toFind)
   if mode == self.VVTtCS or mode == self.VVmoqv:
    if mode == self.VVmoqv : typ = "v"
    else          : typ = ""
    bName   = CCXyjP.VVafKo(toFind)
    VVFJkn  = ("Play"     , BF(self.VVzgJw, mode)     , [])
    VV8lmg = ("Download Options" , BF(self.VVFkBW, mode, typ, "") , [])
    VV0RwZ = ("Options"   , BF(self.VV8f4T, "fnd", mode, bName), [])
    VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, False)   , [])
    VVU95Y = (""     , BF(self.VVYvr5, mode)    , [])
   elif mode == self.VVoBR2:
    VVFJkn  = ("Show Seasons"  , BF(self.VVV3Au, mode)     , [])
    VV0RwZ = None
    VV8lmg = None
    VVUpMt = ("Posters Mode"  , BF(self.VV0r0F, mode, True)    , [])
    VVU95Y = (""     , BF(self.VVFUXh, mode)   , [])
   VVdvf0  = ("Home Menu"   , FFSv8C          , [])
   header, widths, VVXdZ9 = self.VVdEyH(mode)
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVgnkU, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVU95Y=VVU95Y, VVrEme="#0a00292B", VVRBt6="#0a002126", VVfKIv="#0a002126", VV6z2K="#00000000", VVROQm=True, searchCol=1)
   if not VVGvWA:
    FF7BjW(VVSuUg, "Stopped" , 1000)
  else:
   if VVGvWA:
    FF0eUf(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVUyj3(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVTtCS, self.VVF2dq):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVmoqv:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFhc8v(chName)
  url = self.VVZMH2Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVPSI9(url)
  refCode = self.VVWUPj(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVYvr5(self, mode, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVg3cu, mode, VVSuUg, title, txt, colList))
 def VVg3cu(self, mode, VVSuUg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVUyj3(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFGNa7(self, fncMode=CCUr80.VVUJsd, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVFUXh(self, mode, VVSuUg, title, txt, colList):
  FF1QiT(VVSuUg, BF(self.VVQAKy, mode, VVSuUg, title, txt, colList))
 def VVQAKy(self, mode, VVSuUg, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFGNa7(self, fncMode=CCUr80.VVc5Nc, chName=name, text=txt, picUrl=Cover)
 def VV0r0F(self, mode, isSerNames, VVSuUg, title, txt, colList):
  if   mode in ("itv"  , CCXyjP.VVTtCS, CCXyjP.VVF2dq): category = "live"
  elif mode in ("vod"  , CCXyjP.VVmoqv )          : category = "vod"
  elif mode in ("series" , CCXyjP.VVoBR2)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVTtCS : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVF2dq : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVmoqv  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVoBR2 : picCol, descCol, descTxt = 5, 0, "Season"
  FF1QiT(VVSuUg, BF(self.session.open, CCmDNC, VVSuUg, category, nameCol, picCol, descCol, descTxt))
 def VVFkBW(self, mode, typ, seriesName, VVSuUg, title, txt, colList):
  VVZ4NM = []
  isMulti = VVSuUg.VVJZs5
  tot  = VVSuUg.VVv1D2()
  if isMulti:
   if tot < 1:
    FF7BjW(VVSuUg, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVZ4NM.append(("Download %s PIcon%s" % (name, FF1OOs(tot)), "dnldPicons" ))
  if typ:
   VVZ4NM.append(VVVvw4)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVZ4NM.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVZ4NM.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVZ4NM.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCVzxd.VVG9lY():
    VVZ4NM.append(VVVvw4)
    VVZ4NM.append(("Download Manager"      , "dload_stat" ))
  FFLMiy(self, BF(self.VVA7Nj, VVSuUg, mode, typ, seriesName, colList), title="Download Options", VVZ4NM=VVZ4NM)
 def VVA7Nj(self, VVSuUg, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVNUeI(VVSuUg, mode)
   elif item == "dnldSel"  : self.VVREta(VVSuUg, mode, typ, colList, True)
   elif item == "addSel"  : self.VVREta(VVSuUg, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVj2L9(VVSuUg, mode, typ, seriesName)
   elif item == "dload_stat" : CCVzxd.VVwpH0(self, VVSuUg)
 def VVREta(self, VVSuUg, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVpBEw(mode, typ, colList)
  if startDnld:
   CCVzxd.VVxN16(self, decodedUrl)
  else:
   self.VVjiTE(VVSuUg, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVj2L9(self, VVSuUg, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVSuUg.VVOxLE():
   chName, decodedUrl = self.VVpBEw(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVjiTE(VVSuUg, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVjiTE(self, VVSuUg, title, chName, decodedUrl_list, startDnld):
  FF4s3j(self, BF(self.VVSAeX, VVSuUg, decodedUrl_list, startDnld), chName, title=title)
 def VVSAeX(self, VVSuUg, decodedUrl_list, startDnld):
  added, skipped = CCVzxd.VVhJPd(decodedUrl_list)
  FF7BjW(VVSuUg, "Added", 1000)
 def VVpBEw(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVUyj3(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, colList)
   refCode, chUrl = self.VVJxQi(self.VVxyZC, self.VVo4zE, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFsUIS(chUrl)
  return chName, decodedUrl
 def VVNUeI(self, VVSuUg, mode):
  if FF4wzI("ffmpeg"):
   self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVaqSb, VVSuUg, mode)
       , VVtCUJ = self.VVelYi)
  else:
   FF4s3j(self, BF(CCXyjP.VVHyaR, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVelYi(self, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVgnkU["proces"], VVgnkU["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVgnkU["ok"], VVgnkU["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVgnkU["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVgnkU["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVgnkU["badURL"]
  txt += "Download Failure\t: %d\n"   % VVgnkU["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVgnkU["path"]
  if not VVGvWA  : color = "#11402000"
  elif VVgnkU["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVgnkU["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVgnkU["err"], txt)
  title = "PIcons Download Result"
  if not VVGvWA:
   title += "  (cancelled)"
  FFXEvX(self, txt, title=title, VVfKIv=color)
 def VVaqSb(self, VVSuUg, mode, VVx2mk):
  isMulti = VVSuUg.VVJZs5
  if isMulti : totRows = VVSuUg.VVv1D2()
  else  : totRows = VVSuUg.VVmUCw()
  VVx2mk.VVSJhE(totRows)
  VVx2mk.VVNVMA(0)
  counter     = VVx2mk.counter
  maxValue    = VVx2mk.maxValue
  pPath     = CCk0vb.VVJcyT()
  VVx2mk.VVgnkU = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVSuUg.VVOxLE()):
    if VVx2mk.isCancelled:
     break
    if not isMulti or VVSuUg.VVpoRJ(rowNum):
     VVx2mk.VVgnkU["proces"] += 1
     VVx2mk.VVr1vN(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, row)
      refCode = CCXyjP.VVWUPj(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVPqZI(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVUyj3(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVx2mk.VVgnkU["attempt"] += 1
       path, err = FFacHF(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVx2mk:
         VVx2mk.VVgnkU["ok"] += 1
         VVx2mk.VVNVMA(VVx2mk.VVgnkU["ok"])
        if FFPebg(path) > 0:
         cmd = CCUr80.VV293l(path)
         cmd += FFyMLY("mv -f '%s' '%s'" % (path, pPath))
         FFKiof(cmd)
        else:
         if VVx2mk:
          VVx2mk.VVgnkU["size0"] += 1
         FFfhv3(path)
       elif err:
        if VVx2mk:
         VVx2mk.VVgnkU["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVx2mk:
          VVx2mk.VVgnkU["err"] = err.title()
         break
      else:
       if VVx2mk:
        VVx2mk.VVgnkU["exist"] += 1
     else:
      if VVx2mk:
       VVx2mk.VVgnkU["badURL"] += 1
  except:
   pass
 def VVBdBm(self):
  title = "Download PIcons for Current Bouquet"
  if FF4wzI("ffmpeg"):
   self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
       , titlePrefix = ""
       , fncToRun  = self.VV3JZp
       , VVtCUJ = BF(self.VVefKw, title))
  else:
   FF4s3j(self, BF(CCXyjP.VVHyaR, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VV3JZp(self, VVx2mk):
  bName = CC8DHP.VVeKWz()
  pPath = CCk0vb.VVJcyT()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVx2mk.VVgnkU = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC8DHP.VV01Y3()
  if not VVx2mk or VVx2mk.isCancelled:
   return
  if not services or len(services) == 0:
   VVx2mk.VVgnkU = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVx2mk.VVSJhE(totCh)
  VVx2mk.VVNVMA(0)
  for serv in services:
   if not VVx2mk or VVx2mk.isCancelled:
    return
   VVx2mk.VVgnkU = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVx2mk.VVr1vN(1)
   VVx2mk.VVNVMA(totPic)
   fullRef  = serv[0]
   if FFBV7X(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFsUIS(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCyb9m.VVuQpK(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCXyjP.VVmPHt(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCUr80.VVihEd(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFacHF(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVx2mk:
     VVx2mk.VVNVMA(totPic)
    if FFPebg(path) > 0:
     cmd = CCUr80.VV293l(path)
     cmd += FFyMLY("mv -f '%s' '%s'" % (path, pPath))
     FFKiof(cmd)
     totPicOK += 1
    else:
     totSize0
     FFfhv3(path)
  if VVx2mk:
   VVx2mk.VVgnkU = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVefKw(self, title, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVgnkU
  if err:
   FF0eUf(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFNr4J(str(totExist)  , VVqDXM)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFNr4J(str(totNotIptv)  , VVqDXM)
    if totServErr : txt += "Server Errors\t: %s\n" % FFNr4J(str(totServErr) + t1, VVqDXM)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFNr4J(str(totParseErr) , VVqDXM)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFNr4J(str(totInvServ)  , VVqDXM)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFNr4J(str(totInvPicUrl) , VVqDXM)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFNr4J(str(totSize0)  , VVqDXM)
   if not VVGvWA:
    title += "  (stopped)"
   FFXEvX(self, txt, title=title)
 @staticmethod
 def VVHyaR(SELF):
  cmd = FF2pmn(VVLJqS, "ffmpeg")
  if cmd : FFxjL4(SELF, cmd, title="Installing FFmpeg")
  else : FFPXac(SELF)
 @staticmethod
 def VVqiED(SELF):
  SELF.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX
      , titlePrefix = ""
      , fncToRun  = CCXyjP.VVjDbZ
      , VVtCUJ = BF(CCXyjP.VVX4g0, SELF))
 @staticmethod
 def VVjDbZ(VVx2mk):
  bName = CC8DHP.VVeKWz()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVx2mk.VVgnkU = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC8DHP.VV01Y3()
  if not VVx2mk or VVx2mk.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVx2mk.VVSJhE(totCh)
   for serv in services:
    if not VVx2mk or VVx2mk.isCancelled:
     return
    VVx2mk.VVr1vN(1)
    fullRef = serv[0]
    if FFBV7X(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFsUIS(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCyb9m.VVz6iF(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCXyjP.VVJBcL(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVx2mk:
      VVx2mk.VVLJUS(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCh6kb.VVpizh(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVx2mk:
     VVx2mk.VVgnkU = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVx2mk.VVgnkU = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVX4g0(SELF, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVgnkU
  title = "IPTV EPG Import"
  if err:
   FF0eUf(SELF, err, title=title)
  else:
   if VVGvWA and totEpgOK > 0:
    CCh6kb.VVB7El()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFNr4J(str(totNotIptv), VVqDXM)
    if totServErr : txt += "Server Errors\t: %s\n" % FFNr4J(str(totServErr) + t1, VVqDXM)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFNr4J(str(totInv), VVqDXM)
   if not VVGvWA:
    title += "  (stopped)"
   FFXEvX(SELF, txt, title=title)
 @staticmethod
 def VVJBcL(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXyjP.VVPSI9(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCXyjP.VVmPHt(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCXyjP.VVCv0w(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCXyjP.VVCv0w(item, "lang"        ).upper()
    now_playing   = CCXyjP.VVCv0w(item, "now_playing"      )
    start    = CCXyjP.VVCv0w(item, "start"        )
    start_timestamp  = CCXyjP.VVCv0w(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCXyjP.VVCv0w(item, "start_timestamp"     )
    stop_timestamp  = CCXyjP.VVCv0w(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCXyjP.VVCv0w(item, "stop_timestamp"      )
    tTitle    = CCXyjP.VVCv0w(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVWUPj(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCXyjP.VVgA9k(catID, MAX_4b)
  TSID = CCXyjP.VVgA9k(chNum, MAX_4b)
  ONID = CCXyjP.VVgA9k(chNum, MAX_4b)
  NS  = CCXyjP.VVgA9k(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVgA9k(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVafKo(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVysIH(mode):
  if   mode in ("itv"  , CCXyjP.VVQNZo)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCXyjP.VVshXk)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCXyjP.VVw4lF) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCXyjP.VVHzHe) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCXyjP.VVF2dq    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVxVXf(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVCAF9:
   excl = FFhDaE(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FF0eUf(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFtLFA('find %s %s %s' % (path, excl, par))
  if files:
   err = CCNmp1.VVUj2E(files)
   if err : FF0eUf(self, err + FFNr4J('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVQzZA))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FF0eUf(self, err)
  return []
 @staticmethod
 def VVU2YN():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFSiyE(path)
  return "/"
 @staticmethod
 def VVosC7(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCXyjP.VVJBcL(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FF0eUf(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVrEme, VVRBt6, VVfKIv, VV6z2K = CCXyjP.VVysIH("")
   VVdvf0 = ("Home Menu" , FFSv8C, [])
   VVFJkn  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVXdZ9  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFW2Tv(SELF, None, title="Programs for : " + chName, header=header, VVDpqo=pList, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=24, VVFJkn=VVFJkn, VVdvf0=VVdvf0, VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K)
  else:
   FF0eUf(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVheql(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVoEwj(self, isPortal, line, VVMD9SObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FF4s3j(self, BF(self.VVFlSX, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFE6Br(confItem, line)
   FFH1Ib(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVFlSX(self, title, confItem):
  FFE6Br(confItem, "")
  FFH1Ib(self, "Removed from IPTV Menu.", title=title)
 def VVcpxc(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VV29vw(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF1QiT(self, BF(self.VVCppJ, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FF0eUf(self, "Incorrect server data !")
 @staticmethod
 def VVNEFe(SELF, isPortal, line, VVMD9SObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCXyjP.VVU2YN()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF0eUf(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFH1Ib(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF0eUf(SELF, "Error:\n\n%s" % str(e), title=title)
 def VV8f4T(self, source, mode, curBName, VVSuUg, title, txt, colList):
  isMulti = VVSuUg.VVJZs5
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVSuUg.VVv1D2()
   totTxt = "%d Service%s" % (tot, FF1OOs(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFNr4J(totTxt, VVQzZA)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCIjyQ(self, VVSuUg, addSep=False)
  thTxt = "Adding Services ..."
  VVZ4NM, cbFncDict = [], None
  VVZ4NM.append(VVVvw4)
  if itemsOK:
   VVZ4NM.append(("Add %s to New Bouquet : %s"    % (totTxt, FFNr4J(curBName , VVhmJa)), "addToCur1"))
   if curBName2: VVZ4NM.append(("Add %s to New Bouquet : %s" % (totTxt, FFNr4J(curBName2, VVi9VJ)) , "addToCur2"))
   VVZ4NM.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF1QiT, mSel.VVSuUg, BF(self.VV80Ja,source, mode, curBName , VVSuUg, title), title=thTxt)
      , "addToCur2": BF(FF1QiT, mSel.VVSuUg, BF(self.VV80Ja,source, mode, curBName2, VVSuUg, title), title=thTxt)
      , "addToNew" : BF(self.VVjG7e, source, mode, curBName, VVSuUg, title)
      }
  else:
   VVZ4NM.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVfE0v(VVZ4NM, cbFncDict, width=1400)
 def VV80Ja(self, source, mode, curBName, VVSuUg, Title):
  chUrlLst = self.VVX4xk(source, mode, VVSuUg)
  CC8DHP.VV8Ndw(self, Title, curBName, "", chUrlLst)
 def VVjG7e(self, source, mode, curBName, VVSuUg, Title):
  picker = CC8DHP(self, VVSuUg, Title, BF(self.VVX4xk, source, mode, VVSuUg), defBName=curBName)
 def VVX4xk(self, source, mode, VVSuUg):
  totChange = 0
  isMulti = VVSuUg.VVJZs5
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVSuUg.VVOxLE()):
   if not isMulti or VVSuUg.VVpoRJ(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVmg6D(mode, row)
     refCode, chUrl = self.VVJxQi(self.VVxyZC, self.VVo4zE, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VV68gU(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVUyj3(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVbfeF():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VV7EIo():
  return sorted(tuple(CCXyjP.VVbfeF()))
 @staticmethod
 def VVBY0S(rt):
  return CCXyjP.VVbfeF().get(str(rt), "")
 @staticmethod
 def VVU7Ps(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCXyjP.VVBY0S(span.group(1)) if span else ""
 @staticmethod
 def VVGxMM(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVsfDi():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVZ4NM = []
  for ndx, rt in enumerate(CCXyjP.VV7EIo()):
   VVZ4NM.append(FF1giv("%s\t... %s" % (CCXyjP.VVBY0S(rt), rt), rt, CCXyjP.VVGxMM(rt), VVI2ZY if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVZ4NM.append(VVVvw4)
  return VVZ4NM
class CClHsb(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVpbaP(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFIznG(self.frm, frmColor)
  FFIznG(self.bak, bakColor)
  FFIznG(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VV9wcM(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFvWYU(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCMR4S(CClHsb):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CClHsb.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV21LI()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VV1gWt   ,
   "down" : self.VVzsiY  ,
   "left" : self.VVhkxh  ,
   "right" : self.VVFho7  ,
   "next" : self.VVJIVY ,
   "last" : self.VV5pnx
  }, -1)
 def VVCc3u(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVpbaP(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVyAfM()
  self["myPiconPtr"].hide()
 def VVqayy(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV1gWt(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVW8w7()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVewUN()
 def VVzsiY(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVTqJG()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVewUN()
 def VVhkxh(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVW8w7()
  else:
   self.curCol -= 1
   self.VVewUN()
 def VVFho7(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVTqJG()
  else:
   self.curCol += 1
   self.VVewUN()
 def VV5pnx(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVewUN(oldPage != self.curPage)
 def VVJIVY(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVewUN(oldPage != self.curPage)
 def VVTqJG(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVewUN(force)
 def VVW8w7(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVewUN(force)
 def VVewUN(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVnRiv = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVnRiv: self.curPage = VVnRiv
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVmztd()
  self["myPiconPtr"].hide()
  self.VV9wcM(self.curPage + 1, self.totalPages)
  FFdw1m(BF(self.VVYXIB, force or not oldPage == self.curPage, VVnRiv))
 def VVYXIB(self, force, VVnRiv):
  try:
   if force:
    self.VVaBc7()
   if self.curPage == VVnRiv:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVmztd()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVhyPb(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVewUN(False if oldPage == self.curPage else True)
  else:
   FF7BjW(self, "Not found", 1000)
 def VVtnpD(self):
  self.VVhyPb(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VV21LI(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVryx0(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VViauP, CCfckU, defFG=fg, defBG=bg, onlyBG=True)
 def VViauP(self, fg, bg):
  if self.colorCfg and bg:
   FFE6Br(self.colorCfg, bg)
   self.VVyAfM()
 def VVyAfM(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFIznG(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVVkEq(self, lbl, txt, color=""):
  CCMR4S.VVlRwA(lbl, txt, color)
 @staticmethod
 def VVlRwA(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVvwQ0(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCmDNC(Screen, CCMR4S):
 def __init__(self, session, VVSuUg, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFWbv3(VVMc7q, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVSuUg  = VVSuUg
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVDpqo    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FF3tZI(self, self.Title)
  CCMR4S.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVbRSD, subPath)
  if not pathExists(self.pPath):
   FFKiof("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VV4SyA    ,
   "cancel": self.close    ,
   "menu" : self.VVb3PB ,
   "info" : self.VVhaCX  ,
   "0"  : self.VVtnpD
  })
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  FFxlor(self)
  self.VVCc3u()
  self.VVWvKr()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVb3PB(self):
  chName, subj, desc, fName, picUrl = self.VVDpqo[self.curIndex]
  VVZ4NM = []
  VVZ4NM.append(FF1giv("Show Selected Picture"        , "VVDSHo"  , fName))
  VVZ4NM.append(FF1giv("Copy Selected Picture to Export-Directory"   , "VVhhus" , fName))
  VVZ4NM.append(FF1giv("Set Selected Picture as a Poster for a Local Media" , "VVEIRd", fName))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Cache details"       , "VVUgqK"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Poster/Picon Transparency Color" , "VVryx0" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Help (Keys)"        , "help"     ))
  FFLMiy(self, self.VVFkC4, title=self.Title, VVZ4NM=VVZ4NM)
 def VVFkC4(self, item=None):
  if item is not None:
   if   item == "VVDSHo"   : self.VVDSHo()
   elif item == "VVhhus"   : self.VVhhus()
   elif item == "VVEIRd"  : self.VVEIRd()
   elif item == "VVUgqK"  : FF1QiT(self, self.VVUgqK, title="Calculating ...")
   elif item == "VVryx0": self.VVryx0()
   elif item == "help"     : FFC2xZ(self, "_help_servBr", "Server Browser (Keys)")
 def VV4SyA(self):
  self.VVSuUg.VVpxIX(self.curIndex)
  self.VVSuUg.VVcg3H()
 def VVhaCX(self):
  self.VVSuUg.VVpxIX(self.curIndex)
  self.VVSuUg.VVjgQ9()
 def VVWvKr(self):
  for colList in self.VVSuUg.VVOxLE():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVDpqo.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVDpqo)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVSuUg.VVZ2t7()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVewUN(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdbaA)
  except:
   self.timer.callback.append(self.VVdbaA)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV1q7o)
  self.myThread.start()
 def VV1q7o(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVDpqo):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFacHF(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFKiof("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVDpqo[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVdbaA(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVEWKM + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVDpqo[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVDpqo[ndx] = (chName, subj, desc, fName, "")
     CCMR4S.VVvwQ0(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVaBc7(self):
  self.VV21LI()
  f1, f2 = self.VVqayy()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVDpqo[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVkEq(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVrRM9 + "iptv.png"
   CCMR4S.VVvwQ0(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVmztd(self):
  chName, subj, desc, fName, picUrl = self.VVDpqo[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVDSHo(self):
  chName, subj, desc, fName, picUrl = self.VVDpqo[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCWJhm.VVpAVI(self, self.pPath + fName)
  else          : FF7BjW(self, "File not found", 1500)
 def VVhhus(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVDpqo[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFKiof("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFH1Ib(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF0eUf(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FF0eUf(self, "No Poster/PIcon found", title=title)
 def VVEIRd(self):
  self.session.openWithCallback(self.VVbVok, BF(CCNmp1, patternMode="movies", VVxAst=CFG.MovieDownloadPath.getValue()))
 def VVbVok(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVDpqo[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFKiof("cp -f '%s' '%s'" % (srcF, dstF)):
     FFH1Ib(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FF0eUf(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCzqWx.VVFVJV(dstF)
   else:
    FF0eUf(self, "No Poster/PIcon found", title=title)
 def VVUgqK(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVbRSD, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FF0hBQ("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCNmp1.VV3y2b(size)
   txt += "%s\n    %s\n\n" % (FFNr4J(path, VVQzZA), size)
  mainPath = "%sPosters" % VVbRSD
  totFiles = FF0hBQ("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FF1OOs(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFNr4J("Total space used by Posters/PIcons%s:" % totFTxt, VVde5r), CCNmp1.VV3y2b(totSize))
  mountPath = CCNmp1.VVUQ2V(mainPath)
  if pathExists(mountPath):
   totSize  = CCNmp1.VVmDUR(mountPath)
   freeSize = CCNmp1.VVaKQl(mountPath)
   usedSize = CCNmp1.VV3y2b(totSize - freeSize)
   totSize  = CCNmp1.VV3y2b(totSize)
   freeSize = CCNmp1.VV3y2b(freeSize)
   txt += "%s\n" % SEP
   txt += FFNr4J("Media Space:\n", VVljbY)
   txt += "    Media Path\t: %s\n" % FFNr4J(mountPath, VVh9Nn)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFXEvX(self, txt, title="Cache Used Size", height=1000)
class CCzqWx(Screen, CCMR4S):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFWbv3(VV6ZL1, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVDpqo    = lst
  FF3tZI(self, self.Title)
  CCMR4S.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VV4SyA    ,
   "cancel": self.close    ,
   "menu" : self.VVj5hD ,
   "info" : self.VV3OOC  ,
   "0"  : self.VVtnpD
  })
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  FFxlor(self)
  self.VVCc3u()
  self.totalItems = len(self.VVDpqo)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVewUN(True)
 def VVaBc7(self):
  self.VV21LI()
  f1, f2 = self.VVqayy()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVDpqo[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVrRM9 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVkEq(lbl, os.path.splitext(os.path.basename(path))[0])
   CCMR4S.VVvwQ0(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVgO0a(self):
  path, movie, poster = self.VVDpqo[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVmztd(self):
  path, poster = self.VVgO0a()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVj5hD(self):
  path, poster = self.VVgO0a()
  VVZ4NM = []
  VVZ4NM.append(("Go to movie ...", "VVtPVk"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(FF1giv("Show Poster"      , "VVDSHo" , poster))
  VVZ4NM.append(FF1giv("Copy Poster to Export-Directory" , "VVhhus", poster))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Poster/Picon Transparency Color"  , "VVryx0" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Poster (from current movie path) ..." , "VVRcq81"  ))
  VVZ4NM.append(("Change Poster (locate manually) ..."   , "VVRcq82"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Help (Keys)"         , "help"     ))
  FFLMiy(self, self.VVdsnL, title=self.Title, VVZ4NM=VVZ4NM)
 def VVdsnL(self, item=None):
  if item is not None:
   if   item == "VVtPVk"    : self.VVtPVk()
   elif item == "VVhhus"    : self.VVhhus()
   elif item == "VVDSHo"    : self.VVDSHo()
   elif item == "VVryx0" : self.VVryx0()
   elif item == "VVRcq81"  : self.VVRcq8()
   elif item == "VVRcq82"  : self.VVRcq8(True)
   elif item == "help"      : FFC2xZ(self, "_help_movBr", "Movies Browser (Keys)")
 def VVtPVk(self):
  VVJIKO = []
  for ndx, item in enumerate(self.VVDpqo):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVJIKO.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVJIKO.sort(key=lambda x: x[0].lower())
  VVFJkn = ("Select" , self.VVBnBF, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFW2Tv(self, None, title="Select Movie", width=1800, height=1000, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, lastFindConfigObj=CFG.lastFindMovie)
 def VVBnBF(self, VVSuUg, title, txt, colList):
  self.VVhyPb(int(colList[2].strip()))
  VVSuUg.cancel()
 def VV4SyA(self):
  path, poster = self.VVgO0a()
  FF1QiT(self, BF(CCNmp1.VVcIM8, self, path), title="Playing Media ...")
 def VV3OOC(self):
  path, poster = self.VVgO0a()
  txt = "%s:\n%s\n\n" % (FFNr4J("Path", VVQzZA), path)
  size = FFPebg(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFNr4J("File Size", VVQzZA), CCNmp1.VV3y2b(size))
  if poster:
   txt += "%s:\n%s" % (FFNr4J("Poster", VVQzZA), poster)
  FFXEvX(self, txt, title="Media File Information")
 def VVDSHo(self):
  path, poster = self.VVgO0a()
  if fileExists(poster): CCWJhm.VVpAVI(self, poster)
  else     : FF7BjW(self, "No Poster", 1500)
 def VVhhus(self):
  title = "Copy Poster"
  path, poster = self.VVgO0a()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFKiof("cp -f '%s' '%s'" % (poster, dstF)):
    FFH1Ib(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF0eUf(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FF7BjW(self, "No Poster", 1500)
 def VVRcq8(self, isManual=False):
  path, poster = self.VVgO0a()
  sDir = FFSiyE(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VV6HIT, sDir, path), BF(CCNmp1, patternMode="poster", VVxAst=sDir))
  else:
   VVZ4NM = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVZ4NM.append((os.path.basename(item), sDir + item))
   if VVZ4NM:
    VVZ4NM.sort(key=lambda x: x[0].lower())
    VVsk8Y = self.VVXBVe
    FFLMiy(self, BF(self.VV6HIT, sDir, path), VVZ4NM=VVZ4NM, title="Posters", VVsk8Y=VVsk8Y, VVpQam=sDir)
   else:
    FF7BjW(self, "No jpg/png in current dir", 1500)
 def VVXBVe(self, VVKicw, txt, ref, ndx):
  CCWJhm.VVpAVI(self, VV52TG=ref)
 def VV6HIT(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFKiof("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVDpqo[self.curIndex] = (self.VVDpqo[self.curIndex][0], self.VVDpqo[self.curIndex][1], os.path.basename(newPath))
    FF1QiT(self, self.VVaBc7)
    CCzqWx.VVFVJV(newPath)
   else:
    FF7BjW(self, "Cannot copy file", 1000)
 @staticmethod
 def VVFVJV(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFKiof("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVcvPi(SELF):
  eLst = CCid1U.VVyaUp()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCzqWx, title, lst)
  else  : FF0eUf(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCWWGD(Screen, CCMR4S):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFWbv3(VV8XWP, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVDpqo    = lst
  self.pPath    = CCk0vb.VVJcyT()
  self.totalItems   = 0
  self.isFirstTime  = True
  FF3tZI(self, self.Title)
  FFTvkX(self["keyRed"] , "OK = Zap (Review)")
  FFTvkX(self["keyGreen"] , "Zap & Exit")
  FFTvkX(self["keyYellow"], "Find Current Service")
  CCMR4S.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVfY9Y, False),
   "cancel" : self.VVGj7j      ,
   "menu"  : self.VVWzB3   ,
   "red"  : self.VVGj7j      ,
   "green"  : BF(self.VVfY9Y, True) ,
   "yellow" : BF(self.VVx5gb, True)  ,
   "0"   : self.VVtnpD
  })
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFBjfS(self)
   FFxlor(self)
   FFIznG(self["keyRed"], "#0a333333")
   self.VVCc3u()
  else:
   pName, srvLst = CCWWGD.VV63UG()
   if srvLst and not srvLst == self.VVDpqo:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVDpqo = srvLst
   else:
    force = False
  self.totalItems = len(self.VVDpqo)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVewUN(force)
  self.VVx5gb()
 def VVWzB3(self):
  VVZ4NM = []
  VVZ4NM.append(("Find Name (sorted list)" , "findSrt"  ))
  VVZ4NM.append(("Find Name (as listed)" , "findNoSrt"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Change Background Color" , "VVryx0"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Help (Keys)", "help"))
  FFLMiy(self, self.VVf2wk, title="Options", VVZ4NM=VVZ4NM)
 def VVf2wk(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVH7zj(True)
   elif item == "findNoSrt"   : self.VVH7zj(False)
   elif item == "VVryx0": self.VVryx0()
   elif item == "help"     : FFC2xZ(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVH7zj(self, isSort):
  VVZ4NM = []
  for ndx, item in enumerate(self.VVDpqo):
   VVZ4NM.append((item[1], ndx))
  if isSort:
   VVZ4NM.sort(key=lambda x: x[0].lower())
  FFLMiy(self, self.VVlxqC, title="Find Name", VVZ4NM=VVZ4NM, width=1300)
 def VVlxqC(self, ndx=None):
  if ndx is not None:
   self.VVhyPb(ndx)
 def VVGj7j(self):
  if self.shown: self.close()
  else   : self.show()
 def VVfY9Y(self, isExit):
  FF1QiT(self, BF(self.VVKiuj, isExit), title="Starting ...")
 def VVKiuj(self, isExit):
  try:
   if self.shown:
    FFzGKI(self, self.VVDpqo[self.curIndex][0], VVEwyq=False)
    if isExit: self.close()
    else  : CCXYrc.VVRGWe(self.session)
   else:
    self.show()
  except:
   pass
 def VVx5gb(self, VVR9V4=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVDpqo):
    if curRef == item[0]:
     self.VVhyPb(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVR9V4 and err:
   FF7BjW(self, err, 500)
  return -1
 def VVaBc7(self):
  self.VV21LI()
  f1, f2 = self.VVqayy()
  row = col = 0
  noPos = VVrRM9 + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVDpqo[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVkEq(lbl, name)
   path = CCk0vb.VV4jkX(self.pPath, ref, name) or noPos
   CCMR4S.VVvwQ0(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVmztd(self):
  ref, name = self.VVDpqo[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVoGLZ():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVbIOb = InfoBar.instance
  if VVbIOb:
   csel = VVbIOb.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFmmIM(rootRef)
    refName  = FFmmIM(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VV63UG(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCWWGD.VVoGLZ()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFNTAQ(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CC8DHP.VV01Y3()
   pName  = CC8DHP.VVeKWz() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVAw1A(SELF):
  pName, srvLst = CCWWGD.VV63UG()
  if srvLst: SELF.session.open(CCWWGD, pName, srvLst)
  else  : FF0eUf(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCMocy(Screen, CCMR4S):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFWbv3(VVKY6h, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVDpqo    = CCMocy.VVuXEn(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FF3tZI(self, self.Title)
  FFTvkX(self["keyRed"] , "OK = Start Plugin")
  FFTvkX(self["keyYellow"], "Package Info.")
  FFTvkX(self["keyBlue"] , "Plugins Group")
  CCMR4S.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVIUUx   ,
   "cancel" : self.VVGj7j    ,
   "menu"  : self.VVZXGu ,
   "info"  : self.VVqhLk  ,
   "red"  : self.VVGj7j    ,
   "yellow" : BF(FF1QiT, self, self.VV7G06),
   "blue"  : self.VVcHIU  ,
   "0"   : self.VVtnpD
  })
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  FFxlor(self)
  FFIznG(self["keyRed"], "#0a333333")
  self.VVCc3u()
  self.totalItems = len(self.VVDpqo)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVewUN(True)
 def VVGj7j(self):
  self.close()
 def VVIUUx(self):
  name, desc = self.VV8MKU(self.curIndex)
  if name == PLUGIN_NAME:
   FF7BjW(self, "Already running.", 500)
  else:
   try:
    p = self.VVDpqo[self.curIndex]
    p(session=self.session)
   except:
    FF0eUf(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVqhLk(self):
  def VVOb1w(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVDpqo[self.curIndex]
  txt = ""
  try:
   txt += VVOb1w("Path"  , p.path  )
   txt += VVOb1w("Description" , p.description )
   txt += VVOb1w("Icon"  , p.iconstr  )
   txt += VVOb1w("Wakeup Fnc" , p.wakeupfnc )
   txt += VVOb1w("NeedsRestart", p.needsRestart)
   txt += VVOb1w("Internal" , p.internal )
   txt += VVOb1w("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VV8MKU(self.curIndex)
  if txt : FFXEvX(self, txt, title=name)
  else : FF0eUf(self, "Could not read plugin info.", title=name)
 def VV7G06(self):
  p = self.VVDpqo[self.curIndex]
  name, desc = self.VV8MKU(self.curIndex)
  path = p.path
  pkg, err = CC5jmY.VVTUyZ(path)
  if pkg : CC5jmY.VVC4i6(self, pkg, name)
  else : FFVyvQ(self, err, 1000)
 def VVZXGu(self):
  path = self.VVDpqo[self.curIndex].path
  VVZ4NM = []
  txt = "Open Plugin Path in File Manager"
  VVZ4NM.append(FF1giv("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Use Original Icon Size", "setOrigSize"))
  FFLMiy(self, self.VVf1JB, title="Plugins Group", VVZ4NM=VVZ4NM)
 def VVf1JB(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCNmp1, mode=CCNmp1.VVLO4h, VVxAst=self.VVDpqo[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVewUN(True)
 def VVcHIU(self):
  FFLMiy(self, self.VVfIj7, title="Plugins Group", VVZ4NM=CCMocy.VVwFoD(True, True), width=700, VV9pbf=True)
 def VVfIj7(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCMocy.VVgUYl(where)
   if lst:
    self.VVDpqo = CCMocy.VVuXEn(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVDpqo)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVewUN(True)
   else:
    FF0eUf(self, "Not found !", title=self.Title)
 def VVaBc7(self):
  self.VV21LI()
  f1, f2 = self.VVqayy()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VV8MKU(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVkEq(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVDpqo[ndx].icon:
    try:
     pngSz = self.VVDpqo[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVDpqo[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVDpqo[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVrRM9 + "plugin.png")
    for path in icons:
     pixMap = CCMR4S.VVvwQ0(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV8MKU(self, ndx):
  name = str(self.VVDpqo[ndx].name).strip()
  desc = str(self.VVDpqo[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFRa3J(self.VVDpqo[ndx].path)
  return name, desc
 def VVmztd(self):
  name, desc = self.VV8MKU(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVwFoD(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCMocy.VVgUYl(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVi1yn, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVVvw4)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVgUYl(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVuXEn(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFRa3J(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVyQeg(SELF):
  title = "Plugins Browser"
  lst = CCMocy.VVgUYl(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCMocy, title, lst)
  else : FF0eUf(SELF, "No plugins found !", title=title)
class CCwex4(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFWbv3(VV3sDt, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVKxlI  = 0
  self.VVzhMC = 1
  self.VVsWXJ  = 2
  VVZ4NM = []
  VVZ4NM.append(("Find in All Service (from filter)" , "VVXOTh" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Find in All (Manual Entry)"   , "VVZvjE"    ))
  VVZ4NM.append(("Find in TV"       , "VVT8B1"    ))
  VVZ4NM.append(("Find in Radio"      , "VVQj60"   ))
  if self.VVBwYB():
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Hide Channel: %s" % self.servName , "VVFs74"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Zap History"       , "VVvRV9"    ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("IPTV Tools"       , "iptv"      ))
  VVZ4NM.append(("PIcons Tools"       , "PIconsTools"     ))
  VVZ4NM.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVZ4NM.append(("EPG Tools"       , "epgTools"     ))
  FF3tZI(self, VVZ4NM=VVZ4NM, title=title)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self)
  if self.isFindMode:
   self.VVdHEg(self.VVK1nO())
 def VV4SyA(self):
  global VVW2jY
  VVW2jY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVZvjE"    : self.VVZvjE()
   elif item == "VVXOTh" : self.VVXOTh()
   elif item == "VVT8B1"    : self.VVT8B1()
   elif item == "VVQj60"   : self.VVQj60()
   elif item == "VVFs74"   : self.VVFs74()
   elif item == "VVvRV9"    : self.VVvRV9()
   elif item == "iptv"       : self.session.open(CCXyjP)
   elif item == "PIconsTools"     : self.session.open(CCk0vb)
   elif item == "ChannelsTools"    : self.session.open(CCtCGd)
   elif item == "epgTools"      : self.session.open(CCh6kb)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVT8B1(self) : self.VVdHEg(self.VVKxlI)
 def VVQj60(self) : self.VVdHEg(self.VVzhMC)
 def VVZvjE(self) : self.VVdHEg(self.VVsWXJ)
 def VVdHEg(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFFMZg(self, BF(self.VVvDwk, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVXOTh(self):
  filterObj = CCC0Pu(self)
  filterObj.VVX9no(self.VVPs6W)
 def VVPs6W(self, item):
  self.VVvDwk(self.VVsWXJ, item)
 def VVBwYB(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFBV7X(self.refCode)        : return False
  return True
 def VVvDwk(self, mode, VVBLke):
  FF1QiT(self, BF(self.VV5YmW, mode, VVBLke), title="Searching ...")
 def VV5YmW(self, mode, VVBLke):
  if VVBLke:
   VVBLke = VVBLke.strip()
  if VVBLke:
   self.findTxt = VVBLke
   CFG.lastFindContextFind.setValue(VVBLke)
   if   mode == self.VVKxlI  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVzhMC : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVBLke)
   if len(title) > 55:
    title = title[:55] + ".."
   VVJIKO = self.VV4ztg(VVBLke, servTypes)
   if self.isFindMode or mode == self.VVsWXJ:
    VVJIKO += self.VVB6UH(VVBLke)
   if VVJIKO:
    VVJIKO.sort(key=lambda x: x[0].lower())
    VVQLDs = self.VVS6aL
    VVFJkn  = ("Zap"   , self.VVjibp    , [])
    VV8lmg = ("Current Service", self.VVT6FS , [])
    VV0RwZ = ("Options"  , self.VVLZIH , [])
    VVU95Y = (""    , self.VVrJu9 , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVXdZ9  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVQLDs=VVQLDs, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVU95Y=VVU95Y, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVdHEg(self.VVK1nO())
    FFH1Ib(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV4ztg(self, VVBLke, servTypes):
  VVDpqo = CCtCGd.VVb4PL(servTypes)
  VVJIKO = []
  if VVDpqo:
   VVlwSV, VVaaQZ = FFlozs()
   tp = CCwj2W()
   words, asPrefix = CCC0Pu.VVUzJV(VVBLke)
   colorYellow  = CCdDf8.VVhmGI(VVde5r)
   colorWhite  = CCdDf8.VVhmGI(VVqIxN)
   for s in VVDpqo:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFAVEM(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVlwSV:
        STYPE = VVaaQZ[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVJ5hP(refCode)
       if not "-S" in syst:
        sat = syst
       VVJIKO.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVJIKO
 def VVB6UH(self, VVBLke):
  VVBLke = VVBLke.lower()
  VVJIKO = []
  colorYellow  = CCdDf8.VVhmGI(VVde5r)
  colorWhite  = CCdDf8.VVhmGI(VVqIxN)
  for b in CC8DHP.VVt0b6():
   VVkhQ1  = b[0]
   VVReUV  = b[1].toString()
   VVrURN = eServiceReference(VVReUV)
   VV5KXr = FFNTAQ(VVrURN)
   for service in VV5KXr:
    refCode  = service[0]
    if FFBV7X(refCode):
     servName = service[1]
     if VVBLke in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVBLke), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVJIKO.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVJIKO
 def VVK1nO(self):
  VVbIOb = InfoBar.instance
  if VVbIOb:
   VVWuh1 = VVbIOb.servicelist
   if VVWuh1:
    return VVWuh1.mode == 1
  return self.VVsWXJ
 def VVS6aL(self, VVSuUg):
  self.close()
  VVSuUg.cancel()
 def VVjibp(self, VVSuUg, title, txt, colList):
  FFzGKI(VVSuUg, colList[2], VVEwyq=False, checkParentalControl=True)
 def VVT6FS(self, VVSuUg, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(VVSuUg)
  if refCode:
   VVSuUg.VVJnOe(2, FFqmmY(refCode, iptvRef, chName), True)
 def VVLZIH(self, VVSuUg, title, txt, colList):
  servName = colList[0]
  mSel = CCIjyQ(self, VVSuUg)
  VVZ4NM, cbFncDict = CCtCGd.VVthzb(self, VVSuUg, servName, 2)
  mSel.VVfE0v(VVZ4NM, cbFncDict)
 def VVrJu9(self, VVSuUg, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFGNa7(self, fncMode=CCUr80.VVinKd, refCode=refCode, chName=chName, text=txt)
 def VVFs74(self):
  FF4s3j(self, self.VVHzzE, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVHzzE(self):
  ret = FFckWq(self.refCode, True)
  if ret:
   self.VVqlcu()
   self.close()
  else:
   FF7BjW(self, "Cannot change state" , 1000)
 def VVqlcu(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVUz6V()
  except:
   self.VVAE7n()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFzx2D(self, serviceRef)
 def VVUz6V(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVbIOb = InfoBar.instance
   if VVbIOb:
    VVWuh1 = VVbIOb.servicelist
    if VVWuh1:
     hList = VVWuh1.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVWuh1.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVWuh1.history  = newList
       VVWuh1.history_pos = pos
 def VVAE7n(self):
  VVbIOb = InfoBar.instance
  if VVbIOb:
   VVWuh1 = VVbIOb.servicelist
   if VVWuh1:
    VVWuh1.history  = []
    VVWuh1.history_pos = 0
 def VVvRV9(self):
  VVbIOb = InfoBar.instance
  VVJIKO = []
  if VVbIOb:
   VVWuh1 = VVbIOb.servicelist
   if VVWuh1:
    VVlwSV, VVaaQZ = FFlozs()
    for serv in VVWuh1.history:
     refCode = serv[-1].toString()
     chName = FFmmIM(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFBV7X(refCode)
     isSRel = FF98yX(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFAVEM(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVlwSV:
       STYPE = VVaaQZ[sTypeInt]
     VVJIKO.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVJIKO:
   VVFJkn  = ("Zap"   , self.VVpRUc   , [])
   VV0RwZ = ("Clear History" , self.VVx5KS   , [])
   VVU95Y = (""    , self.VVp2u9 , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVXdZ9  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VVFJkn=VVFJkn, VV0RwZ=VV0RwZ, VVU95Y=VVU95Y)
  else:
   FFH1Ib(self, "History is empty.", title=title)
 def VVpRUc(self, VVSuUg, title, txt, colList):
  FFzGKI(VVSuUg, colList[3], VVEwyq=False, checkParentalControl=True)
 def VVx5KS(self, VVSuUg, title, txt, colList):
  FF4s3j(self, BF(self.VV3YJs, VVSuUg), "Clear Zap History ?")
 def VV3YJs(self, VVSuUg):
  self.VVAE7n()
  VVSuUg.cancel()
 def VVp2u9(self, VVSuUg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFGNa7(self, fncMode=CCUr80.VV1Fdu, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVk6qa():
  try:
   global VVEJzO
   if VVEJzO is None:
    VVEJzO    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCwex4.VVaVQc
   ChannelContextMenu.VVeMgz = CCwex4.VVeMgz
  except:
   pass
 @staticmethod
 def VVaVQc(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVEJzO(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VVeMgz, t[i], csel, mode=i))))
 @staticmethod
 def VVeMgz(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFmmIM(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CCWWGD.VVAw1A(self)
  else  : self.session.open(BF(CCwex4, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CCk0vb(Screen, CCMR4S, CC939I):
 VVJv3O   = 0
 VVinmS  = 1
 VVfvmK  = 2
 VVWuaB  = 3
 VVbn1w  = 4
 VV5noR  = 5
 VVvInb  = 6
 VVGW08  = 7
 VV4rMx = 8
 VVMg0U = 9
 VV2rJk = 10
 VV76oh = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VVY1SD, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCk0vb.VVJcyT()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVDpqo    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FF3tZI(self, self.Title)
  FFTvkX(self["keyRed"] , "OK = Zap")
  FFTvkX(self["keyGreen"] , "Current Service")
  FFTvkX(self["keyYellow"], "Page Options")
  FFTvkX(self["keyBlue"] , "Filter")
  CCMR4S.__init__(self, 5, 7, CFG.transpColorPicons)
  CC939I.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVcv7p     ,
   "green"  : self.VVd3mP    ,
   "yellow" : self.VVabaa     ,
   "blue"  : self.VVJX6C     ,
   "menu"  : self.VVnXCQ     ,
   "info"  : self.VVpTLc    ,
   "pageUp" : BF(self.VVldrC, True) ,
   "chanUp" : BF(self.VVldrC, True) ,
   "pageDown" : BF(self.VVldrC, False) ,
   "chanDown" : BF(self.VVldrC, False) ,
   "0"   : self.VVtnpD  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  FFxlor(self)
  FFIznG(self["keyRed"], "#0a333333")
  self.VVCc3u()
  FF1QiT(self, BF(self.VVVJTy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVnXCQ(self):
  if not self.isBusy:
   VVZ4NM = []
   VVZ4NM.append(("Statistics"           , "VVDUID"    ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Suggest PIcons for Current Channel"     , "VVETEw"   ))
   VVZ4NM.append(("Set to Current Channel (copy file)"     , "VVQtQd_file"  ))
   VVZ4NM.append(("Set to Current Channel (as SymLink)"     , "VVQtQd_link"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Export Current File Names List"      , "VVIaTq" ))
   VVZ4NM.append(CCk0vb.VVq2PE())
   VVZ4NM.append(VVVvw4)
   c, cond = VVIZs4, self.filterTitle == "PIcons without Channels"
   VVZ4NM.append(FF1giv("Move Unused PIcons to a Directory", "VVDYQb" , cond, c))
   VVZ4NM.append(FF1giv("DELETE Unused PIcons"    , "VVLF8o" , cond, c))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVcSdP"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM += CCk0vb.VVonKv()
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Change Poster/Picon Transparency Color"    , "VVryx0" ))
   VVZ4NM.append(("Keys Help"           , "VV49Ds"    ))
   FFLMiy(self, self.VVmPyu, width=1100, height=1050, title=self.Title, VVZ4NM=VVZ4NM)
 def VVmPyu(self, item=None):
  if item is not None:
   if   item == "VVDUID"    : self.VVDUID()
   elif item == "VVETEw"   : self.VVETEw()
   elif item == "VVQtQd_file"  : self.VVQtQd(0)
   elif item == "VVQtQd_link"  : self.VVQtQd(1)
   elif item == "VVIaTq"  : self.VVIaTq()
   elif item == "VV18Y5"  : CCk0vb.VV18Y5(self)
   elif item == "VVDYQb"   : self.VVDYQb()
   elif item == "VVLF8o"  : self.VVLF8o()
   elif item == "VVcSdP"  : self.VVcSdP()
   elif item == "VVTPz8"  : CCk0vb.VVTPz8(self)
   elif item == "findPiconBrokenSymLinks" : CCk0vb.VV5Dq3(self, True)
   elif item == "FindAllBrokenSymLinks" : CCk0vb.VV5Dq3(self, False)
   elif item == "VVryx0" : self.VVryx0()
   elif item == "VV49Ds"     : FFC2xZ(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVabaa(self):
  if not self.isBusy:
   VVZ4NM = []
   VVZ4NM.append(("Go to First PIcon"  , "VVTqJG"  ))
   VVZ4NM.append(("Go to Last PIcon"   , "VVW8w7"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Sort by Channel Name"     , "sortByChan" ))
   VVZ4NM.append(("Sort by File Name"  , "sortByFile" ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Find from File List .." , "VVIpE2" ))
   FFLMiy(self, self.VVuGWE, title=self.Title, VVZ4NM=VVZ4NM)
 def VVuGWE(self, item=None):
  if item is not None:
   if   item == "VVTqJG"   : self.VVTqJG()
   elif item == "VVW8w7"   : self.VVW8w7()
   elif item == "sortByChan"  : self.VVsc46(2)
   elif item == "sortByFile"  : self.VVsc46(0)
   elif item == "VVIpE2"  : self.VVIpE2()
 def VVIpE2(self):
  VVZ4NM = []
  for item in self.VVDpqo:
   VVZ4NM.append((item[0], item[0]))
  FFLMiy(self, self.VVqy9M, title='PIcons ".png" Files', VVZ4NM=VVZ4NM, VV9pbf=True)
 def VVqy9M(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVhyPb(ndx)
 def VVcv7p(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVN7II()
   if refCode:
    FFzGKI(self, refCode)
    self.VVZuUB()
    self.VVmztd()
 def VVldrC(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVZuUB()
   self.VVmztd()
  except:
   pass
 def VVd3mP(self):
  if self["keyGreen"].getVisible():
   self.VVhyPb(self.curChanIndex)
 def VVsc46(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF1QiT(self, BF(self.VVVJTy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVQtQd(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVN7II()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVZ4NM = []
     VVZ4NM.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVZ4NM.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFLMiy(self, BF(self.VVLGG2, mode, curChF, selPiconF), VVZ4NM=VVZ4NM, title="Current Channel PIcon (already exists)")
    else:
     self.VVLGG2(mode, curChF, selPiconF, "overwrite")
   else:
    FF0eUf(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF0eUf(self, "Could not read current channel info. !", title=title)
 def VVLGG2(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFKiof(cmd)
   FF1QiT(self, BF(self.VVVJTy, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVDYQb(self):
  defDir = FFSiyE(CCk0vb.VVJcyT() + "picons_backup")
  FFKiof("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VV5KHi, defDir), BF(CCNmp1
         , mode=CCNmp1.VVLQAF, VVxAst=CCk0vb.VVJcyT()))
 def VV5KHi(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCk0vb.VVJcyT():
    FF0eUf(self, "Cannot move to same directory !", title=title)
   else:
    if not FFSiyE(path) == FFSiyE(defDir):
     self.VV1IeF(defDir)
    FF4s3j(self, BF(FF1QiT, self, BF(self.VVwUZL, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVDpqo), path), title=title)
  else:
   self.VV1IeF(defDir)
 def VVwUZL(self, title, defDir, toPath):
  if not iMove:
   self.VV1IeF(defDir)
   FF0eUf(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFSiyE(toPath)
  pPath = CCk0vb.VVJcyT()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVDpqo:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVDpqo)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFXEvX(self, txt, title=title, VVfKIv="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVg1mo("all")
 def VV1IeF(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVLF8o(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVDpqo)
  FF4s3j(self, BF(FF1QiT, self, BF(self.VVKfQG, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FF1OOs(tot)), title=title)
 def VVKfQG(self, title):
  pPath = CCk0vb.VVJcyT()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVDpqo:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVDpqo)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFNr4J(str(totErr), VVqDXM)
  FFXEvX(self, txt, title=title)
 def VVcSdP(self):
  lines = FFtLFA("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FF4s3j(self, BF(self.VVO0F1, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FF1OOs(tot)), VViggQ=True)
  else:
   FFH1Ib(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVO0F1(self, fList):
  FFKiof("find -L '%s' -type l -delete" % self.pPath)
  FFH1Ib(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVpTLc(self):
  FF1QiT(self, self.VVxp2z)
 def VVxp2z(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVN7II()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFNr4J("PIcon Directory:\n", VVi9VJ)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFHdqb(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFHdqb(path)
   txt += FFNr4J("PIcon File:\n", VVi9VJ)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFNr4J("Found %d SymLink%s to this file from:\n" % (tot, FF1OOs(tot)), VVi9VJ)
     for fPath in slLst:
      txt += "  %s\n" % FFNr4J(fPath, VVi1yn)
     txt += "\n"
   if chName:
    txt += FFNr4J("Channel:\n", VVi9VJ)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFNr4J(chName, VVhmJa)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFNr4J("Remarks:\n", VVi9VJ)
    txt += "  %s\n" % FFNr4J("Unused", VVqDXM)
  else:
   txt = "No info found"
  FFGNa7(self, fncMode=CCUr80.VVfGLr, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVN7II(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVDpqo[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFmcAD(sat)
  return fName, refCode, chName, sat, inDB
 def VVZuUB(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVDpqo):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVmztd(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVN7II()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFNr4J("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVi9VJ))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVN7II()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FF98yX(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFNr4J(self.curChanName, VVde5r)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVN7II()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVDUID(self):
  VVlwSV, VVaaQZ = FFlozs()
  sTypeNameDict = {}
  for key, val in VVaaQZ.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVDpqo:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVaaQZ: sTypeDict[VVaaQZ[stNum]] = sTypeDict.get(VVaaQZ[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FF0hBQ("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVJIKO = []
  c = "#b#11003333#"
  VVJIKO.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVJIKO.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVJIKO.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVJIKO.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVJIKO.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVJIKO.append((c + "Satellites"    , str(len(self.nsList))))
  VVJIKO.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVJIKO.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVJIKO.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVJIKO.extend(sTypeRows)
  FFW2Tv(self, None, title=self.Title, VVDpqo=VVJIKO, VVsgYf=28, VV6z2K="#00003333", VV7JIr="#00222222")
 def VVIaTq(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFSiyE(CFG.exportedTablesPath.getValue()), txt, FFXJI8())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVDpqo:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFH1Ib(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVJX6C(self):
  if not self.isBusy:
   VVZ4NM = []
   VVZ4NM.append(("All"        , "all"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Used by Channels"     , "used" ))
   VVZ4NM.append(("Unused PIcons"     , "unused" ))
   VVZ4NM.append(("IPTV PIcons"      , "iptv" ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("PIcons Files"      , "pFiles" ))
   VVZ4NM.append(("SymLinks to PIcons"    , "pLinks" ))
   VVZ4NM.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVZ4NM.append(("By Files Date ..."    , "pDate" ))
   VVZ4NM.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVZ4NM.append(FF2YB6("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FF8TFY(val)
      VVZ4NM.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCC0Pu(self)
   filterObj.VVfcDX(VVZ4NM, self.nsList, self.VVrDZ9)
 def VVrDZ9(self, item=None):
  if item is not None:
   self.VVg1mo(item)
 def VVg1mo(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVJv3O   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVinmS   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVfvmK  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVvInb   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVWuaB  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVbn1w  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV5noR  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV2rJk , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VV76oh , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVGW08   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VV4rMx , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV5noR:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFtLFA("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFRa3J(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF7BjW(self, "Not found", 1000)
     return
   elif mode == self.VV2rJk:
    self.VV30pw(mode)
    return
   elif mode == self.VV76oh:
    self.VVUnMU(mode)
    return
   elif mode == self.VVMg0U:
    return
   else:
    words, asPrefix = CCC0Pu.VVUzJV(words)
   if not words and mode in (self.VVGW08, self.VV4rMx):
    FF7BjW(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF1QiT(self, BF(self.VVVJTy, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV30pw(self, mode):
  VVZ4NM = []
  VVZ4NM.append(("Today"   , "today" ))
  VVZ4NM.append(("Since Yesterday" , "yest" ))
  VVZ4NM.append(("Since 7 days"  , "week" ))
  FFLMiy(self, BF(self.VVxEGi, mode), VVZ4NM=VVZ4NM, title="Filter by Added/Modified Date")
 def VVxEGi(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFrtVw(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFrtVw(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFrtVw(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF1QiT(self, BF(self.VVVJTy, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVUnMU(self, mode):
  VVlwSV, VVaaQZ = FFlozs()
  lst = set()
  for key, val in VVaaQZ.items():
   lst.add(val)
  VVZ4NM = []
  for item in lst:
   VVZ4NM.append((item, item))
  VVZ4NM.sort(key=lambda x: x[0])
  FFLMiy(self, BF(self.VVNFEL, mode), VVZ4NM=VVZ4NM, title="Filter by Service Type")
 def VVNFEL(self, mode, item=None):
  if item:
   VVlwSV, VVaaQZ = FFlozs()
   sTypeList = []
   for key, val in VVaaQZ.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF1QiT(self, BF(self.VVVJTy, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVETEw(self):
  self.session.open(CCuBCl, barTheme=CCuBCl.VVIDig
      , titlePrefix = ""
      , fncToRun  = self.VVzSDv
      , VVtCUJ = self.VVlc3b)
 def VVzSDv(self, VVx2mk):
  VVRxU0, err = CCtCGd.VVUq9T(self, CCtCGd.VVPk5I, VVPsD9=False, VV8wkm=False)
  files = []
  words = []
  if not VVx2mk or VVx2mk.isCancelled:
   return
  VVx2mk.VVgnkU = []
  VVx2mk.VVSJhE(len(VVRxU0))
  if VVRxU0:
   curCh = self.VVsZyp(self.curChanName)
   for refCode in VVRxU0:
    if not VVx2mk or VVx2mk.isCancelled:
     return
    VVx2mk.VVr1vN(1, True)
    chName, sat, inDB = VVRxU0.get(refCode, ("", "", 0))
    ratio = CCk0vb.VVNY6A(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCk0vb.VV1YPI(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFRa3J(f)
       fil = f.replace(".png", "")
       if not fil in VVx2mk.VVgnkU:
        VVx2mk.VVgnkU.append(fil)
 def VVlc3b(self, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  if VVgnkU : FF1QiT(self, BF(self.VVVJTy, mode=self.VVMg0U, words=VVgnkU), title="Loading ...")
  else   : FF7BjW(self, "Not found", 2000)
 def VVVJTy(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VV4nGI(isFirstTime):
   return
  self.isBusy = True
  VV8wkm = True if isFirstTime else False
  VVRxU0, err = CCtCGd.VVUq9T(self, CCtCGd.VVPk5I, VVPsD9=False, VV8wkm=VV8wkm)
  if err:
   self.close()
  iptvRefList = self.VV2Y5c()
  tList = []
  for fName, fType in CCk0vb.VV3bRT(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVRxU0:
    if fName in VVRxU0:
     chName, sat, inDB = VVRxU0.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVJv3O:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVinmS  and chName         : isAdd = True
   elif mode == self.VVfvmK and not chName        : isAdd = True
   elif mode == self.VVWuaB  and fType == 0        : isAdd = True
   elif mode == self.VVbn1w  and fType == 1        : isAdd = True
   elif mode == self.VV5noR  and fName in words       : isAdd = True
   elif mode == self.VVMg0U and fName in words       : isAdd = True
   elif mode == self.VVvInb  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVGW08  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VV4rMx:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV2rJk:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VV76oh:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVDpqo   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FF7BjW(self)
  else:
   self.isBusy = False
   FF7BjW(self, "Not found", 1000)
   return
  self.VVDpqo.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVZuUB()
  self.totalItems = len(self.VVDpqo)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVewUN(True)
 def VV4nGI(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCk0vb.VV3bRT(self.pPath):
    if fName:
     return True
   if isFirstTime : FF0eUf(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF7BjW(self, "Not found", 1000)
  else:
   FF0eUf(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV2Y5c(self):
  VVJIKO = {}
  files  = CCXyjP.VVpx1z()
  if files:
   for path in files:
    txt = FFBRKz(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVJIKO[refCode] = item[1]
  return VVJIKO
 def VVaBc7(self):
  self.VV21LI()
  f1, f2 = self.VVqayy()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVDpqo[ndx]
   fName = self.VVDpqo[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCMR4S.VVvwQ0(pic, path) : color = VVhmJa if inDB else ""
   elif not chName           : color = ""
   else             : color = VVB56o
   self.VVVkEq(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVNY6A(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVq2PE():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VV18Y5")
 @staticmethod
 def VVonKv():
  VVZ4NM = []
  VVZ4NM.append(("Find SymLinks (to PIcon Directory)"   , "VVTPz8"  ))
  VVZ4NM.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVZ4NM.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVZ4NM
 @staticmethod
 def VV18Y5(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF)
  png, path = CCk0vb.VVZQ0A(refCode)
  if path : CCk0vb.VVqCTE(SELF, png, path)
  else : FF0eUf(SELF, "No PIcon found for current channel in:\n\n%s" % CCk0vb.VVJcyT())
 @staticmethod
 def VVTPz8(SELF):
  if VVde5r:
   sed1 = FFVW8g("->", VVde5r)
   sed2 = FFVW8g("picon", VVqDXM)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVB56o, VVqIxN)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFA10e(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFhDaE(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV5Dq3(SELF, isPIcon):
  sed1 = FFVW8g("->", VVB56o)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFVW8g("picon", VVqDXM)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFA10e(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFhDaE(), grep, sed1, sed2))
 @staticmethod
 def VVqCTE(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFVW8g("%s%s" % (dest, png), VVhmJa))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFVW8g(errTxt, VVEWKM))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFftfY(SELF, cmd)
 @staticmethod
 def VV3bRT(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVJcyT():
  path = CFG.PIconsPath.getValue()
  return FFSiyE(path)
 @staticmethod
 def VVZQ0A(refCode, chName=None):
  if FFBV7X(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFsUIS(refCode)
  allPath, fName, refCodeFile, pList = CCk0vb.VV1YPI(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VV4jkX(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCXyjP.VV7EIo():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFhc8v(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VV1YPI(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCk0vb.VVJcyT()
   pList = []
   lst = FFFDtI(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFhc8v(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFRa3J(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCcRIl():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVM0aX  = None
  self.VVa0IQ = ""
  self.VVatfK  = noService
  self.VVYXr1 = 0
  self.VVA0Rt  = noService
  self.VVEvJE = 0
  self.VVOrxM  = "-"
  self.VVKSyr = 0
  self.VVTI8N  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVU0r1(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVM0aX = frontEndStatus
     self.VVglTf()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVglTf(self):
  if self.VVM0aX:
   val = self.VVM0aX.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVa0IQ = "%3.02f dB" % (val / 100.0)
   else         : self.VVa0IQ = ""
   val = self.VVM0aX.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVYXr1 = int(val)
   self.VVatfK  = "%d%%" % val
   val = self.VVM0aX.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVEvJE = int(val)
   self.VVA0Rt  = "%d%%" % val
   val = self.VVM0aX.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVOrxM  = "%d" % val
   val = int(val * 100 / 500)
   self.VVKSyr = min(500, val)
   val = self.VVM0aX.get("tuner_locked", 0)
   if val == 1 : self.VVTI8N = "Locked"
   else  : self.VVTI8N = "Not locked"
 def VVNjrm(self)   : return self.VVa0IQ
 def VVyvLe(self)   : return self.VVatfK
 def VV2rOr(self)  : return self.VVYXr1
 def VVqoKy(self)   : return self.VVA0Rt
 def VVkfrp(self)  : return self.VVEvJE
 def VVb5EH(self)   : return self.VVOrxM
 def VVynoe(self)  : return self.VVKSyr
 def VVdhLt(self)   : return self.VVTI8N
 def VVYtZP(self) : return self.serviceName
class CCwj2W():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVhryw(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFkO4T(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVouEH(self.ORPOS  , mod=1   )
      self.sat2  = self.VVouEH(self.ORPOS  , mod=2   )
      self.freq  = self.VVouEH(self.FREQ  , mod=3   )
      self.sr   = self.VVouEH(self.SR   , mod=4   )
      self.inv  = self.VVouEH(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVouEH(self.POL  , self.D_POL )
      self.fec  = self.VVouEH(self.FEC  , self.D_FEC )
      self.syst  = self.VVouEH(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVouEH("modulation" , self.D_MOD )
       self.rolof = self.VVouEH("rolloff"  , self.D_ROLOF )
       self.pil = self.VVouEH("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVouEH("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVouEH("pls_code"  )
       self.iStId = self.VVouEH("is_id"   )
       self.t2PlId = self.VVouEH("t2mi_plp_id" )
       self.t2PId = self.VVouEH("t2mi_pid"  )
 def VVouEH(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FF8TFY(val)
  elif mod == 2   : return FFwEqh(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVGEMY(self, refCode):
  txt = ""
  self.VVhryw(refCode)
  if self.data:
   def VVOb1w(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVOb1w("System"   , self.syst)
    txt += VVOb1w("Satellite"  , self.sat2)
    txt += VVOb1w("Frequency"  , self.freq)
    txt += VVOb1w("Inversion"  , self.inv)
    txt += VVOb1w("Symbol Rate"  , self.sr)
    txt += VVOb1w("Polarization" , self.pol)
    txt += VVOb1w("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVOb1w("Modulation" , self.mod)
     txt += VVOb1w("Roll-Off" , self.rolof)
     txt += VVOb1w("Pilot"  , self.pil)
     txt += VVOb1w("Input Stream", self.iStId)
     txt += VVOb1w("T2MI PLP ID" , self.t2PlId)
     txt += VVOb1w("T2MI PID" , self.t2PId)
     txt += VVOb1w("PLS Mode" , self.plsMod)
     txt += VVOb1w("PLS Code" , self.plsCod)
   else:
    txt += VVOb1w("System"   , self.txMedia)
    txt += VVOb1w("Frequency"  , self.freq)
  return txt, self.namespace
 def VVlvvd(self, refCode):
  txt = "Transpoder : ?"
  self.VVhryw(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVJ5hP(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFkO4T(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVouEH(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVouEH(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVouEH(self.SYST, self.D_SYS_S)
     freq = self.VVouEH(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVouEH(self.POL , self.D_POL)
      fec = self.VVouEH(self.FEC , self.D_FEC)
      sr = self.VVouEH(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVp6aW(self, refCode):
  self.data = None
  self.VVhryw(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCC9Tv():
 def __init__(self, VVGN0X, path, VVtCUJ=None, curRowNum=-1):
  self.VVGN0X  = VVGN0X
  self.origFile   = path
  self.Title    = "File Editor: " + FFRa3J(path)
  self.VVtCUJ  = VVtCUJ
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  if FFKiof("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FF1QiT(self.VVGN0X, BF(self.VVZmD4, curRowNum), title="Loading file ...")
  else:
   FF0eUf(self.VVGN0X, "Error while preparing edit!")
 def VVZmD4(self, curRowNum):
  VVJIKO = self.VV8PmN()
  VV8lmg = ("Save Changes" , self.VVRr37   , [])
  VVFJkn  = ("Edit Line"  , self.VVEAB9    , [])
  VV0RwZ = ("Go to Line Num" , self.VVQbWn   , [])
  VVUpMt = ("Line Options" , self.VV2bU1   , [])
  VVHEpO = (""    , self.VVi448 , [])
  VVQLDs = self.VVMpPR
  VVbl2R  = self.VVtfH0
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVXdZ9  = (CENTER  , LEFT  )
  VVSuUg = FFW2Tv(self.VVGN0X, None, title=self.Title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VV8lmg=VV8lmg, VVFJkn=VVFJkn, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVQLDs=VVQLDs, VVbl2R=VVbl2R, VVHEpO=VVHEpO, VVROQm=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVrEme   = "#11001111"
    , VVRBt6   = "#11001111"
    , VVfKIv   = "#11001111"
    , VV6z2K  = "#05333333"
    , VV7JIr  = "#00222222"
    , VVpBpY  = "#11331133"
    )
  VVSuUg.VVpxIX(curRowNum)
 def VVQbWn(self, VVSuUg, title, txt, colList):
  totRows = VVSuUg.VVmUCw()
  lineNum = VVSuUg.VVZ2t7() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFFMZg(self.VVGN0X, BF(self.VVdWfs, VVSuUg, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVdWfs(self, VVSuUg, lineNum, totRows, VVz5S3):
  if VVz5S3:
   VVz5S3 = VVz5S3.strip()
   if VVz5S3.isdigit():
    num = FF6FFy(int(VVz5S3) - 1, 0, totRows)
    VVSuUg.VVpxIX(num)
    self.lastLineNum = num + 1
   else:
    FF7BjW(VVSuUg, "Incorrect number", 1500)
 def VV2bU1(self, VVSuUg, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVSuUg.VVdq0g()
  VVZ4NM = []
  VVZ4NM.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVZ4NM.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVGbEo"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVM8pl:
   VVZ4NM.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(  ("Delete Line"         , "deleteLine"   ))
  FFLMiy(self.VVGN0X, BF(self.VVGL1w, VVSuUg, lineNum), VVZ4NM=VVZ4NM, title="Line Options")
 def VVGL1w(self, VVSuUg, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVvZoM("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVSuUg)
   elif item == "VVGbEo"  : self.VVGbEo(VVSuUg, lineNum)
   elif item == "copyToClipboard"  : self.VVQZOI(VVSuUg, lineNum)
   elif item == "pasteFromClipboard" : self.VVxlo7(VVSuUg, lineNum)
   elif item == "deleteLine"   : self.VVvZoM("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVSuUg)
 def VVtfH0(self, VVSuUg):
  VVSuUg.VVy2wX()
 def VVi448(self, VVSuUg, title, txt, colList):
  if   self.insertMode == 1: VVSuUg.VVCDCb()
  elif self.insertMode == 2: VVSuUg.VVPPM0()
  self.insertMode = 0
 def VVGbEo(self, VVSuUg, lineNum):
  if lineNum == VVSuUg.VVdq0g():
   self.insertMode = 1
   self.VVvZoM("echo '' >> '%s'" % self.tmpFile, VVSuUg)
  else:
   self.insertMode = 2
   self.VVvZoM("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVSuUg)
 def VVQZOI(self, VVSuUg, lineNum):
  global VVM8pl
  VVM8pl = FF0hBQ("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVSuUg.VVDnVh("Copied to clipboard")
 def VVRr37(self, VVSuUg, title, txt, colList):
  if self.fileChanged:
   if FFKtq8(self.origFile):
    if FFKiof("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVSuUg.VVDnVh("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVSuUg.VVy2wX()
    else:
     FF0eUf(self.VVGN0X, "Cannot save file!")
   else:
    FF0eUf(self.VVGN0X, "Cannot create backup copy of original file!")
 def VVMpPR(self, VVSuUg):
  if self.fileChanged:
   FF4s3j(self.VVGN0X, BF(self.VVp4vj, VVSuUg), "Cancel changes ?")
  else:
   FFKiof("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVp4vj(VVSuUg)
 def VVp4vj(self, VVSuUg):
  VVSuUg.cancel()
  FFfhv3(self.tmpFile)
  if self.VVtCUJ:
   self.VVtCUJ(self.fileSaved)
 def VVEAB9(self, VVSuUg, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVqIxN + "ORIGINAL TEXT:\n" + VVi1yn + lineTxt
  FFFMZg(self.VVGN0X, BF(self.VVBL2o, lineNum, VVSuUg), title="File Line", defaultText=lineTxt, message=message)
 def VVBL2o(self, lineNum, VVSuUg, VVz5S3):
  if not VVz5S3 is None:
   if VVSuUg.VVdq0g() <= 1:
    self.VVvZoM("echo %s > '%s'" % (VVz5S3, self.tmpFile), VVSuUg)
   else:
    self.VVx1Ib(VVSuUg, lineNum, VVz5S3)
 def VVxlo7(self, VVSuUg, lineNum):
  if lineNum == VVSuUg.VVdq0g() and VVSuUg.VVdq0g() == 1:
   self.VVvZoM("echo %s >> '%s'" % (VVM8pl, self.tmpFile), VVSuUg)
  else:
   self.VVx1Ib(VVSuUg, lineNum, VVM8pl)
 def VVx1Ib(self, VVSuUg, lineNum, newTxt):
  VVSuUg.VVXBxd("Saving ...")
  lines = FFMA9m(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVSuUg.VVZO03()
  VVJIKO = self.VV8PmN()
  VVSuUg.VVuO1Y(VVJIKO)
 def VVvZoM(self, cmd, VVSuUg):
  tCons = CC0afB()
  tCons.ePopen(cmd, BF(self.VVBT7t, VVSuUg))
  self.fileChanged = True
  VVSuUg.VVZO03()
 def VVBT7t(self, VVSuUg, result, retval):
  VVJIKO = self.VV8PmN()
  VVSuUg.VVuO1Y(VVJIKO)
 def VV8PmN(self):
  if fileExists(self.tmpFile):
   lines = FFMA9m(self.tmpFile)
   VVJIKO = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVJIKO.append((str(ndx), line.strip()))
   if not VVJIKO:
    VVJIKO.append((str(1), ""))
   return VVJIKO
  else:
   FF7Hmv(self.VVGN0X, self.tmpFile)
class CCC0Pu():
 def __init__(self, callingSELF, VVrEme="#22003344", VVRBt6="#22002233"):
  self.callingSELF = callingSELF
  self.VVZ4NM  = []
  self.satList  = []
  self.VVrEme  = VVrEme
  self.VVRBt6   = VVRBt6
 def VVX9no(self, VVtCUJ):
  self.VVZ4NM = []
  VVZ4NM, VVNX5F = CCC0Pu.VVu0FI(self.callingSELF, False, True)
  if VVZ4NM:
   self.VVZ4NM += VVZ4NM
   self.VVZoUX(VVtCUJ, VVNX5F)
 def VVdN1H(self, mode, VVSuUg, satCol, VVtCUJ, inFilterFnc=None):
  VVSuUg.VVXBxd("Loading Filters ...")
  self.VVZ4NM = []
  self.VVZ4NM.append(("All Services" , "all"))
  if mode == 1:
   self.VVZ4NM.append(VVVvw4)
   self.VVZ4NM.append(("Parental Control", "parentalControl" ))
   self.VVZ4NM.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVZ4NM.append(VVVvw4)
   self.VVZ4NM.append(("Selected Transponder"   , "selectedTP" ))
   self.VVZ4NM.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVlZko(VVSuUg, satCol)
  VVZ4NM, VVNX5F = CCC0Pu.VVu0FI(self.callingSELF, True, False)
  if VVZ4NM:
   VVZ4NM.insert(0, FF2YB6("Custom Words"))
   self.VVZ4NM += VVZ4NM
  VVSuUg.VVTVqz()
  self.VVZoUX(VVtCUJ, VVNX5F, inFilterFnc)
 def VVfcDX(self, VVZ4NM, sats, VVtCUJ, inFilterFnc=None):
  self.VVZ4NM = VVZ4NM
  VVZ4NM, VVNX5F = CCC0Pu.VVu0FI(self.callingSELF, True, False)
  if VVZ4NM:
   self.VVZ4NM.append(FF2YB6("Custom Words"))
   self.VVZ4NM += VVZ4NM
  self.VVZoUX(VVtCUJ, VVNX5F, inFilterFnc)
 def VVZoUX(self, VVtCUJ, VVNX5F, inFilterFnc=None):
  VVWjWA  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVcrQj = ("Edit Filter"  , BF(self.VVsnaW, VVNX5F))
  VVs32w  = ("Filter Help"  , BF(self.VVIt7o, VVNX5F))
  FFLMiy(self.callingSELF, BF(self.VVrZBb, VVtCUJ), VVZ4NM=self.VVZ4NM, title="Select Filter", VVWjWA=VVWjWA, VVcrQj=VVcrQj, VVs32w=VVs32w, VVmNi5=True, VVrEme=self.VVrEme, VVRBt6=self.VVRBt6)
 def VVrZBb(self, VVtCUJ, item):
  if item:
   VVtCUJ(item)
 def VVsnaW(self, VVNX5F, VVMD9SObj, sel):
  if fileExists(VVNX5F) : CCC9Tv(self.callingSELF, VVNX5F, VVtCUJ=None)
  else       : FF7Hmv(self.callingSELF, VVNX5F)
  VVMD9SObj.cancel()
 def VVIt7o(self, VVNX5F, VVMD9SObj, sel):
  FFC2xZ(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVlZko(self, VVSuUg, satColNum):
  if not self.satList:
   satList = VVSuUg.VVK6pF(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFmcAD(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FF2YB6("Satellites"))
  if self.VVZ4NM:
   self.VVZ4NM += self.satList
 @staticmethod
 def VVu0FI(SELF, addTag, VVR9V4):
  FFWhqi()
  fileName  = "ajpanel_services_filter"
  VVNX5F = VVbRSD + fileName
  VVZ4NM  = []
  if not fileExists(VVNX5F):
   FFKiof("cp -f '%s' '%s'" % (VVrRM9 + fileName, VVNX5F))
  fileFound = False
  if fileExists(VVNX5F):
   fileFound = True
   lines = FFMA9m(VVNX5F)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVZ4NM.append((line, "__w__" + line))
       else  : VVZ4NM.append((line, line))
  if VVR9V4:
   if   not fileFound : FF7Hmv(SELF, VVNX5F)
   elif not VVZ4NM : FFoJHK(SELF, VVNX5F)
  return VVZ4NM, VVNX5F
 @staticmethod
 def VVUzJV(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCIjyQ():
 def __init__(self, callingSELF, VVSuUg, addSep=True):
  self.callingSELF = callingSELF
  self.VVSuUg = VVSuUg
  self.VVZ4NM = []
  iMulSel = self.VVSuUg.VVeK6u()
  if iMulSel : self.VVZ4NM.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVZ4NM.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVSuUg.VVv1D2()
  self.VVZ4NM.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVZ4NM.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVZ4NM.append(VVVvw4)
 def VVfE0v(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVZ4NM.extend(extraMenu)
  FFLMiy(self.callingSELF, BF(self.VVilj8, cbFncDict, okFnc), width=width, title="Options", VVZ4NM=self.VVZ4NM)
 def VVilj8(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVSuUg.VVcNsR(True)
   elif item == "MultSelDisab" : self.VVSuUg.VVcNsR(False)
   elif item == "selectAll" : self.VVSuUg.VVcdtH()
   elif item == "unselectAll" : self.VVSuUg.VVnLFh()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCiBWK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VVwoLN, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF3tZI(self)
  FFTvkX(self["keyRed"]  , "Exit")
  FFTvkX(self["keyGreen"]  , "Save")
  FFTvkX(self["keyYellow"] , "Refresh")
  FFTvkX(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVyL2l  ,
   "green" : self.VVTjFo ,
   "yellow": self.VVQt7f  ,
   "blue" : self.VVv4e2   ,
   "up" : self.VV1gWt    ,
   "down" : self.VVzsiY   ,
   "left" : self.VVhkxh   ,
   "right" : self.VVFho7   ,
   "cancel": self.VVyL2l
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self.VVQt7f()
  self.VVXTxP()
  FFxlor(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVgylb)
  except:
   self.timer.callback.append(self.VVgylb)
  self.timer.start(1000, False)
  self.VVgylb()
 def onExit(self):
  self.timer.stop()
 def VVyL2l(self) : self.close(True)
 def VVMNPH(self) : self.close(False)
 def VVv4e2(self):
  self.session.openWithCallback(self.VVCY3Z, BF(CCJK6S))
 def VVCY3Z(self, closeAll):
  if closeAll:
   self.close()
 def VVgylb(self):
  self["curTime"].setText(str(FFmWOg(iTime())))
 def VV1gWt(self):
  self.VV34aE(1)
 def VVzsiY(self):
  self.VV34aE(-1)
 def VVhkxh(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVXTxP()
 def VVFho7(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVXTxP()
 def VV34aE(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVWTt4(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVWTt4(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVWTt4(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVUewY(year)):
   days += 1
  return days
 def VVUewY(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVXTxP(self):
  for obj in self.list:
   FFIznG(obj, "#11404040")
  FFIznG(self.list[self.index], "#11ff8000")
 def VVQt7f(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVTjFo(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC0afB()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV86sU)
 def VV86sU(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFH1Ib(self, "Nothing returned from the system!")
  else    : FFH1Ib(self, str(result))
class CCJK6S(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VVtrva, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF3tZI(self, addLabel=True)
  FFTvkX(self["keyRed"]  , "Exit")
  FFTvkX(self["keyGreen"]  , "Sync")
  FFTvkX(self["keyYellow"] , "Refresh")
  FFTvkX(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVyL2l   ,
   "green" : self.VVZYHm  ,
   "yellow": self.VVKgVP ,
   "blue" : self.VVc6Fe  ,
   "cancel": self.VVyL2l
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV8SPj()
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  FFxlor(self)
  FFdw1m(self.VVcn2l)
 def VVcn2l(self):
  self.VVHO7W()
  self.VV5Cre(False)
 def VVyL2l(self)  : self.close(True)
 def VVc6Fe(self) : self.close(False)
 def VV8SPj(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVHO7W(self):
  self.VVWE4n()
  self.VVBT9m()
  self.VVvtx5()
  self.VVRYEd()
 def VVKgVP(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV8SPj()
   self.VVHO7W()
   FFdw1m(self.VVcn2l)
 def VVZYHm(self):
  if len(self["keyGreen"].getText()) > 0:
   FF4s3j(self, self.VV0iJH, "Synchronize with Internet Date/Time ?")
 def VV0iJH(self):
  self.VVHO7W()
  FFdw1m(BF(self.VV5Cre, True))
 def VVWE4n(self)  : self["keyRed"].show()
 def VVvHOP(self)  : self["keyGreen"].show()
 def VVjoCr(self) : self["keyYellow"].show()
 def VVq2Ax(self)  : self["keyBlue"].show()
 def VVBT9m(self)  : self["keyGreen"].hide()
 def VVvtx5(self) : self["keyYellow"].hide()
 def VVRYEd(self)  : self["keyBlue"].hide()
 def VV5Cre(self, sync):
  localTime = FFKMpI()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVFws8(server)
   if epoch_time is not None:
    ntpTime = FFmWOg(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC0afB()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV86sU, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVjoCr()
  self.VVq2Ax()
  if ok:
   self.VVvHOP()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV86sU(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV5Cre(False)
  except:
   pass
 def VVFws8(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCoB4g.VVKCNt():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC2wds(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWbv3(VVxNYT, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FF3tZI(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFdw1m(self.VVEDtO)
 def VVEDtO(self):
  if CCoB4g.VVKCNt() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFIznG(self["myBody"], color)
   FFIznG(self["myLabel"], color)
  except:
   pass
class CCQXsN(Screen):
 VVqYKv = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFeubS()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFWbv3(VVO5KY, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCFNoU(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCFNoU(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCFNoU(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCcRIl()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF3tZI(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV1gWt       ,
   "down"  : self.VVzsiY      ,
   "left"  : self.VVhkxh      ,
   "right"  : self.VVFho7      ,
   "info"  : self.VVFqXY     ,
   "epg"  : self.VVFqXY     ,
   "menu"  : self.VV49Ds      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVkl8O, -1)  ,
   "next"  : BF(self.VVkl8O, 1)  ,
   "pageUp" : BF(self.VV6K07, True) ,
   "chanUp" : BF(self.VV6K07, True) ,
   "pageDown" : BF(self.VV6K07, False) ,
   "chanDown" : BF(self.VV6K07, False) ,
   "0"   : BF(self.VVkl8O, 0)  ,
   "1"   : BF(self.VV5w4i, pos=1) ,
   "2"   : BF(self.VV5w4i, pos=2) ,
   "3"   : BF(self.VV5w4i, pos=3) ,
   "4"   : BF(self.VV5w4i, pos=4) ,
   "5"   : BF(self.VV5w4i, pos=5) ,
   "6"   : BF(self.VV5w4i, pos=6) ,
   "7"   : BF(self.VV5w4i, pos=7) ,
   "8"   : BF(self.VV5w4i, pos=8) ,
   "9"   : BF(self.VV5w4i, pos=9) ,
  }, -1)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  if not CCQXsN.VVqYKv:
   CCQXsN.VVqYKv = self
  self.sliderSNR.VVZsl2()
  self.sliderAGC.VVZsl2()
  self.sliderBER.VVZsl2(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV5w4i()
  self.VVx15l()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVqdOi)
  except:
   self.timer.callback.append(self.VVqdOi)
  self.timer.start(500, False)
 def VVx15l(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVU0r1(service)
  serviceName = self.tunerInfo.VVYtZP()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  tp = CCwj2W()
  tpTxt, satTxt = tp.VVlvvd(refCode)
  if tpTxt == "?" :
   tpTxt = FFNr4J("NO SIGNAL", VVIZs4)
  self["myTPInfo"].setText(tpTxt + "  " + FFNr4J(satTxt, VVQzZA))
 def VVqdOi(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVU0r1(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVNjrm())
   self["mySNR"].setText(self.tunerInfo.VVyvLe())
   self["myAGC"].setText(self.tunerInfo.VVqoKy())
   self["myBER"].setText(self.tunerInfo.VVb5EH())
   self.sliderSNR.VVOxVr(self.tunerInfo.VV2rOr())
   self.sliderAGC.VVOxVr(self.tunerInfo.VVkfrp())
   self.sliderBER.VVOxVr(self.tunerInfo.VVynoe())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVOxVr(0)
   self.sliderAGC.VVOxVr(0)
   self.sliderBER.VVOxVr(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
    if state and not state == "Tuned":
     FF7BjW(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVFqXY(self):
  FFGNa7(self, fncMode=CCUr80.VVRUYK)
 def VV49Ds(self):
  FFC2xZ(self, "_help_signal", "Signal Monitor (Keys)")
 def VV1gWt(self)  : self.VV5w4i(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVzsiY(self) : self.VV5w4i(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVhkxh(self) : self.VV5w4i(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVFho7(self) : self.VV5w4i(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV5w4i(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFE6Br(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVkl8O(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF6FFy(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFE6Br(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCQXsN.VVqYKv = None
 def VV6K07(self, isUp):
  FF7BjW(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVx15l()
  except:
   pass
class CCFNoU(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVZsl2(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFIznG(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVrRM9 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFIznG(self.covObj, self.covColor)
   else:
    FFIznG(self.covObj, "#00006688")
    self.isColormode = True
  self.VVOxVr(0)
 def VVOxVr(self, val):
  val  = FF6FFy(val, self.minN, self.maxN)
  width = int(FFvWYU(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF6FFy(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCuBCl(Screen):
 VVIDig    = 0
 VVKmRX = 1
 VVWZQd = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVtCUJ=None, barTheme=VVIDig, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVLY86(barTheme)
  self.skin, self.skinParam = FFWbv3(VVA3ui, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVtCUJ = VVtCUJ
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVgnkU = None
  self.timer   = eTimer()
  self.myThread  = None
  FF3tZI(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self.VVPo7P()
  self["myProgBarVal"].setText("0%")
  FFIznG(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VViy06()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViy06)
  except:
   self.timer.callback.append(self.VViy06)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVSJhE(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVz7WV(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVgnkU), self.counter, self.maxValue, catName)
 def VVLJUS(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVNVMA(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVC4ZF(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVH4sn(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VV7fCH(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVA9ka(self, txt):
  self.newTitle = txt
 def VVr1vN(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVgnkU), self.counter, self.maxValue)
  except:
   pass
 def VVYaoM(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVteZq(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVlpyV(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF7BjW(self, "Cancelling ...")
  self.isCancelled = True
  self.VVTwUs(False)
 def VVTwUs(self, isDone):
  FFdw1m(BF(self.VV2Qit, isDone))
 def VV2Qit(self, isDone):
  if self.VVtCUJ:
   self.VVtCUJ(isDone, self.VVgnkU, self.counter, self.maxValue, self.isError)
  self.close()
 def VViy06(self):
  val = FF6FFy(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFvWYU(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVTwUs(True)
 def VVPo7P(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVKmRX, self.VVWZQd):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVLY86(self, barTheme):
  if   barTheme == self.VVKmRX : return 0.7
  if   barTheme == self.VVWZQd : return 0.5
  else             : return 1
class CC0afB(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVtCUJ = {}
  self.commandRunning = False
  self.VVqmRU  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVtCUJ, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVtCUJ[name] = VVtCUJ
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVqmRU:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVrjtw, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVopE2 , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVrjtw, name))
    self.appContainers[name].appClosed.append(BF(self.VVopE2 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVopE2(name, retval)
  return True
 def VVrjtw(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFNr4J("[UN-DECODED STRING]", VVIZs4))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVopE2(self, name, retval):
  if not self.VVqmRU:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVtCUJ[name]:
   self.VVtCUJ[name](self.appResults[name], retval)
  del self.VVtCUJ[name]
 def VV4z9j(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCOBbu(Screen):
 def __init__(self, session, title="", VVAq5S=None, VVbnXV=False, VV1Mhm=False, VVm3aA=False, VVchSg=False, VVoG0G=False, VVmI01=False, VVgcXL=VVLTYB, VVgmlB=None, VV2BpP=False, VVa1fh=None, VVwSJD="", checkNetAccess=False, VVsgYf=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFWbv3(VVgJDM, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVsgYf, usefixedFont=consFont)
  self.session   = session
  self.VVwSJD = VVwSJD
  FF3tZI(self, addScrollLabel=True)
  self.VVbnXV   = VVbnXV
  self.VV1Mhm   = VV1Mhm
  self.VVm3aA   = VVm3aA
  self.VVchSg  = VVchSg
  self.VVoG0G = VVoG0G
  self.VVmI01 = VVmI01
  self.VVgcXL   = VVgcXL
  self.VVgmlB = VVgmlB
  self.VV2BpP  = VV2BpP
  self.VVa1fh  = VVa1fh
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC0afB()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFFBSc()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVAq5S, str):
   self.VVAq5S = [VVAq5S]
  else:
   self.VVAq5S = VVAq5S
  if self.VVm3aA or self.VVchSg:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVAq5S.append("echo -e '\n%s\n' %s" % (restartNote, FFVW8g(restartNote, VVde5r)))
   if self.VVm3aA:
    self.VVAq5S.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVAq5S.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVoG0G:
   FF7BjW(self, "Processing ...")
  self.onLayoutFinish.append(self.VVReGF)
  self.onClose.append(self.VVT4uu)
 def VVReGF(self):
  self["myLabel"].VVILcs(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVwSJD or "Processing ..."))
  if self.VVbnXV:
   self["myLabel"].VVxeK7()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVLSo9()
  else:
   self.VVKd9w()
 def VVLSo9(self):
  if CCoB4g.VVKCNt():
   self["myLabel"].setText("Processing ...")
   self.VVKd9w()
  else:
   self["myLabel"].setText(FFNr4J("\n   No connection to internet!", VVqDXM))
 def VVKd9w(self):
  allOK = self.container.ePopen(self.VVAq5S[0], self.VVsCFX, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVsCFX("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVmI01 or self.VVm3aA or self.VVchSg:
    self["myLabel"].setText(FF0CQw("STARTED", VVde5r) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVa1fh:
   colorWhite = CCdDf8.VVhmGI(VVqIxN)
   color  = CCdDf8.VVhmGI(self.VVa1fh[0])
   words  = self.VVa1fh[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVgcXL=self.VVgcXL)
 def VVsCFX(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVAq5S):
   allOK = self.container.ePopen(self.VVAq5S[self.cmdNum], self.VVsCFX, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVsCFX("Cannot connect to Console!", -1)
  else:
   if self.VVoG0G and FFXZrK(self):
    FF7BjW(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVmI01:
    self["myLabel"].appendText("\n" + FF0CQw("FINISHED", VVde5r), self.VVgcXL)
   if self.VVbnXV or self.VV1Mhm:
    self["myLabel"].VVxeK7()
   if self.VVgmlB is not None:
    self.VVgmlB()
   if not retval and self.VV2BpP:
    self.VVT4uu()
 def VVT4uu(self):
  if self.container.VV4z9j():
   self.container.killAll()
class CCuyLa(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VVgJDM, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVbRSD + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF0hBQ("pwd") or "/home/root"
  self.container   = CC0afB()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FF3tZI(self, title="Terminal", addScrollLabel=True)
  FFTvkX(self["keyRed"] , self.exitBtnText)
  FFTvkX(self["keyGreen"] , "OK = History")
  FFTvkX(self["keyYellow"], "Menu = Custom Cmds")
  FFTvkX(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVg5EC ,
   "cancel": self.VVZ6RE  ,
   "menu" : self.VVU5ZU ,
   "last" : self.VV09ae  ,
   "next" : self.VV09ae  ,
   "1"  : self.VV09ae  ,
   "2"  : self.VV09ae  ,
   "3"  : self.VV09ae  ,
   "4"  : self.VV09ae  ,
   "5"  : self.VV09ae  ,
   "6"  : self.VV09ae  ,
   "7"  : self.VV09ae  ,
   "8"  : self.VV09ae  ,
   "9"  : self.VV09ae  ,
   "0"  : self.VV09ae
  })
  self.onLayoutFinish.append(self.VV7StE)
  self.onClose.append(self.VVWoY9)
 def VV7StE(self):
  self["myLabel"].VVILcs(isResizable=False, outputFileToSave="terminal")
  FFDUax(self["keyRed"]  , "#00ff8000")
  FFIznG(self["keyRed"]  , self.skinParam["titleColor"])
  FFIznG(self["keyGreen"]  , self.skinParam["titleColor"])
  FFIznG(self["keyYellow"] , self.skinParam["titleColor"])
  FFIznG(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVudwv(FF0hBQ("date"), 5)
  result = FF0hBQ("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVsUbo()
  self.VVNPK6()
 def VVNPK6(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVbRSD + "LinuxCommands.lst"
  templPath = VVrRM9 + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFKiof("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFuxno("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVWoY9(self):
  if self.container.VV4z9j():
   self.container.killAll()
   self.VVudwv("Process killed\n", 4)
   self.VVsUbo()
 def VVZ6RE(self):
  if self.container.VV4z9j():
   self.VVWoY9()
  else:
   FF4s3j(self, self.close, "Exit ?", VVsXR5=False)
 def VVsUbo(self):
  self.VVudwv(self.prompt, 1)
  self["keyRed"].hide()
 def VVudwv(self, txt, mode):
  if   mode == 1 : color = VVde5r
  elif mode == 2 : color = VVi9VJ
  elif mode == 3 : color = VVqIxN
  elif mode == 4 : color = VVqDXM
  elif mode == 5 : color = VVi1yn
  elif mode == 6 : color = VVX5FP
  else   : color = VVqIxN
  try:
   self["myLabel"].appendText(FFNr4J(txt, color))
  except:
   pass
 def VVg5EC(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV9VtA() == "":
   self.VVUYFR("cd /tmp")
   self.VVUYFR("ls")
  VVJIKO = []
  if fileExists(self.commandHistoryFile):
   lines  = FFMA9m(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVJIKO.append((str(c), line, str(lNum)))
   self.VVwbhB(VVJIKO, title, self.commandHistoryFile, isHistory=True)
  else:
   FF7Hmv(self, self.commandHistoryFile, title=title)
 def VV9VtA(self):
  lastLine = FF0hBQ("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVUYFR(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVU5ZU(self, VVSuUg=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFMA9m(self.customCommandsFile)
   VVJIKO = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVJIKO.append((str(c), line, str(lNum)))
   if VVSuUg:
    VVSuUg.VVuO1Y(VVJIKO)
    VVSuUg.VVpxIX(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVwbhB(VVJIKO, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF7Hmv(self, self.customCommandsFile, title=title)
 def VVwbhB(self, VVJIKO, title, filePath=None, isHistory=False):
  if VVJIKO:
   VV6z2K = "#05333333"
   if isHistory: VVrEme = VVRBt6 = VVfKIv = "#11000020"
   else  : VVrEme = VVRBt6 = VVfKIv = "#06002020"
   VVFJkn   = ("Send"   , BF(self.VV6QpX, isHistory)  , [])
   VV8lmg  = ("Modify & Send" , self.VVa9XU     , [])
   if isHistory:
    VV0RwZ = ("Clear History" , self.VVqEDP     , [])
    VVUpMt = None
    VVU95Y = None
   elif filePath:
    VV0RwZ = ("Options"  , self.VVUX0Z      , [])
    VVUpMt = ("Edit File"  , BF(self.VVN6XA, filePath) , [])
    VVU95Y = (""    , self.VVwcAd     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVXdZ9 = (CENTER , LEFT   , CENTER )
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt, VVU95Y=VVU95Y, lastFindConfigObj=CFG.lastFindTerminal, VVROQm=True, searchCol=1
         , VVrEme=VVrEme, VVRBt6=VVRBt6, VVfKIv=VVfKIv, VV6z2K=VV6z2K)
   if not isHistory:
    VVSuUg.VVpxIX(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FF4s3j(self, BF(self.VVorWc, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVwcAd(self, VVSuUg, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFNr4J("Command:", VVQzZA), colList[1])
  txt += "%s\n%s\n\n" % (FFNr4J("Line %s in File:" % colList[2], VVQzZA), self.customCommandsFile)
  FFXEvX(self, txt, title=title)
 def VVUX0Z(self, VVSuUg, title, txt, colList):
  mSel = CCIjyQ(self, VVSuUg)
  VVZ4NM = []
  txt1 = "Change Custom Commands File"
  if VVSuUg.VVJZs5:
   VVZ4NM.append((txt1, ))
   VVZ4NM.append(VVVvw4)
   totSel = VVSuUg.VVv1D2()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFNr4J(totTxt, VVde5r) if totSel else totTxt, FF1OOs(totSel))
   VVZ4NM.append((txt2, "send") if totSel else (txt2,))
  else:
   VVZ4NM.append((txt1, "newFile"))
   VVZ4NM.append(VVVvw4)
   txt2 = "Send current line"
   VVZ4NM.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVorWc, VVSuUg, txt1)
     , "send" : BF(self.VV6QpX, False, VVSuUg, title, txt2, colList) }
  mSel.VVfE0v(VVZ4NM, cbFncDict, okFnc=BF(self.VVh30o, VVSuUg))
 def VVorWc(self, VVSuUg, title):
  VVZ4NM = []
  for fName in os.listdir(VVbRSD):
   path = os.path.join(VVbRSD, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVZ4NM.append((fName, path))
  VVZ4NM.sort(key=lambda x: x[0].lower())
  if VVZ4NM : FFLMiy(self, BF(self.VVqRb0, VVSuUg, title), VVZ4NM=VVZ4NM, title=title, minRows=3, VVrEme="#11220000", VVRBt6="#11220000")
  else  : FF0eUf(self, "No valid files found in:\n\n%s" % VVbRSD, title=title)
 def VVqRb0(self, VVSuUg, title, path=None):
  if path:
   if CCNmp1.VVMLm6(path):
    FF0eUf(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFMA9m(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFE6Br(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFE6Br(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVU5ZU(VVSuUg)
      break
    else:
     FF0eUf(self, "File is empty:\n\n%s" % path, title=title)
 def VVh30o(self, VVSuUg):
  if VVSuUg.VVJZs5 : VVSuUg.VVy2wX()
  else        : VVSuUg.VVZO03()
 def VV6QpX(self, isHistory, VVSuUg, title, txt, colList):
  if VVSuUg.VVJZs5:
   lst = VVSuUg.VVzBF6(1)
   curNdx = VVSuUg.VVA1kq()
  else:
   lst = [colList[1]]
   curNdx = VVSuUg.VVZ2t7()
  if not isHistory:
   FFE6Br(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVSuUg.cancel()
  FFdw1m(self.VVWWmM)
 def VVWWmM(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVudwv("\n%s\n" % cmd, 6)
    self.VVudwv(self.prompt, 1)
    self.VVWWmM()
   else:
    self.VVJHaF(cmd)
 def VVJHaF(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVudwv(cmd, 2)
   self.VVudwv("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVudwv(ch, 0)
   self.VVudwv("\nor\n", 4)
   self.VVudwv("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVsUbo()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFNr4J(parts[0].strip(), VVi9VJ)
    right = FFNr4J("#" + parts[1].strip(), VVX5FP)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVudwv(txt, 2)
   lastLine = self.VV9VtA()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVUYFR(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVsCFX, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF0eUf(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVudwv(data, 3)
 def VVsCFX(self, data, retval):
  if not retval == 0:
   self.VVudwv("Exit Code : %d\n" % retval, 4)
  self.VVsUbo()
  if self.commandsList:
   self.VVWWmM()
 def VVa9XU(self, VVSuUg, title, txt, colList):
  if VVSuUg.VVsdbM():
   cmd = colList[1]
   self.VVKxeW(VVSuUg, cmd)
 def VVqEDP(self, VVSuUg, title, txt, colList):
  FF4s3j(self, BF(self.VV8KB5, VVSuUg), "Reset History File ?", title="Command History")
 def VV8KB5(self, VVSuUg):
  FFuxno("> '%s'" % self.commandHistoryFile)
  VVSuUg.cancel()
 def VVN6XA(self, filePath, VVSuUg, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCC9Tv(self, filePath, VVtCUJ=BF(self.VVI8hR, VVSuUg), curRowNum=rowNum)
  else     : FF7Hmv(self, filePath)
 def VVI8hR(self, VVSuUg, fileChanged):
  if fileChanged:
   VVSuUg.cancel()
   FFdw1m(self.VVU5ZU)
 def VV09ae(self):
  self.VVKxeW(None, self.lastCommand)
 def VVKxeW(self, VVSuUg, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFFMZg(self, BF(self.VVKwJx, VVSuUg), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVKwJx(self, VVSuUg, cmd):
  if cmd and len(cmd) > 0:
   self.VVJHaF(cmd)
   if VVSuUg:
    VVSuUg.cancel()
class CCAMA3(Screen):
 def __init__(self, session, title="", message="", VVgcXL=VVLTYB, width=1400, height=900, VVTarI=False, titleBg="#22002020", VVfKIv="#22001122", VVsgYf=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFWbv3(VVgJDM, width, height, titleFontSize, 30, 20, titleBg, VVfKIv, VVsgYf)
  self.session   = session
  FF3tZI(self, title, addScrollLabel=True)
  self.VVgcXL   = VVgcXL
  self.VVTarI   = VVTarI
  self.VVfKIv   = VVfKIv
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self["myLabel"].VVILcs(VVTarI=self.VVTarI, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVgcXL)
  self["myLabel"].VVxeK7()
class CCFtJi(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFWbv3(VVHAru, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF3tZI(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFQKHn(self["errPic"], "err")
class CCcQXm(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFWbv3(VVzuks, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FF3tZI(self, " ", addCloser=True)
class CCZCdI():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCZCdI.VVlJTg(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VV4T4F)
  except: self.timer.callback.append(self.VV4T4F)
  self.timer.start(timeout, True)
 def VV4T4F(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVlJTg(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCcQXm, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFmOW7(win["myWinTitle"], shadColor, shadW)
  CCZCdI.VVXPKH(win, txt)
  return win
 @staticmethod
 def VVXPKH(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCVzxd():
 VVZm19    = 0
 VVuL7W  = 1
 VVN4SN   = ""
 VV3yW7    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVSuUg   = None
  self.timer     = eTimer()
  self.VV6k9J   = 0
  self.VV0kGa  = 1
  self.VVveDc  = 2
  self.VVpGEB   = 3
  self.VVnUaa   = 4
  VVJIKO = self.VVz6RN()
  if VVJIKO:
   self.VVSuUg = self.VVLbPx(VVJIKO)
  if not VVJIKO and mode == self.VVZm19:
   self.VV9Jog("Download list is empty !")
   self.cancel()
  if mode == self.VVuL7W:
   FF1QiT(self.VVSuUg or self.SELF, BF(self.VVezwi, startDnld, decodedUrl), title="Checking Server ...")
  self.VV8gMr(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV8gMr)
  except:
   self.timer.callback.append(self.VV8gMr)
  self.timer.start(1000, False)
 def VVLbPx(self, VVJIKO):
  VVJIKO.sort(key=lambda x: int(x[0]))
  VVQLDs = self.VVXN6x
  VVFJkn  = ("Play"  , self.VVyOQ8 , [])
  VVU95Y = (""   , self.VVGPTt  , [])
  VVdvf0 = ("Stop"  , self.VV6BD2  , [])
  VV8lmg = ("Resume"  , self.VV5wlO , [])
  VV0RwZ = ("Options" , self.VVnXCQ  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVXdZ9  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFW2Tv(self.SELF, None, title=self.Title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVFJkn=VVFJkn, VVU95Y=VVU95Y, VVQLDs=VVQLDs, VVdvf0=VVdvf0, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, lastFindConfigObj=CFG.lastFindIptv, VVrEme="#11220022", VVRBt6="#11110011", VVfKIv="#11110011", VV6z2K="#00223025", VV7JIr="#0a333333", VVpBpY="#0a400040", VVROQm=True, searchCol=1)
 def VVz6RN(self):
  lines = CCVzxd.VV3rDk()
  VVJIKO = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVo70C(decodedUrl)
      if fName:
       if   FFeEbK(decodedUrl) : sType = "Movie"
       elif FFHIEC(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVv2R7(decodedUrl, fName)
       if size > -1: sizeTxt = CCNmp1.VV3y2b(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVJIKO.append((str(len(VVJIKO) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVJIKO
 def VV0S56(self):
  VVJIKO = self.VVz6RN()
  if VVJIKO:
   if self.VVSuUg : self.VVSuUg.VVuO1Y(VVJIKO, VV8SPjMsg=False)
   else     : self.VVSuUg = self.VVLbPx(VVJIKO)
  else:
   self.cancel()
 def VV8gMr(self, force=False):
  if self.VVSuUg:
   thrListUrls = self.VV1Puy()
   VVJIKO = []
   changed = False
   for ndx, row in enumerate(self.VVSuUg.VVOxLE()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV6k9J
    if m3u8Log:
     percent = CCVzxd.VVk8nH(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVpGEB , "%.2f %%" % percent
      else   : flag, progr = self.VVnUaa , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFPebg(mPath)
     if curSize > -1:
      fSize = CCNmp1.VV3y2b(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCNmp1.VV3y2b(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFPebg(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVpGEB , "%.2f %%" % percent
       else   : flag, progr = self.VVnUaa , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCNmp1.VV3y2b(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVveDc
     if m3u8Log :
      if not speed and not force : flag = self.VV0kGa
      elif curSize == -1   : self.VV1NBr(False)
    elif flag == self.VV6k9J  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV6k9J  : color2 = "#f#00555555#"
    elif flag == self.VV0kGa : color2 = "#f#0000FFFF#"
    elif flag == self.VVveDc : color2 = "#f#0000FFFF#"
    elif flag == self.VVpGEB  : color2 = "#f#00FF8000#"
    elif flag == self.VVnUaa  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVmgi3(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVJIKO.append(row)
   if changed or force:
    self.VVSuUg.VVuO1Y(VVJIKO, VV8SPjMsg=False)
 def VVmgi3(self, flag):
  tDict = self.VVkvpw()
  return tDict.get(flag, "?")
 def VVohRQ(self, state):
  for flag, txt in self.VVkvpw().items():
   if txt == state:
    return flag
  return -1
 def VVkvpw(self):
  return { self.VV6k9J: "Not started", self.VV0kGa: "Connecting", self.VVveDc: "Downloading", self.VVpGEB: "Stopped", self.VVnUaa: "Completed" }
 def VVcUHz(self, title):
  colList = self.VVSuUg.VVU4OP()
  path = colList[6]
  url  = colList[8]
  if self.VV66Tj() : self.VV9Jog("Cannot delete !\n\nFile is downloading.")
  else      : FF4s3j(self.SELF, BF(self.VVKcMH, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVKcMH(self, path, url):
  m3u8Log = self.VVSuUg.VVU4OP()[12]
  if m3u8Log : FFKiof("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFKiof("rm -rf '%s'" % path)
  self.VVw5VW(False)
  self.VV0S56()
 def VVw5VW(self, VVR9V4=True):
  if self.VV66Tj():
   FF7BjW(self.VVSuUg, self.VVmgi3(self.VVveDc), 500)
  else:
   colList  = self.VVSuUg.VVU4OP()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVohRQ(state) in (self.VV6k9J, self.VVnUaa, self.VVpGEB):
    lines = CCVzxd.VV3rDk()
    newLines = []
    found = False
    for line in lines:
     if CCVzxd.VVxow6(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVGhPZ(newLines)
     self.VV0S56()
     FF7BjW(self.VVSuUg, "Removed.", 1000)
    else:
     FF7BjW(self.VVSuUg, "Not found.", 1000)
   elif VVR9V4:
    self.VV9Jog("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV3E2f(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FF4s3j(self.SELF, BF(self.VViPaS, flag), ques, title=title)
 def VViPaS(self, flag):
  list = []
  for ndx, row in enumerate(self.VVSuUg.VVOxLE()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVohRQ(state)
   if   flag == flagVal == self.VVnUaa: list.append(decodedUrl)
   elif flag == flagVal == self.VV6k9J : list.append(decodedUrl)
  lines = CCVzxd.VV3rDk()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVGhPZ(newLines)
   self.VV0S56()
   FF7BjW(self.VVSuUg, "%d removed." % totRem, 1000)
  else:
   FF7BjW(self.VVSuUg, "Not found.", 1000)
 def VVPxug(self):
  colList  = self.VVSuUg.VVU4OP()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF7BjW(self.VVSuUg, "Poster exists", 1500)
  else    : FF1QiT(self.VVSuUg, BF(self.VVdIY4, decodedUrl, path, png), title="Checking Server ...")
 def VVdIY4(self, decodedUrl, path, png):
  err = self.VVNxRE(decodedUrl, path, png)
  if err:
   FF0eUf(self.SELF, err, title="Poster Download")
 def VVNxRE(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCyb9m.VVbTF5(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCXyjP.VVmPHt(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCXyjP.VVCv0w(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFacHF(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFKiof("mv -f '%s' '%s'" % (tPath, png))
   CCWJhm.VVpAVI(self.SELF, VV52TG=png, showGrnMsg="Downloaded")
   return ""
 def VVGPTt(self, VVSuUg, title, txt, colList):
  def VV5jhO(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVOb1w(key, val) : return "\n%s:\n%s\n" % (FFNr4J(key, VVQzZA), val.strip())
  heads  = self.VVSuUg.VVXmTk()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV5jhO(heads[i]  , CCNmp1.VV3y2b(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV5jhO("Downloaded" , CCNmp1.VV3y2b(int(curSize), mode=0))
   else:
    txt += VV5jhO(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVOb1w(heads[i], colList[i])
  FFXEvX(self.SELF, txt, title=title)
 def VVyOQ8(self, VVSuUg, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCNmp1.VVcIM8(self.SELF, path)
  else    : FF7BjW(self.VVSuUg, "File not found", 1000)
 def VVXN6x(self, VVSuUg):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVSuUg:
   self.VVSuUg.cancel()
  del self
 def VVnXCQ(self, VVSuUg, title, txt, colList):
  c1, c2, c3 = VVljbY, VVqDXM, VVQzZA
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVZ4NM = []
  VVZ4NM.append((c1 + "Remove current row"       , "VVw5VW" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVZ4NM.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Delete the file (and remove from list)"  , "VVcUHz"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((resumeTxt + " Auto Resume"       , "VVu8HL" ))
  VVZ4NM.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVZ4NM.append(VVVvw4)
  cond = FFeEbK(decodedUrl)
  VVZ4NM.append(FF1giv("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVPxug", cond, c3))
  VVZ4NM.append(FF1giv("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFLMiy(self.SELF, BF(self.VVo8o6, VVSuUg), VVZ4NM=VVZ4NM, title=self.Title, VV9pbf=True, width=800, VVmNi5=True, VVrEme="#1a001122", VVRBt6="#1a001122")
 def VVo8o6(self, VVSuUg, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVw5VW"  : self.VVw5VW()
   elif ref == "remFinished"   : self.VV3E2f(self.VVnUaa, txt)
   elif ref == "remPending"   : self.VV3E2f(self.VV6k9J, txt)
   elif ref == "VVcUHz" : self.VVcUHz(txt)
   elif ref == "VVPxug"  : self.VVPxug()
   elif ref == "VVu8HL"  : FFE6Br(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFE6Br(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCNmp1, mode=CCNmp1.VVNi6D, jumpToFile=path)
    else    : FF7BjW(VVSuUg, "Path not found !", 1500)
 def VVezwi(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCyb9m.VVbTF5(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VV9Jog("Could not get download link !\n\nTry again later.")
     return
  for line in CCVzxd.VV3rDk():
   if CCVzxd.VVxow6(decodedUrl, line):
    if self.VVSuUg:
     self.VV4VVJ(decodedUrl)
     FFdw1m(BF(FF7BjW, self.VVSuUg, "Already listed !", 2000))
    break
  else:
   params = self.VV7A9G(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VV9Jog(params[0])
   elif len(params) == 2:
    FF4s3j(self.SELF, BF(self.VViNoz, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCNmp1.VV3y2b(fSize)
    FF4s3j(self.SELF, BF(self.VVpYrs, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVpYrs(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCVzxd.VV3Kj8(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV0S56()
  if self.VVSuUg:
   self.VVSuUg.VVPPM0()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCVzxd.VV3yW7, path, decodedUrl)
   self.VVDXo1(threadName, url, decodedUrl, path, resp)
 def VV4VVJ(self, decodedUrl):
  if self.VVSuUg:
   for ndx, row in enumerate(self.VVSuUg.VVOxLE()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVSuUg:
     self.VVSuUg.VVpxIX(ndx)
     break
 def VV7A9G(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVo70C(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVv2R7(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCyb9m.VVbTF5(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCyb9m.VVANoN()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCVzxd.VVJOeJ(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCVzxd.VV7oVw(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VViNoz(self, resp, decodedUrl):
  if not FF4wzI("ffmpeg"):
   FF4s3j(self.SELF, BF(CCXyjP.VVHyaR, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVo70C(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVucsU(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FF4s3j(self.SELF, BF(self.VVyzk7, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVyzk7(rTxt, rUrl)
  else:
   self.VV9Jog("Cannot process m3u8 file !")
 def VVucsU(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVZ4NM = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCXyjP.VVheql(rUrl, fPath)
   VVZ4NM.append((resol, fullUrl))
  if VVZ4NM:
   FFLMiy(self.SELF, self.VV4lpZ, VVZ4NM=VVZ4NM, title="Resolution", VV9pbf=True, VVmNi5=True)
  else:
   self.VV9Jog("Cannot get Resolutions list from server !")
 def VV4lpZ(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FF4s3j(self.SELF, BF(FFdw1m, BF(self.VV1Ugx, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFdw1m(BF(self.VV1Ugx, resolUrl))
 def VV1Ugx(self, resolUrl):
  txt, err = CCyb9m.VVLT2J(resolUrl)
  if err : self.VV9Jog(err)
  else : self.VVyzk7(txt, resolUrl)
 def VVbBob(self, logF, decodedUrl):
  found = False
  lines = CCVzxd.VV3rDk()
  with open(CCVzxd.VV3Kj8(), "w") as f:
   for line in lines:
    if CCVzxd.VVxow6(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCVzxd.VV3Kj8(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV0S56()
  if self.VVSuUg:
   self.VVSuUg.VVPPM0()
 def VVyzk7(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCXyjP.VVheql(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VV9Jog("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVbBob(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFyMLY("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCVzxd.VV3yW7, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVk8nH(dnldLog):
  if fileExists(dnldLog):
   dur = CCVzxd.VVx9IW(dnldLog)
   if dur > -1:
    tim = CCVzxd.VVThwd(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVx9IW(dnldLog):
  lines = FFtLFA("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVThwd(dnldLog):
  lines = FFtLFA("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVv2R7(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFHIEC(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFKiof("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVDXo1(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVSuUg.VVU4OP()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV04gl, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV04gl(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVN4SN == path:
       break
     else:
      break
  except:
   return
  if CCVzxd.VVN4SN:
   CCVzxd.VVN4SN = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFPebg(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV7A9G(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV04gl(url, decodedUrl, path, resp, totFileSize, True)
 def VV6BD2(self, VVSuUg, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVmB75() : FF7BjW(self.VVSuUg, self.VVmgi3(self.VVnUaa), 500)
  elif not self.VV66Tj() : FF7BjW(self.VVSuUg, self.VVmgi3(self.VVpGEB), 500)
  elif m3u8Log      : FF4s3j(self.SELF, self.VV1NBr, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VV1Puy():
    CCVzxd.VVN4SN = colList[6]
    FF7BjW(self.VVSuUg, "Stopping ...", 1000)
   else:
    FF7BjW(self.VVSuUg, "Stopped", 500)
 def VV1NBr(self, withMsg=True):
  if withMsg:
   FF7BjW(self.VVSuUg, "Stopping ...", 1000)
  FFKiof("killall -INT ffmpeg")
 def VV5wlO(self, *args):
  if   self.VVmB75() : FF7BjW(self.VVSuUg, self.VVmgi3(self.VVnUaa) , 500)
  elif self.VV66Tj() : FF7BjW(self.VVSuUg, self.VVmgi3(self.VVveDc), 500)
  else:
   resume = False
   m3u8Log = self.VVSuUg.VVU4OP()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FF4s3j(self.SELF, BF(self.VVjqf6, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV7wps():
    resume = True
   if resume: FF1QiT(self.VVSuUg, BF(self.VV1EHL), title="Checking Server ...")
   else  : FF7BjW(self.VVSuUg, "Cannot resume !", 500)
 def VVjqf6(self, m3u8Log):
  FFKiof("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FF1QiT(self.VVSuUg, BF(self.VV1EHL), title="Checking Server ...")
 def VV1EHL(self):
  colList  = self.VVSuUg.VVU4OP()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCyb9m.VVbTF5(decodedUrl)
   if url:
    decodedUrl = self.VViPlj(decodedUrl, url)
   else:
    self.VV9Jog("Could not get download link !\n\nTry again later.")
    return
  curSize = FFPebg(path)
  params = self.VV7A9G(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VV9Jog(params[0])
   return
  elif len(params) == 2:
   self.VViNoz(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VViPlj(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCVzxd.VV3yW7, path, decodedUrl)
  if resumable: self.VVDXo1(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VV9Jog("Cannot resume from server !")
 def VVo70C(self, decodedUrl):
  fileExt = CCXyjP.VVicib(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFXFl9(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VV9Jog(self, txt):
  FF0eUf(self.SELF, txt, title=self.Title)
 def VV1Puy(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCVzxd.VV3yW7, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VV66Tj(self):
  decodedUrl = self.VVSuUg.VVU4OP()[9]
  return decodedUrl in self.VV1Puy()
 def VVmB75(self):
  colList = self.VVSuUg.VVU4OP()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFPebg(path)) == size
 def VV7wps(self):
  colList = self.VVSuUg.VVU4OP()
  path = colList[6]
  size = int(colList[7])
  curSize = FFPebg(path)
  if curSize > -1:
   size -= curSize
  err = CCVzxd.VV7oVw(size)
  if err:
   FF0eUf(self.SELF, err, title=self.Title)
   return False
  return True
 def VVGhPZ(self, list):
  with open(CCVzxd.VV3Kj8(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VViPlj(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCVzxd.VV3rDk()
  url = decodedUrl
  with open(CCVzxd.VV3Kj8(), "w") as f:
   for line in lines:
    if CCVzxd.VVxow6(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV0S56()
  return url
 @staticmethod
 def VV3rDk():
  list = []
  if fileExists(CCVzxd.VV3Kj8()):
   for line in FFMA9m(CCVzxd.VV3Kj8()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVxow6(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VV7oVw(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCNmp1.VVaKQl(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCNmp1.VV3y2b(size), CCNmp1.VV3y2b(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVZJg5(SELF):
  tot = CCVzxd.VVcVqK()
  if tot:
   FF0eUf(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVcVqK():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCVzxd.VV3yW7):
    c += 1
  return c
 @staticmethod
 def VVwvG0():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCVzxd.VV3yW7, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVG9lY():
  return len(CCVzxd.VV3rDk()) == 0
 @staticmethod
 def VVrWWF():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV9spE():
  mPoints = CCVzxd.VVrWWF()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFKiof("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VV3Kj8():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVwpH0(SELF, waitMsgObj=None):
  FF1QiT(waitMsgObj or SELF, BF(CCVzxd.VVRVSQ, SELF, CCVzxd.VVZm19))
 @staticmethod
 def VV34zd(SELF):
  CCVzxd.VVRVSQ(SELF, CCVzxd.VVuL7W, startDnld=True)
 @staticmethod
 def VVxN16(SELF, url):
  CCVzxd.VVRVSQ(SELF, CCVzxd.VVuL7W, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVC0KL(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF)
  added, skipped = CCVzxd.VVhJPd([decodedUrl])
  FF7BjW(SELF, "Added", 1000)
 @staticmethod
 def VVhJPd(list):
  added = skipped = 0
  for line in CCVzxd.VV3rDk():
   for ndx, url in enumerate(list):
    if url and CCVzxd.VVxow6(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCVzxd.VV3Kj8(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVRVSQ(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCHRwQ.VV3TtN(SELF):
   return
  if mode == CCVzxd.VVZm19 and CCVzxd.VVG9lY():
   FF0eUf(SELF, "Download list is empty !", title=title)
  else:
   inst = CCVzxd(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVJOeJ(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCXYrc(Screen, CCqj56):
 VVvQtf = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFWbv3(VVytm4, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCqj56.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FF3tZI(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVm1oY())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4SyA       ,
   "info"  : self.VVFqXY      ,
   "epg"  : self.VVFqXY      ,
   "menu"  : self.VVDW1f     ,
   "cancel" : self.cancel       ,
   "red"  : self.VV21Qu   ,
   "green"  : self.VVAr6D  ,
   "blue"  : self.VVbRWz      ,
   "yellow" : self.VVFGeV ,
   "left"  : BF(self.VVILDq, -1)    ,
   "right"  : BF(self.VVILDq,  1)    ,
   "play"  : self.VV1Avr      ,
   "pause"  : self.VV1Avr      ,
   "playPause" : self.VV1Avr      ,
   "stop"  : self.VV1Avr      ,
   "rewind" : self.VVGW4d      ,
   "forward" : self.VVP4dK      ,
   "rewindDm" : self.VVGW4d      ,
   "forwardDm" : self.VVP4dK      ,
   "last"  : self.VVWvs3      ,
   "next"  : self.VV3Uem      ,
   "pageUp" : BF(self.VVFySV, True)  ,
   "pageDown" : BF(self.VVFySV, False)  ,
   "chanUp" : BF(self.VVFySV, True)  ,
   "chanDown" : BF(self.VVFySV, False)  ,
   "up"  : BF(self.VVFySV, True)  ,
   "down"  : BF(self.VVFySV, False)  ,
   "audio"  : BF(self.VVWn2H, True)  ,
   "subtitle" : BF(self.VVWn2H, False)  ,
   "text"  : self.VVUXWw  ,
   "0"   : BF(self.VV7CqX , 10)   ,
   "1"   : BF(self.VV7CqX , 1)   ,
   "2"   : BF(self.VV7CqX , 2)   ,
   "3"   : BF(self.VV7CqX , 3)   ,
   "4"   : BF(self.VV7CqX , 4)   ,
   "5"   : BF(self.VV7CqX , 5)   ,
   "6"   : BF(self.VV7CqX , 6)   ,
   "7"   : BF(self.VV7CqX , 7)   ,
   "8"   : BF(self.VV7CqX , 8)   ,
   "9"   : BF(self.VV7CqX , 9)
  }, -1)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  if not CCXYrc.VVvQtf:
   CCXYrc.VVvQtf = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFQKHn(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFQKHn(self["myPlayRpt"], "rpt")
  self.VVHBrS()
  self.instance.move(ePoint(40, 40))
  self.VVLSpV(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAsDR)
  except:
   self.timer.callback.append(self.VVAsDR)
  self.timer.start(250, False)
  self.VVAsDR("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVg5CA()
 def VVAr6D(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  self.lastSubtitle = CCLRK4.VVwmQF()
  if "chCode" in iptvRef:
   if CCHRwQ.VV3TtN(self):
    self.VVg5CA(True)
  else:
   self.VVAsDR("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVHBrS(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVkKyI()
  chName = FFhc8v(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVIZs4 + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFIznG(self["myTitle"], tColor)
  FFIznG(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFIznG(self["myPlay%s" % item], tColor)
  picFile = CCUr80.VVzm63(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCUr80.VV8xmm(self)
  cl = CC0tiy.VVu63j(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVAsDR(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCVzxd.VVcVqK()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVkKyI()
  if evName:
   evName = "    %s    " % FFNr4J(evName, VVi1yn)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVGnlY():
   FFDUax(self["myPlayBlu"], "#00FFFFFF")
   FFIznG(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFDUax(self["myPlayBlu"], "#00FFFF88")
   FFIznG(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCXyjP.VVU7Ps(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVX5FP + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFIznG(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FF6FFy(percVal, 0, 100)
   width = int(FFvWYU(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFIznG(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFDUax(self["myPlayMsg"], "#0000ffff")
   else  : FFDUax(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFDUax(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFDUax(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV6twc()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVVd8d(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCLRK4.VVSOr7(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVWvs3()
  state = self.VVnwXT()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFDUax(self["myPlayMsg"], "#0000ff00")
  else     : FFDUax(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVkKyI(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFAJK0(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCUr80.VVOv7T(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCwj2W()
   tpTxt, satTxt = tp.VVlvvd(refCode)
   self.satInfo_TP = tpTxt + "  " + FFNr4J(satTxt, VVh9Nn)
  evName = evNameNext = ""
  evLst = CCh6kb.VV0L0f(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFQKi3(info, iServiceInformation.sVideoWidth) or -1
   h = FFQKi3(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFQKi3(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCUr80.VV9N0g(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVACx1(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFaFw5(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFaFw5(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFaFw5(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVDW1f(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVkKyI()
  FFeEbKSeries = FFXFl9(decodedUrl)
  VVZ4NM = []
  if not "VVAenP" in globals() and not "VVEbPR" in globals():
   VVZ4NM.append((VVh9Nn + "IPTV Menu", "iptv"))
   VVZ4NM.append(VVVvw4)
  if isIptv and not "&end=" in decodedUrl and not FFeEbKSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVZ4NM.append((VVh9Nn + "Catchup Programs", "catchup" ))
    VVZ4NM.append(VVVvw4)
  if refCode:
   c = VVIZs4
   VVZ4NM.append((c + "Stop Current Service"  , "stop"  ))
   VVZ4NM.append((c + "Restart Current Service" , "restart"  ))
   VVZ4NM.append(FF1giv("Replay with ..." , "replayWith", not isDvb, c))
   VVZ4NM.append(VVVvw4)
  if FFeEbKSeries:
   VVZ4NM.append((VVh9Nn + "File Size (on server)", "fileSize" ))
   VVZ4NM.append(VVVvw4)
  if self.enableDownloadMenu:
   c = VVh9Nn
   addSep = False
   if isIptv and FFeEbKSeries:
    VVZ4NM.append((c + "Start Download"  , "dload_cur" ))
    VVZ4NM.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCVzxd.VVG9lY():
    VVZ4NM.append((VVh9Nn + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVZ4NM.append(VVVvw4)
  fPath, fDir, fName = CCNmp1.VVORqp(self)
  if fPath:
   c = VVI2ZY
   if not "VV4tWs" in globals():
    VVZ4NM.append((c + "Open path in File Manager", "VVJuPG"))
   VVZ4NM.append((c + "Add to Bouquet"             , "VVfB6L" ))
   VVZ4NM.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVLwDF"  ))
   VVZ4NM.append(VVVvw4)
  elif isFtp:
   VVZ4NM.append((VVQzZA + "Add FTP Media to Bouquet"     , "VVoFly"))
  if isDvb:
   VVZ4NM.append((VVh9Nn + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVZ4NM.append((VVQzZA + "Start Subtitle", "VVyX1S"))
   VVZ4NM.append(VVVvw4)
  if CFG.playerPos.getValue() : VVZ4NM.append(("Move Bar to Bottom" , "botm"))
  else      : VVZ4NM.append(("Move Bar to Top" , "top" ))
  VVZ4NM.append(("Help", "help"))
  FFLMiy(self, self.VVCjL7, VVZ4NM=VVZ4NM, width=600, title="Options")
 def VVCjL7(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVFGeV()
   elif item == "stop"     : self.VVFLet(0)
   elif item == "restart"    : self.VVFLet(1)
   elif item == "replayWith"   : self.VVk0N5()
   elif item == "fileSize"    : FF1QiT(self, BF(CCUr80.VVuIxl, self), title="Checking Server")
   elif item == "dload_cur"   : CCVzxd.VV34zd(self)
   elif item == "addToDload"   : CCVzxd.VVC0KL(self)
   elif item == "dload_stat"   : CCVzxd.VVwpH0(self)
   elif item == "VVJuPG" : self.close("close_openInFileMan")
   elif item == "VVfB6L" : self.VVfB6L()
   elif item == "VVoFly" : self.VVoFly()
   elif item == "VVyX1S"  : self.VVv48D()
   elif item == "VVLwDF"  : self.VVLwDF()
   elif item == "botm"     : self.VVLSpV(0)
   elif item == "top"     : self.VVLSpV(1)
   elif item == "sigMon"    : self.VV21Qu()
   elif item == "help"     : FFC2xZ(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCXYrc.VVvQtf = None
 def VVFLet(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVHBrS()
   elif typ == 1:
    self.VVAsDR("Restarting Service ...")
    FFdw1m(BF(self.VVlLsb, serv))
 def VVlLsb(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if "&end=" in decodedUrl: BF(self.VVg5CA, True)
  else     : self.session.nav.playService(serv)
 def VVk0N5(self):
  FFLMiy(self, self.VVQbzb, VVZ4NM=CCXyjP.VVsfDi(), width=650, title="Select Player", VVrEme="#11220000", VVRBt6="#11220000")
 def VVQbzb(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFzx2D(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVAsDR("No active service !")
 def VVfB6L(self):
  fPath, fDir, fName = CCNmp1.VVORqp(self)
  if fPath: picker = CC8DHP(self, self, "Add Current Movie to a Bouquet", BF(self.VVP0SG, [fPath]))
  else : FF7BjW(self, "Path not found !", 1500)
 def VVP0SG(self, pathLst):
  return CC8DHP.VVAa9k(pathLst)
 def VVoFly(self):
  picker = CC8DHP(self, self, "Add FTP Media to Bouquet", self.VVPYjU)
 def VVPYjU(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  return CC8DHP.VVAa9k([origUrl], rType=refCode.split(":", 1)[0])
 def VVLwDF(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVAsDR(txt, highlight=ok)
 def VVLSpV(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFE6Br(CFG.playerPos, pos)
 def VV21Qu(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCUr80.VVOv7T(serv)
   if isDvb: self.close("close_sig")
   else : self.VVAsDR("No Signal for Current Service")
 def VVv48D(self):
  self.session.openWithCallback(self.VVxgLK, BF(CCLRK4))
 def VVUXWw(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVkKyI()
   if posTxt and durTxt: self.VVv48D()
   else    : self.VVAsDR("No duration Info. !")
 def VVxgLK(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVFySV(True)
  elif reason == "subtZapDn" : self.VVFySV(False)
  elif reason == "pause"  : self.VV1Avr()
  elif reason == "audio"  : self.VVWn2H(True)
  elif reason == "subtitle" : self.VVWn2H(False)
  elif reason == "rewind"     : self.VVGW4d()
  elif reason == "forward" : self.VVP4dK()
  elif reason == "rewindDm" : self.VVGW4d()
  elif reason == "forwardDm" : self.VVP4dK()
  else      : txt = reason
  if txt:
   FF7BjW(self, txt, 2000)
 def VV4SyA(self):
  if self.isManualSeek:
   self.VVtAg0()
   self.VVVd8d(self.manualSeekPts)
  elif self.shown:
   if CCLRK4.VVDOWV(self): self.VVv48D()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVtAg0()
  else    : self.close()
 def VVFqXY(self):
  FFGNa7(self, fncMode=CCUr80.VVcEdv)
 def VV1Avr(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVAsDR("Toggling Play/Pause ...")
 def VVtAg0(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVILDq(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVDZhn()
   else:
    self.manualSeekSec += direc * self.VVDZhn()
    self.manualSeekSec = FF6FFy(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFvWYU(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFaFw5(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VV7CqX(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVm1oY())
   FFE6Br(CFG.playerJumpMin, self.jumpMinutes)
  self.VVAsDR("Changed Seek Time to : %d%s" % (val, self.VVMxtB()))
 def VVm1oY(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVMxtB())
 def VVMxtB(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVPeON(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVDZhn(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV6twc(self):
  if "VVZesR" in globals():
   global VVZesR
   if VVZesR:
    VVZesR = VVZesR[1:-1]
    if len(VVZesR) == 3: VVZesR = ""
    else     : return VVZesR
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVbRWz(self):
  cList = self.VVGnlY()
  if cList:
   VVZ4NM = []
   for pts, what in cList:
    txt = FFaFw5(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVZ4NM.append((txt, pts))
   FFLMiy(self, self.VVUjKt, VVZ4NM=VVZ4NM, title="Cut List")
  else:
   self.VVAsDR("No Cut-List for this channel !")
 def VVUjKt(self, item=None):
  if item:
   self.VVVd8d(item)
 def VVGnlY(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVP4dK(self) : self.VVBYAy(1)
 def VVGW4d(self) : self.VVBYAy(-1)
 def VVBYAy(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVDZhn() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVPeON())
    self.VVAsDR(txt)
  except:
   self.VVAsDR("Cannot jump")
 def VVVd8d(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVAsDR("Changing Time ...")
 def VVWvs3(self):
  self.VVFLet(1)
  self.VVAsDR("Replaying ...")
  self.VVtAg0()
 def VV3Uem(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVAsDR("Jumping to end ...")
  except:
   pass
 def VVnwXT(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVFySV(self, isUp):
  if self.enableZapping:
   self.VVAsDR("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVtAg0()
   if self.iptvTableParams:
    FFdw1m(BF(self.VVO5Kc, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
    if "/timeshift/" in decodedUrl:
     self.VVAsDR("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV3af5()
  else:
   self.VVAsDR("Zap Disabled !")
 def VV3af5(self):
  self.lastPlayPos = 0
  self.VVHBrS()
  self.VVg5CA()
 def VVO5Kc(self, isUp):
  CCXyjP_inatance, VVSuUg, mode = self.iptvTableParams
  if isUp : VVSuUg.VVWaHM()
  else : VVSuUg.VV1m5t()
  colList = VVSuUg.VVU4OP()
  if mode == "localIptv":
   chName, chUrl = CCXyjP_inatance.VVcyzJ(VVSuUg, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCXyjP_inatance.VVMHfZ(VVSuUg, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCXyjP_inatance.VVZO8i(mode, VVSuUg, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCXyjP_inatance.VVFqFt(mode, VVSuUg, colList)
  else:
   self.VVAsDR("Cannot Zap")
   return
  FFzGKI(self, chUrl, VVEwyq=False)
  self.VV3af5()
 def VVg5CA(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
   if not self.VVxcLl(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVAsDR("Refreshing Portal")
   FFdw1m(self.VVCM4j)
  except:
   pass
 def VVCM4j(self):
  self.restoreLastPlayPos = self.VVBQZ0()
 def VVFGeV(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
  if not decodedUrl or FFXFl9(decodedUrl):
   self.VVAsDR("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCXyjP.VVcPlk(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVAsDR("Reading Program List ...")
   ok_fnc = BF(self.VVxL5i, refCode, chName, streamId, uHost, uUser, uPass)
   FFdw1m(BF(CCXyjP.VVosC7, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVAsDR("Cannot process this channel")
 def VVxL5i(self, refCode, chName, streamId, uHost, uUser, uPass, VVSuUg, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVSuUg.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVAsDR("Changing Program ...")
   FFdw1m(BF(self.VVW4Y7, chUrl))
  else:
   self.VVAsDR("Incorrect Timestamp !")
 def VVW4Y7(self, chUrl):
  FFzGKI(self, chUrl, VVEwyq=False)
  self.lastPlayPos = 0
  self.VVHBrS()
 def VVWn2H(self, isAudio):
  try:
   VVbIOb = InfoBar.instance
   if VVbIOb:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVbIOb)
    else  : self.session.open(SubtitleSelection, VVbIOb)
  except:
   pass
 @staticmethod
 def VV6CYR(session, mode=None):
  if   mode == "close_sig"   : FFtWxv(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCXyjP)
  elif mode == "close_openInFileMan" : session.open(CCNmp1, gotoMovie=True)
 @staticmethod
 def VVRGWe(session, **kwargs):
  session.openWithCallback(BF(CCXYrc.VV6CYR, session), CCXYrc, **kwargs)
class CCVDHz(Screen):
 def __init__(self, session, title="", VV6LqR="Continue?", VVsXR5=True, VViggQ=False):
  self.skin, self.skinParam = FFWbv3(VVGJSr, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VV6LqR = VV6LqR
  self.VViggQ = VViggQ
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVsXR5 : VVZ4NM = [no , yes]
  else   : VVZ4NM = [yes, no ]
  FF3tZI(self, title, VVZ4NM=VVZ4NM, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV4SyA ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VV6LqR)
  if self.VViggQ:
   self["myLabel"].instance.setHAlign(0)
  self.VViF76()
  FF4VOV(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFmi7L(self["myMenu"])
  FFxf4g(self, self["myMenu"])
 def VV4SyA(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VViF76(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCfVwq(Screen):
 def __init__(self, session, title="", VVZ4NM=None, width=1000, height=850, VVsgYf=30, barText="", minRows=1, VVsd1c=None, VVsk8Y=None, VV6rAJ=None, VVWjWA=None, VVcrQj=None, VVs32w=None, VV9pbf=False, VVmNi5=False, VVpQam=None, VVPgqu=True, VVrEme="#22003344", VVRBt6="#22002233"):
  self.skin, self.skinParam = FFWbv3(VV3sDt, width, height, 50, 40, 30, VVrEme, VVRBt6, VVsgYf, barHeight=40, topRightBtns=3 if VVsk8Y else 0)
  self.session   = session
  self.VVZ4NM   = VVZ4NM
  self.barText   = barText
  self.minRows   = minRows
  self.VVsd1c   = VVsd1c
  self.VVsk8Y   = VVsk8Y
  self.VV6rAJ   = VV6rAJ
  self.VVWjWA  = VVWjWA
  self.VVcrQj  = ("Delete File", BF(self.VVq47l, VVpQam)) if not VVpQam is None else VVcrQj
  self.VVs32w   = VVs32w
  self.VV9pbf  = VV9pbf
  self.VVmNi5  = VVmNi5
  self.Title    = title
  FF3tZI(self, title, VVZ4NM=VVZ4NM)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4SyA    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVTMWH   ,
   "red"  : self.VV8PQa   ,
   "green"  : self.VVdVdE   ,
   "yellow" : self.VV6Zxb   ,
   "blue"  : self.VVg5qF   ,
   "pageUp" : self.VV1zUm ,
   "chanUp" : self.VV1zUm ,
   "pageDown" : self.VV3jTM  ,
   "chanDown" : self.VV3jTM  ,
   "0"   : BF(self.VVOhQn, 0) ,
   "1"   : BF(self.VVOhQn, 1) ,
   "2"   : BF(self.VVOhQn, 2) ,
   "3"   : BF(self.VVOhQn, 3) ,
   "4"   : BF(self.VVOhQn, 4) ,
   "5"   : BF(self.VVOhQn, 5) ,
   "6"   : BF(self.VVOhQn, 6) ,
   "7"   : BF(self.VVOhQn, 7) ,
   "8"   : BF(self.VVOhQn, 8) ,
   "9"   : BF(self.VVOhQn, 9)
  }, -1)
  if VVPgqu:
   FFLPhw(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FF4VOV(self["myMenu"])
  FFxUTp(self, minRows=self.minRows)
  FFBjfS(self)
  self.VVWgSv(self["keyRed"]  , self.VV6rAJ )
  self.VVWgSv(self["keyGreen"] , self.VVWjWA )
  self.VVWgSv(self["keyYellow"] , self.VVcrQj )
  self.VVWgSv(self["keyBlue"]  , self.VVs32w )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFxlor(self)
 def VVWgSv(self, btnObj, btnFnc):
  if btnFnc:
   FFTvkX(btnObj, btnFnc[0])
 def VVjLPA(self, fnc=None):
  self.VVWjWA = fnc
  if fnc : self.VVWgSv(self["keyGreen"], self.VVWjWA)
  else : self["keyGreen"].hide()
 def VVOhQn(self, digit):
  digit = str(digit)
  VVZ4NM = self["myMenu"].list
  for ndx, item in enumerate(VVZ4NM):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFhc8v(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVcLR7(ndx)
     self.VV4SyA()
     break
 def VV4SyA(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVsd1c:
    self.VVsd1c((self, txt, ref, ndx))
   else:
    if self.VV9pbf: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVTMWH(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVsk8Y and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVsk8Y(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VV8PQa(self)  : self.VVFpn4(self.VV6rAJ)
 def VVdVdE(self) : self.VVFpn4(self.VVWjWA)
 def VV6Zxb(self) : self.VVFpn4(self.VVcrQj)
 def VVg5qF(self) : self.VVFpn4(self.VVs32w)
 def VVFpn4(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVmNi5:
    self.cancel()
 def VVUe1j(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVZ4NM = self["myMenu"].list
  VVZ4NM.pop(ndx)
  if len(VVZ4NM) > 0: self["myMenu"].setList(VVZ4NM)
  else    : self.close()
 def VVq47l(self, basePath, menuObj, fName):
  FF4s3j(self, BF(self.VVCveQ, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVCveQ(self, path):
  FFfhv3(path)
  if fileExists(path) : FF7BjW(self, "Not deleted", 1000)
  else    : self.VVUe1j()
 def VVAfT3(self, VVZ4NM):
  if len(VVZ4NM) > 0:
   newList = []
   for item in VVZ4NM:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFxUTp(self, minRows=self.minRows)
  else:
   self.close("")
 def VVRR5n(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFxUTp(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVcjar(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVcLR7(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVhTm7(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVcLR7(ndx)
    break
 def VVEfNd(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVcLR7(ndx)
    break
 def VV1zUm(self) : self["myMenu"].moveToIndex(0)
 def VV3jTM(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCWhQY(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVDpqo=None, VVXdZ9=None, VVQT0l=None, VVsgYf=26, VVROQm=False, VVOPrI=0, VVFJkn=None, VVU95Y=None, menuButtonFnc=None, VVdvf0=None, VV8lmg=None, VV0RwZ=None, VVUpMt=None, VVbl2R=None, VVHEpO=None, VVQLDs=None, VVSboA=-1, VVEIfy=0, searchCol=0, lastFindConfigObj=None, VVrEme=None, VVRBt6=None, VVPZCV="#00dddddd", VVfKIv="#11002233", VVIWfT=None, VV6z2K="#11111111", VV7JIr="#0a555555", VVk8oo="#0affffff", VVpBpY="#11552200", VVAH5S="#0055ff55", VVAH5SRev="#0000bbff"):
  self.skin, self.skinParam = FFWbv3(VVsOWG, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF3tZI(self, title)
  self.Title     = title
  self.header     = header
  self.VVDpqo     = VVDpqo
  self.totalCols    = len(VVDpqo[0])
  self.VVOPrI   = VVOPrI
  self.lastSortModeIsReverese = False
  self.VVROQm   = VVROQm
  self.VVyz1H   = 0.01
  self.VVHINJ   = 0.02
  self.VV4du4 = 0.03
  self.VVpPui  = 1
  self.VVQT0l = VVQT0l
  self.colWidthPixels   = []
  self.VVFJkn   = VVFJkn
  self.OKButtonObj   = None
  self.VVU95Y   = VVU95Y
  self.VVdvf0   = VVdvf0
  self.VV8lmg   = VV8lmg
  self.VV0RwZ  = VV0RwZ
  self.VVUpMt   = VVUpMt
  self.VVbl2R    = VVbl2R
  self.VVHEpO   = VVHEpO
  self.tableRefreshCB   = None
  self.VVQLDs  = VVQLDs
  self.menuButtonFnc   = menuButtonFnc
  self.VVSboA    = VVSboA
  self.VVEIfy   = VVEIfy
  self.searchCol    = searchCol
  self.VVXdZ9    = VVXdZ9
  self.keyPressed    = -1
  self.VVsgYf    = FFhoFB(VVsgYf)
  self.VV12Gz    = FFyUJL(self.VVsgYf, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVrEme    = VVrEme
  self.VVRBt6      = VVRBt6
  self.VVPZCV    = FFYkgg(VVPZCV)
  self.VVfKIv    = FFYkgg(VVfKIv)
  self.VVIWfT    = VVIWfT
  self.VV6z2K    = FFYkgg(VV6z2K)
  self.VV7JIr   = FFYkgg(VV7JIr)
  self.VVk8oo    = FFYkgg(VVk8oo)
  self.VVpBpY    = FFYkgg(VVpBpY)
  self.VVAH5S   = FFYkgg(VVAH5S)
  self.VVAH5SRev  = FFYkgg(VVAH5SRev)
  self.VVJZs5  = False
  self.selectedItems   = 0
  self.VVWHR3   = FFYkgg("#01fefe01")
  self.VVu8eP   = FFYkgg("#11400040")
  self.VVTdHr  = self.VVWHR3
  self.VVGQzI  = self.VV6z2K
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVEIfy:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVEIfy == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVcg3H  ,
   "red"  : self.VV7W2A  ,
   "green"  : self.VVjn2Z ,
   "yellow" : self.VV1ZNz ,
   "blue"  : self.VVAjkh  ,
   "menu"  : self.VVjtFy ,
   "info"  : self.VVjgQ9  ,
   "cancel" : self.VVXeyG  ,
   "up"  : self.VV1m5t    ,
   "down"  : self.VVWaHM  ,
   "left"  : self.VV5pnx   ,
   "right"  : self.VVJIVY  ,
   "next"  : self.VV9oQY  ,
   "last"  : self.VV3tBd  ,
   "home"  : self.VVom40  ,
   "pageUp" : self.VVom40  ,
   "chanUp" : self.VVom40  ,
   "end"  : self.VVPPM0  ,
   "pageDown" : self.VVPPM0  ,
   "chanDown" : self.VVPPM0
  }, -1)
  FFLPhw(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  try:
   self.VVlcL2()
  except Exception as e:
   FF0eUf(self, str(e), title=self.Title)
   self.close(None)
 def VVlcL2(self):
  FFxlor(self)
  if self.VVrEme:
   FFIznG(self["myTitle"], self.VVrEme)
  if self.VVRBt6:
   FFIznG(self["myBody"] , self.VVRBt6)
   FFIznG(self["myTableH"] , self.VVRBt6)
   FFIznG(self["myTable"] , self.VVRBt6)
   FFIznG(self["myBar"]  , self.VVRBt6)
  self.VVWgSv(self.VVdvf0  , self["keyRed"])
  self.VVWgSv(self.VV8lmg  , self["keyGreen"])
  self.VVWgSv(self.VV0RwZ , self["keyYellow"])
  self.VVWgSv(self.VVUpMt  , self["keyBlue"])
  if self.VVFJkn:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVFJkn[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVFJkn[0])
    FFIznG(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV12Gz)
  self["myTableH"].l.setFont(0, gFont(VVbeZc, self.VVsgYf))
  self["myTable"].l.setItemHeight(self.VV12Gz)
  self["myTable"].l.setFont(0, gFont(VVbeZc, self.VVsgYf))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV12Gz)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV12Gz))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV12Gz)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV12Gz
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV12Gz * len(self.VVDpqo) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVQT0l:
   self.VVQT0l = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVQT0l)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVXdZ9:
   self.VVXdZ9 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVXdZ9
   self.VVXdZ9 = []
   for item in tmpList:
    self.VVXdZ9.append(item | RT_VALIGN_CENTER)
  self.VVcKUT()
  if self.VVbl2R:
   self.VVbl2R(self)
 def VVWgSv(self, btnFnc, btn):
  if btnFnc : FFTvkX(btn, btnFnc[0])
  else  : FFTvkX(btn, "")
 def VVdMhy(self, waitTxt):
  FF1QiT(self, self.VVcKUT, title=waitTxt)
 def VVcKUT(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVAH5SRev if self.lastSortModeIsReverese else self.VVAH5S
    self["myTableH"].setList([self.VVF3PO(0, self.header, self.VVk8oo, self.VVpBpY, self.VVk8oo, self.VVpBpY, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVDpqo):
    self["myTable"].list.append(self.VVF3PO(c, row, self.VVPZCV, self.VVfKIv, self.VVIWfT, self.VV6z2K, None))
   self.VVDpqo = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVSboA > -1:
    self["myTable"].moveToIndex(self.VVSboA )
   self.VVqHPG()
   if self.VVEIfy:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV12Gz * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFrdtL(self, width, newH)
   if self.VVHEpO:
    self.VVFpn4(self.VVHEpO, None)
   if self.tableRefreshCB:
    self.VVFpn4(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FF0eUf(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVF3PO(self, keyIndex, columns, VVPZCV, VVfKIv, VVIWfT, VV6z2K, VVAH5S):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVAH5S and ndx == self.VVOPrI : textColor = VVAH5S
   else           : textColor = VVPZCV
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFYkgg(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVfKIv = c
    entry = span.group(3)
   if self.VVXdZ9[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV12Gz)
           , font   = 0
           , flags   = self.VVXdZ9[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVfKIv
           , color_sel  = VVIWfT or textColor
           , backcolor_sel = VV6z2K
           , border_width = 1
           , border_color = self.VV7JIr
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVjgQ9(self):
  rowData = self.VVefb7()
  if rowData:
   title, txt, colList = rowData
   if self.VVU95Y:
    fnc  = self.VVU95Y[1]
    params = self.VVU95Y[2]
    fnc(self, title, txt, colList)
   else:
    FFXEvX(self, txt, title)
 def VVcg3H(self):
  if   self.VVJZs5 : self.VVFSYg(self.VVZ2t7(), mode=2)
  elif self.VVFJkn  : self.VVFpn4(self.VVFJkn, None)
  else      : self.VVjgQ9()
 def VV7W2A(self) : self.VVFpn4(self.VVdvf0 , self["keyRed"])
 def VVjn2Z(self) : self.VVFpn4(self.VV8lmg , self["keyGreen"])
 def VV1ZNz(self): self.VVFpn4(self.VV0RwZ , self["keyYellow"])
 def VVAjkh(self) : self.VVFpn4(self.VVUpMt , self["keyBlue"])
 def VVFpn4(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF7BjW(self, buttonFnc[3])
    FFdw1m(BF(self.VVxGhd, buttonFnc))
   else:
    self.VVxGhd(buttonFnc)
 def VVxGhd(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVefb7()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVFSYg(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVWHR3
   newRow = self.VVU4OP()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVF3PO(ndx, newRow, self.VVPZCV, self.VVfKIv, self.VVIWfT, self.VV6z2K, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVF3PO(ndx, newRow, self.VVWHR3, self.VVu8eP, self.VVTdHr, self.VVGQzI, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVZ2t7() < len(self["myTable"].list) - 1:
    self.VVWaHM()
   else:
    self.VVqHPG()
 def VVcdtH(self)  : FF1QiT(self, BF(self.VVEWGC, True ), title="Selecting all ..."  )
 def VVnLFh(self) : FF1QiT(self, BF(self.VVEWGC, False), title="Unselecting all ...")
 def VVEWGC(self, isSel=True):
  if isSel:
   fg, bg = self.VVWHR3, self.VVu8eP
   self.selectedItems = len(self["myTable"].list)
   self.VVcNsR(True)
  else:
   fg, bg = self.VVPZCV, self.VVfKIv
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVWHR3
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVefb7(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVQT0l[i] > 1 or self.VVQT0l[i] == self.VVyz1H or self.VVQT0l[i] == self.VV4du4:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVXeyG(self):
  if self.VVQLDs : self.VVQLDs(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVdoWv(self):
  return self["myTitle"].getText().strip()
 def VVXmTk(self):
  return self.header
 def VVcL6X(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVxw3n(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFDUax(self["myBar"], color)
 def VVXBxd(self, txt):
  FF7BjW(self, txt)
 def VVDnVh(self, txt, Time=1000):
  FF7BjW(self, txt, Time)
 def VVZO03(self): self["keyGreen"].show()
 def VVy2wX(self): self["keyGreen"].hide()
 def VVsdbM(self): return self["keyGreen"].visible
 def VVTVqz(self):
  FF7BjW(self)
 def VV9XZ7(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVdq0g(self):
  return len(self["myTable"].list)
 def VVZ2t7(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVmUCw(self):
  return len(self["myTable"].list)
 def VVcNsR(self, isOn):
  self.VVJZs5 = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVUpMt: self["keyBlue"].hide()
   if self.VVFJkn and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVUpMt: self["keyBlue"].show()
   if self.VVFJkn and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVFJkn[0])
   self.VVnLFh()
  FFIznG(self["myTitle"], color)
  FFIznG(self["myBar"]  , color)
 def VVeK6u(self):
  return self.VVJZs5
 def VVv1D2(self):
  return self.selectedItems
 def VVCDCb(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVqHPG()
 def VVJoFm(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVvsnp(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVdq0g()
  txt += FF0CQw("Total Unique Items", VVqDXM)
  for i in range(self.totalCols):
   if self.VVQT0l[i - 1] > 1 or self.VVQT0l[i - 1] == self.VVyz1H or self.VVQT0l[i - 1] == self.VV4du4:
    name, tot = self.VVJoFm(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFXEvX(self, txt)
 def VVbc1J(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVU4OP(self):
  return self.VVTuTs(self["myTable"].l.getCurrentSelectionIndex())
 def VVTuTs(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVuO1Y(self, newList, newTitle="", VV8SPjMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVcL6X(newTitle)
  if newList:
   self.VVDpqo = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVROQm and self.VVOPrI == 0:
    isNum = True
   else:
    for cols in self.VVDpqo:
     if not FFaPm7(cols[self.VVOPrI]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVDpqo.sort(key=lambda x: int(x[self.VVOPrI])  , reverse=self.lastSortModeIsReverese)
    else : self.VVDpqo.sort(key=lambda x: x[self.VVOPrI].lower() , reverse=self.lastSortModeIsReverese)
   if VV8SPjMsg : self.VVdMhy("Refreshing ...")
   else   : self.VVcKUT()
  else:
   FF0eUf(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VV9lFe(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVF3PO(self.VVmUCw(), row, self.VVPZCV, self.VVfKIv, self.VVIWfT, self.VV6z2K, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVPPM0()
 def VVeH2a(self):
  self["myTable"].list.pop(self.VVZ2t7())
  self["myTable"].l.setList(self["myTable"].list)
 def VVgAJR(self, data):
  ndx = self.VVZ2t7()
  newRow = self.VVF3PO(ndx, data, self.VVPZCV, self.VVfKIv, self.VVIWfT, self.VV6z2K, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVqHPG()
   return True
  else:
   return False
 def VVghZJ(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVF3PO(ndx, data, self.VVPZCV, self.VVfKIv, self.VVIWfT, self.VV6z2K, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVujI5()
 def VVujI5(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VV8yZR(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVJnOe(self, colNum, textToFind, VVR9V4=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVqHPG()
    break
  else:
   if VVR9V4:
    FF7BjW(self, "Not found", 1000)
 def VVeEhA(self, colDict, VVR9V4=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVqHPG()
    return
  if VVR9V4:
   FF7BjW(self, "Not found", 1000)
  return False
 def VVK6pF(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVfPmi(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFaPm7(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVzBF6(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVWHR3:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVA1kq(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVWHR3:
     return ndx
  return -1
 def VVNKQi(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVWHR3:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVpoRJ(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVWHR3: return True
  else        : return False
 def VVOxLE(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVjtFy(self):
  if self.menuButtonFnc:
   self.VVxGhd(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVEIfy:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVZ2t7()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVZ4NM1, VVNX5F = CCC0Pu.VVu0FI(self, False, False)
  VVZ4NM = []
  VVZ4NM.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVZ4NM.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVZ4NM.append(("Find ...\t\t%s" % (FFNr4J(txt, VVi9VJ) if txt else ""), "findNew"   ))
  VVZ4NM.append(itemOf(bool(VVZ4NM1)    , "Find (from Filter) ..."   , "filter"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Table Statistcis"             , "tableStat"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((FFNr4J("Export Table to .html"     , VVqDXM) , "VVzCTe" ))
  VVZ4NM.append((FFNr4J("Export Table to .csv"     , VVqDXM) , "VVpv1R" ))
  VVZ4NM.append((FFNr4J("Export Table to .txt (Tab Separated)", VVqDXM) , "VVc34P" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVQT0l[i] > 1 or self.VVQT0l[i] == self.VVHINJ:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVZ4NM.append(VVVvw4)
   if tot == 1 : VVZ4NM.append(("Sort", sList[0][1]))
   else  : VVZ4NM += sList
  VVs32w = ("Keys Help", self.FFW2TvHelp)
  FFLMiy(self, self.VVh9zH, VVZ4NM=VVZ4NM, title=self.VVdoWv(), VVs32w=VVs32w)
 def VVh9zH(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVpvWo()
   elif item == "findPrev"  : self.VVpvWo(isPrev=True)
   elif item == "findNew"  : self.VVyU7f()
   elif item == "filter"  : self.VVnhdU()
   elif item == "tableStat" : self.VVvsnp()
   elif item == "VVzCTe": FF1QiT(self, self.VVzCTe, title=title)
   elif item == "VVpv1R" : FF1QiT(self, self.VVpv1R , title=title)
   elif item == "VVc34P" : FF1QiT(self, self.VVc34P , title=title)
   else:
    if self.VVOPrI == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVOPrI, self.lastSortModeIsReverese = item, False
    if self.VVROQm and self.VVOPrI == 0 or self.VVfPmi(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVcKUT(onlyHeader=True)
 def FFW2TvHelp(self, VVKicw, path):
  FFC2xZ(self, "_help_table", "Table (Keys Help)")
 def VV1m5t(self):
  self["myTable"].up()
  self.VVqHPG()
 def VVWaHM(self):
  self["myTable"].down()
  self.VVqHPG()
 def VV5pnx(self):
  self["myTable"].pageUp()
  self.VVqHPG()
 def VVJIVY(self):
  self["myTable"].pageDown()
  self.VVqHPG()
 def VVom40(self):
  self["myTable"].moveToIndex(0)
  self.VVqHPG()
 def VVPPM0(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVqHPG()
 def VVpxIX(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVqHPG()
 def VV9oQY(self):
  if self.lastFindConfigObj.getValue():
   if self.VVZ2t7() == len(self["myTable"].list) - 1 : FF7BjW(self, "End reached", 1000)
   else              : self.VVpvWo()
  else:
   FF7BjW(self, 'Set "Find" in Menu', 1500)
 def VV3tBd(self):
  if self.lastFindConfigObj.getValue():
   if self.VVZ2t7() == 0 : FF7BjW(self, "Top reached", 1000)
   else       : self.VVpvWo(isPrev=True)
  else:
   FF7BjW(self, 'Set "Find" in Menu', 1500)
 def VVHWjV(self, txt):
  FFE6Br(self.lastFindConfigObj, txt)
 def VVyU7f(self):
  FFFMZg(self, self.VVafx1, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVafx1(self, VVz5S3):
  if not VVz5S3 is None:
   txt = VVz5S3.strip()
   self.VVHWjV(txt)
   if VVz5S3: self.VVpvWo(reset=True)
   else  : FF7BjW(self, "Nothing to find !", 1500)
 def VVnhdU(self):
  VVZ4NM, VVNX5F = CCC0Pu.VVu0FI(self, False, False)
  VVcrQj = ("Edit Filter", BF(self.VVCRdZ, VVNX5F))
  if VVZ4NM : FFLMiy(self, self.VV5vjs, VVZ4NM=VVZ4NM, VVcrQj=VVcrQj, title="Find from Filter")
  else  : FF7BjW(self, "Filter Error !", 1500)
 def VV5vjs(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVHWjV(txt)
    self.VVpvWo(reset=True)
   else:
    FF7BjW(self, "No entry !", 1500)
 def VVCRdZ(self, VVNX5F, VVMD9SObj, sel):
  if fileExists(VVNX5F) : CCC9Tv(self, VVNX5F, VVtCUJ=None)
  else       : FF7Hmv(self, VVNX5F)
  VVMD9SObj.cancel()
 def VVpvWo(self, reset=False, isPrev=False):
  curRow = self.VVZ2t7()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCC0Pu.VVUzJV(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVpxIX(i)
      break
    elif any(x in line for x in tupl):
     self.VVpxIX(i)
     break
   else:
    FF7BjW(self, "Not found", 1000)
  else:
   FF7BjW(self, "Check your query", 1500)
 def VVc34P(self):
  expFile = self.VVgHLx() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVmwmX()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVTuTs(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVQT0l[ndx] > self.VVpPui or self.VVQT0l[ndx] == self.VV4du4:
      col = self.VVLm4B(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVGvgJ(expFile)
 def VVpv1R(self):
  expFile = self.VVgHLx() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVmwmX()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVTuTs(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVQT0l[ndx] > self.VVpPui or self.VVQT0l[ndx] == self.VV4du4:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVLm4B(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVGvgJ(expFile)
 def VVzCTe(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVdoWv(), PLUGIN_NAME, VVAgrE)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVdoWv()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVmwmX()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVQT0l:
   colgroup += '   <colgroup>'
   for w in self.VVQT0l:
    if w > self.VVpPui or w == self.VV4du4:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVgHLx() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVTuTs(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVQT0l[ndx] > self.VVpPui or self.VVQT0l[ndx] == self.VV4du4:
      col = self.VVLm4B(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVGvgJ(expFile)
 def VVmwmX(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVQT0l[ndx] > self.VVpPui or self.VVQT0l[ndx] == self.VV4du4:
     newRow.append(col.strip())
  return newRow
 def VVLm4B(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFhc8v(col)
 def VVgHLx(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVdoWv())
  fileName = fileName.replace("__", "_")
  path  = FFSiyE(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFXJI8()
  return expFile
 def VVGvgJ(self, expFile):
  FFH1Ib(self, "File exported to:\n\n%s" % expFile, title=self.VVdoWv())
 def VVqHPG(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC0tiy():
 def __init__(self, pixmapObj, picPath, VVfKIv=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVfKIv  = VVfKIv or "#2200002a"
 def VVa06h(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVQcWN)
    except:
     self.picLoad.PictureData.get().append(self.VVQcWN)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVfKIv])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVQcWN(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVQh8r(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVu63j(pixmapObj, path, VVfKIv=None):
  cl = CC0tiy(pixmapObj, path, VVfKIv)
  ok = cl.VVa06h()
  if ok: return cl
  else : return None
class CCWJhm(Screen):
 def __init__(self, session, VV52TG, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFeubS()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFWbv3(VVBAUc, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VV52TG = VV52TG
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FF3tZI(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VV0OLE  ,
   "up" : BF(self.VVpuXX, -1),
   "down" : BF(self.VVpuXX,  1),
   "left" : BF(self.VVpuXX, -1),
   "right" : BF(self.VVpuXX,  1)
  }, -1)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  self.VV3RBW()
  self.picViewer = CC0tiy.VVu63j(self["myPic"], self.VV52TG)
  if self.picViewer:
   if self.showGrnMsg:
    FF7BjW(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF0eUf(self, "Cannot view picture file:\n\n%s" % self.VV52TG)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVQh8r()
  if self.cbFnc  : self.cbFnc(self.VV52TG)
 def VVpuXX(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VV52TG = FFSiyE(os.path.dirname(self.VV52TG)) + fName
    self.picViewer.picPath = self.VV52TG
    self.picViewer.VVa06h()
    self.VV3RBW()
 def VV0OLE(self):
  txt = "%s:\n  %s" % (FFNr4J("Path", VVQzZA), self.fakePath or self.VV52TG)
  size, sizeTxt, resTxt, form, mode = CCzEE9.VVf8dM(self.VV52TG)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFNr4J("Properties", VVQzZA)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFXEvX(self, txt, title="File Information")
 def VV3RBW(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VV52TG)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVpAVI(SELF, VV52TG, **kwargs):
  SELF.session.open(CCWJhm, VV52TG, **kwargs)
class CC5tNx(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFWbv3(VVDZ6a, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FF3tZI(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.onExit)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFKiof("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVTBDS(SELF, mviFile):
  SELF.session.openWithCallback(BF(CC5tNx.VVt6oz, SELF), CC5tNx, mviFile)
 @staticmethod
 def VVt6oz(SELF, reason=None):
  if reason == -1: FF0eUf(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCVmVV(Screen, ConfigListScreen):
 VVetdd = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VVERBh, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF3tZI(self, title=self.Title)
  FFTvkX(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVvd12()
  self.onShown.append(self.VV7StE)
 def VVvd12(self):
  kList = {
    "ok" : self.VV4SyA   ,
    "green" : self.VVgYK1 ,
    "menu" : self.VVNCvU ,
    "cancel": self.VVr8hO ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVFqhT, 0)
     kList["chanDown"] = BF(self["config"].VVFqhT, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFBjfS(self)
  FF4VOV(self["config"])
  FFxUTp(self, self["config"])
  FFxlor(self)
  self["config"].onSelectionChanged.append(self.VV0Pmm)
  FFIznG(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VV0Pmm()
 def VV0Pmm(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VV4SyA(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VV1F2n()
   elif item == CFG.MovieDownloadPath   : self.VVxque(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVKyme()
   elif isinstance(item, ConfigDirectory) : self.VVUtGJ(item)
   else         : CCVmVV.VV0AtB(self, item, title)
 @staticmethod
 def VV0AtB(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVZ4NM = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVi9VJ + txt
    elif val == confItem.default: defNdx, txt = ndx, VVde5r + txt
   VVZ4NM.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVs32w  = ("Current", BF(CCVmVV.VV2tQr, curNdx))
  VVcrQj = ("Default", BF(CCVmVV.VV2tQr, defNdx))
  VVKicw = FFLMiy(SELF, BF(CCVmVV.VVGAs1, confItem, cbFnc, isSave), VVZ4NM=VVZ4NM, width=1200, VVcrQj=VVcrQj, VVs32w=VVs32w, title=title, VVrEme="#33221111", VVRBt6="#33110011")
  VVKicw.VVcLR7(curNdx)
 @staticmethod
 def VVGAs1(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFE6Br(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VV2tQr(ndx, VVMD9SObj, item):
  VVMD9SObj.VVcLR7(ndx)
 @staticmethod
 def VVlhBD(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVxque(self, item, title):
  tot = CCVzxd.VVcVqK()
  if tot : FF0eUf(self, "Cannot change while downloading.", title=title)
  else : self.VVUtGJ(item)
 def VVKyme(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CC9SOR.VV7OQi(self, "", curEnc)
  if lst:
   VVcrQj = ("Default", self.VVGT8I)
   VVs32w  = ("Current", self.VVqKhy)
   VVKicw = FFLMiy(self, self.VVBGdj, title="Select Priority Encoding", VVZ4NM=lst, width=1000, height=1000, VVs32w=VVs32w, VVcrQj=VVcrQj, VVrEme="#22220000", VVRBt6="#22220000", VV9pbf=True)
   VVKicw.VVhTm7(curEnc)
 def VVBGdj(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVGT8I(self, VVKicw, item): VVKicw.VVhTm7(VVQZ4P)
 def VVqKhy(self, VVKicw, item): VVKicw.VVhTm7(CFG.subtDefaultEnc.getValue())
 def VV1F2n(self):
  VVZ4NM = []
  VVZ4NM.append(("Auto Find" , "auto"))
  VVZ4NM.append(("Custom Path" , "cust"))
  FFLMiy(self, self.VVeuXZ, VVZ4NM=VVZ4NM, title="IPTV Hosts Files Path")
 def VVeuXZ(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVCAF9)
   elif item == "cust":
    VVJIKO = self.VVBmtz()
    if VVJIKO : self.VVWijc(VVJIKO)
    else  : self.session.openWithCallback(self.VV2ONo, BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst="/"))
 def VVWijc(self, VVJIKO):
  VVQLDs = self.VVp4do
  VVdvf0 = ("Remove"  , self.VVnSBX , [])
  VV0RwZ = ("Add "  , self.VVMS8t, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVXdZ9  = (LEFT   , LEFT  )
  FFW2Tv(self, None, title="IPTV Hosts Search Paths", header=header, VVDpqo=VVJIKO, width=1200, height=700, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=26, VVQLDs=VVQLDs, VVdvf0=VVdvf0, VV0RwZ=VV0RwZ
    , VVrEme="#22220000", VVRBt6="#22110000", VVfKIv="#22110011", VV6z2K="#11223025", VV7JIr="#0a333333", VVpBpY="#11400040")
 def VVp4do(self, VVSuUg):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVvCGo)
  VVSuUg.cancel()
 def VV2ONo(self, path):
  if path:
   FFE6Br(CFG.iptvHostsDirs, FFSiyE(path.strip()))
   VVJIKO = self.VVBmtz()
   if VVJIKO : self.VVWijc(VVJIKO)
   else  : FF7BjW(self, "Cannot add dir", 1500)
 def VVEjaP(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVCAF9:
   return []
  return lst
 def VVBmtz(self):
  lst = self.VVEjaP()
  if lst:
   VVJIKO = []
   for Dir in lst:
    VVJIKO.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVJIKO.sort(key=lambda x: x[0].lower())
   return VVJIKO
  else:
   return []
 def VVMS8t(self, VVSuUg, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVxkes, VVSuUg)
         , BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=sDir))
 def VVxkes(self, VVSuUg, path):
  if path:
   path = FFSiyE(path.strip())
   if self.VV53Qo(VVSuUg, path):
    FF7BjW(VVSuUg, "Already added", 1500)
   else:
    lst = self.VVEjaP()
    lst.append(path)
    FFE6Br(CFG.iptvHostsDirs, ",".join(lst))
    VVJIKO = self.VVBmtz()
    VVSuUg.VVuO1Y(VVJIKO, tableRefreshCB=BF(self.VVuY9N, path))
 def VVuY9N(self, path, VVSuUg, title, txt, colList):
  self.VV53Qo(VVSuUg, path)
 def VV53Qo(self, VVSuUg, path):
  for ndx, row in enumerate(VVSuUg.VVOxLE()):
   if row[0].strip() == path.strip():
    VVSuUg.VVpxIX(ndx)
    return True
  return False
 def VVnSBX(self, VVSuUg, title, txt, colList):
  path = colList[0]
  FF4s3j(self, BF(self.VVrh2Q, VVSuUg), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVrh2Q(self, VVSuUg):
  row = VVSuUg.VVU4OP()
  path, rem = row[0], row[1]
  VVJIKO = []
  lst = []
  for ndx, row in enumerate(VVSuUg.VVOxLE()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVJIKO.append((tPath, tRem))
  if len(VVJIKO) > 0:
   FFE6Br(CFG.iptvHostsDirs, ",".join(lst))
   VVSuUg.VVuO1Y(VVJIKO)
   FF7BjW(VVSuUg, "Deleted", 1500)
  else:
   FFE6Br(CFG.iptvHostsMode, VVCAF9)
   FFE6Br(CFG.iptvHostsDirs, "")
   VVSuUg.cancel()
   FFdw1m(BF(FF7BjW, self, "Changed to Auto-Find", 1500))
 def VVUtGJ(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VV45DC, configObj)
         , BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=sDir))
 def VV45DC(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVr8hO(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FF4s3j(self, self.VVgYK1, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVgYK1(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVQxvB()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVNCvU(self):
  VVZ4NM = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVZ4NM.append((txt    , "VVJxmS"   ))
  else        : VVZ4NM.append((txt    ,       ))
  VVZ4NM.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Reset %s Settings" % PLUGIN_NAME      , "VVOPgk"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Backup %s Settings" % PLUGIN_NAME      , "VVV0HD"  ))
  VVZ4NM.append(("Restore %s Settings" % PLUGIN_NAME     , "VVFuKD"  ))
  if fileExists(VVbRSD + CCVmVV.VVetdd):
   VVZ4NM.append(VVVvw4)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVZ4NM.append(('%s Checking for Update' % txt1     , txt2     ))
   VVZ4NM.append(("Reinstall %s" % PLUGIN_NAME      , "VVFOs7"  ))
   VVZ4NM.append(("Update %s" % PLUGIN_NAME      , "VVYaHC"   ))
  FFLMiy(self, self.VVn0ig, VVZ4NM=VVZ4NM, title="Config. Options")
 def VVn0ig(self, item=None):
  if item:
   if   item == "VVJxmS"  : FF4s3j(self, self.VVJxmS , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCdDf8)
   elif item == "VVOPgk"  : FF4s3j(self, BF(self.VVOPgk, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVV0HD" : self.VVV0HD()
   elif item == "VVFuKD" : FF1QiT(self, self.VVFuKD, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFE6Br(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFE6Br(CFG.checkForUpdateAtStartup, False)
   elif item == "VVFOs7" : FF1QiT(self, BF(self.VV6dH8, True ), "Checking Server ...")
   elif item == "VVYaHC"  : FF1QiT(self, BF(self.VV6dH8, False), "Checking Server ...")
 def VVV0HD(self):
  path = "%sajpanel_settings_%s" % (VVbRSD, FFXJI8())
  FFuxno("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVPxkP, path))
  FFH1Ib(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVFuKD(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFtLFA("find / %s -iname '%s*' | grep %s" % (FFhDaE(1), name, name))
  if files:
   err = CCNmp1.VVUj2E(files)
   if err:
    FF4s3j(self, BF(self.VVYzuN, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVZ4NM = []
    for line in files:
     VVZ4NM.append((line, line))
    FFLMiy(self, BF(self.VVaTI6, title), title=title, VVZ4NM=VVZ4NM, width=1200, VVpQam="")
  else:
   FF0eUf(self, "No settings files found !", title=title)
 def VVYzuN(self, title, path=None):
  sDir = "/"
  for path in (VVbRSD, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVaTI6, title), BF(CCNmp1, patternMode="ajpSet", VVxAst=sDir))
 def VVaTI6(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFMA9m(path)
    self.VVOPgk()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVQxvB()
    FFWhqi()
    FF7BjW(self, "Apllied", 1500, isGrn=True)
   else:
    FF7Hmv(self, path, title=title)
 def VVJxmS(self):
  newPath = FFSiyE(VVbRSD)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVQxvB()
 @staticmethod
 def VVKPy4():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVOPgk(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVQxvB()
  if exit:
   self.close()
 def VVQxvB(self):
  configfile.save()
  global VVbRSD
  VVbRSD = CFG.backupPath.getValue()
  FFDKDt()
 def VV6dH8(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCVmVV.VVxe2j()
  if   err    : FF0eUf(self, err, title)
  elif isHigher or force : FF4s3j(self, BF(FF1QiT, self, BF(self.VV5ZJy, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFH1Ib(self, FFNr4J("No update required.", VVhmJa) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VV5ZJy(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFoJDA() == "dpkg" else "ipk")
  path, err = FFacHF(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FF2pmn(VV5fye, path)
   else : cmd = FF2pmn(VVYeKx, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFxjL4(self, cmd, title=title)
   else:
    FFPXac(self, title=title)
  else:
   FF0eUf(self, err, title=title)
 @staticmethod
 def VVxe2j():
  span = iSearch(r"v*(\d.\d.\d)", VVAgrE, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVbRSD + CCVmVV.VVetdd
  if fileExists(path):
   span = iSearch(r"(http.+)", FFBRKz(path), IGNORECASE)
   if span : url = FFSiyE(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFacHF(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFBRKz(path).strip().replace(" ", "")
   FFfhv3(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCdDf8(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VVEAg6, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVY4t9
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF3tZI(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVRJeS("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVRJeS("\c00888888", i) + sp + "GREY\n"
   txt += self.VVRJeS("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVRJeS("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVRJeS("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVRJeS("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVRJeS("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVRJeS("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVRJeS("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVRJeS("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVRJeS("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVRJeS("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV4SyA ,
   "green" : self.VV4SyA ,
   "left" : self.VVhkxh ,
   "right" : self.VVFho7 ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  self.VVSeQm()
 def VV4SyA(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF4s3j(self, self.VVIAKa, "Change to : %s" % txt, title=self.Title)
 def VVIAKa(self):
  FFE6Br(CFG.mixedColorScheme, self.cursorPos)
  global VVY4t9
  VVY4t9 = self.cursorPos
  self.VVZgeP()
  self.close()
 def VVhkxh(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVSeQm()
 def VVFho7(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVSeQm()
 def VVSeQm(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVRJeS(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVhmGI(color):
  if VVde5r: return "\\" + color
  else    : return ""
 @staticmethod
 def VVZgeP():
  global VVX5FP, VVi1yn, VVEWKM, VVIZs4, VVqDXM, VVljbY, VVFb7H, VVbtEO, VVhmJa, VVI2ZY, VVde5r, VVQzZA, VVi9VJ, VVh9Nn, VVB56o, VVqIxN
  VVqIxN   = CCdDf8.VVRJeS("\c00FFFFFF", VVY4t9)
  VVi1yn    = CCdDf8.VVRJeS("\c00888888", VVY4t9)
  VVX5FP  = CCdDf8.VVRJeS("\c005A5A5A", VVY4t9)
  VVbtEO    = CCdDf8.VVRJeS("\c00FF0000", VVY4t9)
  VVEWKM   = CCdDf8.VVRJeS("\c00FF5000", VVY4t9)
  VVIZs4   = CCdDf8.VVRJeS("\c00FFBB66", VVY4t9)
  VVde5r   = CCdDf8.VVRJeS("\c00FFFF00", VVY4t9)
  VVQzZA = CCdDf8.VVRJeS("\c00FFFFAA", VVY4t9)
  VVhmJa   = CCdDf8.VVRJeS("\c0000FF00", VVY4t9)
  VVI2ZY  = CCdDf8.VVRJeS("\c00AAFFAA", VVY4t9)
  VVFb7H    = CCdDf8.VVRJeS("\c000066FF", VVY4t9)
  VVi9VJ    = CCdDf8.VVRJeS("\c0000FFFF", VVY4t9)
  VVh9Nn  = CCdDf8.VVRJeS("\c00AAFFFF", VVY4t9)  #
  VVB56o   = CCdDf8.VVRJeS("\c00FA55E7", VVY4t9)
  VVqDXM    = CCdDf8.VVRJeS("\c00FF8F5F", VVY4t9)
  VVljbY  = CCdDf8.VVRJeS("\c00FFC0C0", VVY4t9)
CCdDf8.VVZgeP()
class CCCLco(Screen):
 def __init__(self, session, path, VVqmRU):
  self.skin, self.skinParam = FFWbv3(VVtrva, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVP6f8   = path
  self.VV5je0   = ""
  self.VVdj9K   = ""
  self.VVqmRU    = VVqmRU
  self.VVUxj5    = ""
  self.VVybb6  = ""
  self.VV4OOt    = False
  self.VVf5tg  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV4a57  = "enigma2-plugin-extensions-"
  self.VVH6NH  = "enigma2-plugin-systemplugins-"
  self.VVOkBm = "enigma2-"
  self.VVBaxl  = 0
  self.VVx97o  = 1
  self.VVXnZl  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV5nVX = "DEBIAN"
  else        : self.VV5nVX = "CONTROL"
  self.controlPath = self.Path + self.VV5nVX
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVqmRU:
   self.packageExt  = ".deb"
   self.VVfKIv  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVfKIv  = "#11001020"
  FF3tZI(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFTvkX(self["keyRed"] , "Create")
  FFTvkX(self["keyGreen"] , "Post Install")
  FFTvkX(self["keyYellow"], "Installation Path")
  FFTvkX(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVZD6M  ,
   "green"   : self.VVqzCH ,
   "yellow"  : self.VVdtsu  ,
   "blue"   : self.VVSdO4  ,
   "cancel"  : self.VVyL2l
  }, -1)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFxlor(self)
  if self.VVfKIv:
   FFIznG(self["myBody"], self.VVfKIv)
   FFIznG(self["myLabel"], self.VVfKIv)
  self.VVqsaV(True)
  self.VVs2qZ(True)
 def VVs2qZ(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVhTqo()
  if isFirstTime:
   if   package.startswith(self.VV4a57) : self.VVP6f8 = VV0xPn + self.VVUxj5 + "/"
   elif package.startswith(self.VVH6NH) : self.VVP6f8 = VVydp3 + self.VVUxj5 + "/"
   else            : self.VVP6f8 = self.Path
  if self.VV4OOt : myColor = VVqDXM
  else    : myColor = VVqIxN
  txt  = ""
  txt += "Source Path\t: %s\n" % FFNr4J(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFNr4J(self.VVP6f8, VVde5r)
  if self.VVdj9K : txt += "Package File\t: %s\n" % FFNr4J(self.VVdj9K, VVi1yn)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFNr4J("Check Control File fields : %s" % errTxt, VVEWKM)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFNr4J("Restart GUI", VVqDXM)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFNr4J("Reboot Device", VVqDXM)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFNr4J("Post Install", VVhmJa), act)
  if not errTxt and VVEWKM in controlInfo:
   txt += "Warning\t: %s\n" % FFNr4J("Errors in control file may affect the result package.", VVEWKM)
  txt += "\nControl File\t: %s\n" % FFNr4J(self.controlFile, VVi1yn)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVqzCH(self):
  if self["keyGreen"].getVisible():
   VVZ4NM = []
   VVZ4NM.append(("No Action"    , "noAction"  ))
   VVZ4NM.append(("Restart GUI"    , "VVm3aA"  ))
   VVZ4NM.append(("Reboot Device"   , "rebootDev"  ))
   FFLMiy(self, self.VVrCxI, title="Package Installation Option (after completing installation)", VVZ4NM=VVZ4NM)
 def VVrCxI(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVm3aA"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVqsaV(False)
   self.VVs2qZ()
 def VVdtsu(self):
  rootPath = FFNr4J("/%s/" % self.VVUxj5, VVQzZA)
  VVZ4NM = []
  VVZ4NM.append(("Current Path"        , "toCurrent"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Extension Path"       , "toExtensions" ))
  VVZ4NM.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVZ4NM.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFLMiy(self, self.VVQ3Cy, title="Installation Path", VVZ4NM=VVZ4NM)
 def VVQ3Cy(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVr3LW(FFabdw(self.Path, True))
   elif item == "toExtensions"  : self.VVr3LW(VV0xPn)
   elif item == "toSystemPlugins" : self.VVr3LW(VVydp3)
   elif item == "toRootPath"  : self.VVr3LW("/")
   elif item == "toRoot"   : self.VVr3LW("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVgcTM, BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=VVbRSD))
 def VVgcTM(self, path):
  if len(path) > 0:
   self.VVr3LW(path)
 def VVr3LW(self, parent, withPackageName=True):
  if withPackageName : self.VVP6f8 = parent + self.VVUxj5 + "/"
  else    : self.VVP6f8 = "/"
  mode = self.VV7RBL()
  FFKiof("sed -i '/Package/c\Package: %s' %s" % (self.VVBdp4(mode), self.controlFile))
  self.VVs2qZ()
 def VVSdO4(self):
  if fileExists(self.controlFile):
   lines = FFMA9m(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFFMZg(self, self.VVnsF3, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF0eUf(self, "Version not found or incorrectly set !")
  else:
   FF7Hmv(self, self.controlFile)
 def VVnsF3(self, VVz5S3):
  if VVz5S3:
   version, color = self.VV8buh(VVz5S3, False)
   if color == VVi9VJ:
    FFKiof("sed -i '/Version:/c\Version: %s' %s" % (VVz5S3, self.controlFile))
    self.VVs2qZ()
   else:
    FF0eUf(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVyL2l(self):
  if self.newControlPath:
   if self.VV4OOt:
    self.VVnt3P()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFNr4J(self.newControlPath, VVi1yn)
    txt += FFNr4J("Do you want to keep these files ?", VVde5r)
    FF4s3j(self, self.close, txt, callBack_No=self.VVnt3P, title="Create Package", VViggQ=True)
  else:
   self.close()
 def VVnt3P(self):
  FFKiof("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVBdp4(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVybb6
  if package.startswith(self.VVOkBm):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVOkBm, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVx97o : prefix = self.VV4a57
  elif mode == self.VVXnZl : prefix = self.VVH6NH
  return (prefix + name).lower()
 def VV7RBL(self):
  if   self.VVP6f8.startswith(VV0xPn) : return self.VVx97o
  elif self.VVP6f8.startswith(VVydp3) : return self.VVXnZl
  else            : return self.VVBaxl
 def VVqsaV(self, isFirstTime):
  self.VVUxj5   = FFRa3J(self.Path)
  self.VVUxj5   = "_".join(self.VVUxj5.split())
  self.VVybb6 = self.VVUxj5.lower()
  self.VV4OOt = self.VVybb6 == VVGEIo.lower()
  if self.VV4OOt and self.VVybb6.endswith(VVGEIo.lower()):
   self.VVybb6 += "el"
  if self.VV4OOt : self.VV5je0 = VVbRSD
  else    : self.VV5je0 = CFG.packageOutputPath.getValue()
  self.VV5je0 = FFSiyE(self.VV5je0)
  if not pathExists(self.controlPath):
   FFKiof("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VV7RBL()
  if fileExists(self.controlFile):
   lines = FFMA9m(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VV4OOt : version, descripton, maintainer = VVAgrE , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVUxj5 , self.VVUxj5
   txt = ""
   txt += "Package: %s\n"  % self.VVBdp4(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VV4OOt : t = PLUGIN_NAME
  else    : t = self.VVUxj5
  self.VVJtvX(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVJtvX(self.postrmFile, "echo 'Package removed.'\n")
  if self.VV4OOt : self.VVJtvX(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVAgrE))
  else    : self.VVJtvX(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVUxj5)
  if isFirstTime and not mode == self.VVBaxl:
   self.postInstAcion = 1
  txt = self.VV3xwo(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFBRKz(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VV3xwo(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFKiof("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVJtvX(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VV3xwo(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVhTqo(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFMA9m(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFNr4J(line, VVEWKM)
     elif not line.startswith(" ")    : line = FFNr4J(line, VVEWKM)
     else          : line = FFNr4J(line, VVi9VJ)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVi9VJ
   else   : color = VVEWKM
   descr = FFNr4J(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVEWKM
     elif line.startswith((" ", "\t")) : color = VVEWKM
     elif line.startswith("#")   : color = VVi1yn
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV8buh(val, True)
      elif key == "Version"  : version, color = self.VV8buh(val, False)
      elif key == "Maintainer" : maint  , color = val, VVi9VJ
      elif key == "Architecture" : arch  , color = val, VVi9VJ
      else:
       color = VVi9VJ
      if not key == "OE" and not key.istitle():
       color = VVEWKM
     else:
      color = VVqDXM
     txt += FFNr4J(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVdj9K = self.VV5je0 + packageName
   self.VVf5tg = True
   errTxt = ""
  else:
   self.VVdj9K  = ""
   self.VVf5tg = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV8buh(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVi9VJ
  else          : return val, VVEWKM
 def VVZD6M(self):
  if not self.VVf5tg:
   FF0eUf(self, "Please fix Control File errors first.")
   return
  if self.VVqmRU: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFabdw(self.VVP6f8, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVUxj5
  symlinkTo  = FFliS8(self.Path)
  dataDir   = self.VVP6f8.rstrip("/")
  removePorjDir = FFyMLY("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFyMLY("rm -f '%s'" % self.VVdj9K)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFib1Q()
  if self.VVqmRU:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF6Lzl("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV4OOt:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVP6f8 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV5nVX)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVdj9K, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVdj9K
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVdj9K, FFVW8g(result  , VVhmJa))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVP6f8, FFVW8g(instPath, VVi9VJ))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFVW8g(failed, VVEWKM))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFxjL4(self, cmd)
class CC8DHP():
 VVFzqD  = "666"
 VVb1in   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVKicw   = None
  self.VVQ5bi()
 def VVQ5bi(self):
  VVZ4NM = CC8DHP.VVk6Tg()
  if VVZ4NM:
   VVcrQj = ("Create New", self.VVAUyi)
   self.VVKicw = FFLMiy(self.SELF, self.VVl6cI, VVZ4NM=VVZ4NM, title=self.Title, VVcrQj=VVcrQj, VV9pbf=True, VVrEme="#22222233", VVRBt6="#22222233")
  else:
   self.VVAUyi()
 def VVl6cI(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV8FkJ(bName, bRef)
  else:
   CC8DHP.VVTU2o(self)
 def VVAUyi(self, VVMD9SObj=None, item=None):
  FFFMZg(self.SELF, BF(self.VVVzyx), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVVzyx(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVKicw:
     self.VVKicw.cancel()
    self.VV8FkJ(bName, "")
   else:
    FF7BjW(self.VVKicw, "Incorrect Bouquet Name !", 2000)
    CC8DHP.VVTU2o(self)
 def VV8FkJ(self, bName, bRef):
  FF1QiT(self.waitMsgSELF, BF(self.VVVheB, bName, bRef), title="Adding Services ...")
 def VVVheB(self, bName, bRef):
  CC8DHP.VV8Ndw(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVTU2o(classObj):
  del classObj
 @staticmethod
 def VV8Ndw(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FF0eUf(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVPxkP + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FF7Hmv(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC8DHP.VVJa7M(bRef)
   bPath = VVPxkP + bFile
  else:
   fName = CCXyjP.VVafKo(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVPxkP + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVPxkP + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFg7n1(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFg7n1(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCk0vb.VVJcyT()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFKiof("cp -f '%s' '%s'" % (poster, picon))
       FFKiof(CCUr80.VV293l(picon))
       break
  FFwnFB()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFXEvX(SELF, txt, title=title)
 @staticmethod
 def VVk6Tg(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVZ4NM = []
  if mode in (0, 2): VVZ4NM.extend(CC8DHP.VVfVLz(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVZ4NM.extend(CC8DHP.VVfVLz(1, showTitle, prefix, onlyIptv))
  return VVZ4NM
 @staticmethod
 def VVfVLz(mode, showTitle, prefix, onlyIptv):
  VVZ4NM = []
  lst = CC8DHP.VVts4u(mode)
  if onlyIptv:
   lst = CC8DHP.VVWn53(lst)
  if lst:
   if showTitle:
    VVZ4NM.append(FF2YB6("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVZ4NM.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVZ4NM.append((item[0], item[1].toString()))
  return VVZ4NM
 @staticmethod
 def VVWn53(lst):
  fLst = CCXyjP.VVpx1z(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVt0b6():
  bLise = CC8DHP.VVts4u(0)
  bLise.extend(CC8DHP.VVts4u(1))
  return bLise
 @staticmethod
 def VVts4u(mode=0):
  bList = []
  VVbIOb = InfoBar.instance
  VVWuh1 = VVbIOb and VVbIOb.servicelist
  if VVWuh1:
   curMode = VVWuh1.mode
   CC8DHP.VVgwqi(VVWuh1, mode)
   bList.extend(VVWuh1.getBouquetList() or [])
   CC8DHP.VVgwqi(VVWuh1, curMode)
  return bList
 @staticmethod
 def VVgwqi(VVWuh1, mode):
  if not mode == VVWuh1.mode:
   if   mode == 0: VVWuh1.setModeTv()
   elif mode == 1: VVWuh1.setModeRadio()
 @staticmethod
 def VVJa7M(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVstve():
  try:
   fName = CC8DHP.VVJa7M(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVPxkP, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVeKWz():
  path = CC8DHP.VVstve()
  if path:
   txt = FFBRKz(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VV01Y3():
  return FFNTAQ(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVQWdi():
  lst = []
  for b in CC8DHP.VVt0b6():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVPxkP + CC8DHP.VVJa7M(bRef)
   if fileExists(path):
    lines = FFMA9m(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVWFIo(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVsrGs(SID="", stripRType=False):
  if SID : patt = CC8DHP.VVWFIo(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC8DHP.VVt0b6():
   for service in FFNTAQ(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVP5t5():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CC8DHP.VVt0b6():
   for service in FFNTAQ(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVFxvn(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVAa9k(pathLst, rType=""):
  refLst = CC8DHP.VVsrGs(CC8DHP.VVFzqD, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC8DHP.VVFxvn(rType, CC8DHP.VVFzqD, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCNmp1(Screen):
 VVNi6D   = 0
 VVLO4h  = 1
 VVLQAF  = 2
 VVJFQp = 3
 VVFCSM    = 20
 VVIn7i   = 0
 VVrYLB   = 1
 VVXlrf   = 2
 def __init__(self, session, VVxAst="/", mode=VVNi6D, VVm4ou="Select", width=1400, height=920, VVsgYf=30, VVrEme="#22001111", VVRBt6="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFWbv3(VV3sDt, width, height, 30, 40, 20, VVrEme, VVRBt6, VVsgYf, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVrEme   = VVrEme
  self.VVRBt6    = VVRBt6
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FF3tZI(self)
  FFTvkX(self["keyRed"] , "Exit")
  FFTvkX(self["keyYellow"], "More Options")
  FFTvkX(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVm4ou = VVm4ou
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVIDud = None
  if patternMode:
   self.mode = self.VVJFQp
   if   patternMode == "srt"  : VVIDud = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVIDud = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVIDud = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVIDud = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVIDud = ("^.*\.(%s)$" % "|".join(CCid1U.VVyaUp()["mov"]), IGNORECASE)
   else       : VVIDud = None
  if self.mode in (self.VVLQAF, self.VVJFQp):
   FFTvkX(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVmfgw, self.VVxAst = True , FFabdw(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVmfgw, self.VVxAst = True , CCNmp1.VVORqp(self)[1] or "/"
  elif self.mode == self.VVNi6D  : VVmfgw, self.VVxAst = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVLQAF : VVmfgw, self.VVxAst = False, VVxAst
  elif self.mode == self.VVJFQp : VVmfgw, self.VVxAst = True , VVxAst
  else           : VVmfgw, self.VVxAst = True , VVxAst
  self.VVxAst = FFSiyE(self.VVxAst)
  self["myMenu"] = CCid1U(  directory   = None
         , VVIDud = VVIDud
         , VVmfgw   = VVmfgw
         , VVjMf8 = True
         , VV67gN = True
         , VVeaGH   = self.skinParam["width"]
         , VVsgYf   = self.skinParam["bodyFontSize"]
         , VV12Gz  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV4SyA    ,
   "red" : self.VV8pgM   ,
   "green" : self.VVAz9I,
   "yellow": self.VVoIkH  ,
   "blue" : self.VVa0IV ,
   "menu" : self.VV7ZKN  ,
   "info" : self.VVE5hF  ,
   "cancel": self.VVtulr    ,
   "pageUp": self.VV15AO   ,
   "chanUp": self.VV15AO
  }, -1)
  FFLPhw(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVXTxP)
  global VV4tWs
  VV4tWs = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  global VV4tWs
  del VV4tWs
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVXTxP)
  FFBjfS(self)
  FF4VOV(self["myMenu"], bg=self.cursorBG)
  FFxlor(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVLQAF, self.VVJFQp):
   FFTvkX(self["keyGreen"], self.VVm4ou)
   self.VVOiIY(self.VVrYLB)
  self.VVXTxP()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVHp4h(self.VVxAst) > self.bigDirSize: FF1QiT(self, self.VV1je6, title="Changing directory...")
  else              : self.VV1je6()
 def VV1je6(self):
  if self.jumpToFile : self.VVo3ES(self.jumpToFile)
  elif self.gotoMovie : self.VVp8vk(chDir=False)
  else    : self["myMenu"].VVv5wk(self.VVxAst)
 def VVpxIX(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVAAJ1(self):
  FF1QiT(self, self.VVDozO, title="Refreshing list ...")
 def VVDozO(self):
  isSel = self["myMenu"].VVwBZs()
  if not isSel:
   self.VVkZwe(False)
  FFZ1wQ()
 def VVQILq(self, saved):
  if saved: self.VVAAJ1()
 def VVHp4h(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VV4SyA(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVI5Ot()
   if ok : self["keyBlue"].setText(self.VV3l5r())
   else : FF7BjW(self, "Cannot select item", 500)
  elif self["myMenu"].VV9wid(): self.VVeHkV()
  else       : self.VVg41K()
 def VV15AO(self):
  if self.multiSelectState:
   FF7BjW(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVFfkw():
    self.VVeHkV()
 def VVeHkV(self, isDirUp=False):
  if self["myMenu"].VV9wid():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVLDDF(self.VVMD9S())
   if self.VVHp4h(path) > self.bigDirSize : FF1QiT(self, self.VVDr3I, title="Changing directory...")
   else           : self.VVDr3I()
 def VVDr3I(self):
  self["myMenu"].descent()
  self.VVXTxP()
 def VVtulr(self):
  if   self.multiSelectState     : self.VVkZwe(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VV8pgM()
  else          : self.VV15AO()
 def VV8pgM(self):
  if not FFXZrK(self):
   self.close("")
 def VVAz9I(self):
  path = self.VVLDDF(self.VVMD9S())
  if self.mode == self.VVLQAF:
   self.close(path)
  elif self.mode == self.VVJFQp:
   if os.path.isfile(path) : self.close(path)
   else     : FF7BjW(self, "Cannot access this file", 1000)
 def VVE5hF(self):
  FF1QiT(self, self.VVmbI0, title="Calculating size ...")
 def VVmbI0(self):
  path = self.VVLDDF(self.VVMD9S())
  param = self.VVI8ee(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FF0hBQ("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCNmp1.VVmDUR(path)
     freeSize = CCNmp1.VVaKQl(path)
     size = totSize - freeSize
     totSize  = CCNmp1.VV3y2b(totSize)
     freeSize = CCNmp1.VV3y2b(freeSize)
    else:
     size = FFoEhk(path)
   usedSize = CCNmp1.VV3y2b(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFNr4J(pathTxt, VVqDXM) + "\n"
   if slBroken : fileTime = self.VVcdux(path)
   else  : fileTime = self.VVHFo7(path)
   def VV5jhO(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV5jhO("Path"    , pathTxt)
   txt += VV5jhO("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV5jhO("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV5jhO("Total Size"   , "%s" % totSize)
    txt += VV5jhO("Used Size"   , "%s" % usedSize)
    txt += VV5jhO("Free Size"   , "%s" % freeSize)
   else:
    txt += VV5jhO("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV5jhO("Owner"    , owner)
   txt += VV5jhO("Group"    , group)
   txt += VV5jhO("Perm. (User)"  , permUser)
   txt += VV5jhO("Perm. (Group)"  , permGroup)
   txt += VV5jhO("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV5jhO("Perm. (Ext.)" , permExtra)
   txt += VV5jhO("iNode"    , iNode)
   txt += VV5jhO("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVTk10(path)
  else:
   FF0eUf(self, "Cannot access information !")
  if len(txt) > 0:
   FFXEvX(self, txt)
 def VVI8ee(self, path):
  path = path.strip()
  path = FFliS8(path)
  result = FF0hBQ("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVsEaH(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVsEaH(perm, 1, 4)
   permGroup = VVsEaH(perm, 4, 7)
   permOther = VVsEaH(perm, 7, 10)
   permExtra = VVsEaH(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFcLfl("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVTk10(self, path):
  txt  = ""
  res  = FF0hBQ("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFNr4J("File Attributes:", VVB56o), txt)
  return txt
 def VVHFo7(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFmWOg(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFmWOg(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFmWOg(os.path.getctime(path))
  return txt
 def VVcdux(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF0hBQ("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF0hBQ("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF0hBQ("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVLDDF(self, currentSel):
  currentDir  = self["myMenu"].VVdFEH()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV9wid():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVMD9S(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVXTxP(self):
  path = self.VVLDDF(self.VVMD9S())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVMSBU()
  if self.mode == self.VVNi6D:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVJFQp:
   path = self.VVLDDF(self.VVMD9S())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VV7ZKN(self):
  color1 = VVljbY
  color2 = VVQzZA
  color3 = VVh9Nn
  totSel = 0
  menuW = 1000
  title = "Options"
  VVZ4NM= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVT6lT()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FF1OOs(totSel))
     VVZ4NM.append((color1 + txt1     , "VVWtlu1" ))
     VVZ4NM.append((color1 + txt1 + txt2   , "VVWtlu2" ))
     VVZ4NM.append(VVVvw4)
    VVZ4NM.append(("[6] Copy"       , "copyBulk" ))
    VVZ4NM.append(("[7] Move"       , "moveBulk" ))
    VVZ4NM.append(("[8] %sDELETE" % VVqDXM , "VVRjcz" ))
   else:
    FF7BjW(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVLQAF, self.VVJFQp):
   VVZ4NM.append(("Properties"           , "properties" ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVLDDF(self.VVMD9S())
   isEditable = self["myMenu"].VVDfdL()
   VVZ4NM.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color1 + "Archiving / Packaging", "VV2M0C_dir"))
   elif os.path.isfile(path):
    selFile = self.VVMD9S()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVZ4NM.append((color1 + "Archive ...", "VV2M0C_file"))
    isText = False
    txt = ""
    if   isArch            : VVZ4NM.extend(self.VVg1KC(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVZ4NM.extend(self.VVOUOy(True))
    elif selFile.endswith(".sh"):
     VVZ4NM.extend(self.VVk2UV(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCNmp1.VVMLm6(path):
     VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color2 + "View"     , "textView_def"))
     VVZ4NM.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVZ4NM.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVDpoo(path) == "pic":
     VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color2 + "Set as PIcon for current channel" , "VVpwkj" ))
     if FF4wzI("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVZ4NM.append(VVVvw4)
      VVZ4NM.append((color2 + "Convert to MVI (1280 x 720 )" , "VVkIT0Hd"   ))
      VVZ4NM.append((color2 + "Convert to MVI (1920 x 1080)" , "VVkIT0Fhd"   ))
    elif selFile.endswith(CCNmp1.VVRq3i()):
     if selFile.endswith(".mvi"):
      if FF4wzI("showiframe"):
       VVZ4NM.append(VVVvw4)
       VVZ4NM.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVZ4NM.append(VVVvw4)
      VVZ4NM.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVZ4NM.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVZ4NM.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVZ4NM.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVZ4NM.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVZ4NM.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVH5NM" ))
    if len(txt) > 0:
     VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color1 + txt, "VVg41K"))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("[4] Create SymLink", "VVKCX5"))
   if isEditable:
    VVZ4NM.append(("[5] Rename"      , "VV7iVr" ))
    VVZ4NM.append(("[6] Copy"       , "copyFileOrDir" ))
    VVZ4NM.append(("[7] Move"       , "moveFileOrDir" ))
    VVZ4NM.append(("[8] %sDELETE" % VVqDXM , "VVuMKj" ))
    if fileExists(path):
     VVZ4NM.append(VVVvw4)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVZ4NM.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVZ4NM.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVZ4NM.append((chmodTxt + "777)", "chmod777"))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVZ4NM.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCNmp1.VVORqp(self)
   if fPath:
    VVZ4NM.append(VVVvw4)
    VVZ4NM.append((color2 + "Go to Current Movie Dir", "VVp8vk"))
  FFLMiy(self, self.VV9jZe, width=menuW, height=1050, title=title, VVZ4NM=VVZ4NM, VVPgqu=False, VVrEme="#00101020", VVRBt6="#00101A2A")
 def VV9jZe(self, item=None):
  if item is not None:
   path = self.VVLDDF(self.VVMD9S())
   selFile = self.VVMD9S()
   if   item == "VVWtlu1"    : self.VVWtlu(False)
   if   item == "VVWtlu2"    : self.VVWtlu(True)
   elif item == "copyBulk"     : self.VVzqIf(False)
   elif item == "moveBulk"     : self.VVzqIf(True)
   elif item == "VVRjcz"    : self.VVRjcz()
   elif item == "properties"    : self.VVE5hF()
   elif item == "VV2M0C_dir" : self.VV2M0C(path, True)
   elif item == "VV2M0C_file" : self.VV2M0C(path, False)
   elif item == "VVsTZQ"  : self.VVsTZQ(path)
   elif item == "VVlBnd"  : self.VVlBnd(path)
   elif item.startswith("extract_")  : self.VVnfxM(path, selFile, item)
   elif item.startswith("script_")   : self.VVdgqa(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVbnmw(path, selFile, item)
   elif item.startswith("textView_def") : FFRva2(self, path)
   elif item.startswith("textView_enc") : self.VVubVT(path)
   elif item.startswith("text_Edit")  : FF1QiT(self, BF(CCC9Tv, self, path, VVtCUJ=self.VVQILq), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVjvN8(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVjvN8(path, "Save as Other Encoding", False)
   elif item.startswith("VVH5NM") : self.VVH5NM(path)
   elif item == "viewAsBootlogo"   : self.VVyFKy(path, True)
   elif item == "addMovieToBouquet"  : self.VV1ReJ(path, False)
   elif item == "addAllMoviesToBouquet" : self.VV1ReJ(path, True)
   elif item == "playWith"     : self.VVcZ3E(path)
   elif item == "VVpwkj" : self.VVpwkj(path)
   elif item == "VVkIT0Hd"   : FF1QiT(self, BF(self.VVkIT0, path, False))
   elif item == "VVkIT0Fhd"   : FF1QiT(self, BF(self.VVkIT0, path, True))
   elif item == "VVKCX5"   : self.VVKCX5(path, selFile)
   elif item == "VV7iVr"   : self.VV7iVr(path, selFile)
   elif item == "copyFileOrDir"   : self.VVxQ7T(path, False)
   elif item == "moveFileOrDir"   : self.VVxQ7T(path, True)
   elif item == "VVuMKj"   : self.VVuMKj(path, selFile)
   elif item == "chmod644"     : self.VVt2fj(path, selFile, "644")
   elif item == "chmod755"     : self.VVt2fj(path, selFile, "755")
   elif item == "chmod777"     : self.VVt2fj(path, selFile, "777")
   elif item == "createNewFile"   : self.VV5SmY(path, True)
   elif item == "createNewDir"    : self.VV5SmY(path, False)
   elif item == "VVp8vk"   : self.VVp8vk()
   elif item == "VVg41K"    : self.VVg41K()
 def VVg41K(self):
  if self.mode == self.VVJFQp and not self.patternMode == "poster":
   return
  selFile = self.VVMD9S()
  path  = self.VVLDDF(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVDpoo(path)
   if   cat == "pic"       : self.VVS8V1(path)
   elif cat == "txt"       : FFRva2(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VViEYg(path, selFile)
   elif cat == "scr"       : self.VVY2cV(path, selFile)
   elif cat == "m3u"       : self.VVTm0a(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVjYvd(path, selFile)
   elif cat in ("mov", "mus")     : self.VVyFKy(path)
   elif not CCNmp1.VVMLm6(path) : FFRva2(self, path)
 def VVS8V1(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVDpoo(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCWJhm.VVpAVI(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVBV8A)
 def VVBV8A(self, path):
  self.VVo3ES(path)
 def VVyFKy(self, path, asLogo=False):
  if asLogo : CC5tNx.VVTBDS(self, path)
  else  : FF1QiT(self, BF(self.VVcIM8, self, path), title="Playing Media ...")
 def VVa0IV(self):
  if self["keyBlue"].getVisible():
   VVDpqo = self.VVrIK7()
   if VVDpqo:
    path = self.VVLDDF(self.VVMD9S())
    enableGreenBtn = False if path in self.VVrIK7() else True
    newList = []
    for line in VVDpqo:
     newList.append((line, line))
    VV6rAJ  = ("Delete"    , self.VV8Ssp    )
    VVWjWA  = ("Add Current Dir"   , BF(self.VVuFAY, path) ) if enableGreenBtn else None
    VVcrQj = ("Move Up"     , self.VV8z7Y    )
    VVs32w  = ("Move Down"   , self.VVGBXZ    )
    self.bookmarkMenu = FFLMiy(self, self.VVzaFh, width=1200, title="Bookmarks", VVZ4NM=newList, minRows=10 ,VV6rAJ=VV6rAJ, VVWjWA=VVWjWA, VVcrQj=VVcrQj, VVs32w=VVs32w, VVrEme="#00000022", VVRBt6="#00000022")
 def VV8Ssp(self, VVKicw=None, path=None):
  VVDpqo = self.VVrIK7()
  if VVDpqo:
   while path in VVDpqo:
    VVDpqo.remove(path)
   self.VVFcJt(VVDpqo)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVAfT3(VVDpqo)
   self.bookmarkMenu.VVjLPA(("Add Current Dir", BF(self.VVuFAY, path)))
  else:
   FF7BjW(self, "Removed", 800)
  self.VVMSBU()
 def VVuFAY(self, path, VVKicw=None, item=None):
  VVDpqo = self.VVrIK7()
  if len(VVDpqo) >= self.VVFCSM:
   FF0eUf(SELF, "Max bookmarks reached (max=%d)." % self.VVFCSM)
  elif not path in VVDpqo:
   if not os.path.isdir(path):
    path = FFabdw(path, True)
   newList = [path] + VVDpqo
   self.VVFcJt(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVAfT3(newList)
    self.bookmarkMenu.VVjLPA()
   else:
    FF7BjW(self, "Added", 800)
  self.VVMSBU()
 def VV8z7Y(self, VVMD9SObj, path):
  if self.bookmarkMenu:
   VVDpqo = self.bookmarkMenu.VVcjar(True)
   if VVDpqo:
    self.VVFcJt(VVDpqo)
 def VVGBXZ(self, VVMD9SObj, path):
  if self.bookmarkMenu:
   VVDpqo = self.bookmarkMenu.VVcjar(False)
   if VVDpqo:
    self.VVFcJt(VVDpqo)
 def VVzaFh(self, folder=None):
  if folder:
   folder = FFSiyE(folder)
   self["myMenu"].VVv5wk(folder)
   self["myMenu"].moveToIndex(0)
  self.VVXTxP()
 def VVrIK7(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVseYc(self):
  return True if VVrIK7() else False
 def VVFcJt(self, VVDpqo):
  line = ",".join(VVDpqo)
  FFE6Br(CFG.browserBookmarks, line)
 def VVo3ES(self, path):
  if fileExists(path):
   fDir  = FFSiyE(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVv5wk(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF7BjW(self, "Not found", 1000)
 def VVp8vk(self, chDir=True):
  fPath, fDir, fName = CCNmp1.VVORqp(self)
  self.VVo3ES(fPath)
 def VVoIkH(self):
  path = self.VVLDDF(self.VVMD9S())
  isAdd = False if path in self.VVrIK7() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVi9VJ, VVI2ZY, VVQzZA
  VVZ4NM = []
  VVZ4NM.append(("Find Files ..." , "find"))
  VVZ4NM.append(("Sort ..."   , "sort"))
  VVZ4NM.append(VVVvw4)
  if isAdd: VVZ4NM.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVZ4NM.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVNi6D:
   VVZ4NM.append(VVVvw4)
   if self.multiSelectState: VVZ4NM.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVZ4NM.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVZ4NM.append(       (c3 + "Select all"    , "selAll"  ))
  FFLMiy(self, BF(self.VVkumt, path), width=750, title="More Options", VVZ4NM=VVZ4NM, VVrEme="#00221111", VVRBt6="#00221111")
 def VVkumt(self, path, item):
  if item:
   if   item == "find"  : self.VV10Rv(path)
   elif item == "sort"  : self.VV6mxl()
   elif item == "addBM" : self.VVuFAY(path)
   elif item == "remBM" : self.VV8Ssp(None, path)
   elif item == "start" : self.VVhd7R(path)
   elif item == "multiOn" : self.VVkZwe(True)
   elif item == "multiOff" : self.VVkZwe(False)
   elif item == "selAll" : self.VVkZwe(True, True)
 def VVkZwe(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FF1QiT(self, BF(self["myMenu"].VVtrtY, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVOiIY(self.VVXlrf if isOn else self.VVIn7i)
 def VVOiIY(self, mode=0):
  if   mode == self.VVrYLB : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVXlrf: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVrEme, self.VVRBt6
  FFIznG(self["myTitle"], titBg)
  FFIznG(self["myBar"], titBg)
  FFIznG(self["myBody"], bodBg)
  FFIznG(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VV3l5r()
  else     : bg, txt = VVO3mz[3], "Bookmarks"
  FFTvkX(self["keyBlue"], txt)
  FFIznG(self["keyBlue"], bg)
  self.VVMSBU()
 def VV3l5r(self):
  return "Selected Items = %d" % self["myMenu"].VVT6lT()
 def VVMSBU(self):
  if self.VVrIK7() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV10Rv(self, path):
  VVZ4NM = []
  VVZ4NM.append(("Find in Current Directory"    , "findCur"  ))
  VVZ4NM.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVZ4NM.append(("Find in all Storage Systems"    , "findAll"  ))
  FFLMiy(self, BF(self.VVeJIY, path), width=700, title="Find File/Pattern", VVZ4NM=VVZ4NM, VV9pbf=True, VVmNi5=True, VVrEme="#00221111", VVRBt6="#00221111")
 def VVeJIY(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVvzbQ(0, path, title)
   elif item == "findCurR" : self.VVvzbQ(1, path, title)
   elif item == "findAll" : self.VVvzbQ(2, path, title)
 def VVvzbQ(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFFMZg(self, BF(self.VVQIA8, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVQIA8(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFE6Br(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FF7BjW(self, "No entery", 1500)
   elif badLst  : FF7BjW(self, "Too many file !", 1500)
   else   : FF1QiT(self, BF(self.VVj8sx, mode, path, title, filePatt), title="Searching ...")
 def VVj8sx(self, mode, path, title, filePatt):
  lst = FFtLFA(FFPg54("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCNmp1.VVUj2E(lst)
   if err:
    FF0eUf(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVU95Y = (""     , self.VV4K2M , [])
    VV8lmg = ("Go to File Location", self.VVNEYz  , [])
    FFW2Tv(self, None, title="%s : %s" % (title, filePatt), header=header, VVDpqo=lst, VVQT0l=widths, VVsgYf=26, VVU95Y=VVU95Y, VV8lmg=VV8lmg)
  else:
   FFVyvQ(self, "Not found !", 2000)
 def VVNEYz(self, VVSuUg, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVSuUg.cancel()
   self.VVo3ES(path)
  else:
   FF7BjW(VVSuUg, "Path not found !", 1000)
 def VV4K2M(self, VVSuUg, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFNr4J("File:"  , VVQzZA), colList[0])
  txt += "%s\n%s"  % (FFNr4J("Directory:", VVQzZA), FFSiyE(colList[1]))
  FFXEvX(VVSuUg, txt, title=title)
 def VV6mxl(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVkRtD()
  VVZ4NM = []
  VVZ4NM.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVZ4NM.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVZ4NM.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVZ4NM.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVs32w = ("Mix", BF(self.VVjs0K, True))
  FFLMiy(self, BF(self.VVM3jI, False), barText=txt, width=650, title="Sort Options", VVZ4NM=VVZ4NM, VVs32w=VVs32w, VVmNi5=True, VVrEme="#00221111", VVRBt6="#00221111")
 def VVjs0K(self, isMix, VVKicw, item):
  self.VVM3jI(True, item)
 def VVM3jI(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVkRtD()
   title = "Sorting ... "
   if   item == "nameAlp": FF1QiT(self, BF(self["myMenu"].VVUHpW, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF1QiT(self, BF(self["myMenu"].VVUHpW, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF1QiT(self, BF(self["myMenu"].VVUHpW, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF1QiT(self, BF(self["myMenu"].VVUHpW, typeMode , isMix, False), title=title)
 def VVhd7R(self, path):
  if not os.path.isdir(path):
   path = FFabdw(path, True)
  FFE6Br(CFG.browserStartPath, path)
  FF7BjW(self, "Done", 500)
 def VVb7uM(self, selFile, VV6LqR, command):
  FF4s3j(self, BF(FFxjL4, self, command, consFont=True, VVgmlB=self.VVAAJ1), "%s\n\n%s" % (VV6LqR, selFile))
 def VVg1KC(self, path, calledFromMenu):
  destPath = self.VVg788(path)
  lastPart = FFRa3J(destPath)
  color = VVQzZA if calledFromMenu else ""
  VVZ4NM = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVZ4NM.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVZ4NM.append(VVVvw4)
   VVZ4NM.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVZ4NM.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVZ4NM.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color + "Convert .zip to .tar.gz"       , "VVsTZQ" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVZ4NM.append(VVVvw4)
     VVZ4NM.append((color + "Convert .tar.gz to .zip"       , "VVlBnd" ))
  return VVZ4NM
 def VViEYg(self, path, selFile):
  FFLMiy(self, BF(self.VVnfxM, path, selFile), title="Compressed File Options", VVZ4NM=self.VVg1KC(path, False))
 def VVnfxM(self, path, selFile, item=None):
  if item is not None:
   parent  = FFabdw(path, False)
   destPath = self.VVg788(path)
   lastPart = FFRa3J(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF6Lzl("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF6Lzl("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFA10e(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVsTZQ" : self.VVsTZQ(path)
    else       : self.VVGxQ5(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVlBnd" and path.endswith(".tar.gz"):
    self.VVlBnd(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FF0hBQ("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFH1Ib(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVAAJ1()
    else:
     FF0eUf(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVtOjR(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFyMLY("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVb7uM(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVb7uM(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFabdw(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVb7uM(selFile, "Extract Here ?"      , cmd)
 def VVg788(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVGxQ5(self, item, path, parent, destPath, VV6LqR):
  FF4s3j(self, BF(self.VVtuDv, item, path, parent, destPath), VV6LqR)
 def VVtuDv(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF6Lzl("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFVW8g(destPath, VVhmJa))
  cmd +=   sep
  cmd += "fi;"
  FFfDBJ(self, cmd, VVgmlB=self.VVAAJ1)
 def VVtOjR(self, item, path, parent, destPath, VV6LqR):
  FF4s3j(self, BF(self.VVKoEs, item, path, parent, destPath), VV6LqR)
 def VVKoEs(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFSiyE(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF6Lzl("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFVW8g(destPath, VVhmJa))
  cmd +=   sep
  cmd += "fi;"
  FFfDBJ(self, cmd, VVgmlB=self.VVAAJ1)
 def VVk2UV(self, addSep=False):
  VVZ4NM = []
  if addSep:
   VVZ4NM.append(VVVvw4)
  VVZ4NM.append((VVQzZA + "View Script File"  , "script_View"  ))
  VVZ4NM.append((VVQzZA + "Execute Script File" , "script_Execute" ))
  VVZ4NM.append((VVQzZA + "Edit"     , "script_Edit"  ))
  return VVZ4NM
 def VVY2cV(self, path, selFile):
  FFLMiy(self, BF(self.VVdgqa, path, selFile), title="Script File Options", VVZ4NM=self.VVk2UV())
 def VVdgqa(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFRva2(self, path)
   elif item == "script_Execute" : self.VVb7uM(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCC9Tv(self, path, VVtCUJ=self.VVQILq)
 def VVOUOy(self, addSep=False):
  VVZ4NM = []
  if addSep:
   VVZ4NM.append(VVVvw4)
  VVZ4NM.append((VVQzZA + "Browse IPTV Channels" , "m3u_Browse" ))
  VVZ4NM.append((VVQzZA + "Edit"     , "m3u_Edit" ))
  VVZ4NM.append((VVQzZA + "View"     , "m3u_View" ))
  return VVZ4NM
 def VVTm0a(self, path, selFile):
  FFLMiy(self, BF(self.VVbnmw, path, selFile), title="M3U/M3U8 File Options", VVZ4NM=self.VVOUOy())
 def VVbnmw(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF1QiT(self, BF(self.session.open, CCXyjP, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCC9Tv(self, path, VVtCUJ=self.VVQILq)
   elif item == "m3u_View"  : FFRva2(self, path)
 def VVubVT(self, path):
  if fileExists(path) : FF1QiT(self, BF(CC9SOR.VVJOY4, self, path, BF(self.VVGXkC, path)), title="Loading Codecs ...")
  else    : FF7Hmv(self, path)
 def VVGXkC(self, path, item=None):
  if item:
   FFRva2(self, path, encLst=item)
 def VVjvN8(self, path, title, asUtf8):
  if fileExists(path) : FF1QiT(self, BF(CC9SOR.VVJOY4, self, path, BF(self.VV74fJ, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FF7Hmv(self, path)
 def VV74fJ(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVD6gu(path, title, fromEnc, "UTF-8")
   else  : CC9SOR.VVvkzS(self, BF(self.VVD6gu, path, title, fromEnc), title="Convert to Encoding")
 def VVD6gu(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFNr4J("Successful\n\n", VVhmJa)
      txt += FFNr4J("From Encoding (%s):\n" % fromEnc, VVde5r)
      txt += "%s\n\n" % path
      txt += FFNr4J("To Encoding (%s):\n" % toEnc, VVde5r)
      txt += "%s\n\n" % outFile
      FFXEvX(self, txt, title=title)
    except:
     FF0eUf(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FF7BjW(self, "Cannot open file", 2000)
   self.VVAAJ1()
 def VVH5NM(self, path):
  title = "File Line-Break Conversion"
  FF4s3j(self, BF(self.VVzNI1, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVzNI1(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFNr4J("File converted:", VVhmJa), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFH1Ib(self, txt, title=title)
  else:
   FF7Hmv(self, path, title=title)
 def VVt2fj(self, path, selFile, newChmod):
  FF4s3j(self, BF(self.VVmZZw, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVmZZw(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VViDgN)
  result = FF0hBQ(cmd)
  if result == "Successful" : FFH1Ib(self, result)
  else      : FF0eUf(self, result)
 def VVKCX5(self, path, selFile):
  parent = FFabdw(path, False)
  self.session.openWithCallback(self.VVDrJd, BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=parent, VVm4ou="Create Symlink here"))
 def VVDrJd(self, newPath):
  if len(newPath) > 0:
   target = self.VVLDDF(self.VVMD9S())
   target = FFliS8(target)
   linkName = FFRa3J(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFSiyE(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF0eUf(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF4s3j(self, BF(self.VVGqqE, target, link), "Create Soft Link ?\n\n%s" % txt, VViggQ=True)
 def VVGqqE(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VViDgN)
  result = FF0hBQ(cmd)
  if result == "Successful" : FFH1Ib(self, result)
  else      : FF0eUf(self, result)
 def VV7iVr(self, path, selFile):
  lastPart = FFRa3J(path)
  FFFMZg(self, BF(self.VVIe2G, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVIe2G(self, path, selFile, VVz5S3):
  if VVz5S3:
   parent = FFabdw(path, True)
   if os.path.isdir(path):
    path = FFliS8(path)
   newName = parent + VVz5S3
   cmd = "mv '%s' '%s' %s" % (path, newName, VViDgN)
   if VVz5S3:
    if selFile != VVz5S3:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF4s3j(self, BF(self.VVJe4Y, cmd), message, title="Rename file?")
    else:
     FF0eUf(self, "Cannot use same name!", title="Rename")
 def VVJe4Y(self, cmd):
  result = FF0hBQ(cmd)
  if "Fail" in result:
   FF0eUf(self, result)
  self.VVAAJ1()
 def VVWtlu(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVLtFA, title, preserve)
      , VVtCUJ = BF(self.VVIzce, title))
 def VVLtFA(self, title, preserve, VVx2mk):
  totSel = self["myMenu"].VVT6lT()
  totOk = totFail = 0
  VVx2mk.VVSJhE(totSel)
  VVx2mk.VVgnkU = ["", totSel, totOk, totFail, ""]
  VVx2mk.VVA9ka("Prepareing targz file")
  curDir = self["myMenu"].VVdFEH()
  lastPart = FFRa3J(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVx2mk or VVx2mk.isCancelled:
      return
     if row[2][6]:
      VVx2mk.VVr1vN(1)
      name  = FFliS8(row[0][0])
      lastPath = FFRa3J(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVx2mk:
       VVx2mk.VVgnkU = [outF, totSel, totOk, totFail, path]
       VVx2mk.VV7fCH(totOk, lastPath)
  except:
   totFail += 1
   if VVx2mk:
    VVx2mk.VVgnkU = [outF, totSel, totOk, totFail, path]
 def VVIzce(self, title, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVgnkU
  txt  = "%s:\n%s\n\n"   % (FFNr4J("Output File", VVhmJa), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFNr4J("Failed\t: %d\n" % totFail, VVqDXM)
  if not VVGvWA: txt += "%s\n%s" % (FFNr4J("\nCancelled while copying:", VVqDXM), path)
  FFXEvX(self, txt, title=title)
  self.VVAAJ1()
 def VVzqIf(self, isMove):
  self.session.openWithCallback(BF(self.VVwSi9, isMove), BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=self["myMenu"].VVdFEH(), VVm4ou="Move to here" if isMove else "Paste here"))
 def VVwSi9(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVBvky, title, action, isMove, newPath)
       , VVtCUJ = BF(self.VVfkrn, title, action, isMove, newPath))
 def VVBvky(self, title, action, isMove, newPath, VVx2mk):
  curDir = self["myMenu"].VVdFEH()
  totOk = totFail = 0
  totSel = self["myMenu"].VVT6lT()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVx2mk.VVSJhE(totSel)
  VVx2mk.VVgnkU = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVx2mk or VVx2mk.isCancelled:
    return
   if row[2][6]:
    VVx2mk.VVr1vN(1)
    VVx2mk.VVH4sn(action, totOk, FFRa3J(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFRa3J(path)
    if os.path.isdir(path): path = FFliS8(path)
    dest = os.path.join(newPath, lastPart)
    if FFKiof("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVx2mk:
     VVx2mk.VVgnkU = [totSel, totOk, totFail, path]
     VVx2mk.VVH4sn(action, totOk, FFRa3J(row[0][0]))
 def VVfkrn(self, title, action, isMove, newPath, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVgnkU
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFNr4J("Failed\t: %d\n" % totFail, VVqDXM)
  if not VVGvWA: txt += "%s\n%s" % (FFNr4J("\nCancelled while copying:", VVqDXM), path)
  FFXEvX(self, txt, title=title)
  self.VVAAJ1()
 def VVRjcz(self):
  tot = self["myMenu"].VVT6lT()
  FF4s3j(self, BF(FF1QiT, self, self.VV9yMx, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FF1OOs(tot)), title="Delete Selection")
 def VV9yMx(self):
  path = self["myMenu"].VVdFEH()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFQQBK(os.path.join(path, row[0][0]))
  FF7BjW(self)
  self.VVAAJ1()
 def VVxQ7T(self, path, isMove):
  self.session.openWithCallback(BF(self.VVPT5T, isMove, path), BF(CCNmp1, mode=CCNmp1.VVLQAF, VVxAst=FFabdw(path, False), VVm4ou="Move to here" if isMove else "Paste here"))
 def VVPT5T(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFliS8(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFliS8(src)
  dst = os.path.join(dst, FFRa3J(src))
  if src == dst:
   FF0eUf(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FF4s3j(self, BF(self.VVqa5B, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FF4s3j(self, BF(self.VVqa5B, prams), "Overwrite Destination Files", title=title)
  else         : self.VVqa5B(prams)
 def VVqa5B(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCNmp1.VVUQ2V(src) == CCNmp1.VVUQ2V(dst):
   FF1QiT(self, BF(self.VVUdLL, prams), title="Moving %s ..." % srcSubj)
  else:
   FF1QiT(self, BF(self.VVLTJz, prams), title="Calculating Size ...")
 def VVUdLL(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FF0hBQ("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVAAJ1()
  else:
   FF0eUf(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVLTJz(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFPebg(src)
  else  : size = FFoEhk(src)
  if size > -1:
   self.session.open(CCuBCl, barTheme=CCuBCl.VVKmRX, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVSGK6, prams, size)
       , VVtCUJ = BF(self.VVGw38, prams))
  else:
   FF0eUf(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVSGK6(self, prams, size, VVx2mk):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVx2mk.VVSJhE(size)
  VVx2mk.VVgnkU = ("", "", False)
  def VV7TKp(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFfhv3(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVx2mk or VVx2mk.isCancelled:
        VVx2mk.VVgnkU = (srcFile, "", True)
        FFfhv3(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVx2mk.VVr1vN(len(data))
       except Exception as e:
        VVx2mk.VVgnkU = (srcFile, str(e), False)
        FFfhv3(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFfhv3(srcFile)
   return True
  if isFile:
   tot = 1
   VV7TKp(src, dst)
  else:
   VVx2mk.VVA9ka("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFPgYE(src)
   if not VVx2mk or VVx2mk.isCancelled:
    VVx2mk.VVgnkU = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVx2mk.VVgnkU = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVx2mk.VVA9ka("File: %d/%d >> %s" % (fCount, tot, f))
      if not VV7TKp(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFKiof("rm -fr '%s'" % Dir)
   if isMove:
    FFKiof("rm -fr '%s'" % src)
 def VVGw38(self, prams, VVGvWA, VVgnkU, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVgnkU
  if err:
   FF0eUf(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FF7BjW(self, "Canelled", 1000)
   else  : FF0eUf(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FF7BjW(self, "Done", 1500, isGrn=True)
  if VVGvWA and isMove:
   self.VVAAJ1()
 def VVuMKj(self, path, fileName):
  path = FFliS8(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF4s3j(self, BF(FF1QiT, self, BF(self.VViPgE, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VViPgE(self, path):
  FFQQBK(path)
  FF7BjW(self)
  self.VVAAJ1()
 def VV5SmY(self, path, isFile):
  dirName = FFSiyE(os.path.dirname(path))
  if isFile : objName, VVz5S3 = "File"  , self.edited_newFile
  else  : objName, VVz5S3 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFFMZg(self, BF(self.VVuKf4, dirName, isFile, title), title=title, defaultText=VVz5S3, message="Enter %s Name:" % objName)
 def VVuKf4(self, dirName, isFile, title, VVz5S3):
  if VVz5S3:
   if isFile : self.edited_newFile = VVz5S3
   else  : self.edited_newDir  = VVz5S3
   path = dirName + VVz5S3
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VViDgN)
    else  : cmd = "mkdir '%s' %s" % (path, VViDgN)
    result = FF0hBQ(cmd)
    if "Fail" in result:
     FF0eUf(self, result)
    self.VVAAJ1()
   else:
    FF0eUf(self, "Name already exists !\n\n%s" % path, title)
 def VVjYvd(self, path, selFile):
  c1, c2, c3 = VVI2ZY, VVQzZA, VVljbY
  VVZ4NM = []
  VVZ4NM.append((c1 + "List Package Files"         , "VV4po6"     ))
  VVZ4NM.append((c1 + "Package Information"         , "VVBIp4"     ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Install Package"          , "VVaFxb_CheckVersion" ))
  VVZ4NM.append((c2 + "Install Package (force reinstall)"     , "VVaFxb_ForceReinstall" ))
  VVZ4NM.append((c2 + "Install Package (force overwrite)"     , "VVaFxb_ForceOverwrite" ))
  VVZ4NM.append((c2 + "Install Package (force downgrade)"     , "VVaFxb_ForceDowngrade" ))
  VVZ4NM.append((c2 + "Install Package (ignore failed dependencies)"  , "VVaFxb_IgnoreDepends" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c3 + "Remove Related Package"        , "VVRYhn_ExistingPackage" ))
  VVZ4NM.append((c3 + "Remove Related Package (force remove)"    , "VVRYhn_ForceRemove"  ))
  VVZ4NM.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVRYhn_IgnoreDepends" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Extract Files"           , "VVN5Kg"     ))
  VVZ4NM.append(("Unbuild Package"           , "VVluAL"     ))
  FFLMiy(self, BF(self.VVRIA8, path, selFile), VVZ4NM=VVZ4NM)
 def VVRIA8(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV4po6"      : self.VV4po6(path, selFile)
   elif item == "VVBIp4"      : self.VVBIp4(path)
   elif item == "VVaFxb_CheckVersion"  : self.VVaFxb(path, selFile, VVLJqS     )
   elif item == "VVaFxb_ForceReinstall" : self.VVaFxb(path, selFile, VV5fye )
   elif item == "VVaFxb_ForceOverwrite" : self.VVaFxb(path, selFile, VVYeKx )
   elif item == "VVaFxb_ForceDowngrade" : self.VVaFxb(path, selFile, VVcuwj )
   elif item == "VVaFxb_IgnoreDepends" : self.VVaFxb(path, selFile, VVhGyM )
   elif item == "VVRYhn_ExistingPackage" : self.VVRYhn(path, selFile, VVhXK7     )
   elif item == "VVRYhn_ForceRemove"  : self.VVRYhn(path, selFile, VVZceH  )
   elif item == "VVRYhn_IgnoreDepends"  : self.VVRYhn(path, selFile, VV0gcx )
   elif item == "VVN5Kg"     : self.VVN5Kg(path, selFile)
   elif item == "VVluAL"     : self.VVluAL(path, selFile)
   else           : self.close()
 def VV4po6(self, path, selFile):
  if FF4wzI("ar") : cmd = "allOK='1';"
  else    : cmd  = FFib1Q()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFC7Cq(self, cmd, VVgmlB=self.VVAAJ1)
 def VVN5Kg(self, path, selFile):
  lastPart = FFRa3J(path)
  dest  = FFabdw(path, True) + selFile[:-4]
  cmd  =  FFib1Q()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFyMLY("mkdir '%s'" % dest)
  cmd +=    FFyMLY("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFVW8g(dest, VVhmJa))
  cmd += "fi;"
  FFxjL4(self, cmd, VVgmlB=self.VVAAJ1)
 def VVluAL(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVJFYp = os.path.splitext(path)[0]
  else        : VVJFYp = path + "_"
  if path.endswith(".deb")   : VV5nVX = "DEBIAN"
  else        : VV5nVX = "CONTROL"
  cmd  = FFib1Q()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVJFYp
  cmd += "  mkdir '%s';"      % VVJFYp
  cmd += "  CONTPATH='%s/%s';"    % (VVJFYp, VV5nVX)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVJFYp
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVJFYp, VVJFYp)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVJFYp
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVJFYp, VVJFYp)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVJFYp
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVJFYp
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVJFYp, FFVW8g(VVJFYp, VVhmJa))
  cmd += "fi;"
  FFxjL4(self, cmd, VVgmlB=self.VVAAJ1)
 def VVBIp4(self, path):
  listCmd  = FF8xxa(VVWjcv, "")
  infoCmd  = FF2pmn(VVsD89 , "")
  filesCmd = FF2pmn(VVEQtj, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFsa3j(VVde5r)
   notInst = "Package not installed."
   cmd  = FF437T("File Info", VVde5r)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF437T("System Info", VVde5r)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFVW8g(notInst, VVqDXM))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF437T("Related Files", VVde5r)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFA10e(self, cmd)
  else:
   FFPXac(self)
 def VVaFxb(self, path, selFile, cmdOpt):
  cmd = FF2pmn(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF4s3j(self, BF(FFxjL4, self, cmd, VVgmlB=FFZ1wQ), "Install Package ?\n\n%s" % selFile)
  else:
   FFPXac(self)
 def VVRYhn(self, path, selFile, cmdOpt):
  listCmd  = FF8xxa(VVWjcv, "")
  infoCmd  = FF2pmn(VVsD89, "")
  instRemCmd = FF2pmn(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFVW8g(errTxt, VVqDXM))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFVW8g(cannotTxt, VVqDXM))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFVW8g(tryTxt, VVqDXM))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF4s3j(self, BF(FFxjL4, self, cmd, VVgmlB=FFZ1wQ), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFPXac(self)
 def VVQlpP(self, path):
  hostName = FF0hBQ("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV2M0C(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVZ4NM = []
  VVZ4NM.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVZ4NM.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVZ4NM.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVZ4NM.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVZ4NM.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVZ4NM.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVZ4NM.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVZ4NM.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVZ4NM.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVZ4NM.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFLMiy(self, BF(self.VVfz6g, path, isDir, title), VVZ4NM=VVZ4NM, title=title, VVrEme=c1, VVRBt6=c2)
 def VVfz6g(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVjDk9(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVjDk9(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVjDk9(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVjDk9(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVjDk9(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVjDk9(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVjDk9(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVjDk9(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVjDk9(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVjDk9(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVxktM(path, False)
   elif item == "convertDirToDeb" : self.VVxktM(path, True)
 def VVxktM(self, path, VVqmRU):
  self.session.openWithCallback(self.VVAAJ1, BF(CCCLco, path=path, VVqmRU=VVqmRU))
 def VVjDk9(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFabdw(path, True)
  lastPart = FFRa3J(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF6Lzl("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF6Lzl("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF6Lzl("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFyMLY("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFVW8g(failed, VVIZs4))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFVW8g(srcTxt, VVi9VJ))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFVW8g("Output", VVhmJa))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFVW8g(failed, VVEWKM))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFC7Cq(self, cmd, VVgmlB=self.VVAAJ1, title=title)
 def VV1ReJ(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCNmp1.VVDPeF(FFabdw(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC8DHP(self, self, title, BF(self.VVP0SG, pathLst))
 def VVP0SG(self, pathLst):
  return CC8DHP.VVAa9k(pathLst)
 def VVsTZQ(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVdoyK, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF4s3j(self, BF(FF1QiT, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF1QiT(self, fnc, title=txt)
  else:
   FF0eUf(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVdoyK(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFXEvX(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVAAJ1()
  else:
   FFfhv3(tarPath)
   FF0eUf(self, "Error while converting.", title=title)
 def VVlBnd(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVKd5t, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF4s3j(self, BF(FF1QiT, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF1QiT(self, fnc, title=txt)
  else:
   FF0eUf(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVKd5t(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFXEvX(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVAAJ1()
  else:
   FFfhv3(zipPath)
   FF0eUf(self, "Error while converting.", title=title)
 def VVkIT0(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFSiyE(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFKiof("rm -f '%s' '%s'" % (m1v, mvi))
  if FFKiof("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFKiof("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVAAJ1()
   FFH1Ib(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FF0eUf(self, "Cannot convert this file !", title=title)
 def VVpwkj(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCk0vb.VVJcyT()
  if pathExists(pPath):
   if CCzEE9.VVTmbu(self, title, False, cbFnc=BF(self.VVpwkj, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVZ4NM = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVZ4NM.append(("%d x %d" % (item), item))
    VVsk8Y = self.VVBwxZ
    VVs32w = ("Stretch", BF(self.VV5hcd, title, path, picon))
    VVKicw = FFLMiy(self, BF(self.VVl1ek, title, path, picon, False), VVZ4NM=VVZ4NM, width=700, title='PIcon Max. Size', VVsk8Y=VVsk8Y, VVs32w=VVs32w, barText="OK = Fit within size")
    VVKicw.VVcLR7(3)
  else:
   FF0eUf(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VV5hcd(self, title, path, picon, VVMD9SObj, item):
  self.VVl1ek(title, path, picon, True, item)
  VVMD9SObj.cancel()
 def VVl1ek(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFGNa7(self, fncMode=CCUr80.VV26qy)
   except Exception as e:
    FF0eUf(self, "Image Processing error:\n\n%s" % e)
 def VVBwxZ(self, VVKicw, txt, ref, ndx):
  FFC2xZ(self, "_help_resize", "Picture File Resizing")
 def VVcZ3E(self, path):
  FFLMiy(self, BF(self.VVbzYO, path), VVZ4NM=CCXyjP.VVsfDi(), width=650, title="Select Player", VVrEme="#11220000", VVRBt6="#11220000")
 def VVbzYO(self, path, rType=None):
  if rType:
   FF1QiT(self, BF(self.VVcIM8, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVcIM8(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCXYrc.VVRGWe(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVORqp(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFSiyE(fDir), fName
  return "", "", ""
 @staticmethod
 def VVmDUR(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVaKQl(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV3y2b(size, mode=0):
  txt = CCNmp1.VVdL6F(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVdL6F(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVMLm6(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV1wzQ(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FF0eUf(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVRq3i():
  tDict = CCid1U.VVyaUp()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVDPeF(path):
  lst = []
  for ext in CCNmp1.VVRq3i():
   lst.extend(FFFDtI(path, "*.%s" % ext))
  return sorted(lst, key=FFl2yM(FFaQHk))
 @staticmethod
 def VVHXvz(path):
  return FFKiof("tar -tzf '%s'" % path)
 @staticmethod
 def VVUQ2V(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVUj2E(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVwyjo:
   return VVwyjo
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCid1U(MenuList):
 VVyiMd   = 0
 VVsgW9   = 1
 VVhDmL   = 2
 VV2qQA   = 3
 VVgckh   = 4
 VVKCGF   = 5
 VVrqTo   = 6
 VVe4XB   = 7
 VVuRfG   = "<List of Storage Devices>"
 VVl1SS  = "<Parent Directory>"
 VVrOVX   = 0
 VVBb2r   = 1
 VVO7XQ = 2
 VVsBiP  = 3
 VVVyFP   = 4
 VVp65G   = 5
 FILE_TYPE_LINK   = 6
 VV4JhE  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VV67gN=False, directory="/", VVs3ub=True, VVmfgw=True, VVjMf8=True, VVIDud=None, VV4pRs=False, VVfWj2=False, VVDy0K=False, isTop=False, VVUMfV=None, VVeaGH=1000, VVsgYf=30, VV12Gz=30):
  MenuList.__init__(self, list, VV67gN, eListboxPythonMultiContent)
  self.VVs3ub  = VVs3ub
  self.VVmfgw    = VVmfgw
  self.VVjMf8  = VVjMf8
  self.VVIDud  = VVIDud
  self.VV4pRs   = VV4pRs
  self.VVfWj2   = VVfWj2 or []
  self.VVDy0K   = VVDy0K or []
  self.isTop     = isTop
  self.additional_extensions = VVUMfV
  self.VVeaGH    = VVeaGH
  self.VVsgYf    = VVsgYf
  self.VV12Gz    = VV12Gz
  self.EXTENSIONS    = CCid1U.VVyaUp()
  self.VV8MQ7   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFYkgg("#11ff4444")
  self.l.setFont(0, gFont(VVbeZc, self.VVsgYf))
  self.l.setItemHeight(self.VV12Gz)
  self.png_mem   = CCid1U.VVMo7M("mem")
  self.png_usb   = CCid1U.VVMo7M("usb")
  self.png_fil   = CCid1U.VVMo7M("fil")
  self.png_dir   = CCid1U.VVMo7M("dir")
  self.png_dirup   = CCid1U.VVMo7M("dirup")
  self.png_srv   = CCid1U.VVMo7M("srv")
  self.png_slwfil   = CCid1U.VVMo7M("slwfil")
  self.png_slbfil   = CCid1U.VVMo7M("slbfil")
  self.png_slwdir   = CCid1U.VVMo7M("slwdir")
  self.VVos6X()
  self.VVv5wk(directory)
 @staticmethod
 def VVMo7M(category):
  return LoadPixmap("%s%s.png" % (VVrRM9, category), getDesktop(0))
 @staticmethod
 def VVyaUp():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVlErd(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFliS8(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFNr4J(" -> " , VVde5r) + FFNr4J(os.readlink(path), VVhmJa)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV12Gz + 10, 0, self.VVeaGH, self.VV12Gz, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV5WKm: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV12Gz-4, self.VV12Gz-4, png, None, None, VV5WKm))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV12Gz-4, self.VV12Gz-4, png, None, None))
  return tableRow
 def VVDpoo(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVos6X(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVH6ZT(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVzoNv(self, file):
  if os.path.realpath(file) == file:
   return self.VVH6ZT(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVH6ZT(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVH6ZT(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVI5Ot(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVCiw6(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVtrtY(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVCiw6(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVCiw6(self, row, bg):
  if self.VVxFBC(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVxFBC(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVp65G, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVVyFP:
    if   VVLt64           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVDfdL(self):
  return self.VVxFBC(self.list[self.l.getCurrentSelectionIndex()])
 def VVT6lT(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVDEfc(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVv5wk(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVjMf8:
    self.current_mountpoint = self.VVzoNv(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVjMf8:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVDy0K and not self.VVDEfc(path, self.VVfWj2):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVlErd(name=p.description, absolute=path, isDir=True, typ=self.VVrOVX, png=png))
    path = "/"
    if path not in self.VVDy0K and not self.VVDEfc(path, self.VVfWj2):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVlErd(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVBb2r, png=self.png_mem))
  elif self.VV4pRs:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV8MQ7 = eServiceCenter.getInstance()
   list = VV8MQ7.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVs3ub and not self.isTop:
   if directory == self.current_mountpoint and self.VVjMf8:
    self.list.append(self.VVlErd(name=self.VVuRfG, absolute=None, isDir=True, typ=self.VVO7XQ, png=self.png_dirup))
   elif (directory != "/") and not (self.VVDy0K and self.VVH6ZT(directory) in self.VVDy0K):
    self.list.append(self.VVlErd(name=self.VVl1SS, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVsBiP, png=self.png_dirup))
  if self.VVs3ub:
   for x in directories:
    if not (self.VVDy0K and self.VVH6ZT(x) in self.VVDy0K) and not self.VVDEfc(x, self.VVfWj2):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVlErd(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFliS8(x)) else self.VVVyFP, png=png))
  if self.VVmfgw:
   for x in files:
    if self.VV4pRs:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFNr4J(" -> " , VVde5r) + FFNr4J(target, VVhmJa)
       else:
        png = self.png_slbfil
        name += FFNr4J(" -> " , VVde5r) + FFNr4J(target, VVEWKM)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVDpoo(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVrRM9, category))
    if (self.VVIDud is None) or iCompile(self.VVIDud[0], flags=self.VVIDud[1]).search(path):
     self.list.append(self.VVlErd(name=name, absolute=x , isDir=False, typ=self.VVp65G, png=png))
  if self.VVjMf8 and len(self.list) == 0:
   self.list.append(self.VVlErd(name=FFNr4J("No USB connected", VVi1yn), absolute=None, isDir=False, typ=self.VV4JhE, png=self.png_usb))
  self.l.setList(self.list)
  self.VVUHpW()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVdFEH(self):
  return self.current_directory
 def VV9wid(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVFfkw(self):
  return self.VVhwr8() and self.VVdFEH()
 def VVhwr8(self):
  return self.list[0][1][7] in (self.VVuRfG, self.VVl1SS)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVv5wk(self.getSelection()[0], self.current_directory)
 def VVu0Zy(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VViGoh)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VViGoh)
 def VViGoh(self, action, device):
  self.VVos6X()
  if self.current_directory is None:
   self.VVwBZs()
 def VVwBZs(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVv5wk(self.current_directory, self.VVu0Zy())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVkRtD(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVyiMd : nameAlpMode, nameAlpTxt = self.VVsgW9, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVyiMd, sAZ
  if mode == self.VVhDmL : nameNumMode, nameNumTxt = self.VV2qQA, s90
  else       : nameNumMode, nameNumTxt = self.VVhDmL, s09
  if mode == self.VVgckh : dateMode, dateTxt = self.VVKCGF, sON
  else       : dateMode, dateTxt = self.VVgckh, sNO
  if mode == self.VVrqTo : typeMode, typeTxt = self.VVe4XB, sZA
  else       : typeMode, typeTxt = self.VVrqTo, sAZ
  if   mode in (self.VVyiMd, self.VVsgW9): txt = "Name (%s)" % (sAZ if mode == self.VVyiMd else sZA)
  elif mode in (self.VVhDmL, self.VV2qQA): txt = "Name (%s)" % (s09 if mode == self.VVyiMd else s90)
  elif mode in (self.VVgckh, self.VVKCGF): txt = "Date (%s)" % (sNO if mode == self.VVgckh else sON)
  elif mode in (self.VVrqTo, self.VVe4XB): txt = "Type (%s)" % (sAZ if mode == self.VVrqTo else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVUHpW(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFE6Br(CFG.browserSortMode, mode)
   FFE6Br(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVhwr8() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVyiMd, self.VVsgW9):
    rev = True if mode == self.VVsgW9 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVhDmL, self.VV2qQA):
    rev = True if mode == self.VV2qQA else False
    self.list = sorted(self.list[item0:], key=FFl2yM(BF(self.VVwsB9, isMix, rev)), reverse=rev)
   elif mode in (self.VVgckh, self.VVKCGF):
    rev = True if mode == self.VVKCGF else False
    self.list = sorted(self.list[item0:], key=FFl2yM(BF(self.VVtNmH, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVe4XB else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVwsB9(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFaQHk(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFIi1s(dir2, dir1) or FFaQHk(name1, name2)
 def VVtNmH(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFIi1s(stat2.st_ctime, stat1.st_ctime)
    else : return FFIi1s(dir2, dir1) or FFIi1s(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCfckU(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFWbv3(VV2Ev8, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVDpqo   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVt6fn(defFG, "#00FFFFFF")
  self.defBG   = self.VVt6fn(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF3tZI(self, self.Title)
  self["keyRed"].show()
  FFTvkX(self["keyGreen"] , "< > Transp.")
  FFTvkX(self["keyYellow"], "Foreground")
  FFTvkX(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV3tDw     ,
   "green"   : self.VV3tDw     ,
   "yellow"  : BF(self.VV6F9R, False)  ,
   "blue"   : BF(self.VV6F9R, True)  ,
   "up"   : self.VV1gWt       ,
   "down"   : self.VVzsiY      ,
   "left"   : self.VVhkxh      ,
   "right"   : self.VVFho7      ,
   "last"   : BF(self.VVXq6u, -5) ,
   "next"   : BF(self.VVXq6u, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV7StE)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFIznG(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFIznG(self["keyRed"] , c)
  FFIznG(self["keyGreen"] , c)
  self.VVkxoN()
  self.VVr1uk()
  FFDUax(self["myColorTst"], self.defFG)
  FFIznG(self["myColorTst"], self.defBG)
 def VVt6fn(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVr1uk(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVyJaJ(0, 0)
     return
 def VV3tDw(self):
  self.close(self.defFG, self.defBG)
 def VV1gWt(self): self.VVyJaJ(-1, 0)
 def VVzsiY(self): self.VVyJaJ(1, 0)
 def VVhkxh(self): self.VVyJaJ(0, -1)
 def VVFho7(self): self.VVyJaJ(0, 1)
 def VVyJaJ(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVK0QJ()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVoLTH()
 def VVkxoN(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVoLTH(self):
  color = self.VVK0QJ()
  if self.isBgMode: FFIznG(self["myColorTst"], color)
  else   : FFDUax(self["myColorTst"], color)
 def VV6F9R(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVkxoN()
   self.VVr1uk()
 def VVXq6u(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVyJaJ(0, 0)
 def VVbpYA(self):
  return hex(self.transp)[2:].zfill(2)
 def VVK0QJ(self):
  return ("#%s%s" % (self.VVbpYA(), self.colors[self.curRow][self.curCol])).upper()
class CCLRK4(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWbv3(VVHYPd, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FF3tZI(self, title="%s%s%s" % (self.Title, " " * 10, FFNr4J("Change values with Up , Down, < , 0 , >", VVi1yn)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4SyA      ,
   "cancel" : self.VVGj7j      ,
   "info"  : self.VVEepk    ,
   "red"  : self.VVkWHy  ,
   "green"  : self.VVrz3R   ,
   "yellow" : BF(self.VV6Vnt, 0)  ,
   "blue"  : self.VVjrEC    ,
   "menu"  : self.VV02yv      ,
   "left"  : self.VVhkxh      ,
   "right"  : self.VVFho7      ,
   "last"  : self.VVDkeh     ,
   "next"  : self.VVBPps     ,
   "0"   : self.VVaYVc    ,
   "up"  : self.VV1gWt       ,
   "down"  : self.VVzsiY      ,
   "pageUp" : BF(self.VVh4wA, True) ,
   "pageDown" : BF(self.VVh4wA, False) ,
   "chanUp" : BF(self.VVh4wA, True) ,
   "chanDown" : BF(self.VVh4wA, False) ,
   "play"  : BF(self.VV6X2H, "pause")  ,
   "pause"  : BF(self.VV6X2H, "pause")  ,
   "playPause" : BF(self.VV6X2H, "pause")  ,
   "stop"  : BF(self.VV6X2H, "pause")  ,
   "audio"  : BF(self.VV6X2H, "audio")  ,
   "subtitle" : BF(self.VV6X2H, "subtitle") ,
   "rewind" : BF(self.VV6X2H, "rewind" ) ,
   "forward" : BF(self.VV6X2H, "forward" ) ,
   "rewindDm" : BF(self.VV6X2H, "rewindDm") ,
   "forwardDm" : BF(self.VV6X2H, "forwardDm")
  }, -1)
  self.VVB8sn()
  self.onShown.append(self.VV7StE)
  self.onClose.append(self.VVtI43)
 def VVB8sn(self):
  lst = []
  for fil in FFFDtI(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVI9QA:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VV7StE(self):
  self.onShown.remove(self.VV7StE)
  FFxlor(self)
  FFBjfS(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVxu5m()
  self.VVB9Vi()
  self.VVyX1S()
 def VVtI43(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVU5WS(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFIznG(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVuQPj()
 def VVxu5m(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFIznG(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VV4SyA(self):
  if self.settingShown:
   confItem = self.VVPsCb()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVZ4NM = []
   if isinstance(lst[0], tuple):
    for item in lst: VVZ4NM.append((item[1], item[0]))
   else:
    for item in lst: VVZ4NM.append((item, item))
   VVKicw = FFLMiy(self, self.VV5AVw, VVZ4NM=VVZ4NM, width=700, title=title, VVrEme="#33221111", VVRBt6="#33110011")
   VVKicw.VVEfNd(confItem.getText())
  else:
   self.close("subtExit")
 def VV5AVw(self, item=None):
  if item:
   self.VVPsCb()[self.CursorPos].setValue(item)
   self.VVuQPj()
   self.VVB9Vi()
   self.VVHGpm(True)
 def VVGj7j(self):
  for confItem in self.VVPsCb():
   if confItem.isChanged():
    FF4s3j(self, BF(self.VVsf9p, cbFnc=self.VVcSKK), "Save Changes ?", callBack_No=self.VVxPaQ, title=self.Title)
    break
  else:
   self.VVcSKK()
 def VVcSKK(self):
   if self.settingShown: self.VVxu5m()
   else    : self.close("subtExit")
 def VV02yv(self):
  if self.settingShown: self.VV7SDo()
  else    : self.VVU5WS()
 def VVhkxh(self): self.VVIqXj(-1)
 def VVFho7(self): self.VVIqXj(1)
 def VVIqXj(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VV3Kjx()
   if pos == -1: ndx = self.VVijd5(posVal)
   else  : ndx = self.VV3bs6(posVal)
   if   ndx < 0      : FF7BjW(self, "Not found" , 500)
   elif ndx == 0      : FF7BjW(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FF7BjW(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVISVS(frmSec)
    if allow:
     self.VV6Vnt(delay, True)
     self.VVHGpm(force=True)
     CCZCdI(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FF7BjW(self, "Delay out of range", 800)
 def VVh4wA(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV6X2H(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVDkeh(self) : self.VVFI2R(5)
 def VVBPps(self) : self.VVFI2R(6)
 def VVaYVc(self) : self.VVFI2R(-1)
 def VV1gWt(self):
  if self.settingShown: self.VVFI2R(1)
  else    : self.VVh4wA(True)
 def VVzsiY(self):
  if self.settingShown: self.VVFI2R(0)
  else    : self.VVh4wA(False)
 def VVFI2R(self, direction):
  if self.settingShown:
   confItem = self.VVPsCb()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVuQPj()
   self.VVB9Vi()
   self.VVHGpm(True)
 def VVPsCb(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVxPaQ(self):
  for confItem in self.VVPsCb(): confItem.cancel()
  self.VVuQPj()
  self.VVB9Vi()
  self.VVxu5m()
 def VVkWHy(self):
  if self.settingShown:
   FF4s3j(self, self.VV3FWK, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV3FWK(self):
  for confItem in self.VVPsCb(): confItem.setValue(confItem.default)
  self.VVsf9p()
  self.VVuQPj()
  self.VVB9Vi()
 def VV6Vnt(self, delay, force=False):
  if self.settingShown or force:
   FFE6Br(CFG.subtDelaySec, delay)
   self.VVXY6N()
   self.VVuQPj()
   self.VVB9Vi()
   if self.settingShown:
    FF7BjW(self, 'Reset to "0"', 800, isGrn=True)
 def VVrz3R(self):
  if self.settingShown:
   self.VVsf9p()
   self.VVxu5m()
 def VVsf9p(self, cbFnc=None):
  for confItem in self.VVPsCb(): confItem.save()
  configfile.save()
  self.VVXY6N()
  FF7BjW(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVuQPj(self):
  cfgLst = self.VVPsCb()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVB9Vi(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFdhDJ(path, fnt, isRepl=1)
  else:
   fnt = VVbeZc
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFvWYU(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFDUax(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFIznG(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFyUJL(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFvWYU(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFeubS()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFrdtL(self, winW, winH)
 def VVEepk(self):
  sp = "    "
  txt  = "%s\n"   % FFNr4J("Subtitle File:", VVQzZA)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFNr4J("Subtitle Settings:", VVQzZA)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VV3Kjx()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFaFw5(frmSec1)
   time2 = FFaFw5(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFNr4J("Timing:", VVQzZA)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFaFw5(durVal)
   txt += sp + "Progress\t: %s\n" % FFaFw5(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFNr4J("Subtitle end reached.", VVIZs4)
  FFXEvX(self, txt, title="Current Subtitle")
 def VVyX1S(self, path="", delay=0, enc=""):
  FF1QiT(self, BF(self.VV1MO4, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VV1MO4(self, path="", delay=0, enc=""):
  FF7BjW(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVRGTb(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVuQPj()
     self.VVOQcB()
   else:
    path, delay, enc = CCLRK4.VVYkSW(self)
    if path:
     self.VVyX1S(path=path, delay=delay, enc=enc)
    else:
     self.VV7SDo()
  except:
   pass
 def VVOQcB(self):
  posVal, durVal = self.VV3Kjx()
  if self.VVQzY4(posVal):
   return
  CCLRK4.VVSOr7(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVHGpm)
  except:
   self.timerUpdate.callback.append(self.VVHGpm)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVboK2)
  except:
   self.timerEndText.callback.append(self.VVboK2)
  FF7BjW(self, "Subtitle started", 700, isGrn=True)
 def VVQzY4(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCLRK4.VV8ZLI(self)
   FFfhv3(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV7SDo(self):
  c1, c2, c3, c4, c5 = "", VVQzZA, VVh9Nn, VVljbY, VVIZs4
  VVZ4NM = []
  VVZ4NM.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVZ4NM.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVZ4NM.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVZ4NM.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append(("Help (Keys)"        , "help"  ))
  FFLMiy(self, self.VVbGdT, VVZ4NM=VVZ4NM, width=700, title='Find Subtitle ".srt" File', VVrEme="#33221111", VVRBt6="#33110011")
 def VVbGdT(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVr4bT(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVr4bT(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVFsZF, BF(CCNmp1, patternMode="srt", VVxAst=sDir))
   elif item.startswith("sugSrt") : self.VVr4bT(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF1QiT(self, BF(CC9SOR.VVJOY4, self, self.lastSubtFile, self.VV8JX5, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FF7BjW(self, "SRT File error", 1000)
   elif item == "disab":
    FFfhv3(CCLRK4.VV8ZLI(self))
    self.close("subtExit")
   elif item == "help"    : FFC2xZ(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VV8JX5(self, item=None):
  if item:
   FF1QiT(self, BF(self.VVyX1S, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVFsZF(self, path):
  if path:
   FFE6Br(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVyX1S(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVr4bT(self, defSrt="", mode=0, coeff=0.25):
  FF1QiT(self, BF(self.VVCnzY, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVCnzY(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCLRK4.VVrWce(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFtLFA('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFhDaE(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVhnWl(srtList, coeff)
     if err:
      if self.settingShown: FFVyvQ(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVJIKO = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFSiyE(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVJIKO.append((fName, Dir))
   VVFJkn  = ("Select"    , self.VVsYJi     , [])
   VVQLDs = self.VVsMta
   VVU95Y = (""     , self.VVTAV1       , [])
   VVHEpO = (""     , BF(self.VVcUcF, defSrt, False) , [])
   VV8lmg = ("Find Current File" , BF(self.VVcUcF, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVQT0l=widths, VVsgYf=28, VVFJkn=VVFJkn, VVQLDs=VVQLDs, VVU95Y=VVU95Y, VVHEpO=VVHEpO, VV8lmg=VV8lmg, lastFindConfigObj=CFG.lastFindSubtitle
     , VVrEme="#11002222", VVRBt6="#33001111", VVfKIv="#33001111", VVIWfT="#11ffff00", VV6z2K="#11445544", VV7JIr="#22222222", VVpBpY="#11002233")
  elif self.settingShown : FFVyvQ(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVsMta(self, VVSuUg):
  VVSuUg.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVTAV1(self, VVSuUg, title, txt, colList):
  fName, Dir = colList
  FFXEvX(VVSuUg, "%s\n\n%s%s" % (FFNr4J("Path:", VVQzZA), Dir, fName), title=title)
 def VVcUcF(self, path, VVR9V4, VVSuUg, title, txt, colList):
  for ndx, row in enumerate(VVSuUg.VVOxLE()):
   if path == row[1].strip() + row[0].strip():
    VVSuUg.VVpxIX(ndx)
    break
  else:
   if VVR9V4:
    FF7BjW(VVSuUg, "Not in list !", 1000)
 def VVsYJi(self, VVSuUg, title, txt, colList):
  VVSuUg.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVyX1S(path=path)
 def VVhnWl(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCh6kb.VVTCNl(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCh6kb.VVFfoF(evName, "en")[0] or evName
   lst, err = CCLRK4.VV16yz(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVRGTb(self, path, enc=None):
  if enc and CC9SOR.VVuRGF(path, enc)      : enc = enc
  elif CC9SOR.VVuRGF(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFPebg(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFMA9m(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VV9Xzu(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVSTKK(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVXY6N()
  return subtList, ""
 def VVSTKK(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VV9Xzu(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVXY6N(self):
  path = CCLRK4.VV8ZLI(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVHGpm(self, force=False):
  posVal, durVal = self.VV3Kjx()
  if self.VVQzY4(posVal):
   return
  curIndex = self.VVBmTN(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVboK2()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFDUax(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VV3Kjx(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXYrc.VVACx1(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCh6kb.VVTCNl(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVBmTN(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVijd5(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV3bs6(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVboK2(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFDUax(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVjrEC(self):
  FF1QiT(self, self.VVATrX, title="Loading Lines ...")
 def VVATrX(self):
  VVJIKO = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVJIKO.append((cap, FFaFw5(frm), str(frm), firstLine))
  if VVJIKO:
   title = "Select Current Subtitle Line"
   VVbl2R  = self.VV1DOt
   VVQLDs = self.VVBMg4
   VVFJkn  = ("Select"   , self.VVE2IH , [title])
   VV8lmg = ("Current Line" , self.VVEBup , [True])
   VV0RwZ = ("Reset Delay" , self.VVIV2n , [])
   VVUpMt = ("New Delay"  , self.VV7lo3   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVXdZ9  = (CENTER , CENTER, CENTER , LEFT    )
   VVSuUg = FFW2Tv(self, None, title=title, header=header, VVDpqo=VVJIKO, VVXdZ9=VVXdZ9, VVQT0l=widths, VVsgYf=28, VVbl2R=VVbl2R, VVQLDs=VVQLDs, VVFJkn=VVFJkn, VV8lmg=VV8lmg, VV0RwZ=VV0RwZ, VVUpMt=VVUpMt
          , VVrEme="#33002222", VVRBt6="#33001111", VVfKIv="#33110011", VVIWfT="#11ffff00", VV6z2K="#0a334455", VV7JIr="#22222222", VVpBpY="#33002233")
  else:
   FFVyvQ(self, "Cannot read lines !", 2000)
 def VV1DOt(self, VVSuUg):
  self.subtLinesTable = VVSuUg
  if CFG.subtDelaySec.getValue():
   VVSuUg["keyYellow"].show()
   VVSuUg["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVSuUg["keyYellow"].hide()
  VVSuUg["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFIznG(VVSuUg["keyBlue"], "#22222222")
  VVSuUg.VV9XZ7(BF(self.VVqZUA, VVSuUg))
  self.VVEBup(VVSuUg, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVPYdm)
  except:
   self.timerSubtLines.callback.append(self.VVPYdm)
  self.timerSubtLines.start(1000, False)
 def VVBMg4(self, VVSuUg):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVSuUg.cancel()
 def VVPYdm(self):
  if self.subtLinesTable:
   VVSuUg = self.subtLinesTable
   posVal, durVal = self.VV3Kjx()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVBmTN(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVSuUg.VVTuTs(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVSuUg.VVghZJ(self.subtLinesTableNdx, row)
     row = VVSuUg.VVTuTs(curIndex)
     row[0] = color + row[0]
     VVSuUg.VVghZJ(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVE2IH(self, VVSuUg, Title):
  delay, color, allow = self.VVVUu2(VVSuUg)
  if allow:
   self.VVBMg4(VVSuUg)
   self.VV6Vnt(delay, True)
  else:
   FF7BjW(VVSuUg, "Delay out of range", 1500)
 def VVEBup(self, VVSuUg, VVR9V4, onlyColor=False):
  if VVSuUg:
   posVal, durVal = self.VV3Kjx()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVBmTN(posVal)
    if curIndex > -1:
     VVSuUg.VVpxIX(curIndex)
    else:
     ndx = self.VVijd5(posVal)
     if ndx > -1:
      VVSuUg.VVpxIX(ndx)
 def VVIV2n(self, VVSuUg, title, txt, colList):
  if VVSuUg["keyYellow"].getVisible():
   self.VV6Vnt(0, True)
   VVSuUg["keyYellow"].hide()
   self.VVEBup(VVSuUg, False)
 def VVqZUA(self, VVSuUg):
  delay, color, allow = self.VVVUu2(VVSuUg)
  VVSuUg["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVVUu2(self, VVSuUg):
  lineTime = float(VVSuUg.VVU4OP()[2].strip())
  return self.VVISVS(lineTime)
 def VVISVS(self, lineTime):
  posVal, durVal = self.VV3Kjx()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVI2ZY
   else     : allow, color = False, VVIZs4
   delay = FF6FFy(val, -600, 600)
  return delay, color, allow
 def VV7lo3(self, VVSuUg, title, txt, colList):
  pass
 @staticmethod
 def VVDOWV(SELF):
  path, delay, enc = CCLRK4.VVYkSW(SELF)
  return True if path else False
 @staticmethod
 def VVYkSW(SELF):
  path, delay, enc = CCLRK4.VVt2C7(SELF)
  if not path:
   path = CCLRK4.VVXcK4(SELF)
  return path, delay, enc
 @staticmethod
 def VVt2C7(SELF):
  srtCfgPath = CCLRK4.VV8ZLI(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFMA9m(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VV8ZLI(SELF):
  fPath, fDir, fName = CCNmp1.VVORqp(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCh6kb.VVTCNl(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFAJK0(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVXcK4(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCNmp1.VVORqp(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCLRK4.VVrWce(SELF)
    bLst, err = CCLRK4.VV16yz(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVrWce(SELF):
  fPath, fDir, fName = CCNmp1.VVORqp(SELF)
  if pathExists(fDir):
   files = FFFDtI(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VV16yz(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVwmQF():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVSOr7(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCLRK4.VVJImU()
 @staticmethod
 def VVJImU():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCTyJ1(ScrollLabel):
 def __init__(self, parentSELF, text="", VVhhF4=True):
  ScrollLabel.__init__(self, text)
  self.VVhhF4   = VVhhF4
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVomuf  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVsgYf    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVJ4f9 ,
   "green"   : self.VVcaBK ,
   "yellow"  : self.VVyM7c ,
   "blue"   : self.VVtsTs ,
   "up"   : self.VV5pnx   ,
   "down"   : self.VVJIVY  ,
   "left"   : self.VV5pnx   ,
   "right"   : self.VVJIVY  ,
   "last"   : BF(self.VVFDqk, 0) ,
   "0"    : BF(self.VVFDqk, 1) ,
   "next"   : BF(self.VVFDqk, 2) ,
   "pageUp"  : self.VVq7xy   ,
   "chanUp"  : self.VVq7xy   ,
   "pageDown"  : self.VVnRiv   ,
   "chanDown"  : self.VVnRiv
  }, -1)
 def VVILcs(self, isResizable=True, VVTarI=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFDUax(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFIznG(self.parentSELF["keyRedTop"], "#113A5365")
  FFxlor(self.parentSELF, True)
  self.isResizable = isResizable
  if VVTarI:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVsgYf  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFIznG(self, color)
 def VVPUkd(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VV12Gz  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VV12Gz)
  margin   = int(VV12Gz / 6)
  self.pageHeight = int(self.pageLines * VV12Gz)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVomuf - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVh1gT()
 def VV5pnx(self):
  if self.VVomuf > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVJIVY(self):
  if self.VVomuf > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVq7xy(self):
  self.setPos(0)
 def VVnRiv(self):
  self.setPos(self.VVomuf-self.pageHeight)
 def VV20p3(self):
  return self.VVomuf <= self.pageHeight or self.curPos == self.VVomuf - self.pageHeight
 def getText(self):
  return self.message
 def VVh1gT(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVomuf, 3))
   start = int((100 - vis) * self.curPos / (self.VVomuf - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVgcXL=VVLTYB):
  old_VV20p3 = self.VV20p3()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVomuf = self.long_text.calculateSize().height()
   if self.VVhhF4 and self.VVomuf > self.pageHeight:
    self.scrollbar.show()
    self.VVh1gT()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVomuf))
    self.VVomuf = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVomuf))
   else:
    self.scrollbar.hide()
   if   VVgcXL == VVFlog: self.setPos(0)
   elif VVgcXL == VV8u5W : self.VVnRiv()
   elif old_VV20p3    : self.VVnRiv()
 def appendText(self, text, VVgcXL=VV8u5W):
  self.setText(self.message + str(text), VVgcXL=VVgcXL)
 def VVyM7c(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVLeQp(size)
 def VVtsTs(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVLeQp(size)
 def VVcaBK(self):
  self.VVLeQp(self.VVsgYf)
 def VVLeQp(self, VVsgYf):
  self.long_text.setFont(gFont(self.fontFamily, VVsgYf))
  self.setText(self.message, VVgcXL=VVLTYB)
  self.VVxeK7()
 def VVFDqk(self, align):
  self.long_text.setHAlign(align)
 def VVJ4f9(self):
  VVZ4NM = []
  VVZ4NM.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Align Left" , "left" ))
  VVZ4NM.append(("Align Center" , "center" ))
  VVZ4NM.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVZ4NM.append(VVVvw4)
   VVZ4NM.append((FFNr4J("Save to File", VVQzZA), "save"))
  VVZ4NM.append(VVVvw4)
  VVZ4NM.append(("Keys (Shortcuts)", "help"))
  FFLMiy(self.parentSELF, self.VVopfM, VVZ4NM=VVZ4NM, title="Text Option", width=500)
 def VVopfM(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVFDqk(0)
   elif item == "center" : self.VVFDqk(1)
   elif item == "right" : self.VVFDqk(2)
   elif item == "save"  : self.VVtTos()
   elif item == "help"  : FFC2xZ(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVtTos(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFSiyE(expPath), self.outputFileToSave, FFXJI8())
   with open(outF, "w") as f:
    f.write(FFhc8v(self.message))
   FFH1Ib(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FF0eUf(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVxeK7(self, minHeight=0):
  if self.isResizable:
   VV12Gz = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VV12Gz * (len(self.message.splitlines()) + 1))
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
