import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVJjPN   = "v8.4.0"
VVotAg    = "09-01-2023"
EASY_MODE    = 0
VVDbue   = 0
VVkqaS   = 0
VVUMIB  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VV8tIu  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVFuxe    = "/media/usb/"
VVv2S9    = "/usr/share/enigma2/picon/"
VVJO6z = "/etc/enigma2/blacklist"
VVCQ1V   = "/etc/enigma2/"
VVna0S   = "AJPan"
VVoZbD  = "AUTO FIND"
VVw1Jl  = "Custom"
VVqayx  = None
VVSVeV    = ""
VV9D2A = "Regular"
VVOOU4 = "Fixed"
VVZkLz  = "AJP_Main"
VV3uf8 = "AJP_Terminal"
VVQQU5 = "AJP_System"
VVrbou  = VV9D2A
VVa91R      = "-" * 80
VVttU7    = ("-" * 100, )
VV9phB    = ""
VVdxfj   = " && echo 'Successful' || echo 'Failed!'"
VV5AGC    = []
VVQXcS  = "Cannot continue (No Enough Memory) !"
BAR_BUTTONS_COLORS  = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
VVxGgU  = False
VVwdnn  = False
VVUJSe     = 0
VV18CB    = 1
VVVGfB    = 2
VVeIPH   = 3
VVzM1v    = 4
VVhWvd    = 5
VVgBg4 = 6
VVys1c = 7
VV0AqT  = 8
VVVQL7   = 9
VVCdJQ  = 10
VVIrDR  = 11
VVqhhs = 12
VVxwD0 = 13
VVEtuy = 14
VV2JSW    = 15
VVhLTO   = 16
VV781Z   = 17
VVYZ9k    = 18
VV2Krc    = 19
VVlUWx  = 20
VVSyAJ    = 21
VVIrLf   = 0
VVOlxm   = 1
VVumOn   = 2
def FFKoJO():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVrbou
  if VVZkLz in lst and CFG.fontPathMain.getValue(): VVrbou = VVZkLz
  else               : VVrbou = VV9D2A
  return lst
 else:
  return [VV9D2A]
def FFvu68(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVoZbD, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVv2S9, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVFuxe, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVrbou, choices=[(x,  x) for x in FFKoJO()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FF1IQX():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVtAA1  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVszgu = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVtAA1  : return 0
  elif VVszgu : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FF1IQX()
VVky8q = VVOEUE = VVfzKO = VVNNKJ = VVXz72 = VVAjMy = VVYofj = VVKnHQ = VVTVTj = VVlyaF = VVNUk6 = VVMCs3 = VVFiA5 = VVM7JM = VVJsQK = VVDIbD = ""
def FFxUJo()  : FFnmMZ(FFGqHQ())
def FFQvQ6()  : FFnmMZ(FFF8Gp())
def FFnO0o(tDict): FFnmMZ(iDumps(tDict, indent=4, sort_keys=True))
def FF6yfj(*args): FFaghx(True, True, *args)
def FFnmMZ(*args) : FFaghx(True , False , *args)
def FFNuEd(*args): FFaghx(False, False, *args)
def FFaghx(addSep=True, isArray=True, *args):
 if VVDbue:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFN4Jn(fnc):
 def VVIWXr(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFnmMZ(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVIWXr
def FFSbfY(*args):
 if VVDbue:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFNuEd("Added to : %s" % path)
def FFdy2E(txt, isAppend=True, ignoreErr=False):
 if VVDbue:
  tm = FFPu8B()
  err = ""
  if not ignoreErr:
   err = FFF8Gp()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFnmMZ(err)
  FFnmMZ("Output Log File : %s" % fileName)
def FFF8Gp():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFPu8B()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFGqHQ():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVHQcl = 0
def FFLEaq():
 global VVHQcl
 VVHQcl = iTime()
def FFC4Qh(txt=""):
 FFnmMZ(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVHQcl)).rstrip("0"), txt))
VV5AGC = []
def FFUaCm(win):
 global VV5AGC
 if not win in VV5AGC:
  VV5AGC.append(win)
def FFjVEj(*args):
 global VV5AGC
 for win in VV5AGC:
  try:
   win.close()
  except:
   pass
 VV5AGC = []
def FF62Qo():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVpLR7 = FF62Qo()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFTLrq()    : return PluginDescriptor(fnc=FFlNGb, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FF1K3v()      : return getDescriptor(FFbkTq , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFP7Do()     : return getDescriptor(FFJF7a  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFn7T7()  : return getDescriptor(FFmyM5, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFTF7A() : return getDescriptor(FFOtef , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FF7YcV()  : return getDescriptor(FFySz1 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FF5pOo()  : return getDescriptor(FFzmle  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFEkyG()    : return getDescriptor(FFH1ff, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFP7Do() , FF1K3v() , FFTLrq() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFn7T7())
  result.append(FFTF7A())
  result.append(FF7YcV())
  result.append(FF5pOo())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFEkyG())
 return result
def FFlNGb(reason, **kwargs):
 if reason == 0:
  CCd0Fn.VVZwWh()
  if "session" in kwargs:
   session = kwargs["session"]
   FF5jwm(session)
   CCBkSl(session)
def FFbkTq(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFJF7a, PLUGIN_NAME, 45)]
 else:
  return []
def FFJF7a(session, **kwargs):
 session.open(Main_Menu)
def FFmyM5(session, **kwargs):
 session.open(CC1TwY)
def FFOtef(session, **kwargs):
 session.open(CCXWrP)
def FFySz1(session, **kwargs):
 CCi57e.VVnjtb(session, isFromExternal=True)
def FFzmle(session, **kwargs):
 FFh1dN(session, reopen=True)
def FFH1ff(session, **kwargs):
 session.open(CC40v5, fncMode=CC40v5.VVxue5)
def FFiWwr():
 FFt0SB(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFn7T7(), FFTF7A(), FF7YcV(), FF5pOo() ])
 FFt0SB(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFEkyG() ])
def FFt0SB(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FF5jwm(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFDHsm, session, "lok")
 hk.actions["longCancel"]= BF(FFDHsm, session, "lesc")
 hk.actions["longRed"] = BF(FFDHsm, session, "lred")
 for k in (CCQNEy.VVQvA1, CCQNEy.VV8h1R, CCQNEy.VVYZ8R):
  hk.actions[k] = BF(CCQNEy.VVthf0, session, k)
def FFDHsm(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCXLzE.VVt6rP:
    CCXLzE.VVt6rP.close()
   if not CCi57e.VVYwjf:
    CCi57e.VVnjtb(session, isFromExternal=True)
  except:
   pass
def FFSmZ2(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFOh1m(SELF, title="", addLabel=False, addScrollLabel=False, VVGtpd=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFKNF8()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCGxqz(SELF)
 if VVGtpd:
  SELF["myMenu"] = MenuList(VVGtpd)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVyihG ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFWx6Q(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFTtOE, SELF, "0"),
  "1" : BF(FFTtOE, SELF, "1"),
  "2" : BF(FFTtOE, SELF, "2"),
  "3" : BF(FFTtOE, SELF, "3"),
  "4" : BF(FFTtOE, SELF, "4"),
  "5" : BF(FFTtOE, SELF, "5"),
  "6" : BF(FFTtOE, SELF, "6"),
  "7" : BF(FFTtOE, SELF, "7"),
  "8" : BF(FFTtOE, SELF, "8"),
  "9" : BF(FFTtOE, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFack4, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFTtOE(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVDIbD:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVDIbD + SELF.keyPressed + VVOEUE)
    txt = VVOEUE + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFgjbJ(SELF, txt)
def FFack4(SELF, tableObj, colNum, isMenu):
 FFgjbJ(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFg0L0(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVUnla(i)
     else  : SELF.VVvFsV(i)
     break
 except:
  pass
def FFKNF8():
 return ("  %s" % VV9phB)
def FFiTXq(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFg0L0(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFrqBY(color):
 return parseColor(color).argb()
def FFmnMn(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFZM4C(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFyBB(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFYHN3(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVDIbD)
 else:
  return ""
def FFvibQ(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVa91R, word, VVa91R, VVDIbD)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVa91R, word, VVa91R)
def FFj5YA(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVDIbD
def FFo3wt(color):
 if color: return "echo -e '%s' %s;" % (VVa91R, FFYHN3(VVa91R, VVNUk6))
 else : return "echo -e '%s';" % VVa91R
def FFY7Lk(title, color):
 title = "%s\n%s\n%s\n" % (VVa91R, title, VVa91R)
 return FFj5YA(title, color)
def FFeJ1R(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFfpz3(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFkWtI(callBackFunction):
 tCons = CCzBO0()
 tCons.ePopen("echo", BF(FFKkyE, callBackFunction))
def FFKkyE(callBackFunction, result, retval):
 callBackFunction()
def FFKsz7(SELF, fnc, title="Processing ...", clearMsg=True):
 FFgjbJ(SELF, title)
 tCons = CCzBO0()
 tCons.ePopen("echo", BF(FFBqWt, SELF, fnc, clearMsg))
def FFBqWt(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFgjbJ(SELF)
def FFg1NP(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVQXcS
  else       : return ""
def FFCpSv(cmd):
 txt = FFg1NP(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFfoZ6(cmd):
 lines = FFCpSv(cmd)
 if lines: return lines[0]
 else : return ""
def FFZIED(SELF, cmd):
 lines = FFCpSv(cmd)
 VVzpbP = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVzpbP.append((key, val))
  elif line:
   VVzpbP.append((line, ""))
 if VVzpbP:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF4zYj(SELF, None, header=header, VVkGEY=VVzpbP, VVsmwq=widths, VVdez8=28)
 else:
  FFm2b8(SELF, cmd)
def FFm2b8(    SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVfUaM=True, VV4T9O=VVOlxm, **kwargs)
def FFS0ir(  SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, **kwargs)
def FFpXhB(   SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVJRz4=True, VVZesh=True, VV4T9O=VVOlxm, **kwargs)
def FFftHz(  SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVJRz4=True, VVZesh=True, VV4T9O=VVumOn, **kwargs)
def FFB1pa(  SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVYK5P=True , **kwargs)
def FFEa0B(  session, cmd, **kwargs):      session.open(CCIK0j, VVxUb7=cmd, VVYK5P=True , **kwargs)
def FFZmIF( SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVOh6Q=True   , **kwargs)
def FFe3vO( SELF, cmd, **kwargs): SELF.session.open(CCIK0j, VVxUb7=cmd, VVKmA3=True  , **kwargs)
def FFN2Os(cmd):
 return cmd + " > /dev/null 2>&1"
def FFrpms(cmd):
 return cmd + " 2> /dev/null"
def FFFAUl():
 return " > /dev/null 2>&1"
def FFGxuB(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFxM0r(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFik66():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFfoZ6(cmd)
VV9WZR     = 0
VV0jlF      = 1
VV4P4m   = 2
VVtENU      = 3
VVBGkK      = 4
VVSTsT     = 5
VVKyPA     = 6
VVOwmy = 7
VV3VA9 = 8
VVLDPy = 9
VVqqpv  = 10
VVtksw     = 11
VVPMkm  = 12
VV0drk  = 13
def FFqitY(parmNum, grepTxt):
 if   parmNum == VV9WZR  : param = ["update"   , "dpkg update" ]
 elif parmNum == VV0jlF   : param = ["list"   , "apt list" ]
 elif parmNum == VV4P4m: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFik66()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFDHcv(parmNum, package):
 if   parmNum == VVtENU      : param = ["info"      , "apt show"         ]
 elif parmNum == VVBGkK      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVSTsT     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVKyPA     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVOwmy : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV3VA9 : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVLDPy : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVqqpv  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVtksw     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVPMkm  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV0drk  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFik66()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFhRck():
 result = FFfoZ6("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFDHcv(VVKyPA , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFN2Os("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFN2Os("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFYHN3(failed1, VVNUk6))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFYHN3(failed2, VVNUk6))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFYHN3(failed3, VVfzKO))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFzUYV(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFDHcv(VVKyPA , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFN2Os("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFYHN3(failed1, VVNUk6))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFYHN3(failed2, VVfzKO))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFEJE4(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCoiM6.VV06wI()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF8eQ2(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFEJE4(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFv9qK(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFkas1(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFEJE4(path, maxSize=maxSize, encLst=encLst)
  if lines: FFcTZL(SELF, lines, title=title, VV4T9O=VVOlxm, width=1600, height=1000, titleFontSize=30)
  else : FFPPOX(SELF, path, title=title)
 else:
  FFE0MG(SELF, path, title)
def FFFaGN(SELF, fName, title):
 path = VViEnD + fName
 if fileExists(path):
  txt = FFEJE4(path)
  txt = txt.replace("#W#", VVDIbD)
  txt = txt.replace("#Y#", VVMCs3)
  txt = txt.replace("#G#", VVOEUE)
  txt = txt.replace("#C#", VVFiA5)
  txt = txt.replace("#P#", VVXz72)
  FFcTZL(SELF, txt, title=title)
 else:
  FFE0MG(SELF, path, title)
def FFcNRJ(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFImxj(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFoR3R(parent)
 else    : return FFgJRr(parent)
def FFYgWN(path):
 return os.path.basename(os.path.normpath(path))
def FFkas1(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFe9uq(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    size += os.path.getsize(fp)
   except:
    pass
 return size
def FF9qnP(path):
 try:
  os.remove(path)
 except:
  pass
def FFTyUh(path):
 return os.system(FFN2Os("chattr -AacDdijsStu '%s'" % path) + ";" + FFN2Os("rm -fr '%s'" % path))
def FFoR3R(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFgJRr(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFSAAY():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVUMIB)
 paths.append(VVUMIB.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFcNRJ(ba)
 for p in list:
  p = ba + p + VVUMIB
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVna0S, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVUMIB, VVna0S , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVjba7, VViEnD = FFSAAY()
def FFmC2q():
 def VV61fd(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVfpEn   = VV61fd(CFG.backupPath, CCYEM7.VVht4P())
 VVOcbN   = VV61fd(CFG.downloadedPackagesPath, t)
 VVNa0c  = VV61fd(CFG.exportedTablesPath, t)
 VVuGba  = VV61fd(CFG.exportedPIconsPath, t)
 VV24Ca   = VV61fd(CFG.packageOutputPath, t)
 global VVFuxe
 VVFuxe = FFoR3R(CFG.backupPath.getValue())
 if VVfpEn or VV24Ca or VVOcbN or VVNa0c or VVuGba or oldMovieDownloadPath:
  configfile.save()
 return VVfpEn, VV24Ca, VVOcbN, VVNa0c, VVuGba, oldMovieDownloadPath
def FF5L7o(path):
 path = FFgJRr(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFhS09(SELF, pathList, tarFileName, addTimeStamp=True):
 VVkGEY = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVkGEY.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVkGEY.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVkGEY.append(path)
 if not VVkGEY:
  FFoFqK(SELF, "Files not found!")
 elif not pathExists(VVFuxe):
  FFoFqK(SELF, "Path not found!\n\n%s" % VVFuxe)
 else:
  VVSQJB = FFoR3R(VVFuxe)
  tarFileName = "%s%s" % (VVSQJB, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFbNWS())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVkGEY:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVa91R
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFYHN3(tarFileName, VVTVTj))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFYHN3(failed, VVTVTj))
  cmd += "fi;"
  cmd +=  sep
  FFS0ir(SELF, cmd)
def FFe04V(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFTvKK(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFTvKK(SELF["keyInfo"], "info")
def FFTvKK(barObj, fName):
 path = "%s%s%s" % (VViEnD, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFvbLy(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFEBso(satNum)
  return satName
def FFEBso(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFFJgS(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFvbLy(val)
  else  : sat = FFEBso(val)
 return sat
def FF8CMQ(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFvbLy(num)
 except:
  pass
 return sat
def FF3fLh(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFHJhk(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFNY8f(info, iServiceInformation.sServiceref)
   prov = FFNY8f(info, iServiceInformation.sProvider)
   state = str(FFNY8f(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFBTpz(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFfLGx(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFNY8f(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFbK3k(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFxa2y(refCode):
 info = FF8JD6(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFL7ha(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFyVqp(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF8JD6(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVmPIJ = eServiceCenter.getInstance()
  if VVmPIJ:
   info = VVmPIJ.info(service)
 return info
def FF4utl(SELF, refCode, VVoHm3=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFfLGx(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCWAkM()
  if pr.VVuPDh(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVMiYM(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFp8VH(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVoHm3:
   FFgCm7(SELF, isFromSession)
 try:
  VV0qUH = InfoBar.instance
  if VV0qUH:
   VViA5x = VV0qUH.servicelist
   if VViA5x:
    servRef = eServiceReference(refCode)
    VViA5x.saveChannel(servRef)
 except:
  pass
def FFp8VH(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCWAkM()
    if pr.VVuPDh(refCode, chName, decodedUrl, iptvRef):
     pr.VVMiYM(SELF, isFromSession)
def FFBTpz(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFXaBx(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFjbqo(url): return FFCX2Z(url) or FF8kdM(url)
def FFCX2Z(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FF8kdM(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFfLGx(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFgvCy(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFgvCy(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFiBxf(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFYI2o(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFqKcx(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFdPwT(txt):
 try:
  return FFYI2o(FFqKcx(txt)) == txt
 except:
  return False
def FFKQDF(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFoR3R(newPath), patt))
def FFgCm7(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCi57e.VVnjtb(session, isFromExternal=isFromSession)
 else      : FFh1dN(session, reopen=True)
def FFh1dN(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFh1dN, session), CCXLzE)
  except:
   try:
    FFV4bo(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFdW3e(refCode):
 tp = CCNm5S()
 if tp.VVVwsM(refCode) : return True
 else        : return False
def FFd0nh(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFEuF7(True)
     return True
 return False
def FFEuF7(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFbrS9()
def FFbrS9():
 VV0qUH = InfoBar.instance
 if VV0qUH:
  VViA5x = VV0qUH.servicelist
  if VViA5x:
   VViA5x.setMode()
def FFsmA3(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVmPIJ = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVmPIJ.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFsyUd():
 VVfTgd = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVGKcu = list(VVfTgd)
 return VVGKcu, VVfTgd
def FFMq43():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFcZUZ(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FF5ivG(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFtkvI():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFbNWS():
 return FFtkvI().replace(" ", "_").replace("-", "").replace(":", "")
def FF1ZBm(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFPu8B():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFg3JL(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCXWrP.VVQOpp(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCXWrP.VVbum4(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFN2Os("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFXGYs(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFLQjK(num):
 return "s" if num > 1 else ""
def FF5nM6(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFkk2r(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF1MDp(a, b):
 return (a > b) - (a < b)
def FF3S0Y(a, b):
 def VVpL4L(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVpL4L(a)
 b = VVpL4L(b)
 return (a > b) - (a < b)
def FFcCYd(mycmp):
 class CCs9ZV(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCs9ZV
def FFOPTX(SELF, message, title="", VV00AH=None):
 SELF.session.openWithCallback(VV00AH, CCyGKj, title=title, message=message, VVxOd9=True)
def FFcTZL(SELF, message, title="", VV4T9O=VVOlxm, VV00AH=None, **kwargs):
 SELF.session.openWithCallback(VV00AH, CCyGKj, title=title, message=message, VV4T9O=VV4T9O, **kwargs)
def FFoFqK(SELF, message, title="")  : FFV4bo(SELF.session, message, title)
def FFE0MG(SELF, path, title="") : FFV4bo(SELF.session, "File not found !\n\n%s" % path, title)
def FFPPOX(SELF, path, title="") : FFV4bo(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFmApx(SELF, title="")  : FFV4bo(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFV4bo(session, message, title="") : session.open(BF(CCfZkX, title=title, message=message))
def FF8cVc(SELF, VV00AH, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VV00AH, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VV00AH, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFoFqK(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFlEph(SELF, callBack_Yes, VV7fsq, callBack_No=None, title="", VV4A3A=False, VVOr97=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FF37s7, callBack_Yes, callBack_No)
         , BF(CC10W9, title=title, VV7fsq=VV7fsq, VVOr97=VVOr97, VV4A3A=VV4A3A))
def FF37s7(callBack_Yes, callBack_No, FFlEphed):
 if FFlEphed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFgjbJ(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFZM4C(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFVgyg(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFmmGR(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVP0xf = eTimer()
def FFVgyg(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FF7msJ, SELF))
 fnc = BF(FF7msJ, SELF)
 try:
  t = VVP0xf.timeout.connect(fnc)
 except:
  VVP0xf.callback.append(fnc)
 VVP0xf.start(milliSeconds, 1)
def FF7msJ(SELF):
 VVP0xf.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FF4zYj(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCxWDA, **kwargs))
  else   : win = SELF.session.open(BF(CCxWDA, **kwargs))
  FFUaCm(win)
  return win
 except:
  return None
def FFINMf(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCopPT, **kwargs))
 FFUaCm(win)
 return win
def FFPPw2(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFeMt4(SELF, **kwargs):
 SELF.session.open(CC40v5, **kwargs)
def FFsHsH(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
  except:
   pass
def FFFFBF(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFcIId(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVrbou, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFpvIL(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFcIId(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFlPq0(SELF, winSize.width(), winSize.height())
def FFlPq0(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFIyPo():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF9wzN(VVdez8):
 screenSize  = FFIyPo()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVdez8)
 return bodyFontSize
def FFcg8p(VVdez8, extraSpace):
 font = gFont(VVrbou, VVdez8)
 VVuWSd = fontRenderClass.getInstance().getLineHeight(font) or (VVdez8 * 1.25)
 return int(VVuWSd + VVuWSd * extraSpace)
def FFkttW(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0):
 screenSize = FFIyPo()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVrbou, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFcg8p(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVrbou, titleFontSize, alignLeftCenter)
 if winType in (VVUJSe, VV18CB):
  if winType == VV18CB : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVlUWx:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VV2Krc:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVrbou, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VV2JSW:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFOPTXL = b2Left2 + timeW + marginLeft
  FFOPTXW = b2Left3 - marginLeft - FFOPTXL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFOPTXL , b2Top, FFOPTXW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVhLTO:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVzM1v:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVVGfB:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVeIPH:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVrbou, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVrbou, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVCdJQ:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVrbou, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV781Z:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVrbou, fontH, alignCenter)
 elif winType in (VVIrDR, VVqhhs, VVxwD0, VVEtuy):
  if   winType == VVIrDR  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVqhhs: totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVxwD0: totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int((width - vSliderW)  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVIrDR:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVrbou, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVrbou, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVrbou, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVrbou, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVrbou, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVrbou, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  extraPar = (boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" noWrap="1" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVrbou, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVYZ9k:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVhWvd:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVys1c : align = alignLeftCenter
  elif winType == VVgBg4 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVVQL7:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVrbou
  if usefixedFont and winType == VVgBg4:
   fLst = FFKoJO()
   if   VV3uf8 in fLst and CFG.fontPathTerm.getValue(): fontName = VV3uf8
   elif VVOOU4 in fLst         : fontName = VVOOU4
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVdez8 = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVrbou, VVdez8, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVrbou, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, BAR_BUTTONS_COLORS[i], VVrbou, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVgBg4:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, BAR_BUTTONS_COLORS[i], VVrbou, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVn2YC = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVJjPN)
  VVGtpd = []
  if VVkqaS:
   VVGtpd.append(("-- MY TEST --", "myTest" ))
  VVGtpd.append(("File Manager"  , "fMan" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("IPTV"    , "iptv" ))
  VVGtpd.append(("Movies Browser" , "movie" ))
  VVGtpd.append(("Services/Channels", "chan" ))
  VVGtpd.append(("PIcons"   , "picon" ))
  VVGtpd.append(("EPG"    , "epg"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Terminal"   , "term" ))
  VVGtpd.append(("SoftCam"   , "soft" ))
  VVGtpd.append(("Plugins"   , "plug" ))
  VVGtpd.append(("Backup & Restore" , "bakup" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Date/Time"  , "date" ))
  VVGtpd.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVGtpd):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVGtpd[ndx] = tuple(item)
  FFOh1m(self, title=self.Title, VVGtpd=VVGtpd)
  FFiTXq(self["keyRed"] , "Exit")
  FFiTXq(self["keyGreen"] , "Settings")
  FFiTXq(self["keyYellow"], "Dev. Info.")
  FFiTXq(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VV3nzY      ,
   "yellow": self.VVQWGE      ,
   "blue" : self.VVZZ6q     ,
   "info" : BF(FFKsz7, self, self.VVBLKu) ,
   "text" : self.VViYSs      ,
   "menu" : self.VVgm0i    ,
   "0"  : BF(self.VVQGVU, 0)   ,
   "1"  : BF(self.VVC3et, "fMan")   ,
   "2"  : BF(self.VVC3et, "iptv")   ,
   "3"  : BF(self.VVC3et, "movie")   ,
   "4"  : BF(self.VVC3et, "chan")   ,
   "5"  : BF(self.VVC3et, "picon")   ,
   "6"  : BF(self.VVC3et, "epg")   ,
   "7"  : BF(self.VVC3et, "term")   ,
   "8"  : BF(self.VVC3et, "soft")   ,
   "9"  : BF(self.VVC3et, "plug")   ,
   "last" : BF(self.VVC3et, "bakup")   ,
   "next" : BF(self.VVC3et, "date")
  })
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
  global VVxGgU, VVwdnn
  VVxGgU = VVwdnn = False
 def VVyihG(self):
  self.VVC3et(self["myMenu"].l.getCurrentSelection()[1])
 def VVC3et(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VV9phB
   VV9phB = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVpqh8()
   elif item == "fMan"  : self.session.open(CC1TwY)
   elif item == "iptv"  : self.session.open(CCXWrP)
   elif item == "movie" : FFKsz7(self, BF(CCYzkG.VVQHL6, self))
   elif item == "chan"  : self.session.open(CC5MnI)
   elif item == "picon" : self.VVvsOu()
   elif item == "epg"  : self.session.open(CC8SZQ)
   elif item == "term"  : self.session.open(CCi2xg)
   elif item == "soft"  : self.session.open(CCfMYX)
   elif item == "plug"  : self.session.open(CCTrGQ)
   elif item == "bakup" : self.session.open(CCrP3q)
   elif item == "date"  : self.session.open(CCj0a1)
   elif item == "net"  : self.session.open(CC7wW6)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
  FFsHsH(self)
  FFe04V(self)
  VVfpEn, VV24Ca, VVOcbN, VVNa0c, VVuGba, oldMovieDownloadPath = FFmC2q()
  if VVfpEn or VV24Ca or VVOcbN or VVNa0c or VVuGba or oldMovieDownloadPath:
   VVy3eN = lambda path, subj: "%s:\n%s\n\n" % (subj, FFj5YA(path, VVNNKJ)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVy3eN(VVfpEn   , "Backup/Restore Path"    )
   txt += VVy3eN(VV24Ca  , "Created Package Files (IPK/DEB)" )
   txt += VVy3eN(VVOcbN  , "Download Packages (from feeds)" )
   txt += VVy3eN(VVNa0c , "Exported Tables"     )
   txt += VVy3eN(VVuGba , "Exported PIcons"     )
   txt += VVy3eN(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFcTZL(self, txt, title="Settings Paths")
  self.VVaTR9()
  if (EASY_MODE or VVDbue or VVkqaS):
   FFZM4C(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFgjbJ(self, "Welcome", 300)
  FFkWtI(self.VVKKqv)
 def VVKKqv(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCYEM7.VVGfl8()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  os.system(FFN2Os("rm /tmp/ajp_*"))
  global VVxGgU, VVwdnn
  VVxGgU = VVwdnn = False
 def VVQGVU(self, digit):
  self.VVn2YC += str(digit)
  ln = len(self.VVn2YC)
  global VVxGgU
  if ln == 4:
   if self.VVn2YC == "0" * ln:
    VVxGgU = True
    FFZM4C(self["myTitle"], "#11805040")
   else:
    self.VVn2YC = "x"
 def VViYSs(self):
  self.VVn2YC += "t"
  if self.VVn2YC == "0" * 4 + "t" * 2:
   global VVwdnn
   VVwdnn = True
   FFZM4C(self["myTitle"], "#dd5588")
 def VVvsOu(self):
  found = False
  pPath = CCMEuJ.VVaKDV()
  if pathExists(pPath):
   for fName, fType in CCMEuJ.VV7Acb(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCMEuJ)
  else:
   VVGtpd = []
   VVGtpd.append(("PIcons Tools" , "CCMEuJ" ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(CCMEuJ.VV4Nbq())
   VVGtpd.append(VVttU7)
   VVGtpd += CCMEuJ.VV7s59()
   FFINMf(self, self.VVorCI, VVGtpd=VVGtpd)
 def VVorCI(self, item=None):
  if item:
   if   item == "CCMEuJ"   : self.session.open(CCMEuJ)
   elif item == "VV4bWN"  : CCMEuJ.VV4bWN(self)
   elif item == "VVQKS2"  : CCMEuJ.VVQKS2(self)
   elif item == "findPiconBrokenSymLinks" : CCMEuJ.VVeuB5(self, True)
   elif item == "FindAllBrokenSymLinks" : CCMEuJ.VVeuB5(self, False)
 def VVBLKu(self):
  changeLogFile = VViEnD + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF8eQ2(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFj5YA("\n%s\n%s\n%s" % (VVa91R, line, VVa91R), VVNUk6, VVDIbD)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFj5YA(line, VVOEUE, VVDIbD)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFcTZL(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVJjPN, PLUGIN_DESCRIPTION), VVdez8=28, width=1600, height=1000)
 def VVgm0i(self):
  VVGtpd = []
  VVGtpd.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Keys Help"     , "hlp" ))
  FFINMf(self, self.VVIvlW, VVGtpd=VVGtpd, width=650, title="Options")
 def VVIvlW(self, item=None):
  if item:
   if   item == "libr" : FFKsz7(self, BF(self.VVQD5Z))
   elif item == "hlp" : FFFaGN(self, "_help_main", "Main Page (Keys Help)")
 def VV3nzY(self) : self.session.open(CCYEM7)
 def VVQWGE(self) : self.session.open(CCB7Ee)
 def VVZZ6q(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVlyaF, VVNNKJ, VVMCs3, VVAjMy
  VVGtpd = []
  VVGtpd.append((c1 + "Change Title Colors"   , "title"  ))
  VVGtpd.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVGtpd.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVGtpd.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVGtpd.append((c2 + "Reset Colors"    , "resetColor" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVGtpd.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c4 + "Change System Font"    , "sysFont"  ))
  FFINMf(self, BF(self.VV0gLR, title), VVGtpd=VVGtpd, width=600, title=title)
 def VV0gLR(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVbs64()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVomF0, tDict, item), CCPDAn, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFlEph(self, self.VVOHj5, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVwH4s(VVZkLz  )
   elif item == "termFont"  : self.VVwH4s(VV3uf8)
   elif item == "sysFont"  : self.VVwH4s(VVQQU5  )
 def VVQD5Z(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVzpbP, pkgs = self.VVAuBH()
  VVtaAK = ("Install", BF(self.VVkD1k, title, pkgs)  , [])
  VVyNdP  = ("Update Sys. Packages", self.VV8eGt , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVZq8i = (LEFT  , CENTER , LEFT  )
  VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, width=1350, VVtaAK=VVtaAK, VVyNdP=VVyNdP, VVRaJ8="#00ffffaa", VVwTA1=1)
 def VVkD1k(self, Title, pkgs, VVeDC2, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVy8bA, VVeDC2)
   item = colList[0]
   if   item == "requests" : CC7Fot.VVaSI5(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCQNEy.VVHaRf(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFB1pa(self, FFhRck(), VVRBrK=cbFnc)
   elif item in pkgs  : FFB1pa(self, FFzUYV(item, item, item.capitalize()), VVRBrK=cbFnc)
  else:
   FFgjbJ(VVeDC2, "Already installed.", 700, isGrn=True)
 def VV8eGt(self, VVeDC2, title, txt, colList):
  CCTrGQ.VV1LMJ(self)
 def VVy8bA(self, VVeDC2):
  VVzpbP, pkgs = self.VVAuBH()
  VVeDC2.VVji2V(VVzpbP[VVeDC2.VVUy0w()])
 def VVAuBH(self):
  tDict = {}
  path = VViEnD + "_sup_lib"
  if fileExists(path):
   for line in FF8eQ2(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVy3eN(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFj5YA("Installed", VVTVTj), txt)
   else : return (lib, FFj5YA("Not installed", VVfzKO), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVzpbP = []
  VVzpbP.append(VVy3eN("requests", CC7Fot.VVaSI5(self, install=False)))
  VVzpbP.append(VVy3eN("Imaging" , CCQNEy.VVHaRf(self, "", False, install=False)))
  VVzpbP.append(VVy3eN("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VVzpbP.append(VVy3eN(item, FFGxuB(item)))
  VVzpbP.sort(key=lambda x: x[0].lower())
  return VVzpbP, pkgs
 def VVl9ne(self):
  return VVFuxe + "ajpanel_colors"
 def VVbs64(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVl9ne()
  if fileExists(p):
   txt = FFEJE4(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVomF0(self, tDict, item, fg, bg):
  if fg:
   self.VVPDaJ(item, fg)
   self.VV0Fd0(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVXUSL(tDict)
 def VVXUSL(self, tDict):
   p = self.VVl9ne()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVPDaJ(self, item, fg):
  if   item == "title" : FFmnMn(self["myTitle"], fg)
  elif item == "body"  :
   FFmnMn(self["myMenu"], fg)
   FFmnMn(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFmnMn(self[item], fg)
 def VV0Fd0(self, item, bg):
  if   item == "title" : FFZM4C(self["myTitle"], bg)
  elif item == "body"  :
   FFZM4C(self["myMenu"], bg)
   FFZM4C(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFZM4C(self["myBar"], bg)
 def VVOHj5(self):
  os.system(FFN2Os("rm %s" % self.VVl9ne()))
  self.close()
 def VVaTR9(self):
  tDict = self.VVbs64()
  for item in ("title", "body", "cursor", "bar"):
   self.VVEvvH(tDict, item)
 def VVEvvH(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVPDaJ(name, fg)
  if bg: self.VV0Fd0(name, bg)
 def VVwH4s(self, which):
  if   which == VVZkLz  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VV3uf8 : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVQQU5  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCc2Gw.VVsl6K(self, "Change %s Font" % title, defFnt, rest, BF(self.VVO8Tr, which))
 def VVO8Tr(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVZkLz  : FFSmZ2(CFG.fontPathMain, path)
   elif which == VV3uf8: FFSmZ2(CFG.fontPathTerm, path)
   elif which == VVQQU5  : FFSmZ2(CFG.fontPathSys , path)
   err = Main_Menu.VVb5kZ(which)
   if err          : FFoFqK(self, err, title=title)
   elif which == VVZkLz   : self.close()
   elif which == VV3uf8  : FFgjbJ(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVQQU5 and path: FFgjbJ(self, "System font applied", 1500, isGrn=True)
   elif which == VVQQU5   : FFlEph(self, BF(Main_Menu.VVOh6Q, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVOh6Q(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVb5kZ(name):
  if   name == VVZkLz : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VV3uf8: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVQQU5 : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFKoJO()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVQQU5:
   nameLst = []
   for nm in FFKoJO():
    if not nm in (VVZkLz, VV3uf8):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFvu68(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFKoJO()
  else    : return "Could not add font"
 def VVpqh8(self):
  CCxYG1.VVZL7c(self)
class CC7wW6(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVFuxe, "ajpanel_network")
  c1, c2 = VVMCs3, VVlyaF
  VVGtpd = []
  VVGtpd.append((c1 + "Network Devices"     , "dev" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Network Scanner (ping)"    , "ping"))
  VVGtpd.append(("Port Scanner (scan for famous ports)" , "port"))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c2 + "Check Internet Connection"  , "intr"))
  FFOh1m(self, title="Network Tools", VVGtpd=VVGtpd)
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFKsz7(self, self.VV7a3p, title="REading Devices ...")
  elif item == "ping" : FFKsz7(self, self.VVKqcm, title="Scanning ...")
  elif item == "port" : CCcrQv.VVXtie(self, self.VVBvgX, title="Select host to scan")
  elif item == "intr" : self.session.open(CCSG3J)
 def VV7a3p(self, canCencel=False):
  title = "Network Devices"
  VVzpbP = self.VVbzyW()
  if VVzpbP:
   bg = "#0a223333"
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVsgQj = BF(self.VVC8yn, canCencel)
   VVLseV  = ("Start FTP"   , self.VVx6mT    , [])
   VV0q2u = ("Entry Options"  , self.VVrElp  , [])
   VVyNdP = ("Scan for Devices" , self.VVygpM , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVZq8i = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, width=1500, height=900, VVsmwq=widths, VVdez8=28, VVLseV=VVLseV, VVsgQj=VVsgQj, VV0q2u=VV0q2u, VVyNdP=VVyNdP
       , VVghW2=bg, VVlnMM=bg, VValS2=bg, VVRaJ8="#11ffff00", VVKJ4V="#11220000", VVEwGL="#00333333", VVtDKG="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVeDC2.VVvFsV(ndx)
  else:
   FFlEph(self, BF(FFKsz7, self, BF(self.VVxyVg, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVC8yn, canCencel), title=title)
 def VVrElp(self, VVeDC2, title, txt, colList):
  VVGtpd = []
  VVGtpd.append(("Change Username"   , "user"))
  VVGtpd.append(("Change Password"   , "pass"))
  VVGtpd.append(("Change Remarks"   , "rem"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Remove Selected Server" , "del"))
  FFINMf(self, BF(self.VVZ80N, VVeDC2), VVGtpd=VVGtpd, title="Entry Options")
 def VVZ80N(self, VVeDC2, item=None):
  if item:
   if   item == "user" : self.VVEEBB("u", VVeDC2)
   elif item == "pass" : self.VVEEBB("p", VVeDC2)
   elif item == "rem" : self.VVEEBB("r", VVeDC2)
   elif item == "del" : FFlEph(self, BF(FFKsz7, self, BF(self.VVee9M, VVeDC2), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVC8yn(self, canCencel, VVeDC2=None):
  if VVeDC2: VVeDC2.cancel()
  if canCencel : self.close()
 def VVx6mT(self, VVeDC2, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFSmZ2(CFG.lastNetworkDevice, VVeDC2.VVUy0w())
  self.session.openWithCallback(BF(self.VVwCWR, entry, VVeDC2), CCQEUH, entry)
 def VVwCWR(self, entry, VVeDC2, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVf8IX("d", newPath, ip, u, p, path, rem)
    self.VVQLRB(VVeDC2)
 def VVygpM(self, VVeDC2, title, txt, colList):
  FFKsz7(VVeDC2, BF(self.VVxyVg, mainTableInst=VVeDC2), title="Scanning Network ...")
 def VVxyVg(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCcrQv.VV8bXw(CCcrQv.VVgXd3)
  if err:
   FFoFqK(self, err, title=title)
   return
  telLst, err = CCcrQv.VV8bXw(CCcrQv.VVcZVT)
  if err:
   FFoFqK(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVyq6h(p1, p2): return FF3S0Y(p1[0], p2[0])
   lst.sort(key=FFcCYd(VVyq6h))
   bg = "#0a202020"
   VVsgQj = BF(self.VVC8yn, canCencel)
   VVLseV  = ("Add to Devices" , BF(self.VV2hB9, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVZq8i = (LEFT   , CENTER   , CENTER  )
   FF4zYj(self, None, title=title, header=header, VVkGEY=lst, VVZq8i=VVZq8i, VVsmwq=widths, width=1200, VVdez8=30, VVLseV=VVLseV, VVsgQj=VVsgQj, VVwTA1=2
     , VVghW2=bg, VVlnMM=bg, VValS2=bg, VVRaJ8="#11ffffaa", VVKJ4V="#0a225555", VVtDKG="#11403040")
  else:
   FFoFqK(self, "No devices found !", title=title)
 def VVKqcm(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCcrQv.VV8bXw(-1)
  if err:
   FFoFqK(self, err, title=title)
  elif lst:
   def VVyq6h(p1, p2): return FF3S0Y(p1[0], p2[0])
   lst.sort(key=FFcCYd(VVyq6h))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVZq8i = (LEFT   , LEFT   )
   FF4zYj(self, None, title=title, header=header, VVkGEY=lst, VVZq8i=VVZq8i, VVsmwq=widths, width=1000, height=700, VVdez8=30
     , VVghW2=bg, VVlnMM=bg, VValS2=bg, VVRaJ8="#11ffffaa", VVKJ4V="#0a225555", VVtDKG="#11403040")
  else:
   FFoFqK(self, "Network scanning failed !", title=title)
 def VVBvgX(self, ip=None):
  if ip:
   FFKsz7(self, BF(self.VVs4pW, ip), title="Scanning %s" % ip)
 def VVs4pW(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCcrQv.VVSOrl(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCcrQv.VVuwTA(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFcTZL(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVbzyW(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFEJE4(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVyq6h(p1, p2): return FF3S0Y(p1[0], p2[0])
  tLst.sort(key=FFcCYd(VVyq6h))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVbzyW(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFEJE4(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVyq6h(p1, p2): return FF3S0Y(p1[0], p2[0])
  tLst.sort(key=FFcCYd(VVyq6h))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VV2hB9(self, mainTableInst, canCencel, VVeDC2, title, txt, colList):
  ip, mac, typ = VVeDC2.VVMpUH(VVeDC2.VVUy0w())
  if "Own" in ip:
   FFgjbJ(VVeDC2, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVbzyW():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     CC3pKJ.VVvT3F(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVyUQJ(ip, u, p, path, rem))
   if mainTableInst: self.VVQLRB(mainTableInst, [ip, u, p, path, rem])
   else   : self.VV7a3p(canCencel)
   VVeDC2.cancel()
 def VVyUQJ(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVee9M(self, VVeDC2):
  num, ip, u, p, path, rem = VVeDC2.VVMpUH(VVeDC2.VVUy0w())
  lst = self.VVbzyW()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVyUQJ(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVQLRB(VVeDC2)
  else:
   VVeDC2.cancel()
 def VVEEBB(self, col, VVeDC2):
  num, ip, u, p, path, rem = VVeDC2.VVMpUH(VVeDC2.VVUy0w())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FF8cVc(self, BF(self.VVEWfb, col, orig, VVeDC2, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVEWfb(self, col, orig, VVeDC2, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFgjbJ(VVeDC2, "No change", 1500)
   elif not newTxt and col == "u":
    FFgjbJ(VVeDC2, "No user !", 2000)
   else:
    self.VVf8IX(col, newTxt, ip, u, p, path, rem)
    self.VVQLRB(VVeDC2)
 def VVf8IX(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVbzyW()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVyUQJ(ip1, u1, p1, path1, rem1))
 def VVQLRB(self, VVeDC2, newEntry=None):
  VVzpbP = self.VVbzyW()
  if VVzpbP : VVeDC2.VV6IAT(VVzpbP, tableRefreshCB=BF(self.VViFhK, newEntry))
  else  : VVeDC2.cancel()
 def VViFhK(self, newEntry, VVeDC2, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVeDC2.VVmbqa()):
    if row[1:] == newEntry:
     VVeDC2.VVvFsV(ndx)
 def VVC8yn(self, canCencel, VVeDC2=None):
  if VVeDC2: VVeDC2.cancel()
  if canCencel : self.close()
class CCcrQv():
 VVgXd3 = 21
 VVcZVT = 23
 def __init__(self):
  self.VVG8G5()
 def VVG8G5(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVYF2c(self, ip, User, Pass, timeout=5):
  myIp = CCcrQv.VVO2A3()
  if ip != myIp:
   if CCcrQv.VVuwTA(ip, CCcrQv.VVgXd3):
    self.VVG8G5()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to to your Device-IP:\n\n%s" % ip
  return err
 def VVgYpW(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVcAlV(self):
  try:
   return self.ftp.sendcmd("NOOP")
   return True
  except:
   return False
 def VVEDEH(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVY0KE(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVI4NX(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVtjg0(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVFDzj(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVtjg0()
   if self.VVI4NX(path) : typ = "d"
   else      : typ = "b"
   self.VVI4NX(curDir)
   return typ
 def VVVAXc(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVI4NX(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VV1uxv(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVJnxC(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except Exception as e:
   return False
 def VVabnH(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVXNeO(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVVAXc(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FF9qnP(locFile)
   return "", sz, str(e)
 def VVoVvQ(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVG8G5()
 @staticmethod
 def VVUzk5():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVO2A3():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VV5ler():
  myIp = CCcrQv.VVO2A3()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVL5kx():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFfoZ6("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVFYJJ(port=-1):
  lst = []
  def VV7pWk(ip):
   if port > -1: ok = CCcrQv.VVuwTA(ip, port)
   else  : ok = CCcrQv.VVSOrl(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCcrQv.VV5ler()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VV7pWk, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VV8bXw(port):
  myIp = CCcrQv.VVO2A3()
  myGw = CCcrQv.VVL5kx()
  tDict = { myIp: CCcrQv.VVUzk5() }
  devLst, err = CCcrQv.VVFYJJ(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFg1NP("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVMCs3
    elif key == myGw: txt = " %s Gateway" % VVMCs3
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVSOrl(ip):
  return True if os.system(FFN2Os("ping -W1 -q -c1 %s" % ip)) == 0 else False
 @staticmethod
 def VVuwTA(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVTBsl(ip="1.1.1.1", timeout=1):
  if CCcrQv.VVuwTA(ip, 53, timeout):
   return True
  if CCcrQv.VVSOrl(ip):
   return True
  return os.system(FFN2Os("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
 @staticmethod
 def VVXtie(SELF, okFnc, title):
  baseIp = CCcrQv.VV5ler()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFINMf(SELF, okFnc, VVGtpd=lst, width=600, title=title, VVghW2="#222222", VVlnMM="#222222")
class CCQEUH(Screen, CCcrQv):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFkttW(VVUJSe, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVdez8  = self.skinParam["bodyFontSize"]
  self.VVuWSd  = self.skinParam["bodyLineH"]
  self.VV0ne0  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CC8VbN.VVX09T("fil")
  self.png_dir  = CC8VbN.VVX09T("dir")
  self.png_dirup  = CC8VbN.VVX09T("dirup")
  self.png_slwfil  = CC8VbN.VVX09T("slwfil")
  self.png_slbfil  = CC8VbN.VVX09T("slbfil")
  self.png_slwdir  = CC8VbN.VVX09T("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCcrQv.__init__(self)
  VVGtpd = [("Item-%d" % x,) for x in range(50)]
  FFOh1m(self, title=self.Title, VVGtpd=VVGtpd)
  FFiTXq(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVGtpd, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVrbou, self.VVdez8))
  self["myMenu"].l.setItemHeight(self.VVuWSd)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVc1BV, True) ,
   "ok" : self.VVyihG    ,
   "cancel": self.VVc1BV    ,
   "menu" : self.VV3Tzb   ,
   "info" : self.VVZf37  ,
   "pageUp": self.VVZ19R    ,
   "chanUp": self.VVZ19R
  })
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVMCKd)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
  FFsHsH(self)
  FFe04V(self)
  FFZM4C(self["keyBlue"], "#11333333")
  FFKsz7(self, self.VVjlGj, title="Connecting ...")
 def VVjlGj(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVYF2c(ip, u, p)
  if err:
   FFoFqK(self, err, title=self.Title)
   FFiTXq(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFiTXq(self["keyBlue"], self.ftpIp)
   if not self.VVI4NX(path):
    path = "/"
   self.VV2ti6(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVcAlV():
   self.VVoVvQ()
 def VVyihG(self):
  if self.VVWZdJ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VV2ti6(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVZ19R()
    else         : self.VVeilo(os.path.join(self.curDir, name))
 def VVc1BV(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVZ19R()
 def VVWZdJ(self):
  if self.VVcAlV():
   return True
  else:
   FFoFqK(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVeilo(self, path):
  cat = self.VVtnYB(path)
  if cat in ("pic"):
   FFKsz7(self, BF(self.VVOSiq, path))
  elif cat in ("mov", "mus"):
   if CCXWrP.VV1hwS("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFKsz7(self, BF(CC1TwY.VV9CaF, self, url, rType=rType), title="Playing Media ...")
 def VVOSiq(self, path):
  locFile, size, err = self.VVXNeO(path)
  if err: FFoFqK(self, err, title="View Picture File")
  else  : CC9YFX.VVqn2L(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FF9qnP))
 def VVMCKd(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CC8VbN.VVusuX else sel[0][0])
  else  : title=  VVfzKO + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVZ19R(self):
  if self.VVWZdJ():
   lastPart = FFYgWN(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VV2ti6(parentDir, lastPart, "d")
 def VV2ti6(self, Dir, moveTo="", moveToType=""):
  FFKsz7(self, BF(self.VVTRqh, Dir, moveTo, moveToType))
 def VVTRqh(self, Dir, moveTo, moveToType):
  files, err = self.VVY0KE(Dir, isLong=True)
  self.curDir = self.VVtjg0() or "/"
  self.VVsD4P(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVsD4P(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVMd62(CC8VbN.VVusuX, CC8VbN.VVusuX, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVFDzj(target)
    color = VVfzKO if targetState == "b" else VVTVTj
    origName = name + VVNUk6 + linkSep + color + " "+ target
   self.list.append(self.VVMd62(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVMd62(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVtnYB(name)
    if cat: png = LoadPixmap("%s%s.png" % (VViEnD, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CC8VbN.VVusuX: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVuWSd + 10, 0, self.VV0ne0, self.VVuWSd, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVpLR7: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVuWSd-4, self.VVuWSd-4, png, None, None, VVpLR7))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVuWSd-4, self.VVuWSd-4, png, None, None))
  return tableRow
 def VVtnYB(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CC8VbN.VVB1kx().items():
    if ext in lst:
     return cat
  return ""
 def VV3Tzb(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CC8VbN.VVusuX
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VV2Je2(titl, ref, chk, color=""):
   if chk: return VVGtpd.append((color + titl, ref))
   else  : return VVGtpd.append((titl, ))
  VVGtpd = []
  VV2Je2("Properties", "VVZf37", not isTop)
  c = VVMCs3
  VVGtpd.append(VVttU7)
  VV2Je2("Download Selected File ..."    , "FFg3JLFromServer", isFile, c)
  VV2Je2("Upload a Local File to Remote Server ...", "VVjZC2" , True  , c)
  VVGtpd.append(VVttU7)
  VV2Je2("Create new directory", "VV1iNY", True)
  VV2Je2("Rename", "VVECsg", not isTop)
  VV2Je2("DELETE", "VVnxzn", not isTop, VVXz72)
  VVGtpd.append(VVttU7)
  VV2Je2("FTP Server Information", "VV43Ya", True)
  VVGtpd.append(VVttU7)
  VV2Je2("Refresh File List", "refresh", True)
  FFINMf(self, self.VVsNIM, VVGtpd=VVGtpd, title="Options")
 def VVsNIM(self, item=None):
  if item:
   if   item == "VVZf37"     : self.VVZf37()
   elif item == "FFg3JLFromServer"   : self.FFg3JLFromServer()
   elif item == "VVjZC2"   : self.VVjZC2()
   elif item == "VV1iNY"   : self.VV1iNY()
   elif item == "VVECsg"   : self.VVECsg()
   elif item == "VVnxzn"   : self.VVnxzn()
   elif item == "VV43Ya"    : self.VV43Ya()
   elif item == "refresh"and self.VVWZdJ() : self.VV2ti6(self.curDir)
 def VVZf37(self):
  if self.VVWZdJ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFj5YA("Path", VVMCs3), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVVAXc(path)
    if sz > -1: txt += "Size\t: %s" % CC1TwY.VVBRyA(sz)
   else:
    txt = "Nothing selected"
   FFcTZL(self, txt, title="Properties")
 def VV43Ya(self):
  if self.VVWZdJ():
   Sys  = self.VVgYpW() or " -"
   txt = "%s\n  %s\n\n" % (FFj5YA("System:", VVMCs3), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVEDEH() or " -"
   txt += "%s\n" % (FFj5YA("Status:", VVMCs3))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFcTZL(self, txt, title="FTP Server Information")
 def VV1iNY(self, name=""):
  if self.VVWZdJ():
   title = "Add New Directory"
   FF8cVc(self, BF(self.VV2fAs, title), defaultText=name, title=title, message="Enter Directory name")
 def VV2fAs(self, title, name):
  if name and name.strip():
   if self.VV1uxv(name) : self.VV2ti6(self.curDir, name, "d")
   else     : FFoFqK(self, "Failed to create : %s" % name, title)
 def VVECsg(self):
  if self.VVWZdJ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FF8cVc(self, BF(self.VVDsbp, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVDsbp(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVabnH(name, newName.strip()) : self.VV2ti6(self.curDir, newName, flag)
   else          : FFoFqK(self, "Failed to rename to : %s" % newName, title)
 def VVnxzn(self):
  if self.VVWZdJ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFlEph(self, BF(FFKsz7, self, BF(self.VV6s59, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VV6s59(self, name, flag):
  if self.VVJnxC(name, flag) : self.VV2ti6(self.curDir)
  else         : FFoFqK(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFg3JLFromServer(self):
  if self.VVWZdJ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVVAXc(remFile)
    if size == -1:
     FFoFqK(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVFuxe
     self.session.openWithCallback(BF(self.VVq15z, title, remFile, name, size), BF(CC1TwY, mode=CC1TwY.VVtIla, VVZmYA="Download here", VViJ7i=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVq15z(self, title, remFile, name, size, locPath):
  if locPath:
   FFSmZ2(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVFMlW, remFile, size, locFile)
       , VV00AH = BF(self.VVafCY, remFile, size, locFile))
 def VVFMlW(self, remFile, size, locFile, VVfBS1):
  VVfBS1.VV9WKz(size)
  VVfBS1.VVcdNf = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVEjbv(data):
     if not VVfBS1 or VVfBS1.isCancelled:
      return
     locFileObj.write(data)
     VVfBS1.VVSxQe(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVEjbv)
   except Exception as e:
    VVfBS1.VVcdNf = str(e)
 def VVafCY(self, remFile, size, locFile, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVcdNf:
   FFoFqK(self, "%s\n\nftp:/%s" % (VVcdNf, remFile), title="Download Error")
   delF = True
  elif not VV9pDl:
   FFoFqK(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFkas1(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFOPTX(self, txt, title=title)
   else:
    FFoFqK(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FF9qnP(locFile)
 def VVjZC2(self):
  if self.VVWZdJ():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVFuxe
   self.session.openWithCallback(self.VVCtP5, BF(CC1TwY, VVZmYA="Upload selected file", VViJ7i=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVCtP5(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFSmZ2(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFkas1(locFile)
   if size == -1:
    FFoFqK(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VV77oG, locFile, size, remFile)
        , VV00AH = BF(self.VVH5HB, locFile, size, remFile))
 def VV77oG(self, locFile, size, remFile, VVfBS1):
  VVfBS1.VV9WKz(size)
  VVfBS1.VVcdNf = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVL15D(data):
     if not VVfBS1 or VVfBS1.isCancelled:
      return
     VVfBS1.VVSxQe(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVL15D)
   except Exception as e:
    VVfBS1.VVcdNf = str(e)
 def VVH5HB(self, locFile, size, remFile, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  delF = False
  if VVcdNf:
   FFoFqK(self, "%s\n\nftp:/%s" % (VVcdNf, remFile), title="Upload Error")
   delF = True
  elif not VV9pDl:
   FFoFqK(self, "Upload cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFkas1(locFile):
    txt = "Successfully uploaded to:\n\n%s" % remFile
    FFOPTX(self, txt, title=title)
    self.VV2ti6(self.curDir)
   else:
    FFoFqK(self, "Incorrect uploaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   self.VVjQA5(remFile)
class CCQNEy():
 VVQvA1  = "all"
 VV8h1R = "vid"
 VVYZ8R  = "osd"
 @staticmethod
 def VVthf0(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFGxuB("grab"):
    winShown = session.current_dialog.shown
    if k == CCQNEy.VV8h1R and winShown: session.current_dialog.hide()
    FFkWtI(BF(CCQNEy.VVgRcR, title, session, k, winShown))
   else:
    FFV4bo(session, "No Grab command !", title=title)
 @staticmethod
 def VVgRcR(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCQNEy.VVYZ8R:
   if not winShown:
    FFV4bo(session, "No Window to capture !", title=title)
    return
   if not CCQNEy.VVHaRf(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCQNEy.VV75zN(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFV4bo(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFoR3R(CFG.exportedPIconsPath.getValue()), fTitle, FFbNWS(), ext)
  res = os.system(FFrpms("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCQNEy.VV8h1R and winShown:
   session.current_dialog.show()
  elif k == CCQNEy.VVYZ8R:
   ok = CCQNEy.VV8OYX(path, x, y, w, h)
   if not ok:
    FF9qnP(path)
    FFV4bo(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CC9YFX, title=path, VVVTIX=path))
  else       : FFV4bo(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVHaRf(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFlEph(SELF, BF(CCQNEy.VVBgJ5, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVBgJ5(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFEa0B, VVRBrK=cbFnc)
  else    : fnc = BF(FFB1pa , VVRBrK=cbFnc)
  fnc(SELF, FFDHcv(VVKyPA, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VV75zN(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VV8OYX(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFIyPo()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFkk2r(x , 0, scrW, 0, w)
     y  = FFkk2r(y , 0, scrH, 0, h)
     x1 = FFkk2r(x1, 0, scrW, 0, w)
     y1 = FFkk2r(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVoDz0(path):
  size = FFkas1(path)
  sizeTxt = CC1TwY.VVBRyA(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCc2Gw(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFkttW(VVUJSe, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFj5YA(" (Requires GUI Restart)", VVAjMy) if withRestart else ""
  VVGtpd = []
  for path in self.fontsList:
   VVGtpd.append((os.path.splitext(os.path.basename(path))[0], path))
  VVGtpd.sort(key=lambda x: x[0].lower())
  VVGtpd.insert(0, VVttU7)
  VVGtpd.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVGtpd):
    if len(item) == 2 and item[1] == self.defFnt:
     VVGtpd[ndx] = (VVTVTj + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVGtpd[curIndex] = (VVTVTj + VVGtpd[curIndex][0], VVGtpd[curIndex][1])
  FFOh1m(self, VVGtpd=VVGtpd, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
  self["myMenu"].onSelectionChanged.append(self.VVBZNb)
  self["myBar"].setText(self.VV1MbX())
  self["myBar"].instance.setHAlign(1)
  self.VVBZNb()
 def VVyihG(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVBZNb(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFvu68(path, fnt, isRepl=1)
  else:
   fnt = VV9D2A
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VV1MbX(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVsl6K(SELF, title, defFnt, rest, VV00AH):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFKQDF(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VV00AH, CCc2Gw, title, fontsList, defFnt, rest)
  else  : FFoFqK(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CC1Wvt(Screen):
 def __init__(self, session, path, VVGtpd, title):
  self.skin, self.skinParam = FFkttW(VVUJSe, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFOh1m(self, VVGtpd=VVGtpd, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyihG   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVELDM,
   "chanUp" : self.VVELDM,
   "pageDown" : self.VVMk08 ,
   "chanDown" : self.VVMk08 ,
  }, -1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
  FFZM4C(self["myLabelFrm"], "#11110000")
  FFZM4C(self["myLabelTit"], "#11663322")
  FFZM4C(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VV1IMX)
  self.VV1IMX()
 def VV1IMX(self):
  if fileExists(self.path): txt = FFEJE4(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVyihG(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVELDM(self) : self["myMenu"].moveToIndex(0)
 def VVMk08(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCoiM6():
 @staticmethod
 def VV06wI():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVvzf6(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FF4zYj(SELF, None, VVkGEY=lst, VVdez8=30, VVwTA1=1)
 @staticmethod
 def VVfJOY(path, SELF=None):
  for enc in CCoiM6.VV06wI():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFoFqK(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVHC0y(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFgjbJ(SELF)
  lst = CCoiM6.VVy0cO(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVGtpd = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFj5YA(txt, VVTVTj)
    VVGtpd.append((txt, enc))
   if onlyWorkingEnc: SELF.session.openWithCallback(cbFnc, CC1Wvt, path, VVGtpd, title)
   else    : FFINMf(SELF, cbFnc, title=title, VVGtpd=VVGtpd, width=900, VVghW2="#22220000", VVlnMM="#22220000")
  else:
   FFgjbJ(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVy0cO(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VViEnD + "_sup_codecs"
  if fileExists(cPath):
   lines = FF8eQ2(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCoiM6.VV06wI())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCB7Ee(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGtpd = []
  VVGtpd.append(("Settings File"   , "SettingsFile"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Box Info"     , "VVG8He"   ))
  VVGtpd.append(("Tuners Info"    , "VVFZtq"  ))
  VVGtpd.append(("Python Version"   , "VV0Mv0"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Screen Size"    , "ScreenSize"   ))
  VVGtpd.append(("Language/Locale"   , "Locale"    ))
  VVGtpd.append(("Processor"    , "Processor"   ))
  VVGtpd.append(("Operating System"   , "OperatingSystem"  ))
  VVGtpd.append(("Drivers"     , "drivers"    ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("System Users"    , "SystemUsers"   ))
  VVGtpd.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVGtpd.append(("Uptime"     , "Uptime"    ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Host Name"    , "HostName"   ))
  VVGtpd.append(("MAC Address"    , "MACAddress"   ))
  VVGtpd.append(("Network Configuration" , "NetworkConfiguration"))
  VVGtpd.append(("Network Status"   , "NetworkStatus"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Disk Usage"    , "VVUBGh"   ))
  VVGtpd.append(("Mount Points"    , "MountPoints"   ))
  VVGtpd.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVGtpd.append(("USB Devices"    , "USB_Devices"   ))
  VVGtpd.append(("List Block-Devices"  , "listBlockDevices" ))
  VVGtpd.append(("Directory Size"   , "DirectorySize"  ))
  VVGtpd.append(("Memory"     , "Memory"    ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVGtpd.append(("Running Processes"  , "RunningProcesses" ))
  VVGtpd.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFOh1m(self, VVGtpd=VVGtpd, title="Device Information")
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCc4Qy)
   elif item == "VVG8He"   : self.VVG8He()
   elif item == "VVFZtq"  : self.VVFZtq()
   elif item == "VV0Mv0"  : self.VV0Mv0()
   elif item == "ScreenSize"   : FFcTZL(self, "Width\t: %s\nHeight\t: %s" % (FFIyPo()[0], FFIyPo()[1]))
   elif item == "Locale"    : CCoiM6.VVvzf6(self)
   elif item == "Processor"   : self.VV2oXm()
   elif item == "OperatingSystem"  : FFm2b8(self, "uname -a")
   elif item == "drivers"    : self.VVluTi()
   elif item == "SystemUsers"   : FFm2b8(self, "id")
   elif item == "LoggedInUsers"  : FFm2b8(self, "who -a")
   elif item == "Uptime"    : FFm2b8(self, "uptime")
   elif item == "HostName"    : FFm2b8(self, "hostname")
   elif item == "MACAddress"   : self.VV7BaU()
   elif item == "NetworkConfiguration" : FFm2b8(self, "ifconfig %s %s" % (FFYHN3("HWaddr", VVJsQK), FFYHN3("addr:", VVNUk6)))
   elif item == "NetworkStatus"  : FFm2b8(self, "netstat -tulpn"       )
   elif item == "VVUBGh"   : self.VVUBGh()
   elif item == "MountPoints"   : FFm2b8(self, "mount %s" % (FFYHN3(" on ", VVNUk6)))
   elif item == "FileSystemTable"  : FFm2b8(self, "cat /etc/fstab")
   elif item == "USB_Devices"   : FFm2b8(self, "lsusb")
   elif item == "listBlockDevices"  : FFm2b8(self, "blkid")
   elif item == "DirectorySize"  : FFm2b8(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVFxJT="Reading size ...")
   elif item == "Memory"    : FFm2b8(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVHowr()
   elif item == "RunningProcesses"  : FFm2b8(self, "ps")
   elif item == "ProcessesOpenFiles" : FFm2b8(self, "lsof")
   elif item == "DreamBoxBootloader"  : self.VVeELg()
   else        : self.close()
 def VV7BaU(self):
  res = FFg1NP("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFcTZL(self, txt)
  else:
   FFm2b8(self, "ip link")
 def VVb9Q5(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFCpSv(cmd)
  return lines
 def VVDu4b(self, lines, headerRepl, widths, VVZq8i):
  VVzpbP = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVzpbP.append(parts)
  if VVzpbP and len(header) == len(widths):
   VVzpbP.sort(key=lambda x: x[0].lower())
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVwTA1=1)
   return True
  else:
   return False
 def VVUBGh(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFg1NP(cmd)
  if not "invalid option" in txt:
   lines  = self.VVb9Q5(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVZq8i = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVDu4b(lines, headerRepl, widths, VVZq8i)
  else:
   cmd = "df -h"
   lines  = self.VVb9Q5(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVZq8i = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVDu4b(lines, headerRepl, widths, VVZq8i)
  if not allOK:
   lines = FFCpSv(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFgJRr(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVTVTj:
     note = "\n%s" % FFj5YA("Green = Mounted Partitions", VVTVTj)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVNUk6
     elif line.endswith(mountList) : color = VVTVTj
     else       : color = VVOEUE
     txt += FFj5YA(line, color) + "\n"
    FFcTZL(self, txt + note)
   else:
    FFoFqK(self, "Not data from system !")
 def VVHowr(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVb9Q5(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVZq8i = (LEFT , CENTER, LEFT )
  allOK = self.VVDu4b(lines, headerRepl, widths, VVZq8i)
  if not allOK:
   FFm2b8(self, cmd)
 def VVluTi(self):
  cmd = FFqitY(VV4P4m, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFm2b8(self, cmd)
  else : FFmApx(self)
 def VV2oXm(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFm2b8(self, cmd)
 def VVeELg(self):
  cmd = FFqitY(VV0jlF, "| grep secondstage")
  if cmd : FFm2b8(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFmApx(self)
 def VVG8He(self):
  c = VVTVTj
  VVkGEY = []
  VVkGEY.append((FFj5YA("Box Type"  , c), FFj5YA(self.VVRE78("boxtype").upper(), c)))
  VVkGEY.append((FFj5YA("Board Version", c), FFj5YA(self.VVRE78("board_revision") , c)))
  VVkGEY.append((FFj5YA("Chipset"  , c), FFj5YA(self.VVRE78("chipset")  , c)))
  VVkGEY.append((FFj5YA("S/N"   , c), FFj5YA(self.VVRE78("sn")    , c)))
  VVkGEY.append((FFj5YA("Version"  , c), FFj5YA(self.VVRE78("version")  , c)))
  VVoGMZ   = []
  VV2Txs = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV2Txs = SystemInfo[key]
     else:
      VVoGMZ.append((FFj5YA(str(key), VVFiA5), FFj5YA(str(SystemInfo[key]), VVFiA5)))
  except:
   pass
  if VV2Txs:
   VVaJOG = self.VVL7C0(VV2Txs)
   if VVaJOG:
    VVaJOG.sort(key=lambda x: x[0].lower())
    VVkGEY += VVaJOG
  if VVoGMZ:
   VVoGMZ.sort(key=lambda x: x[0].lower())
   VVkGEY += VVoGMZ
  if VVkGEY:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF4zYj(self, None, header=header, VVkGEY=VVkGEY, VVsmwq=widths, VVdez8=28, VVwTA1=1)
  else:
   FFcTZL(self, "Could not read info!")
 def VVRE78(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF8eQ2(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVL7C0(self, mbDict):
  try:
   mbList = list(mbDict)
   VVkGEY = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVkGEY.append((FFj5YA(subject, VVNUk6), FFj5YA(value, VVNUk6)))
  except:
   pass
  return VVkGEY
 def VVFZtq(self):
  txt = self.VVHrfK("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVHrfK("/proc/bus/nim_sockets")
  if not txt: txt = self.VVyqTt()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFcTZL(self, txt)
 def VVyqTt(self):
  txt = ""
  VVy3eN = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVy3eN("Slot Name" , slot.getSlotName())
     txt += FFj5YA(slotName, VVNUk6)
     txt += VVy3eN("Description"  , slot.getFullDescription())
     txt += VVy3eN("Frontend ID"  , slot.frontend_id)
     txt += VVy3eN("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVHrfK(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF8eQ2(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFj5YA(line, VVNUk6)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV0Mv0(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFcTZL(self, txt)
 @staticmethod
 def VV0wGB():
  def VVy3eN(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVy3eN(v,0), "/etc/issue.net": VVy3eN(v,1), "/etc/image-version": VVy3eN(v,2)}
  for p1, d in v.items():
   img = CCB7Ee.VV7zRC(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVy3eN(v,0), p + "Plugins/": VVy3eN(v,1), VV8tIu: VVy3eN(v,2), VVUMIB: VVy3eN(v,3)}
  for p1, d in v.items():
   img = CCB7Ee.VVFCcN(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV7zRC(path, d):
  if fileExists(path):
   txt = FFEJE4(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVFCcN(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCc4Qy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGtpd = []
  VVGtpd.append(("Settings (All)"   , "Settings_All"   ))
  VVGtpd.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVGtpd.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVGtpd.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVGtpd.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVGtpd.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVGtpd.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVwdnn:
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVGtpd.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVCQ1V
   grep = " | grep "
   if   item == "Settings_All"   : FFm2b8(self, cmd)
   elif item == "Settings_HotKeys"  : FFm2b8(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFm2b8(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFm2b8(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFm2b8(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFm2b8(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFm2b8(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFm2b8(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFm2b8(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCfMYX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVhSp7, VVjSaE, VVivBf, camCommand = CCfMYX.VVwqcH()
  self.VVjSaE = VVjSaE
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVjSaE:
   c = VVlyaF if VVivBf else VVM7JM
   if   "oscam" in VVjSaE : camName, oC = "OSCam", c
   elif "ncam"  in VVjSaE : camName, nC = "NCam" , c
  VVGtpd = []
  VVGtpd.append(("OSCam Files" , "OSCamFiles" ))
  VVGtpd.append(("NCam Files" , "NCamFiles" ))
  VVGtpd.append(("CCcam Files" , "CCcamFiles" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((VVMCs3 + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVRxGR" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVGtpd.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVGtpd.append(VVttU7)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVjSaE: VVGtpd.append((c + txt  , "camInfo" ))
  else  : VVGtpd.append((txt  ,    ))
  VVGtpd.append(VVttU7)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVjSaE:
   for item in camLst: VVGtpd.append(item)
  else:
   for item in camLst: VVGtpd.append((item[0], ))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCZijr, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCZijr, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCZijr, "cccam"))
   elif item == "VVRxGR" : self.VVRxGR()
   elif item == "OSCamReaders"  : self.VVgHhM("os")
   elif item == "NSCamReaders"  : self.VVgHhM("n")
   elif item == "camInfo"   : FFZIED(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCfMYX.VVlZCq(self.session, CCZe0t.VVB7Gc)
   elif item == "camLiveReaders" : CCfMYX.VVlZCq(self.session, CCZe0t.VV9GCr)
   elif item == "camLiveLog"  : CCfMYX.VVlZCq(self.session, CCZe0t.VVI89e)
   else       : self.close()
 def VVRxGR(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVFuxe, FFbNWS())
  if fileExists(path):
   lines = FF8eQ2("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVy3eN = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVy3eN("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVy3eN("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVy3eN("protocol"   , "cccam"))
      f.write(VVy3eN("device"    , "%s,%s" % (host, port)))
      f.write(VVy3eN("user"    , User))
      f.write(VVy3eN("password"   , Pass))
      f.write(VVy3eN("fallback"   , "1"))
      f.write(VVy3eN("group"    , "64"))
      f.write(VVy3eN("cccversion"   , "2.3.2"))
      f.write(VVy3eN("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFOPTX(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFLQjK(tot), outFile))
   else:
    FFgjbJ(self, "No valid CCcam lines", 1500)
  else:
   FFgjbJ(self, "%s not found" % path, 1500)
 def VVgHhM(self, camPrefix):
  VVzpbP = self.VVHQUL(camPrefix)
  if VVzpbP:
   VVzpbP.sort(key=lambda x: int(x[0]))
   if self.VVjSaE and self.VVjSaE.startswith(camPrefix):
    VVtaAK = ("Toggle State", self.VVTBOe, [camPrefix], "Changing State ...")
   else:
    VVtaAK = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVZq8i  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVtaAK=VVtaAK, VV0i4h=True)
 def VVHQUL(self, camPrefix):
  readersFile = self.VVhSp7 + camPrefix + "cam.server"
  VVzpbP = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF8eQ2(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVzpbP.append((str(len(VVzpbP) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVzpbP:
    FFoFqK(self, "No readers found !")
  else:
   FFE0MG(self, readersFile)
  return VVzpbP
 def VVTBOe(self, VVeDC2, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVhSp7, camPrefix)
  readerState  = VVeDC2.VVhJef(1)
  readerLabel  = VVeDC2.VVhJef(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCfMYX.VV4v2V(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVeDC2.VVtAan()
    FFoFqK(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVzpbP = self.VVHQUL(camPrefix)
   if VVzpbP:
    VVeDC2.VV6IAT(VVzpbP)
  else:
   VVeDC2.VVtAan()
 @staticmethod
 def VV4v2V(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF8eQ2(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFoFqK(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFoFqK(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFE0MG(SELF, confFile)
   return None
  if not iRequest:
   FFoFqK(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCfMYX.VVhhXR(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFoFqK(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVhhXR(SELF):
  if iElem:
   return True
  else:
   FFoFqK(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVlZCq(session, VVczEl):
  VVhSp7, VVjSaE, VVivBf, camCommand = CCfMYX.VVwqcH()
  if VVjSaE:
   runLog = False
   if   VVczEl == CCZe0t.VVB7Gc : runLog = True
   elif VVczEl == CCZe0t.VV9GCr : runLog = True
   elif not VVivBf          : FFV4bo(session, message="SoftCam not started yet!")
   elif fileExists(VVivBf)        : runLog = True
   else             : FFV4bo(session, message="File not found !\n\n%s" % VVivBf)
   if runLog:
    session.open(BF(CCZe0t, VVhSp7=VVhSp7, VVjSaE=VVjSaE, VVivBf=VVivBf, VVczEl=VVczEl))
  else:
   FFV4bo(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVwqcH():
  VVhSp7 = "/etc/tuxbox/config/"
  VVjSaE = None
  VVivBf  = None
  camCommand = FFfoZ6("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVjSaE = "oscam"
   elif camCmd.startswith("ncam") : VVjSaE = "ncam"
  if VVjSaE:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFEJE4(path), IGNORECASE)
     if span:
      VVhSp7 = FFoR3R(span.group(1))
      break
   else:
    path = FFfoZ6(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFoR3R(path)
    if pathExists(path):
     VVhSp7 = path
   tFile = FFoR3R(VVhSp7) + VVjSaE + ".conf"
   tFile = FFfoZ6("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVivBf = tFile
  return VVhSp7, VVjSaE, VVivBf, camCommand
class CCZijr(Screen):
 def __init__(self, VVzQtG, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVhSp7, VVjSaE, VVivBf, camCommand = CCfMYX.VVwqcH()
  if   VVzQtG == "ncam" : self.prefix = "n"
  elif VVzQtG == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVGtpd = []
  if self.prefix == "":
   VVGtpd.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVGtpd.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVGtpd.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVGtpd.append(("constant.cw"         , "x_constant_cw" ))
   VVGtpd.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVGtpd.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVGtpd.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVGtpd.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVGtpd.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVGtpd.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVGtpd.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVGtpd.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVGtpd.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVGtpd.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVGtpd.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFv9qK(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFv9qK(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFv9qK(self, self.VVhSp7 + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFv9qK(self, self.VVhSp7 + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVpTzW("cam.ccache")
   elif item == "x_cam_conf"  : self.VVpTzW("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVpTzW("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVpTzW("cam.provid")
   elif item == "x_cam_server"  : self.VVpTzW("cam.server")
   elif item == "x_cam_services" : self.VVpTzW("cam.services")
   elif item == "x_cam_srvid2"  : self.VVpTzW("cam.srvid2")
   elif item == "x_cam_user"  : self.VVpTzW("cam.user")
   elif item == "x_VVa91R"   : pass
   elif item == "x_SoftCam_Key" : self.VVIove()
   elif item == "x_CCcam_cfg"  : FFv9qK(self, self.VVhSp7 + "CCcam.cfg")
   elif item == "x_VVa91R"   : pass
   elif item == "x_cam_log"  : FFv9qK(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFv9qK(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFv9qK(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVpTzW(self, fileName):
  FFv9qK(self, self.VVhSp7 + self.prefix + fileName)
 def VVIove(self):
  path = self.VVhSp7 + "SoftCam.Key"
  if fileExists(path) : FFv9qK(self, path)
  else    : FFv9qK(self, path.replace(".Key", ".key"))
class CCZe0t(Screen):
 VVB7Gc  = 0
 VV9GCr = 1
 VVI89e = 2
 def __init__(self, session, VVhSp7="", VVjSaE="", VVivBf="", VVczEl=VVB7Gc):
  self.skin, self.skinParam = FFkttW(VVgBg4, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVivBf   = VVivBf
  self.VVczEl  = VVczEl
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVhSp7 + VVjSaE + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVjSaE : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVhSp7, self.camPrefix)
  if self.VVczEl == self.VVB7Gc:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVczEl == self.VV9GCr:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFOh1m(self, self.Title, addScrollLabel=True)
  FFiTXq(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVC4Xm
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self["myLabel"].VVP4jT(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFsHsH(self)
  self.VVC4Xm()
 def onExit(self):
  self.timer.stop()
 def VV66KR(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV4FjD)
  except:
   self.timer.callback.append(self.VV4FjD)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFgjbJ(self, "Started", 1000)
 def VVIqEz(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV4FjD)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFgjbJ(self, "Stopped", 1000)
 def VVC4Xm(self):
  if self.timerRunning:
   self.VVIqEz()
  else:
   self.VV66KR()
   if self.VVczEl == self.VVB7Gc or self.VVczEl == self.VV9GCr:
    if self.VVczEl == self.VVB7Gc : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCfMYX.VV4v2V(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFkWtI(self.VVmL45)
    else:
     self.close()
   else:
    self.VVjVPT()
 def VV4FjD(self):
  if self.timerRunning:
   if   self.VVczEl == self.VVB7Gc : self.VV24ZC()
   elif self.VVczEl == self.VV9GCr : self.VV24ZC()
   else            : self.VVjVPT()
 def VVjVPT(self):
  if fileExists(self.VVivBf):
   fTime = FF5ivG(os.path.getmtime(self.VVivBf))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV9x8z(), VV4T9O=VVumOn)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVivBf)
 def VVmL45(self):
  self.VV24ZC()
 def VV24ZC(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFj5YA("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVXz72))
   self.camWebIfErrorFound = True
   self.VVIqEz()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVczEl == self.VVB7Gc : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFj5YA("Error while parsing data elements !\n\nError = %s" % str(e), VVfzKO)
   self.camWebIfErrorFound = True
   self.VVIqEz()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVVmrC(root)
  self["myLabel"].setText(txt, VV4T9O=VVumOn)
  self["myBar"].setText("Last Update : %s" % FFtkvI())
 def VVVmrC(self, rootElement):
  def VVy3eN(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVczEl == self.VVB7Gc:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFj5YA(status, VVTVTj)
    else          : status = FFj5YA(status, VVfzKO)
    txt += VVa91R + "\n"
    txt += VVy3eN("Name"  , name)
    txt += VVy3eN("Description" , desc)
    txt += VVy3eN("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVy3eN("Protocol" , protocol)
    txt += VVy3eN("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFj5YA("Yes", VVTVTj)
    else    : enabTxt = FFj5YA("No", VVfzKO)
    txt += VVa91R + "\n"
    txt += VVy3eN("Label"  , label)
    txt += VVy3eN("Protocol" , protocol)
    txt += VVy3eN("Enabled" , enabTxt)
  return txt
 def VV9x8z(self):
  lines = FFCpSv("tail -n %d %s" % (100, self.VVivBf))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVAjMy + line[:19] + VVOEUE + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVYofj + "WebIf" + VVOEUE)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVFiA5 + h1 + h2 + VVOEUE + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVTVTj + span.group(2) + VVMCs3 + span.group(3) + VVOEUE + span.group(4)
    line = self.VV0oY2(line, VVMCs3, ("(webif)", ))
    line = self.VV0oY2(line, VVMCs3, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV0oY2(line, VVTVTj, ("OSCam", "NCam", "log switched"))
    line = self.VV0oY2(line, VVNNKJ, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVNUk6 + line[ndx + 3:] + VVOEUE
   elif line.startswith("----") or ">>" in line:
    line = FFj5YA(line, VVDIbD)
   txt += line + "\n"
  return txt
 def VV0oY2(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVOEUE + t3
  return line
class CCrP3q(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVGtpd = []
  VVGtpd.append(("Backup Channels"    , "VVS5aI"   ))
  VVGtpd.append(("Restore Channels"    , "Restore_Channels"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Backup SoftCAM Files"   , "VV5p1g" ))
  VVGtpd.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVGtpd.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVGtpd.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Backup Network Settings"  , "VVU6IT"   ))
  VVGtpd.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVwdnn:
   VVGtpd.append(VVttU7)
   VVGtpd.append((VVXz72 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VV4xZ9"   ))
   VVGtpd.append((VVTVTj + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVotAg), "createMyIpk"   ))
   VVGtpd.append((VVTVTj + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVotAg), "createMyDeb"   ))
   VVGtpd.append((VVFiA5 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVGtpd.append((VVFiA5 + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVSUeP" ))
   VVGtpd.append((VVFiA5 + "Show Windows Stats"           , "VVHUWU" ))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVS5aI"    : self.VVS5aI()
   elif item == "Restore_Channels"    : self.VVtJaQ("channels_backup*.tar.gz", self.VVCztL, isChan=True)
   elif item == "VV5p1g"   : self.VV5p1g()
   elif item == "Restore_SoftCAM_Files"  : self.VVtJaQ("softcam_backup*.tar.gz", self.VVbjOI)
   elif item == "Backup_TunerDiSEqC"   : self.VV5AkQ("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVtJaQ("tuner_backup*.backup", BF(self.VVEIKD, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV5AkQ("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVtJaQ("hotkey_*backup*.backup", BF(self.VVEIKD, "misc"))
   elif item == "VVU6IT"    : self.VVU6IT()
   elif item == "Restore_Network"    : self.VVtJaQ("network_backup*.tar.gz", self.VVCEtb)
   elif item == "VV4xZ9"     : FFlEph(self, BF(FFKsz7, self, BF(CCrP3q.VV4xZ9, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVOcyE(False)
   elif item == "createMyDeb"     : self.VVOcyE(True)
   elif item == "createMyTar"     : self.VVD3p0()
   elif item == "VVSUeP"   : self.VVSUeP()
   elif item == "VVHUWU"    : CCrP3q.VVHUWU(self)
 @staticmethod
 def VVy1xk(SELF):
  OBF_Path = VVjba7 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFE0MG(SELF, OBF_Path)
   return None
 @staticmethod
 def VVHUWU(SELF):
  obf = CCrP3q.VVy1xk(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFcTZL(SELF, txt, title=title)
 @staticmethod
 def VV4xZ9(SELF):
  obf = CCrP3q.VVy1xk(SELF)
  if obf:
   txt, err = obf.fixCode(VVjba7, VVJjPN, VVotAg)
   if err : FFoFqK(SELF, err)
   else : FFcTZL(SELF, txt)
 def VVOcyE(self, VVtGSd):
  OBF_Path = VVjba7 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFoFqK(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVjba7)
  os.system("mv -f %s %s" % (VVjba7 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVjba7 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVjba7 + "plugin.py"))
  self.session.openWithCallback(self.VVJMi9, BF(CCZlUG, path=VVjba7, VVtGSd=VVtGSd))
 def VVJMi9(self):
  os.system("mv -f %s %s" % (VVjba7 + "OBF/main.py"  , VVjba7))
  os.system("mv -f %s %s" % (VVjba7 + "OBF/plugin.py" , VVjba7))
 def VVSUeP(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFoFqK(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFoFqK(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVbsyz("%s*.list" % path)
  if err:
   FFE0MG(self, path + "*.list")
   return
  srcF, err = self.VVbsyz("%s*main_final.py" % path)
  if err:
   FFE0MG(self, path + "*.final.py")
   return
  VVkGEY = []
  for f in files:
   f = os.path.basename(f)
   VVkGEY.append((f, f))
  FFINMf(self, BF(self.VV9kIf, path, codF, srcF), VVGtpd=VVkGEY)
 def VV9kIf(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFE0MG(self, logF)
   else     : FFKsz7(self, BF(self.VVKZ2x, logF, codF, srcF))
 def VVKZ2x(self, logF, codF, srcF):
  lst  = []
  lines = FF8eQ2(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFoFqK(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV42EZ(lst, logF, newLogF)
  totSrc  = self.VV42EZ(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFcTZL(self, txt)
 def VVbsyz(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV42EZ(self, lst, f1, f2):
  txt = FFEJE4(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVD3p0(self):
  VVkGEY = []
  VVkGEY.append("%s%s" % (VVjba7, "*.py"))
  VVkGEY.append("%s%s" % (VVjba7, "*.png"))
  VVkGEY.append("%s%s" % (VVjba7, "*.xml"))
  VVkGEY.append("%s"  % (VViEnD))
  FFhS09(self, VVkGEY, "%s_%s" % (PLUGIN_NAME, VVJjPN), addTimeStamp=False)
 def VVS5aI(self):
  path1 = VVCQ1V
  path2 = "/etc/tuxbox/"
  VVkGEY = []
  VVkGEY.append("%s%s" % (path1, "*.tv"))
  VVkGEY.append("%s%s" % (path1, "*.radio"))
  VVkGEY.append("%s%s" % (path1, "*list"))
  VVkGEY.append("%s%s" % (path1, "lamedb*"))
  VVkGEY.append("%s%s" % (path2, "*.xml"))
  FFhS09(self, VVkGEY, self.VVCPj0("channels_backup"), addTimeStamp=True)
 def VV5p1g(self):
  VVkGEY = []
  VVkGEY.append("/etc/tuxbox/config/")
  VVkGEY.append("/usr/keys/")
  VVkGEY.append("/usr/scam/")
  VVkGEY.append("/etc/CCcam.cfg")
  FFhS09(self, VVkGEY, self.VVCPj0("softcam_backup"), addTimeStamp=True)
 def VVU6IT(self):
  VVkGEY = []
  VVkGEY.append("/etc/hostname")
  VVkGEY.append("/etc/default_gw")
  VVkGEY.append("/etc/resolv.conf")
  VVkGEY.append("/etc/wpa_supplicant*.conf")
  VVkGEY.append("/etc/network/interfaces")
  VVkGEY.append("%snameserversdns.conf" % VVCQ1V)
  FFhS09(self, VVkGEY, self.VVCPj0("network_backup"), addTimeStamp=True)
 def VVCPj0(self, fName):
  img = CCB7Ee.VV0wGB()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVCztL(self, fileName=None):
  if fileName:
   FFlEph(self, BF(FFKsz7, self, BF(self.VV7pWV, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VV7pWV(self, fileName):
  path = "%s%s" % (VVFuxe, fileName)
  if fileExists(path):
   if CC1TwY.VVsW6t(path):
    VVrqSy , VVJ0hD = CC5MnI.VVE0Bv()
    VVHwX2, VVaMCM = CC5MnI.VVsNuD()
    cmd  = FFN2Os("cd %s" % VVCQ1V) + ";"
    cmd += FFN2Os("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVJ0hD, VVaMCM))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFEuF7()
    if res == 0 : FFOPTX(self, "Channels Restored.")
    else  : FFoFqK(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFoFqK(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFE0MG(self, path)
 def VVbjOI(self, fileName=None):
  if fileName:
   FFlEph(self, BF(self.VVla3B, fileName), "Overwrite SoftCAM files ?")
 def VVla3B(self, fileName):
  fileName = "%s%s" % (VVFuxe, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVa91R
   note = "You may need to restart your SoftCAM."
   FFftHz(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFYHN3(note, VVNUk6), sep))
  else:
   FFE0MG(self, fileName)
 def VVCEtb(self, fileName=None):
  if fileName:
   FFlEph(self, BF(self.VV4nYA, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV4nYA(self, fileName):
  fileName = "%s%s" % (VVFuxe, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFB1pa(self,  cmd)
  else:
   FFE0MG(self, fileName)
 def VVtJaQ(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFKNF8()
  if pathExists(VVFuxe):
   myFiles = FFKQDF(VVFuxe, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVkGEY = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVkGEY.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVVLOF = ("Sat. List", self.VV4Xdw)
    elif isChan and iTar: VVVLOF = ("Bouquets Importer", CCzej8.VVeOXS)
    else    : VVVLOF = None
    FFINMf(self, callBackFunction, title=title, width=1200, VVGtpd=VVkGEY, VVVLOF=VVVLOF, yellowBasePath=VVFuxe)
   else:
    FFoFqK(self, "No files found in:\n\n%s" % VVFuxe, title)
  else:
   FFoFqK(self, "Path not found:\n\n%s" % VVFuxe, title)
 def VV5AkQ(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVCQ1V
  tCons = CCzBO0()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVpXrF, filePrefix))
 def VVpXrF(self, filePrefix, result, retval):
  title = FFKNF8()
  if pathExists(VVFuxe):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFoFqK(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVFuxe, filePrefix, self.VVCPj0(""), FFbNWS())
    try:
     VVkGEY = str(result.strip()).split()
     if VVkGEY:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVkGEY:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVa91R, FFj5YA(fName, VVNUk6), VVa91R)
       FFcTZL(self, txt, title=title, VV4T9O=VVumOn)
      else:
       FFoFqK(self, "File creation failed!", title)
     else:
      FFoFqK(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFN2Os("rm %s" % fName))
     FFoFqK(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFN2Os("rm %s" % fName))
     FFoFqK(self, "Error while writing file.")
  else:
   FFoFqK(self, "Path not found:\n\n%s" % VVFuxe, title)
 def VVEIKD(self, mode, path=None):
  if path:
   path = "%s%s" % (VVFuxe, path)
   if fileExists(path):
    lines = FF8eQ2(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFlEph(self, BF(self.VVkhVI, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFPPOX(self, path, title=FFKNF8())
   else:
    FFE0MG(self, path)
 def VVkhVI(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  isVTi = pathExists(VV8tIu + "VTIPanel")
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    if isVTi and ".dvbs." in line: pass
    else       : finalList.append(line)
  VVxUb7 = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVxUb7.append("echo -e 'Reading current settings ...'")
  VVxUb7.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVxUb7.append("echo -e 'Preparing new settings ...'")
  VVxUb7.append(settingsLines)
  VVxUb7.append("echo -e 'Applying new settings ...'")
  VVxUb7.append("mv -f %s %s" % (tFile, sFile))
  FFe3vO(self, VVxUb7)
 def VV4Xdw(self, VVE2XdObj, path):
  if not path:
   return
  path = VVFuxe + path
  if not fileExists(path):
   FFE0MG(self, path)
   return
  txt = FFEJE4(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFvbLy(item[1]))
   FFcTZL(self, txt, title="Satellites List")
  else:
   FFoFqK(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCzej8():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVeOXS(SELF, fName):
  bi = CCzej8(SELF)
  bi.instance = bi
  bi.VV10Eq(SELF, fName)
 @staticmethod
 def VVadtq(SELF):
  bi = CCzej8(SELF)
  bi.instance = bi
  bi.VVdwKz()
 def VV10Eq(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVFuxe + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFKsz7(waitObg, self.VVWMM7, title="Reading bouquets ...")
  else      : self.VVtOEU(self.filePath)
 def VVy1Mf(self, txt) : FFoFqK(self.SELF, txt, title=self.Title)
 def VVjHD0(self, txt)  : FFgjbJ(self, txt, 1500)
 def VVtOEU(self, path) : FFE0MG(self.SELF, path, title=self.Title)
 def VVdwKz(self):
  if pathExists(VVFuxe):
   lst = FFKQDF(VVFuxe, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVcszG())
   if len(lst) > 0:
    VVGtpd = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFj5YA(item, VVMCs3) if item.endswith(".zip") else item
     VVGtpd.append((txt, item))
    VVGtpd.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVH5KW
    FFINMf(self.SELF, self.VViyJ8, minRows=3, title=self.Title, width=1200, VVGtpd=VVGtpd, OKBtnFnc=OKBtnFnc, yellowBasePath=VVFuxe, VVghW2="#22111111", VVlnMM="#22111111")
   else:
    self.VVy1Mf("No valid backup files found in:\n\n%s" % VVFuxe)
  else:
   self.VVy1Mf("Backup Directory not found:\n\n%s" % VVFuxe)
 def VVH5KW(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VV10Eq(menuInstance, fName)
 def VViyJ8(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVcszG(self):
  files = FFKQDF(VVFuxe, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVWMM7(self):
  lines, err = CCzej8.VVSmvn(self.filePath, "bouquets.tv")
  if err:
   self.VVy1Mf(err)
   return
  bTvSortLst  = self.VVEnXV(lines)
  lines, err = CCzej8.VVSmvn(self.filePath, "bouquets.radio")
  if err:
   self.VVy1Mf(err)
   return
  bRadSortLst = self.VVEnXV(lines)
  VVzpbP = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VV8Zkn(f, mode, len(VVzpbP), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVzpbP.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VV8Zkn(f, mode, len(VVzpbP), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VV8Zkn(f, mode, len(VVzpbP), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVzpbP.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VV8Zkn(f, mode, len(VVzpbP), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVzpbP:
   VVzpbP.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVzpbP): VVzpbP[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVzpbP):
     if key == os.path.basename(row[9]):
      VVzpbP = VVzpbP[:ndx+1] + lst + VVzpbP[ndx+1:]
      break
   for ndx, item in enumerate(VVzpbP): VVzpbP[ndx][0] = str(ndx + 1)
   VValS2 = "#11000600"
   VVLseV  = ("Show Services" , self.VVcAKC  , [], "Reading ..." )
   VVXlcT = (""    , self.VVrgh2, [])
   VV0q2u = ("Options"  , self.VVaaAW, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVZq8i  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FF4zYj(self.SELF, None, title=self.Title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=24, VVLseV=VVLseV, VVXlcT=VVXlcT, VV0q2u=VV0q2u, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVghW2=VValS2, VVlnMM=VValS2, VValS2=VValS2, VVRaJ8="#11ffffff", VVKJ4V="#00004455", VVEwGL="#0a282828")
  else:
   self.VVy1Mf("No valid bouquets in:\n\n%s" % self.filePath)
 def VVEnXV(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVrgh2(self, VVeDC2, title, txt, colList):
  FFcTZL(self.SELF, FFg0L0(txt), title=title)
 def VVaaAW(self, VVeDC2, title, txt, colList):
  mSel = CCqt6h(self.SELF, VVeDC2)
  if VVeDC2.VVFCH5:
   totSel = VVeDC2.VVau1b()
   if totSel: VVGtpd = [("Import %s Bouquet%s" % (FFj5YA(str(totSel), VVTVTj), FFLQjK(totSel)), "imp")]
   else  : VVGtpd = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFj5YA(bName, VVTVTj)
   VVGtpd = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFKsz7, VVeDC2, BF(CCzej8.VV6QqL, self.SELF, VVeDC2, self.filePath))}
  mSel.VVO5ex(VVGtpd, cbFncDict)
 def VVcAKC(self, VVeDC2, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCzej8.VVSmvn(self.filePath, "lamedb")
   if err:
    self.VVy1Mf(err)
    return
   dbServLst = CC5MnI.VVEzir(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVeDC2.VVxY0I()
   lines, err = CCzej8.VVSmvn(self.filePath, os.path.basename(fName))
   if err:
    self.VVy1Mf(err)
    return
   VVzpbP = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVzpbP.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVzpbP.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVzpbP.append((span.group(1).strip() or "-", "Stream Relay" if FFXaBx(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVzpbP.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVzpbP.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CC5MnI.VVEH7o(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVzpbP.append((name.strip() or "-", FFFJgS(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVzpbP):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCzej8.VVSmvn(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVzpbP[ndx] = (bName, descr)
   if VVzpbP:
    VValS2 = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVZq8i = (LEFT  , CENTER)
    FF4zYj(self.SELF, None, title="Services in : %s" % bName, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVghW2=VValS2, VVlnMM=VValS2, VValS2=VValS2, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFgjbJ(VVeDC2, err, 1500)
  else : VVeDC2.VVtAan()
 def VV8Zkn(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVy1Mf("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFXaBx(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVAqUp(var):
   return str(var) if var else VVky8q + str(var)
  totItem = VVNUk6 + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVXz72   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVMCs3, "Sub-B."
  else  : bColor, totBnb = ""      , VVAqUp(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVAqUp(totDVB), VVAqUp(totIptv), VVAqUp(totSRelay), VVAqUp(totLoc), VVAqUp(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VV6QqL(SELF, VVeDC2, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVCQ1V + "bouquets.tv"
  radBouquetFile = VVCQ1V + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFE0MG(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFE0MG(SELF, radBouquetFile, title=title)
   return
  isMulti = VVeDC2.VVFCH5
  if isMulti : rows = VVeDC2.VVdQBn()
  else  : rows = [VVeDC2.VVxY0I()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFoFqK(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFg0L0(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFg0L0(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVCQ1V + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVCQ1V + newFile
    CCzej8.VVOpmZ(archPath, fName, VVCQ1V, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CC3pKJ.VVvT3F(tvBouquetFile)
   CC3pKJ.VVvT3F(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCzej8.VVScb5(SELF, archPath, bList)
   FFEuF7()
  txt  = FFj5YA("Added:\n", VVMCs3)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFj5YA("Imported to lamedab:\n", VVMCs3)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFj5YA("Missing from archived lamedb:\n", VVXz72)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFcTZL(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVScb5(SELF, archPath, bList):
  VVrqSy, err = CC5MnI.VVPohR(SELF, VVjxU1=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CC5MnI.VVtBbO(VVrqSy, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF8eQ2(VVCQ1V + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CC5MnI.VVEH7o(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CC5MnI.VVDi2X(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCzej8.VVeWij(archPath, dbName)
   CCzej8.VVOpmZ(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CC5MnI.VVtBbO(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CC5MnI.VVtBbO(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CC5MnI.VVtBbO(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CC5MnI.VVtBbO(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FF9qnP(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVrqSy + ".tmp"
   lines   = FF8eQ2(VVrqSy)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFN2Os("mv -f '%s' '%s'" % (tmpDbFile, VVrqSy)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVFXdL(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVeWij(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVOpmZ(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVSmvn(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCTrGQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVUJSe, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVGtpd = []
  VVGtpd.append(("Plugins Browser List"       , "VVipzn"  ))
  VVGtpd.append(("Plugins Additional Menus"      , "pluginsMenus"   ))
  VVGtpd.append(("Startup Plugins"        , "pluginsStartup"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Extensions and System Plugins"    , "pluginsDirList"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages" ))
  VVGtpd.append(("Remove Packages (show all)"     , "VV0ZkHsAll"  ))
  VVGtpd.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Update Packages List from Feed"    , "VV1LMJ"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Packaging Tool"        , "VV7gfs"   ))
  VVGtpd.append(("Packages Feeds"        , "packagesFeeds"   ))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVipzn"   : self.VVipzn()
   elif item == "pluginsMenus"     : self.VViHNz(0)
   elif item == "pluginsStartup"    : self.VViHNz(1)
   elif item == "pluginsDirList"    : self.VVY11d()
   elif item == "downloadInstallPackages"  : FFKsz7(self, BF(self.VVlJZC, 0, ""))
   elif item == "VV0ZkHsAll"   : FFKsz7(self, BF(self.VVlJZC, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFKsz7(self, BF(self.VVlJZC, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV1LMJ"   : CCTrGQ.VV1LMJ(self)
   elif item == "VV7gfs"    : self.VV7gfs()
   elif item == "packagesFeeds"    : self.VVmIYA()
   else          : self.close()
 def VVY11d(self):
  extDirs  = FFcNRJ(VVUMIB)
  sysDirs  = FFcNRJ(VV8tIu)
  VVkGEY  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVkGEY.append((item, VVUMIB + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVkGEY.append((item, VV8tIu + item))
  if VVkGEY:
   VVkGEY.sort(key=lambda x: x[0].lower())
   VV0q2u = ("Package Info.", self.VVqqXu, [])
   VVyNdP = ("Open in File Manager", BF(self.VV5P24, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FF4zYj(self, None, header=header, VVkGEY=VVkGEY, VVsmwq=widths, VVdez8=28, VV0q2u=VV0q2u, VVyNdP=VVyNdP)
  else:
   FFoFqK(self, "Nothing found!")
 def VVqqXu(self, VVeDC2, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVUMIB) : loc = "extensions"
  elif path.startswith(VV8tIu) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV8RLD(package)
  else:
   FFoFqK(self, "No info!")
 def VVmIYA(self):
  pkg = FFik66()
  if pkg : FFm2b8(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFmApx(self)
 def VVipzn(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVy3eN(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVa91R + "\n"
    txt += VVy3eN("Number"   , str(c))
    txt += VVy3eN("Name"   , FFj5YA(str(p.name), VVNUk6))
    txt += VVy3eN("Path"  , p.path  )
    txt += VVy3eN("Description" , p.description )
    txt += VVy3eN("Icon"  , p.iconstr  )
    txt += VVy3eN("Wakeup Fnc" , p.wakeupfnc )
    txt += VVy3eN("NeedsRestart", p.needsRestart)
    txt += VVy3eN("Internal" , p.internal )
    txt += VVy3eN("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFcTZL(self, txt)
 def VViHNz(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVkGEY = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVkGEY.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVkGEY:
   VVkGEY.sort(key=lambda x: x[0].lower())
   VVyNdP = ("Open in File Manager", BF(self.VV5P24, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVkGEY, VVsmwq=widths, VVdez8=26, VVyNdP=VVyNdP)
  else:
   FFoFqK(self, "Nothing Found", title=title)
 def VV5P24(self, pathColNum, VVeDC2, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CC1TwY, mode=CC1TwY.VVW12q, VViJ7i=path)
  else    : FFgjbJ(VVeDC2, "Path not found !", 1500)
 @staticmethod
 def VV1LMJ(SELF):
  cmd = FFqitY(VV9WZR, "")
  if cmd : FFB1pa(SELF, cmd, checkNetAccess=True)
  else : FFmApx(SELF)
 def VV7gfs(self):
  pkg = FFik66()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFOPTX(self, txt)
 def VVlJZC(self, mode, grep, VVeDC2=None, title=""):
  if   mode == 0: cmd = FFqitY(VV0jlF    , grep)
  elif mode == 1: cmd = FFqitY(VV4P4m , grep)
  elif mode == 2: cmd = FFqitY(VV4P4m , grep)
  if not cmd:
   FFmApx(self)
   return
  VVzpbP = FFCpSv(cmd)
  if VVzpbP:
   err = CC1TwY.VVQSTE(VVzpbP, fromFind=False)
   if err:
    FFoFqK(self, err)
    return
  else:
   if VVeDC2: VVeDC2.VVtAan()
   FFoFqK(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVkGEY  = []
  for item in VVzpbP:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVkGEY.append((name, package, version))
  if mode > 0:
   extensions = FFCpSv("ls %s -l | grep '^d' | awk '{print $9}'" % VVUMIB)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVkGEY:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVkGEY.append((name, VVUMIB + item, "-"))
   systemPlugins = FFCpSv("ls %s -l | grep '^d' | awk '{print $9}'" % VV8tIu)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVkGEY:
      if item.lower() == row[0].lower():
       break
     else:
      VVkGEY.append((item, VV8tIu + item, "-"))
  if not VVkGEY:
   FFoFqK(self, "No packages found!")
   return
  if VVeDC2:
   VVkGEY.sort(key=lambda x: x[0].lower())
   VVeDC2.VV6IAT(VVkGEY, title)
  else:
   widths = (20, 50, 30)
   VVtaAK = None
   VVyNdP = None
   if mode == 0:
    VVJ6wE = ("Install" , self.VVoYHx   , [])
    VVtaAK = ("Download" , self.VVV36l   , [])
    VVyNdP = ("Filter"  , self.VVJ1Du , [])
   elif mode == 1:
    VVJ6wE = ("Uninstall", self.VV0ZkH, [])
   elif mode == 2:
    VVJ6wE = ("Uninstall", self.VV0ZkH, [])
    widths= (18, 57, 25)
   VVkGEY.sort(key=lambda x: x[0].lower())
   VV0q2u = ("Package Info.", self.VV4hA1, [])
   header   = ("Name" ,"Package" , "Version" )
   FF4zYj(self, None, header=header, VVkGEY=VVkGEY, VVsmwq=widths, VVdez8=28, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VV465R=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVghW2="#22110011", VVlnMM="#22191111", VValS2="#22191111", VVKJ4V="#00003030", VVEwGL="#00333333")
 def VV4hA1(self, VVeDC2, title, txt, colList):
  package = colList[1]
  self.VV8RLD(package)
 def VVJ1Du(self, VVeDC2, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVGtpd = []
  VVGtpd.append(("All Packages", "all"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVGtpd.append(VVttU7)
  for word in words:
   VVGtpd.append((word, word))
  FFINMf(self, BF(self.VVJbYg, VVeDC2), VVGtpd=VVGtpd, title="Select Filter")
 def VVJbYg(self, VVeDC2, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFKsz7(VVeDC2, BF(self.VVlJZC, 0, grep, VVeDC2, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV0ZkH(self, VVeDC2, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVUMIB, VV8tIu)):
   FFlEph(self, BF(self.VV5IMk, VVeDC2, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVGtpd = []
   VVGtpd.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVGtpd.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVGtpd.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFINMf(self, BF(self.VV1O8W, VVeDC2, package), VVGtpd=VVGtpd)
 def VV5IMk(self, VVeDC2, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVdxfj)
  FFB1pa(self, cmd, VVRBrK=BF(self.VVL5Pc, VVeDC2))
 def VV1O8W(self, VVeDC2, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVtksw
   elif item == "remove_ForceRemove"  : cmdOpt = VVPMkm
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV0drk
   FFlEph(self, BF(self.VVgA6I, VVeDC2, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVgA6I(self, VVeDC2, package, cmdOpt):
  self.lastSelectedRow = VVeDC2.VVUy0w()
  cmd = FFDHcv(cmdOpt, package)
  if cmd : FFB1pa(self, cmd, VVRBrK=BF(self.VVL5Pc, VVeDC2))
  else : FFmApx(self)
 def VVL5Pc(self, VVeDC2):
  VVeDC2.cancel()
  FFMq43()
 def VVoYHx(self, VVeDC2, title, txt, colList):
  package  = colList[1]
  VVGtpd = []
  VVGtpd.append(("Install Package"        , "install_CheckVersion" ))
  VVGtpd.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVGtpd.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVGtpd.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVGtpd.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFINMf(self, BF(self.VVHCkV, package), VVGtpd=VVGtpd)
 def VVHCkV(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVKyPA
   elif item == "install_ForceReinstall" : cmdOpt = VVOwmy
   elif item == "install_ForceOverwrite" : cmdOpt = VV3VA9
   elif item == "install_ForceDowngrade" : cmdOpt = VVLDPy
   elif item == "install_IgnoreDepends" : cmdOpt = VVqqpv
   FFlEph(self, BF(self.VVh4ui, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVh4ui(self, package, cmdOpt):
  cmd = FFDHcv(cmdOpt, package)
  if cmd : FFB1pa(self, cmd, VVRBrK=FFMq43, checkNetAccess=True)
  else : FFmApx(self)
 def VVV36l(self, VVeDC2, title, txt, colList):
  package  = colList[1]
  FFlEph(self, BF(self.VViDkS, package), "Download Package ?\n\n%s" % package)
 def VViDkS(self, package):
  if CCcrQv.VVTBsl():
   cmd = FFDHcv(VVSTsT, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFYHN3(success, VVTVTj))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFYHN3(fail, VVfzKO))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFB1pa(self, cmd, VVJIBF=[VVfzKO, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFmApx(self)
  else:
   FFoFqK(self, "No internet connection !")
 def VV8RLD(self, package):
  infoCmd  = FFDHcv(VVtENU, package)
  filesCmd = FFDHcv(VVBGkK, package)
  listInstCmd = FFqitY(VV4P4m, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFo3wt(VVNUk6)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFYHN3(notInst, VVXz72))
   cmd += "else "
   cmd +=   FFvibQ("System Info", VVNUk6)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFvibQ("Related Files", VVNUk6)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFpXhB(self, cmd)
  else:
   FFmApx(self)
class CCHhER():
 def VVt3Qs(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVy640()
 def VVy640(self):
  files = FFKQDF(VVFuxe, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVGtpd = []
   for fil in files:
    VVGtpd.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVghW2, VVlnMM = "#22221133", "#22221133"
   else    : VVghW2, VVlnMM = "#22003344", "#22002233"
   VVVLOF  = ("Add new File", self.VV5daY)
   FFINMf(self, self.VVfNok, VVGtpd=VVGtpd, width=1100, VVVLOF=VVVLOF, yellowBasePath="", minRows=4, VVghW2=VVghW2, VVlnMM=VVlnMM)
  else:
   FFlEph(self, self.VVsCi9, "No files found.\n\nCreate a new file ?")
 def VVsCi9(self):
  path = self.VVHBls()
  if fileExists(path) : self.VVy640()
  else    : FFgjbJ(self, "Cannot create file", 1500)
 def VV5daY(self, menuInstance, path):
  path = self.VVHBls()
  menuInstance.VVDznA((os.path.basename(path), path), isSort=True)
 def VVHBls(self):
  path = "%s%s%s.xml" % (VVFuxe, self.shareFilePrefix, FFbNWS())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVfNok(self, path=None):
  if path:
   FFKsz7(self, BF(self.VVNfKe, path))
 def VVNfKe(self, path):
  if not fileExists(path):
   FFE0MG(self, path)
   return
  elif not CC1TwY.VVVE2E(self, path, FFKNF8()):
   return
  else:
   self.shareFilePath = path
  if not CCfMYX.VVhhXR(self):
   return
  tree = CC5MnI.VV09qR(self, self.shareFilePath)
  if not tree:
   return
  refLst = CC3pKJ.VV2RZF()
  def VVy3eN(refCode):
   if   FFdW3e(refCode): return FFj5YA("DVB", VVlyaF)
   elif refCode in refLst     : return FFj5YA("IPTV", VVlyaF)
   else         : return ""
  VVzpbP= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVnpcz(ch)
   if ok:
    srcTxt = VVy3eN(srcRef)
    dstTxt = VVy3eN(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVzpbP:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVzpbP.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVzpbP:
   if self.shareIsRef : VVghW2, VVlnMM, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVghW2, VVlnMM, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVHUGA = (""    , BF(self.VVjUK5, dupl), [])
   VVXlcT = (""    , self.VVkCME    , [])
   VVJ6wE = ("Delete Entry" , self.VVCa9T   , [])
   VVtaAK = ("Add Entry"  , self.VVIy0w   , [])
   VV0q2u = (optTxt   , self.VVqr53  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVZq8i = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVeDC2 = FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=24, VVHUGA=VVHUGA, VVXlcT=VVXlcT, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VV0i4h=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VVlnMM, VVRaJ8="#00ffffaa", VVKJ4V="#0a000000")
  else:
   FFoFqK(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVjUK5(self, dupl, VVeDC2, title, txt, colList):
  if dupl:
   VVeDC2.VVdL9K("Skipped %d duplicate%s" % (dupl, FFLQjK(dupl)), 2000)
 def VVkCME(self, VVeDC2, title, txt, colList):
  def VVy3eN(key, val): return "%s\t: %s\n" % (key, val or FFj5YA("?", VVNNKJ))
  Keys = VVeDC2.VV07Cq()
  Vals = VVeDC2.VVxY0I()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVy3eN(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVTVTj, VVNNKJ
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFcTZL(self, txt + txt1, title=title)
 def VVnpcz(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVCa9T(self, VVeDC2, title, txt, colList):
  if VVeDC2.VVUy0w() == 0 and VVeDC2.VVz6J6() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFlEph(self, BF(self.VVMDWv, isLast, VVeDC2), ques)
 def VVMDWv(self, isLast, VVeDC2):
  if isLast:
   FF9qnP(self.shareFilePath)
   VVeDC2.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVeDC2.VVxY0I()
   if self.VVi5jm(srcName, srcRef, dstName, dstRef):
    VVeDC2.VV6b8U()
    VVeDC2.VVkSTY()
    FFgjbJ(VVeDC2, "Deleted", 500, isGrn=True)
   else:
    FFgjbJ(VVeDC2, "Cannot delete from file", 2000)
 def VVIy0w(self, VVeDC2, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVtERx(VVeDC2, isDvb=True)
  else    : self.VV8uyM(VVeDC2, "Source Channel", "#22003344", "#22002233")
 def VV8uyM(self, mainTableInst, title, VVghW2, VVlnMM):
  FFINMf(self, BF(self.VVuRl4, mainTableInst, title), VVGtpd=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVghW2=VVghW2, VVlnMM=VVlnMM)
 def VVuRl4(self, mainTableInst, title, item=None):
  if item:
   FFKsz7(mainTableInst, BF(self.VVOf01, mainTableInst, title, item), clearMsg=False)
 def VVOf01(self, mainTableInst, title, item):
  FFgjbJ(mainTableInst)
  if item == "DVB": self.VVtERx(mainTableInst, isDvb=True)
  else   : self.VVtERx(mainTableInst, isDvb=False)
 def VVfn0q(self, mainTableInst, chType, VVeDC2, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVeDC2.VVUy0w()
  if   chType == "DVB" : FFSmZ2(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFSmZ2(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVmbqa()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFoFqK(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVDSQd(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVydVv((str(mainTableInst.VVz6J6() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFgjbJ(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFgjbJ(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFgjbJ(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVtERx(mainTableInst, isDvb=False)
   else    : FFkWtI(BF(self.VV8uyM, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVeDC2.cancel()
 def VVcxrk(self, item, VVeDC2, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVeDC2.VVvFsV(ndx)
 def VVtERx(self, VVeDC2, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVfn0q, VVeDC2, typ)
  doneFnc = BF(self.VVcxrk, typ)
  if isDvb: CCHhER.VVl4E6(VVeDC2 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCHhER.VVPIqW(VVeDC2, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVl4E6(SELF, title, okFnc, doneFnc=None):
  FFKsz7(SELF, BF(CCHhER.VVGC2g, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVGC2g(SELF, title, okFnc, doneFnc=None):
  VVzpbP, err = CC5MnI.VV4kit(SELF, CC5MnI.VVFPgG)
  if VVzpbP:
   color = "#0a000022"
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVLseV = ("Select" , okFnc, [])
   VVHUGA= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVZq8i = (LEFT  , LEFT  , CENTER, LEFT    )
   FF4zYj(SELF, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVghW2=color, VVlnMM=color, VValS2=color, VVLseV=VVLseV, VVHUGA=VVHUGA, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFoFqK(SELF, "No DVB Services !")
 @staticmethod
 def VVPIqW(SELF, title, okFnc, doneFnc=None):
  FFKsz7(SELF, BF(CCHhER.VVTJ4a, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVTJ4a(SELF, title, okFnc, doneFnc=None):
  VVzpbP = CCHhER.VVGGq7()
  if VVzpbP:
   color = "#0a112211"
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVLseV = ("Select" , okFnc, [])
   VVHUGA= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FF4zYj(SELF, None, title=title, header=header, VVkGEY=VVzpbP, VVsmwq=widths, VVdez8=26, VVghW2=color, VVlnMM=color, VValS2=color, VVLseV=VVLseV, VVHUGA=VVHUGA, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFoFqK(SELF, "No IPTV Services !")
 @staticmethod
 def VVGGq7():
  VVzpbP = []
  files  = CCXWrP.VV26sg()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFEJE4(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVezVx = span.group(1)
    else : VVezVx = ""
    VVezVx_lCase = VVezVx.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVzpbP.append((chName, VVezVx, url, refCode))
  return VVzpbP
 def VVDSQd(self, srcName, srcRef, dstName, dstRef):
  tree = CC5MnI.VV09qR(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVwepP(tree, root)
  return True
 def VVi5jm(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CC5MnI.VV09qR(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVnpcz(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVwepP(tree, root)
  return found
 def VVwepP(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CC5MnI.VVGmJw(xmlTxt)
  parser = CC5MnI.CCQ4st()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVqr53(self, VVeDC2, title, txt, colList):
  if self.onlyEpg:
   self.VVn8Bs(VVeDC2, "epg")
  else:
   if self.shareIsRef:
    FFlEph(self, BF(FFKsz7, VVeDC2, BF(self.VVq4e3, VVeDC2)), "Copy all References from Source to Destination ?")
   else:
    VVGtpd = []
    VVGtpd.append(("Copy EPG\t (All List)" , "epg"  ))
    VVGtpd.append(("Copy Picons\t (All List)" , "picon" ))
    FFINMf(self, BF(self.VVn8Bs, VVeDC2), VVGtpd=VVGtpd, width=1000)
 def VVn8Bs(self, VVeDC2, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VV3r9u  , "EPG"
   elif item == "picon": fnc, txt = self.VVtG8Q , "PIcons"
   title = "Copy %s" % txt
   tot   = VVeDC2.VVz6J6()
   FFlEph(self, BF(FFKsz7, VVeDC2, BF(fnc, VVeDC2, title)), "Overwrite %s for %d Service%s ?" % (FFj5YA(txt, VVNUk6), tot, FFLQjK(tot)), title=title)
 def VVq4e3(self, VVeDC2):
  files = CCXWrP.VV26sg()
  totChange = 0
  if files:
   for path in files:
    txt = FFEJE4(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVeDC2.VVmbqa():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFEuF7()
  tot = VVeDC2.VVz6J6()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFcTZL(self, txt)
 def VVtG8Q(self, VVeDC2, title):
  if not iCopyfile:
   FFoFqK(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCMEuJ.VVaKDV()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVeDC2.VVmbqa():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVeDC2.VVz6J6()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFcTZL(self, txt, title=title)
 def VV3r9u(self, VVeDC2, title):
  txt, err = CC8SZQ.VVaxZY(VVeDC2, title)
  if err : FFoFqK(self, err, title=title)
  else : FFcTZL(self, txt, title=title)
 class CCQ4st(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VV09qR(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CC5MnI.CCQ4st())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFj5YA("XML Parse Error in:", VVNNKJ), path)
   txt += "%s\n%s\n\n" % (FFj5YA("Error:", VVNNKJ), str(e))
   FFcTZL(SELF, txt, VValS2="#11220000", title=title)
   return None
 @staticmethod
 def VVGmJw(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CC8SZQ(Screen, CCHhER):
 VV81A9  = "BDTSE"
 VVpO7n   = "save"
 VVctip   = "load"
 VV6WG1  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VVUJSe, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CC8SZQ.VVgDzx()
  qUrl, iptvRef = CCXWrP.VVE89T(self)
  VVGtpd = []
  VVGtpd.append((VVlyaF + "Cache File Info." , "inf"))
  VVGtpd.append(VVttU7)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVGtpd.append((t1, self.VVpO7n))
   VVGtpd.append((t2, self.VVctip))
  else:
   VVGtpd.append((t1, ))
   VVGtpd.append((t2, ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((VVXz72 + "Delete EPG (from RAM only)", self.VV6WG1))
  VVGtpd.append(VVttU7)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVGtpd.append((txt, "refreshIptvEPG" ))
  else        : VVGtpd.append((txt,     ))
  VVGtpd.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Translate Current Channel EPG %s(Experimental)" % VVXz72, "VVgjtz"))
  FFOh1m(self, VVGtpd=VVGtpd)
  self.onShown.append(self.VVP1sX)
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVoSHU()
   elif item in (self.VVpO7n, self.VVctip, self.VV6WG1):
    reset = item == self.VVctip
    FFlEph(self, BF(FFKsz7, self, BF(self.VVvono, item, reset)), VV7fsq="Continue ?")
   elif item == "refreshIptvEPG"  : CCXWrP.VV27Ot(self)
   elif item == "VVgjtz" : self.VVgjtz()
   elif item == "copyEpg"    : self.VVt3Qs(False, onlyEpg=True)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVvono(self, act, reset=False):
  ok = CC8SZQ.VVNkoO(act)
  if ok:
   if reset:
    CC8SZQ.VV35Wp(self)
   FFOPTX(self, "Done")
  else:
   FFOPTX(self, "Failed!")
 def VVoSHU(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CC8SZQ.VVgDzx()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFj5YA("File not found (check System EPG settings).", VVXz72))
   FFcTZL(self, txt, title=title)
  else:
   FFoFqK(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VV3qo8():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVgjtz(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVLseV  = (""  , BF(self.VVs5ST, title, True) , [])
  VVtaAK = ("Start" , BF(self.VVs5ST, title, False), [])
  VVyNdP = ("Change Language", self.VVTNDI      , [])
  widths  = (70 , 30)
  VVZq8i = (LEFT , CENTER)
  FF4zYj(self, None, title=title, VVkGEY=self.VVy6kv(), VVZq8i=VVZq8i, VVsmwq=widths, width=1200, vMargin=20, VVdez8=30, VVLseV=VVLseV, VVtaAK=VVtaAK, VVyNdP=VVyNdP, VVwTA1=2
    , VVghW2="#11201010", VVlnMM=bg, VValS2=bg, VVRaJ8="#00ffffaa", VVKJ4V="#00004455", VVEwGL=bg)
 def VVy6kv(self):
  Def, ch = "DISABLED", dict(CC8SZQ.VV3qo8())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVkGEY = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVkGEY
 def VVTNDI(self, VVeDC2, title, txt, colList):
  ndx = VVeDC2.VVUy0w()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCYEM7.VV2Dmg(self, confItem, title, lst=CC8SZQ.VV3qo8(), cbFnc=BF(self.VVHjRi, VVeDC2))
 def VVHjRi(self, VVeDC2):
  for ndx, row in enumerate(self.VVy6kv()):
   VVeDC2.VVTczo(ndx, row)
 def VVs5ST(self, Title, isAsk, VVeDC2, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFgjbJ(VVeDC2, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
   refCode, evList, err = CC8SZQ.VVtb2P(refCode)
   fnc = BF(self.VVvpNl, Title, refCode, evList, VVeDC2)
   if   err : FFoFqK(self, err, title=Title)
   elif isAsk : FFlEph(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVvpNl(self, title, refCode, evList, VVeDC2):
  self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVAVLQ, evList)
      , VV00AH = BF(self.VVmE58, title, refCode))
  VVeDC2.cancel()
 def VVAVLQ(self, evList, VVfBS1):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVfBS1.VV9WKz(totEv)
  VVfBS1.VVcdNf = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CC8SZQ.VVbQpg(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1)
   VVfBS1.VV5wHW(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVfBS1.VVcdNf = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVmE58(self, title, refCode, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVcdNf
  if newLst: totEv, totOK = CC8SZQ.VVavFa(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CC8SZQ.VVYZ0A()
   CC8SZQ.VV35Wp(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFcTZL(self, txt, title=title)
 @staticmethod
 def VVbQpg(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVy3eN(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CC8SZQ.VVZTaO(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVy3eN, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVZTaO(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFiBxf(txt))
   txt, err = CCXWrP.VVmjdi(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFgvCy(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CC8SZQ.VVKGMq(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVgDzx():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFkas1(path)
   szTxt = CC1TwY.VVBRyA(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVuMkR():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVYZ0A(): CC8SZQ.VVNkoO(CC8SZQ.VVpO7n)
 @staticmethod
 def VVNkoO(act):
  ec, inst = CC8SZQ.VVuMkR()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VV35Wp(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVtb2P(refCode):
  ec, inst = CC8SZQ.VVuMkR()
  if inst:
   try:
    evList = inst.lookupEvent([CC8SZQ.VV81A9, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVavFa(refCode, events, longDescDays=0):
  ec, inst = CC8SZQ.VVuMkR()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVmbsq(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CC8SZQ.VVuMkR()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CC8SZQ.VVorid(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CC40v5.CC8SZQ(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVorid(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CC8SZQ.VVsc5I(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VV3M3J(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CC8SZQ.VVuMkR()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CC8SZQ.VVorid(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FF5ivG(evTime)
       evEndTxt  = FF5ivG(evEnd)
       evDurTxt  = FF1ZBm(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FF1ZBm(evPos)
        evRem = evEnd - now
        evRemTxt = FF1ZBm(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FF1ZBm(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVsc5I(event):
  genre = PR = ""
  try:
   genre  = CC8SZQ.VV0Mkt(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CC8SZQ.VV5DEt(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VV5DEt(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV0Mkt(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CC8SZQ.VVE9E2()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVE9E2():
  path = VViEnD + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFEJE4(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFEJE4(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVaxZY(VVeDC2, title):
  ec, inst = CC8SZQ.VVuMkR()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVeDC2.VVmbqa():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CC8SZQ.VV81A9, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CC8SZQ.VVavFa(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CC8SZQ.VVYZ0A()
  txt  = "Services\t: %d\n"  % VVeDC2.VVz6J6()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVBt15(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CC8SZQ.VVBOwH(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CC8SZQ.VVBOwH(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CC8SZQ.VVBOwH(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVBOwH(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8SZQ.VVorid(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CC8SZQ.VVbQpg(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFj5YA(evName, VVMCs3)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFj5YA(evNameTransl, VVMCs3))
    if evTime           : txt += "Start Time\t: %s\n" % FF5ivG(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF5ivG(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF1ZBm(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF1ZBm(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF1ZBm(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFj5YA(evShort, VVM7JM)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFj5YA(evDesc , VVM7JM)
    if txt:
     txt = FFj5YA("\n%s\n%s Event:\n%s\n" % (VVa91R, ("Current", "Next")[evNum], VVa91R), VVMCs3) + txt
  return txt
 @staticmethod
 def VVKGMq(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CC5MnI(Screen, CCHhER):
 VVnras  = 0
 VVE6oZ = 1
 VVlT84  = 2
 VVfe3W  = 3
 VV4vFK = 4
 VVvv2B = 5
 VVFzjh = 6
 VVFPgG   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VVUJSe, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVsFhN = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVGtpd = self.VVgjVE()
  FFOh1m(self, VVGtpd=VVGtpd, title="Services/Channels")
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self["myMenu"].setList(self.VVgjVE())
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
 def VVgjVE(self):
  VVGtpd = []
  c = VVlyaF
  VVGtpd.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVGtpd.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVGtpd.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVGtpd.append(VVttU7)
  c = VVMCs3
  VVGtpd.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVGtpd.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVGtpd.append((VVNNKJ + "More tables ..."     , "VVROeu"    ))
  c = VVM7JM
  VVGtpd.append(VVttU7)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVGtpd.append((c + txt          , "VVadtq"  ))
  else : VVGtpd.append((txt           ,          ))
  VVGtpd.append((c + 'Export Services to "channels.xml"'    , "VVuvdE"      ))
  VVGtpd.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVAjMy
  VVGtpd.append(VVttU7)
  VVGtpd.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVGtpd.append((c + "Invalid Services Cleaner"       , "VV0h66"    ))
  c = VVAjMy
  VVGtpd.append(VVttU7)
  VVGtpd.append((c + "Delete Channels with no names"     , "VVf6Cg"    ))
  VVGtpd.append((c + "Delete Empty Bouquets"       , "VVk7rD"     ))
  VVGtpd.append(VVttU7)
  VVrqSy, VVJ0hD = CC5MnI.VVE0Bv()
  if fileExists(VVrqSy):
   enab = fileExists(VVJ0hD)
   if enab: VVGtpd.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVGtpd.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVGtpd.append(("Reset Parental Control Settings"      , "VV4fvO"    ))
  VVGtpd.append(("Reload Channels and Bouquets"       , "VVVKDS"      ))
  return VVGtpd
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCi57e.VVnjtb(self.session)
   elif item == "openSignal"       : FFh1dN(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFeMt4(self, fncMode=CC40v5.VVxue5)
   elif item == "lameDB_allChannels_with_refCode"  : FFKsz7(self, self.VVPnQ7)
   elif item == "lameDB_allChannels_with_tranaponder" : FFKsz7(self, self.VVt29w)
   elif item == "VVROeu"     : self.VVROeu()
   elif item == "VVadtq"  : CCzej8.VVadtq(self)
   elif item == "VVuvdE"      : self.VVuvdE()
   elif item == "copyEpgPicons"      : self.VVt3Qs(False)
   elif item == "SatellitesCleaner"     : FFKsz7(self, self.FFKsz7_SatellitesCleaner)
   elif item == "VV0h66"    : FFKsz7(self, BF(self.VV0h66))
   elif item == "VVf6Cg"    : FFKsz7(self, self.VVf6Cg)
   elif item == "VVk7rD"     : self.VVk7rD(self)
   elif item == "enableHiddenChannels"     : self.VVjpKY(True)
   elif item == "disableHiddenChannels"    : self.VVjpKY(False)
   elif item == "VV4fvO"    : FFlEph(self, self.VV4fvO, "Reset and Restart ?")
   elif item == "VVVKDS"      : FFKsz7(self, BF(CC5MnI.VVVKDS, self))
 def VVROeu(self):
  VVGtpd = []
  VVGtpd.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVGtpd.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVGtpd.append(("Services with PIcons for the System"  , "VVkrOe"    ))
  VVGtpd.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVGtpd.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFINMf(self, self.VVFsl2, VVGtpd=VVGtpd, title="Service Information", VVOvZt=True)
 def VVFsl2(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFKsz7(self, BF(self.VVSYDW, title))
   elif ref == "parentalControlChannels"   : FFKsz7(self, BF(self.VVEnr6, title))
   elif ref == "showHiddenChannels"    : FFKsz7(self, BF(self.VVIt36, title))
   elif ref == "VVkrOe"    : FFKsz7(self, BF(self.VV2Jp6, title))
   elif ref == "servicesWithMissingPIcons"   : FFKsz7(self, BF(self.VVDe4J, title))
   elif ref == "TranspondersStats"     : FFKsz7(self, BF(self.VVmTfM, title))
   elif ref == "SatellitesXmlStats"    : FFKsz7(self, BF(self.VVIutN, title))
 def VVuvdE(self):
  VVGtpd = []
  VVGtpd.append(("All DVB-S/C/T Services", "all"))
  VVGtpd.extend(CC3pKJ.VVuwX4())
  FFINMf(self, self.VVrgT5, VVGtpd=VVGtpd, title="", VVOvZt=True)
 def VVrgT5(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CC5MnI.VVDqxo("1:7:")
   else   : lst = FFsmA3(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFFJgS(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFXaBx(r)  : sat = "Stream Relay"
       elif FFBTpz(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFoR3R(CFG.exportedTablesPath.getValue()), FFbNWS())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFOPTX(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFgjbJ(self, "No Services found !", 1500)
 @staticmethod
 def VVVKDS(SELF):
  FFEuF7()
  FFOPTX(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVPnQ7(self):
  self.VVsFhN = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZt3D(self)
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVnras)
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVLseV  = ("Zap"   , self.VV1dzU     , [])
   VVXlcT = (""    , self.VV1AnQ   , [])
   VV0q2u = ("Options"  , self.VVIIin , [])
   VVtaAK = ("Current Service", self.VVRJZ2 , [])
   VVyNdP = ("Filter"   , self.VVy7SP  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVZq8i  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindServices)
 def VVt29w(self):
  self.VVsFhN = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZt3D(self)
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVE6oZ)
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVLseV  = ("Zap"   , self.VV1dzU      , [])
   VVXlcT = (""    , self.VV1AnQ    , [])
   VVtaAK = ("Current Service", self.VVRJZ2  , [])
   VV0q2u = ("Options"  , self.VV4jGi , [])
   VVyNdP = ("Filter"   , self.VVtlZ7  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVZq8i  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindServices)
 def VVIIin(self, VVeDC2, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCqt6h(self, VVeDC2)
  VVGtpd = []
  isMulti = VVeDC2.VVFCH5
  if isMulti:
   refCodeList = VVeDC2.VV2oru(3)
   if refCodeList:
    VVGtpd.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVGtpd.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVGtpd.append(VVttU7)
    VVGtpd.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVGtpd.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVGtpd.append(VVttU7)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVGtpd.append((txt1, "parentalControl_add" ))
    VVGtpd.append((txt2,        ))
   else:
    VVGtpd.append((txt1,       ))
    VVGtpd.append((txt2, "parentalControl_remove" ))
   VVGtpd.append(VVttU7)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVGtpd.append((txt1, "hiddenServices_add"  ))
    VVGtpd.append((txt2,       ))
   else:
    VVGtpd.append((txt1,        ))
    VVGtpd.append((txt2, "hiddenServices_remove" ))
   VVGtpd.append(VVttU7)
  cbFncDict = { "parentalControl_add"   : BF(self.VVq0eN, VVeDC2, refCode, True)
     , "parentalControl_remove"  : BF(self.VVq0eN, VVeDC2, refCode, False)
     , "hiddenServices_add"   : BF(self.VVDDsb, VVeDC2, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVDDsb, VVeDC2, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVrmKX, VVeDC2, True)
     , "parentalControl_sel_remove" : BF(self.VVrmKX, VVeDC2, False)
     , "hiddenServices_sel_add"  : BF(self.VVRRhE, VVeDC2, True)
     , "hiddenServices_sel_remove" : BF(self.VVRRhE, VVeDC2, False)
     }
  VVGtpd1, cbFncDict1 = CC5MnI.VVmgn7(self, VVeDC2, servName, 3)
  VVGtpd.extend(VVGtpd1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVO5ex(VVGtpd, cbFncDict)
 def VV4jGi(self, VVeDC2, title, txt, colList):
  servName = colList[0]
  mSel = CCqt6h(self, VVeDC2)
  VVGtpd, cbFncDict = CC5MnI.VVmgn7(self, VVeDC2, servName, 3)
  mSel.VVO5ex(VVGtpd, cbFncDict)
 @staticmethod
 def VVmgn7(SELF, VVeDC2, servName, refCodeCol):
  tot = VVeDC2.VVau1b()
  if tot > 0:
   sTxt = FFj5YA("%d Service%s" % (tot, FFLQjK(tot)), VVMCs3)
   VVGtpd = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFg0L0(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFj5YA(servName, VVMCs3)
   VVGtpd = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CC5MnI.VV37TL, SELF, VVeDC2, refCodeCol, True)
     , "addToBouquet_one" : BF(CC5MnI.VV37TL, SELF, VVeDC2, refCodeCol, False)
     }
  return VVGtpd, cbFncDict
 @staticmethod
 def VV37TL(SELF, VVeDC2, refCodeCol, isMulti):
  picker = CC3pKJ(SELF, VVeDC2, "Add to Bouquet", BF(CC5MnI.VVBGsF, VVeDC2, refCodeCol, isMulti))
 @staticmethod
 def VVBGsF(VVeDC2, refCodeCol, isMulti):
  if isMulti : refCodeList = VVeDC2.VV2oru(refCodeCol)
  else  : refCodeList = [VVeDC2.VVxY0I()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVq0eN(self, VVeDC2, refCode, isAddToBlackList):
  VVeDC2.VVaLck("Processing ...")
  FFkWtI(BF(self.VVb72C, VVeDC2, [refCode], isAddToBlackList))
 def VVrmKX(self, VVeDC2, isAddToBlackList):
  refCodeList = VVeDC2.VV2oru(3)
  if not refCodeList:
   FFoFqK(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVeDC2.VVaLck("Processing ...")
  FFkWtI(BF(self.VVb72C, VVeDC2, refCodeList, isAddToBlackList))
 def VVb72C(self, VVeDC2, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVJO6z, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVJO6z):
   lines = FF8eQ2(VVJO6z)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVJO6z, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVeDC2.VVFCH5
   if isMulti:
    self.VVGipn(VVeDC2, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVfL1s(VVeDC2, refCode)
    VVeDC2.VVtAan()
  else:
   VVeDC2.VVdL9K("No changes")
 def VVDDsb(self, VVeDC2, refCode, isHide):
  title = "Change Hidden State"
  if FFdW3e(refCode):
   VVeDC2.VVaLck("Processing ...")
   ret = FFd0nh(refCode, isHide)
   if ret : FFKsz7(self, BF(self.VVfL1s, VVeDC2, refCode))
   else : FFoFqK(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFoFqK(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVfL1s(self, VVeDC2, refCode):
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVnras, VVgdul=[3, [refCode], False])
  done = False
  if VVzpbP:
   data = VVzpbP[0]
   if data[3] == refCode:
    done = VVeDC2.VVji2V(data)
  if not done:
   self.VVuyMA(VVeDC2, VVeDC2.VVpmbi(), self.VVnras)
  VVeDC2.VVtAan()
 def VVGipn(self, VVeDC2, totRefCodes):
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVnras, VVgdul=self.VVsFhN)
  VVeDC2.VV6IAT(VVzpbP)
  VVeDC2.VVMWca(False)
  VVeDC2.VVdL9K("%d Processed" % totRefCodes)
 def VVRRhE(self, VVeDC2, isHide):
  refCodeList = VVeDC2.VV2oru(3)
  if not refCodeList:
   FFoFqK(self, "Nothing selected", title="Change Hidden State")
   return
  VVeDC2.VVaLck("Processing ...")
  FFkWtI(BF(self.VV8OHh, VVeDC2, refCodeList, isHide))
 def VV8OHh(self, VVeDC2, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFd0nh(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFEuF7(True)
   self.VVGipn(VVeDC2, len(refCodeList))
  else:
   VVeDC2.VVdL9K("No changes")
 def VVy7SP(self, VVeDC2, title, txt, colList):
  inFilterFnc = BF(self.VVQcCW, VVeDC2) if self.VVsFhN else None
  self.filterObj.VVGJJx(1, VVeDC2, 2, BF(self.VVaZpf, VVeDC2), inFilterFnc=inFilterFnc)
 def VVaZpf(self, VVeDC2, item):
  self.VViGlk(VVeDC2, False, item, 2, self.VVnras)
 def VVQcCW(self, VVeDC2, menuInstance, item):
  self.VViGlk(VVeDC2, True, item, 2, self.VVnras)
 def VVtlZ7(self, VVeDC2, title, txt, colList):
  inFilterFnc = BF(self.VVb806, VVeDC2) if self.VVsFhN else None
  self.filterObj.VVGJJx(2, VVeDC2, 4, BF(self.VV7vYx, VVeDC2), inFilterFnc=inFilterFnc)
 def VV7vYx(self, VVeDC2, item):
  self.VViGlk(VVeDC2, False, item, 4, self.VVE6oZ)
 def VVb806(self, VVeDC2, menuInstance, item):
  self.VViGlk(VVeDC2, True, item, 4, self.VVE6oZ)
 def VVjO8E(self, VVeDC2, title, txt, colList):
  inFilterFnc = BF(self.VV536x, VVeDC2) if self.VVsFhN else None
  self.filterObj.VVGJJx(0, VVeDC2, 4, BF(self.VV1GcW, VVeDC2), inFilterFnc=inFilterFnc)
 def VV1GcW(self, VVeDC2, item):
  self.VViGlk(VVeDC2, False, item, 4, self.VVlT84)
 def VV536x(self, VVeDC2, menuInstance, item):
  self.VViGlk(VVeDC2, True, item, 4, self.VVlT84)
 def VViGlk(self, VVeDC2, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVeDC2.VVhJef(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVsFhN = None
  else:
   words, asPrefix = CCZt3D.VVvY0h(words)
   self.VVsFhN = [col, words, asPrefix]
  if words: FFKsz7(VVeDC2, BF(self.VVuyMA, VVeDC2, title, mode), clearMsg=False)
  else : FFgjbJ(VVeDC2, "Incorrect filter", 2000)
 def VVuyMA(self, VVeDC2, title, mode):
  VVzpbP, err = CC5MnI.VV4kit(self, mode, VVgdul=self.VVsFhN, VVa1kB=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVeDC2.VVmbqa():
    try:
     ndx = VVzpbP.index(tuple(list(map(str.strip, row))))
     lst.append(VVzpbP[ndx])
    except:
     pass
   VVzpbP = lst
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVeDC2.VV6IAT(VVzpbP, title)
  else:
   FFgjbJ(VVeDC2, "Not found!", 1500)
 def VVFFTl(self, title, VVkGEY, VVLseV=None, VVXlcT=None, VVJ6wE=None, VVtaAK=None, VV0q2u=None, VVyNdP=None):
  VVtaAK = ("Current Service", self.VVRJZ2, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVZq8i = (LEFT  , LEFT  , CENTER, LEFT    )
  FF4zYj(self, None, title=title, header=header, VVkGEY=VVkGEY, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindServices)
 def VVRJZ2(self, VVeDC2, title, txt, colList):
  self.VVlBjA(VVeDC2)
 def VVNkRG(self, VVeDC2, title, txt, colList):
  self.VVlBjA(VVeDC2, True)
 def VVlBjA(self, VVeDC2, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVeDC2.VVWrIi(colDict, VVjHD0=True)
   else:
    VVeDC2.VV6eK5(3, refCode, True)
   return
  FFoFqK(self, "Cannot read current Reference Code !")
 def VVSYDW(self, title):
  self.VVsFhN = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZt3D(self)
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVlT84)
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVXlcT = (""    , self.VVF9BT , []      )
   VVtaAK = ("Current Service", self.VVNkRG  , []      )
   VVyNdP = ("Filter"   , self.VVjO8E   , [], "Loading Filters ..." )
   VVLseV  = ("Zap"   , self.VV0wRA      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVZq8i  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVtaAK=VVtaAK, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindServices)
 def VVF9BT(self, VVeDC2, title, txt, colList):
  refCode  = self.VVofU6(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFeMt4(self, fncMode=CC40v5.VVGwv9, refCode=refCode, chName=chName, text=txt)
 def VV0wRA(self, VVeDC2, title, txt, colList):
  refCode = self.VVofU6(colList)
  FF4utl(self, refCode)
 def VV1dzU(self, VVeDC2, title, txt, colList):
  FF4utl(self, colList[3])
 def VVofU6(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVtBbO(VVrqSy, mode=0):
  lines = FF8eQ2(VVrqSy, encLst=["UTF-8"])
  return CC5MnI.VVEzir(lines, mode)
 @staticmethod
 def VVEzir(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VV4kit(SELF, mode, VVgdul=None, VVa1kB=True, VVjxU1=True):
  VVrqSy, err = CC5MnI.VVPohR(SELF, VVjxU1)
  if err:
   return None, err
  asPrefix = False
  if VVgdul:
   filterCol = VVgdul[0]
   filterWords = VVgdul[1]
   asPrefix = VVgdul[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CC5MnI.VVnras:
   blackList = None
   if fileExists(VVJO6z):
    blackList = FF8eQ2(VVJO6z)
    if blackList:
     blackList = set(blackList)
  elif mode == CC5MnI.VVE6oZ:
   tp = CCNm5S()
  VVGKcu, VVfTgd = FFsyUd()
  if mode in (CC5MnI.VVvv2B, CC5MnI.VVFzjh):
   VVzpbP = {}
  else:
   VVzpbP = []
  tagFound = False
  with ioOpen(VVrqSy, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFEBso(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CC5MnI.VVlT84:
       if sTypeInt in VVGKcu:
        STYPE = VVfTgd[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVzpbP.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVzpbP.append(tRow)
       else:
        VVzpbP.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CC5MnI.VVFPgG:
        VVzpbP.append((chName, chProv, sat, refCode))
       elif mode == CC5MnI.VVvv2B:
        VVzpbP[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CC5MnI.VVFzjh:
        VVzpbP[chName] = refCode
       elif mode == CC5MnI.VVnras:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVzpbP.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVzpbP.append(tRow)
        else:
         VVzpbP.append(tRow)
       elif mode == CC5MnI.VVE6oZ:
        if sTypeInt in VVGKcu:
         STYPE = VVfTgd[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVcq92(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVzpbP.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVzpbP.append(tRow)
        else:
         VVzpbP.append(tRow)
       elif mode == CC5MnI.VVfe3W:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVzpbP.append((chName, chProv, sat, refCode))
       elif mode == CC5MnI.VV4vFK:
        VVzpbP.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVzpbP and VVa1kB:
   FFoFqK(SELF, "No services found!")
  return VVzpbP, ""
 def VVEnr6(self, title):
  if fileExists(VVJO6z):
   lines = FF8eQ2(VVJO6z)
   if lines:
    newRows = []
    VVzpbP, err = CC5MnI.VV4kit(self, self.VV4vFK)
    if VVzpbP:
     lines = set(lines)
     for item in VVzpbP:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVzpbP = newRows
      VVzpbP.sort(key=lambda x: x[0].lower())
      VVXlcT = ("", self.VV1AnQ, [])
      VVLseV = ("Zap", self.VV1dzU, [])
      self.VVFFTl(title, VVzpbP, VVLseV=VVLseV, VVXlcT=VVXlcT)
     else:
      FFcTZL(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVzpbP)))
   else:
    FFOPTX(self, "No active Parental Control services.", FFKNF8())
  else:
   FFE0MG(self, VVJO6z)
 def VVIt36(self, title):
  VVzpbP, err = CC5MnI.VV4kit(self, self.VVfe3W)
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVXlcT = ("" , self.VV1AnQ, [])
   VVLseV  = ("Zap", self.VV1dzU, [])
   self.VVFFTl(title, VVzpbP, VVLseV=VVLseV, VVXlcT=VVXlcT)
  elif err:
   pass
  else:
   FFOPTX(self, "No hidden services.", FFKNF8())
 def VV0h66(self):
  title = "Services unused in Tuner Configuration"
  VVrqSy, err = CC5MnI.VVPohR(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CC5MnI.VVeDBV()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVtC6P(str(item[0]))
    nsLst.add(ns)
  sysLst = CC5MnI.VVDqxo("1:7:")
  tpLst  = CC5MnI.VVtBbO(VVrqSy, mode=1)
  VVzpbP = []
  for refCode, chName in sysLst:
   servID = CC5MnI.VVEH7o(refCode)
   tpID = CC5MnI.VVDi2X(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVzpbP.append((chName, FFFJgS(refCode, False), refCode, servID))
  if VVzpbP:
   VVzpbP.sort(key=lambda x: x[0].lower())
   VV0q2u = ("Options"   , BF(self.VV7Ppo, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVZq8i  = (LEFT  , CENTER , LEFT   , CENTER   )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VV0q2u=VV0q2u, VVghW2="#0a001122", VVlnMM="#0a001122", VValS2="#0a001122", VVKJ4V="#00004455", VVEwGL="#0a333333", VVtDKG="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFOPTX(self, "No invalid service found !", title=title)
 def VV7Ppo(self, Title, VVeDC2, title, txt, colList):
  mSel = CCqt6h(self, VVeDC2)
  isMulti = VVeDC2.VVFCH5
  if isMulti : txt = "Remove %s Services" % FFj5YA(str(VVeDC2.VVau1b()), VVNNKJ)
  else  : txt = "Remove : %s" % FFj5YA(VVeDC2.VVxY0I()[0], VVNNKJ)
  VVGtpd = [(txt, "del")]
  cbFncDict = {"del": BF(FFKsz7, VVeDC2, BF(self.VVwQxf, VVeDC2, Title))}
  mSel.VVO5ex(VVGtpd, cbFncDict)
 def VVwQxf(self, VVeDC2, title):
  VVrqSy, err = CC5MnI.VVPohR(self, title=title)
  if err:
   return
  isMulti = VVeDC2.VVFCH5
  skipLst = []
  if isMulti : skipLst = VVeDC2.VV2oru(3)
  else  : skipLst = [VVeDC2.VVxY0I()[3]]
  tpLst = CC5MnI.VVtBbO(VVrqSy, mode=0)
  servLst = CC5MnI.VVtBbO(VVrqSy, mode=10)
  tmpDbFile = VVrqSy + ".tmp"
  lines   = FF8eQ2(VVrqSy)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFN2Os("mv -f '%s' '%s'" % (tmpDbFile, VVrqSy)))
  VVzpbP = []
  for row in VVeDC2.VVmbqa():
   if not row[3] in skipLst:
    VVzpbP.append(row)
  FFEuF7()
  FFcTZL(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVzpbP:
   VVeDC2.VV6IAT(VVzpbP, title)
   VVeDC2.VVMWca(False)
  else:
   VVeDC2.cancel()
 def VVmTfM(self, title):
  VVrqSy, err = CC5MnI.VVPohR(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV3G9y(VVrqSy)
  txt = FFj5YA("Total Transponders:\n\n", VVFiA5)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFj5YA("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVFiA5)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF3fLh(item), satList.count(item))
  FFcTZL(self, txt, title)
 def VV3G9y(self, VVrqSy):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVrqSy, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVIutN(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFE0MG(self, path, title=title)
   return
  elif not CC1TwY.VVVE2E(self, path, title):
   return
  if not CCfMYX.VVhhXR(self):
   return
  tree = CC5MnI.VV09qR(self, path, title=title)
  if not tree:
   return
  VVzpbP = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFEBso(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVzpbP.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVzpbP:
   VVzpbP.sort(key=lambda x: int(x[1]))
   VVtaAK = ("Current Satellite", BF(self.VV9rni, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVZq8i  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=25, VVO3NV=1, VVtaAK=VVtaAK, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFoFqK(self, "No data found !", title=title)
 def VV9rni(self, satCol, VVeDC2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  sat = FFFJgS(refCode, False)
  for ndx, row in enumerate(VVeDC2.VVmbqa()):
   if sat == row[satCol].strip():
    VVeDC2.VVvFsV(ndx)
    break
  else:
   FFgjbJ(VVeDC2, "No listed !", 1500)
 def FFKsz7_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFoFqK(self, "No Satellites found !")
   return
  usedSats = CC5MnI.VVeDBV()
  VVzpbP = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVzpbP.append((sat[1], posTxt, FFEBso(sat[0]), tuners, str(posVal)))
  if VVzpbP:
   VValS2 = "#11222222"
   VVzpbP.sort(key=lambda x: int(x[1]))
   VVtaAK = ("Current Satellite" , BF(self.VV9rni, 2) , [])
   VV0q2u = ("Options"   , self.VVzV9R  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVZq8i  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVghW2=VValS2, VVlnMM=VValS2, VValS2=VValS2, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFoFqK(self, "No data found !")
 def VVzV9R(self, VVeDC2, title, txt, colList):
  mSel = CCqt6h(self, VVeDC2)
  isMulti = VVeDC2.VVFCH5
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFj5YA(str(VVeDC2.VVau1b()), VVNNKJ)
  else  : txt = "Remove ALL Services on : %s" % FFj5YA(VVeDC2.VVxY0I()[0], VVNNKJ)
  VVGtpd = []
  VVGtpd.append((txt, "deleteSat"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Delete Empty Bouquets", "VVk7rD"))
  cbFncDict = { "deleteSat"   : BF(FFKsz7, VVeDC2, BF(self.VVyq2b, VVeDC2))
     , "VVk7rD" : BF(self.VVk7rD, VVeDC2)
     }
  mSel.VVO5ex(VVGtpd, cbFncDict)
 def VVyq2b(self, VVeDC2):
  posLst = []
  isMulti = VVeDC2.VVFCH5
  posLst = []
  if isMulti : posLst = VVeDC2.VV2oru(4)
  else  : posLst = [VVeDC2.VVxY0I()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVtC6P(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVW2w5(nsLst)
  FFEuF7(True)
  FFcTZL(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVk7rD(self, winObj):
  title = "Delete Empty Bouquets"
  FFlEph(self, BF(FFKsz7, winObj, BF(self.VVbe71, title)), "Delete bouquets with no services ?", title=title)
 def VVbe71(self, title):
  bList = CC3pKJ.VV0taO()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CC3pKJ.VVVpEV(bRef)
    bPath = VVCQ1V + bFile
    FF9qnP(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVCQ1V + fil
     if fileExists(path):
      lines = FF8eQ2(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFEuF7(True)
  if bNames: txt = "%s\n\n%s" % (FFj5YA("Deleted Bouquets:", VVMCs3), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFcTZL(self, txt, title=title)
 def VVtC6P(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVW2w5(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVCQ1V)
  for srcF in files:
   if fileExists(srcF):
    lines = FF8eQ2(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFL7ha(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV2Jp6(self, title)   : self.VVkrOe(title, True)
 def VVDe4J(self, title) : self.VVkrOe(title, False)
 def VVkrOe(self, title, isWithPIcons):
  piconsPath = CCMEuJ.VVaKDV()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCMEuJ.VV7Acb(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVzpbP, err = CC5MnI.VV4kit(self, self.VV4vFK)
    if VVzpbP:
     channels = []
     for (chName, chProv, sat, refCode) in VVzpbP:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFyVqp(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVzpbP)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVy3eN(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVy3eN("PIcons Path"  , piconsPath)
     txt += VVy3eN("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVy3eN("Total services" , totalServices)
     txt += VVy3eN("With PIcons"  , totalWithPIcons)
     txt += VVy3eN("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFcTZL(self, txt)
     else:
      VVXlcT     = (""      , self.VV1AnQ , [])
      if isWithPIcons : VVyNdP = ("Export Current PIcon", self.VVdFSA  , [])
      else   : VVyNdP = None
      VV0q2u     = ("Statistics", FFcTZL, [txt])
      VVLseV      = ("Zap", self.VV1dzU, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVFFTl(title, channels, VVLseV=VVLseV, VVXlcT=VVXlcT, VV0q2u=VV0q2u, VVyNdP=VVyNdP)
   else:
    FFoFqK(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFoFqK(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VV1AnQ(self, VVeDC2, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFeMt4(self, fncMode=CC40v5.VVGwv9, refCode=refCode, chName=chName, text=txt)
 def VVdFSA(self, VVeDC2, title, txt, colList):
  png, path = CCMEuJ.VVtrJq(colList[3], colList[0])
  if path:
   CCMEuJ.VVNRSI(self, png, path)
 @staticmethod
 def VVE0Bv():
  VVrqSy  = "%slamedb" % VVCQ1V
  VVJ0hD = "%slamedb.disabled" % VVCQ1V
  return VVrqSy, VVJ0hD
 @staticmethod
 def VVsNuD():
  VVHwX2  = "%slamedb5" % VVCQ1V
  VVaMCM = "%slamedb5.disabled" % VVCQ1V
  return VVHwX2, VVaMCM
 def VVjpKY(self, isEnable):
  VVrqSy, VVJ0hD = CC5MnI.VVE0Bv()
  if isEnable and not fileExists(VVJ0hD):
   FFOPTX(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVrqSy):
   FFoFqK(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFlEph(self, BF(self.VVG2xx, isEnable), "%s Hidden Channels ?" % word)
 def VVG2xx(self, isEnable):
  VVrqSy , VVJ0hD = CC5MnI.VVE0Bv()
  VVHwX2, VVaMCM = CC5MnI.VVsNuD()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVJ0hD, VVJ0hD, VVrqSy)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVaMCM, VVaMCM, VVHwX2)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVrqSy  , VVrqSy , VVJ0hD)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVHwX2 , VVHwX2, VVaMCM)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVJ0hD, VVrqSy )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVaMCM, VVHwX2)
  res = os.system(cmd)
  FFEuF7()
  if res == 0 : FFOPTX(self, "Hidden List %s" % word)
  else  : FFoFqK(self, "Error while restoring:\n\n%s" % fileName)
 def VV4fvO(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVCQ1V
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVCQ1V
  FFe3vO(self, cmd)
 def VVf6Cg(self):
  VVrqSy, err = CC5MnI.VVPohR(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FF9qnP(tmpFile)
  totChan = totRemoved = 0
  lines = FF8eQ2(VVrqSy, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFlEph(self, BF(FFKsz7, self, BF(self.VVR1L4, tmpFile, VVrqSy, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFLQjK(totRemoved), totChan, FFLQjK(totChan))
      , callBack_No=BF(self.VVAP8F, tmpFile))
  else:
   FFcTZL(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVR1L4(self, tmpFile, VVrqSy, totRemoved, totChan):
  os.system(FFN2Os("mv -f '%s' '%s'" % (tmpFile, VVrqSy)))
  FFEuF7()
  FFcTZL(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVAP8F(self, tmpFile):
  FF9qnP(tmpFile)
 @staticmethod
 def VVPohR(SELF, VVjxU1=True, title=""):
  VVrqSy, VVJ0hD = CC5MnI.VVE0Bv()
  if   not fileExists(VVrqSy)       : err = "File not found !\n\n%s" % VVrqSy
  elif not CC1TwY.VVVE2E(SELF, VVrqSy) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVjxU1:
   FFoFqK(SELF, err, title=title)
  return VVrqSy, err
 @staticmethod
 def VVDi2X(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVEH7o(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVDqxo(servTypes):
  VVmPIJ  = eServiceCenter.getInstance()
  VVh8Ps   = '%s ORDER BY name' % servTypes
  VVRNvD   = eServiceReference(VVh8Ps)
  VVaf7U = VVmPIJ.list(VVRNvD)
  if VVaf7U: return VVaf7U.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVeDBV():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CC40v5(Screen):
 VVxue5  = 0
 VVCnGh   = 1
 VVE80m   = 2
 VVGwv9    = 3
 VVxHFg    = 4
 VVQ6yY   = 5
 VVED5C   = 6
 VVHyY2    = 7
 VVwyS7   = 8
 VVNv6g   = 9
 VVmvGX   = 10
 VV732k   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFkttW(VVgBg4, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVxue5)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFj5YA("%s\n", VVky8q) % VVa91R
  self.picViewer  = None
  FFOh1m(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVChWx })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self["myLabel"].VVP4jT(outputFileToSave="chann_info")
  if   self.fncMode == self.VVxue5 : fnc = self.VVQdEq
  elif self.fncMode == self.VVCnGh  : fnc = self.VVQdEq
  elif self.fncMode == self.VVE80m  : fnc = self.VVQdEq
  elif self.fncMode == self.VVGwv9  : fnc = self.VVevIk
  elif self.fncMode == self.VVxHFg  : fnc = self.VV9XQl
  elif self.fncMode == self.VVQ6yY  : fnc = self.VVxvbM
  elif self.fncMode == self.VVED5C  : fnc = self.VVd0Jl
  elif self.fncMode == self.VVHyY2  : fnc = self.VVHVLR
  elif self.fncMode == self.VVwyS7  : fnc = self.VV6eEP
  elif self.fncMode == self.VVNv6g : fnc = self.VVd908
  elif self.fncMode == self.VVmvGX  : fnc = self.VV8dvs
  elif self.fncMode == self.VV732k : fnc = self.VV6Oj0
  self["myLabel"].setText("\n   Reading Info ...")
  FFkWtI(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVNdUh()
 def VVdeA1(self, err):
  self["myLabel"].setText(err)
  FFZM4C(self["myTitle"], "#22200000")
  FFZM4C(self["myBody"], "#22200000")
  self["myLabel"].VVN2D3("#22200000")
  self["myLabel"].VVPcFJ()
 def VVQdEq(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  self.refCode = refCode
  self.VVpR5a(chName)
 def VVevIk(self):
  self.VVpR5a(self.chName)
 def VV9XQl(self):
  self.VVpR5a(self.chName)
 def VVxvbM(self):
  self.VVpR5a(self.chName)
 def VVd0Jl(self):
  self.VVpR5a("Picon Info")
 def VVHVLR(self):
  self.VVpR5a(self.chName)
 def VV6eEP(self):
  self.VVpR5a(self.chName)
 def VVd908(self):
  self.VVpR5a(self.chName)
 def VV8dvs(self):
  self.chUrl = self.refCode + self.callingSELF.VV0Shr(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVpR5a(self.chName)
 def VV6Oj0(self):
  self.VVpR5a(self.chName)
 def VVpR5a(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFHJhk(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVElr3(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFj5YA(self.VV7A7C(tUrl), VVOEUE)
  if not self.epg:
   epg = CC8SZQ.VVBt15(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVZssn(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCMEuJ.VVtrJq(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVZssn(path)
  self.VVh32u()
  self.VVZCEb()
  self["myLabel"].setText(self.text or "   No active service", VV4T9O=VVOlxm)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVPcFJ(minHeight=minH)
 def VVZCEb(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFBTpz(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVe6I2(FFgvCy(url))
  if epg:
   self.text += "\n" + FFY7Lk("EPG:", VVMCs3) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVh32u()
 def VVh32u(self):
  if not self.piconShown and self.picUrl:
   path, err = FFg3JL(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVZssn(path)
    if self.piconShown and self.refCode:
     self.VVobIL(path, self.refCode)
 def VVobIL(self, path, refCode):
  if path and fileExists(path) and os.system(FFN2Os("which ffmpeg")) == 0:
   pPath = CCMEuJ.VVaKDV()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CC40v5.VVaKtk(path)
    cmd += FFN2Os("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVZssn(self, path):
  if path and fileExists(path):
   err, w, h = self.VVXK9T(path)
   if not err:
    if h > w:
     self.VVuhq3(self["myPicF"], w, h, True)
     self.VVuhq3(self["myPicB"], w, h, False)
     self.VVuhq3(self["myPic"] , w, h, False)
   self.picViewer = CCbFDB.VVEk3B(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVuhq3(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVXK9T(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFfoZ6(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVElr3(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFj5YA(chName, VVMCs3)
  txt += self.VVy3eN(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFj5YA(state, VVXz72)
   txt += "State\t: %s\n" % state
  w = FFNY8f(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFNY8f(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVcFBg(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVy3eN(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVy3eN(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVy3eN(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVCKId()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVO5Z0()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CC40v5.VVEjpp(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFj5YA("Stream-Relay" if FFXaBx(decodedUrl) else "IPTV", VVFiA5)
   txt += self.VVKf8g(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVj7fb(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCNm5S()
    tpTxt, namespace = tp.VV9LUN(refCode)
    if tpTxt:
     txt += FFj5YA("Tuner:\n", VVMCs3)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFj5YA("Codes:\n", VVMCs3)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVy3eN(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVy3eN(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVy3eN(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVy3eN(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVy3eN(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVy3eN(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVy3eN(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVy3eN(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVy3eN(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVcFBg(info):
  if info:
   aspect = FFNY8f(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVy3eN(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFNY8f(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVlqyb(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVlqyb(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVCKId(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVO5Z0(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVj7fb(self, refCode, iptvRef, chName):
  refCode = FFbK3k(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFEJE4(VVCQ1V + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFEJE4(VVCQ1V + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVkGEY = []
  tmpRefCode = FFgvCy(refCode)
  for item in fList:
   path = VVCQ1V + item
   if fileExists(path):
    txt = FFEJE4(path)
    if tmpRefCode in FFgvCy(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVkGEY.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVkGEY:
   if len(VVkGEY) == 1:
    txt += "%s\t: %s%s\n" % (FFj5YA("Bouquet", VVMCs3), VVkGEY[0][0], " (%s)" % VVkGEY[0][1] if VVxGgU else "")
   else:
    txt += FFj5YA("Bouquets:\n", VVMCs3)
    for ndx, item in enumerate(VVkGEY):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVxGgU else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVKf8g(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFfLGx(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCkzVG()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFj5YA("URL:", VVFiA5) + "\n%s\n" % self.VV7A7C(decodedUrl)
  else:
   txt = "\n"
   txt += FFj5YA("Reference:", VVFiA5) + "\n%s\n" % refCode
  return txt
 def VV7A7C(self, url):
  if not FFXaBx(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVwdnn:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFgvCy(url)
 def VVe6I2(self, decodedUrl):
  if not CCcrQv.VVTBsl():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCXWrP.VVmjdi(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVkJbs(tDict)
   elif uType == "movie" : epg, picUrl = CC40v5.VV8N1n(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVkJbs(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCXWrP.VV6FjI(item, "title"    , is_base64=True )
     lang    = CCXWrP.VV6FjI(item, "lang"         ).upper()
     description   = CCXWrP.VV6FjI(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCXWrP.VV6FjI(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCXWrP.VV6FjI(item, "start_timestamp"      )
     stop_timestamp  = CCXWrP.VV6FjI(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCXWrP.VV6FjI(item, "stop_timestamp"       )
     now_playing   = CCXWrP.VV6FjI(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVDIbD, ""
      else     : color, txt = VVXz72 , "    (CURRENT EVENT)"
      epg += FFj5YA("_" * 32 + "\n", VVky8q)
      epg += FFj5YA("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFj5YA(description, VVOEUE)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CC8SZQ.VVavFa(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VV8N1n(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCXWrP.VV6FjI(item, "movie_image" )
    genre  = CCXWrP.VV6FjI(item, "genre"   ) or "-"
    plot  = CCXWrP.VV6FjI(item, "plot"   ) or "-"
    cast  = CCXWrP.VV6FjI(item, "cast"   ) or "-"
    rating  = CCXWrP.VV6FjI(item, "rating"   ) or "-"
    director = CCXWrP.VV6FjI(item, "director"  ) or "-"
    releasedate = CCXWrP.VV6FjI(item, "releasedate" ) or "-"
    duration = CCXWrP.VV6FjI(item, "duration"  ) or "-"
    try:
     lang = CCXWrP.VV6FjI(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFj5YA(cast, VVOEUE)
    epg += "Plot:\n%s"    % FFj5YA(plot, VVOEUE)
   except:
    pass
  return epg, movie_image
 def VVChWx(self):
  if VVwdnn:
   def VVy3eN(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVy3eN(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCkzVG()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVy3eN(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVa91R, txt))
   FFgjbJ(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVPXTG(SELF):
  if not CC7Fot.VVaSI5(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF)
  err = url =  fSize = resumable = ""
  if FFjbqo(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCkzVG.VVjw5b(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCkzVG.VVZgAc(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFoFqK(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC1TwY.VVBRyA(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFj5YA(" (M3U/M3U8 File)", VVOEUE)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCxguE.VVwADe(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVAqUp(subj, val):
   return "%s\n%s\n\n" % (FFj5YA("%s:" % subj, VVMCs3), val)
  title = "File Size"
  txt  = VVAqUp(title , fSize or "?")
  txt += VVAqUp("Name" , chName)
  txt += VVAqUp("URL" , url)
  if resumable: txt += VVAqUp("Supports Download-Resume", resumable)
  if err  : txt += FFj5YA("Error:\n", VVXz72) + err
  FFcTZL(SELF, txt, title=title)
 @staticmethod
 def VVEjpp(SELF):
  fPath, fDir, fName = CC1TwY.VV58mN(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVaKtk(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVfj7L(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCMEuJ.VVaKDV() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVPswp(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFBTpz(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFL7ha(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCkzVG():
 def __init__(self):
  self.VV6lBw()
  self.VVTdWu    = ""
  self.VVjdv5   = "#f#11ffffaa#User"
  self.VV2CLV   = "#f#11aaffff#Server"
 def VV6lBw(self):
  self.VVfAyW   = ""
  self.VVdFeQ    = ""
  self.VVOuzo   = ""
  self.VVPqq8 = ""
  self.VV5YAQ  = ""
  self.VVmoVr = 0
 def VV0mkP(self, url, mac, ph1="", VVjHD0=True):
  self.VV6lBw()
  self.VVTdWu = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVa5GA(url)
  if not host:
   if VVjHD0:
    self.VVy1Mf("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVLtFp(mac)
  if not host:
   if VVjHD0:
    self.VVy1Mf("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVfAyW = host
  self.VVdFeQ  = mac
  return True
 def VVa5GA(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVLtFp(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVpkaL(self):
  res, err = self.VVGK16(self.VVzSiO())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVfAyW.endswith("/c"):
    self.VVfAyW = self.VVfAyW[:-2]
    res, err = self.VVGK16(self.VVzSiO())
   elif self.VVfAyW.endswith("/stalker_portal"):
    self.VVfAyW = self.VVfAyW[:-15]
    res, err = self.VVGK16(self.VVzSiO())
   else:
    self.VVfAyW += "/c"
    res, err = self.VVGK16(self.VVzSiO())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCXWrP.VV6FjI(tDict["js"], "token")
    rand  = CCXWrP.VV6FjI(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVycwh(self, VVjHD0=True):
  if not self.VVTdWu:
   self.VVhY5h()
  err = blkMsg = FFOPTXTxt = ""
  try:
   token, rand, err = self.VVpkaL()
   if token:
    self.VVOuzo = token
    self.VVPqq8 = rand
    if rand:
     self.VVmoVr = 2
    prof, retTxt = self.VVJfAV(True)
    if prof:
     self.VV5YAQ = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVmoVr = 3
      prof, retTxt = self.VVJfAV(False)
      if retTxt:
       self.VV5YAQ = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFOPTXTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFOPTXTxt: tErr += "\n%s" % FFOPTXTxt
  if VVjHD0:
   self.VVy1Mf(tErr)
  return "", "", tErr
 def VVhY5h(self):
  try:
   import requests
   url = self.VVJRoY()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCkzVG.VVZgAc(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCkzVG.VVZgAc(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVfAyW = url
       self.VVTdWu = span.group(1)
       return
  except:
   pass
  self.VVTdWu = "/server/load.php"
 def VVJRoY(self):
  url = self.VVfAyW.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVpHpn(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVGK16("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVGK16("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVJfAV(self, capMac):
  res, err = self.VVGK16(self.VVvZPW(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCXWrP.VV6FjI(tDict["js"], "block_%s" % word)
    FFOPTXTxt = CCXWrP.VV6FjI(tDict["js"], word)
    return tDict, FFOPTXTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVvZPW(self, capMac):
  param = ""
  if self.VV5YAQ or self.VVPqq8:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVdFeQ.upper() if capMac else self.VVdFeQ.lower(), self.VVPqq8))
  return self.VViO8J() + "type=stb&action=get_profile" + param
 exec(FFqKcx("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVcVMJ(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV6Jkz()
  if len(rows) < 10:
   rows = self.VV8Aee()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVfAyW ))
   rows.append(("MAC (from URL)" , self.VVdFeQ ))
   rows.append(("Token"   , self.VVOuzo ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVjdv5  , "MAC" , self.VVdFeQ ))
   rows.append(("2", self.VV2CLV, "Host" , self.VVfAyW ))
   rows.append(("2", self.VV2CLV, "Token" , self.VVOuzo ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV0q3g(self, isPhp=True, VVjHD0=False):
  token, profile, tErr = self.VVycwh(VVjHD0)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVcX6U()
  res, err = self.VVGK16(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCXWrP.VV6FjI(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFiBxf(span.group(2))
     pass1 = FFiBxf(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV6Jkz(self):
  m3u_Url, host, user1, pass1, err = self.VV0q3g()
  rows = []
  if m3u_Url:
   res, err = self.VVGK16(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF5ivG(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVjdv5, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF5ivG(int(val))
      else      : val = str(val)
      rows.append(("2", self.VV2CLV, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV8Aee(self):
  token, profile, tErr = self.VVycwh()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFdPwT(val): val = FFqKcx(val.decode("UTF-8"))
     else     : val = self.VVdFeQ
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF5ivG(int(parts[1]))
      if parts[2] : ends = FF5ivG(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF5ivG(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV0Shr(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVycwh(VVjHD0=False)
  if not token:
   return ""
  crLinkUrl = self.VVJIGu(mode, chCm, epNum, epId)
  res, err = self.VVGK16(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCXWrP.VV6FjI(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VViO8J(self):
  return self.VVfAyW + self.VVTdWu + "?"
 def VVzSiO(self):
  return self.VViO8J() + "type=stb&action=handshake&token=&mac=%s" % self.VVdFeQ
 def VVvpUJ(self, mode):
  url = self.VViO8J() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVz7jB(self, catID):
  return self.VViO8J() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV0mJF(self, mode, catID, page):
  url = self.VViO8J() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VV50Sd(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VViO8J() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVzwaT(self, mode, catID):
  return self.VViO8J() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVJIGu(self, mode, chCm, serCode, serId):
  url = self.VViO8J() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVcX6U(self):
  return self.VViO8J() + "type=itv&action=create_link"
 def VV5BKM(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVzkhN(catID, stID, chNum)
  query = self.VVsLhZ(mode, self.VVTdWu[1:2], FFYI2o(host), FFYI2o(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVsLhZ(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVMGkt(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVsLhZ(mode, ph1, host, mac, epNum, epId, FFiBxf(chCm))
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFqKcx(host)
  mac   = FFqKcx(mac)
  valid = False
  if self.VVa5GA(playHost) and self.VVa5GA(host) and self.VVa5GA(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVGK16(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCkzVG.VVZgAc()
   if self.VVOuzo:
    headers["Authorization"] = "Bearer %s" % self.VVOuzo
   if useCookies : cookies = {"mac": self.VVdFeQ, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVmuRu(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCkzVG.VVZgAc(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVZgAc():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVdRKN(host, mac, tType, action, keysList=None):
  myPortal = CCkzVG()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VV0mkP(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVycwh(VVjHD0=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVGK16(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVZCJj(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVZCJj(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVy1Mf(self, err, title="Portal Browser"):
  FFoFqK(self, str(err), title=title)
 def VVBNqO(self, mode):
  if   mode in ("itv"  , CCXWrP.VVQ6fI , CCXWrP.VVO1rz)  : return "Live"
  elif mode in ("vod"  , CCXWrP.VVztTk , CCXWrP.VVqldT)  : return "VOD"
  elif mode in ("series" , CCXWrP.VVKYPw , CCXWrP.VVthva) : return "Series"
  else                          : return "IPTV"
 def VVRuoe(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVBNqO(mode), FFj5YA(searchName, VVOEUE))
 def VVpTQi(self, catchup=False):
  VVGtpd = []
  VVGtpd.append(("Live"    , "live"  ))
  VVGtpd.append(("VOD"    , "vod"   ))
  VVGtpd.append(("Series"   , "series"  ))
  if catchup:
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Catch-up TV" , "catchup"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Account Info." , "accountInfo" ))
  return VVGtpd
 @staticmethod
 def VVSQqB(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCkzVG()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(decodedUrl)
  if valid:
   ok = p.VV0mkP(host, mac, ph1, VVjHD0=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VV0q3g(isPhp=False, VVjHD0=False)
    streamId = CCkzVG.VVMMPR(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVMMPR(decodedUrl):
  p = CCkzVG()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFqKcx(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVjw5b(decodedUrl):
  p = CCkzVG()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(decodedUrl)
  if valid:
   if CCkzVG.VV8PVP(chCm):
    return FFgvCy(chCm)
   else:
    ok = p.VV0mkP(host, mac, ph1, VVjHD0=False)
    if ok:
     try:
      chUrl = p.VV0Shr(mode, chCm, epNum, epId)
      return FFgvCy(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VV8PVP(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCWAkM(CCkzVG):
 def __init__(self):
  CCkzVG.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVuPDh(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVMGkt(decodedUrl)
  if valid:
   if self.VV0mkP(host, mac, ph1, VVjHD0=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVMiYM(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VV0Shr(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCkzVG.VV8PVP(self.chCm):
   chUrl = FFgvCy(self.chCm)
   chUrl = FFiBxf(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVD3e2(chUrl)
  bPath = CC3pKJ.VVV0dw()
  if newIptvRef:
   if passedSELF:
    FF4utl(passedSELF, newIptvRef, VVoHm3=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FF4utl(self, newIptvRef, VVoHm3=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVRCpf(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVD3e2(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVRCpf(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FF8eQ2(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFEuF7()
class CCBkSl(CCWAkM):
 def __init__(self, passedSession):
  CCWAkM.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVb5kZ(VVZkLz  )
  Main_Menu.VVb5kZ(VV3uf8)
  Main_Menu.VVb5kZ(VVQQU5  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVCXV0, iPlayableService.evEOF: self.VVY764, iPlayableService.evEnd: self.VVivFj})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVd97a)
  except:
   self.timer2.callback.append(self.VVd97a)
  self.timer2.start(3000, False)
  self.VVd97a()
 def VVd97a(self):
  if not CFG.downloadMonitor.getValue():
   self.VVLIKf()
   return
  lst = CCxguE.VVbNU1()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFkas1(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCxguE.VVk0FT(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CChNMz, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFFFBF(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVLIKf()
 def VVLIKf(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVCXV0(self):
  self.startTime = iTime()
 def VVY764(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFjbqo(decodedUrl):
     self.isFromEOF = True
     CC5zgq(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVivFj(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVrHwl)
  except:
   self.timer1.callback.append(self.VVrHwl)
  self.timer1.start(100, True)
 def VVrHwl(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVuPDh(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCi57e.VVYwjf:
       self.isFromEOF = False
       self.VVMiYM(self.passedSession, isFromSession=True)
class CCzdJA():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVOkht(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCXWrP.VVkrnc(name):
   return CCXWrP.VV6pxh(name)
  name = self.VV8PPX(name)
  return name.strip() or name
 def VV8PPX(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VV2pbV(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV8PPX(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVDV8e(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVtzrp(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVaMpR(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC7Fot(CCkzVG):
 def __init__(self):
  CCkzVG.__init__(self)
 def VVK5ps(self):
  if CC7Fot.VVaSI5(self):
   FFKsz7(self, BF(self.VVwd81, 2), title="Searching ...")
 def VVXtml(self, winSession, url, mac):
  self.curUrl = url
  if CC7Fot.VVaSI5(self):
   if self.VV0mkP(url, mac):
    FFKsz7(winSession, self.VVD5kQ, title="Checking Server ...")
   else:
    FFoFqK(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV0rPI(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCoiM6.VVfJOY(path, self)
   if enc == -1:
    return
   self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVMV4f, path, enc)
       , VV00AH = BF(self.VV5krM, menuInstance, path))
 def VVMV4f(self, path, enc, VVfBS1):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVfBS1.VV9WKz(totLines)
  VVfBS1.VVcdNf = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVfBS1 or VVfBS1.isCancelled:
     return
    VVfBS1.VVSxQe(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVa5GA(url)
     mac  = self.VVLtFp(mac)
     if host and mac and VVfBS1:
      VVfBS1.VVcdNf.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVa5GA(url)
      mac  = self.VVLtFp(mac)
      if host and mac and not mac.startswith("AC") and VVfBS1:
       VVfBS1.VVcdNf.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VV5krM(self, menuInstance, path, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVcdNf:
   VVJ6wE  = ("Home Menu"  , FFjVEj            , [])
   VV0q2u = ("Edit File"  , BF(self.VVYHXV, path)       , [])
   VVtaAK = ("M3U Options" , self.VVOYOB         , [])
   VVyNdP = ("Check & Filter" , BF(self.VV85td, menuInstance, path), [])
   VVLseV  = ("Select"   , self.VVLY1d      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVZq8i  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVcdNf, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVghW2="#0a001122", VVlnMM="#0a001122", VValS2="#0a001122", VVKJ4V="#00004455", VVEwGL="#0a333333", VVtDKG="#11331100", VV0i4h=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VV9pDl:
    FFgjbJ(VVeDC2, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV9pDl:
    FFoFqK(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVOYOB(self, VVeDC2, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVGtpd = []
  VVGtpd.append(("Browse as M3U"  , "browse"))
  VVGtpd.append(("Download M3U File" , "downld"))
  FFINMf(self, BF(self.VV9rxR, VVeDC2, host, mac), title=title, VVGtpd=VVGtpd, width=600, VVOvZt=True)
 def VV9rxR(self, VVeDC2, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFKsz7(VVeDC2, BF(self.VVEfdW, VVeDC2, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFlEph(self, BF(FFKsz7, VVeDC2, BF(self.VVEfdW, VVeDC2, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVEfdW(self, VVeDC2, title, host, mac, item):
  p = CCkzVG()
  m3u_Url = ""
  ok = p.VV0mkP(host, mac, VVjHD0=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV0q3g(VVjHD0=False)
  if m3u_Url:
   if   item == "browse": self.VVb7UF(title, m3u_Url)
   elif item == "downld": self.VV8I2x(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFoFqK(self, err or "No response from Server !", title=title)
 def VVLY1d(self, VVeDC2, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVXtml(VVeDC2, url, mac)
 def VVYHXV(self, path, VVeDC2, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCkPUj(self, path, VV00AH=BF(self.VVSVRS, VVeDC2), curRowNum=rowNum)
  else    : FFE0MG(self, path)
 def VV85td(self, menuInstance, path, VVeDC2, title, txt, colList):
  self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVyq4c, VVeDC2)
      , VV00AH = BF(self.VV9S63, menuInstance, VVeDC2, path))
 def VVyq4c(self, VVeDC2, VVfBS1):
  VVfBS1.VVcdNf = []
  VVfBS1.VV9WKz(VVeDC2.VVz6J6())
  for row in VVeDC2.VVmbqa():
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VV0mkP(host, mac, VVjHD0=False):
    token, profile, tErr = self.VVycwh(VVjHD0=False)
    if token and VVfBS1 and not VVfBS1.isCancelled:
     res, err = self.VVGK16(self.VVvpUJ("itv"))
     if res and VVfBS1 and not VVfBS1.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVfBS1.VVSxQe(0, showFound=True)
       VVfBS1.VVcdNf.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVfBS1:
    return
 def VV9S63(self, menuInstance, VVeDC2, path, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VVcdNf:
   VVeDC2.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFbNWS())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVcdNf:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFj5YA(str(threadCounter), VVXz72)
    skipped = FFj5YA(str(threadTotal - threadCounter), VVXz72)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVcdNf)
   txt += "%s\n\n%s"    %  (FFj5YA("Result File:", VVMCs3), newPath)
   FFcTZL(self, txt, title="Accessible Portals")
  elif VV9pDl:
   FFoFqK(self, "No portal access found !", title="Accessible Portals")
 def VVmeqQ(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFqKcx(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVD5kQ(self):
  token, profile, tErr = self.VVycwh()
  if token:
   dots = "." * self.VVmoVr
   dots += "+" if self.VVTdWu[1:2] == "p" else ""
   dots += "*" if not self.VVfAyW == self.curUrl else ""
   VVGtpd  = self.VVpTQi()
   OKBtnFnc = self.VV4NKy
   infoBtnFnc = self.VVXeyi
   VVuZl0 = ("Home Menu", FFjVEj)
   VV3Pkd= ("Add to Menu", BF(CCXWrP.VVld2V, self, True, self.VVfAyW + "\t" + self.VVdFeQ))
   VVDhcZ = ("Bookmark Server", BF(CCXWrP.VV1geq, self, True, self.VVfAyW + "\t" + self.VVdFeQ))
   FFINMf(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVdFeQ, dots), VVGtpd=VVGtpd, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVuZl0=VVuZl0, VV3Pkd=VV3Pkd, VVDhcZ=VVDhcZ)
 def VV4NKy(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFKsz7(menuInstance, BF(self.VVJPTo, mode), title="Reading Categories ...")
   else : FFKsz7(menuInstance, BF(self.VVfelL, menuInstance, title), title="Reading Account ...")
 def VVfelL(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVcVMJ(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVdFeQ)
  VVJ6wE  = ("Home Menu" , FFjVEj           , [])
  VVtaAK  = None
  if VVwdnn:
   VVtaAK = ("Get JS"  , BF(self.VVhvTw, self.VVJRoY()) , [])
  if totCols == 2:
   VVyNdP = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVyNdP = ("More Info.", BF(self.VVp7NW, menuInstance)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FF4zYj(self, None, title=title, width=1200, header=header, VVkGEY=rows, VVsmwq=widths, VVdez8=26, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VVyNdP=VVyNdP, VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000", searchCol=searchCol)
 def VVhvTw(self, url, VVeDC2, title, txt, colList):
  FFKsz7(VVeDC2, BF(self.VV5IRu, url), title="Getting JS ...")
 def VV5IRu(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVdFeQ)
  ver, err = self.VVpHpn(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVpHpn(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFcTZL(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVp7NW(self, menuInstance, VVeDC2, title, txt, colList):
  VVeDC2.cancel()
  FFKsz7(menuInstance, BF(self.VVfelL, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVJPTo(self, mode):
  token, profile, tErr = self.VVycwh()
  if not token:
   return
  res, err = self.VVGK16(self.VVvpUJ(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVICJb = CCzdJA()
     chList = tDict["js"]
     for item in chList:
      Id   = CCXWrP.VV6FjI(item, "id"       )
      Title  = CCXWrP.VV6FjI(item, "title"      )
      censored = CCXWrP.VV6FjI(item, "censored"     )
      Title = VVICJb.VVDV8e(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVxGgU:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVBNqO(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3(mode)
   mName = self.VVBNqO(mode)
   VVLseV   = ("Show List"   , BF(self.VVzkhQ, mode)   , [])
   VVJ6wE  = ("Home Menu"   , FFjVEj        , [])
   if mode in ("vod", "series"):
    VV0q2u = ("Find in %s" % mName , BF(self.VVUx6W, mode, False), [])
    VVyNdP = ("Find in Selected" , BF(self.VVUx6W, mode, True) , [])
   else:
    VV0q2u = None
    VVyNdP = None
   header   = None
   widths   = (100   , 0  )
   FF4zYj(self, None, title=title, width=1200, header=header, VVkGEY=list, VVsmwq=widths, VVdez8=30, VVJ6wE=VVJ6wE, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVLseV=VVLseV, VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVKJ4V=VVKJ4V, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VV5YAQ:
     txt += "\n\n( %s )" % self.VV5YAQ
   else:
    txt = "Could not get Categories from server!"
   FFoFqK(self, txt, title=title)
 def VVcVkY(self, mode, VVeDC2, title, txt, colList):
  FFKsz7(VVeDC2, BF(self.VVEgS1, mode, VVeDC2, title, txt, colList), title="Downloading ...")
 def VVEgS1(self, mode, VVeDC2, title, txt, colList):
  token, profile, tErr = self.VVycwh()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVGK16(self.VVz7jB(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCXWrP.VV6FjI(item, "id"    )
      actors   = CCXWrP.VV6FjI(item, "actors"   )
      added   = CCXWrP.VV6FjI(item, "added"   )
      age    = CCXWrP.VV6FjI(item, "age"   )
      category_id  = CCXWrP.VV6FjI(item, "category_id" )
      description  = CCXWrP.VV6FjI(item, "description" )
      director  = CCXWrP.VV6FjI(item, "director"  )
      genres_str  = CCXWrP.VV6FjI(item, "genres_str"  )
      name   = CCXWrP.VV6FjI(item, "name"   )
      path   = CCXWrP.VV6FjI(item, "path"   )
      screenshot_uri = CCXWrP.VV6FjI(item, "screenshot_uri" )
      series   = CCXWrP.VV6FjI(item, "series"   )
      cmd    = CCXWrP.VV6FjI(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVLseV  = ("Play"    , BF(self.VVYgpW, mode)       , [])
   VVXlcT = (""     , BF(self.VVQSiz, mode)     , [])
   VVJ6wE = ("Home Menu"   , FFjVEj            , [])
   VVtaAK = ("Download Options" , BF(self.VVnM56, mode, "sp", seriesName) , [])
   VV0q2u = ("Options"   , BF(self.VVDweH, "pEp", mode, seriesName) , [])
   VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVZq8i  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF4zYj(self, None, title=seriesName, width=1200, header=header, VVkGEY=list, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindIptv, VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000")
  else:
   FFoFqK(self, "Could not get Episodes from server!", title=seriesName)
 def VVUx6W(self, mode, searchInCat, VVeDC2, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVGtpd = []
  VVGtpd.append(("Keyboard"  , "manualEntry"))
  VVGtpd.append(("From Filter" , "fromFilter"))
  FFINMf(self, BF(self.VVC3uP, VVeDC2, mode, searchCatId), title="Input Type", VVGtpd=VVGtpd, width=400)
 def VVC3uP(self, VVeDC2, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF8cVc(self, BF(self.VV4m2j, VVeDC2, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCZt3D(self)
    filterObj.VVTzbi(BF(self.VV4m2j, VVeDC2, mode, searchCatId))
 def VV4m2j(self, VVeDC2, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFSmZ2(CFG.lastFindIptv, searchName)
   title = self.VVRuoe(mode, searchName)
   if "," in searchName : FFoFqK(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFoFqK(self, "Enter at least 3 characters.", title=title)
   else     :
    VVICJb = CCzdJA()
    if CFG.hideIptvServerAdultWords.getValue() and VVICJb.VVtzrp([searchName]):
     FFoFqK(self, VVICJb.VVaMpR(), title=title)
    else:
     self.VV1vwh(mode, searchName, "", searchName, searchCatId)
 def VVzkhQ(self, mode, VVeDC2, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VV1vwh(mode, bName, catID, "", "")
 def VV1vwh(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVnBgX, mode, bName, catID, searchName, searchCatId)
      , VV00AH = BF(self.VVm3MS, mode, bName, catID, searchName, searchCatId))
 def VVm3MS(self, mode, bName, catID, searchName, searchCatId, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVRuoe(mode, searchName)
  else   : title = "%s : %s" % (self.VVBNqO(mode), bName)
  if VVcdNf:
   VVtaAK = None
   VV0q2u = None
   if mode == "series":
    VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3("series2")
    VVLseV  = ("Episodes"   , BF(self.VVcVkY, mode)           , [])
   else:
    VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3("")
    VVLseV  = ("Play"    , BF(self.VVYgpW, mode)           , [])
    VVtaAK = ("Download Options" , BF(self.VVnM56, mode, "vp" if mode == "vod" else "", "") , [])
    VV0q2u = ("Options"   , BF(self.VVDweH, "pCh", mode, bName)      , [])
   VVXlcT = (""      , BF(self.VVb3wj, mode)         , [])
   VVJ6wE = ("Home Menu"    , FFjVEj                , [])
   VVyNdP = ("Posters Mode"   , BF(self.VVVeQp, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVZq8i  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVcdNf, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindIptv, VVLseV=VVLseV, VVXlcT=VVXlcT, VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVKJ4V=VVKJ4V, VV0i4h=True, searchCol=1)
   if not VV9pDl:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVeDC2.VVWHzV(VVeDC2.VVpmbi() + tot)
    if threadErr: FFgjbJ(VVeDC2, "Error while reading !", 2000)
    else  : FFgjbJ(VVeDC2, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFoFqK(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFoFqK(self, "Could not get list from server !", title=title)
 def VVb3wj(self, mode, VVeDC2, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFeMt4(self, fncMode=CC40v5.VV732k, portalHost=self.VVfAyW, portalMac=self.VVdFeQ, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV2Ijr(mode, VVeDC2, title, txt, colList)
 def VVQSiz(self, mode, VVeDC2, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFj5YA(colList[10], VVOEUE)
  txt += "Description:\n%s" % FFj5YA(colList[11], VVOEUE)
  self.VV2Ijr(mode, VVeDC2, title, txt, colList)
 def VV2Ijr(self, mode, VVeDC2, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, colList)
  refCode, chUrl = self.VV5BKM(self.VVfAyW, self.VVdFeQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFeMt4(self, fncMode=CC40v5.VVmvGX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVnBgX(self, mode, bName, catID, searchName, searchCatId, VVfBS1):
  try:
   token, profile, tErr = self.VVycwh()
   if not token:
    return
   if VVfBS1.isCancelled:
    return
   VVfBS1.VVcdNf, total_items, max_page_items, err = self.VVCMGb(mode, catID, 1, 1, searchName, searchCatId)
   if VVfBS1.isCancelled:
    return
   if VVfBS1.VVcdNf and total_items > -1 and max_page_items > -1:
    VVfBS1.VV9WKz(total_items)
    VVfBS1.VVSxQe(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVfBS1.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVCMGb(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVfBS1.VVIfKo()
     if VVfBS1.isCancelled:
      return
     if list:
      VVfBS1.VVcdNf += list
      VVfBS1.VVSxQe(len(list), True)
  except:
   pass
 def VVCMGb(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV50Sd(mode, searchName, searchCatId, page)
  else   : url = self.VV0mJF(mode, catID, page)
  res, err = self.VVGK16(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVaYFE(CCXWrP.VV6FjI(item, "total_items" ))
     max_page_items = self.VVaYFE(CCXWrP.VV6FjI(item, "max_page_items" ))
     VVICJb = CCzdJA()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCXWrP.VV6FjI(item, "id"    )
      name   = CCXWrP.VV6FjI(item, "name"   )
      o_name   = CCXWrP.VV6FjI(item, "o_name"   )
      tv_genre_id  = CCXWrP.VV6FjI(item, "tv_genre_id" )
      number   = CCXWrP.VV6FjI(item, "number"   ) or str(counter)
      logo   = CCXWrP.VV6FjI(item, "logo"   )
      screenshot_uri = CCXWrP.VV6FjI(item, "screenshot_uri" )
      cmd    = CCXWrP.VV6FjI(item, "cmd"   )
      censored  = CCXWrP.VV6FjI(item, "censored"  )
      genres_str  = CCXWrP.VV6FjI(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVfAyW + picon).replace(sp * 2, sp)
      counter += 1
      name = VVICJb.VVOkht(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVaYFE(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVYgpW(self, mode, VVeDC2, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, colList)
  refCode, chUrl = self.VV5BKM(self.VVfAyW, self.VVdFeQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVkrnc(chName):
   FFgjbJ(VVeDC2, "This is a marker!", 300)
  else:
   FFKsz7(VVeDC2, BF(self.VVWUY0, mode, VVeDC2, chUrl), title="Playing ...")
 def VVWUY0(self, mode, VVeDC2, chUrl):
  FF4utl(self, chUrl, VVoHm3=False)
  CCi57e.VVnjtb(self.session, iptvTableParams=(self, VVeDC2, mode))
 def VV845t(self, mode, VVeDC2, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, colList)
  refCode, chUrl = self.VV5BKM(self.VVfAyW, self.VVdFeQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVAeyH(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVaSI5(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVGtpd = []
    VVGtpd.append((title        , "inst" ))
    VVGtpd.append(("Update Packages then %s" % title , "updInst" ))
    FFINMf(SELF, BF(CC7Fot.VVqhqb, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVGtpd=VVGtpd)
   return False
 @staticmethod
 def VVqhqb(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFqitY(VV9WZR, "")
   if cmdUpd:
    cmdInst = FFDHcv(VVKyPA, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFB1pa(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVRBrK=cbFnc)
   else:
    FFmApx(SELF)
class CCXWrP(Screen, CC7Fot, CCHhER):
 VVYLq2    = 0
 VV0LCO    = 1
 VVEOyx    = 2
 VVHY5c    = 3
 VVOp4F     = 4
 VVma7D     = 5
 VVl1YD     = 6
 VV13ut     = 7
 VV9U4O     = 8
 VVdFei     = 9
 VVI561      = 10
 VVlVbj     = 11
 VVop1e     = 12
 VVcQyx     = 13
 VVTOvg     = 14
 VVyeJW      = 15
 VV1mKH      = 16
 VVK6FS      = 17
 VVZcKm      = 18
 VVCR9C      = 19
 VV5hta    = 0
 VVQ6fI   = 1
 VVztTk   = 2
 VVKYPw   = 3
 VVYAZY  = 4
 VVuoNK  = 5
 VVO1rz   = 6
 VVqldT   = 7
 VVthva  = 8
 VVKK8G  = 9
 VVpwH6  = 10
 VVI3jb = 0
 VVgZBq = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFkttW(VVUJSe, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVeDC2    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV7lPdData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCXWrP.VV26sg(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CC7Fot.__init__(self)
  VVGtpd = self.VVgjVE()
  FFOh1m(self, title="IPTV", VVGtpd=VVGtpd)
  self["myActionMap"].actions.update({
   "menu" : self.VVSbS9
  })
  self["myMenu"].onSelectionChanged.append(self.VVj3U1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self["myMenu"].setList(self.VVgjVE())
  FFpvIL(self)
  FFe04V(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFeJ1R(self["myMenu"])
   FFUaCm(self)
   if self.m3uOrM3u8File:
    self.VVmiEy(self.m3uOrM3u8File, (0, (), False, ""))
 def VVj3U1(self):
  if self["myMenu"].getCurrent()[1] in ("VVKNa8", "VVZ9vmPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVSbS9(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVZ9vmPortal" : confItem = CFG.favServerPortal
   elif item == "VVKNa8" : confItem = CFG.favServerPlaylist
   else         : return
   FFlEph(self, BF(self.VVRa3k, confItem), 'Remove from menu ?', title=title)
 def VVRa3k(self, confItem):
  FFSmZ2(confItem, "")
  self.VVP1sX()
 def VVgjVE(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVAjMy
  VVGtpd = []
  if isFav1: VVGtpd.append((c +  "Favourite Playlist Server"   , "VVKNa8" ))
  if isFav2: VVGtpd.append((c +  "Favourite Portal Server"    , "VVZ9vmPortal" ))
  VVGtpd.append(("IPTV Server Browser (from Playlists)"     , "VV7lPd_fromPlayList" ))
  VVGtpd.append(("IPTV Server Browser (from Portal List)"    , "VV7lPd_fromMac"  ))
  VVGtpd.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV7lPd_fromM3u"  ))
  qUrl, iptvRef = CCXWrP.VVE89T(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVGtpd.append((item     , "VV7lPd_fromCurrChan" ))
  else       : VVGtpd.append((item     ,       ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("M3U/M3U8 File Browser"        , "VVVEqj"   ))
  if self.iptvFileAvailable:
   VVGtpd.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVGtpd.append(VVttU7)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVGtpd.append((item1            , "refreshIptvEPG"   ))
   VVGtpd.append((item2            , "refreshIptvPicons"  ))
  else:
   VVGtpd.append((item1            ,       ))
   VVGtpd.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVGtpd.append(VVttU7)
   c1, c2 = VVM7JM, VVMCs3
   t1 = FFj5YA("auto-match names", VVAjMy)
   t2 = FFj5YA("from xml file"  , VVAjMy)
   VVGtpd.append((c1 + "Count Available IPTV Channels"    , "VVYul1"    ))
   VVGtpd.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVGtpd.append(VVttU7)
   VVGtpd.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVGtpd.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVGOU8" ))
   VVGtpd.append((VVNNKJ + "More Reference Tools ..."  , "VVed0o"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Reload Channels and Bouquets"       , "VVVKDS"   ))
  VVGtpd.append(VVttU7)
  if not CCxguE.VVCmgk():
   VVGtpd.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVGtpd.append(("Download Manager ... No donwloads"    ,       ))
  return VVGtpd
 def VVC3et(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVlqIN"   : self.VVlqIN()
   elif item == "VVAeob" : FFlEph(self, self.VVAeob, "Change Current List References to Unique Codes ?")
   elif item == "VVHZZT_rows" : FFlEph(self, BF(FFKsz7, self.VVeDC2, self.VVHZZT), "Change Current List References to Identical Codes ?")
   elif item == "VVdpDN"   : self.VVdpDN(tTitle)
   elif item == "VVzVVf"   : self.VVzVVf(tTitle)
   elif item == "VVKNa8" : self.VVZ9vm(False)
   elif item == "VVZ9vmPortal" : self.VVZ9vm(True)
   elif item == "VV7lPd_fromPlayList" : FFKsz7(self, BF(self.VVwd81, 1), title=title)
   elif item == "VV7lPd_fromM3u"  : FFKsz7(self, BF(self.VV7Yf5, CCXWrP.VVI3jb), title=title)
   elif item == "VV7lPd_fromMac"  : self.VVK5ps()
   elif item == "VV7lPd_fromCurrChan" : self.VVZgj5()
   elif item == "VVVEqj"   : self.VVVEqj()
   elif item == "iptvTable_all"   : FFKsz7(self, BF(self.VViB0e, self.VVYLq2), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCXWrP.VV27Ot(self)
   elif item == "refreshIptvPicons"  : self.VVmfNw()
   elif item == "VVYul1"    : FFKsz7(self, self.VVYul1)
   elif item == "copyEpgPicons"   : self.VVt3Qs(False)
   elif item == "renumIptvRef_fromFile" : self.VVt3Qs(True)
   elif item == "VVGOU8" : FFlEph(self, BF(FFKsz7, self, self.VVGOU8), VV7fsq="Continue ?")
   elif item == "VVed0o"    : self.VVed0o()
   elif item == "VVVKDS"   : FFKsz7(self, BF(CC5MnI.VVVKDS, self))
   elif item == "dload_stat"    : CCxguE.VVZs2U(self)
 def VVVEqj(self):
  if CC7Fot.VVaSI5(self):
   FFKsz7(self, BF(self.VV7Yf5, CCXWrP.VVgZBq), title="Searching ...")
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVC3et(item)
 def VViB0e(self, mode):
  VVzpbP = self.VVWIRd(mode)
  if VVzpbP:
   VVtaAK = ("Current Service", self.VV1UQI , [])
   VV0q2u = ("Options"  , self.VVNk8K   , [])
   VVyNdP = ("Filter"   , self.VVvzxN   , [])
   VVLseV  = ("Play"   , BF(self.VVLr1I)  , [])
   VVXlcT = (""    , self.VVgxI1    , [])
   VVHUGA = (""    , self.VVI0la     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVZq8i  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FF4zYj(self, None, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26
     , VVLseV=VVLseV, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVXlcT=VVXlcT, VVHUGA=VVHUGA
     , VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000", VV0i4h=True, searchCol=1)
  else:
   if mode == self.VVdFei: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFoFqK(self, err)
 def VVI0la(self, VVeDC2, title, txt, colList):
  self.VVeDC2 = VVeDC2
 def VVNk8K(self, VVeDC2, title, txt, colList):
  VVGtpd = []
  VVGtpd.append(("Add Current List to a New Bouquet"    , "VVlqIN"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change Current List References to Unique Codes" , "VVAeob"))
  VVGtpd.append(("Change Current List References to Identical Codes", "VVHZZT_rows" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Share Reference with DVB Service (manual entry)" , "VVdpDN"   ))
  VVGtpd.append(("Share Reference with DVB Service (auto-find)"  , "VVzVVf"   ))
  FFINMf(self, self.VVC3et, title="IPTV Tools", VVGtpd=VVGtpd)
 def VVvzxN(self, VVeDC2, title, txt, colList):
  VVGtpd = []
  VVGtpd.append(("All"         , "all"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Prefix of Selected Channel"   , "sameName" ))
  VVGtpd.append(("Suggest Words from Selected Channel" , "partName" ))
  VVGtpd.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVGtpd.append(("Duplicate References"     , "depRef"  ))
  VVGtpd.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVGtpd.append(("Stream Relay"       , "SRelay"  ))
  VVGtpd.append(FFPPw2("Category"))
  VVGtpd.append(("Live TV"        , "live"  ))
  VVGtpd.append(("VOD"         , "vod"   ))
  VVGtpd.append(("Series"        , "series"  ))
  VVGtpd.append(("Uncategorised"      , "uncat"  ))
  VVGtpd.append(FFPPw2("Media"))
  VVGtpd.append(("Video"        , "video"  ))
  VVGtpd.append(("Audio"        , "audio"  ))
  VVGtpd.append(FFPPw2("File Type"))
  VVGtpd.append(("MKV"         , "MKV"   ))
  VVGtpd.append(("MP4"         , "MP4"   ))
  VVGtpd.append(("MP3"         , "MP3"   ))
  VVGtpd.append(("AVI"         , "AVI"   ))
  VVGtpd.append(("FLV"         , "FLV"   ))
  VVGtpd.extend(CC3pKJ.VVuwX4(prefix="__b__"))
  inFilterFnc = BF(self.VVDNPW, VVeDC2) if VVeDC2.VVpmbi().startswith("IPTV Filter ") else None
  filterObj = CCZt3D(self)
  filterObj.VVmYdR(VVGtpd, VVGtpd, BF(self.VVAtf8, VVeDC2, False), inFilterFnc=inFilterFnc)
 def VVDNPW(self, VVeDC2, menuInstance, item):
  self.VVAtf8(VVeDC2, True, item)
 def VVAtf8(self, VVeDC2, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVeDC2.VVhJef(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVYLq2 , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV0LCO , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVEOyx , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVHY5c , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVl1YD  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV13ut  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VV9U4O  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVdFei  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVI561   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVlVbj  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVop1e  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVcQyx  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVTOvg  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVyeJW   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV1mKH   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVK6FS   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVZcKm   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVCR9C   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVOp4F  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVma7D  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVEOyx:
   VVGtpd = []
   chName = VVeDC2.VVhJef(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVGtpd.append((item, item))
    if not VVGtpd and chName:
     VVGtpd.append((chName, chName))
    FFINMf(self, BF(self.VVGv0r, title), title="Words from Current Selection", VVGtpd=VVGtpd)
   else:
    VVeDC2.VVdL9K("Invalid Channel Name")
  else:
   words, asPrefix = CCZt3D.VVvY0h(words)
   if not words and mode in (self.VVOp4F, self.VVma7D):
    FFgjbJ(self.VVeDC2, "Incorrect filter", 2000)
   else:
    FFKsz7(self.VVeDC2, BF(self.VV5cia, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVGv0r(self, title, word=None):
  if word:
   words = [word.lower()]
   FFKsz7(self.VVeDC2, BF(self.VV5cia, self.VVEOyx, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV6pxh(txt):
  return "#f#11ffff00#" + txt
 def VV5cia(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVzpbP = self.VV3zU1(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVzpbP = self.VVWIRd(mode=mode, words=words, asPrefix=asPrefix)
  if VVzpbP : self.VVeDC2.VV6IAT(VVzpbP, title)
  else  : self.VVeDC2.VVdL9K("Not found")
 def VV3zU1(self, mode=0, words=None, asPrefix=False):
  VVzpbP = []
  for row in self.VVeDC2.VVmbqa():
   row = list(map(str.strip, row))
   chNum, chName, VVezVx, chType, refCode, url = row
   if self.VV8XNA(mode, refCode, FFgvCy(url).lower(), chName, words, VVezVx.lower(), asPrefix):
    VVzpbP.append(row)
  VVzpbP = self.VVUUm3(mode, VVzpbP)
  return VVzpbP
 def VVWIRd(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVzpbP = []
  files  = self.VVXy5E()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFEJE4(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVezVx = span.group(1)
    else : VVezVx = ""
    VVezVx_lCase = VVezVx.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVkrnc(chName): chNameMod = self.VV6pxh(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVezVx, chType + (" SRel" if FFXaBx(url) else ""), refCode, url)
     if self.VV8XNA(mode, refCode, FFgvCy(url).lower(), chName, words, VVezVx_lCase, asPrefix):
      VVzpbP.append(row)
      chNum += 1
  VVzpbP = self.VVUUm3(mode, VVzpbP)
  return VVzpbP
 def VVUUm3(self, mode, VVzpbP):
  newRows = []
  if VVzpbP and mode == self.VVl1YD:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVzpbP)
   for item in VVzpbP:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVzpbP
 def VV8XNA(self, mode, refCode, tUrl, chName, words, VVezVx_lCase, asPrefix):
  if   mode == self.VVYLq2 : return True
  elif mode == self.VVl1YD : return True
  elif mode == self.VV13ut  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VV9U4O : return FFXaBx(tUrl)
  elif mode == self.VVcQyx  : return CCXWrP.VVQOpp(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVTOvg  : return CCXWrP.VVQOpp(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVdFei  : return CCXWrP.VVQOpp(tUrl, compareType="live")
  elif mode == self.VVI561  : return CCXWrP.VVQOpp(tUrl, compareType="movie")
  elif mode == self.VVlVbj : return CCXWrP.VVQOpp(tUrl, compareType="series")
  elif mode == self.VVop1e  : return CCXWrP.VVQOpp(tUrl, compareType="")
  elif mode == self.VVyeJW  : return CCXWrP.VVQOpp(tUrl, compareExt="mkv")
  elif mode == self.VV1mKH  : return CCXWrP.VVQOpp(tUrl, compareExt="mp4")
  elif mode == self.VVK6FS  : return CCXWrP.VVQOpp(tUrl, compareExt="mp3")
  elif mode == self.VVZcKm  : return CCXWrP.VVQOpp(tUrl, compareExt="avi")
  elif mode == self.VVCR9C  : return CCXWrP.VVQOpp(tUrl, compareExt="flv")
  elif mode == self.VV0LCO: return chName.lower().startswith(words[0])
  elif mode == self.VVEOyx: return words[0] in chName.lower()
  elif mode == self.VVHY5c: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVOp4F : return words[0] == VVezVx_lCase
  elif mode == self.VVma7D :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVlqIN(self):
  picker = CC3pKJ(self, self.VVeDC2, "Add to Bouquet", self.VV8Jl0)
 def VV8Jl0(self):
  chUrlLst = []
  for row in self.VVeDC2.VVmbqa():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVed0o(self):
  c1 = VVlyaF
  t1 = FFj5YA("Bouquet", VVAjMy)
  t2 = FFj5YA("ALL", VVAjMy)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVGtpd = []
  VVGtpd.append((c1 + "Check System Acceptable Reference Types" , "VVPXth"    ))
  if self.iptvFileAvailable:
   VVGtpd.append((c1 + "Check Reference Codes Format"  , "VVkaux"    ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVWLwd" ))
  VVGtpd.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVXwrQ_all"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change %s References to Unique Codes" % t2 , "VVEaYY"  ))
  VVGtpd.append(("Change %s References to Identical Codes" % t2 , "VVHZZT_all"  ))
  OKBtnFnc = self.VVrEJa
  FFINMf(self, None, width=1200, title="Reference Tools", VVGtpd=VVGtpd, OKBtnFnc=OKBtnFnc)
 def VVrEJa(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVPXth"    : FFKsz7(menuInstance, self.VVPXth)
   elif item == "VVkaux"     : FFKsz7(menuInstance, self.VVkaux)
   elif item == "VVWLwd" : self.VVWLwd(menuInstance)
   elif item == "VVXwrQ_all"  : self.VVnQYP(menuInstance, None, None)
   elif item == "VVEaYY"  : FFlEph(self, BF(self.VVEaYY , menuInstance, txt), title=txt, VV7fsq=ques)
   elif item == "VVHZZT_all"  : FFlEph(self, BF(FFKsz7, menuInstance, self.VVHZZT), title=txt, VV7fsq=ques)
 def VVnQYP(self, menuInstance, bName, bPath):
  VVGtpd = []
  for rt in CCXWrP.VVvWQW():
   VVGtpd.append(("%s\t ... %s" % (rt, CCXWrP.VVCJ6S(rt)), rt))
  FFINMf(self, BF(self.VVHQ4K, menuInstance, bName, bPath), VVGtpd=VVGtpd, width=800, title="Change Reference Types to:")
 def VVHQ4K(self, menuInstance, bName, bPath, rType=None):
  if rType:
   self.VVJnkM(menuInstance, bName, bPath, rType)
 def VVWLwd(self, menuInstance):
  VVGtpd = CC3pKJ.VVuwX4()
  if VVGtpd:
   FFINMf(self, BF(self.VV30mh, menuInstance), VVGtpd=VVGtpd, title="IPTV Bouquets", VVOvZt=True)
  else:
   FFgjbJ(menuInstance, "No bouquets Found !", 1500)
 def VV30mh(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVCQ1V + span.group(1)
    if fileExists(bPath): self.VVnQYP(menuInstance, bName, bPath)
    else    : FFgjbJ(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFgjbJ(menuInstance, "Cannot process bouquet !", 2000)
 def VVJnkM(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFj5YA(bName, VVNUk6)
  else : title = "Change for %s" % FFj5YA("All IPTV Services", VVNUk6)
  FFlEph(self, BF(FFKsz7, menuInstance, BF(self.VV1T23, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFj5YA(rType, VVNUk6), title=title)
 def VV1T23(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVXy5E()
  if files:
   newRType = rType + ":"
   piconPath = CCMEuJ.VVaKDV()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CC1TwY.VVVE2E(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFoFqK(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFN2Os("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFN2Os(cmd))
  self.VVQSo9(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVYul1(self):
  totFiles = 0
  files  = self.VVXy5E()
  if files:
   totFiles = len(files)
  totChans = 0
  VVzpbP = self.VVWIRd()
  if VVzpbP:
   totChans = len(VVzpbP)
  FFcTZL(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVkaux(self):
  files  = self.VVXy5E()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFEJE4(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVTVTj
   else    : color = VVXz72
   totInvalid = FFj5YA(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFj5YA("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFcTZL(self, txt, title="Check IPTV References")
 def VVPXth(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCXWrP.VVvWQW()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC3pKJ.VVIKtn(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVNl2A = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVNl2A:
   VVmwsq = FFsmA3(VVNl2A)
   if VVmwsq:
    for service in VVmwsq:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVCQ1V + userBName
  bFile = VVCQ1V + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFN2Os("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFN2Os("rm -f '%s'" % path)
  os.system(cmd)
  FFEuF7()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVTVTj
    else     : res, color = "No" , VVXz72
    pl = CCXWrP.VVCJ6S(item)
    txt += "    %s\t: %s%s\n" % (item, FFj5YA(res, color), FFj5YA("\t... %s" % pl, VVOEUE) if pl else "")
   FFcTZL(self, txt, title=title)
  else:
   txt = FFoFqK(self, "Could not complete the test on your system!", title=title)
 def VVGOU8(self):
  VV19bT, err = CC5MnI.VV4kit(self, CC5MnI.VVFzjh)
  if VV19bT:
   totChannels = 0
   totChange = 0
   for path in self.VVXy5E():
    toSave = False
    txt = FFEJE4(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VV19bT.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVQSo9(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFoFqK(self, 'No channels in "lamedb" !')
 def VVEaYY(self, menuInstance, title):
  bFiles = self.VVXy5E()
  if bFiles:
   self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVra9L, bFiles)
       , VV00AH = BF(self.VVAi4Q, title))
  else:
   FFgjbJ(menuInstance, "No bouquets files !", 1500)
 def VVra9L(self, bFiles, VVfBS1):
  VVfBS1.VVcdNf = ""
  VVfBS1.VVRq7B("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF8eQ2(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVfBS1 or VVfBS1.isCancelled:
   return
  elif not totLines:
   VVfBS1.VVcdNf = "No IPTV Services !"
   return
  else:
   VVfBS1.VV9WKz(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF8eQ2(path)
    for ndx, line in enumerate(lines):
     if not VVfBS1 or VVfBS1.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVfBS1:
       VVfBS1.VVRq7B("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVfBS1:
       VVfBS1.VVSxQe(1)
      refCode, startId, startNS = CC3pKJ.VV3Due(rType, CC3pKJ.VVaU6c, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVfBS1:
        VVfBS1.VVcdNf = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVAi4Q(self, title, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVcdNf:
   txt += "\n\n%s\n%s" % (FFj5YA("Ended with Error:", VVXz72), VVcdNf)
  self.VVQSo9(True, title, txt)
 def VVAeob(self):
  bFiles = self.VVXy5E()
  if not bFiles:
   FFgjbJ(self.VVeDC2, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVeDC2.VVmbqa():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFgjbJ(self.VVeDC2, "Cannot read list", 1500)
   return
  self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVeoGH, bFiles, tableRefList)
      , VV00AH = BF(self.VVAi4Q, "Change Current List References to Unique Codes"))
 def VVeoGH(self, bFiles, tableRefList, VVfBS1):
  VVfBS1.VVcdNf = ""
  VVfBS1.VVRq7B("Reading System References ...")
  refLst = CC3pKJ.VVS9za(CC3pKJ.VVaU6c, stripRType=True)
  if not VVfBS1 or VVfBS1.isCancelled:
   return
  VVfBS1.VV9WKz(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFEJE4(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVfBS1 or VVfBS1.isCancelled:
     return
    VVfBS1.VVRq7B("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVfBS1 or VVfBS1.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVfBS1.VVSxQe(1)
      refCode, startId, startNS = CC3pKJ.VV3Due(rType, CC3pKJ.VVaU6c, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVfBS1:
        VVfBS1.VVcdNf = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVHZZT(self):
  list = None
  if self.VVeDC2:
   list = []
   for row in self.VVeDC2.VVmbqa():
    list.append(row[4] + row[5])
  files  = self.VVXy5E()
  totChange = 0
  if files:
   for path in files:
    lines = FF8eQ2(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVQSo9(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVQSo9(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFEuF7()
   if refreshTable and self.VVeDC2:
    VVzpbP = self.VVWIRd()
    if VVzpbP and self.VVeDC2:
     self.VVeDC2.VV6IAT(VVzpbP, self.tableTitle)
     self.VVeDC2.VVdL9K(txt)
   FFcTZL(self, txt, title=title)
  else:
   FFOPTX(self, "No changes.")
 def VVXy5E(self):
  return CCXWrP.VV26sg()
 @staticmethod
 def VV26sg(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVCQ1V + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFEJE4(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVgxI1(self, VVeDC2, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFgvCy(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFeMt4(self, fncMode=CC40v5.VVHyY2, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVJZWb(self, VVeDC2, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVLr1I(self, VVeDC2, title, txt, colList):
  chName, chUrl = self.VVJZWb(VVeDC2, colList)
  self.VVEDbm(VVeDC2, chName, chUrl, "localIptv")
 def VVhO9E(self, mode, VVeDC2, colList):
  chName, chUrl, picUrl, refCode = self.VVbXIz(mode, colList)
  return chName, chUrl
 def VVSyl3(self, mode, VVeDC2, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVbXIz(mode, colList)
  self.VVEDbm(VVeDC2, chName, chUrl, mode)
 def VVEDbm(self, VVeDC2, chName, chUrl, playerFlag):
  chName = FFg0L0(chName)
  if self.VVkrnc(chName):
   FFgjbJ(VVeDC2, "This is a marker!", 300)
  else:
   FFKsz7(VVeDC2, BF(self.VVb043, VVeDC2, chUrl, playerFlag), title="Playing ...")
 def VVb043(self, VVeDC2, chUrl, playerFlag):
  FF4utl(self, chUrl, VVoHm3=False)
  CCi57e.VVnjtb(self.session, iptvTableParams=(self, VVeDC2, playerFlag))
 @staticmethod
 def VVkrnc(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VV1UQI(self, VVeDC2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  if refCode:
   url1 = FFgvCy(origUrl.strip())
   for ndx, row in enumerate(VVeDC2.VVmbqa()):
    if refCode in row[4]:
     tableRow = FFgvCy(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVeDC2.VVvFsV(ndx)
      break
   else:
    FFgjbJ(VVeDC2, "No found", 1000)
 def VV7Yf5(self, m3uMode):
  lines = self.VVSE1j(3)
  if lines:
   lines.sort()
   VVGtpd = []
   for line in lines:
    VVGtpd.append((line, line))
   if m3uMode == CCXWrP.VVI3jb:
    title = "Browse Server from M3U URLs"
    VVDhcZ = ("All to Playlist", self.VVClOL)
   else:
    title = "M3U/M3U8 File Browser"
    VVDhcZ = None
   OKBtnFnc = BF(self.VV3oIz, m3uMode, title)
   infoBtnFnc = self.VVZ6MR
   FFINMf(self, None, title=title, VVGtpd=VVGtpd, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VVDhcZ=VVDhcZ, VVghW2="#11221122", VVlnMM="#11221122")
 def VV3oIz(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCXWrP.VVI3jb:
    FFKsz7(menuInstance, BF(self.VVmcF2, title, path))
   else:
    self.VVsWhK(menuInstance, path)
 def VVsWhK(self, menuInstance, path=None):
  if path:
   VVGtpd = []
   VVGtpd.append(("All"      , "all"  ))
   VVGtpd.append(FFPPw2("Category"))
   VVGtpd.append(("Live TV"     , "live" ))
   VVGtpd.append(("VOD"      , "vod"  ))
   VVGtpd.append(("Series"     , "series" ))
   VVGtpd.append(("Uncategorised"   , "uncat" ))
   VVGtpd.append(FFPPw2("Media"))
   VVGtpd.append(("Video"     , "video" ))
   VVGtpd.append(("Audio"     , "audio" ))
   VVGtpd.append(FFPPw2("File Type"))
   VVGtpd.append(("MKV"      , "MKV"  ))
   VVGtpd.append(("MP4"      , "MP4"  ))
   VVGtpd.append(("MP3"      , "MP3"  ))
   VVGtpd.append(("AVI"      , "AVI"  ))
   VVGtpd.append(("FLV"      , "FLV"  ))
   filterObj = CCZt3D(self, VVghW2="#11552233", VVlnMM="#11552233")
   filterObj.VVmYdR(VVGtpd, [], BF(self.VVftdc, menuInstance, path), inFilterFnc=None)
 def VVftdc(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVYLq2 , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVdFei  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVI561  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVlVbj  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVop1e  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVcQyx  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVTOvg  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVyeJW  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VV1mKH  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVK6FS  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVZcKm  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVCR9C  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVma7D  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCZt3D.VVvY0h(words)
   if not mode == self.VVYLq2:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFj5YA(fTitle, VVOEUE)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFKsz7(menuInstance, BF(self.VVmiEy, path, m3uFilterParam))
 def VVmiEy(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFEJE4(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVICJb = CCzdJA()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVclUn(propLine, "group-title") or "-"
   if not group == "-" and VVICJb.VVOkht(group):
    groups.add(group)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VVzpbP = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVzpbP.append((group, group))
   VVzpbP.append(("ALL", ""))
   VVzpbP.sort(key=lambda x: x[0].lower())
   VVsgQj = self.VVgnoy
   VVLseV  = ("Select" , BF(self.VVTLnS, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVZq8i  = (LEFT  , LEFT)
   FF4zYj(self, None, title=title, width= 1000, header=None, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=30, VVLseV=VVLseV, VVsgQj=VVsgQj, lastFindConfigObj=CFG.lastFindIptv
     , VVghW2="#11110022", VVlnMM="#11110022", VValS2="#11110022", VVKJ4V="#00444400")
  else:
   txt = FFEJE4(srcPath)
   self.VVXW6U(txt, "", m3uFilterParam)
 def VVTLnS(self, srcPath, m3uFilterParam, VVeDC2, title, txt, colList):
  group = colList[1]
  txt = FFEJE4(srcPath)
  self.VVXW6U(txt, group, m3uFilterParam)
 def VVXW6U(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VViJaP, lst, filterGroup, m3uFilterParam)
       , VV00AH = BF(self.VVkfDp, title, bName))
  else:
   self.VV0eud("Not valid lines found !", title)
 def VViJaP(self, lst, filterGroup, m3uFilterParam, VVfBS1):
  VVfBS1.VVcdNf = []
  VVfBS1.VV9WKz(len(lst))
  VVICJb = CCzdJA()
  num = 0
  for cols in lst:
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVclUn(propLine, "tvg-logo")
   group = self.VVclUn(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVICJb.VVOkht(group) : skip = True
    elif chName and not VVICJb.VVOkht(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VV8XNA(mode, "", FFgvCy(url).lower(), chName, words, "", asPrefix)
    if not skip and VVfBS1:
     num += 1
     VVfBS1.VVcdNf.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVkfDp(self, title, bName, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VVcdNf:
   VVsgQj = self.VVgnoy
   VVLseV  = ("Select"   , BF(self.VVSM8P, title)   , [])
   VVXlcT = (""    , self.VVtprH        , [])
   VVtaAK = ("Download PIcons", self.VVVu5x       , [])
   VV0q2u = ("Options"  , BF(self.VVDweH, "m3Ch", "", bName) , [])
   VVyNdP = ("Posters Mode" , BF(self.VVVeQp, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVZq8i  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVcdNf, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVLseV=VVLseV, VVsgQj=VVsgQj, VVXlcT=VVXlcT, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindIptv, VV0i4h=True, searchCol=1
     , VVghW2="#0a00192B", VVlnMM="#0a00192B", VValS2="#0a00192B", VVKJ4V="#00000000")
  else:
   self.VV0eud("Not found !", title)
 def VVVu5x(self, VVeDC2, title, txt, colList):
  self.VV8ah2(VVeDC2, "m3u/m3u8")
 def VVUGh2(self, rowNum, url, chName):
  refCode = self.VVfZ7y(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFiBxf(url), chName)
  return chUrl
 def VVfZ7y(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVzkhN(catID, stID, chNum)
  return refCode
 def VVclUn(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVSM8P(self, Title, VVeDC2, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFKsz7(VVeDC2, BF(self.VVBAwB, Title, VVeDC2, colList), title="Checking Server ...")
  else:
   self.VVWmFy(VVeDC2, url, chName)
 def VVBAwB(self, title, VVeDC2, colList):
  if not CC7Fot.VVaSI5(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCkzVG.VVmuRu(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVGtpd = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCXWrP.VVYnNH(url, fPath)
     VVGtpd.append((resol, fullUrl))
    if VVGtpd:
     if len(VVGtpd) > 1:
      FFINMf(self, BF(self.VVBpn0, VVeDC2, chName), VVGtpd=VVGtpd, title="Resolution", VVOvZt=True, VVsFdc=True)
     else:
      self.VVWmFy(VVeDC2, VVGtpd[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVWmFy(VVeDC2, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCXWrP.VVYnNH(url, span.group(1))
       self.VVWmFy(VVeDC2, fullUrl, chName)
      else:
       self.VVy1Mf("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVXW6U(txt, filterGroup="")
      return
    self.VVWmFy(VVeDC2, url, chName)
   else:
    self.VV0eud("Cannot process this channel !", title)
  else:
   self.VV0eud(err, title)
 def VVBpn0(self, VVeDC2, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVWmFy(VVeDC2, resolUrl, chName)
 def VVWmFy(self, VVeDC2, url, chName):
  FFKsz7(VVeDC2, BF(self.VV5jg6, VVeDC2, url, chName), title="Playing ...")
 def VV5jg6(self, VVeDC2, url, chName):
  chUrl = self.VVUGh2(VVeDC2.VVUy0w(), url, chName)
  FF4utl(self, chUrl, VVoHm3=False)
  CCi57e.VVnjtb(self.session, iptvTableParams=(self, VVeDC2, "m3u/m3u8"))
 def VVWo0a(self, VVeDC2, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVUGh2(VVeDC2.VVUy0w(), url, chName)
  return chName, chUrl
 def VVtprH(self, VVeDC2, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFeMt4(self, fncMode=CC40v5.VVHyY2, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV0eud(self, err, title):
  FFoFqK(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVgnoy(self, VVeDC2):
  if self.m3uOrM3u8File:
   self.close()
  VVeDC2.cancel()
 def VVClOL(self, VVE2XdObj, item=None):
  FFKsz7(VVE2XdObj, BF(self.VVl5t8, VVE2XdObj, item))
 def VVl5t8(self, VVE2XdObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVE2XdObj.VVGtpd):
    path = item[1]
    if fileExists(path):
     enc = CCoiM6.VVfJOY(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCXWrP.VVVEY1(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCXWrP.VVUT7B()
    pListF = "%sPlaylist_%s.txt" % (path, FFbNWS())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVE2XdObj.VVGtpd)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFcTZL(self, txt, title=title)
   else:
    FFoFqK(self, "Could not obtain URLs from this file list !", title=title)
 def VVwd81(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVLSZZ
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV0rPI
  lines = self.VVSE1j(mode)
  if lines:
   lines.sort()
   VVGtpd = []
   for line in lines:
    VVGtpd.append((FFj5YA(line, VVMCs3) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VVZ6MR
   FFINMf(self, None, title=title, VVGtpd=VVGtpd, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VVZ6MR(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FFkas1(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CC1TwY.VVBRyA(sz)
  FFcTZL(self, txt, title="File Path")
 def VVLSZZ(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFKsz7(menuInstance, BF(self.VV9w6H, menuInstance, path), title="Processing File ...")
 def VV9w6H(self, VV7nmp, path):
  enc = CCoiM6.VVfJOY(path, self)
  if enc == -1:
   return
  VVzpbP = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFoR3R(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXWrP.VVDOSW(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVzpbP:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVzpbP.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVzpbP:
   title = "Playlist File : %s" % os.path.basename(path)
   VVLseV  = ("Start"    , BF(self.VVFRRb, "Playlist File")      , [])
   VVJ6wE = ("Home Menu"   , FFjVEj             , [])
   VVtaAK = ("Download M3U File" , self.VVePML         , [])
   VV0q2u = ("Edit File"   , BF(self.VVxlba, path)        , [])
   VVyNdP = ("Check & Filter"  , BF(self.VVbQji, VV7nmp, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVZq8i  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVJ6wE=VVJ6wE, VVyNdP=VVyNdP, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVghW2="#11001116", VVlnMM="#11001116", VValS2="#11001116", VVKJ4V="#00003635", VVEwGL="#0a333333", VVtDKG="#11331100", VV0i4h=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFoFqK(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVePML(self, VVeDC2, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFlEph(self, BF(FFKsz7, VVeDC2, BF(self.VV8I2x, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV8I2x(self, title, url):
  path, err = FFg3JL(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFoFqK(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFEJE4(path)
   if '{"user_info":{"auth":0}}' in txt:
    FF9qnP(path)
    FFoFqK(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FF9qnP(path)
    FFoFqK(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCXWrP.VVUT7B() + fName
    os.system(FFN2Os("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFOPTX(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFoFqK(self, "Could not download the M3U file!", title=errTitle)
 def VVFRRb(self, Title, VVeDC2, title, txt, colList):
  url = colList[6]
  FFKsz7(VVeDC2, BF(self.VVb7UF, Title, url), title="Checking Server ...")
 def VVxlba(self, path, VVeDC2, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCkPUj(self, path, VV00AH=BF(self.VVSVRS, VVeDC2), curRowNum=rowNum)
  else    : FFE0MG(self, path)
 def VVSVRS(self, VVeDC2, fileChanged):
  if fileChanged:
   VVeDC2.cancel()
 def VVdpDN(self, title):
  curChName = self.VVeDC2.VVhJef(1)
  FF8cVc(self, BF(self.VV4tPF, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV4tPF(self, title, name):
  if name:
   VV19bT, err = CC5MnI.VV4kit(self, CC5MnI.VV4vFK, VVa1kB=False, VVjxU1=False)
   list = []
   if VV19bT:
    VVICJb = CCzdJA()
    name = VVICJb.VV2pbV(name)
    ratio = "1"
    for item in VV19bT:
     if name in item[0].lower():
      list.append((item[0], FF8CMQ(item[2]), item[3], ratio))
   if list : self.VVu8bi(list, title)
   else : FFoFqK(self, "Not found:\n\n%s" % name, title=title)
 def VVzVVf(self, title):
  curChName = self.VVeDC2.VVhJef(1)
  self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVuoOk
      , VV00AH = BF(self.VV0XnS, title, curChName))
 def VVuoOk(self, VVfBS1):
  curChName = self.VVeDC2.VVhJef(1)
  VV19bT, err = CC5MnI.VV4kit(self, CC5MnI.VVvv2B, VVa1kB=False, VVjxU1=False)
  if not VV19bT or not VVfBS1 or VVfBS1.isCancelled:
   return
  VVfBS1.VVcdNf = []
  VVfBS1.VV9WKz(len(VV19bT))
  VVICJb = CCzdJA()
  curCh = VVICJb.VV2pbV(curChName)
  for refCode in VV19bT:
   chName, sat, inDB = VV19bT.get(refCode, ("", "", 0))
   ratio = CCMEuJ.VVbcV8(chName.lower(), curCh)
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1, True)
   if VVfBS1 and ratio > 50:
    VVfBS1.VVcdNf.append((chName, FF8CMQ(sat), refCode.replace("_", ":"), str(ratio)))
 def VV0XnS(self, title, curChName, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VVcdNf: self.VVu8bi(VVcdNf, title)
  elif VV9pDl: FFoFqK(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVu8bi(self, VVzpbP, title):
  curChName = self.VVeDC2.VVhJef(1)
  VVR5Bl = self.VVeDC2.VVhJef(4)
  curUrl  = self.VVeDC2.VVhJef(5)
  VVzpbP.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVLseV  = ("Share Sat/C/T Ref.", BF(self.VVSCGE, title, curChName, VVR5Bl, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVghW2="#0a00112B", VVlnMM="#0a001126", VValS2="#0a001126", VVKJ4V="#00000000")
 def VVSCGE(self, newtitle, curChName, VVR5Bl, curUrl, VVeDC2, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVR5Bl, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFlEph(self.VVeDC2, BF(FFKsz7, self.VVeDC2, BF(self.VVLLy2, VVeDC2, data)), ques, title=newtitle, VV4A3A=True)
 def VVLLy2(self, VVeDC2, data):
  VVeDC2.cancel()
  title, curChName, VVR5Bl, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVR5Bl = VVR5Bl.strip()
  newRefCode = newRefCode.strip()
  if not VVR5Bl.endswith(":") : VVR5Bl += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVR5Bl, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVR5Bl + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVXy5E():
    txt = FFEJE4(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFEuF7()
    newRow = []
    for i in range(6):
     newRow.append(self.VVeDC2.VVhJef(i))
    newRow[4] = newRefCode
    done = self.VVeDC2.VVji2V(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFkWtI(BF(FFOPTX , self, resTxt, title=title))
  elif resErr: FFkWtI(BF(FFoFqK, self, resErr, title=title))
 def VVbQji(self, VV7nmp, path, VVeDC2, title, txt, colList):
  self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVooAk, VVeDC2)
      , VV00AH = BF(self.VVEMT5, VV7nmp, path, VVeDC2))
 def VVooAk(self, VVeDC2, VVfBS1):
  VVfBS1.VV9WKz(VVeDC2.VVpRlV())
  VVfBS1.VVcdNf = []
  for row in VVeDC2.VVmbqa():
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1, True)
   qUrl = self.VVrARv(self.VV5hta, row[6])
   txt, err = self.VVmjdi(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV6FjI(item, "auth") == "0":
       VVfBS1.VVcdNf.append(qUrl)
    except:
     pass
 def VVEMT5(self, VV7nmp, path, VVeDC2, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VV9pDl:
   list = VVcdNf
   title = "Authorized Servers"
   if list:
    totChk = VVeDC2.VVpRlV()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFbNWS()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVwd81(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFj5YA(str(totAuth), VVTVTj)
     txt += "%s\n\n%s"    %  (FFj5YA("Result File:", VVMCs3), newPath)
     FFcTZL(self, txt, title=title)
     VVeDC2.close()
     VV7nmp.close()
    else:
     FFOPTX(self, "All URLs are authorized.", title=title)
   else:
    FFoFqK(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVmjdi(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVDOSW(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVQOpp(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CC8VbN.VVB1kx()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVo7hy(decodedUrl):
  return CCXWrP.VVQOpp(decodedUrl, justRetDotExt=True)
 def VVrARv(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVDOSW(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV5hta   : return "%s"            % url
  elif mode == self.VVQ6fI   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVztTk   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVKYPw  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVYAZY  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVuoNK : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVO1rz   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVqldT    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVthva  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVpwH6 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVKK8G  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV6FjI(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF5ivG(int(val))
    elif is_base64 : val = FFqKcx(val)
    elif isToHHMMSS : val = FF1ZBm(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVmcF2(self, title, path):
  if fileExists(path):
   enc = CCoiM6.VVfJOY(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCXWrP.VVVEY1(line)
     if qUrl:
      break
   if qUrl : self.VVb7UF(title, qUrl)
   else : FFoFqK(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFoFqK(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVZgj5(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCXWrP.VVE89T(self)
  if qUrl or "chCode" in iptvRef:
   p = CCkzVG()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVMGkt(iptvRef)
   if valid:
    self.VVXtml(self, host, mac)
    return
   elif qUrl:
    FFKsz7(self, BF(self.VVb7UF, title, qUrl), title="Checking Server ...")
    return
  FFoFqK(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVE89T(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF)
  qUrl = CCXWrP.VVVEY1(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVVEY1(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVb7UF(self, title, url):
  self.curUrl = url
  self.VV7lPdData = {}
  qUrl = self.VVrARv(self.VV5hta, url)
  txt, err = self.VVmjdi(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV7lPdData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV7lPdData["username"    ] = self.VV6FjI(item, "username"        )
    self.VV7lPdData["password"    ] = self.VV6FjI(item, "password"        )
    self.VV7lPdData["message"    ] = self.VV6FjI(item, "message"        )
    self.VV7lPdData["auth"     ] = self.VV6FjI(item, "auth"         )
    self.VV7lPdData["status"    ] = self.VV6FjI(item, "status"        )
    self.VV7lPdData["exp_date"    ] = self.VV6FjI(item, "exp_date"    , isDate=True )
    self.VV7lPdData["is_trial"    ] = self.VV6FjI(item, "is_trial"        )
    self.VV7lPdData["active_cons"   ] = self.VV6FjI(item, "active_cons"       )
    self.VV7lPdData["created_at"   ] = self.VV6FjI(item, "created_at"   , isDate=True )
    self.VV7lPdData["max_connections"  ] = self.VV6FjI(item, "max_connections"      )
    self.VV7lPdData["allowed_output_formats"] = self.VV6FjI(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV7lPdData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV7lPdData["url"    ] = self.VV6FjI(item, "url"        )
    self.VV7lPdData["port"    ] = self.VV6FjI(item, "port"        )
    self.VV7lPdData["https_port"  ] = self.VV6FjI(item, "https_port"      )
    self.VV7lPdData["server_protocol" ] = self.VV6FjI(item, "server_protocol"     )
    self.VV7lPdData["rtmp_port"   ] = self.VV6FjI(item, "rtmp_port"       )
    self.VV7lPdData["timezone"   ] = self.VV6FjI(item, "timezone"       )
    self.VV7lPdData["timestamp_now"  ] = self.VV6FjI(item, "timestamp_now"  , isDate=True )
    self.VV7lPdData["time_now"   ] = self.VV6FjI(item, "time_now"       )
    VVGtpd  = self.VVpTQi(True)
    OKBtnFnc = self.VViEWc
    infoBtnFnc = self.VVXeyi
    VVuZl0 = ("Home Menu", FFjVEj)
    VV3Pkd= ("Add to Menu", BF(CCXWrP.VVld2V, self, False, self.VV7lPdData["playListURL"]))
    VVDhcZ = ("Bookmark Server", BF(CCXWrP.VV1geq, self, False, self.VV7lPdData["playListURL"]))
    FFINMf(self, None, title="IPTV Server Resources", VVGtpd=VVGtpd, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVuZl0=VVuZl0, VV3Pkd=VV3Pkd, VVDhcZ=VVDhcZ)
   else:
    err = "Could not get data from server !"
  if err:
   FFoFqK(self, err, title=title)
  FFgjbJ(self)
 def VViEWc(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFKsz7(menuInstance, BF(self.VVTB9N, self.VVQ6fI  , title=title), title=wTxt)
   elif ref == "vod"   : FFKsz7(menuInstance, BF(self.VVTB9N, self.VVztTk  , title=title), title=wTxt)
   elif ref == "series"  : FFKsz7(menuInstance, BF(self.VVTB9N, self.VVKYPw , title=title), title=wTxt)
   elif ref == "catchup"  : FFKsz7(menuInstance, BF(self.VVTB9N, self.VVYAZY , title=title), title=wTxt)
   elif ref == "accountInfo" : FFKsz7(menuInstance, BF(self.VVsBZi           , title=title), title=wTxt)
 def VVXeyi(self, menuInstance, txt, ref, ndx):
  FFKsz7(menuInstance, self.VV26kP)
 def VV26kP(self):
  txt = self.curUrl
  if VVwdnn:
   ver, err = self.VVpHpn(self.VVJRoY())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVfAyW
   txt += "PHP\t: %s\n"  % self.VVTdWu
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVmoVr, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFcTZL(self, txt, title="Current Server URL")
 def VVsBZi(self, title):
  rows = []
  for key, val in self.VV7lPdData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VV2CLV
   else:
    num, part = "1", self.VVjdv5
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVJ6wE  = ("Home Menu", FFjVEj, [])
  VVtaAK  = None
  if VVwdnn:
   VVtaAK = ("Get JS" , BF(self.VVhvTw, "/".join(self.VV7lPdData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FF4zYj(self, None, title=title, width=1200, header=header, VVkGEY=rows, VVsmwq=widths, VVdez8=26, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000", searchCol=2)
 def VVRBCW(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVICJb = CCzdJA()
    if mode in (self.VVO1rz, self.VVKK8G):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV6FjI(item, "num"         )
      name     = self.VV6FjI(item, "name"        )
      stream_id    = self.VV6FjI(item, "stream_id"       )
      stream_icon    = self.VV6FjI(item, "stream_icon"       )
      epg_channel_id   = self.VV6FjI(item, "epg_channel_id"      )
      added     = self.VV6FjI(item, "added"    , isDate=True )
      is_adult    = self.VV6FjI(item, "is_adult"       )
      category_id    = self.VV6FjI(item, "category_id"       )
      tv_archive    = self.VV6FjI(item, "tv_archive"       )
      direct_source   = self.VV6FjI(item, "direct_source"      )
      tv_archive_duration  = self.VV6FjI(item, "tv_archive_duration"     )
      name = VVICJb.VVOkht(name, is_adult)
      if name:
       if mode == self.VVO1rz or mode == self.VVKK8G and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVqldT:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV6FjI(item, "num"         )
      name    = self.VV6FjI(item, "name"        )
      stream_id   = self.VV6FjI(item, "stream_id"       )
      stream_icon   = self.VV6FjI(item, "stream_icon"       )
      added    = self.VV6FjI(item, "added"    , isDate=True )
      is_adult   = self.VV6FjI(item, "is_adult"       )
      category_id   = self.VV6FjI(item, "category_id"       )
      container_extension = self.VV6FjI(item, "container_extension"     ) or "mp4"
      name = VVICJb.VVOkht(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVthva:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV6FjI(item, "num"        )
      name    = self.VV6FjI(item, "name"       )
      series_id   = self.VV6FjI(item, "series_id"      )
      cover    = self.VV6FjI(item, "cover"       )
      genre    = self.VV6FjI(item, "genre"       )
      episode_run_time = self.VV6FjI(item, "episode_run_time"    )
      category_id   = self.VV6FjI(item, "category_id"      )
      container_extension = self.VV6FjI(item, "container_extension"    ) or "mp4"
      name = VVICJb.VVOkht(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVTB9N(self, mode, title):
  cList, err = self.VVVAd2(mode)
  if cList and mode == self.VVYAZY:
   cList = self.VVqDeu(cList)
  if err:
   FFoFqK(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3(mode)
   mName = self.VVBNqO(mode)
   if   mode == self.VVQ6fI  : fMode = self.VVO1rz
   elif mode == self.VVztTk  : fMode = self.VVqldT
   elif mode == self.VVKYPw : fMode = self.VVthva
   elif mode == self.VVYAZY : fMode = self.VVKK8G
   if mode == self.VVYAZY:
    VV0q2u = None
    VVyNdP = None
   else:
    VV0q2u = ("Find in %s" % mName , BF(self.VVzNQu, fMode, True) , [])
    VVyNdP = ("Find in Selected" , BF(self.VVzNQu, fMode, False) , [])
   VVLseV   = ("Show List"   , BF(self.VV6Xm4, mode)  , [])
   VVJ6wE  = ("Home Menu"   , FFjVEj         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF4zYj(self, None, title=title, width=1200, header=header, VVkGEY=cList, VVsmwq=widths, VVdez8=30, VVJ6wE=VVJ6wE, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVLseV=VVLseV, VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVKJ4V=VVKJ4V, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFoFqK(self, "No list from server !", title=title)
  FFgjbJ(self)
 def VVVAd2(self, mode):
  qUrl  = self.VVrARv(mode, self.VV7lPdData["playListURL"])
  txt, err = self.VVmjdi(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVICJb = CCzdJA()
    for item in tDict:
     category_id  = self.VV6FjI(item, "category_id"  )
     category_name = self.VV6FjI(item, "category_name" )
     parent_id  = self.VV6FjI(item, "parent_id"  )
     category_name = VVICJb.VVDV8e(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVqDeu(self, catList):
  mode  = self.VVKK8G
  qUrl  = self.VVrARv(mode, self.VV7lPdData["playListURL"])
  txt, err = self.VVmjdi(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVRBCW(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV6Xm4(self, mode, VVeDC2, title, txt, colList):
  title = colList[1]
  FFKsz7(VVeDC2, BF(self.VV3Dnv, mode, VVeDC2, title, txt, colList), title="Downloading ...")
 def VV3Dnv(self, mode, VVeDC2, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVBNqO(mode) + " : "+ bName
  if   mode == self.VVQ6fI  : mode = self.VVO1rz
  elif mode == self.VVztTk  : mode = self.VVqldT
  elif mode == self.VVKYPw : mode = self.VVthva
  elif mode == self.VVYAZY : mode = self.VVKK8G
  qUrl  = self.VVrARv(mode, self.VV7lPdData["playListURL"], catID)
  txt, err = self.VVmjdi(qUrl)
  list  = []
  if not err and mode in (self.VVO1rz, self.VVqldT, self.VVthva, self.VVKK8G):
   list, err = self.VVRBCW(mode, txt)
  if err:
   FFoFqK(self, err, title=title)
  elif list:
   VVJ6wE  = ("Home Menu"   , FFjVEj            , [])
   if mode in (self.VVO1rz, self.VVKK8G):
    VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3(mode)
    VVXlcT = (""     , BF(self.VVIAWm, mode)      , [])
    VVtaAK = ("Download Options" , BF(self.VVnM56, mode, "", "")   , [])
    VV0q2u = ("Options"   , BF(self.VVDweH, "lv", mode, bName)   , [])
    VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, False)     , [])
    if mode == self.VVO1rz:
     VVLseV = ("Play"    , BF(self.VVSyl3, mode)       , [])
    else:
     VVLseV = ("Programs"   , BF(self.VV76kV, mode, bName) , [])
   elif mode == self.VVqldT:
    VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3(mode)
    VVLseV  = ("Play"    , BF(self.VVSyl3, mode)       , [])
    VVXlcT = (""     , BF(self.VVIAWm, mode)      , [])
    VVtaAK = ("Download Options" , BF(self.VVnM56, mode, "v", "")   , [])
    VV0q2u = ("Options"   , BF(self.VVDweH, "v", mode, bName)   , [])
    VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, False)     , [])
   elif mode == self.VVthva:
    VVghW2, VVlnMM, VValS2, VVKJ4V = self.VVZYY3("series2")
    VVLseV  = ("Show Seasons"  , BF(self.VVi3eX, mode)       , [])
    VVXlcT = (""     , BF(self.VVi9uX, mode)     , [])
    VVtaAK = None
    VV0q2u = None
    VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, True)      , [])
   header, widths, VVZq8i = self.VVRIJ4(mode)
   FF4zYj(self, None, title=title, header=header, VVkGEY=list, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindIptv, VVXlcT=VVXlcT, VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVKJ4V=VVKJ4V, VV0i4h=True, searchCol=1)
  else:
   FFoFqK(self, "No Channels found !", title=title)
  FFgjbJ(self)
 def VVRIJ4(self, mode):
  if mode in (self.VVO1rz, self.VVKK8G):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVZq8i  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVqldT:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVZq8i  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVthva:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVZq8i  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVZq8i
 def VV76kV(self, mode, bName, VVeDC2, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV7lPdData["playListURL"]
  ok_fnc  = BF(self.VVJXpS, hostUrl, chName, catId, streamId)
  FFKsz7(VVeDC2, BF(CCXWrP.VV6HeQ, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVJXpS(self, chUrl, chName, catId, streamId, VVeDC2, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXWrP.VVDOSW(chUrl)
   chNum = "333"
   refCode = CCXWrP.VVzkhN(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FF4utl(self, chUrl, VVoHm3=False)
   CCi57e.VVnjtb(self.session)
  else:
   FFoFqK(self, "Incorrect Timestamp", pTitle)
 def VVi3eX(self, mode, VVeDC2, title, txt, colList):
  title = colList[1]
  FFKsz7(VVeDC2, BF(self.VVVwVf, mode, VVeDC2, title, txt, colList), title="Downloading ...")
 def VVVwVf(self, mode, VVeDC2, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVrARv(self.VVuoNK, self.VV7lPdData["playListURL"], series_id)
  txt, err = self.VVmjdi(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV6FjI(tDict["info"], "name"   )
      category_id = self.VV6FjI(tDict["info"], "category_id" )
      icon  = self.VV6FjI(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVICJb = CCzdJA()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV6FjI(EP, "id"     )
        episode_num   = self.VV6FjI(EP, "episode_num"   )
        epTitle    = self.VV6FjI(EP, "title"     )
        container_extension = self.VV6FjI(EP, "container_extension" )
        seasonNum   = self.VV6FjI(EP, "season"    )
        epTitle = VVICJb.VVOkht(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFoFqK(self, err, title=title)
  elif list:
   VVJ6wE = ("Home Menu"   , FFjVEj          , [])
   VVtaAK = ("Download Options" , BF(self.VVnM56, mode, "s", title), [])
   VV0q2u = ("Options"   , BF(self.VVDweH, "s", mode, title) , [])
   VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, False)   , [])
   VVXlcT = (""     , BF(self.VVIAWm, mode)    , [])
   VVLseV  = ("Play"    , BF(self.VVSyl3, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVZq8i  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF4zYj(self, None, title=title, header=header, VVkGEY=list, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VVLseV=VVLseV, VVXlcT=VVXlcT, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindIptv, VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000")
  else:
   FFoFqK(self, "No Channels found !", title=title)
  FFgjbJ(self)
 def VVzNQu(self, mode, isAll, VVeDC2, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVGtpd = []
  VVGtpd.append(("Keyboard"  , "manualEntry"))
  VVGtpd.append(("From Filter" , "fromFilter"))
  FFINMf(self, BF(self.VVY5ek, VVeDC2, mode, onlyCatID), title="Input Type", VVGtpd=VVGtpd, width=400)
 def VVY5ek(self, VVeDC2, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF8cVc(self, BF(self.VVk9Jt, VVeDC2, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCZt3D(self)
    filterObj.VVTzbi(BF(self.VVk9Jt, VVeDC2, mode, onlyCatID))
 def VVk9Jt(self, VVeDC2, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFSmZ2(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCZt3D.VVvY0h(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFoFqK(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFoFqK(self, "All words must be at least 3 characters !", title=title)
        return
     VVICJb = CCzdJA()
     if CFG.hideIptvServerAdultWords.getValue() and VVICJb.VVtzrp(words):
      FFoFqK(self, VVICJb.VVaMpR(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVtlzE, VVeDC2, mode, onlyCatID, title, words, toFind, asPrefix, VVICJb)
          , VV00AH = BF(self.VVg5v4, mode, toFind, title))
   if not words:
    FFgjbJ(VVeDC2, "Nothing to find !", 1500)
 def VVtlzE(self, VVeDC2, mode, onlyCatID, title, words, toFind, asPrefix, VVICJb, VVfBS1):
  VVfBS1.VV9WKz(VVeDC2.VVz6J6() if onlyCatID is None else 1)
  VVfBS1.VVcdNf = []
  for row in VVeDC2.VVmbqa():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVSxQe(1)
   VVfBS1.VVisIo(catName)
   qUrl  = self.VVrARv(mode, self.VV7lPdData["playListURL"], catID)
   txt, err = self.VVmjdi(qUrl)
   if not err:
    tList, err = self.VVRBCW(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVICJb.VVOkht(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVfBS1.VVcdNf.append(item)
 def VVg5v4(self, mode, toFind, title, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VVcdNf:
   title = self.VVRuoe(mode, toFind)
   if mode == self.VVO1rz or mode == self.VVqldT:
    if mode == self.VVqldT : typ = "v"
    else          : typ = ""
    bName   = CCXWrP.VVbum4(toFind)
    VVLseV  = ("Play"     , BF(self.VVSyl3, mode)     , [])
    VVtaAK = ("Download Options" , BF(self.VVnM56, mode, typ, "") , [])
    VV0q2u = ("Options"   , BF(self.VVDweH, "fnd", mode, bName), [])
    VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, False)   , [])
    VVXlcT = (""     , BF(self.VVIAWm, mode)    , [])
   elif mode == self.VVthva:
    VVLseV  = ("Show Seasons"  , BF(self.VVi3eX, mode)     , [])
    VV0q2u = None
    VVtaAK = None
    VVyNdP = ("Posters Mode"  , BF(self.VVVeQp, mode, True)    , [])
    VVXlcT = (""     , BF(self.VVi9uX, mode)   , [])
   VVJ6wE  = ("Home Menu"   , FFjVEj          , [])
   header, widths, VVZq8i = self.VVRIJ4(mode)
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVcdNf, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVXlcT=VVXlcT, VVghW2="#0a00292B", VVlnMM="#0a002126", VValS2="#0a002126", VVKJ4V="#00000000", VV0i4h=True, searchCol=1)
   if not VV9pDl:
    FFgjbJ(VVeDC2, "Stopped" , 1000)
  else:
   if VV9pDl:
    FFoFqK(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVbXIz(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVO1rz, self.VVKK8G):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVqldT:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFg0L0(chName)
  url = self.VV7lPdData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVDOSW(url)
  refCode = self.VVzkhN(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVIAWm(self, mode, VVeDC2, title, txt, colList):
  FFKsz7(VVeDC2, BF(self.VVTUBZ, mode, VVeDC2, title, txt, colList))
 def VVTUBZ(self, mode, VVeDC2, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVbXIz(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFeMt4(self, fncMode=CC40v5.VVwyS7, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVi9uX(self, mode, VVeDC2, title, txt, colList):
  FFKsz7(VVeDC2, BF(self.VVrLSK, mode, VVeDC2, title, txt, colList))
 def VVrLSK(self, mode, VVeDC2, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFeMt4(self, fncMode=CC40v5.VVNv6g, chName=name, text=txt, picUrl=Cover)
 def VVVeQp(self, mode, isSerNames, VVeDC2, title, txt, colList):
  if   mode in ("itv"  , CCXWrP.VVO1rz, CCXWrP.VVKK8G): category = "live"
  elif mode in ("vod"  , CCXWrP.VVqldT )          : category = "vod"
  elif mode in ("series" , CCXWrP.VVthva)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVO1rz : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVKK8G : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVqldT  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVthva : picCol, descCol, descTxt = 5, 0, "Season"
  FFKsz7(VVeDC2, BF(self.session.open, CCztM1, VVeDC2, category, nameCol, picCol, descCol, descTxt))
 def VVnM56(self, mode, typ, seriesName, VVeDC2, title, txt, colList):
  VVGtpd = []
  isMulti = VVeDC2.VVFCH5
  tot  = VVeDC2.VVau1b()
  if isMulti:
   if tot < 1:
    FFgjbJ(VVeDC2, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVGtpd.append(("Download %s PIcon%s" % (name, FFLQjK(tot)), "dnldPicons" ))
  if typ:
   VVGtpd.append(VVttU7)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVGtpd.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVGtpd.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVGtpd.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCxguE.VVCmgk():
    VVGtpd.append(VVttU7)
    VVGtpd.append(("Download Manager"      , "dload_stat" ))
  FFINMf(self, BF(self.VVTdfN, VVeDC2, mode, typ, seriesName, colList), title="Download Options", VVGtpd=VVGtpd)
 def VVTdfN(self, VVeDC2, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV8ah2(VVeDC2, mode)
   elif item == "dnldSel"  : self.VVSWAX(VVeDC2, mode, typ, colList, True)
   elif item == "addSel"  : self.VVSWAX(VVeDC2, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVh3l3(VVeDC2, mode, typ, seriesName)
   elif item == "dload_stat" : CCxguE.VVZs2U(self)
 def VVSWAX(self, VVeDC2, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVGBmE(mode, typ, colList)
  if startDnld:
   CCxguE.VVwpDG(self, decodedUrl)
  else:
   self.VVn0ik(VVeDC2, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVh3l3(self, VVeDC2, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVeDC2.VVmbqa():
   chName, decodedUrl = self.VVGBmE(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVn0ik(VVeDC2, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVn0ik(self, VVeDC2, title, chName, decodedUrl_list, startDnld):
  FFlEph(self, BF(self.VVSXPm, VVeDC2, decodedUrl_list, startDnld), chName, title=title)
 def VVSXPm(self, VVeDC2, decodedUrl_list, startDnld):
  added, skipped = CCxguE.VVDxMf(decodedUrl_list)
  FFgjbJ(VVeDC2, "Added", 1000)
 def VVGBmE(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVbXIz(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, colList)
   refCode, chUrl = self.VV5BKM(self.VVfAyW, self.VVdFeQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFfLGx(chUrl)
  return chName, decodedUrl
 def VV8ah2(self, VVeDC2, mode):
  if os.system(FFN2Os("which ffmpeg")) == 0:
   self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVm8Nq, VVeDC2, mode)
       , VV00AH = self.VVJ1Hr)
  else:
   FFlEph(self, BF(CCXWrP.VVxbSn, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVJ1Hr(self, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVcdNf["proces"], VVcdNf["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVcdNf["ok"], VVcdNf["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVcdNf["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVcdNf["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVcdNf["badURL"]
  txt += "Download Failure\t: %d\n"   % VVcdNf["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVcdNf["path"]
  if not VV9pDl  : color = "#11402000"
  elif VVcdNf["err"]: color = "#11201000"
  else     : color = None
  if VVcdNf["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVcdNf["err"], txt)
  title = "PIcons Download Result"
  if not VV9pDl:
   title += "  (cancelled)"
  FFcTZL(self, txt, title=title, VValS2=color)
 def VVm8Nq(self, VVeDC2, mode, VVfBS1):
  isMulti = VVeDC2.VVFCH5
  if isMulti : totRows = VVeDC2.VVau1b()
  else  : totRows = VVeDC2.VVz6J6()
  VVfBS1.VV9WKz(totRows)
  VVfBS1.VVWtM0(0)
  counter     = VVfBS1.counter
  maxValue    = VVfBS1.maxValue
  pPath     = CCMEuJ.VVaKDV()
  VVfBS1.VVcdNf = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVeDC2.VVmbqa()):
    if VVfBS1.isCancelled:
     break
    if not isMulti or VVeDC2.VVZg6r(rowNum):
     VVfBS1.VVcdNf["proces"] += 1
     VVfBS1.VVSxQe(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, row)
      refCode = CCXWrP.VVzkhN(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVfZ7y(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVbXIz(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVfBS1.VVcdNf["attempt"] += 1
       path, err = FFg3JL(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVfBS1:
         VVfBS1.VVcdNf["ok"] += 1
         VVfBS1.VVWtM0(VVfBS1.VVcdNf["ok"])
        if FFkas1(path) > 0:
         cmd = CC40v5.VVaKtk(path)
         cmd += FFN2Os("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVfBS1:
          VVfBS1.VVcdNf["size0"] += 1
         FF9qnP(path)
       elif err:
        if VVfBS1:
         VVfBS1.VVcdNf["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVfBS1:
          VVfBS1.VVcdNf["err"] = err.title()
         break
      else:
       if VVfBS1:
        VVfBS1.VVcdNf["exist"] += 1
     else:
      if VVfBS1:
       VVfBS1.VVcdNf["badURL"] += 1
  except:
   pass
 def VVmfNw(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFN2Os("which ffmpeg")) == 0:
   self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
       , titlePrefix = ""
       , fncToRun  = self.VVSiB5
       , VV00AH = BF(self.VVA4eS, title))
  else:
   FFlEph(self, BF(CCXWrP.VVxbSn, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVSiB5(self, VVfBS1):
  bName = CC3pKJ.VVqz5e()
  pPath = CCMEuJ.VVaKDV()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVfBS1.VVcdNf = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC3pKJ.VVDzSY()
  if not VVfBS1 or VVfBS1.isCancelled:
   return
  if not services or len(services) == 0:
   VVfBS1.VVcdNf = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVfBS1.VV9WKz(totCh)
  VVfBS1.VVWtM0(0)
  for serv in services:
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   VVfBS1.VVcdNf = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVfBS1.VVSxQe(1)
   VVfBS1.VVWtM0(totPic)
   fullRef  = serv[0]
   if FFBTpz(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFfLGx(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCkzVG.VVSQqB(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCXWrP.VVmjdi(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CC40v5.VV8N1n(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFg3JL(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVfBS1:
     VVfBS1.VVWtM0(totPic)
    if FFkas1(path) > 0:
     cmd = CC40v5.VVaKtk(path)
     cmd += FFN2Os("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FF9qnP(path)
  if VVfBS1:
   VVfBS1.VVcdNf = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVA4eS(self, title, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVcdNf
  if err:
   FFoFqK(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFj5YA(str(totExist)  , VVXz72)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFj5YA(str(totNotIptv)  , VVXz72)
    if totServErr : txt += "Server Errors\t: %s\n" % FFj5YA(str(totServErr) + t1, VVXz72)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFj5YA(str(totParseErr) , VVXz72)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFj5YA(str(totInvServ)  , VVXz72)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFj5YA(str(totInvPicUrl) , VVXz72)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFj5YA(str(totSize0)  , VVXz72)
   if not VV9pDl:
    title += "  (stopped)"
   FFcTZL(self, txt, title=title)
 @staticmethod
 def VVxbSn(SELF):
  cmd = FFDHcv(VVKyPA, "ffmpeg")
  if cmd : FFB1pa(SELF, cmd, title="Installing FFmpeg")
  else : FFmApx(SELF)
 @staticmethod
 def VV27Ot(SELF):
  SELF.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2
      , titlePrefix = ""
      , fncToRun  = CCXWrP.VVUJOW
      , VV00AH = BF(CCXWrP.VVDElT, SELF))
 @staticmethod
 def VVUJOW(VVfBS1):
  bName = CC3pKJ.VVqz5e()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVfBS1.VVcdNf = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC3pKJ.VVDzSY()
  if not VVfBS1 or VVfBS1.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVfBS1.VV9WKz(totCh)
   for serv in services:
    if not VVfBS1 or VVfBS1.isCancelled:
     return
    VVfBS1.VVSxQe(1)
    fullRef = serv[0]
    if FFBTpz(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFfLGx(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCkzVG.VVSQqB(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(m3u_Url)
     if VVfBS1:
      VVfBS1.VVJhZJ(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCXWrP.VVTJDY(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CC8SZQ.VVavFa(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVfBS1:
     VVfBS1.VVcdNf = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVfBS1.VVcdNf = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVDElT(SELF, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVcdNf
  title = "IPTV EPG Import"
  if err:
   FFoFqK(SELF, err, title=title)
  else:
   if VV9pDl and totEpgOK > 0:
    CC8SZQ.VVYZ0A()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFj5YA(str(totNotIptv), VVXz72)
    if totServErr : txt += "Server Errors\t: %s\n" % FFj5YA(str(totServErr) + t1, VVXz72)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFj5YA(str(totInv), VVXz72)
   if not VV9pDl:
    title += "  (stopped)"
   FFcTZL(SELF, txt, title=title)
 @staticmethod
 def VVTJDY(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCXWrP.VVDOSW(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCXWrP.VVmjdi(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCXWrP.VV6FjI(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCXWrP.VV6FjI(item, "lang"        ).upper()
    now_playing   = CCXWrP.VV6FjI(item, "now_playing"      )
    start    = CCXWrP.VV6FjI(item, "start"        )
    start_timestamp  = CCXWrP.VV6FjI(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCXWrP.VV6FjI(item, "start_timestamp"     )
    stop_timestamp  = CCXWrP.VV6FjI(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCXWrP.VV6FjI(item, "stop_timestamp"      )
    tTitle    = CCXWrP.VV6FjI(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVzkhN(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCXWrP.VVKp9A(catID, MAX_4b)
  TSID = CCXWrP.VVKp9A(chNum, MAX_4b)
  ONID = CCXWrP.VVKp9A(chNum, MAX_4b)
  NS  = CCXWrP.VVKp9A(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVKp9A(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVbum4(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVZYY3(mode):
  if   mode in ("itv"  , CCXWrP.VVQ6fI)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCXWrP.VVztTk)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCXWrP.VVKYPw) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCXWrP.VVYAZY) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCXWrP.VVKK8G    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVSE1j(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVoZbD:
   excl = FFxM0r(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFoFqK(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFCpSv('find %s %s %s' % (path, excl, par))
  if files:
   err = CC1TwY.VVQSTE(files)
   if err : FFoFqK(self, err + FFj5YA('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVMCs3))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFoFqK(self, err)
  return []
 @staticmethod
 def VVUT7B():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFoR3R(path)
  return "/"
 @staticmethod
 def VV6HeQ(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCXWrP.VVTJDY(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFoFqK(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVghW2, VVlnMM, VValS2, VVKJ4V = CCXWrP.VVZYY3("")
   VVJ6wE = ("Home Menu" , FFjVEj, [])
   VVLseV  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVZq8i  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF4zYj(SELF, None, title="Programs for : " + chName, header=header, VVkGEY=pList, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=24, VVLseV=VVLseV, VVJ6wE=VVJ6wE, VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVKJ4V=VVKJ4V)
  else:
   FFoFqK(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVYnNH(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVld2V(self, isPortal, line, VVE2XdObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFlEph(self, BF(self.VV99LF, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFSmZ2(confItem, line)
   FFOPTX(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV99LF(self, title, confItem):
  FFSmZ2(confItem, "")
  FFOPTX(self, "Removed from IPTV Menu.", title=title)
 def VVZ9vm(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVXtml(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFKsz7(self, BF(self.VVb7UF, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFoFqK(self, "Incorrect server data !")
 @staticmethod
 def VV1geq(SELF, isPortal, line, VVE2XdObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCXWrP.VVUT7B()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFoFqK(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFOPTX(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFoFqK(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVDweH(self, source, mode, curBName, VVeDC2, title, txt, colList):
  isMulti = VVeDC2.VVFCH5
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVeDC2.VVau1b()
   totTxt = "%d Service%s" % (tot, FFLQjK(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFj5YA(totTxt, VVMCs3)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCqt6h(self, VVeDC2, addSep=False)
  thTxt = "Adding Services ..."
  VVGtpd, cbFncDict = [], None
  VVGtpd.append(VVttU7)
  if itemsOK:
   VVGtpd.append(("Add %s to New Bouquet : %s"    % (totTxt, FFj5YA(curBName , VVTVTj)), "addToCur1"))
   if curBName2: VVGtpd.append(("Add %s to New Bouquet : %s" % (totTxt, FFj5YA(curBName2, VVFiA5)) , "addToCur2"))
   VVGtpd.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFKsz7, mSel.VVeDC2, BF(self.VVIa0m,source, mode, curBName , VVeDC2, title), title=thTxt)
      , "addToCur2": BF(FFKsz7, mSel.VVeDC2, BF(self.VVIa0m,source, mode, curBName2, VVeDC2, title), title=thTxt)
      , "addToNew" : BF(self.VVqZmz, source, mode, curBName, VVeDC2, title)
      }
  else:
   VVGtpd.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVO5ex(VVGtpd, cbFncDict, width=1200)
 def VVIa0m(self, source, mode, curBName, VVeDC2, Title):
  chUrlLst = self.VVmTsD(source, mode, VVeDC2)
  CC3pKJ.VVIKtn(self, Title, curBName, "", chUrlLst)
 def VVqZmz(self, source, mode, curBName, VVeDC2, Title):
  picker = CC3pKJ(self, VVeDC2, Title, BF(self.VVmTsD, source, mode, VVeDC2), defBName=curBName)
 def VVmTsD(self, source, mode, VVeDC2):
  totChange = 0
  isMulti = VVeDC2.VVFCH5
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVeDC2.VVmbqa()):
   if not isMulti or VVeDC2.VVZg6r(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAeyH(mode, row)
     refCode, chUrl = self.VV5BKM(self.VVfAyW, self.VVdFeQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVUGh2(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVbXIz(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVcO9r():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVvWQW():
  return sorted(tuple(CCXWrP.VVcO9r()))
 @staticmethod
 def VVCJ6S(rt):
  return CCXWrP.VVcO9r().get(str(rt), "")
 @staticmethod
 def VV1hwS(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVmBnX():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVGtpd = []
  for ndx, rt in enumerate(CCXWrP.VVvWQW()):
   txt = "%s\t... %s" % ((VVlyaF if rt == defRt else "") + CCXWrP.VVCJ6S(rt), rt)
   if CCXWrP.VV1hwS(rt): VVGtpd.append((txt, rt))
   else       : VVGtpd.append((txt, ))
   if ndx < 4 and ndx % 2: VVGtpd.append(VVttU7)
  return VVGtpd
class CCW9od(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVU9X9(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFZM4C(self.frm, frmColor)
  FFZM4C(self.bak, bakColor)
  FFZM4C(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VV4bFG(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFkk2r(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCgjdq(CCW9od):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCW9od.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VViXuA   ,
   "down" : self.VVYUWo  ,
   "left" : self.VVefd6  ,
   "right" : self.VVJDDO  ,
   "next" : self.VVMncE ,
   "last" : self.VVI9hL
  }, -1)
 def VV0Eco(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVU9X9(x, y, w, h)
  self.VVAllZ()
 def VVQz40(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VViXuA(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVXWSX()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVxwaS()
 def VVYUWo(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVRIn2()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVxwaS()
 def VVefd6(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVXWSX()
  else:
   self.curCol -= 1
   self.VVxwaS()
 def VVJDDO(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVRIn2()
  else:
   self.curCol += 1
   self.VVxwaS()
 def VVI9hL(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVxwaS(True)
 def VVMncE(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVxwaS(True)
 def VVRIn2(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVxwaS(True)
 def VVXWSX(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVxwaS(True)
 def VVxwaS(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV4bfq = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV4bfq: self.curPage = VV4bfq
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VV5MCj()
  self.VV4bFG(self.curPage + 1, self.totalPages)
  FFkWtI(BF(self.VVFtol, force or not oldPage == self.curPage, VV4bfq))
 def VVFtol(self, force, VV4bfq):
  try:
   if force:
     self.VVdOKN()
   if self.curPage == VV4bfq:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VV5MCj()
   boxT, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxW * self.curCol), int(boxT + boxH * self.curRow)))
   self["myPiconPtr"].show()
  except:
   return
 def VVVU8C(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVxwaS(False if oldPage == self.curPage else True)
  else:
   FFgjbJ(self, "Not found", 1000)
 def VV0b77(self):
  self.VVVU8C(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVo7KX(self):
  self["myPiconPtr"].hide()
 def VVD7dx(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVmi0E(self):
  fg = bg = self.colorCfg.getValue()
  self.session.openWithCallback(self.VV7aKF, CCPDAn, defFG=fg, defBG=bg, onlyBG=True)
 def VV7aKF(self, fg, bg):
  if bg:
   FFSmZ2(self.colorCfg, bg)
   self.VVAllZ()
 def VVAllZ(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFZM4C(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
class CCztM1(Screen, CCgjdq):
 def __init__(self, session, VVeDC2, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFkttW(VVqhhs, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVeDC2  = VVeDC2
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVkGEY    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFOh1m(self, self.Title)
  CCgjdq.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVFuxe, subPath)
  if not pathExists(self.pPath):
   os.system(FFN2Os("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVyihG    ,
   "cancel": self.close    ,
   "menu" : self.VVsCwI ,
   "info" : self.VVlxnL  ,
   "0"  : self.VV0b77
  })
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  FFsHsH(self)
  self.VV0Eco()
  self.VVjoQh()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVsCwI(self):
  chName, subj, desc, fName, picUrl = self.VVkGEY[self.curIndex]
  VVGtpd = []
  txt1 = "Show Selected Picture"
  txt2 = "Copy Selected Picture to Export-Directory"
  txt3 = "Set Selected Picture as a Poster for a Local Media"
  if fName:
   VVGtpd.append((txt1, "VVpLNe"   ))
   VVGtpd.append((txt2, "VVEBV6"  ))
   VVGtpd.append((txt3, "VVBGWo" ))
  else:
   VVGtpd.append((txt1, ))
   VVGtpd.append((txt2, ))
   VVGtpd.append((txt3, ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Cache details"       , "VVqhLX"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change Poster/Picon Transparency Color" , "VVmi0E" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Help (Keys)"        , "help"     ))
  FFINMf(self, self.VVZnAl, title=self.Title, VVGtpd=VVGtpd)
 def VVZnAl(self, item=None):
  if item is not None:
   if   item == "VVpLNe"   : self.VVpLNe()
   elif item == "VVEBV6"   : self.VVEBV6()
   elif item == "VVBGWo"  : self.VVBGWo()
   elif item == "VVqhLX"  : FFKsz7(self, self.VVqhLX, title="Calculating ...")
   elif item == "VVmi0E": self.VVmi0E()
   elif item == "help"     : FFFaGN(self, "_help_servBr", "Server Browser (Keys)")
 def VVyihG(self):
  self.VVeDC2.VVvFsV(self.curIndex)
  self.VVeDC2.VV7P4W()
 def VVlxnL(self):
  self.VVeDC2.VVvFsV(self.curIndex)
  self.VVeDC2.VVgd40()
 def VVjoQh(self):
  for colList in self.VVeDC2.VVmbqa():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVkGEY.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVkGEY)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVeDC2.VVUy0w()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVxwaS(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViMje)
  except:
   self.timer.callback.append(self.VViMje)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVspsF)
  self.myThread.start()
 def VVspsF(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVkGEY):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFg3JL(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFN2Os("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVkGEY[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VViMje(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVfzKO + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVkGEY[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVkGEY[ndx] = (chName, subj, desc, fName, "")
     try:
      CCYzkG.VVgSGP(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVdOKN(self):
  self.VVD7dx()
  f1, f2 = self.VVQz40()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVkGEY[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VViEnD + "iptv.png"
   try:
    CCYzkG.VVgSGP(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV5MCj(self):
  chName, subj, desc, fName, picUrl = self.VVkGEY[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVpLNe(self):
  chName, subj, desc, fName, picUrl = self.VVkGEY[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CC9YFX.VVqn2L(self, self.pPath + fName)
  else          : FFgjbJ(self, "File not found", 1500)
 def VVEBV6(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVkGEY[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFN2Os("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FFOPTX(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFoFqK(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFoFqK(self, "No Poster/PIcon found", title=title)
 def VVBGWo(self):
  self.session.openWithCallback(self.VV0e8d, BF(CC1TwY, patternMode="movies", VViJ7i=CFG.MovieDownloadPath.getValue()))
 def VV0e8d(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVkGEY[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    res = os.system(FFN2Os("cp -f '%s' '%s'" % (srcF, dstF)))
    if res == 0 : FFOPTX(self, "File copied to:\n\n%s" % dstF, title=title)
    else  : FFoFqK(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCYzkG.VV7KJI(dstF)
   else:
    FFoFqK(self, "No Poster/PIcon found", title=title)
 def VVqhLX(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVFuxe, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFfoZ6("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CC1TwY.VVBRyA(size)
   txt += "%s\n    %s\n\n" % (FFj5YA(path, VVMCs3), size)
  mainPath = "%sPosters" % VVFuxe
  totFiles = FFfoZ6("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFLQjK(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFj5YA("Total space used by Posters/PIcons%s:" % totFTxt, VVNUk6), CC1TwY.VVBRyA(totSize))
  mountPath = CC1TwY.VV2aHq(mainPath)
  if pathExists(mountPath):
   totSize  = CC1TwY.VVF4gB(mountPath)
   freeSize = CC1TwY.VV66fB(mountPath)
   usedSize = CC1TwY.VVBRyA(totSize - freeSize)
   totSize  = CC1TwY.VVBRyA(totSize)
   freeSize = CC1TwY.VVBRyA(freeSize)
   txt += "%s\n" % VVa91R
   txt += FFj5YA("Media Space:\n", VVAjMy)
   txt += "    Media Path\t: %s\n" % FFj5YA(mountPath, VVM7JM)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFcTZL(self, txt, title="Cache Used Size", height=1000)
class CCYzkG(Screen, CCgjdq):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFkttW(VVxwD0, 1870, 1030, 50, 10, 10, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVkGEY    = lst
  FFOh1m(self, self.Title)
  CCgjdq.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVyihG    ,
   "cancel": self.close    ,
   "menu" : self.VVX0J8 ,
   "info" : self.VViUox  ,
   "0"  : self.VV0b77
  })
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  FFsHsH(self)
  self.VV0Eco()
  self.totalItems = len(self.VVkGEY)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVxwaS(True)
 def VVdOKN(self):
  self.VVD7dx()
  f1, f2 = self.VVQz40()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVkGEY[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VViEnD + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(os.path.splitext(os.path.basename(path))[0])
   lbl.show()
   pic.show()
   try:
    self.VVgSGP(pic, poster)
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVXz2V(self):
  path, movie, poster = self.VVkGEY[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VV5MCj(self):
  path, poster = self.VVXz2V()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVX0J8(self):
  path, poster = self.VVXz2V()
  VVGtpd = []
  VVGtpd.append(("Go to movie ...", "VVegjM"))
  VVGtpd.append(VVttU7)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVGtpd.append((txt1, "VVpLNe" ))
   VVGtpd.append((txt2, "VVEBV6"))
  else:
   VVGtpd.append((txt1, ))
   VVGtpd.append((txt2, ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change Poster/Picon Transparency Color"  , "VVmi0E" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change Poster (from current movie path) ..." , "VVT3Ux1"  ))
  VVGtpd.append(("Change Poster (locate manually) ..."   , "VVT3Ux2"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Help (Keys)"         , "help"     ))
  FFINMf(self, self.VV1h4m, title=self.Title, VVGtpd=VVGtpd)
 def VV1h4m(self, item=None):
  if item is not None:
   if   item == "VVegjM"    : self.VVegjM()
   elif item == "VVEBV6"    : self.VVEBV6()
   elif item == "VVpLNe"    : self.VVpLNe()
   elif item == "VVmi0E" : self.VVmi0E()
   elif item == "VVT3Ux1"  : self.VVT3Ux()
   elif item == "VVT3Ux2"  : self.VVT3Ux(True)
   elif item == "help"      : FFFaGN(self, "_help_movBr", "Movies Browser (Keys)")
 def VVegjM(self):
  VVzpbP = []
  for ndx, item in enumerate(self.VVkGEY):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVzpbP.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVzpbP.sort(key=lambda x: x[0].lower())
  VVLseV = ("Select" , self.VVc5wg, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FF4zYj(self, None, title="Select Movie", width=1800, height=1000, header=header, VVkGEY=VVzpbP, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, lastFindConfigObj=CFG.lastFindMovie)
 def VVc5wg(self, VVeDC2, title, txt, colList):
  self.VVVU8C(int(colList[2].strip()))
  VVeDC2.cancel()
 def VVyihG(self):
  path, poster = self.VVXz2V()
  FFKsz7(self, BF(CC1TwY.VV9CaF, self, path), title="Playing Media ...")
 def VViUox(self):
  path, poster = self.VVXz2V()
  txt = "%s:\n%s\n\n" % (FFj5YA("Path", VVMCs3), path)
  size = FFkas1(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFj5YA("File Size", VVMCs3), CC1TwY.VVBRyA(size))
  if poster:
   txt += "%s:\n%s" % (FFj5YA("Poster", VVMCs3), poster)
  FFcTZL(self, txt, title="Media File Information")
 def VVpLNe(self):
  path, poster = self.VVXz2V()
  if fileExists(poster): CC9YFX.VVqn2L(self, poster)
  else     : FFgjbJ(self, "No Poster", 1500)
 def VVEBV6(self):
  title = "Copy Poster"
  path, poster = self.VVXz2V()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FFN2Os("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FFOPTX(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFoFqK(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFgjbJ(self, "No Poster", 1500)
 def VVT3Ux(self, isManual=False):
  path, poster = self.VVXz2V()
  sDir = FFoR3R(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVOIAc, sDir, path), BF(CC1TwY, patternMode="poster", VViJ7i=sDir))
  else:
   VVGtpd = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVGtpd.append((os.path.basename(item), sDir + item))
   if VVGtpd:
    VVGtpd.sort(key=lambda x: x[0].lower())
    infoBtnFnc = self.VVNhg5
    FFINMf(self, BF(self.VVOIAc, sDir, path), VVGtpd=VVGtpd, title="Posters", infoBtnFnc=infoBtnFnc, yellowBasePath=sDir)
   else:
    FFgjbJ(self, "No jpg/png in current dir", 1500)
 def VVNhg5(self, menuInstance, txt, ref, ndx):
  CC9YFX.VVqn2L(self, VVVTIX=ref)
 def VVOIAc(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   res = os.system(FFN2Os("cp -f '%s' '%s'" % (pPath, newPath)))
   if res == 0 or pPath == newPath:
    self.VVkGEY[self.curIndex] = (self.VVkGEY[self.curIndex][0], self.VVkGEY[self.curIndex][1], os.path.basename(newPath))
    FFKsz7(self, self.VVdOKN)
    CCYzkG.VV7KJI(newPath)
   else:
    FFgjbJ(self, "Cannot copy file", 1000)
 @staticmethod
 def VV7KJI(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    os.system(FFN2Os("mv -f '%s' '%s'" % (jpgF, newF)))
 @staticmethod
 def VVgSGP(pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 @staticmethod
 def VVQHL6(SELF):
  eLst = CC8VbN.VVB1kx()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCYzkG, title, lst)
  else  : FFoFqK(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCxYG1(Screen, CCgjdq):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFkttW(VVEtuy, 1840, 1040, 50, 10, 10, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVkGEY    = lst
  self.pPath    = CCMEuJ.VVaKDV()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFOh1m(self, self.Title)
  FFiTXq(self["keyRed"] , "OK = Zap (Review)")
  FFiTXq(self["keyGreen"] , "Zap & Exit")
  FFiTXq(self["keyYellow"], "Find Current Service")
  CCgjdq.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VV48wq, False),
   "cancel" : self.VVc1BV      ,
   "menu"  : self.VVrmNN   ,
   "red"  : self.VVc1BV      ,
   "green"  : BF(self.VV48wq, True) ,
   "yellow" : BF(self.VVWNle, True)  ,
   "0"   : self.VV0b77
  })
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFe04V(self)
   FFsHsH(self)
   FFZM4C(self["keyRed"], "#0a333333")
   self.VV0Eco()
  else:
   pName, srvLst = CCxYG1.VVY8DG()
   if srvLst and not srvLst == self.VVkGEY:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVkGEY = srvLst
   else:
    force = False
  self.totalItems = len(self.VVkGEY)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVxwaS(force)
  self.VVWNle()
 def VVrmNN(self):
  VVGtpd = []
  VVGtpd.append(("Find Name (sorted list)"   , "findSrt"  ))
  VVGtpd.append(("Find Name (as listed)"   , "findNoSrt"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Change Background Color"   , "VVmi0E"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Help (Keys)", "help"))
  FFINMf(self, self.VVPraE, title="Options", VVGtpd=VVGtpd)
 def VVPraE(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVko9M(True)
   elif item == "findNoSrt"   : self.VVko9M(False)
   elif item == "VVmi0E": self.VVmi0E()
   elif item == "help"     : FFFaGN(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVko9M(self, isSort):
  VVGtpd = []
  for ndx, item in enumerate(self.VVkGEY):
   VVGtpd.append((item[1], ndx))
  if isSort:
   VVGtpd.sort(key=lambda x: x[0].lower())
  FFINMf(self, self.VVzffY, title="Find Name", VVGtpd=VVGtpd, width=1300)
 def VVzffY(self, ndx=None):
  if ndx is not None:
   self.VVVU8C(ndx)
 def VVc1BV(self):
  if self.shown: self.close()
  else   : self.show()
 def VV48wq(self, isExit):
  FFKsz7(self, BF(self.VVbNVk, isExit), title="Starting ...")
 def VVbNVk(self, isExit):
  try:
   if self.shown:
    FF4utl(self, self.VVkGEY[self.curIndex][0], VVoHm3=False)
    if isExit: self.close()
    else  : CCi57e.VVnjtb(self.session)
   else:
    self.show()
  except:
   pass
 def VVWNle(self, VVjHD0=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVkGEY):
    if curRef == item[0]:
     self.VVVU8C(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVjHD0 and err:
   FFgjbJ(self, err, 500)
  return -1
 def VVdOKN(self):
  self.VVD7dx()
  f1, f2 = self.VVQz40()
  row = col = 0
  noPos = VViEnD + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVkGEY[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(name)
   lbl.show()
   pic.show()
   path = CCMEuJ.VVRkjb(self.pPath, ref, name) or noPos
   try:
    CCYzkG.VVgSGP(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV5MCj(self):
  ref, name = self.VVkGEY[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVOr4U():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VV0qUH = InfoBar.instance
  if VV0qUH:
   csel = VV0qUH.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFxa2y(rootRef)
    refName  = FFxa2y(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVY8DG(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCxYG1.VVOr4U()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFsmA3(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CC3pKJ.VVDzSY()
   pName  = CC3pKJ.VVqz5e() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVZL7c(SELF):
  pName, srvLst = CCxYG1.VVY8DG()
  if srvLst: SELF.session.open(CCxYG1, pName, srvLst)
  else  : FFoFqK(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCd0Fn(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFkttW(VVUJSe, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVQnN3  = 0
  self.VVWmtF = 1
  self.VVuoPC  = 2
  VVGtpd = []
  VVGtpd.append(("Find in All Service (from filter)" , "VVAjGG" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Find in All (Manual Entry)"   , "VVJ21h"    ))
  VVGtpd.append(("Find in TV"       , "VVkA6k"    ))
  VVGtpd.append(("Find in Radio"      , "VVHfGg"   ))
  if self.VV9Hah():
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Hide Channel: %s" % self.servName , "VVRDxh"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Zap History"       , "VV5wWX"    ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("IPTV Tools"       , "iptv"      ))
  VVGtpd.append(("PIcons Tools"       , "PIconsTools"     ))
  VVGtpd.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVGtpd.append(("EPG Tools"       , "epgTools"     ))
  FFOh1m(self, VVGtpd=VVGtpd, title=title)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self)
  if self.isFindMode:
   self.VVwWjc(self.VVPYMd())
 def VVyihG(self):
  global VV9phB
  VV9phB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVJ21h"    : self.VVJ21h()
   elif item == "VVAjGG" : self.VVAjGG()
   elif item == "VVkA6k"    : self.VVkA6k()
   elif item == "VVHfGg"   : self.VVHfGg()
   elif item == "VVRDxh"   : self.VVRDxh()
   elif item == "VV5wWX"    : self.VV5wWX()
   elif item == "iptv"       : self.session.open(CCXWrP)
   elif item == "PIconsTools"     : self.session.open(CCMEuJ)
   elif item == "ChannelsTools"    : self.session.open(CC5MnI)
   elif item == "epgTools"      : self.session.open(CC8SZQ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVkA6k(self) : self.VVwWjc(self.VVQnN3)
 def VVHfGg(self) : self.VVwWjc(self.VVWmtF)
 def VVJ21h(self) : self.VVwWjc(self.VVuoPC)
 def VVwWjc(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF8cVc(self, BF(self.VV38gl, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVAjGG(self):
  filterObj = CCZt3D(self)
  filterObj.VVTzbi(self.VVeHYy)
 def VVeHYy(self, item):
  self.VV38gl(self.VVuoPC, item)
 def VV9Hah(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFBTpz(self.refCode)        : return False
  return True
 def VV38gl(self, mode, VVASgy):
  FFKsz7(self, BF(self.VV3UTp, mode, VVASgy), title="Searching ...")
 def VV3UTp(self, mode, VVASgy):
  if VVASgy:
   VVASgy = VVASgy.strip()
  if VVASgy:
   self.findTxt = VVASgy
   CFG.lastFindContextFind.setValue(VVASgy)
   if   mode == self.VVQnN3  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVWmtF : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVASgy)
   if len(title) > 55:
    title = title[:55] + ".."
   VVzpbP = self.VVtbVl(VVASgy, servTypes)
   if self.isFindMode or mode == self.VVuoPC:
    VVzpbP += self.VVLYWI(VVASgy)
   if VVzpbP:
    VVzpbP.sort(key=lambda x: x[0].lower())
    VVsgQj = self.VVhIi2
    VVLseV  = ("Zap"   , self.VVaWkb    , [])
    VVtaAK = ("Current Service", self.VVbwvR , [])
    VV0q2u = ("Options"  , self.VVQjvK , [])
    VVXlcT = (""    , self.VVOgXj , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVZq8i  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVsgQj=VVsgQj, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVXlcT=VVXlcT, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVwWjc(self.VVPYMd())
    FFOPTX(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVtbVl(self, VVASgy, servTypes):
  VVkGEY = CC5MnI.VVDqxo(servTypes)
  VVzpbP = []
  if VVkGEY:
   VVGKcu, VVfTgd = FFsyUd()
   tp = CCNm5S()
   words, asPrefix = CCZt3D.VVvY0h(VVASgy)
   colorYellow  = CCec5j.VVgasN(VVNUk6)
   colorWhite  = CCec5j.VVgasN(VVDIbD)
   for s in VVkGEY:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFFJgS(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVGKcu:
        STYPE = VVfTgd[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVcq92(refCode)
       if not "-S" in syst:
        sat = syst
       VVzpbP.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVzpbP
 def VVLYWI(self, VVASgy):
  VVASgy = VVASgy.lower()
  VVzpbP = []
  colorYellow  = CCec5j.VVgasN(VVNUk6)
  colorWhite  = CCec5j.VVgasN(VVDIbD)
  for b in CC3pKJ.VVs9Lp():
   VVezVx  = b[0]
   VVsW7x  = b[1].toString()
   VVNl2A = eServiceReference(VVsW7x)
   VVmwsq = FFsmA3(VVNl2A)
   for service in VVmwsq:
    refCode  = service[0]
    if FFBTpz(refCode):
     servName = service[1]
     if VVASgy in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVASgy), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVzpbP.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVzpbP
 def VVPYMd(self):
  VV0qUH = InfoBar.instance
  if VV0qUH:
   VViA5x = VV0qUH.servicelist
   if VViA5x:
    return VViA5x.mode == 1
  return self.VVuoPC
 def VVhIi2(self, VVeDC2):
  self.close()
  VVeDC2.cancel()
 def VVaWkb(self, VVeDC2, title, txt, colList):
  FF4utl(VVeDC2, colList[2], VVoHm3=False, checkParentalControl=True)
 def VVbwvR(self, VVeDC2, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(VVeDC2)
  if refCode:
   VVeDC2.VV6eK5(2, FFbK3k(refCode, iptvRef, chName), True)
 def VVQjvK(self, VVeDC2, title, txt, colList):
  servName = colList[0]
  mSel = CCqt6h(self, VVeDC2)
  VVGtpd, cbFncDict = CC5MnI.VVmgn7(self, VVeDC2, servName, 2)
  mSel.VVO5ex(VVGtpd, cbFncDict)
 def VVOgXj(self, VVeDC2, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFeMt4(self, fncMode=CC40v5.VVxHFg, refCode=refCode, chName=chName, text=txt)
 def VVRDxh(self):
  FFlEph(self, self.VVcfbj, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVcfbj(self):
  ret = FFd0nh(self.refCode, True)
  if ret:
   self.VVPYAP()
   self.close()
  else:
   FFgjbJ(self, "Cannot change state" , 1000)
 def VVPYAP(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV9RHy()
  except:
   self.VVrlUl()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFp8VH(self, serviceRef)
 def VV9RHy(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV0qUH = InfoBar.instance
   if VV0qUH:
    VViA5x = VV0qUH.servicelist
    if VViA5x:
     hList = VViA5x.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VViA5x.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VViA5x.history  = newList
       VViA5x.history_pos = pos
 def VVrlUl(self):
  VV0qUH = InfoBar.instance
  if VV0qUH:
   VViA5x = VV0qUH.servicelist
   if VViA5x:
    VViA5x.history  = []
    VViA5x.history_pos = 0
 def VV5wWX(self):
  VV0qUH = InfoBar.instance
  VVzpbP = []
  if VV0qUH:
   VViA5x = VV0qUH.servicelist
   if VViA5x:
    VVGKcu, VVfTgd = FFsyUd()
    for serv in VViA5x.history:
     refCode = serv[-1].toString()
     chName = FFxa2y(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFBTpz(refCode)
     isSRel = FFXaBx(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFFJgS(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVGKcu:
       STYPE = VVfTgd[sTypeInt]
     VVzpbP.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVzpbP:
   VVLseV  = ("Zap"   , self.VVCT9b   , [])
   VV0q2u = ("Clear History" , self.VVUimD   , [])
   VVXlcT = (""    , self.VVJn66 , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVZq8i  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVLseV=VVLseV, VV0q2u=VV0q2u, VVXlcT=VVXlcT)
  else:
   FFOPTX(self, "History is empty.", title=title)
 def VVCT9b(self, VVeDC2, title, txt, colList):
  FF4utl(VVeDC2, colList[3], VVoHm3=False, checkParentalControl=True)
 def VVUimD(self, VVeDC2, title, txt, colList):
  FFlEph(self, BF(self.VVRLkH, VVeDC2), "Clear Zap History ?")
 def VVRLkH(self, VVeDC2):
  self.VVrlUl()
  VVeDC2.cancel()
 def VVJn66(self, VVeDC2, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFeMt4(self, fncMode=CC40v5.VVQ6yY, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVZwWh():
  try:
   global VVqayx
   if VVqayx is None:
    VVqayx    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCd0Fn.VV19gS
   ChannelContextMenu.VVadf2 = CCd0Fn.VVadf2
  except:
   pass
 @staticmethod
 def VV19gS(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVqayx(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VVadf2, t[i], csel, mode=i))))
 @staticmethod
 def VVadf2(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFxa2y(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CCxYG1.VVZL7c(self)
  else  : self.session.open(BF(CCd0Fn, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CCMEuJ(Screen, CCgjdq):
 VVnz0n   = 0
 VVl7ge  = 1
 VVh7gA  = 2
 VVoGrq  = 3
 VVXuVR  = 4
 VV1qwo  = 5
 VVl5kR  = 6
 VVoVEe  = 7
 VVZ2PU = 8
 VVkliD = 9
 VVFZyR = 10
 VVo6IO = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VVIrDR, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCMEuJ.VVaKDV()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVkGEY    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFOh1m(self, self.Title)
  FFiTXq(self["keyRed"] , "OK = Zap")
  FFiTXq(self["keyGreen"] , "Current Service")
  FFiTXq(self["keyYellow"], "Page Options")
  FFiTXq(self["keyBlue"] , "Filter")
  CCgjdq.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVVgtg     ,
   "green"  : self.VVmB66    ,
   "yellow" : self.VV2EKT     ,
   "blue"  : self.VVu2PC     ,
   "menu"  : self.VVAorH     ,
   "info"  : self.VVBD08    ,
   "pageUp" : BF(self.VVbYSI, True) ,
   "chanUp" : BF(self.VVbYSI, True) ,
   "pageDown" : BF(self.VVbYSI, False) ,
   "chanDown" : BF(self.VVbYSI, False) ,
   "0"   : self.VV0b77  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  FFsHsH(self)
  FFZM4C(self["keyRed"], "#0a333333")
  self.VV0Eco()
  self.VVo7KX()
  FFKsz7(self, BF(self.VVc7ww, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVAorH(self):
  if not self.isBusy:
   VVGtpd = []
   VVGtpd.append(("Statistics"           , "VVuEnK"    ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Suggest PIcons for Current Channel"     , "VV2TKD"   ))
   VVGtpd.append(("Set to Current Channel (copy file)"     , "VVQ4EE_file"  ))
   VVGtpd.append(("Set to Current Channel (as SymLink)"     , "VVQ4EE_link"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Export Current File Names List"      , "VVh8I4" ))
   VVGtpd.append(CCMEuJ.VV4Nbq())
   VVGtpd.append(VVttU7)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVNNKJ
    VVGtpd.append((c + movTxt           , "VVIZ6l"  ))
    VVGtpd.append((c + delTxt           , "VVOjBE" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVGtpd.append((movTxt + disTxt         ,       ))
    VVGtpd.append((delTxt + disTxt         ,       ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVMFPU"  ))
   VVGtpd.append(VVttU7)
   VVGtpd += CCMEuJ.VV7s59()
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Change Poster/Picon Transparency Color"    , "VVmi0E" ))
   VVGtpd.append(("Keys Help"           , "VVx38A"    ))
   FFINMf(self, self.VVC3et, width=1100, height=1050, title=self.Title, VVGtpd=VVGtpd)
 def VVC3et(self, item=None):
  if item is not None:
   if   item == "VVuEnK"    : self.VVuEnK()
   elif item == "VV2TKD"   : self.VV2TKD()
   elif item == "VVQ4EE_file"  : self.VVQ4EE(0)
   elif item == "VVQ4EE_link"  : self.VVQ4EE(1)
   elif item == "VVh8I4"  : self.VVh8I4()
   elif item == "VV4bWN"  : CCMEuJ.VV4bWN(self)
   elif item == "VVIZ6l"   : self.VVIZ6l()
   elif item == "VVOjBE"  : self.VVOjBE()
   elif item == "VVMFPU"  : self.VVMFPU()
   elif item == "VVQKS2"  : CCMEuJ.VVQKS2(self)
   elif item == "findPiconBrokenSymLinks" : CCMEuJ.VVeuB5(self, True)
   elif item == "FindAllBrokenSymLinks" : CCMEuJ.VVeuB5(self, False)
   elif item == "VVmi0E" : self.VVmi0E()
   elif item == "VVx38A"     : FFFaGN(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VV2EKT(self):
  if not self.isBusy:
   VVGtpd = []
   VVGtpd.append(("Go to First PIcon"  , "VVRIn2"  ))
   VVGtpd.append(("Go to Last PIcon"   , "VVXWSX"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Sort by Channel Name"     , "sortByChan" ))
   VVGtpd.append(("Sort by File Name"  , "sortByFile" ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Find from File List .." , "VVpbBD" ))
   FFINMf(self, self.VVImpI, title=self.Title, VVGtpd=VVGtpd)
 def VVImpI(self, item=None):
  if item is not None:
   if   item == "VVRIn2"   : self.VVRIn2()
   elif item == "VVXWSX"   : self.VVXWSX()
   elif item == "sortByChan"  : self.VVU1IH(2)
   elif item == "sortByFile"  : self.VVU1IH(0)
   elif item == "VVpbBD"  : self.VVpbBD()
 def VVpbBD(self):
  VVGtpd = []
  for item in self.VVkGEY:
   VVGtpd.append((item[0], item[0]))
  FFINMf(self, self.VVr7Zf, title='PIcons ".png" Files', VVGtpd=VVGtpd, VVOvZt=True)
 def VVr7Zf(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVVU8C(ndx)
 def VVVgtg(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVItSv()
   if refCode:
    FF4utl(self, refCode)
    self.VVOZCJ()
    self.VV5MCj()
 def VVbYSI(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVOZCJ()
   self.VV5MCj()
  except:
   pass
 def VVmB66(self):
  if self["keyGreen"].getVisible():
   self.VVVU8C(self.curChanIndex)
 def VVU1IH(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFKsz7(self, BF(self.VVc7ww, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVQ4EE(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVItSv()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVGtpd = []
     VVGtpd.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVGtpd.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFINMf(self, BF(self.VV7FBH, mode, curChF, selPiconF), VVGtpd=VVGtpd, title="Current Channel PIcon (already exists)")
    else:
     self.VV7FBH(mode, curChF, selPiconF, "overwrite")
   else:
    FFoFqK(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFoFqK(self, "Could not read current channel info. !", title=title)
 def VV7FBH(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFKsz7(self, BF(self.VVc7ww, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVIZ6l(self):
  defDir = FFoR3R(CCMEuJ.VVaKDV() + "picons_backup")
  os.system(FFN2Os("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVbJFv, defDir), BF(CC1TwY
         , mode=CC1TwY.VVtIla, VViJ7i=CCMEuJ.VVaKDV()))
 def VVbJFv(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCMEuJ.VVaKDV():
    FFoFqK(self, "Cannot move to same directory !", title=title)
   else:
    if not FFoR3R(path) == FFoR3R(defDir):
     self.VVssCN(defDir)
    FFlEph(self, BF(FFKsz7, self, BF(self.VVBdkP, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVkGEY), path), title=title)
  else:
   self.VVssCN(defDir)
 def VVBdkP(self, title, defDir, toPath):
  if not iMove:
   self.VVssCN(defDir)
   FFoFqK(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFoR3R(toPath)
  pPath = CCMEuJ.VVaKDV()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVkGEY:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVkGEY)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFcTZL(self, txt, title=title, VValS2="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVkIjZ("all")
 def VVssCN(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVOjBE(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVkGEY)
  FFlEph(self, BF(FFKsz7, self, BF(self.VVBohn, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFLQjK(tot)), title=title)
 def VVBohn(self, title):
  pPath = CCMEuJ.VVaKDV()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVkGEY:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVkGEY)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFj5YA(str(totErr), VVXz72)
  FFcTZL(self, txt, title=title)
 def VVMFPU(self):
  lines = FFCpSv("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFlEph(self, BF(self.VVAp69, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFLQjK(tot)), VV4A3A=True)
  else:
   FFOPTX(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVAp69(self, fList):
  os.system(FFN2Os("find -L '%s' -type l -delete" % self.pPath))
  FFOPTX(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVBD08(self):
  FFKsz7(self, self.VVOZit)
 def VVOZit(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVItSv()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFj5YA("PIcon Directory:\n", VVFiA5)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF5L7o(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF5L7o(path)
   txt += FFj5YA("PIcon File:\n", VVFiA5)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFj5YA("Found %d SymLink%s to this file from:\n" % (tot, FFLQjK(tot)), VVFiA5)
     for fPath in slLst:
      txt += "  %s\n" % FFj5YA(fPath, VVOEUE)
     txt += "\n"
   if chName:
    txt += FFj5YA("Channel:\n", VVFiA5)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFj5YA(chName, VVTVTj)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFj5YA("Remarks:\n", VVFiA5)
    txt += "  %s\n" % FFj5YA("Unused", VVXz72)
  else:
   txt = "No info found"
  FFeMt4(self, fncMode=CC40v5.VVED5C, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVItSv(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVkGEY[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF8CMQ(sat)
  return fName, refCode, chName, sat, inDB
 def VVOZCJ(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVkGEY):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV5MCj(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVItSv()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFj5YA("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVFiA5))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVItSv()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFXaBx(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFj5YA(self.curChanName, VVNUk6)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVItSv()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVuEnK(self):
  VVGKcu, VVfTgd = FFsyUd()
  sTypeNameDict = {}
  for key, val in VVfTgd.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVkGEY:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVfTgd: sTypeDict[VVfTgd[stNum]] = sTypeDict.get(VVfTgd[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFfoZ6("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVzpbP = []
  c = "#b#11003333#"
  VVzpbP.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVzpbP.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVzpbP.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVzpbP.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVzpbP.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVzpbP.append((c + "Satellites"    , str(len(self.nsList))))
  VVzpbP.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVzpbP.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVzpbP.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVzpbP.extend(sTypeRows)
  FF4zYj(self, None, title=self.Title, VVkGEY=VVzpbP, VVdez8=28, VVKJ4V="#00003333", VVEwGL="#00222222")
 def VVh8I4(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFoR3R(CFG.exportedTablesPath.getValue()), txt, FFbNWS())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVkGEY:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFOPTX(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVu2PC(self):
  if not self.isBusy:
   VVGtpd = []
   VVGtpd.append(("All"        , "all"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Used by Channels"     , "used" ))
   VVGtpd.append(("Unused PIcons"     , "unused" ))
   VVGtpd.append(("IPTV PIcons"      , "iptv" ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("PIcons Files"      , "pFiles" ))
   VVGtpd.append(("SymLinks to PIcons"    , "pLinks" ))
   VVGtpd.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVGtpd.append(("By Files Date ..."    , "pDate" ))
   VVGtpd.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVGtpd.append(FFPPw2("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFEBso(val)
      VVGtpd.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCZt3D(self)
   filterObj.VVmYdR(VVGtpd, self.nsList, self.VV1Gvr)
 def VV1Gvr(self, item=None):
  if item is not None:
   self.VVkIjZ(item)
 def VVkIjZ(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVnz0n   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVl7ge   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVh7gA  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVl5kR   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVoGrq  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVXuVR  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV1qwo  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVFZyR , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVo6IO , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVoVEe   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVZ2PU , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV1qwo:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFCpSv("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFYgWN(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFgjbJ(self, "Not found", 1000)
     return
   elif mode == self.VVFZyR:
    self.VVjmFw(mode)
    return
   elif mode == self.VVo6IO:
    self.VVBSsF(mode)
    return
   elif mode == self.VVkliD:
    return
   else:
    words, asPrefix = CCZt3D.VVvY0h(words)
   if not words and mode in (self.VVoVEe, self.VVZ2PU):
    FFgjbJ(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFKsz7(self, BF(self.VVc7ww, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVjmFw(self, mode):
  VVGtpd = []
  VVGtpd.append(("Today"   , "today" ))
  VVGtpd.append(("Since Yesterday" , "yest" ))
  VVGtpd.append(("Since 7 days"  , "week" ))
  FFINMf(self, BF(self.VVmkxW, mode), VVGtpd=VVGtpd, title="Filter by Added/Modified Date")
 def VVmkxW(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFcZUZ(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFcZUZ(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFcZUZ(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFKsz7(self, BF(self.VVc7ww, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVBSsF(self, mode):
  VVGKcu, VVfTgd = FFsyUd()
  lst = set()
  for key, val in VVfTgd.items():
   lst.add(val)
  VVGtpd = []
  for item in lst:
   VVGtpd.append((item, item))
  VVGtpd.sort(key=lambda x: x[0])
  FFINMf(self, BF(self.VVwk2B, mode), VVGtpd=VVGtpd, title="Filter by Service Type")
 def VVwk2B(self, mode, item=None):
  if item:
   VVGKcu, VVfTgd = FFsyUd()
   sTypeList = []
   for key, val in VVfTgd.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFKsz7(self, BF(self.VVc7ww, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VV2TKD(self):
  self.session.open(CCEwtS, barTheme=CCEwtS.VVZxQb
      , titlePrefix = ""
      , fncToRun  = self.VVqa4D
      , VV00AH = self.VVCAFF)
 def VVqa4D(self, VVfBS1):
  VV19bT, err = CC5MnI.VV4kit(self, CC5MnI.VVvv2B, VVa1kB=False, VVjxU1=False)
  files = []
  words = []
  if not VVfBS1 or VVfBS1.isCancelled:
   return
  VVfBS1.VVcdNf = []
  VVfBS1.VV9WKz(len(VV19bT))
  if VV19bT:
   VVICJb = CCzdJA()
   curCh = VVICJb.VV2pbV(self.curChanName)
   for refCode in VV19bT:
    if not VVfBS1 or VVfBS1.isCancelled:
     return
    VVfBS1.VVSxQe(1, True)
    chName, sat, inDB = VV19bT.get(refCode, ("", "", 0))
    ratio = CCMEuJ.VVbcV8(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCMEuJ.VVj1l9(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFYgWN(f)
       fil = f.replace(".png", "")
       if not fil in VVfBS1.VVcdNf:
        VVfBS1.VVcdNf.append(fil)
 def VVCAFF(self, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  if VVcdNf : FFKsz7(self, BF(self.VVc7ww, mode=self.VVkliD, words=VVcdNf), title="Loading ...")
  else   : FFgjbJ(self, "Not found", 2000)
 def VVc7ww(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VV2yyl(isFirstTime):
   return
  self.isBusy = True
  VVjxU1 = True if isFirstTime else False
  VV19bT, err = CC5MnI.VV4kit(self, CC5MnI.VVvv2B, VVa1kB=False, VVjxU1=VVjxU1)
  if err:
   self.close()
  iptvRefList = self.VVqPi7()
  tList = []
  for fName, fType in CCMEuJ.VV7Acb(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VV19bT:
    if fName in VV19bT:
     chName, sat, inDB = VV19bT.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVnz0n:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVl7ge  and chName         : isAdd = True
   elif mode == self.VVh7gA and not chName        : isAdd = True
   elif mode == self.VVoGrq  and fType == 0        : isAdd = True
   elif mode == self.VVXuVR  and fType == 1        : isAdd = True
   elif mode == self.VV1qwo  and fName in words       : isAdd = True
   elif mode == self.VVkliD and fName in words       : isAdd = True
   elif mode == self.VVl5kR  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVoVEe  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVZ2PU:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVFZyR:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVo6IO:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVkGEY   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFgjbJ(self)
  else:
   self.isBusy = False
   FFgjbJ(self, "Not found", 1000)
   return
  self.VVkGEY.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVOZCJ()
  self.totalItems = len(self.VVkGEY)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVxwaS(True)
 def VV2yyl(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCMEuJ.VV7Acb(self.pPath):
    if fName:
     return True
   if isFirstTime : FFoFqK(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFgjbJ(self, "Not found", 1000)
  else:
   FFoFqK(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVqPi7(self):
  VVzpbP = {}
  files  = CCXWrP.VV26sg()
  if files:
   for path in files:
    txt = FFEJE4(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVzpbP[refCode] = item[1]
  return VVzpbP
 def VVdOKN(self):
  self.VVD7dx()
  f1, f2 = self.VVQz40()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVkGEY[ndx]
   fName = self.VVkGEY[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFj5YA(chName, VVTVTj))
    else : lbl.setText("-")
   except:
    lbl.setText(FFj5YA(chName, VVJsQK))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVbcV8(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV4Nbq():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VV4bWN")
 @staticmethod
 def VV7s59():
  VVGtpd = []
  VVGtpd.append(("Find SymLinks (to PIcon Directory)"   , "VVQKS2"  ))
  VVGtpd.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVGtpd.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVGtpd
 @staticmethod
 def VV4bWN(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF)
  png, path = CCMEuJ.VVtrJq(refCode)
  if path : CCMEuJ.VVNRSI(SELF, png, path)
  else : FFoFqK(SELF, "No PIcon found for current channel in:\n\n%s" % CCMEuJ.VVaKDV())
 @staticmethod
 def VVQKS2(SELF):
  if VVNUk6:
   sed1 = FFYHN3("->", VVNUk6)
   sed2 = FFYHN3("picon", VVXz72)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVJsQK, VVDIbD)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFpXhB(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFxM0r(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVeuB5(SELF, isPIcon):
  sed1 = FFYHN3("->", VVJsQK)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFYHN3("picon", VVXz72)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFpXhB(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFxM0r(), grep, sed1, sed2))
 @staticmethod
 def VVNRSI(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFYHN3("%s%s" % (dest, png), VVTVTj))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFYHN3(errTxt, VVfzKO))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFm2b8(SELF, cmd)
 @staticmethod
 def VV7Acb(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVaKDV():
  path = CFG.PIconsPath.getValue()
  return FFoR3R(path)
 @staticmethod
 def VVtrJq(refCode, chName=None):
  if FFBTpz(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFfLGx(refCode)
  allPath, fName, refCodeFile, pList = CCMEuJ.VVj1l9(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVRkjb(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCXWrP.VVvWQW():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFg0L0(chName)
   for ext in exts:
    path = "%s%s.%s" % (pPath, chName, ext)
    if fileExists(path):
     return path
  return ""
 @staticmethod
 def VVj1l9(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCMEuJ.VVaKDV()
   pList = []
   lst = FFKQDF(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFg0L0(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFYgWN(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC5jcX():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVLHhg  = None
  self.VVpau9 = ""
  self.VVV3ba  = noService
  self.VV6m2K = 0
  self.VVR8KU  = noService
  self.VVZD4g = 0
  self.VV3z6M  = "-"
  self.VVe2U9 = 0
  self.VVvlGn  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVwnjJ(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVLHhg = frontEndStatus
     self.VV48xg()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV48xg(self):
  if self.VVLHhg:
   val = self.VVLHhg.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVpau9 = "%3.02f dB" % (val / 100.0)
   else         : self.VVpau9 = ""
   val = self.VVLHhg.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV6m2K = int(val)
   self.VVV3ba  = "%d%%" % val
   val = self.VVLHhg.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVZD4g = int(val)
   self.VVR8KU  = "%d%%" % val
   val = self.VVLHhg.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV3z6M  = "%d" % val
   val = int(val * 100 / 500)
   self.VVe2U9 = min(500, val)
   val = self.VVLHhg.get("tuner_locked", 0)
   if val == 1 : self.VVvlGn = "Locked"
   else  : self.VVvlGn = "Not locked"
 def VV96sm(self)   : return self.VVpau9
 def VVPeBl(self)   : return self.VVV3ba
 def VVsg0t(self)  : return self.VV6m2K
 def VV4Ijl(self)   : return self.VVR8KU
 def VV8v64(self)  : return self.VVZD4g
 def VV6QgJ(self)   : return self.VV3z6M
 def VVaMEf(self)  : return self.VVe2U9
 def VVul2I(self)   : return self.VVvlGn
 def VVJA4I(self) : return self.serviceName
class CCNm5S():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVoWZI(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFL7ha(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV4YIn(self.ORPOS  , mod=1   )
      self.sat2  = self.VV4YIn(self.ORPOS  , mod=2   )
      self.freq  = self.VV4YIn(self.FREQ  , mod=3   )
      self.sr   = self.VV4YIn(self.SR   , mod=4   )
      self.inv  = self.VV4YIn(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV4YIn(self.POL  , self.D_POL )
      self.fec  = self.VV4YIn(self.FEC  , self.D_FEC )
      self.syst  = self.VV4YIn(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV4YIn("modulation" , self.D_MOD )
       self.rolof = self.VV4YIn("rolloff"  , self.D_ROLOF )
       self.pil = self.VV4YIn("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV4YIn("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV4YIn("pls_code"  )
       self.iStId = self.VV4YIn("is_id"   )
       self.t2PlId = self.VV4YIn("t2mi_plp_id" )
       self.t2PId = self.VV4YIn("t2mi_pid"  )
 def VV4YIn(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFEBso(val)
  elif mod == 2   : return FFvbLy(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VV9LUN(self, refCode):
  txt = ""
  self.VVoWZI(refCode)
  if self.data:
   def VVy3eN(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVy3eN("System"   , self.syst)
    txt += VVy3eN("Satellite"  , self.sat2)
    txt += VVy3eN("Frequency"  , self.freq)
    txt += VVy3eN("Inversion"  , self.inv)
    txt += VVy3eN("Symbol Rate"  , self.sr)
    txt += VVy3eN("Polarization" , self.pol)
    txt += VVy3eN("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVy3eN("Modulation" , self.mod)
     txt += VVy3eN("Roll-Off" , self.rolof)
     txt += VVy3eN("Pilot"  , self.pil)
     txt += VVy3eN("Input Stream", self.iStId)
     txt += VVy3eN("T2MI PLP ID" , self.t2PlId)
     txt += VVy3eN("T2MI PID" , self.t2PId)
     txt += VVy3eN("PLS Mode" , self.plsMod)
     txt += VVy3eN("PLS Code" , self.plsCod)
   else:
    txt += VVy3eN("System"   , self.txMedia)
    txt += VVy3eN("Frequency"  , self.freq)
  return txt, self.namespace
 def VVWwHI(self, refCode):
  txt = "Transpoder : ?"
  self.VVoWZI(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVcq92(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFL7ha(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV4YIn(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV4YIn(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV4YIn(self.SYST, self.D_SYS_S)
     freq = self.VV4YIn(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV4YIn(self.POL , self.D_POL)
      fec = self.VV4YIn(self.FEC , self.D_FEC)
      sr = self.VV4YIn(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVVwsM(self, refCode):
  self.data = None
  self.VVoWZI(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCkPUj():
 def __init__(self, VVTXkg, path, VV00AH=None, curRowNum=-1):
  self.VVTXkg  = VVTXkg
  self.origFile   = path
  self.Title    = "File Editor: " + FFYgWN(path)
  self.VV00AH  = VV00AH
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFN2Os("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVZw1D(curRowNum)
  else:
   FFoFqK(self.VVTXkg, "Error while preparing edit!")
 def VVZw1D(self, curRowNum):
  VVzpbP = self.VVQVST()
  VVtaAK = ("Save Changes" , self.VVYls9   , [])
  VVLseV  = ("Edit Line"  , self.VVPeTS    , [])
  VV0q2u = ("Go to Line Num" , self.VVj3yq   , [])
  VVyNdP = ("Line Options" , self.VVzK87   , [])
  VVHUGA = (""    , self.VV2dMy , [])
  VVsgQj = self.VVKIH9
  VVDXub  = self.VVpjCb
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVZq8i  = (CENTER  , LEFT  )
  VVeDC2 = FF4zYj(self.VVTXkg, None, title=self.Title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVtaAK=VVtaAK, VVLseV=VVLseV, VV0q2u=VV0q2u, VVyNdP=VVyNdP, VVsgQj=VVsgQj, VVDXub=VVDXub, VVHUGA=VVHUGA, VV0i4h=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVghW2   = "#11001111"
    , VVlnMM   = "#11001111"
    , VValS2   = "#11001111"
    , VVKJ4V  = "#05333333"
    , VVEwGL  = "#00222222"
    , VVtDKG  = "#11331133"
    )
  VVeDC2.VVvFsV(curRowNum)
 def VVj3yq(self, VVeDC2, title, txt, colList):
  totRows = VVeDC2.VVz6J6()
  lineNum = VVeDC2.VVUy0w() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FF8cVc(self.VVTXkg, BF(self.VV7TPP, VVeDC2, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VV7TPP(self, VVeDC2, lineNum, totRows, VVOd8Z):
  if VVOd8Z:
   VVOd8Z = VVOd8Z.strip()
   if VVOd8Z.isdigit():
    num = FF5nM6(int(VVOd8Z) - 1, 0, totRows)
    VVeDC2.VVvFsV(num)
    self.lastLineNum = num + 1
   else:
    FFgjbJ(VVeDC2, "Incorrect number", 1500)
 def VVzK87(self, VVeDC2, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVeDC2.VVpRlV()
  VVGtpd = []
  VVGtpd.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVGtpd.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVfX8d"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVSVeV:
   VVGtpd.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(  ("Delete Line"         , "deleteLine"   ))
  FFINMf(self.VVTXkg, BF(self.VVTOfv, VVeDC2, lineNum), VVGtpd=VVGtpd, title="Line Options")
 def VVTOfv(self, VVeDC2, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVkvRL("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVeDC2)
   elif item == "VVfX8d"  : self.VVfX8d(VVeDC2, lineNum)
   elif item == "copyToClipboard"  : self.VVgImR(VVeDC2, lineNum)
   elif item == "pasteFromClipboard" : self.VVMyvO(VVeDC2, lineNum)
   elif item == "deleteLine"   : self.VVkvRL("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVeDC2)
 def VVpjCb(self, VVeDC2):
  VVeDC2.VV8fXV()
 def VV2dMy(self, VVeDC2, title, txt, colList):
  if   self.insertMode == 1: VVeDC2.VVAH6a()
  elif self.insertMode == 2: VVeDC2.VVnICW()
  self.insertMode = 0
 def VVfX8d(self, VVeDC2, lineNum):
  if lineNum == VVeDC2.VVpRlV():
   self.insertMode = 1
   self.VVkvRL("echo '' >> '%s'" % self.tmpFile, VVeDC2)
  else:
   self.insertMode = 2
   self.VVkvRL("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVeDC2)
 def VVgImR(self, VVeDC2, lineNum):
  global VVSVeV
  VVSVeV = FFfoZ6("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVeDC2.VVdL9K("Copied to clipboard")
 def VVYls9(self, VVeDC2, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFN2Os("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFN2Os("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVeDC2.VVdL9K("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVeDC2.VV8fXV()
    else:
     FFoFqK(self.VVTXkg, "Cannot save file!")
   else:
    FFoFqK(self.VVTXkg, "Cannot create backup copy of original file!")
 def VVKIH9(self, VVeDC2):
  if self.fileChanged:
   FFlEph(self.VVTXkg, BF(self.VV5Yc8, VVeDC2), "Cancel changes ?")
  else:
   finalOK = os.system(FFN2Os("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VV5Yc8(VVeDC2)
 def VV5Yc8(self, VVeDC2):
  VVeDC2.cancel()
  FF9qnP(self.tmpFile)
  if self.VV00AH:
   self.VV00AH(self.fileSaved)
 def VVPeTS(self, VVeDC2, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVDIbD + "ORIGINAL TEXT:\n" + VVOEUE + lineTxt
  FF8cVc(self.VVTXkg, BF(self.VVmEXr, lineNum, VVeDC2), title="File Line", defaultText=lineTxt, message=message)
 def VVmEXr(self, lineNum, VVeDC2, VVOd8Z):
  if not VVOd8Z is None:
   if VVeDC2.VVpRlV() <= 1:
    self.VVkvRL("echo %s > '%s'" % (VVOd8Z, self.tmpFile), VVeDC2)
   else:
    self.VVoPaz(VVeDC2, lineNum, VVOd8Z)
 def VVMyvO(self, VVeDC2, lineNum):
  if lineNum == VVeDC2.VVpRlV() and VVeDC2.VVpRlV() == 1:
   self.VVkvRL("echo %s >> '%s'" % (VVSVeV, self.tmpFile), VVeDC2)
  else:
   self.VVoPaz(VVeDC2, lineNum, VVSVeV)
 def VVoPaz(self, VVeDC2, lineNum, newTxt):
  VVeDC2.VVaLck("Saving ...")
  lines = FF8eQ2(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVeDC2.VV5b0T()
  VVzpbP = self.VVQVST()
  VVeDC2.VV6IAT(VVzpbP)
 def VVkvRL(self, cmd, VVeDC2):
  tCons = CCzBO0()
  tCons.ePopen(cmd, BF(self.VVUaQB, VVeDC2))
  self.fileChanged = True
  VVeDC2.VV5b0T()
 def VVUaQB(self, VVeDC2, result, retval):
  VVzpbP = self.VVQVST()
  VVeDC2.VV6IAT(VVzpbP)
 def VVQVST(self):
  if fileExists(self.tmpFile):
   lines = FF8eQ2(self.tmpFile)
   VVzpbP = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVzpbP.append((str(ndx), line.strip()))
   if not VVzpbP:
    VVzpbP.append((str(1), ""))
   return VVzpbP
  else:
   FFE0MG(self.VVTXkg, self.tmpFile)
class CCZt3D():
 def __init__(self, callingSELF, VVghW2="#22003344", VVlnMM="#22002233"):
  self.callingSELF = callingSELF
  self.VVGtpd  = []
  self.satList  = []
  self.VVghW2  = VVghW2
  self.VVlnMM   = VVlnMM
 def VVTzbi(self, VV00AH):
  self.VVGtpd = []
  VVGtpd, VVzBKK = CCZt3D.VVqaPy(self.callingSELF, False, True)
  if VVGtpd:
   self.VVGtpd += VVGtpd
   self.VVR3tz(VV00AH, VVzBKK)
 def VVGJJx(self, mode, VVeDC2, satCol, VV00AH, inFilterFnc=None):
  VVeDC2.VVaLck("Loading Filters ...")
  self.VVGtpd = []
  self.VVGtpd.append(("All Services" , "all"))
  if mode == 1:
   self.VVGtpd.append(VVttU7)
   self.VVGtpd.append(("Parental Control", "parentalControl"))
   self.VVGtpd.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVGtpd.append(VVttU7)
   self.VVGtpd.append(("Selected Transponder"   , "selectedTP" ))
   self.VVGtpd.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVHOer(VVeDC2, satCol)
  VVGtpd, VVzBKK = CCZt3D.VVqaPy(self.callingSELF, True, False)
  if VVGtpd:
   VVGtpd.insert(0, FFPPw2("Custom Words"))
   self.VVGtpd += VVGtpd
  VVeDC2.VVtAan()
  self.VVR3tz(VV00AH, VVzBKK, inFilterFnc)
 def VVmYdR(self, VVGtpd, sats, VV00AH, inFilterFnc=None):
  self.VVGtpd = VVGtpd
  VVGtpd, VVzBKK = CCZt3D.VVqaPy(self.callingSELF, True, False)
  if VVGtpd:
   self.VVGtpd.append(FFPPw2("Custom Words"))
   self.VVGtpd += VVGtpd
  self.VVR3tz(VV00AH, VVzBKK, inFilterFnc)
 def VVR3tz(self, VV00AH, VVzBKK, inFilterFnc=None):
  VVVLOF  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VV3Pkd = ("Edit Filter"  , BF(self.VVgdN9, VVzBKK))
  VVDhcZ  = ("Filter Help"  , BF(self.VVdWA2, VVzBKK))
  FFINMf(self.callingSELF, BF(self.VVQqAv, VV00AH), VVGtpd=self.VVGtpd, title="Select Filter", VVVLOF=VVVLOF, VV3Pkd=VV3Pkd, VVDhcZ=VVDhcZ, VVsFdc=True, VVghW2=self.VVghW2, VVlnMM=self.VVlnMM)
 def VVQqAv(self, VV00AH, item):
  if item:
   VV00AH(item)
 def VVgdN9(self, VVzBKK, VVE2XdObj, sel):
  if fileExists(VVzBKK) : CCkPUj(self.callingSELF, VVzBKK, VV00AH=None)
  else       : FFE0MG(self.callingSELF, VVzBKK)
  VVE2XdObj.cancel()
 def VVdWA2(self, VVzBKK, VVE2XdObj, sel):
  FFFaGN(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVHOer(self, VVeDC2, satColNum):
  if not self.satList:
   satList = VVeDC2.VV8E66(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF8CMQ(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFPPw2("Satellites"))
  if self.VVGtpd:
   self.VVGtpd += self.satList
 @staticmethod
 def VVqaPy(SELF, addTag, VVjHD0):
  FFmC2q()
  fileName  = "ajpanel_services_filter"
  VVzBKK = VVFuxe + fileName
  VVGtpd  = []
  if not fileExists(VVzBKK):
   os.system(FFN2Os("cp -f '%s' '%s'" % (VViEnD + fileName, VVzBKK)))
  fileFound = False
  if fileExists(VVzBKK):
   fileFound = True
   lines = FF8eQ2(VVzBKK)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVGtpd.append((line, "__w__" + line))
       else  : VVGtpd.append((line, line))
  if VVjHD0:
   if   not fileFound : FFE0MG(SELF, VVzBKK)
   elif not VVGtpd : FFPPOX(SELF, VVzBKK)
  return VVGtpd, VVzBKK
 @staticmethod
 def VVvY0h(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCqt6h():
 def __init__(self, callingSELF, VVeDC2, addSep=True):
  self.callingSELF = callingSELF
  self.VVeDC2 = VVeDC2
  self.VVGtpd = []
  iMulSel = self.VVeDC2.VVrpFI()
  if iMulSel : self.VVGtpd.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVGtpd.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVeDC2.VVau1b()
  self.VVGtpd.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVGtpd.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVGtpd.append(VVttU7)
 def VVO5ex(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVGtpd.extend(extraMenu)
  FFINMf(self.callingSELF, BF(self.VVFLNU, cbFncDict, okFnc), width=width, title="Options", VVGtpd=self.VVGtpd)
 def VVFLNU(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVeDC2.VVMWca(True)
   elif item == "MultSelDisab" : self.VVeDC2.VVMWca(False)
   elif item == "selectAll" : self.VVeDC2.VVQoZi()
   elif item == "unselectAll" : self.VVeDC2.VVFrvE()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCj0a1(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVeIPH, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFOh1m(self)
  FFiTXq(self["keyRed"]  , "Exit")
  FFiTXq(self["keyGreen"]  , "Save")
  FFiTXq(self["keyYellow"] , "Refresh")
  FFiTXq(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVW3c8  ,
   "green" : self.VVeLGq ,
   "yellow": self.VVaTSr  ,
   "blue" : self.VVzup6   ,
   "up" : self.VViXuA    ,
   "down" : self.VVYUWo   ,
   "left" : self.VVefd6   ,
   "right" : self.VVJDDO   ,
   "cancel": self.VVW3c8
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self.VVaTSr()
  self.VVdTSX()
  FFsHsH(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVjaco)
  except:
   self.timer.callback.append(self.VVjaco)
  self.timer.start(1000, False)
  self.VVjaco()
 def onExit(self):
  self.timer.stop()
 def VVW3c8(self) : self.close(True)
 def VVPLd2(self) : self.close(False)
 def VVzup6(self):
  self.session.openWithCallback(self.VVBevK, BF(CCAGrg))
 def VVBevK(self, closeAll):
  if closeAll:
   self.close()
 def VVjaco(self):
  self["curTime"].setText(str(FF5ivG(iTime())))
 def VViXuA(self):
  self.VVHlu6(1)
 def VVYUWo(self):
  self.VVHlu6(-1)
 def VVefd6(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVdTSX()
 def VVJDDO(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVdTSX()
 def VVHlu6(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVABvz(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVABvz(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVABvz(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVm1ka(year)):
   days += 1
  return days
 def VVm1ka(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVdTSX(self):
  for obj in self.list:
   FFZM4C(obj, "#11404040")
  FFZM4C(self.list[self.index], "#11ff8000")
 def VVaTSr(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVeLGq(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCzBO0()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVuOzr)
 def VVuOzr(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFOPTX(self, "Nothing returned from the system!")
  else:
   FFOPTX(self, str(result))
class CCAGrg(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VVys1c, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFOh1m(self, addLabel=True)
  FFiTXq(self["keyRed"]  , "Exit")
  FFiTXq(self["keyGreen"]  , "Sync")
  FFiTXq(self["keyYellow"] , "Refresh")
  FFiTXq(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVW3c8   ,
   "green" : self.VVwdJM  ,
   "yellow": self.VVFWzA ,
   "blue" : self.VVezc7  ,
   "cancel": self.VVW3c8
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVAnCi()
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  FFsHsH(self)
  FFkWtI(self.VV4bMz)
 def VV4bMz(self):
  self.VVISJB()
  self.VV52Vq(False)
 def VVW3c8(self)  : self.close(True)
 def VVezc7(self) : self.close(False)
 def VVAnCi(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVISJB(self):
  self.VVyLrl()
  self.VVLDnS()
  self.VVI3nl()
  self.VVuB79()
 def VVFWzA(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVAnCi()
   self.VVISJB()
   FFkWtI(self.VV4bMz)
 def VVwdJM(self):
  if len(self["keyGreen"].getText()) > 0:
   FFlEph(self, self.VVclit, "Synchronize with Internet Date/Time ?")
 def VVclit(self):
  self.VVISJB()
  FFkWtI(BF(self.VV52Vq, True))
 def VVyLrl(self)  : self["keyRed"].show()
 def VVaSD8(self)  : self["keyGreen"].show()
 def VV6nle(self) : self["keyYellow"].show()
 def VVU3fm(self)  : self["keyBlue"].show()
 def VVLDnS(self)  : self["keyGreen"].hide()
 def VVI3nl(self) : self["keyYellow"].hide()
 def VVuB79(self)  : self["keyBlue"].hide()
 def VV52Vq(self, sync):
  localTime = FFtkvI()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVGUxl(server)
   if epoch_time is not None:
    ntpTime = FF5ivG(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCzBO0()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVuOzr, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV6nle()
  self.VVU3fm()
  if ok:
   self.VVaSD8()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVuOzr(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV52Vq(False)
  except:
   pass
 def VVGUxl(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCcrQv.VVTBsl():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCSG3J(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFkttW(VV0AqT, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFOh1m(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFkWtI(self.VVbUUC)
 def VVbUUC(self):
  if CCcrQv.VVTBsl() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFZM4C(self["myBody"], color)
   FFZM4C(self["myLabel"], color)
  except:
   pass
class CCXLzE(Screen):
 VVt6rP = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFIyPo()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFkttW(VVCdJQ, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC2QHE(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC2QHE(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC2QHE(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC5jcX()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFOh1m(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VViXuA       ,
   "down"  : self.VVYUWo      ,
   "left"  : self.VVefd6      ,
   "right"  : self.VVJDDO      ,
   "info"  : self.VV4aEJ     ,
   "epg"  : self.VV4aEJ     ,
   "menu"  : self.VVx38A      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VV4zb7, -1)  ,
   "next"  : BF(self.VV4zb7, 1)  ,
   "pageUp" : BF(self.VV4y8Q, True) ,
   "chanUp" : BF(self.VV4y8Q, True) ,
   "pageDown" : BF(self.VV4y8Q, False) ,
   "chanDown" : BF(self.VV4y8Q, False) ,
   "0"   : BF(self.VV4zb7, 0)  ,
   "1"   : BF(self.VVost7, pos=1) ,
   "2"   : BF(self.VVost7, pos=2) ,
   "3"   : BF(self.VVost7, pos=3) ,
   "4"   : BF(self.VVost7, pos=4) ,
   "5"   : BF(self.VVost7, pos=5) ,
   "6"   : BF(self.VVost7, pos=6) ,
   "7"   : BF(self.VVost7, pos=7) ,
   "8"   : BF(self.VVost7, pos=8) ,
   "9"   : BF(self.VVost7, pos=9) ,
  }, -1)
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  if not CCXLzE.VVt6rP:
   CCXLzE.VVt6rP = self
  self.sliderSNR.VVhywz()
  self.sliderAGC.VVhywz()
  self.sliderBER.VVhywz(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVost7()
  self.VVzZWI()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTG3K)
  except:
   self.timer.callback.append(self.VVTG3K)
  self.timer.start(500, False)
 def VVzZWI(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVwnjJ(service)
  serviceName = self.tunerInfo.VVJA4I()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  tp = CCNm5S()
  tpTxt, satTxt = tp.VVWwHI(refCode)
  if tpTxt == "?" :
   tpTxt = FFj5YA("NO SIGNAL", VVNNKJ)
  self["myTPInfo"].setText(tpTxt + "  " + FFj5YA(satTxt, VVMCs3))
 def VVTG3K(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVwnjJ(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV96sm())
   self["mySNR"].setText(self.tunerInfo.VVPeBl())
   self["myAGC"].setText(self.tunerInfo.VV4Ijl())
   self["myBER"].setText(self.tunerInfo.VV6QgJ())
   self.sliderSNR.VVFIvv(self.tunerInfo.VVsg0t())
   self.sliderAGC.VVFIvv(self.tunerInfo.VV8v64())
   self.sliderBER.VVFIvv(self.tunerInfo.VVaMEf())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVFIvv(0)
   self.sliderAGC.VVFIvv(0)
   self.sliderBER.VVFIvv(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
    if state and not state == "Tuned":
     FFgjbJ(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VV4aEJ(self):
  FFeMt4(self, fncMode=CC40v5.VVCnGh)
 def VVx38A(self):
  FFFaGN(self, "_help_signal", "Signal Monitor (Keys)")
 def VViXuA(self)  : self.VVost7(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVYUWo(self) : self.VVost7(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVefd6(self) : self.VVost7(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVJDDO(self) : self.VVost7(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVost7(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFSmZ2(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV4zb7(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF5nM6(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFSmZ2(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCXLzE.VVt6rP = None
 def VV4y8Q(self, isUp):
  FFgjbJ(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVzZWI()
  except:
   pass
class CC2QHE(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVhywz(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFZM4C(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VViEnD +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFZM4C(self.covObj, self.covColor)
   else:
    FFZM4C(self.covObj, "#00006688")
    self.isColormode = True
  self.VVFIvv(0)
 def VVFIvv(self, val):
  val  = FF5nM6(val, self.minN, self.maxN)
  width = int(FFkk2r(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF5nM6(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCEwtS(Screen):
 VVZxQb    = 0
 VVyaE2 = 1
 VVeC3U = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VV00AH=None, barTheme=VVZxQb, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVD2Jb(barTheme)
  self.skin, self.skinParam = FFkttW(VV781Z, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VV00AH = VV00AH
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVcdNf = None
  self.timer   = eTimer()
  self.myThread  = None
  FFOh1m(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self.VVS4Xt()
  self["myProgBarVal"].setText("0%")
  FFZM4C(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVXyHv()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVXyHv)
  except:
   self.timer.callback.append(self.VVXyHv)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VV9WKz(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVisIo(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVcdNf), self.counter, self.maxValue, catName)
 def VVJhZJ(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVWtM0(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV5wHW(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVPAO7(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVRc8P(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVRq7B(self, txt):
  self.newTitle = txt
 def VVSxQe(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVcdNf), self.counter, self.maxValue)
  except:
   pass
 def VVDShu(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVxzzx(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVIfKo(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFgjbJ(self, "Cancelling ...")
  self.isCancelled = True
  self.VVtfJs(False)
 def VVtfJs(self, isDone):
  FFkWtI(BF(self.VVHfHc, isDone))
 def VVHfHc(self, isDone):
  if self.VV00AH:
   self.VV00AH(isDone, self.VVcdNf, self.counter, self.maxValue, self.isError)
  self.close()
 def VVXyHv(self):
  val = FF5nM6(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFkk2r(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVtfJs(True)
 def VVS4Xt(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVyaE2, self.VVeC3U):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVD2Jb(self, barTheme):
  if   barTheme == self.VVyaE2 : return 0.7
  if   barTheme == self.VVeC3U : return 0.5
  else             : return 1
class CCzBO0(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VV00AH = {}
  self.commandRunning = False
  self.VVtGSd  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VV00AH, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VV00AH[name] = VV00AH
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVtGSd:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVEWOz, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVxkhC , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVEWOz, name))
    self.appContainers[name].appClosed.append(BF(self.VVxkhC , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVxkhC(name, retval)
  return True
 def VVEWOz(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFj5YA("[UN-DECODED STRING]", VVNNKJ))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVxkhC(self, name, retval):
  if not self.VVtGSd:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VV00AH[name]:
   self.VV00AH[name](self.appResults[name], retval)
  del self.VV00AH[name]
 def VVu6JL(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCIK0j(Screen):
 def __init__(self, session, title="", VVxUb7=None, VVfUaM=False, VVZesh=False, VVOh6Q=False, VVKmA3=False, VVJRz4=False, VVYK5P=False, VV4T9O=VVIrLf, VVRBrK=None, VVgjOx=False, VVJIBF=None, VVFxJT="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFkttW(VVgBg4, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFOh1m(self, addScrollLabel=True)
  if not VVFxJT:
   VVFxJT = "Processing ..."
  self["myLabel"].setText("   %s" % VVFxJT)
  self.VVfUaM   = VVfUaM
  self.VVZesh   = VVZesh
  self.VVOh6Q   = VVOh6Q
  self.VVKmA3  = VVKmA3
  self.VVJRz4 = VVJRz4
  self.VVYK5P = VVYK5P
  self.VV4T9O   = VV4T9O
  self.VVRBrK = VVRBrK
  self.VVgjOx  = VVgjOx
  self.VVJIBF  = VVJIBF
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCzBO0()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFKNF8()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVxUb7, str):
   self.VVxUb7 = [VVxUb7]
  else:
   self.VVxUb7 = VVxUb7
  if self.VVOh6Q or self.VVKmA3:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVa91R, VVa91R)
   self.VVxUb7.append("echo -e '\n%s\n' %s" % (restartNote, FFYHN3(restartNote, VVNUk6)))
   if self.VVOh6Q:
    self.VVxUb7.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVxUb7.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVJRz4:
   FFgjbJ(self, "Processing ...")
  self.onLayoutFinish.append(self.VV3gpX)
  self.onClose.append(self.VV3pQd)
 def VV3gpX(self):
  self["myLabel"].VVP4jT(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVfUaM:
   self["myLabel"].VVPcFJ()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVbI9N()
  else:
   self.VV10CE()
 def VVbI9N(self):
  if CCcrQv.VVTBsl():
   self["myLabel"].setText("Processing ...")
   self.VV10CE()
  else:
   self["myLabel"].setText(FFj5YA("\n   No connection to internet!", VVXz72))
 def VV10CE(self):
  allOK = self.container.ePopen(self.VVxUb7[0], self.VVQzlz, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVQzlz("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVYK5P or self.VVOh6Q or self.VVKmA3:
    self["myLabel"].setText(FFY7Lk("STARTED", VVNUk6) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVJIBF:
   colorWhite = CCec5j.VVgasN(VVDIbD)
   color  = CCec5j.VVgasN(self.VVJIBF[0])
   words  = self.VVJIBF[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV4T9O=self.VV4T9O)
 def VVQzlz(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVxUb7):
   allOK = self.container.ePopen(self.VVxUb7[self.cmdNum], self.VVQzlz, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVQzlz("Cannot connect to Console!", -1)
  else:
   if self.VVJRz4 and FFmmGR(self):
    FFgjbJ(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVYK5P:
    self["myLabel"].appendText("\n" + FFY7Lk("FINISHED", VVNUk6), self.VV4T9O)
   if self.VVfUaM or self.VVZesh:
    self["myLabel"].VVPcFJ()
   if self.VVRBrK is not None:
    self.VVRBrK()
   if not retval and self.VVgjOx:
    self.VV3pQd()
 def VV3pQd(self):
  if self.container.VVu6JL():
   self.container.killAll()
class CCi2xg(Screen):
 def __init__(self, session, VVxUb7=None, VVJRz4=False):
  self.skin, self.skinParam = FFkttW(VVgBg4, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVFuxe + "ajpanel_terminal.history"
  self.customCommandsFile = VVFuxe + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFfoZ6("pwd") or "/home/root"
  self.container   = CCzBO0()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFOh1m(self, title="Terminal", addScrollLabel=True)
  FFiTXq(self["keyRed"] , self.exitBtnText)
  FFiTXq(self["keyGreen"] , "OK = History")
  FFiTXq(self["keyYellow"], "Menu = Custom Cmds")
  FFiTXq(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVM3eW ,
   "cancel": self.VVJd9U  ,
   "menu" : self.VVSKTJ ,
   "last" : self.VVRKcg  ,
   "next" : self.VVRKcg  ,
   "1"  : self.VVRKcg  ,
   "2"  : self.VVRKcg  ,
   "3"  : self.VVRKcg  ,
   "4"  : self.VVRKcg  ,
   "5"  : self.VVRKcg  ,
   "6"  : self.VVRKcg  ,
   "7"  : self.VVRKcg  ,
   "8"  : self.VVRKcg  ,
   "9"  : self.VVRKcg  ,
   "0"  : self.VVRKcg
  })
  self.onLayoutFinish.append(self.VVP1sX)
  self.onClose.append(self.VVrlbT)
 def VVP1sX(self):
  self["myLabel"].VVP4jT(isResizable=False, outputFileToSave="terminal")
  FFmnMn(self["keyRed"]  , "#00ff8000")
  FFZM4C(self["keyRed"]  , self.skinParam["titleColor"])
  FFZM4C(self["keyGreen"]  , self.skinParam["titleColor"])
  FFZM4C(self["keyYellow"] , self.skinParam["titleColor"])
  FFZM4C(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVuc6n(FFfoZ6("date"), 5)
  result = FFfoZ6("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVEnhK()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VViEnD + "LinuxCommands.lst"
   newTemplate = VViEnD + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFN2Os("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFN2Os("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVrlbT(self):
  if self.container.VVu6JL():
   self.container.killAll()
   self.VVuc6n("Process killed\n", 4)
   self.VVEnhK()
 def VVJd9U(self):
  if self.container.VVu6JL():
   self.VVrlbT()
  else:
   FFlEph(self, self.close, "Exit ?", VVOr97=False)
 def VVEnhK(self):
  self.VVuc6n(self.prompt, 1)
  self["keyRed"].hide()
 def VVuc6n(self, txt, mode):
  if   mode == 1 : color = VVNUk6
  elif mode == 2 : color = VVFiA5
  elif mode == 3 : color = VVDIbD
  elif mode == 4 : color = VVXz72
  elif mode == 5 : color = VVOEUE
  elif mode == 6 : color = VVky8q
  else   : color = VVDIbD
  try:
   self["myLabel"].appendText(FFj5YA(txt, color))
  except:
   pass
 def VVM3eW(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVnA7G() == "":
   self.VVtZmD("cd /tmp")
   self.VVtZmD("ls")
  VVzpbP = []
  if fileExists(self.commandHistoryFile):
   lines  = FF8eQ2(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVzpbP.append((str(c), line, str(lNum)))
   self.VVu4Hv(VVzpbP, title, self.commandHistoryFile, isHistory=True)
  else:
   FFE0MG(self, self.commandHistoryFile, title=title)
 def VVnA7G(self):
  lastLine = FFfoZ6("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVtZmD(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVSKTJ(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF8eQ2(self.customCommandsFile)
   lastLineIsSep = False
   VVzpbP = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVzpbP.append((str(c), line, str(lNum)))
   self.VVu4Hv(VVzpbP, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFE0MG(self, self.customCommandsFile, title=title)
 def VVu4Hv(self, VVzpbP, title, filePath=None, isHistory=False):
  if VVzpbP:
   VVKJ4V = "#05333333"
   if isHistory: VVghW2 = VVlnMM = VValS2 = "#11000020"
   else  : VVghW2 = VVlnMM = VValS2 = "#06002020"
   VVLseV   = ("Send"   , BF(self.VVO0dr, isHistory)  , [])
   VVtaAK  = ("Modify & Send" , self.VVkjqa     , [])
   if isHistory:
    VV0q2u = ("Clear History" , self.VVQk7V     , [])
    VVyNdP = None
   elif filePath:
    VV0q2u = ("Options"  , self.VVYXrL      , [])
    VVyNdP = ("Edit File"  , BF(self.VVtQH3, filePath) , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVZq8i = (CENTER , LEFT   , CENTER )
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP, lastFindConfigObj=CFG.lastFindTerminal, VV0i4h=True, searchCol=1
         , VVghW2=VVghW2, VVlnMM=VVlnMM, VValS2=VValS2, VVRaJ8="#05ffff00", VVKJ4V=VVKJ4V)
   if not isHistory:
    VVeDC2.VVvFsV(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFPPOX(self, filePath, title=title)
 def VVYXrL(self, VVeDC2, title, txt, colList):
  mSel = CCqt6h(self, VVeDC2)
  if VVeDC2.VVFCH5:
   totSel = VVeDC2.VVau1b()
   totTxt = str(totSel)
   txt = "Send %s Command%s" % (FFj5YA(totTxt, VVNUk6) if totSel else totTxt, FFLQjK(totSel))
   VVGtpd = [(txt, "send")] if totSel else [(txt,)]
  else:
   VVGtpd = [("Send current line", "send")]
  cbFncDict = {"send": BF(self.VVO0dr, False, VVeDC2, title, txt, colList)}
  mSel.VVO5ex(VVGtpd, cbFncDict, okFnc=BF(self.VVnCYb, VVeDC2))
 def VVnCYb(self, VVeDC2):
  if VVeDC2.VVFCH5 : VVeDC2.VV8fXV()
  else        : VVeDC2.VV5b0T()
 def VVO0dr(self, isHistory, VVeDC2, title, txt, colList):
  if VVeDC2.VVFCH5:
   lst = VVeDC2.VV2oru(1)
   curNdx = VVeDC2.VVLzYo()
  else:
   lst = [colList[1]]
   curNdx = VVeDC2.VVUy0w()
  if not isHistory:
   FFSmZ2(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVeDC2.cancel()
  FFkWtI(self.VVYxei)
 def VVYxei(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVuc6n("\n%s\n" % cmd, 6)
    self.VVuc6n(self.prompt, 1)
    self.VVYxei()
   else:
    self.VV594K(cmd)
 def VV594K(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVuc6n(cmd, 2)
   self.VVuc6n("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVuc6n(ch, 0)
   self.VVuc6n("\nor\n", 4)
   self.VVuc6n("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVEnhK()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFj5YA(parts[0].strip(), VVFiA5)
    right = FFj5YA("#" + parts[1].strip(), VVky8q)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVuc6n(txt, 2)
   lastLine = self.VVnA7G()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVtZmD(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVQzlz, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFoFqK(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVuc6n(data, 3)
 def VVQzlz(self, data, retval):
  if not retval == 0:
   self.VVuc6n("Exit Code : %d\n" % retval, 4)
  self.VVEnhK()
  if self.commandsList:
   self.VVYxei()
 def VVkjqa(self, VVeDC2, title, txt, colList):
  if VVeDC2.VVrScD():
   cmd = colList[1]
   self.VVi7Uw(VVeDC2, cmd)
 def VVQk7V(self, VVeDC2, title, txt, colList):
  FFlEph(self, BF(self.VVFO3V, VVeDC2), "Reset History File ?", title="Command History")
 def VVFO3V(self, VVeDC2):
  os.system(FFN2Os("echo '' > %s" % self.commandHistoryFile))
  VVeDC2.cancel()
 def VVtQH3(self, filePath, VVeDC2, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCkPUj(self, filePath, VV00AH=BF(self.VV7VOy, VVeDC2), curRowNum=rowNum)
  else     : FFE0MG(self, filePath)
 def VV7VOy(self, VVeDC2, fileChanged):
  if fileChanged:
   VVeDC2.cancel()
   FFkWtI(self.VVSKTJ)
 def VVRKcg(self):
  self.VVi7Uw(None, self.lastCommand)
 def VVi7Uw(self, VVeDC2, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF8cVc(self, BF(self.VVgzuX, VVeDC2), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVgzuX(self, VVeDC2, cmd):
  if cmd and len(cmd) > 0:
   self.VV594K(cmd)
   if VVeDC2:
    VVeDC2.cancel()
class CCyGKj(Screen):
 def __init__(self, session, title="", message="", VV4T9O=VVIrLf, width=1400, height=900, VVxOd9=False, VValS2=None, VVdez8=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFkttW(VVgBg4, width, height, titleFontSize, 30, 20, "#22002020", "#22001122", VVdez8)
  self.session   = session
  FFOh1m(self, title, addScrollLabel=True)
  self.VV4T9O   = VV4T9O
  self.VVxOd9   = VVxOd9
  self.VValS2   = VValS2
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self["myLabel"].VVP4jT(VVxOd9=self.VVxOd9, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VV4T9O)
  if self.VValS2:
   FFZM4C(self["myBody"], self.VValS2)
   FFZM4C(self["myLabel"], self.VValS2)
   FFFyBB(self["myLabel"], self.VValS2)
  self["myLabel"].VVPcFJ()
class CCfZkX(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFkttW(VVVQL7, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFOh1m(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFTvKK(self["errPic"], "err")
class CChNMz(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFkttW(VVlUWx, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFOh1m(self, " ", addCloser=True)
class CC5zgq():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.win = session.instantiateDialog(CChNMz, txt, fonSize)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFFFBF(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVuOoE)
  except:
   self.timer.callback.append(self.VVuOoE)
  self.timer.start(timeout, True)
 def VVuOoE(self):
  self.session.deleteDialog(self.win)
class CCxguE():
 VVjytG    = 0
 VV7ryb  = 1
 VVXYXl   = ""
 VVDBBp    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVeDC2   = None
  self.timer     = eTimer()
  self.VV8fJC   = 0
  self.VVjZti  = 1
  self.VVMhXC  = 2
  self.VVRvFL   = 3
  self.VVGFwN   = 4
  VVzpbP = self.VVgqEE()
  if VVzpbP:
   self.VVeDC2 = self.VVrBxZ(VVzpbP)
  if not VVzpbP and mode == self.VVjytG:
   self.VVy1Mf("Download list is empty !")
   self.cancel()
  if mode == self.VV7ryb:
   FFKsz7(self.VVeDC2 or self.SELF, BF(self.VVpQ9N, startDnld, decodedUrl), title="Checking Server ...")
  self.VV8mpM(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV8mpM)
  except:
   self.timer.callback.append(self.VV8mpM)
  self.timer.start(1000, False)
 def VVrBxZ(self, VVzpbP):
  VVzpbP.sort(key=lambda x: int(x[0]))
  VVsgQj = self.VVLBn8
  VVLseV  = ("Play"  , self.VVyekq , [])
  VVXlcT = (""   , self.VVpi6e  , [])
  VVJ6wE = ("Stop"  , self.VVHJIu  , [])
  VVtaAK = ("Resume"  , self.VVRLoa , [])
  VV0q2u = ("Options" , self.VVAorH  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVZq8i  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FF4zYj(self.SELF, None, title=self.Title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVLseV=VVLseV, VVXlcT=VVXlcT, VVsgQj=VVsgQj, VVJ6wE=VVJ6wE, VVtaAK=VVtaAK, VV0q2u=VV0q2u, lastFindConfigObj=CFG.lastFindIptv, VVghW2="#11220022", VVlnMM="#11110011", VValS2="#11110011", VVRaJ8="#00ffff00", VVKJ4V="#00223025", VVEwGL="#0a333333", VVtDKG="#0a400040", VV0i4h=True, searchCol=1)
 def VVgqEE(self):
  lines = CCxguE.VVrDNH()
  VVzpbP = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VV7RUN(decodedUrl)
      if fName:
       if   FFCX2Z(decodedUrl) : sType = "Movie"
       elif FF8kdM(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVwIfo(decodedUrl, fName)
       if size > -1: sizeTxt = CC1TwY.VVBRyA(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVzpbP.append((str(len(VVzpbP) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVzpbP
 def VVxCq4(self):
  VVzpbP = self.VVgqEE()
  if VVzpbP:
   if self.VVeDC2 : self.VVeDC2.VV6IAT(VVzpbP, VVAnCiMsg=False)
   else     : self.VVeDC2 = self.VVrBxZ(VVzpbP)
  else:
   self.cancel()
 def VV8mpM(self, force=False):
  if self.VVeDC2:
   thrListUrls = self.VVRwLZ()
   VVzpbP = []
   changed = False
   for ndx, row in enumerate(self.VVeDC2.VVmbqa()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV8fJC
    if m3u8Log:
     percent = CCxguE.VVk0FT(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVRvFL , "%.2f %%" % percent
      else   : flag, progr = self.VVGFwN , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFkas1(mPath)
     if curSize > -1:
      fSize = CC1TwY.VVBRyA(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC1TwY.VVBRyA(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFkas1(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVRvFL , "%.2f %%" % percent
       else   : flag, progr = self.VVGFwN , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC1TwY.VVBRyA(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVMhXC
     if m3u8Log :
      if not speed and not force : flag = self.VVjZti
      elif curSize == -1   : self.VV0KpZ(False)
    elif flag == self.VV8fJC  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV8fJC  : color2 = "#f#00555555#"
    elif flag == self.VVjZti : color2 = "#f#0000FFFF#"
    elif flag == self.VVMhXC : color2 = "#f#0000FFFF#"
    elif flag == self.VVRvFL  : color2 = "#f#00FF8000#"
    elif flag == self.VVGFwN  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVsOZ4(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVzpbP.append(row)
   if changed or force:
    self.VVeDC2.VV6IAT(VVzpbP, VVAnCiMsg=False)
 def VVsOZ4(self, flag):
  tDict = self.VVR5fT()
  return tDict.get(flag, "?")
 def VVlGRn(self, state):
  for flag, txt in self.VVR5fT().items():
   if txt == state:
    return flag
  return -1
 def VVR5fT(self):
  return { self.VV8fJC: "Not started", self.VVjZti: "Connecting", self.VVMhXC: "Downloading", self.VVRvFL: "Stopped", self.VVGFwN: "Completed" }
 def VVIN2n(self, title):
  colList = self.VVeDC2.VVxY0I()
  path = colList[6]
  url  = colList[8]
  if self.VVQKmu() : self.VVy1Mf("Cannot delete !\n\nFile is downloading.")
  else      : FFlEph(self.SELF, BF(self.VVB5AF, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVB5AF(self, path, url):
  m3u8Log = self.VVeDC2.VVxY0I()[12]
  if m3u8Log : os.system(FFN2Os("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFN2Os("rm -r '%s'" % path))
  self.VVH94f(False)
  self.VVxCq4()
 def VVH94f(self, VVjHD0=True):
  if self.VVQKmu():
   FFgjbJ(self.VVeDC2, self.VVsOZ4(self.VVMhXC), 500)
  else:
   colList  = self.VVeDC2.VVxY0I()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVlGRn(state) in (self.VV8fJC, self.VVGFwN, self.VVRvFL):
    lines = CCxguE.VVrDNH()
    newLines = []
    found = False
    for line in lines:
     if CCxguE.VVDt3U(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVSZzM(newLines)
     self.VVxCq4()
     FFgjbJ(self.VVeDC2, "Removed.", 1000)
    else:
     FFgjbJ(self.VVeDC2, "Not found.", 1000)
   elif VVjHD0:
    self.VVy1Mf("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVhuc1(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFlEph(self.SELF, BF(self.VVKy0s, flag), ques, title=title)
 def VVKy0s(self, flag):
  list = []
  for ndx, row in enumerate(self.VVeDC2.VVmbqa()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVlGRn(state)
   if   flag == flagVal == self.VVGFwN: list.append(decodedUrl)
   elif flag == flagVal == self.VV8fJC : list.append(decodedUrl)
  lines = CCxguE.VVrDNH()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVSZzM(newLines)
   self.VVxCq4()
   FFgjbJ(self.VVeDC2, "%d removed." % totRem, 1000)
  else:
   FFgjbJ(self.VVeDC2, "Not found.", 1000)
 def VVJ8jb(self):
  colList  = self.VVeDC2.VVxY0I()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFgjbJ(self.VVeDC2, "Poster exists", 1500)
  else    : FFKsz7(self.VVeDC2, BF(self.VVtiwU, decodedUrl, path, png), title="Checking Server ...")
 def VVtiwU(self, decodedUrl, path, png):
  err = self.VVuys4(decodedUrl, path, png)
  if err:
   FFoFqK(self.SELF, err, title="Poster Download")
 def VVuys4(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCkzVG.VVjw5b(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCXWrP.VVmjdi(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCXWrP.VV6FjI(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFg3JL(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFN2Os("mv -f '%s' '%s'" % (tPath, png)))
   CC9YFX.VVqn2L(self.SELF, VVVTIX=png, showGrnMsg="Downloaded")
   return ""
 def VVpi6e(self, VVeDC2, title, txt, colList):
  def VVAqUp(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVy3eN(key, val) : return "\n%s:\n%s\n" % (FFj5YA(key, VVMCs3), val.strip())
  heads  = self.VVeDC2.VV07Cq()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVAqUp(heads[i]  , CC1TwY.VVBRyA(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVAqUp("Downloaded" , CC1TwY.VVBRyA(int(curSize), mode=0))
   else:
    txt += VVAqUp(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVy3eN(heads[i], colList[i])
  FFcTZL(self.SELF, txt, title=title)
 def VVyekq(self, VVeDC2, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC1TwY.VV9CaF(self.SELF, path)
  else    : FFgjbJ(self.VVeDC2, "File not found", 1000)
 def VVLBn8(self, VVeDC2):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVeDC2:
   self.VVeDC2.cancel()
  del self
 def VVAorH(self, VVeDC2, title, txt, colList):
  c1, c2, c3 = VVAjMy, VVXz72, VVMCs3
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVGtpd = []
  VVGtpd.append((c1 + "Remove current row"       , "VVH94f" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVGtpd.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c2 + "Delete the file (and remove from list)"  , "VVIN2n"))
  VVGtpd.append(VVttU7)
  VVGtpd.append((resumeTxt + " Auto Resume"       , "VVZ1UB" ))
  VVGtpd.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVGtpd.append(VVttU7)
  t = "Download Movie Poster "
  if FFCX2Z(decodedUrl): VVGtpd.append((c3 + "%s(from server)" % t , "VVJ8jb"  ))
  else      : VVGtpd.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVGtpd.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVGtpd.append(("Open in File Manager"  ,      ))
  FFINMf(self.SELF, BF(self.VVxrgv, VVeDC2), VVGtpd=VVGtpd, title=self.Title, VVOvZt=True, width=800, VVsFdc=True, VVghW2="#1a001122", VVlnMM="#1a001122")
 def VVxrgv(self, VVeDC2, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVH94f"  : self.VVH94f()
   elif ref == "remFinished"   : self.VVhuc1(self.VVGFwN, txt)
   elif ref == "remPending"   : self.VVhuc1(self.VV8fJC, txt)
   elif ref == "VVIN2n" : self.VVIN2n(txt)
   elif ref == "VVJ8jb"  : self.VVJ8jb()
   elif ref == "VVZ1UB"  : FFSmZ2(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFSmZ2(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CC1TwY, mode=CC1TwY.VVk7Gc, jumpToFile=path)
    else    : FFgjbJ(VVeDC2, "Path not found !", 1500)
 def VVpQ9N(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCkzVG.VVjw5b(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVy1Mf("Could not get download link !\n\nTry again later.")
     return
  for line in CCxguE.VVrDNH():
   if CCxguE.VVDt3U(decodedUrl, line):
    if self.VVeDC2:
     self.VV7XIg(decodedUrl)
     FFkWtI(BF(FFgjbJ, self.VVeDC2, "Already listed !", 2000))
    break
  else:
   params = self.VVZqiJ(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVy1Mf(params[0])
   elif len(params) == 2:
    FFlEph(self.SELF, BF(self.VVZRsa, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC1TwY.VVBRyA(fSize)
    FFlEph(self.SELF, BF(self.VV7ebK, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV7ebK(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCxguE.VVxUvA(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVxCq4()
  if self.VVeDC2:
   self.VVeDC2.VVnICW()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCxguE.VVDBBp, path, decodedUrl)
   self.VVlt6z(threadName, url, decodedUrl, path, resp)
 def VV7XIg(self, decodedUrl):
  if self.VVeDC2:
   for ndx, row in enumerate(self.VVeDC2.VVmbqa()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVeDC2:
     self.VVeDC2.VVvFsV(ndx)
     break
 def VVZqiJ(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VV7RUN(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVwIfo(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCkzVG.VVjw5b(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCkzVG.VVZgAc()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCxguE.VVwADe(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCxguE.VVQzSB(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVZRsa(self, resp, decodedUrl):
  if not os.system(FFN2Os("which ffmpeg")) == 0:
   FFlEph(self.SELF, BF(CCXWrP.VVxbSn, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VV7RUN(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVOQQc(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFlEph(self.SELF, BF(self.VVtOi9, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVtOi9(rTxt, rUrl)
  else:
   self.VVy1Mf("Cannot process m3u8 file !")
 def VVOQQc(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVGtpd = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCXWrP.VVYnNH(rUrl, fPath)
   VVGtpd.append((resol, fullUrl))
  if VVGtpd:
   FFINMf(self.SELF, self.VVLwsr, VVGtpd=VVGtpd, title="Resolution", VVOvZt=True, VVsFdc=True)
  else:
   self.VVy1Mf("Cannot get Resolutions list from server !")
 def VVLwsr(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFlEph(self.SELF, BF(FFkWtI, BF(self.VVBJRe, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFkWtI(BF(self.VVBJRe, resolUrl))
 def VVBJRe(self, resolUrl):
  txt, err = CCkzVG.VVmuRu(resolUrl)
  if err : self.VVy1Mf(err)
  else : self.VVtOi9(txt, resolUrl)
 def VVMLTD(self, logF, decodedUrl):
  found = False
  lines = CCxguE.VVrDNH()
  with open(CCxguE.VVxUvA(), "w") as f:
   for line in lines:
    if CCxguE.VVDt3U(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCxguE.VVxUvA(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVxCq4()
  if self.VVeDC2:
   self.VVeDC2.VVnICW()
 def VVtOi9(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCXWrP.VVYnNH(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVy1Mf("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVMLTD(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFN2Os("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCxguE.VVDBBp, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVk0FT(dnldLog):
  if fileExists(dnldLog):
   dur = CCxguE.VVVYU6(dnldLog)
   if dur > -1:
    tim = CCxguE.VVo1Lj(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVVYU6(dnldLog):
  lines = FFCpSv("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVo1Lj(dnldLog):
  lines = FFCpSv("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVwIfo(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FF8kdM(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFN2Os("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVlt6z(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVeDC2.VVxY0I()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVl86j, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVl86j(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVXYXl == path:
       break
     else:
      break
  except:
   return
  if CCxguE.VVXYXl:
   CCxguE.VVXYXl = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFkas1(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVZqiJ(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVl86j(url, decodedUrl, path, resp, totFileSize, True)
 def VVHJIu(self, VVeDC2, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVFPc3() : FFgjbJ(self.VVeDC2, self.VVsOZ4(self.VVGFwN), 500)
  elif not self.VVQKmu() : FFgjbJ(self.VVeDC2, self.VVsOZ4(self.VVRvFL), 500)
  elif m3u8Log      : FFlEph(self.SELF, self.VV0KpZ, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVRwLZ():
    CCxguE.VVXYXl = colList[6]
    FFgjbJ(self.VVeDC2, "Stopping ...", 1000)
   else:
    FFgjbJ(self.VVeDC2, "Stopped", 500)
 def VV0KpZ(self, withMsg=True):
  if withMsg:
   FFgjbJ(self.VVeDC2, "Stopping ...", 1000)
  os.system(FFN2Os("killall -INT ffmpeg"))
 def VVRLoa(self, *args):
  if   self.VVFPc3() : FFgjbJ(self.VVeDC2, self.VVsOZ4(self.VVGFwN) , 500)
  elif self.VVQKmu() : FFgjbJ(self.VVeDC2, self.VVsOZ4(self.VVMhXC), 500)
  else:
   resume = False
   m3u8Log = self.VVeDC2.VVxY0I()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFlEph(self.SELF, BF(self.VVgk8X, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VViz8S():
    resume = True
   if resume: FFKsz7(self.VVeDC2, BF(self.VVLkgo), title="Checking Server ...")
   else  : FFgjbJ(self.VVeDC2, "Cannot resume !", 500)
 def VVgk8X(self, m3u8Log):
  os.system(FFN2Os("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFKsz7(self.VVeDC2, BF(self.VVLkgo), title="Checking Server ...")
 def VVLkgo(self):
  colList  = self.VVeDC2.VVxY0I()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCkzVG.VVjw5b(decodedUrl)
   if url:
    decodedUrl = self.VVLu9p(decodedUrl, url)
   else:
    self.VVy1Mf("Could not get download link !\n\nTry again later.")
    return
  curSize = FFkas1(path)
  params = self.VVZqiJ(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVy1Mf(params[0])
   return
  elif len(params) == 2:
   self.VVZRsa(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVLu9p(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCxguE.VVDBBp, path, decodedUrl)
  if resumable: self.VVlt6z(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVy1Mf("Cannot resume from server !")
 def VV7RUN(self, decodedUrl):
  fileExt = CCXWrP.VVo7hy(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFjbqo(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVy1Mf(self, txt):
  FFoFqK(self.SELF, txt, title=self.Title)
 def VVRwLZ(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCxguE.VVDBBp, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVQKmu(self):
  decodedUrl = self.VVeDC2.VVxY0I()[9]
  return decodedUrl in self.VVRwLZ()
 def VVFPc3(self):
  colList = self.VVeDC2.VVxY0I()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFkas1(path)) == size
 def VViz8S(self):
  colList = self.VVeDC2.VVxY0I()
  path = colList[6]
  size = int(colList[7])
  curSize = FFkas1(path)
  if curSize > -1:
   size -= curSize
  err = CCxguE.VVQzSB(size)
  if err:
   FFoFqK(self.SELF, err, title=self.Title)
   return False
  return True
 def VVSZzM(self, list):
  with open(CCxguE.VVxUvA(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVLu9p(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCxguE.VVrDNH()
  url = decodedUrl
  with open(CCxguE.VVxUvA(), "w") as f:
   for line in lines:
    if CCxguE.VVDt3U(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVxCq4()
  return url
 @staticmethod
 def VVrDNH():
  list = []
  if fileExists(CCxguE.VVxUvA()):
   for line in FF8eQ2(CCxguE.VVxUvA()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVDt3U(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVQzSB(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC1TwY.VV66fB(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC1TwY.VVBRyA(size), CC1TwY.VVBRyA(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVDtf0(SELF):
  tot = CCxguE.VVYzUH()
  if tot:
   FFoFqK(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVYzUH():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCxguE.VVDBBp):
    c += 1
  return c
 @staticmethod
 def VVbNU1():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCxguE.VVDBBp, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVCmgk():
  return len(CCxguE.VVrDNH()) == 0
 @staticmethod
 def VVX2xS():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVWj3n():
  mPoints = CCxguE.VVX2xS()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFN2Os("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVxUvA():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVZs2U(SELF):
  CCxguE.VVYDvQ(SELF, CCxguE.VVjytG)
 @staticmethod
 def VVtOOy(SELF):
  CCxguE.VVYDvQ(SELF, CCxguE.VV7ryb, startDnld=True)
 @staticmethod
 def VVwpDG(SELF, url):
  CCxguE.VVYDvQ(SELF, CCxguE.VV7ryb, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVLdle(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF)
  added, skipped = CCxguE.VVDxMf([decodedUrl])
  FFgjbJ(SELF, "Added", 1000)
 @staticmethod
 def VVDxMf(list):
  added = skipped = 0
  for line in CCxguE.VVrDNH():
   for ndx, url in enumerate(list):
    if url and CCxguE.VVDt3U(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCxguE.VVxUvA(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVYDvQ(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CC7Fot.VVaSI5(SELF):
   return
  if mode == CCxguE.VVjytG and CCxguE.VVCmgk():
   FFoFqK(SELF, "Download list is empty !", title=title)
  else:
   inst = CCxguE(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVwADe(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCi57e(Screen, CCWAkM):
 VVYwjf = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFkttW(VV2JSW, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCWAkM.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFOh1m(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVGQp6())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyihG       ,
   "info"  : self.VV4aEJ      ,
   "epg"  : self.VV4aEJ      ,
   "menu"  : self.VVJwU9     ,
   "cancel" : self.cancel       ,
   "red"  : self.VV6Vyx   ,
   "green"  : self.VVpgvF  ,
   "blue"  : self.VVM8px      ,
   "yellow" : self.VVcNlh ,
   "left"  : BF(self.VVAnen, -1)    ,
   "right"  : BF(self.VVAnen,  1)    ,
   "play"  : self.VVuoWY      ,
   "pause"  : self.VVuoWY      ,
   "playPause" : self.VVuoWY      ,
   "stop"  : self.VVuoWY      ,
   "rewind" : self.VV081p      ,
   "forward" : self.VVHU4v      ,
   "rewindDm" : self.VV081p      ,
   "forwardDm" : self.VVHU4v      ,
   "last"  : self.VV2zsc      ,
   "next"  : self.VVKJ61      ,
   "pageUp" : BF(self.VVPFaL, True)  ,
   "pageDown" : BF(self.VVPFaL, False)  ,
   "chanUp" : BF(self.VVPFaL, True)  ,
   "chanDown" : BF(self.VVPFaL, False)  ,
   "up"  : BF(self.VVPFaL, True)  ,
   "down"  : BF(self.VVPFaL, False)  ,
   "audio"  : BF(self.VVausC, True)  ,
   "subtitle" : BF(self.VVausC, False)  ,
   "text"  : self.VVf1tj  ,
   "0"   : BF(self.VVndCX , 10)   ,
   "1"   : BF(self.VVndCX , 1)   ,
   "2"   : BF(self.VVndCX , 2)   ,
   "3"   : BF(self.VVndCX , 3)   ,
   "4"   : BF(self.VVndCX , 4)   ,
   "5"   : BF(self.VVndCX , 5)   ,
   "6"   : BF(self.VVndCX , 6)   ,
   "7"   : BF(self.VVndCX , 7)   ,
   "8"   : BF(self.VVndCX , 8)   ,
   "9"   : BF(self.VVndCX , 9)
  }, -1)
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  if not CCi57e.VVYwjf:
   CCi57e.VVYwjf = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFTvKK(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFTvKK(self["myPlayRpt"], "rpt")
  self.VVZdow()
  self.instance.move(ePoint(40, 40))
  self.VVd6N2(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVJTkc)
  except:
   self.timer.callback.append(self.VVJTkc)
  self.timer.start(250, False)
  self.VVJTkc("Checking ...")
  if not bool(self.iptvTableParams):
   self.VV881I()
 def VVpgvF(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  self.lastSubtitle = CCfZ0K.VVEjwj()
  if "chCode" in iptvRef:
   if CC7Fot.VVaSI5(self):
    self.VV881I(True)
  else:
   self.VVJTkc("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVZdow(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVPhoV()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVNNKJ + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFZM4C(self["myTitle"], tColor)
  FFZM4C(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFZM4C(self["myPlay%s" % item], tColor)
  picFile = CC40v5.VVfj7L(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CC40v5.VVEjpp(self)
  cl = CCbFDB.VVEk3B(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVJTkc(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCxguE.VVYzUH()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVPhoV()
  if evName:
   evName = "    %s    " % FFj5YA(evName, VVOEUE)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVHknD():
   FFmnMn(self["myPlayBlu"], "#00FFFFFF")
   FFZM4C(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFmnMn(self["myPlayBlu"], "#00FFFF88")
   FFZM4C(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFZM4C(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FF5nM6(percVal, 0, 100)
   width = int(FFkk2r(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFZM4C(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFmnMn(self["myPlayMsg"], "#0000ffff")
   else  : FFmnMn(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFmnMn(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFmnMn(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVnDFP()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVVx3H(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCfZ0K.VVGbcj(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV2zsc()
  state = self.VVNDPr()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFmnMn(self["myPlayMsg"], "#0000ff00")
  else     : FFmnMn(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVPhoV(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFHJhk(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC40v5.VVPswp(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCNm5S()
   tpTxt, satTxt = tp.VVWwHI(refCode)
   self.satInfo_TP = tpTxt + "  " + FFj5YA(satTxt, VVM7JM)
  evName = evNameNext = ""
  evLst = CC8SZQ.VV3M3J(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFNY8f(info, iServiceInformation.sVideoWidth) or -1
   h = FFNY8f(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFNY8f(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CC40v5.VVcFBg(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVuXkx(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF1ZBm(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF1ZBm(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FF1ZBm(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVJwU9(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVPhoV()
  FFCX2ZSeries = FFjbqo(decodedUrl)
  VVGtpd = []
  if self.isFromExternal:
   VVGtpd.append((VVM7JM + "IPTV Menu", "iptv"))
   VVGtpd.append(VVttU7)
  if isIptv and not "&end=" in decodedUrl and not FFCX2ZSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVGtpd.append((VVM7JM + "Catchup Programs", "catchup" ))
    VVGtpd.append(VVttU7)
  if refCode:
   c = VVNNKJ
   VVGtpd.append((c + "Stop Current Service"  , "stop"  ))
   VVGtpd.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVGtpd.append((txt     ,    ))
   else : VVGtpd.append((c + txt    , "replayWith" ))
   VVGtpd.append(VVttU7)
  if FFCX2ZSeries:
   VVGtpd.append((VVM7JM + "File Size (on server)", "fileSize" ))
   VVGtpd.append(VVttU7)
  if self.enableDownloadMenu:
   c = VVM7JM
   addSep = False
   if isIptv and FFCX2ZSeries:
    VVGtpd.append((c + "Start Download"  , "dload_cur" ))
    VVGtpd.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCxguE.VVCmgk():
    VVGtpd.append((VVM7JM + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVGtpd.append(VVttU7)
  fPath, fDir, fName = CC1TwY.VV58mN(self)
  if fPath:
   c = VVlyaF
   if self.enableOpenInFMan and not CC1TwY.VVSkK3:
    VVGtpd.append((c + "Open path in File Manager", "VVxTQ4"))
   VVGtpd.append((c + "Add to Bouquet"             , "VVYTPW" ))
   VVGtpd.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVt6QI"  ))
   VVGtpd.append(VVttU7)
  elif isFtp:
   VVGtpd.append((VVMCs3 + "Add FTP Media to Bouquet"     , "VVAD2Q"))
  if isDvb:
   VVGtpd.append((VVM7JM + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVGtpd.append((VVMCs3 + "Start Subtitle", "VVHPyN"))
   VVGtpd.append(VVttU7)
  if CFG.playerPos.getValue() : VVGtpd.append(("Move Bar to Bottom" , "botm"))
  else      : VVGtpd.append(("Move Bar to Top" , "top" ))
  VVGtpd.append(("Help", "help"))
  FFINMf(self, self.VVY5Bi, VVGtpd=VVGtpd, width=600, title="Options")
 def VVY5Bi(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVcNlh()
   elif item == "stop"     : self.VVMPm6(0)
   elif item == "restart"    : self.VVMPm6(1)
   elif item == "replayWith"   : self.VVwSIM()
   elif item == "fileSize"    : FFKsz7(self, BF(CC40v5.VVPXTG, self), title="Checking Server")
   elif item == "dload_cur"   : CCxguE.VVtOOy(self)
   elif item == "addToDload"   : CCxguE.VVLdle(self)
   elif item == "dload_stat"   : CCxguE.VVZs2U(self)
   elif item == "VVxTQ4" : self.close("close_openInFileMan")
   elif item == "VVYTPW" : self.VVYTPW()
   elif item == "VVAD2Q" : self.VVAD2Q()
   elif item == "VVHPyN"  : self.VVVMsn()
   elif item == "VVt6QI"  : self.VVt6QI()
   elif item == "botm"     : self.VVd6N2(0)
   elif item == "top"     : self.VVd6N2(1)
   elif item == "sigMon"    : self.VV6Vyx()
   elif item == "help"     : FFFaGN(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCi57e.VVYwjf = None
 def VVMPm6(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVZdow()
   elif typ == 1:
    self.VVJTkc("Restarting Service ...")
    FFkWtI(BF(self.VVSROF, serv))
 def VVSROF(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  if "&end=" in decodedUrl: BF(self.VV881I, True)
  else     : self.session.nav.playService(serv)
 def VVwSIM(self):
  FFINMf(self, self.VVMmlr, VVGtpd=CCXWrP.VVmBnX(), width=650, title="Select Player", VVghW2="#11220000", VVlnMM="#11220000")
 def VVMmlr(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFp8VH(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVJTkc("No active service !")
 def VVYTPW(self):
  fPath, fDir, fName = CC1TwY.VV58mN(self)
  if fPath: picker = CC3pKJ(self, self, "Add Current Movie to a Bouquet", BF(self.VVHPaw, [fPath]))
  else : FFgjbJ(self, "Path not found !", 1500)
 def VVHPaw(self, pathLst):
  return CC3pKJ.VV0YoR(pathLst)
 def VVAD2Q(self):
  picker = CC3pKJ(self, self, "Add FTP Media to Bouquet", self.VVSJQu)
 def VVSJQu(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  return CC3pKJ.VV0YoR([origUrl], rType=refCode.split(":", 1)[0])
 def VVt6QI(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVJTkc(txt, highlight=ok)
 def VVd6N2(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFSmZ2(CFG.playerPos, pos)
 def VV6Vyx(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC40v5.VVPswp(serv)
   if isDvb: self.close("close_sig")
   else : self.VVJTkc("No Signal for Current Service")
 def VVVMsn(self):
  self.session.openWithCallback(self.VVwm41, BF(CCfZ0K))
 def VVf1tj(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVPhoV()
   if posTxt and durTxt: self.VVVMsn()
   else    : self.VVJTkc("No duration Info. !")
 def VVwm41(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVPFaL(True)
  elif reason == "subtZapDn" : self.VVPFaL(False)
  elif reason == "pause"  : self.VVuoWY()
  elif reason == "audio"  : self.VVausC(True)
  elif reason == "subtitle" : self.VVausC(False)
  elif reason == "rewind"     : self.VV081p()
  elif reason == "forward" : self.VVHU4v()
  elif reason == "rewindDm" : self.VV081p()
  elif reason == "forwardDm" : self.VVHU4v()
  else      : txt = reason
  if txt:
   FFgjbJ(self, txt, 2000)
 def VVyihG(self):
  if self.isManualSeek:
   self.VVa0Xs()
   self.VVVx3H(self.manualSeekPts)
  elif self.shown:
   if CCfZ0K.VVGOUe(self): self.VVVMsn()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVa0Xs()
  else    : self.close()
 def VV4aEJ(self):
  FFeMt4(self, fncMode=CC40v5.VVE80m)
 def VVuoWY(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVJTkc("Toggling Play/Pause ...")
 def VVa0Xs(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVAnen(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVVjw5()
   else:
    self.manualSeekSec += direc * self.VVVjw5()
    self.manualSeekSec = FF5nM6(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFkk2r(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF1ZBm(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVndCX(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVGQp6())
   FFSmZ2(CFG.playerJumpMin, self.jumpMinutes)
  self.VVJTkc("Changed Seek Time to : %d%s" % (val, self.VVUS9W()))
 def VVGQp6(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVUS9W())
 def VVUS9W(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VV6MXW(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVVjw5(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVnDFP(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVM8px(self):
  cList = self.VVHknD()
  if cList:
   VVGtpd = []
   for pts, what in cList:
    txt = FF1ZBm(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVGtpd.append((txt, pts))
   FFINMf(self, self.VV36vF, VVGtpd=VVGtpd, title="Cut List")
  else:
   self.VVJTkc("No Cut-List for this channel !")
 def VV36vF(self, item=None):
  if item:
   self.VVVx3H(item)
 def VVHknD(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVHU4v(self) : self.VVWvSg(1)
 def VV081p(self) : self.VVWvSg(-1)
 def VVWvSg(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVVjw5() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VV6MXW())
    self.VVJTkc(txt)
  except:
   self.VVJTkc("Cannot jump")
 def VVVx3H(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVJTkc("Changing Time ...")
 def VV2zsc(self):
  self.VVMPm6(1)
  self.VVJTkc("Replaying ...")
  self.VVa0Xs()
 def VVKJ61(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVJTkc("Jumping to end ...")
  except:
   pass
 def VVNDPr(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVPFaL(self, isUp):
  if self.enableZapping:
   self.VVJTkc("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVa0Xs()
   if self.iptvTableParams:
    FFkWtI(BF(self.VVFucH, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
    if "/timeshift/" in decodedUrl:
     self.VVJTkc("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV1L1v()
  else:
   self.VVJTkc("Zap Disabled !")
 def VV1L1v(self):
  self.lastPlayPos = 0
  self.VVZdow()
  self.VV881I()
 def VVFucH(self, isUp):
  CCXWrP_inatance, VVeDC2, mode = self.iptvTableParams
  if isUp : VVeDC2.VV5Q0M()
  else : VVeDC2.VViqxN()
  colList = VVeDC2.VVxY0I()
  if mode == "localIptv":
   chName, chUrl = CCXWrP_inatance.VVJZWb(VVeDC2, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCXWrP_inatance.VVWo0a(VVeDC2, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCXWrP_inatance.VVhO9E(mode, VVeDC2, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCXWrP_inatance.VV845t(mode, VVeDC2, colList)
  else:
   self.VVJTkc("Cannot Zap")
   return
  FF4utl(self, chUrl, VVoHm3=False)
  self.VV1L1v()
 def VV881I(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
   if not self.VVuPDh(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVJTkc("Refreshing Portal")
   FFkWtI(self.VVP3ob)
  except:
   pass
 def VVP3ob(self):
  self.restoreLastPlayPos = self.VVMiYM()
 def VVcNlh(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
  if not decodedUrl or FFjbqo(decodedUrl):
   self.VVJTkc("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCXWrP.VVQOpp(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVJTkc("Reading Program List ...")
   ok_fnc = BF(self.VVixSC, refCode, chName, streamId, uHost, uUser, uPass)
   FFkWtI(BF(CCXWrP.VV6HeQ, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVJTkc("Cannot process this channel")
 def VVixSC(self, refCode, chName, streamId, uHost, uUser, uPass, VVeDC2, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVeDC2.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVJTkc("Changing Program ...")
   FFkWtI(BF(self.VVs8JQ, chUrl))
  else:
   self.VVJTkc("Incorrect Timestamp !")
 def VVs8JQ(self, chUrl):
  FF4utl(self, chUrl, VVoHm3=False)
  self.lastPlayPos = 0
  self.VVZdow()
 def VVausC(self, isAudio):
  try:
   VV0qUH = InfoBar.instance
   if VV0qUH:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV0qUH)
    else  : self.session.open(SubtitleSelection, VV0qUH)
  except:
   pass
 @staticmethod
 def VVuvka(session, mode=None):
  if   mode == "close_sig"   : FFh1dN(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCXWrP)
  elif mode == "close_openInFileMan" : session.open(CC1TwY, gotoMovie=True)
 @staticmethod
 def VVnjtb(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCi57e.VVuvka, session), CCi57e, isFromExternal=isFromExternal, **kwargs)
class CC10W9(Screen):
 def __init__(self, session, title="", VV7fsq="Continue?", VVOr97=True, VV4A3A=False):
  self.skin, self.skinParam = FFkttW(VVzM1v, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VV7fsq = VV7fsq
  self.VV4A3A = VV4A3A
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVOr97 : VVGtpd = [no , yes]
  else   : VVGtpd = [yes, no ]
  FFOh1m(self, title, VVGtpd=VVGtpd, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVyihG ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VV7fsq)
  if self.VV4A3A:
   self["myLabel"].instance.setHAlign(0)
  self.VVu5VT()
  FFeJ1R(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFfpz3(self["myMenu"])
  FFcIId(self, self["myMenu"])
 def VVyihG(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVu5VT(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCopPT(Screen):
 def __init__(self, session, title="", VVGtpd=None, width=1000, height=850, VVdez8=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVuZl0=None, VVVLOF=None, VV3Pkd=None, VVDhcZ=None, VVOvZt=False, VVsFdc=False, yellowBasePath=None, rcuSearch=True, VVghW2="#22003344", VVlnMM="#22002233"):
  self.skin, self.skinParam = FFkttW(VVUJSe, width, height, 50, 40, 30, VVghW2, VVlnMM, VVdez8, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVGtpd   = VVGtpd
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVuZl0   = VVuZl0
  self.VVVLOF  = VVVLOF
  self.VV3Pkd  = ("Delete File", BF(self.VVkVua, yellowBasePath)) if not yellowBasePath is None else VV3Pkd
  self.VVDhcZ   = VVDhcZ
  self.VVOvZt  = VVOvZt
  self.VVsFdc  = VVsFdc
  self.Title    = title
  FFOh1m(self, title, VVGtpd=VVGtpd)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyihG    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVGlfE   ,
   "red"  : self.VVo4r3   ,
   "green"  : self.VV9ha6   ,
   "yellow" : self.VVHvSE   ,
   "blue"  : self.VVnvyJ   ,
   "pageUp" : self.VVELDM ,
   "chanUp" : self.VVELDM ,
   "pageDown" : self.VVMk08  ,
   "chanDown" : self.VVMk08  ,
   "0"   : BF(self.VVdYgL, 0) ,
   "1"   : BF(self.VVdYgL, 1) ,
   "2"   : BF(self.VVdYgL, 2) ,
   "3"   : BF(self.VVdYgL, 3) ,
   "4"   : BF(self.VVdYgL, 4) ,
   "5"   : BF(self.VVdYgL, 5) ,
   "6"   : BF(self.VVdYgL, 6) ,
   "7"   : BF(self.VVdYgL, 7) ,
   "8"   : BF(self.VVdYgL, 8) ,
   "9"   : BF(self.VVdYgL, 9)
  }, -1)
  if rcuSearch:
   FFWx6Q(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFeJ1R(self["myMenu"])
  FFpvIL(self, minRows=self.minRows)
  FFe04V(self)
  self.VV1ctc(self["keyRed"]  , self.VVuZl0 )
  self.VV1ctc(self["keyGreen"] , self.VVVLOF )
  self.VV1ctc(self["keyYellow"] , self.VV3Pkd )
  self.VV1ctc(self["keyBlue"]  , self.VVDhcZ )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFsHsH(self)
 def VV1ctc(self, btnObj, btnFnc):
  if btnFnc:
   FFiTXq(btnObj, btnFnc[0])
 def VVQnY4(self, fnc=None):
  self.VVVLOF = fnc
  if fnc : self.VV1ctc(self["keyGreen"], self.VVVLOF)
  else : self["keyGreen"].hide()
 def VVdYgL(self, digit):
  digit = str(digit)
  VVGtpd = self["myMenu"].list
  for ndx, item in enumerate(VVGtpd):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFg0L0(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVUnla(ndx)
     self.VVyihG()
     break
 def VVyihG(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVOvZt: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVGlfE(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVo4r3(self)  : self.VVAfG8(self.VVuZl0)
 def VV9ha6(self) : self.VVAfG8(self.VVVLOF)
 def VVHvSE(self) : self.VVAfG8(self.VV3Pkd)
 def VVnvyJ(self) : self.VVAfG8(self.VVDhcZ)
 def VVAfG8(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVsFdc:
    self.cancel()
 def VVUnla(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VV1zV5(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVGtpd = self["myMenu"].list
  VVGtpd.pop(ndx)
  if len(VVGtpd) > 0: self["myMenu"].setList(VVGtpd)
  else    : self.close()
 def VVkVua(self, basePath, menuObj, fName):
  FFlEph(self, BF(self.VVgCaL, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVgCaL(self, path):
  FF9qnP(path)
  if fileExists(path) : FFgjbJ(self, "Not deleted", 1000)
  else    : self.VV1zV5()
 def VV1Oys(self, VVGtpd):
  if len(VVGtpd) > 0:
   newList = []
   for item in VVGtpd:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFpvIL(self, minRows=self.minRows)
  else:
   self.close("")
 def VVDznA(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFpvIL(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVUdDF(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVELDM(self) : self["myMenu"].moveToIndex(0)
 def VVMk08(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCxWDA(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVkGEY=None, VVZq8i=None, VVsmwq=None, VVdez8=26, VV0i4h=False, VVO3NV=0, VVLseV=None, VVXlcT=None, VVJ6wE=None, VVtaAK=None, VV0q2u=None, VVyNdP=None, VVDXub=None, VVHUGA=None, VVsgQj=None, VV465R=-1, VVwTA1=0, searchCol=0, lastFindConfigObj=None, VVghW2=None, VVlnMM=None, VV5aNF="#00dddddd", VValS2="#11002233", VVRaJ8="#00ff8833", VVKJ4V="#11111111", VVEwGL="#0a555555", VVXn94="#0affffff", VVtDKG="#11552200", VVLFuA="#0055ff55", VVLFuARev="#0000bbff"):
  self.skin, self.skinParam = FFkttW(VVVGfB, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFOh1m(self, title)
  self.Title     = title
  self.header     = header
  self.VVkGEY     = VVkGEY
  self.totalCols    = len(VVkGEY[0])
  self.VVO3NV   = VVO3NV
  self.lastSortModeIsReverese = False
  self.VV0i4h   = VV0i4h
  self.VVmPEy   = 0.01
  self.VVkNyI   = 0.02
  self.VVP8QY = 0.03
  self.VVG9va  = 1
  self.VVsmwq = VVsmwq
  self.colWidthPixels   = []
  self.VVLseV   = VVLseV
  self.OKButtonObj   = None
  self.VVXlcT   = VVXlcT
  self.VVJ6wE   = VVJ6wE
  self.VVtaAK   = VVtaAK
  self.VV0q2u  = VV0q2u
  self.VVyNdP   = VVyNdP
  self.VVDXub    = VVDXub
  self.VVHUGA   = VVHUGA
  self.tableRefreshCB   = None
  self.VVsgQj  = VVsgQj
  self.VV465R    = VV465R
  self.VVwTA1   = VVwTA1
  self.searchCol    = searchCol
  self.VVZq8i    = VVZq8i
  self.keyPressed    = -1
  self.VVdez8    = FF9wzN(VVdez8)
  self.VVuWSd    = FFcg8p(self.VVdez8, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVghW2    = VVghW2
  self.VVlnMM      = VVlnMM
  self.VV5aNF    = FFrqBY(VV5aNF)
  self.VValS2    = FFrqBY(VValS2)
  self.VVRaJ8    = FFrqBY(VVRaJ8)
  self.VVKJ4V    = FFrqBY(VVKJ4V)
  self.VVEwGL   = FFrqBY(VVEwGL)
  self.VVXn94    = FFrqBY(VVXn94)
  self.VVtDKG    = FFrqBY(VVtDKG)
  self.VVLFuA   = FFrqBY(VVLFuA)
  self.VVLFuARev  = FFrqBY(VVLFuARev)
  self.VVFCH5  = False
  self.selectedItems   = 0
  self.VVuDDy   = FFrqBY("#01fefe01")
  self.VVOuLL   = FFrqBY("#11400040")
  self.VVQrBy  = self.VVuDDy
  self.VVO9hh  = self.VVKJ4V
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVwTA1:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVwTA1 == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV7P4W  ,
   "red"  : self.VVdaea  ,
   "green"  : self.VV8E3D ,
   "yellow" : self.VVuahG ,
   "blue"  : self.VVHfFP  ,
   "menu"  : self.VVXE7A ,
   "info"  : self.VVgd40  ,
   "cancel" : self.VVD7ui  ,
   "up"  : self.VViqxN    ,
   "down"  : self.VV5Q0M  ,
   "left"  : self.VVI9hL   ,
   "right"  : self.VVMncE  ,
   "next"  : self.VVUZtN  ,
   "last"  : self.VVKBe1  ,
   "home"  : self.VVmS73  ,
   "pageUp" : self.VVmS73  ,
   "chanUp" : self.VVmS73  ,
   "end"  : self.VVnICW  ,
   "pageDown" : self.VVnICW  ,
   "chanDown" : self.VVnICW
  }, -1)
  FFWx6Q(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  try:
   self.VVb8rD()
  except Exception as e:
   FFoFqK(self, str(e), title=self.Title)
   self.close(None)
 def VVb8rD(self):
  FFsHsH(self)
  if self.VVghW2:
   FFZM4C(self["myTitle"], self.VVghW2)
  if self.VVlnMM:
   FFZM4C(self["myBody"] , self.VVlnMM)
   FFZM4C(self["myTableH"] , self.VVlnMM)
   FFZM4C(self["myTable"] , self.VVlnMM)
   FFZM4C(self["myBar"]  , self.VVlnMM)
  self.VV1ctc(self.VVJ6wE  , self["keyRed"])
  self.VV1ctc(self.VVtaAK  , self["keyGreen"])
  self.VV1ctc(self.VV0q2u , self["keyYellow"])
  self.VV1ctc(self.VVyNdP  , self["keyBlue"])
  if self.VVLseV:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVLseV[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVLseV[0])
    FFZM4C(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVuWSd)
  self["myTableH"].l.setFont(0, gFont(VVrbou, self.VVdez8))
  self["myTable"].l.setItemHeight(self.VVuWSd)
  self["myTable"].l.setFont(0, gFont(VVrbou, self.VVdez8))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVuWSd)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVuWSd))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVuWSd)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVuWSd
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVuWSd * len(self.VVkGEY) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVsmwq:
   self.VVsmwq = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVsmwq)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVZq8i:
   self.VVZq8i = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVZq8i
   self.VVZq8i = []
   for item in tmpList:
    self.VVZq8i.append(item | RT_VALIGN_CENTER)
  self.VVRDP7()
  if self.VVDXub:
   self.VVDXub(self)
 def VV1ctc(self, btnFnc, btn):
  if btnFnc : FFiTXq(btn, btnFnc[0])
  else  : FFiTXq(btn, "")
 def VV0bZY(self, waitTxt):
  FFKsz7(self, self.VVRDP7, title=waitTxt)
 def VVRDP7(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVLFuARev if self.lastSortModeIsReverese else self.VVLFuA
    self["myTableH"].setList([self.VVWgz8(0, self.header, self.VVXn94, self.VVtDKG, self.VVXn94, self.VVtDKG, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVkGEY):
    self["myTable"].list.append(self.VVWgz8(c, row, self.VV5aNF, self.VValS2, self.VVRaJ8, self.VVKJ4V, None))
   self.VVkGEY = []
   self["myTable"].setList(self["myTable"].list)
   if self.VV465R > -1:
    self["myTable"].moveToIndex(self.VV465R )
   self.VVYLDv()
   if self.VVwTA1:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVuWSd * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFlPq0(self, width, newH)
   if self.VVHUGA:
    self.VVAfG8(self.VVHUGA, None)
   if self.tableRefreshCB:
    self.VVAfG8(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFoFqK(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVWgz8(self, keyIndex, columns, VV5aNF, VValS2, VVRaJ8, VVKJ4V, VVLFuA):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVLFuA and ndx == self.VVO3NV : textColor = VVLFuA
   else           : textColor = VV5aNF
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFrqBY(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VValS2 = c
    entry = span.group(3)
   if self.VVZq8i[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVuWSd)
           , font   = 0
           , flags   = self.VVZq8i[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VValS2
           , color_sel  = VVRaJ8
           , backcolor_sel = VVKJ4V
           , border_width = 1
           , border_color = self.VVEwGL
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVgd40(self):
  rowData = self.VVfQOI()
  if rowData:
   title, txt, colList = rowData
   if self.VVXlcT:
    fnc  = self.VVXlcT[1]
    params = self.VVXlcT[2]
    fnc(self, title, txt, colList)
   else:
    FFcTZL(self, txt, title)
 def VV7P4W(self):
  if   self.VVFCH5 : self.VVKewx(self.VVUy0w(), mode=2)
  elif self.VVLseV  : self.VVAfG8(self.VVLseV, None)
  else      : self.VVgd40()
 def VVdaea(self) : self.VVAfG8(self.VVJ6wE , self["keyRed"])
 def VV8E3D(self) : self.VVAfG8(self.VVtaAK , self["keyGreen"])
 def VVuahG(self): self.VVAfG8(self.VV0q2u , self["keyYellow"])
 def VVHfFP(self) : self.VVAfG8(self.VVyNdP , self["keyBlue"])
 def VVAfG8(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFgjbJ(self, buttonFnc[3])
    FFkWtI(BF(self.VVzACq, buttonFnc))
   else:
    self.VVzACq(buttonFnc)
 def VVzACq(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVfQOI()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVKewx(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVuDDy
   newRow = self.VVxY0I()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVWgz8(ndx, newRow, self.VV5aNF, self.VValS2, self.VVRaJ8, self.VVKJ4V, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVWgz8(ndx, newRow, self.VVuDDy, self.VVOuLL, self.VVQrBy, self.VVO9hh, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVUy0w() < len(self["myTable"].list) - 1:
    self.VV5Q0M()
   else:
    self.VVYLDv()
 def VVQoZi(self)  : FFKsz7(self, BF(self.VV9cTm, True ), title="Selecting all ..."  )
 def VVFrvE(self) : FFKsz7(self, BF(self.VV9cTm, False), title="Unselecting all ...")
 def VV9cTm(self, isSel=True):
  if isSel:
   fg, bg = self.VVuDDy, self.VVOuLL
   self.selectedItems = len(self["myTable"].list)
   self.VVMWca(True)
  else:
   fg, bg = self.VV5aNF, self.VValS2
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVuDDy
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVfQOI(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVsmwq[i] > 1 or self.VVsmwq[i] == self.VVmPEy or self.VVsmwq[i] == self.VVP8QY:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVD7ui(self):
  if self.VVsgQj : self.VVsgQj(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVpmbi(self):
  return self["myTitle"].getText().strip()
 def VV07Cq(self):
  return self.header
 def VVWHzV(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVjBIT(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFmnMn(self["myBar"], color)
 def VVaLck(self, txt):
  FFgjbJ(self, txt)
 def VVdL9K(self, txt, Time=1000):
  FFgjbJ(self, txt, Time)
 def VV5b0T(self): self["keyGreen"].show()
 def VV8fXV(self): self["keyGreen"].hide()
 def VVrScD(self): return self["keyGreen"].visible
 def VVtAan(self):
  FFgjbJ(self)
 def VVDsgs(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVpRlV(self):
  return len(self["myTable"].list)
 def VVUy0w(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVz6J6(self):
  return len(self["myTable"].list)
 def VVMWca(self, isOn):
  self.VVFCH5 = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVyNdP: self["keyBlue"].hide()
   if self.VVLseV and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVyNdP: self["keyBlue"].show()
   if self.VVLseV and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVLseV[0])
   self.VVFrvE()
  FFZM4C(self["myTitle"], color)
  FFZM4C(self["myBar"]  , color)
 def VVrpFI(self):
  return self.VVFCH5
 def VVau1b(self):
  return self.selectedItems
 def VVAH6a(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVYLDv()
 def VVcNFm(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVmmCx(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVpRlV()
  txt += FFY7Lk("Total Unique Items", VVXz72)
  for i in range(self.totalCols):
   if self.VVsmwq[i - 1] > 1 or self.VVsmwq[i - 1] == self.VVmPEy or self.VVsmwq[i - 1] == self.VVP8QY:
    name, tot = self.VVcNFm(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFcTZL(self, txt)
 def VVhJef(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVxY0I(self):
  return self.VVMpUH(self["myTable"].l.getCurrentSelectionIndex())
 def VVMpUH(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV6IAT(self, newList, newTitle="", VVAnCiMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VVWHzV(newTitle)
  if newList:
   self.VVkGEY = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VV0i4h and self.VVO3NV == 0:
    isNum = True
   else:
    for cols in self.VVkGEY:
     if not FFXGYs(cols[self.VVO3NV]): break
    else:
     isNum = True
   if isNum: self.VVkGEY.sort(key=lambda x: int(x[self.VVO3NV])  , reverse=self.lastSortModeIsReverese)
   else : self.VVkGEY.sort(key=lambda x: x[self.VVO3NV].lower() , reverse=self.lastSortModeIsReverese)
   if VVAnCiMsg : self.VV0bZY("Refreshing ...")
   else   : self.VVRDP7()
  else:
   FFoFqK(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVydVv(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVWgz8(self.VVz6J6(), row, self.VV5aNF, self.VValS2, self.VVRaJ8, self.VVKJ4V, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVnICW()
 def VV6b8U(self):
  self["myTable"].list.pop(self.VVUy0w())
  self["myTable"].l.setList(self["myTable"].list)
 def VVji2V(self, data):
  ndx = self.VVUy0w()
  newRow = self.VVWgz8(ndx, data, self.VV5aNF, self.VValS2, self.VVRaJ8, self.VVKJ4V, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVYLDv()
   return True
  else:
   return False
 def VVTczo(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVWgz8(ndx, data, self.VV5aNF, self.VValS2, self.VVRaJ8, self.VVKJ4V, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVZmUC()
 def VVZmUC(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVkSTY(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VV6eK5(self, colNum, textToFind, VVjHD0=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVYLDv()
    break
  else:
   if VVjHD0:
    FFgjbJ(self, "Not found", 1000)
 def VVWrIi(self, colDict, VVjHD0=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVYLDv()
    return
  if VVjHD0:
   FFgjbJ(self, "Not found", 1000)
 def VV8E66(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVCai4(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFXGYs(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VV2oru(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVuDDy:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVLzYo(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVuDDy:
     return ndx
  return -1
 def VVdQBn(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVuDDy:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVZg6r(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVuDDy: return True
  else        : return False
 def VVmbqa(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVXE7A(self):
  if not self["keyMenu"].getVisible() or self.VVwTA1:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVUy0w()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVGtpd1, VVzBKK = CCZt3D.VVqaPy(self, False, False)
  VVGtpd = []
  VVGtpd.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVGtpd.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVGtpd.append(("Find ...\t\t%s" % (FFj5YA(txt, VVFiA5) if txt else ""), "findNew"   ))
  VVGtpd.append(itemOf(bool(VVGtpd1)    , "Find (from Filter) ..."   , "filter"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Table Statistcis"             , "tableStat"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((FFj5YA("Export Table to .html"     , VVXz72) , "VVkQG6" ))
  VVGtpd.append((FFj5YA("Export Table to .csv"     , VVXz72) , "VVuvF4" ))
  VVGtpd.append((FFj5YA("Export Table to .txt (Tab Separated)", VVXz72) , "VVyaKO" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVsmwq[i] > 1 or self.VVsmwq[i] == self.VVkNyI:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVGtpd.append(VVttU7)
   if tot == 1 : VVGtpd.append(("Sort", sList[0][1]))
   else  : VVGtpd += sList
  VVDhcZ = ("Keys Help", self.FF4zYjHelp)
  FFINMf(self, self.VV29Kq, VVGtpd=VVGtpd, title=self.VVpmbi(), VVDhcZ=VVDhcZ)
 def VV29Kq(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVrKwu()
   elif item == "findPrev"  : self.VVrKwu(isPrev=True)
   elif item == "findNew"  : self.VVOHFT()
   elif item == "filter"  : self.VVuFrr()
   elif item == "tableStat" : self.VVmmCx()
   elif item == "VVkQG6": FFKsz7(self, self.VVkQG6, title=title)
   elif item == "VVuvF4" : FFKsz7(self, self.VVuvF4 , title=title)
   elif item == "VVyaKO" : FFKsz7(self, self.VVyaKO , title=title)
   else:
    if self.VVO3NV == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVO3NV, self.lastSortModeIsReverese = item, False
    if self.VV0i4h and self.VVO3NV == 0 or self.VVCai4(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVRDP7(onlyHeader=True)
 def FF4zYjHelp(self, menuInstance, path):
  FFFaGN(self, "_help_table", "Table (Keys Help)")
 def VViqxN(self):
  self["myTable"].up()
  self.VVYLDv()
 def VV5Q0M(self):
  self["myTable"].down()
  self.VVYLDv()
 def VVI9hL(self):
  self["myTable"].pageUp()
  self.VVYLDv()
 def VVMncE(self):
  self["myTable"].pageDown()
  self.VVYLDv()
 def VVmS73(self):
  self["myTable"].moveToIndex(0)
  self.VVYLDv()
 def VVnICW(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVYLDv()
 def VVvFsV(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVYLDv()
 def VVUZtN(self):
  if self.lastFindConfigObj.getValue():
   if self.VVUy0w() == len(self["myTable"].list) - 1 : FFgjbJ(self, "End reached", 1000)
   else              : self.VVrKwu()
  else:
   FFgjbJ(self, 'Set "Find" in Menu', 1500)
 def VVKBe1(self):
  if self.lastFindConfigObj.getValue():
   if self.VVUy0w() == 0 : FFgjbJ(self, "Top reached", 1000)
   else       : self.VVrKwu(isPrev=True)
  else:
   FFgjbJ(self, 'Set "Find" in Menu', 1500)
 def VVbZld(self, txt):
  FFSmZ2(self.lastFindConfigObj, txt)
 def VVOHFT(self):
  FF8cVc(self, self.VVdrGS, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVdrGS(self, VVOd8Z):
  if not VVOd8Z is None:
   txt = VVOd8Z.strip()
   self.VVbZld(txt)
   if VVOd8Z: self.VVrKwu(reset=True)
   else  : FFgjbJ(self, "Nothing to find !", 1500)
 def VVuFrr(self):
  VVGtpd, VVzBKK = CCZt3D.VVqaPy(self, False, False)
  VV3Pkd = ("Edit Filter", BF(self.VVVZxX, VVzBKK))
  if VVGtpd : FFINMf(self, self.VVLHYx, VVGtpd=VVGtpd, VV3Pkd=VV3Pkd, title="Find from Filter")
  else  : FFgjbJ(self, "Filter Error !", 1500)
 def VVLHYx(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVbZld(txt)
    self.VVrKwu(reset=True)
   else:
    FFgjbJ(self, "No entry !", 1500)
 def VVVZxX(self, VVzBKK, VVE2XdObj, sel):
  if fileExists(VVzBKK) : CCkPUj(self, VVzBKK, VV00AH=None)
  else       : FFE0MG(self, VVzBKK)
  VVE2XdObj.cancel()
 def VVrKwu(self, reset=False, isPrev=False):
  curRow = self.VVUy0w()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCZt3D.VVvY0h(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVvFsV(i)
      break
    elif any(x in line for x in tupl):
     self.VVvFsV(i)
     break
   else:
    FFgjbJ(self, "Not found", 1000)
  else:
   FFgjbJ(self, "Check your query", 1500)
 def VVyaKO(self):
  expFile = self.VVlVbW() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVbEns()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVMpUH(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVsmwq[ndx] > self.VVG9va or self.VVsmwq[ndx] == self.VVP8QY:
      col = self.VV0dN8(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVTBVi(expFile)
 def VVuvF4(self):
  expFile = self.VVlVbW() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVbEns()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVMpUH(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVsmwq[ndx] > self.VVG9va or self.VVsmwq[ndx] == self.VVP8QY:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VV0dN8(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVTBVi(expFile)
 def VVkQG6(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVpmbi(), PLUGIN_NAME, VVJjPN)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVpmbi()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVbEns()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVsmwq:
   colgroup += '   <colgroup>'
   for w in self.VVsmwq:
    if w > self.VVG9va or w == self.VVP8QY:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVlVbW() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVMpUH(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVsmwq[ndx] > self.VVG9va or self.VVsmwq[ndx] == self.VVP8QY:
      col = self.VV0dN8(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVTBVi(expFile)
 def VVbEns(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVsmwq[ndx] > self.VVG9va or self.VVsmwq[ndx] == self.VVP8QY:
     newRow.append(col.strip())
  return newRow
 def VV0dN8(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFg0L0(col)
 def VVlVbW(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVpmbi())
  fileName = fileName.replace("__", "_")
  path  = FFoR3R(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFbNWS()
  return expFile
 def VVTBVi(self, expFile):
  FFOPTX(self, "File exported to:\n\n%s" % expFile, title=self.VVpmbi())
 def VVYLDv(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCbFDB():
 def __init__(self, pixmapObj, picPath, VValS2=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VValS2  = VValS2 or "#2200002a"
 def VVsEbo(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVd0uw)
    except:
     self.picLoad.PictureData.get().append(self.VVd0uw)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VValS2])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVd0uw(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVNdUh(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVEk3B(pixmapObj, path, VValS2=None):
  cl = CCbFDB(pixmapObj, path, VValS2)
  ok = cl.VVsEbo()
  if ok: return cl
  else : return None
class CC9YFX(Screen):
 def __init__(self, session, VVVTIX, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFIyPo()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFkttW(VVhWvd, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVVTIX = VVVTIX
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFOh1m(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVJy6n  ,
   "up" : BF(self.VVY3yr, -1),
   "down" : BF(self.VVY3yr,  1),
   "left" : BF(self.VVY3yr, -1),
   "right" : BF(self.VVY3yr,  1)
  }, -1)
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  self.VVMCKd()
  self.picViewer = CCbFDB.VVEk3B(self["myPic"], self.VVVTIX)
  if self.picViewer:
   if self.showGrnMsg:
    FFgjbJ(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFoFqK(self, "Cannot view picture file:\n\n%s" % self.VVVTIX)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVNdUh()
  if self.cbFnc  : self.cbFnc(self.VVVTIX)
 def VVY3yr(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVVTIX = FFoR3R(os.path.dirname(self.VVVTIX)) + fName
    self.picViewer.picPath = self.VVVTIX
    self.picViewer.VVsEbo()
    self.VVMCKd()
 def VVJy6n(self):
  txt = "%s:\n  %s" % (FFj5YA("Path", VVMCs3), self.fakePath or self.VVVTIX)
  size, sizeTxt, resTxt, form, mode = CCQNEy.VVoDz0(self.VVVTIX)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFj5YA("Properties", VVMCs3)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFcTZL(self, txt, title="File Information")
 def VVMCKd(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVVTIX)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVqn2L(SELF, VVVTIX, **kwargs):
  SELF.session.open(CC9YFX, VVVTIX, **kwargs)
class CCNZwT(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFkttW(VVSyAJ, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFOh1m(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.onExit)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFN2Os("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVrh2Q(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCNZwT.VVWDU7, SELF), CCNZwT, mviFile)
 @staticmethod
 def VVWDU7(SELF, reason=None):
  if reason == -1: FFoFqK(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCYEM7(Screen, ConfigListScreen):
 VVU128 = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VV18CB, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFOh1m(self, title=self.Title)
  FFiTXq(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (for File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry(VVa91R *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVa91R *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVa91R *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV5bYh()
  self.onShown.append(self.VVP1sX)
 def VV5bYh(self):
  kList = {
    "ok" : self.VVyihG   ,
    "green" : self.VVGdCQ ,
    "menu" : self.VVkYmg ,
    "cancel": self.VVmd36 ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVmDHs, 0)
     kList["chanDown"] = BF(self["config"].VVmDHs, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFe04V(self)
  FFeJ1R(self["config"])
  FFpvIL(self, self["config"])
  FFsHsH(self)
  self["config"].onSelectionChanged.append(self.VVn2uf)
  FFZM4C(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVn2uf()
 def VVn2uf(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVyihG(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVYxn5()
   elif item == CFG.MovieDownloadPath   : self.VVAcQe(item, self["config"].getCurrent()[0])
   elif isinstance(item, ConfigDirectory) : self.VVmNXq(item)
   else         : CCYEM7.VV2Dmg(self, item, title)
 @staticmethod
 def VV2Dmg(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVGtpd = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVa91R)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVFiA5 + txt
    elif val == confItem.default: defNdx, txt = ndx, VVNUk6 + txt
   VVGtpd.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVDhcZ  = ("Current", BF(CCYEM7.VVfjdB, curNdx))
  VV3Pkd = ("Default", BF(CCYEM7.VVfjdB, defNdx))
  menuInstance = FFINMf(SELF, BF(CCYEM7.VV8Ua2, confItem, cbFnc), VVGtpd=VVGtpd, width=1200, VV3Pkd=VV3Pkd, VVDhcZ=VVDhcZ, title=title, VVghW2="#33221111", VVlnMM="#33110011")
  menuInstance.VVUnla(curNdx)
 @staticmethod
 def VV8Ua2(confItem, cbFnc, item=None):
  if not item is None:
   FFSmZ2(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVfjdB(ndx, VVE2XdObj, item):
  VVE2XdObj.VVUnla(ndx)
 @staticmethod
 def VVI5Gm(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVAcQe(self, item, title):
  tot = CCxguE.VVYzUH()
  if tot : FFoFqK(self, "Cannot change while downloading.", title=title)
  else : self.VVmNXq(item)
 def VVYxn5(self):
  VVGtpd = []
  VVGtpd.append(("Auto Find" , "auto"))
  VVGtpd.append(("Custom Path" , "cust"))
  FFINMf(self, self.VVnZmm, VVGtpd=VVGtpd, title="IPTV Hosts Files Path")
 def VVnZmm(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVoZbD)
   elif item == "cust":
    VVzpbP = self.VVGbp4()
    if VVzpbP : self.VV8Ryk(VVzpbP)
    else  : self.session.openWithCallback(self.VV2mOA, BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i="/"))
 def VV8Ryk(self, VVzpbP):
  VVsgQj = self.VVZzb8
  VVJ6wE = ("Remove"  , self.VVOgFf , [])
  VV0q2u = ("Add "  , self.VVMAux, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVZq8i  = (LEFT   , LEFT  )
  FF4zYj(self, None, title="IPTV Hosts Search Paths", header=header, VVkGEY=VVzpbP, width=1200, height=700, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=26, VVsgQj=VVsgQj, VVJ6wE=VVJ6wE, VV0q2u=VV0q2u
    , VVghW2="#22220000", VVlnMM="#22110000", VValS2="#22110011", VVRaJ8="#11ffff00", VVKJ4V="#11223025", VVEwGL="#0a333333", VVtDKG="#11400040")
 def VVZzb8(self, VVeDC2):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVw1Jl)
  VVeDC2.cancel()
 def VV2mOA(self, path):
  if path:
   FFSmZ2(CFG.iptvHostsDirs, FFoR3R(path.strip()))
   VVzpbP = self.VVGbp4()
   if VVzpbP : self.VV8Ryk(VVzpbP)
   else  : FFgjbJ(self, "Cannot add dir", 1500)
 def VVkZ7W(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVoZbD:
   return []
  return lst
 def VVGbp4(self):
  lst = self.VVkZ7W()
  if lst:
   VVzpbP = []
   for Dir in lst:
    VVzpbP.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVzpbP.sort(key=lambda x: x[0].lower())
   return VVzpbP
  else:
   return []
 def VVMAux(self, VVeDC2, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVHm9C, VVeDC2)
         , BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=sDir))
 def VVHm9C(self, VVeDC2, path):
  if path:
   path = FFoR3R(path.strip())
   if self.VVY184(VVeDC2, path):
    FFgjbJ(VVeDC2, "Already added", 1500)
   else:
    lst = self.VVkZ7W()
    lst.append(path)
    FFSmZ2(CFG.iptvHostsDirs, ",".join(lst))
    VVzpbP = self.VVGbp4()
    VVeDC2.VV6IAT(VVzpbP, tableRefreshCB=BF(self.VV0bX7, path))
 def VV0bX7(self, path, VVeDC2, title, txt, colList):
  self.VVY184(VVeDC2, path)
 def VVY184(self, VVeDC2, path):
  for ndx, row in enumerate(VVeDC2.VVmbqa()):
   if row[0].strip() == path.strip():
    VVeDC2.VVvFsV(ndx)
    return True
  return False
 def VVOgFf(self, VVeDC2, title, txt, colList):
  path = colList[0]
  FFlEph(self, BF(self.VVL0Sq, VVeDC2), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVL0Sq(self, VVeDC2):
  row = VVeDC2.VVxY0I()
  path, rem = row[0], row[1]
  VVzpbP = []
  lst = []
  for ndx, row in enumerate(VVeDC2.VVmbqa()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVzpbP.append((tPath, tRem))
  if len(VVzpbP) > 0:
   FFSmZ2(CFG.iptvHostsDirs, ",".join(lst))
   VVeDC2.VV6IAT(VVzpbP)
   FFgjbJ(VVeDC2, "Deleted", 1500)
  else:
   FFSmZ2(CFG.iptvHostsMode, VVoZbD)
   FFSmZ2(CFG.iptvHostsDirs, "")
   VVeDC2.cancel()
   FFkWtI(BF(FFgjbJ, self, "Changed to Auto-Find", 1500))
 def VVmNXq(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVPOTy, configObj)
         , BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=sDir))
 def VVPOTy(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVmd36(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFlEph(self, self.VVGdCQ, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVGdCQ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVyCET()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVkYmg(self):
  VVGtpd = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVGtpd.append((txt    , "VVG9dj"   ))
  else        : VVGtpd.append((txt    ,       ))
  VVGtpd.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Reset %s Settings" % PLUGIN_NAME      , "VVfDpx"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Backup %s Settings" % PLUGIN_NAME      , "VV54VE"  ))
  VVGtpd.append(("Restore %s Settings" % PLUGIN_NAME     , "VVd7TH"  ))
  if fileExists(VVFuxe + CCYEM7.VVU128):
   VVGtpd.append(VVttU7)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVGtpd.append(('%s Checking for Update' % txt1     , txt2     ))
   VVGtpd.append(("Reinstall %s" % PLUGIN_NAME      , "VVcjiZ"  ))
   VVGtpd.append(("Update %s" % PLUGIN_NAME      , "VViBzY"   ))
  FFINMf(self, self.VVCfvj, VVGtpd=VVGtpd, title="Config. Options")
 def VVCfvj(self, item=None):
  if item:
   if   item == "VVG9dj"  : FFlEph(self, self.VVG9dj , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCec5j)
   elif item == "VVfDpx"  : FFlEph(self, BF(self.VVfDpx, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VV54VE" : self.VV54VE()
   elif item == "VVd7TH" : FFKsz7(self, self.VVd7TH, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFSmZ2(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFSmZ2(CFG.checkForUpdateAtStartup, False)
   elif item == "VVcjiZ" : FFKsz7(self, BF(self.VVRjEd, True ), "Checking Server ...")
   elif item == "VViBzY"  : FFKsz7(self, BF(self.VVRjEd, False), "Checking Server ...")
 def VV54VE(self):
  path = "%sajpanel_settings_%s" % (VVFuxe, FFbNWS())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVCQ1V, path))
  FFOPTX(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVd7TH(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFCpSv("find / %s -iname '%s*' | grep %s" % (FFxM0r(1), name, name))
  if files:
   err = CC1TwY.VVQSTE(files)
   if err:
    FFlEph(self, BF(self.VVlXmz, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVGtpd = []
    for line in files:
     VVGtpd.append((line, line))
    FFINMf(self, BF(self.VVzb6c, title), title=title, VVGtpd=VVGtpd, width=1200, yellowBasePath="")
  else:
   FFoFqK(self, "No settings files found !", title=title)
 def VVlXmz(self, title, path=None):
  sDir = "/"
  for path in (VVFuxe, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVzb6c, title), BF(CC1TwY, patternMode="ajpSet", VViJ7i=sDir))
 def VVzb6c(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF8eQ2(path)
    self.VVfDpx()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVyCET()
    FFmC2q()
    FFgjbJ(self, "Apllied", 1500, isGrn=True)
   else:
    FFE0MG(self, path, title=title)
 def VVG9dj(self):
  newPath = FFoR3R(VVFuxe)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVyCET()
 @staticmethod
 def VVht4P():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVfDpx(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVyCET()
  if exit:
   self.close()
 def VVyCET(self):
  configfile.save()
  global VVFuxe
  VVFuxe = CFG.backupPath.getValue()
  FFiWwr()
 def VVRjEd(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCYEM7.VVGfl8()
  if   err    : FFoFqK(self, err, title)
  elif isHigher or force : FFlEph(self, BF(FFKsz7, self, BF(self.VVDbD6, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFOPTX(self, FFj5YA("No update required.", VVTVTj) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVDbD6(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFik66() == "dpkg" else "ipk")
  path, err = FFg3JL(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFDHcv(VVOwmy, path)
   else : cmd = FFDHcv(VV3VA9, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
    FFB1pa(self, cmd, title=title)
   else:
    FFmApx(self, title=title)
  else:
   FFoFqK(self, err, title=title)
 @staticmethod
 def VVGfl8():
  span = iSearch(r"v*(\d.\d.\d)", VVJjPN, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVFuxe + CCYEM7.VVU128
  if fileExists(path):
   span = iSearch(r"(http.+)", FFEJE4(path), IGNORECASE)
   if span : url = FFoR3R(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFg3JL(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFEJE4(path).strip().replace(" ", "")
   FF9qnP(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, True if webTup > curTup else False, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCec5j(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VVhLTO, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFOh1m(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVVLAZ("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVVLAZ("\c00888888", i) + sp + "GREY\n"
   txt += self.VVVLAZ("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVVLAZ("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVVLAZ("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVVLAZ("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVVLAZ("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVVLAZ("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVVLAZ("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVVLAZ("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVVLAZ("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVVLAZ("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVyihG ,
   "green" : self.VVyihG ,
   "left" : self.VVefd6 ,
   "right" : self.VVJDDO ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  self.VVFzZf()
 def VVyihG(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFlEph(self, self.VV4Lmc, "Change to : %s" % txt, title=self.Title)
 def VV4Lmc(self):
  FFSmZ2(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVxo84()
  self.close()
 def VVefd6(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVFzZf()
 def VVJDDO(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVFzZf()
 def VVFzZf(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVVLAZ(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVgasN(color):
  if VVNUk6: return "\\" + color
  else    : return ""
 @staticmethod
 def VVxo84():
  global VVky8q, VVOEUE, VVfzKO, VVNNKJ, VVXz72, VVAjMy, VVYofj, VVKnHQ, VVTVTj, VVlyaF, VVNUk6, VVMCs3, VVFiA5, VVM7JM, VVJsQK, VVDIbD
  VVDIbD   = CCec5j.VVVLAZ("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVOEUE    = CCec5j.VVVLAZ("\c00888888", COLOR_SCHEME_NUM)
  VVky8q  = CCec5j.VVVLAZ("\c005A5A5A", COLOR_SCHEME_NUM)
  VVKnHQ    = CCec5j.VVVLAZ("\c00FF0000", COLOR_SCHEME_NUM)
  VVfzKO   = CCec5j.VVVLAZ("\c00FF5000", COLOR_SCHEME_NUM)
  VVNNKJ   = CCec5j.VVVLAZ("\c00FFBB66", COLOR_SCHEME_NUM)
  VVNUk6   = CCec5j.VVVLAZ("\c00FFFF00", COLOR_SCHEME_NUM)
  VVMCs3 = CCec5j.VVVLAZ("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVTVTj   = CCec5j.VVVLAZ("\c0000FF00", COLOR_SCHEME_NUM)
  VVlyaF  = CCec5j.VVVLAZ("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVYofj    = CCec5j.VVVLAZ("\c000066FF", COLOR_SCHEME_NUM)
  VVFiA5    = CCec5j.VVVLAZ("\c0000FFFF", COLOR_SCHEME_NUM)
  VVM7JM  = CCec5j.VVVLAZ("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVJsQK   = CCec5j.VVVLAZ("\c00FA55E7", COLOR_SCHEME_NUM)
  VVXz72    = CCec5j.VVVLAZ("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVAjMy  = CCec5j.VVVLAZ("\c00FFC0C0", COLOR_SCHEME_NUM)
CCec5j.VVxo84()
class CCZlUG(Screen):
 def __init__(self, session, path, VVtGSd):
  self.skin, self.skinParam = FFkttW(VVys1c, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVaPiN   = path
  self.VVGESs   = ""
  self.VVzU2O   = ""
  self.VVtGSd    = VVtGSd
  self.VVw2Ty    = ""
  self.VVKQwT  = ""
  self.VVMjO5    = False
  self.VVnjCB  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVShk2  = "enigma2-plugin-extensions-"
  self.VVgPAo  = "enigma2-plugin-systemplugins-"
  self.VVelq7 = "enigma2-"
  self.VVKrou  = 0
  self.VV1UAM  = 1
  self.VVKdQH  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVeAy6 = "DEBIAN"
  else        : self.VVeAy6 = "CONTROL"
  self.controlPath = self.Path + self.VVeAy6
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVtGSd:
   self.packageExt  = ".deb"
   self.VValS2  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VValS2  = "#11001020"
  FFOh1m(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFiTXq(self["keyRed"] , "Create")
  FFiTXq(self["keyGreen"] , "Post Install")
  FFiTXq(self["keyYellow"], "Installation Path")
  FFiTXq(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV0jYB  ,
   "green"   : self.VVsWQy ,
   "yellow"  : self.VVm7s6  ,
   "blue"   : self.VVGXOu  ,
   "cancel"  : self.VVW3c8
  }, -1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFsHsH(self)
  if self.VValS2:
   FFZM4C(self["myBody"], self.VValS2)
   FFZM4C(self["myLabel"], self.VValS2)
  self.VVNZnJ(True)
  self.VVatMN(True)
 def VVatMN(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVA1Ob()
  if isFirstTime:
   if   package.startswith(self.VVShk2) : self.VVaPiN = VVUMIB + self.VVw2Ty + "/"
   elif package.startswith(self.VVgPAo) : self.VVaPiN = VV8tIu + self.VVw2Ty + "/"
   else            : self.VVaPiN = self.Path
  if self.VVMjO5 : myColor = VVXz72
  else    : myColor = VVDIbD
  txt  = ""
  txt += "Source Path\t: %s\n" % FFj5YA(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFj5YA(self.VVaPiN, VVNUk6)
  if self.VVzU2O : txt += "Package File\t: %s\n" % FFj5YA(self.VVzU2O, VVOEUE)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFj5YA("Check Control File fields : %s" % errTxt, VVfzKO)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFj5YA("Restart GUI", VVXz72)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFj5YA("Reboot Device", VVXz72)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFj5YA("Post Install", VVTVTj), act)
  if not errTxt and VVfzKO in controlInfo:
   txt += "Warning\t: %s\n" % FFj5YA("Errors in control file may affect the result package.", VVfzKO)
  txt += "\nControl File\t: %s\n" % FFj5YA(self.controlFile, VVOEUE)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVsWQy(self):
  if self["keyGreen"].getVisible():
   VVGtpd = []
   VVGtpd.append(("No Action"    , "noAction"  ))
   VVGtpd.append(("Restart GUI"    , "VVOh6Q"  ))
   VVGtpd.append(("Reboot Device"   , "rebootDev"  ))
   FFINMf(self, self.VVHpxS, title="Package Installation Option (after completing installation)", VVGtpd=VVGtpd)
 def VVHpxS(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVOh6Q"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVNZnJ(False)
   self.VVatMN()
 def VVm7s6(self):
  rootPath = FFj5YA("/%s/" % self.VVw2Ty, VVMCs3)
  VVGtpd = []
  VVGtpd.append(("Current Path"        , "toCurrent"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Extension Path"       , "toExtensions" ))
  VVGtpd.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVGtpd.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFINMf(self, self.VVs4WD, title="Installation Path", VVGtpd=VVGtpd)
 def VVs4WD(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVdPnq(FFImxj(self.Path, True))
   elif item == "toExtensions"  : self.VVdPnq(VVUMIB)
   elif item == "toSystemPlugins" : self.VVdPnq(VV8tIu)
   elif item == "toRootPath"  : self.VVdPnq("/")
   elif item == "toRoot"   : self.VVdPnq("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVppUg, BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=VVFuxe))
 def VVppUg(self, path):
  if len(path) > 0:
   self.VVdPnq(path)
 def VVdPnq(self, parent, withPackageName=True):
  if withPackageName : self.VVaPiN = parent + self.VVw2Ty + "/"
  else    : self.VVaPiN = "/"
  mode = self.VV9pun()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVjf0g(mode), self.controlFile))
  self.VVatMN()
 def VVGXOu(self):
  if fileExists(self.controlFile):
   lines = FF8eQ2(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF8cVc(self, self.VVvdz5, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFoFqK(self, "Version not found or incorrectly set !")
  else:
   FFE0MG(self, self.controlFile)
 def VVvdz5(self, VVOd8Z):
  if VVOd8Z:
   version, color = self.VVG425(VVOd8Z, False)
   if color == VVFiA5:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVOd8Z, self.controlFile))
    self.VVatMN()
   else:
    FFoFqK(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVW3c8(self):
  if self.newControlPath:
   if self.VVMjO5:
    self.VV2gGv()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFj5YA(self.newControlPath, VVOEUE)
    txt += FFj5YA("Do you want to keep these files ?", VVNUk6)
    FFlEph(self, self.close, txt, callBack_No=self.VV2gGv, title="Create Package", VV4A3A=True)
  else:
   self.close()
 def VV2gGv(self):
  os.system(FFN2Os("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVjf0g(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVKQwT
  if package.startswith(self.VVelq7):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVelq7, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV1UAM : prefix = self.VVShk2
  elif mode == self.VVKdQH : prefix = self.VVgPAo
  return (prefix + name).lower()
 def VV9pun(self):
  if   self.VVaPiN.startswith(VVUMIB) : return self.VV1UAM
  elif self.VVaPiN.startswith(VV8tIu) : return self.VVKdQH
  else            : return self.VVKrou
 def VVNZnJ(self, isFirstTime):
  self.VVw2Ty   = FFYgWN(self.Path)
  self.VVw2Ty   = "_".join(self.VVw2Ty.split())
  self.VVKQwT = self.VVw2Ty.lower()
  self.VVMjO5 = self.VVKQwT == VVna0S.lower()
  if self.VVMjO5 and self.VVKQwT.endswith("ajpan"):
   self.VVKQwT += "el"
  if self.VVMjO5 : self.VVGESs = VVFuxe
  else    : self.VVGESs = CFG.packageOutputPath.getValue()
  self.VVGESs = FFoR3R(self.VVGESs)
  if not pathExists(self.controlPath):
   os.system(FFN2Os("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VV9pun()
  if fileExists(self.controlFile):
   lines = FF8eQ2(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVMjO5 : version, descripton, maintainer = VVJjPN , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVw2Ty , self.VVw2Ty
   txt = ""
   txt += "Package: %s\n"  % self.VVjf0g(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVMjO5 : t = PLUGIN_NAME
  else    : t = self.VVw2Ty
  self.VVD29t(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVD29t(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVMjO5 : self.VVD29t(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVJjPN))
  else    : self.VVD29t(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVw2Ty)
  if isFirstTime and not mode == self.VVKrou:
   self.postInstAcion = 1
  txt = self.VVLJkC(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFEJE4(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVLJkC(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFN2Os("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVD29t(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVLJkC(self, action):
  sep  = "echo '%s'\n" % VVa91R
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVA1Ob(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF8eQ2(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFj5YA(line, VVfzKO)
     elif not line.startswith(" ")    : line = FFj5YA(line, VVfzKO)
     else          : line = FFj5YA(line, VVFiA5)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVFiA5
   else   : color = VVfzKO
   descr = FFj5YA(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVfzKO
     elif line.startswith((" ", "\t")) : color = VVfzKO
     elif line.startswith("#")   : color = VVOEUE
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVG425(val, True)
      elif key == "Version"  : version, color = self.VVG425(val, False)
      elif key == "Maintainer" : maint  , color = val, VVFiA5
      elif key == "Architecture" : arch  , color = val, VVFiA5
      else:
       color = VVFiA5
      if not key == "OE" and not key.istitle():
       color = VVfzKO
     else:
      color = VVXz72
     txt += FFj5YA(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVzU2O = self.VVGESs + packageName
   self.VVnjCB = True
   errTxt = ""
  else:
   self.VVzU2O  = ""
   self.VVnjCB = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVG425(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVFiA5
  else          : return val, VVfzKO
 def VV0jYB(self):
  if not self.VVnjCB:
   FFoFqK(self, "Please fix Control File errors first.")
   return
  if self.VVtGSd: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFImxj(self.VVaPiN, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVw2Ty
  symlinkTo  = FFgJRr(self.Path)
  dataDir   = self.VVaPiN.rstrip("/")
  removePorjDir = FFN2Os("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFN2Os("rm -f '%s'" % self.VVzU2O) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFhRck()
  if self.VVtGSd:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFzUYV("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVMjO5:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVaPiN == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVeAy6)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVzU2O, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVzU2O
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVzU2O, FFYHN3(result  , VVTVTj))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVaPiN, FFYHN3(instPath, VVFiA5))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFYHN3(failed, VVfzKO))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFB1pa(self, cmd)
class CC3pKJ():
 VVlPlw  = "666"
 VVaU6c   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VVjNnM()
 def VVjNnM(self):
  VVGtpd = CC3pKJ.VVuwX4()
  if VVGtpd:
   VV3Pkd = ("Create New", self.VV5Gpa)
   self.menuInstance = FFINMf(self.SELF, self.VVQGmC, VVGtpd=VVGtpd, title=self.Title, VV3Pkd=VV3Pkd, VVOvZt=True, VVghW2="#22222233", VVlnMM="#22222233")
  else:
   self.VV5Gpa()
 def VVQGmC(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVNSZ0(bName, bRef)
  else:
   CC3pKJ.VVcCEZ(self)
 def VV5Gpa(self, VVE2XdObj=None, item=None):
  FF8cVc(self.SELF, BF(self.VVXsFq), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVXsFq(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVNSZ0(bName, "")
   else:
    FFgjbJ(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CC3pKJ.VVcCEZ(self)
 def VVNSZ0(self, bName, bRef):
  FFKsz7(self.waitMsgSELF, BF(self.VVHjFN, bName, bRef), title="Adding Services ...")
 def VVHjFN(self, bName, bRef):
  CC3pKJ.VVIKtn(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVcCEZ(classObj):
  del classObj
 @staticmethod
 def VVIKtn(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFoFqK(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVCQ1V + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFE0MG(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC3pKJ.VVVpEV(bRef)
   bPath = VVCQ1V + bFile
  else:
   fName = CCXWrP.VVbum4(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVCQ1V + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVCQ1V + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CC3pKJ.VVvT3F(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CC3pKJ.VVvT3F(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCMEuJ.VVaKDV()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFN2Os("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CC40v5.VVaKtk(picon))
       break
  FFEuF7()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFcTZL(SELF, txt, title=title)
 @staticmethod
 def VVuwX4(mode=2, showTitle=True, prefix=""):
  VVGtpd = []
  if mode in (0, 2): VVGtpd.extend(CC3pKJ.VV3HnL(0, showTitle, prefix))
  if mode in (1, 2): VVGtpd.extend(CC3pKJ.VV3HnL(1, showTitle, prefix))
  return VVGtpd
 @staticmethod
 def VV3HnL(mode, showTitle, prefix):
  VVGtpd = []
  lst = CC3pKJ.VVfUIB(mode)
  if lst:
   if showTitle:
    VVGtpd.append(FFPPw2("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVGtpd.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVGtpd.append((item[0], item[1].toString()))
  return VVGtpd
 @staticmethod
 def VVs9Lp():
  bLise = CC3pKJ.VVfUIB(0)
  bLise.extend(CC3pKJ.VVfUIB(1))
  return bLise
 @staticmethod
 def VVfUIB(mode=0):
  bList = []
  VV0qUH = InfoBar.instance
  VViA5x = VV0qUH and VV0qUH.servicelist
  if VViA5x:
   curMode = VViA5x.mode
   CC3pKJ.VVZQc3(VViA5x, mode)
   bList.extend(VViA5x.getBouquetList() or [])
   CC3pKJ.VVZQc3(VViA5x, curMode)
  return bList
 @staticmethod
 def VVZQc3(VViA5x, mode):
  if not mode == VViA5x.mode:
   if   mode == 0: VViA5x.setModeTv()
   elif mode == 1: VViA5x.setModeRadio()
 @staticmethod
 def VVvT3F(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVVpEV(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVV0dw():
  try:
   fName = CC3pKJ.VVVpEV(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVCQ1V, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVqz5e():
  path = CC3pKJ.VVV0dw()
  if path:
   txt = FFEJE4(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVDzSY():
  return FFsmA3(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VV0taO():
  lst = []
  for b in CC3pKJ.VVs9Lp():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVCQ1V + CC3pKJ.VVVpEV(bRef)
   if fileExists(path):
    lines = FF8eQ2(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VV0wiU(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVS9za(SID="", stripRType=False):
  if SID : patt = CC3pKJ.VV0wiU(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC3pKJ.VVs9Lp():
   for service in FFsmA3(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VV2RZF():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CC3pKJ.VVs9Lp():
   for service in FFsmA3(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VV3Due(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VV0YoR(pathLst, rType=""):
  refLst = CC3pKJ.VVS9za(CC3pKJ.VVlPlw, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC3pKJ.VV3Due(rType, CC3pKJ.VVlPlw, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CC1TwY(Screen):
 VVk7Gc   = 0
 VVW12q  = 1
 VVtIla  = 2
 VVY6lA = 3
 VV7Jlu    = 20
 VVSkK3  = None
 VVbA15   = 0
 VVLvb9   = 1
 VVnfdm   = 2
 def __init__(self, session, VViJ7i="/", mode=VVk7Gc, VVZmYA="Select", width=1400, height=920, VVdez8=30, VVghW2="#22001111", VVlnMM="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFkttW(VVUJSe, width, height, 30, 40, 20, VVghW2, VVlnMM, VVdez8, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVghW2   = VVghW2
  self.VVlnMM    = VVlnMM
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFOh1m(self)
  FFiTXq(self["keyRed"] , "Exit")
  FFiTXq(self["keyYellow"], "More Options")
  FFiTXq(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVZmYA = VVZmYA
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  CC1TwY.VVSkK3 = self
  VVP0VB = None
  if patternMode:
   self.mode = self.VVY6lA
   if   patternMode == "srt"   : VVP0VB = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet": VVP0VB = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster": VVP0VB = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "movies": VVP0VB = ("^.*\.(%s)$" % "|".join(CC8VbN.VVB1kx()["mov"]), IGNORECASE)
   else      : VVP0VB = None
  if self.mode in (self.VVtIla, self.VVY6lA):
   FFiTXq(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVJsVJ, self.VViJ7i = True , FFImxj(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVJsVJ, self.VViJ7i = True , CC1TwY.VV58mN(self)[1] or "/"
  elif self.mode == self.VVk7Gc  : VVJsVJ, self.VViJ7i = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVtIla : VVJsVJ, self.VViJ7i = False, VViJ7i
  elif self.mode == self.VVY6lA : VVJsVJ, self.VViJ7i = True , VViJ7i
  else           : VVJsVJ, self.VViJ7i = True , VViJ7i
  self.VViJ7i = FFoR3R(self.VViJ7i)
  self["myMenu"] = CC8VbN(  directory   = None
         , VVP0VB = VVP0VB
         , VVJsVJ   = VVJsVJ
         , VVFVAN = True
         , VVOJaW = True
         , VV0ne0   = self.skinParam["width"]
         , VVdez8   = self.skinParam["bodyFontSize"]
         , VVuWSd  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVyihG    ,
   "red" : self.VVkBKz   ,
   "green" : self.VVOyIu,
   "yellow": self.VVckvy  ,
   "blue" : self.VVOMpX ,
   "menu" : self.VVqdak  ,
   "info" : self.VVxoMN  ,
   "cancel": self.VVuFR3    ,
   "pageUp": self.VVbFfE   ,
   "chanUp": self.VVbFfE
  }, -1)
  FFWx6Q(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVdTSX)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  CC1TwY.VVSkK3 = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVdTSX)
  FFe04V(self)
  FFeJ1R(self["myMenu"], bg=self.cursorBG)
  FFsHsH(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVtIla, self.VVY6lA):
   FFiTXq(self["keyGreen"], self.VVZmYA)
   self.VVCvwo(self.VVLvb9)
  self.VVdTSX()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVv8RO(self.VViJ7i) > self.bigDirSize: FFKsz7(self, self.VVFBAb, title="Changing directory...")
  else              : self.VVFBAb()
 def VVFBAb(self):
  if self.jumpToFile : self.VVPlO6(self.jumpToFile)
  elif self.gotoMovie : self.VVqlPm(chDir=False)
  else    : self["myMenu"].VVhCMp(self.VViJ7i)
 def VVvFsV(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV6CJU(self):
  FFKsz7(self, self.VVEHId, title="Refreshing list ...")
 def VVEHId(self):
  isSel = self["myMenu"].VVxtXf()
  if not isSel:
   self.VV3KmJ(False)
  FFMq43()
 def VVv8RO(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVyihG(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVJhny()
   if ok : self["keyBlue"].setText(self.VV1Muo())
   else : FFgjbJ(self, "Cannot select item", 500)
  elif self["myMenu"].VVts9E(): self.VVQmFi()
  else       : self.VVUOMY()
 def VVbFfE(self):
  if self.multiSelectState:
   FFgjbJ(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVpdTr():
    self.VVQmFi()
 def VVQmFi(self, isDirUp=False):
  if self["myMenu"].VVts9E():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVEjQM(self.VVE2Xd())
   if self.VVv8RO(path) > self.bigDirSize : FFKsz7(self, self.VVcUcA, title="Changing directory...")
   else           : self.VVcUcA()
 def VVcUcA(self):
  self["myMenu"].descent()
  self.VVdTSX()
 def VVuFR3(self):
  if   self.multiSelectState     : self.VV3KmJ(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVkBKz()
  else          : self.VVbFfE()
 def VVkBKz(self):
  if not FFmmGR(self):
   self.close("")
 def VVOyIu(self):
  path = self.VVEjQM(self.VVE2Xd())
  if self.mode == self.VVtIla:
   self.close(path)
  elif self.mode == self.VVY6lA:
   if os.path.isfile(path) : self.close(path)
   else     : FFgjbJ(self, "Cannot access this file", 1000)
 def VVxoMN(self):
  FFKsz7(self, self.VVV81q, title="Calculating size ...")
 def VVV81q(self):
  path = self.VVEjQM(self.VVE2Xd())
  param = self.VV9h8D(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFfoZ6("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC1TwY.VVF4gB(path)
     freeSize = CC1TwY.VV66fB(path)
     size = totSize - freeSize
     totSize  = CC1TwY.VVBRyA(totSize)
     freeSize = CC1TwY.VVBRyA(freeSize)
    else:
     size = FFe9uq(path)
   usedSize = CC1TwY.VVBRyA(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFj5YA(pathTxt, VVXz72) + "\n"
   if slBroken : fileTime = self.VVlGQE(path)
   else  : fileTime = self.VVP021(path)
   def VVAqUp(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVAqUp("Path"    , pathTxt)
   txt += VVAqUp("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVAqUp("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVAqUp("Total Size"   , "%s" % totSize)
    txt += VVAqUp("Used Size"   , "%s" % usedSize)
    txt += VVAqUp("Free Size"   , "%s" % freeSize)
   else:
    txt += VVAqUp("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVAqUp("Owner"    , owner)
   txt += VVAqUp("Group"    , group)
   txt += VVAqUp("Perm. (User)"  , permUser)
   txt += VVAqUp("Perm. (Group)"  , permGroup)
   txt += VVAqUp("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVAqUp("Perm. (Ext.)" , permExtra)
   txt += VVAqUp("iNode"    , iNode)
   txt += VVAqUp("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVa91R, VVa91R)
    txt += hLinkedFiles
   txt += self.VVoIJT(path)
  else:
   FFoFqK(self, "Cannot access information !")
  if len(txt) > 0:
   FFcTZL(self, txt)
 def VV9h8D(self, path):
  path = path.strip()
  path = FFgJRr(path)
  result = FFfoZ6("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVE7yo(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVE7yo(perm, 1, 4)
   permGroup = VVE7yo(perm, 4, 7)
   permOther = VVE7yo(perm, 7, 10)
   permExtra = VVE7yo(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFg1NP("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVoIJT(self, path):
  txt  = ""
  res  = FFfoZ6("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFj5YA("File Attributes:", VVJsQK), txt)
  return txt
 def VVP021(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF5ivG(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF5ivG(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF5ivG(os.path.getctime(path))
  return txt
 def VVlGQE(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFfoZ6("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFfoZ6("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFfoZ6("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVEjQM(self, currentSel):
  currentDir  = self["myMenu"].VVxRjO()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVts9E():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVE2Xd(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVdTSX(self):
  path = self.VVEjQM(self.VVE2Xd())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVbEr4()
  if self.mode == self.VVk7Gc:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVY6lA:
   path = self.VVEjQM(self.VVE2Xd())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVqdak(self):
  color1 = VVAjMy
  color2 = VVMCs3
  color3 = VVM7JM
  totSel = 0
  menuW = 1000
  title = "Options"
  VVGtpd= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVhOSY()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFLQjK(totSel))
     VVGtpd.append((color1 + txt1     , "VVKJm91" ))
     VVGtpd.append((color1 + txt1 + txt2   , "VVKJm92" ))
     VVGtpd.append(VVttU7)
    VVGtpd.append(("[6] Copy"       , "copyBulk" ))
    VVGtpd.append(("[7] Move"       , "moveBulk" ))
    VVGtpd.append(("[8] %sDELETE" % VVXz72 , "VVJQGd" ))
   else:
    FFgjbJ(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVtIla, self.VVY6lA):
   VVGtpd.append(("Properties"           , "properties" ))
   VVGtpd.append(VVttU7)
   VVGtpd.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVEjQM(self.VVE2Xd())
   isEditable = self["myMenu"].VVt0O2()
   VVGtpd.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVGtpd.append(VVttU7)
     VVGtpd.append((color1 + "Archiving / Packaging", "VVcHAL_dir"))
   elif os.path.isfile(path):
    selFile = self.VVE2Xd()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVGtpd.append((color1 + "Archive ...", "VVcHAL_file"))
    isText = False
    txt = ""
    if   isArch            : VVGtpd.extend(self.VV0rY2(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVGtpd.extend(self.VVd9eR(True))
    elif selFile.endswith(".sh"):
     VVGtpd.extend(self.VVChfT(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CC1TwY.VVjjQQ(path):
     VVGtpd.append(VVttU7)
     VVGtpd.append((color2 + "View"     , "textView_def"))
     VVGtpd.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVGtpd.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVgWKp(path) == "pic":
     VVGtpd.append(VVttU7)
     VVGtpd.append((color2 + "Set as PIcon for current channel" , "VVHMZE" ))
     if FFGxuB("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVGtpd.append(VVttU7)
      VVGtpd.append((color2 + "Convert to MVI (1280 x 720 )" , "VVM9n7Hd"   ))
      VVGtpd.append((color2 + "Convert to MVI (1920 x 1080)" , "VVM9n7Fhd"   ))
    elif selFile.endswith(CC1TwY.VVZ7hb()):
     if selFile.endswith(".mvi"):
      if FFGxuB("showiframe"):
       VVGtpd.append(VVttU7)
       VVGtpd.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVGtpd.append(VVttU7)
      VVGtpd.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVGtpd.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVGtpd.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVGtpd.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVGtpd.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVGtpd.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVLzdw" ))
    if len(txt) > 0:
     VVGtpd.append(VVttU7)
     VVGtpd.append((color1 + txt, "VVUOMY"))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("[4] Create SymLink", "VVhTcQ"))
   if isEditable:
    VVGtpd.append(("[5] Rename"      , "VVPd2m" ))
    VVGtpd.append(("[6] Copy"       , "copyFileOrDir" ))
    VVGtpd.append(("[7] Move"       , "moveFileOrDir" ))
    VVGtpd.append(("[8] %sDELETE" % VVXz72 , "VVTv1d" ))
    if fileExists(path):
     VVGtpd.append(VVttU7)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVGtpd.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVGtpd.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVGtpd.append((chmodTxt + "777)", "chmod777"))
   VVGtpd.append(VVttU7)
   VVGtpd.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVGtpd.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC1TwY.VV58mN(self)
   if fPath:
    VVGtpd.append(VVttU7)
    VVGtpd.append((color2 + "Go to Current Movie Dir", "VVqlPm"))
  FFINMf(self, self.VVD3Xb, width=menuW, height=1050, title=title, VVGtpd=VVGtpd, rcuSearch=False, VVghW2="#00101020", VVlnMM="#00101A2A")
 def VVD3Xb(self, item=None):
  if item is not None:
   path = self.VVEjQM(self.VVE2Xd())
   selFile = self.VVE2Xd()
   if   item == "VVKJm91"    : self.VVKJm9(False)
   if   item == "VVKJm92"    : self.VVKJm9(True)
   elif item == "copyBulk"     : self.VVKKpc(False)
   elif item == "moveBulk"     : self.VVKKpc(True)
   elif item == "VVJQGd"    : self.VVJQGd()
   elif item == "properties"    : self.VVxoMN()
   elif item == "VVcHAL_dir" : self.VVcHAL(path, True)
   elif item == "VVcHAL_file" : self.VVcHAL(path, False)
   elif item == "VVHst8"  : self.VVHst8(path)
   elif item == "VVbhmG"  : self.VVbhmG(path)
   elif item.startswith("extract_")  : self.VVru5v(path, selFile, item)
   elif item.startswith("script_")   : self.VVD77R(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVS5qj(path, selFile, item)
   elif item.startswith("textView_def") : FFv9qK(self, path)
   elif item.startswith("textView_enc") : self.VVn37n(path)
   elif item.startswith("text_Edit")  : FFKsz7(self, BF(CCkPUj, self, path), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVlb8Z(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVlb8Z(path, "Save as Other Encoding", False)
   elif item.startswith("VVLzdw") : self.VVLzdw(path)
   elif item == "viewAsBootlogo"   : self.VVwg5X(path, True)
   elif item == "addMovieToBouquet"  : self.VVzmrO(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVzmrO(path, True)
   elif item == "playWith"     : self.VVxEVD(path)
   elif item == "VVHMZE" : self.VVHMZE(path)
   elif item == "VVM9n7Hd"   : FFKsz7(self, BF(self.VVM9n7, path, False))
   elif item == "VVM9n7Fhd"   : FFKsz7(self, BF(self.VVM9n7, path, True))
   elif item == "VVhTcQ"   : self.VVhTcQ(path, selFile)
   elif item == "VVPd2m"   : self.VVPd2m(path, selFile)
   elif item == "copyFileOrDir"   : self.VVf8El(path, False)
   elif item == "moveFileOrDir"   : self.VVf8El(path, True)
   elif item == "VVTv1d"   : self.VVTv1d(path, selFile)
   elif item == "chmod644"     : self.VVUbqW(path, selFile, "644")
   elif item == "chmod755"     : self.VVUbqW(path, selFile, "755")
   elif item == "chmod777"     : self.VVUbqW(path, selFile, "777")
   elif item == "createNewFile"   : self.VVuLg9(path, True)
   elif item == "createNewDir"    : self.VVuLg9(path, False)
   elif item == "VVqlPm"   : self.VVqlPm()
   elif item == "VVUOMY"    : self.VVUOMY()
 def VVUOMY(self):
  if self.mode == self.VVY6lA and not self.patternMode == "poster":
   return
  selFile = self.VVE2Xd()
  path  = self.VVEjQM(selFile)
  if os.path.isfile(path):
   VVxUb7  = []
   category = self["myMenu"].VVgWKp(path)
   if   category == "pic"      : self.VVBRmY(path)
   elif category == "txt"      : FFv9qK(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVSq4m(path, selFile)
   elif category == "scr"      : self.VVyck9(path, selFile)
   elif category == "m3u"      : self.VVWg4l(path, selFile)
   elif category in ("ipk", "deb")    : self.VVASfm(path, selFile)
   elif category in ("mov", "mus")    : self.VVwg5X(path)
   elif not CC1TwY.VVjjQQ(path) : FFv9qK(self, path)
 def VVBRmY(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVgWKp(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CC9YFX.VVqn2L(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VV47Th)
 def VV47Th(self, path):
  self.VVPlO6(path)
 def VVwg5X(self, path, asLogo=False):
  if asLogo : CCNZwT.VVrh2Q(self, path)
  else  : FFKsz7(self, BF(self.VV9CaF, self, path), title="Playing Media ...")
 def VVOMpX(self):
  if self["keyBlue"].getVisible():
   VVkGEY = self.VVcYkL()
   if VVkGEY:
    path = self.VVEjQM(self.VVE2Xd())
    enableGreenBtn = False if path in self.VVcYkL() else True
    newList = []
    for line in VVkGEY:
     newList.append((line, line))
    VVuZl0  = ("Delete"    , self.VVz4qg    )
    VVVLOF  = ("Add Current Dir"   , BF(self.VVJ3K7, path) ) if enableGreenBtn else None
    VV3Pkd = ("Move Up"     , self.VVDXtD    )
    VVDhcZ  = ("Move Down"   , self.VVvHhe    )
    self.bookmarkMenu = FFINMf(self, self.VVHVzr, width=1200, title="Bookmarks", VVGtpd=newList, minRows=10 ,VVuZl0=VVuZl0, VVVLOF=VVVLOF, VV3Pkd=VV3Pkd, VVDhcZ=VVDhcZ, VVghW2="#00000022", VVlnMM="#00000022")
 def VVz4qg(self, menuInstance=None, path=None):
  VVkGEY = self.VVcYkL()
  if VVkGEY:
   while path in VVkGEY:
    VVkGEY.remove(path)
   self.VVy0Xi(VVkGEY)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV1Oys(VVkGEY)
   self.bookmarkMenu.VVQnY4(("Add Current Dir", BF(self.VVJ3K7, path)))
  else:
   FFgjbJ(self, "Removed", 800)
  self.VVbEr4()
 def VVJ3K7(self, path, menuInstance=None, item=None):
  VVkGEY = self.VVcYkL()
  if len(VVkGEY) >= self.VV7Jlu:
   FFoFqK(SELF, "Max bookmarks reached (max=%d)." % self.VV7Jlu)
  elif not path in VVkGEY:
   newList = [path] + VVkGEY
   self.VVy0Xi(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV1Oys(newList)
    self.bookmarkMenu.VVQnY4()
   else:
    FFgjbJ(self, "Added", 800)
  self.VVbEr4()
 def VVDXtD(self, VVE2XdObj, path):
  if self.bookmarkMenu:
   VVkGEY = self.bookmarkMenu.VVUdDF(True)
   if VVkGEY:
    self.VVy0Xi(VVkGEY)
 def VVvHhe(self, VVE2XdObj, path):
  if self.bookmarkMenu:
   VVkGEY = self.bookmarkMenu.VVUdDF(False)
   if VVkGEY:
    self.VVy0Xi(VVkGEY)
 def VVHVzr(self, folder=None):
  if folder:
   folder = FFoR3R(folder)
   self["myMenu"].VVhCMp(folder)
   self["myMenu"].moveToIndex(0)
  self.VVdTSX()
 def VVcYkL(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV5YLK(self):
  return True if VVcYkL() else False
 def VVy0Xi(self, VVkGEY):
  line = ",".join(VVkGEY)
  FFSmZ2(CFG.browserBookmarks, line)
 def VVPlO6(self, path):
  if fileExists(path):
   fDir  = FFoR3R(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVhCMp(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFgjbJ(self, "Not found", 1000)
 def VVqlPm(self, chDir=True):
  fPath, fDir, fName = CC1TwY.VV58mN(self)
  self.VVPlO6(fPath)
 def VVckvy(self):
  path = self.VVEjQM(self.VVE2Xd())
  isAdd = False if path in self.VVcYkL() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVFiA5, VVlyaF, VVMCs3
  VVGtpd = []
  VVGtpd.append(("Find Files ..." , "find"))
  VVGtpd.append(("Sort ..."   , "sort"))
  VVGtpd.append(VVttU7)
  if isAdd: VVGtpd.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVGtpd.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVk7Gc:
   VVGtpd.append(VVttU7)
   if self.multiSelectState: VVGtpd.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVGtpd.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVGtpd.append(       (c3 + "Select all"    , "selAll"  ))
  FFINMf(self, BF(self.VVke8b, path), width=750, title="More Options", VVGtpd=VVGtpd, VVghW2="#00221111", VVlnMM="#00221111")
 def VVke8b(self, path, item):
  if item:
   if   item == "find"  : self.VVbTxK(path)
   elif item == "sort"  : self.VVgXNv()
   elif item == "addBM" : self.VVJ3K7(path)
   elif item == "remBM" : self.VVz4qg(None, path)
   elif item == "start" : self.VVbHMs(path)
   elif item == "multiOn" : self.VV3KmJ(True)
   elif item == "multiOff" : self.VV3KmJ(False)
   elif item == "selAll" : self.VV3KmJ(True, True)
 def VV3KmJ(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFKsz7(self, BF(self["myMenu"].VVPF2t, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVCvwo(self.VVnfdm if isOn else self.VVbA15)
 def VVCvwo(self, mode=0):
  if   mode == self.VVLvb9 : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVnfdm: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVghW2, self.VVlnMM
  FFZM4C(self["myTitle"], titBg)
  FFZM4C(self["myBar"], titBg)
  FFZM4C(self["myBody"], bodBg)
  FFZM4C(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VV1Muo()
  else     : bg, txt = BAR_BUTTONS_COLORS[3], "Bookmarks"
  FFiTXq(self["keyBlue"], txt)
  FFZM4C(self["keyBlue"], bg)
  self.VVbEr4()
 def VV1Muo(self):
  return "Selected Items = %d" % self["myMenu"].VVhOSY()
 def VVbEr4(self):
  if self.VVcYkL() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVbTxK(self, path):
  VVGtpd = []
  VVGtpd.append(("Find in Current Directory"    , "findCur"  ))
  VVGtpd.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVGtpd.append(("Find in all Storage Systems"    , "findAll"  ))
  FFINMf(self, BF(self.VVW6Mk, path), width=700, title="Find File/Pattern", VVGtpd=VVGtpd, VVOvZt=True, VVsFdc=True, VVghW2="#00221111", VVlnMM="#00221111")
 def VVW6Mk(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVoH6v(0, path, title)
   elif item == "findCurR" : self.VVoH6v(1, path, title)
   elif item == "findAll" : self.VVoH6v(2, path, title)
 def VVoH6v(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FF8cVc(self, BF(self.VVziDh, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVziDh(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFSmZ2(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFgjbJ(self, "No entery", 1500)
   elif badLst  : FFgjbJ(self, "Too many file !", 1500)
   else   : FFKsz7(self, BF(self.VVb6GJ, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVb6GJ(self, mode, path, title, filePatt):
  FFgjbJ(self)
  lst = FFCpSv(FFrpms("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CC1TwY.VVQSTE(lst)
   if err:
    FFoFqK(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVXlcT = (""     , self.VVzRbZ , [])
    VVtaAK = ("Go to File Location", self.VVVLPz  , [])
    FF4zYj(self, None, title="%s : %s" % (title, filePatt), header=header, VVkGEY=lst, VVsmwq=widths, VVdez8=26, VVXlcT=VVXlcT, VVtaAK=VVtaAK)
  else:
   FFgjbJ(self, "Not found !", 2000)
 def VVVLPz(self, VVeDC2, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVeDC2.cancel()
   self.VVPlO6(path)
  else:
   FFgjbJ(VVeDC2, "Path not found !", 1000)
 def VVzRbZ(self, VVeDC2, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFj5YA("File:"  , VVMCs3), colList[0])
  txt += "%s\n%s"  % (FFj5YA("Directory:", VVMCs3), FFoR3R(colList[1]))
  FFcTZL(VVeDC2, txt, title=title)
 def VVgXNv(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV0Tn2()
  VVGtpd = []
  VVGtpd.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVGtpd.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVGtpd.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVGtpd.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVDhcZ = ("Mix", BF(self.VVteL5, True))
  FFINMf(self, BF(self.VVLtWe, False), barText=txt, width=650, title="Sort Options", VVGtpd=VVGtpd, VVDhcZ=VVDhcZ, VVsFdc=True, VVghW2="#00221111", VVlnMM="#00221111")
 def VVteL5(self, isMix, menuInstance, item):
  self.VVLtWe(True, item)
 def VVLtWe(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV0Tn2()
   title = "Sorting ... "
   if   item == "nameAlp": FFKsz7(self, BF(self["myMenu"].VVw8Ro, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFKsz7(self, BF(self["myMenu"].VVw8Ro, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFKsz7(self, BF(self["myMenu"].VVw8Ro, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFKsz7(self, BF(self["myMenu"].VVw8Ro, typeMode , isMix, False), title=title)
 def VVbHMs(self, path):
  if not os.path.isdir(path):
   path = FFImxj(path, True)
  FFSmZ2(CFG.browserStartPath, path)
  FFgjbJ(self, "Done", 500)
 def VV4UmZ(self, selFile, VV7fsq, command):
  FFlEph(self, BF(FFB1pa, self, command, VVRBrK=self.VV6CJU), "%s\n\n%s" % (VV7fsq, selFile))
 def VV0rY2(self, path, calledFromMenu):
  destPath = self.VVsK7w(path)
  lastPart = FFYgWN(destPath)
  VVGtpd = []
  if calledFromMenu:
   VVGtpd.append(VVttU7)
   color = VVMCs3
  else:
   color = ""
  VVGtpd.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVGtpd.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVGtpd.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVGtpd.append(VVttU7)
    VVGtpd.append((color + "Convert .zip to .tar.gz"       , "VVHst8" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVGtpd.append(VVttU7)
    VVGtpd.append((color + "Convert .tar.gz to .zip"       , "VVbhmG" ))
  return VVGtpd
 def VVSq4m(self, path, selFile):
  FFINMf(self, BF(self.VVru5v, path, selFile), title="Compressed File Options", VVGtpd=self.VV0rY2(path, False))
 def VVru5v(self, path, selFile, item=None):
  if item is not None:
   parent  = FFImxj(path, False)
   destPath = self.VVsK7w(path)
   lastPart = FFYgWN(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVa91R
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFzUYV("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFzUYV("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVa91R, VVa91R)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFpXhB(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVHst8" : self.VVHst8(path)
    else       : self.VVbUGP(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVbhmG" and path.endswith(".tar.gz"):
    self.VVbhmG(path)
   elif path.endswith(".rar"):
    self.VVPn4p(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFN2Os("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV4UmZ(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV4UmZ(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFImxj(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV4UmZ(selFile, "Extract Here ?"      , cmd)
 def VVsK7w(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVbUGP(self, item, path, parent, destPath, VV7fsq):
  FFlEph(self, BF(self.VVxWMJ, item, path, parent, destPath), VV7fsq)
 def VVxWMJ(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVa91R
  cmd  = FFzUYV("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFYHN3(destPath, VVTVTj))
  cmd +=   sep
  cmd += "fi;"
  FFftHz(self, cmd, VVRBrK=self.VV6CJU)
 def VVPn4p(self, item, path, parent, destPath, VV7fsq):
  FFlEph(self, BF(self.VVr25D, item, path, parent, destPath), VV7fsq)
 def VVr25D(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFoR3R(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVa91R
  cmd  = FFzUYV("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFYHN3(destPath, VVTVTj))
  cmd +=   sep
  cmd += "fi;"
  FFftHz(self, cmd, VVRBrK=self.VV6CJU)
 def VVChfT(self, addSep=False):
  VVGtpd = []
  if addSep:
   VVGtpd.append(VVttU7)
  VVGtpd.append((VVMCs3 + "View Script File"  , "script_View"  ))
  VVGtpd.append((VVMCs3 + "Execute Script File" , "script_Execute" ))
  VVGtpd.append((VVMCs3 + "Edit"     , "script_Edit"  ))
  return VVGtpd
 def VVyck9(self, path, selFile):
  FFINMf(self, BF(self.VVD77R, path, selFile), title="Script File Options", VVGtpd=self.VVChfT())
 def VVD77R(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFv9qK(self, path)
   elif item == "script_Execute" : self.VV4UmZ(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCkPUj(self, path)
 def VVd9eR(self, addSep=False):
  VVGtpd = []
  if addSep:
   VVGtpd.append(VVttU7)
  VVGtpd.append((VVMCs3 + "Browse IPTV Channels" , "m3u_Browse" ))
  VVGtpd.append((VVMCs3 + "Edit"     , "m3u_Edit" ))
  VVGtpd.append((VVMCs3 + "View"     , "m3u_View" ))
  return VVGtpd
 def VVWg4l(self, path, selFile):
  FFINMf(self, BF(self.VVS5qj, path, selFile), title="M3U/M3U8 File Options", VVGtpd=self.VVd9eR())
 def VVS5qj(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFKsz7(self, BF(self.session.open, CCXWrP, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCkPUj(self, path)
   elif item == "m3u_View"  : FFv9qK(self, path)
 def VVn37n(self, path):
  if fileExists(path) : FFKsz7(self, BF(CCoiM6.VVHC0y, self, path, BF(self.VVIk7n, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFE0MG(self, path)
 def VVIk7n(self, path, item=None):
  if item:
   FFv9qK(self, path, encLst=item)
 def VVlb8Z(self, path, title, asUtf8):
  if fileExists(path) : FFKsz7(self, BF(CCoiM6.VVHC0y, self, path, BF(self.VVQQBR, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFE0MG(self, path)
 def VVQQBR(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVh70t(path, title, fromEnc, "UTF-8")
   else  : CCoiM6.VVHC0y(self, path,  BF(self.VVh70t, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVh70t(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFj5YA("Successful\n\n", VVTVTj)
      txt += FFj5YA("From Encoding (%s):\n" % fromEnc, VVNUk6)
      txt += "%s\n\n" % path
      txt += FFj5YA("To Encoding (%s):\n" % toEnc, VVNUk6)
      txt += "%s\n\n" % outFile
      FFcTZL(self, txt, title=title)
    except:
     FFoFqK(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFgjbJ(self, "Cannot open file", 2000)
  self.VV6CJU()
 def VVLzdw(self, path):
  title = "File Line-Break Conversion"
  FFlEph(self, BF(self.VVaH0c, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVaH0c(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFj5YA("File converted:", VVTVTj), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFOPTX(self, txt, title=title)
  else:
   FFE0MG(self, path, title=title)
 def VVUbqW(self, path, selFile, newChmod):
  FFlEph(self, BF(self.VVpo7i, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVpo7i(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVdxfj)
  result = FFfoZ6(cmd)
  if result == "Successful" : FFOPTX(self, result)
  else      : FFoFqK(self, result)
 def VVhTcQ(self, path, selFile):
  parent = FFImxj(path, False)
  self.session.openWithCallback(self.VVjBwn, BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=parent, VVZmYA="Create Symlink here"))
 def VVjBwn(self, newPath):
  if len(newPath) > 0:
   target = self.VVEjQM(self.VVE2Xd())
   target = FFgJRr(target)
   linkName = FFYgWN(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFoR3R(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFoFqK(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFlEph(self, BF(self.VVMFf2, target, link), "Create Soft Link ?\n\n%s" % txt, VV4A3A=True)
 def VVMFf2(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVdxfj)
  result = FFfoZ6(cmd)
  if result == "Successful" : FFOPTX(self, result)
  else      : FFoFqK(self, result)
 def VVPd2m(self, path, selFile):
  lastPart = FFYgWN(path)
  FF8cVc(self, BF(self.VVPhca, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVPhca(self, path, selFile, VVOd8Z):
  if VVOd8Z:
   parent = FFImxj(path, True)
   if os.path.isdir(path):
    path = FFgJRr(path)
   newName = parent + VVOd8Z
   cmd = "mv '%s' '%s' %s" % (path, newName, VVdxfj)
   if VVOd8Z:
    if selFile != VVOd8Z:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFlEph(self, BF(self.VVyqVt, cmd), message, title="Rename file?")
    else:
     FFoFqK(self, "Cannot use same name!", title="Rename")
 def VVyqVt(self, cmd):
  result = FFfoZ6(cmd)
  if "Fail" in result:
   FFoFqK(self, result)
  self.VV6CJU()
 def VVKJm9(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVbDdF, title, preserve)
      , VV00AH = BF(self.VVTp5s, title))
 def VVbDdF(self, title, preserve, VVfBS1):
  totSel = self["myMenu"].VVhOSY()
  totOk = totFail = 0
  VVfBS1.VV9WKz(totSel)
  VVfBS1.VVcdNf = ["", totSel, totOk, totFail, ""]
  VVfBS1.VVRq7B("Prepareing targz file")
  curDir = self["myMenu"].VVxRjO()
  lastPart = FFYgWN(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVfBS1 or VVfBS1.isCancelled:
      return
     if row[2][6]:
      VVfBS1.VVSxQe(1)
      name  = FFgJRr(row[0][0])
      lastPath = FFYgWN(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVfBS1:
       VVfBS1.VVcdNf = [outF, totSel, totOk, totFail, path]
       VVfBS1.VVRc8P(totOk, lastPath)
  except:
   totFail += 1
   if VVfBS1:
    VVfBS1.VVcdNf = [outF, totSel, totOk, totFail, path]
 def VVTp5s(self, title, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVcdNf
  txt  = "%s:\n%s\n\n"   % (FFj5YA("Output File", VVTVTj), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFj5YA("Failed\t: %d\n" % totFail, VVXz72)
  if not VV9pDl: txt += "%s\n%s" % (FFj5YA("\nCancelled while copying:", VVXz72), path)
  FFcTZL(self, txt, title=title)
  self.VV6CJU()
 def VVKKpc(self, isMove):
  self.session.openWithCallback(BF(self.VVrUAf, isMove), BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=self["myMenu"].VVxRjO(), VVZmYA="Move to here" if isMove else "Paste here"))
 def VVrUAf(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCEwtS, barTheme=CCEwtS.VVyaE2, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVNPmg, title, action, isMove, newPath)
       , VV00AH = BF(self.VVnfcG, title, action, isMove, newPath))
 def VVNPmg(self, title, action, isMove, newPath, VVfBS1):
  curDir = self["myMenu"].VVxRjO()
  totOk = totFail = 0
  totSel = self["myMenu"].VVhOSY()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVfBS1.VV9WKz(totSel)
  VVfBS1.VVcdNf = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVfBS1 or VVfBS1.isCancelled:
    return
   if row[2][6]:
    VVfBS1.VVSxQe(1)
    VVfBS1.VVPAO7(action, totOk, FFYgWN(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFYgWN(path)
    if os.path.isdir(path): path = FFgJRr(path)
    dest = os.path.join(newPath, lastPart)
    res = os.system(FFN2Os("%s '%s' '%s'" % (cmd, path, dest)))
    if res == 0 : totOk += 1
    else  : totFail += 1
    if VVfBS1:
     VVfBS1.VVcdNf = [totSel, totOk, totFail, path]
     VVfBS1.VVPAO7(action, totOk, FFYgWN(row[0][0]))
 def VVnfcG(self, title, action, isMove, newPath, VV9pDl, VVcdNf, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVcdNf
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFj5YA("Failed\t: %d\n" % totFail, VVXz72)
  if not VV9pDl: txt += "%s\n%s" % (FFj5YA("\nCancelled while copying:", VVXz72), path)
  FFcTZL(self, txt, title=title)
  self.VV6CJU()
 def VVJQGd(self):
  tot = self["myMenu"].VVhOSY()
  FFlEph(self, BF(FFKsz7, self, self.VVtqQo, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFLQjK(tot)), title="Delete Selection")
 def VVtqQo(self):
  path = self["myMenu"].VVxRjO()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFTyUh(os.path.join(path, row[0][0]))
  FFgjbJ(self)
  self.VV6CJU()
 def VVf8El(self, path, isMove):
  self.session.openWithCallback(BF(self.VV6CEy, isMove, path), BF(CC1TwY, mode=CC1TwY.VVtIla, VViJ7i=FFImxj(path, False), VVZmYA="Move to here" if isMove else "Paste here"))
 def VV6CEy(self, isMove, path, newPath):
  if len(newPath) > 0:
   lastPart = FFYgWN(path)
   if os.path.isdir(path): path = FFgJRr(path)
   newPath = FFoR3R(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFoFqK(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -frp"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFlEph(self, BF(FFm2b8, self, cmd, VVRBrK=self.VV6CJU), txt, VV4A3A=True)
   else:
    FFoFqK(self, "Cannot %s to same directory !" % action.lower())
 def VVTv1d(self, path, fileName):
  path = FFgJRr(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFlEph(self, BF(FFKsz7, self, BF(self.VVihme, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVihme(self, path):
  FFTyUh(path)
  FFgjbJ(self)
  self.VV6CJU()
 def VVuLg9(self, path, isFile):
  dirName = FFoR3R(os.path.dirname(path))
  if isFile : objName, VVOd8Z = "File"  , self.edited_newFile
  else  : objName, VVOd8Z = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF8cVc(self, BF(self.VVmYJj, dirName, isFile, title), title=title, defaultText=VVOd8Z, message="Enter %s Name:" % objName)
 def VVmYJj(self, dirName, isFile, title, VVOd8Z):
  if VVOd8Z:
   if isFile : self.edited_newFile = VVOd8Z
   else  : self.edited_newDir  = VVOd8Z
   path = dirName + VVOd8Z
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVdxfj)
    else  : cmd = "mkdir '%s' %s" % (path, VVdxfj)
    result = FFfoZ6(cmd)
    if "Fail" in result:
     FFoFqK(self, result)
    self.VV6CJU()
   else:
    FFoFqK(self, "Name already exists !\n\n%s" % path, title)
 def VVASfm(self, path, selFile):
  c1, c2, c3 = VVlyaF, VVMCs3, VVAjMy
  VVGtpd = []
  VVGtpd.append((c1 + "List Package Files"         , "VVduPH"     ))
  VVGtpd.append((c1 + "Package Information"         , "VVxDuc"     ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c2 + "Install Package"          , "VVhLxF_CheckVersion" ))
  VVGtpd.append((c2 + "Install Package (force reinstall)"     , "VVhLxF_ForceReinstall" ))
  VVGtpd.append((c2 + "Install Package (force overwrite)"     , "VVhLxF_ForceOverwrite" ))
  VVGtpd.append((c2 + "Install Package (force downgrade)"     , "VVhLxF_ForceDowngrade" ))
  VVGtpd.append((c2 + "Install Package (ignore failed dependencies)"  , "VVhLxF_IgnoreDepends" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c3 + "Remove Related Package"        , "VVWnlP_ExistingPackage" ))
  VVGtpd.append((c3 + "Remove Related Package (force remove)"    , "VVWnlP_ForceRemove"  ))
  VVGtpd.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVWnlP_IgnoreDepends" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Extract Files"           , "VViti1"     ))
  VVGtpd.append(("Unbuild Package"           , "VVeoG6"     ))
  FFINMf(self, BF(self.VVJdOT, path, selFile), VVGtpd=VVGtpd)
 def VVJdOT(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVduPH"      : self.VVduPH(path, selFile)
   elif item == "VVxDuc"      : self.VVxDuc(path)
   elif item == "VVhLxF_CheckVersion"  : self.VVhLxF(path, selFile, VVKyPA     )
   elif item == "VVhLxF_ForceReinstall" : self.VVhLxF(path, selFile, VVOwmy )
   elif item == "VVhLxF_ForceOverwrite" : self.VVhLxF(path, selFile, VV3VA9 )
   elif item == "VVhLxF_ForceDowngrade" : self.VVhLxF(path, selFile, VVLDPy )
   elif item == "VVhLxF_IgnoreDepends" : self.VVhLxF(path, selFile, VVqqpv )
   elif item == "VVWnlP_ExistingPackage" : self.VVWnlP(path, selFile, VVtksw     )
   elif item == "VVWnlP_ForceRemove"  : self.VVWnlP(path, selFile, VVPMkm  )
   elif item == "VVWnlP_IgnoreDepends"  : self.VVWnlP(path, selFile, VV0drk )
   elif item == "VViti1"     : self.VViti1(path, selFile)
   elif item == "VVeoG6"     : self.VVeoG6(path, selFile)
   else           : self.close()
 def VVduPH(self, path, selFile):
  if FFGxuB("ar") : cmd = "allOK='1';"
  else    : cmd  = FFhRck()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVa91R, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVa91R, VVa91R)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFS0ir(self, cmd, VVRBrK=self.VV6CJU)
 def VViti1(self, path, selFile):
  lastPart = FFYgWN(path)
  dest  = FFImxj(path, True) + selFile[:-4]
  cmd  =  FFhRck()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFN2Os("mkdir '%s'" % dest) + ";"
  cmd +=    FFN2Os("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFYHN3(dest, VVTVTj))
  cmd += "fi;"
  FFB1pa(self, cmd, VVRBrK=self.VV6CJU)
 def VVeoG6(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVSQJB = os.path.splitext(path)[0]
  else        : VVSQJB = path + "_"
  if path.endswith(".deb")   : VVeAy6 = "DEBIAN"
  else        : VVeAy6 = "CONTROL"
  cmd  = FFhRck()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVSQJB, FFFAUl())
  cmd += "  mkdir '%s';"    % VVSQJB
  cmd += "  CONTPATH='%s/%s';"  % (VVSQJB, VVeAy6)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVSQJB
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVSQJB, VVSQJB)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVSQJB
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVSQJB, VVSQJB)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVSQJB
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVSQJB
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVSQJB, FFYHN3(VVSQJB, VVTVTj))
  cmd += "fi;"
  FFB1pa(self, cmd, VVRBrK=self.VV6CJU)
 def VVxDuc(self, path):
  listCmd  = FFqitY(VV4P4m, "")
  infoCmd  = FFDHcv(VVtENU , "")
  filesCmd = FFDHcv(VVBGkK, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFo3wt(VVNUk6)
   notInst = "Package not installed."
   cmd  = FFvibQ("File Info", VVNUk6)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFvibQ("System Info", VVNUk6)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFYHN3(notInst, VVXz72))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFvibQ("Related Files", VVNUk6)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFpXhB(self, cmd)
  else:
   FFmApx(self)
 def VVhLxF(self, path, selFile, cmdOpt):
  cmd = FFDHcv(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFlEph(self, BF(FFB1pa, self, cmd, VVRBrK=FFMq43), "Install Package ?\n\n%s" % selFile)
  else:
   FFmApx(self)
 def VVWnlP(self, path, selFile, cmdOpt):
  listCmd  = FFqitY(VV4P4m, "")
  infoCmd  = FFDHcv(VVtENU, "")
  instRemCmd = FFDHcv(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFYHN3(errTxt, VVXz72))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFYHN3(cannotTxt, VVXz72))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFYHN3(tryTxt, VVXz72))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFlEph(self, BF(FFB1pa, self, cmd, VVRBrK=FFMq43), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFmApx(self)
 def VVUcS4(self, path):
  hostName = FFfoZ6("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVcHAL(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVGtpd = []
  VVGtpd.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVGtpd.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVGtpd.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVGtpd.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVGtpd.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVGtpd.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVGtpd.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVGtpd.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVGtpd.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVGtpd.append(VVttU7)
   VVGtpd.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVGtpd.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFINMf(self, BF(self.VV0FUT, path, isDir, title), VVGtpd=VVGtpd, title=title, VVghW2=c1, VVlnMM=c2)
 def VV0FUT(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVRjUw(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVRjUw(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVRjUw(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVRjUw(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVRjUw(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVRjUw(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVRjUw(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVRjUw(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVRjUw(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVRjUw(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVns9f(path, False)
   elif item == "convertDirToDeb" : self.VVns9f(path, True)
 def VVns9f(self, path, VVtGSd):
  self.session.openWithCallback(self.VV6CJU, BF(CCZlUG, path=path, VVtGSd=VVtGSd))
 def VVRjUw(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFImxj(path, True)
  lastPart = FFYgWN(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFzUYV("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFzUYV("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFzUYV("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVa91R
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFN2Os("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFYHN3(failed, VVNNKJ))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFYHN3(srcTxt, VVFiA5))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFYHN3("Output", VVTVTj))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFYHN3(failed, VVfzKO))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFS0ir(self, cmd, VVRBrK=self.VV6CJU, title=title)
 def VVzmrO(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CC1TwY.VVRH6i(FFImxj(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC3pKJ(self, self, title, BF(self.VVHPaw, pathLst))
 def VVHPaw(self, pathLst):
  return CC3pKJ.VV0YoR(pathLst)
 def VVHst8(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVMuOL, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFlEph(self, BF(FFKsz7, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFKsz7(self, fnc, title=txt)
  else:
   FFoFqK(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVMuOL(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFcTZL(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VV6CJU()
  else:
   FF9qnP(tarPath)
   FFoFqK(self, "Error while converting.", title=title)
 def VVbhmG(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVlrLK, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFlEph(self, BF(FFKsz7, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFKsz7(self, fnc, title=txt)
  else:
   FFoFqK(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVlrLK(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFcTZL(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VV6CJU()
  else:
   FF9qnP(zipPath)
   FFoFqK(self, "Error while converting.", title=title)
 def VVM9n7(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFoR3R(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFN2Os("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFN2Os("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFN2Os("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VV6CJU()
   FFOPTX(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFoFqK(self, "Cannot convert this file !", title=title)
 def VVHMZE(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCMEuJ.VVaKDV()
  if pathExists(pPath):
   if CCQNEy.VVHaRf(self, title, False, cbFnc=BF(self.VVHMZE, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVGtpd = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVGtpd.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VVB0qa
    VVDhcZ = ("Stretch", BF(self.VV63Z7, title, path, picon))
    menuInstance = FFINMf(self, BF(self.VVhgcy, title, path, picon, False), VVGtpd=VVGtpd, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VVDhcZ=VVDhcZ, barText="OK = Fit within size")
    menuInstance.VVUnla(3)
  else:
   FFoFqK(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VV63Z7(self, title, path, picon, VVE2XdObj, item):
  self.VVhgcy(title, path, picon, True, item)
  VVE2XdObj.cancel()
 def VVhgcy(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFeMt4(self, fncMode=CC40v5.VVxue5)
   except Exception as e:
    FFoFqK(self, "Image Processing error:\n\n%s" % e)
 def VVB0qa(self, menuInstance, txt, ref, ndx):
  FFFaGN(self, "_help_resize", "Picture File Resizing")
 def VVxEVD(self, path):
  FFINMf(self, BF(self.VVgMAq, path), VVGtpd=CCXWrP.VVmBnX(), width=650, title="Select Player", VVghW2="#11220000", VVlnMM="#11220000")
 def VVgMAq(self, path, rType=None):
  if rType:
   FFKsz7(self, BF(self.VV9CaF, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VV9CaF(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCi57e.VVnjtb(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VV58mN(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFoR3R(fDir), fName
  return "", "", ""
 @staticmethod
 def VVF4gB(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV66fB(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVBRyA(size, mode=0):
  txt = CC1TwY.VVNvPr(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVNvPr(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVjjQQ(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVVE2E(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFoFqK(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVZ7hb():
  tDict = CC8VbN.VVB1kx()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVRH6i(path):
  lst = []
  for ext in CC1TwY.VVZ7hb():
   lst.extend(FFKQDF(path, "*.%s" % ext))
  return sorted(lst, key=FFcCYd(FF3S0Y))
 @staticmethod
 def VVsW6t(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VV2aHq(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVQSTE(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVQXcS:
   return VVQXcS
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CC8VbN(MenuList):
 VV0UPR   = 0
 VVVt0m   = 1
 VVSH5v   = 2
 VVDW2L   = 3
 VVdULM   = 4
 VV1a7c   = 5
 VVbtdL   = 6
 VVeLlG   = 7
 VVZmxw   = "<List of Storage Devices>"
 VVusuX  = "<Parent Directory>"
 VVOlYP   = 0
 VVPhsI   = 1
 VV732V = 2
 VVy3V8  = 3
 VVSf1U   = 4
 VVc8jX   = 5
 FILE_TYPE_LINK   = 6
 VVnuhW  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVOJaW=False, directory="/", VVrvXz=True, VVJsVJ=True, VVFVAN=True, VVP0VB=None, VVrEqi=False, VVItMi=False, VV5Tbs=False, isTop=False, VVBMdr=None, VV0ne0=1000, VVdez8=30, VVuWSd=30):
  MenuList.__init__(self, list, VVOJaW, eListboxPythonMultiContent)
  self.VVrvXz  = VVrvXz
  self.VVJsVJ    = VVJsVJ
  self.VVFVAN  = VVFVAN
  self.VVP0VB  = VVP0VB
  self.VVrEqi   = VVrEqi
  self.VVItMi   = VVItMi or []
  self.VV5Tbs   = VV5Tbs or []
  self.isTop     = isTop
  self.additional_extensions = VVBMdr
  self.VV0ne0    = VV0ne0
  self.VVdez8    = VVdez8
  self.VVuWSd    = VVuWSd
  self.EXTENSIONS    = CC8VbN.VVB1kx()
  self.VVmPIJ   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFrqBY("#11ff4444")
  self.l.setFont(0, gFont(VVrbou, self.VVdez8))
  self.l.setItemHeight(self.VVuWSd)
  self.png_mem   = CC8VbN.VVX09T("mem")
  self.png_usb   = CC8VbN.VVX09T("usb")
  self.png_fil   = CC8VbN.VVX09T("fil")
  self.png_dir   = CC8VbN.VVX09T("dir")
  self.png_dirup   = CC8VbN.VVX09T("dirup")
  self.png_srv   = CC8VbN.VVX09T("srv")
  self.png_slwfil   = CC8VbN.VVX09T("slwfil")
  self.png_slbfil   = CC8VbN.VVX09T("slbfil")
  self.png_slwdir   = CC8VbN.VVX09T("slwdir")
  self.VVejQ5()
  self.VVhCMp(directory)
 @staticmethod
 def VVX09T(category):
  return LoadPixmap("%s%s.png" % (VViEnD, category), getDesktop(0))
 @staticmethod
 def VVB1kx():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVFRA5(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFgJRr(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFj5YA(" -> " , VVNUk6) + FFj5YA(os.readlink(path), VVTVTj)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVuWSd + 10, 0, self.VV0ne0, self.VVuWSd, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVpLR7: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVuWSd-4, self.VVuWSd-4, png, None, None, VVpLR7))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVuWSd-4, self.VVuWSd-4, png, None, None))
  return tableRow
 def VVgWKp(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVejQ5(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVUIEq(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV65gG(self, file):
  if os.path.realpath(file) == file:
   return self.VVUIEq(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVUIEq(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVUIEq(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVJhny(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VV81iF(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVPF2t(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VV81iF(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VV81iF(self, row, bg):
  if self.VVgwI3(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVgwI3(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVc8jX, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVSf1U:
    if   VVxGgU           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVt0O2(self):
  return self.VVgwI3(self.list[self.l.getCurrentSelectionIndex()])
 def VVhOSY(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVUdK6(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVhCMp(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVFVAN:
    self.current_mountpoint = self.VV65gG(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVFVAN:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VV5Tbs and not self.VVUdK6(path, self.VVItMi):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVFRA5(name=p.description, absolute=path, isDir=True, typ=self.VVOlYP, png=png))
    path = "/"
    if path not in self.VV5Tbs and not self.VVUdK6(path, self.VVItMi):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVFRA5(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVPhsI, png=self.png_mem))
  elif self.VVrEqi:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVmPIJ = eServiceCenter.getInstance()
   list = VVmPIJ.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVrvXz and not self.isTop:
   if directory == self.current_mountpoint and self.VVFVAN:
    self.list.append(self.VVFRA5(name=self.VVZmxw, absolute=None, isDir=True, typ=self.VV732V, png=self.png_dirup))
   elif (directory != "/") and not (self.VV5Tbs and self.VVUIEq(directory) in self.VV5Tbs):
    self.list.append(self.VVFRA5(name=self.VVusuX, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVy3V8, png=self.png_dirup))
  if self.VVrvXz:
   for x in directories:
    if not (self.VV5Tbs and self.VVUIEq(x) in self.VV5Tbs) and not self.VVUdK6(x, self.VVItMi):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVFRA5(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFgJRr(x)) else self.VVSf1U, png=png))
  if self.VVJsVJ:
   for x in files:
    if self.VVrEqi:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFj5YA(" -> " , VVNUk6) + FFj5YA(target, VVTVTj)
       else:
        png = self.png_slbfil
        name += FFj5YA(" -> " , VVNUk6) + FFj5YA(target, VVfzKO)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVgWKp(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VViEnD, category))
    if (self.VVP0VB is None) or iCompile(self.VVP0VB[0], flags=self.VVP0VB[1]).search(path):
     self.list.append(self.VVFRA5(name=name, absolute=x , isDir=False, typ=self.VVc8jX, png=png))
  if self.VVFVAN and len(self.list) == 0:
   self.list.append(self.VVFRA5(name=FFj5YA("No USB connected", VVOEUE), absolute=None, isDir=False, typ=self.VVnuhW, png=self.png_usb))
  self.l.setList(self.list)
  self.VVw8Ro()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVxRjO(self):
  return self.current_directory
 def VVts9E(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVpdTr(self):
  return self.VVYsEc() and self.VVxRjO()
 def VVYsEc(self):
  return self.list[0][1][7] in (self.VVZmxw, self.VVusuX)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVhCMp(self.getSelection()[0], self.current_directory)
 def VVXzJi(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVrIke)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVrIke)
 def VVrIke(self, action, device):
  self.VVejQ5()
  if self.current_directory is None:
   self.VVxtXf()
 def VVxtXf(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVhCMp(self.current_directory, self.VVXzJi())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VV0Tn2(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VV0UPR : nameAlpMode, nameAlpTxt = self.VVVt0m, sZA
  else       : nameAlpMode, nameAlpTxt = self.VV0UPR, sAZ
  if mode == self.VVSH5v : nameNumMode, nameNumTxt = self.VVDW2L, s90
  else       : nameNumMode, nameNumTxt = self.VVSH5v, s09
  if mode == self.VVdULM : dateMode, dateTxt = self.VV1a7c, sON
  else       : dateMode, dateTxt = self.VVdULM, sNO
  if mode == self.VVbtdL : typeMode, typeTxt = self.VVeLlG, sZA
  else       : typeMode, typeTxt = self.VVbtdL, sAZ
  if   mode in (self.VV0UPR, self.VVVt0m): txt = "Name (%s)" % (sAZ if mode == self.VV0UPR else sZA)
  elif mode in (self.VVSH5v, self.VVDW2L): txt = "Name (%s)" % (s09 if mode == self.VV0UPR else s90)
  elif mode in (self.VVdULM, self.VV1a7c): txt = "Date (%s)" % (sNO if mode == self.VVdULM else sON)
  elif mode in (self.VVbtdL, self.VVeLlG): txt = "Type (%s)" % (sAZ if mode == self.VVbtdL else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVw8Ro(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFSmZ2(CFG.browserSortMode, mode)
   FFSmZ2(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVYsEc() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VV0UPR, self.VVVt0m):
    rev = True if mode == self.VVVt0m else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVSH5v, self.VVDW2L):
    rev = True if mode == self.VVDW2L else False
    self.list = sorted(self.list[item0:], key=FFcCYd(BF(self.VViXRN, isMix, rev)), reverse=rev)
   elif mode in (self.VVdULM, self.VV1a7c):
    rev = True if mode == self.VV1a7c else False
    self.list = sorted(self.list[item0:], key=FFcCYd(BF(self.VVEsia, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVeLlG else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VViXRN(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FF3S0Y(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FF1MDp(dir2, dir1) or FF3S0Y(name1, name2)
 def VVEsia(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FF1MDp(stat2.st_ctime, stat1.st_ctime)
    else : return FF1MDp(dir2, dir1) or FF1MDp(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCPDAn(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFkttW(VVYZ9k, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVkGEY   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVYpDi(defFG, "#00FFFFFF")
  self.defBG   = self.VVYpDi(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFOh1m(self, self.Title)
  self["keyRed"].show()
  FFiTXq(self["keyGreen"] , "< > Transp.")
  FFiTXq(self["keyYellow"], "Foreground")
  FFiTXq(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVEGjq     ,
   "green"   : self.VVEGjq     ,
   "yellow"  : BF(self.VVW5LJ, False)  ,
   "blue"   : BF(self.VVW5LJ, True)  ,
   "up"   : self.VViXuA       ,
   "down"   : self.VVYUWo      ,
   "left"   : self.VVefd6      ,
   "right"   : self.VVJDDO      ,
   "last"   : BF(self.VVgcLt, -5) ,
   "next"   : BF(self.VVgcLt, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVP1sX)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFZM4C(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFZM4C(self["keyRed"] , c)
  FFZM4C(self["keyGreen"] , c)
  self.VVtv0d()
  self.VV0hHZ()
  FFmnMn(self["myColorTst"], self.defFG)
  FFZM4C(self["myColorTst"], self.defBG)
 def VVYpDi(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV0hHZ(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVVVri(0, 0)
     return
 def VVEGjq(self):
  self.close(self.defFG, self.defBG)
 def VViXuA(self): self.VVVVri(-1, 0)
 def VVYUWo(self): self.VVVVri(1, 0)
 def VVefd6(self): self.VVVVri(0, -1)
 def VVJDDO(self): self.VVVVri(0, 1)
 def VVVVri(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVLQrX()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVj47m()
 def VVtv0d(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVj47m(self):
  color = self.VVLQrX()
  if self.isBgMode: FFZM4C(self["myColorTst"], color)
  else   : FFmnMn(self["myColorTst"], color)
 def VVW5LJ(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVtv0d()
   self.VV0hHZ()
 def VVgcLt(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVVVri(0, 0)
 def VVuhnP(self):
  return hex(self.transp)[2:].zfill(2)
 def VVLQrX(self):
  return ("#%s%s" % (self.VVuhnP(), self.colors[self.curRow][self.curCol])).upper()
class CCfZ0K(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFkttW(VV2Krc, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFOh1m(self, title="%s%s%s" % (self.Title, " " * 10, FFj5YA("Change values with Up , Down, < , 0 , >", VVOEUE)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyihG      ,
   "cancel" : self.VVc1BV      ,
   "info"  : self.VVZ1xL    ,
   "red"  : self.VVUMYl  ,
   "green"  : self.VVtUVy   ,
   "yellow" : BF(self.VV6DNb, 0)  ,
   "blue"  : self.VVnL1K    ,
   "menu"  : self.VVXUwR      ,
   "left"  : self.VVefd6      ,
   "right"  : self.VVJDDO      ,
   "last"  : self.VVkegu     ,
   "next"  : self.VVTkXt     ,
   "0"   : self.VVkHH6    ,
   "up"  : self.VViXuA       ,
   "down"  : self.VVYUWo      ,
   "pageUp" : BF(self.VVnEqg, True) ,
   "pageDown" : BF(self.VVnEqg, False) ,
   "chanUp" : BF(self.VVnEqg, True) ,
   "chanDown" : BF(self.VVnEqg, False) ,
   "play"  : BF(self.VVuorl, "pause")  ,
   "pause"  : BF(self.VVuorl, "pause")  ,
   "playPause" : BF(self.VVuorl, "pause")  ,
   "stop"  : BF(self.VVuorl, "pause")  ,
   "audio"  : BF(self.VVuorl, "audio")  ,
   "subtitle" : BF(self.VVuorl, "subtitle") ,
   "rewind" : BF(self.VVuorl, "rewind" ) ,
   "forward" : BF(self.VVuorl, "forward" ) ,
   "rewindDm" : BF(self.VVuorl, "rewindDm") ,
   "forwardDm" : BF(self.VVuorl, "forwardDm")
  }, -1)
  self.VVZ644()
  self.onShown.append(self.VVP1sX)
  self.onClose.append(self.VVudeW)
 def VVZ644(self):
  lst = []
  for fil in FFKQDF(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VV9D2A:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVP1sX(self):
  self.onShown.remove(self.VVP1sX)
  FFsHsH(self)
  FFe04V(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VV2V9q()
  self.VVBoR7()
  self.VVHPyN()
 def VVudeW(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVx853(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFZM4C(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVImQS()
 def VV2V9q(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFZM4C(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVyihG(self):
  if self.settingShown:
   confItem = self.VVYTMN()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVGtpd = []
   if isinstance(lst[0], tuple):
    for item in lst: VVGtpd.append((item[1], item[0]))
   else:
    for item in lst: VVGtpd.append((item, item))
   menuInstance = FFINMf(self, self.VVp2Iu, VVGtpd=VVGtpd, width=700, title=title, VVghW2="#33221111", VVlnMM="#33110011")
   menuInstance.VVUnla(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVp2Iu(self, item=None):
  if item:
   self.VVYTMN()[self.CursorPos].setValue(item)
   self.VVImQS()
   self.VVBoR7()
   self.VVVpY9(True)
 def VVc1BV(self):
  for confItem in self.VVYTMN():
   if confItem.isChanged():
    FFlEph(self, self.VV2lZ3, "Save Changes ?", callBack_No=self.VVXfg9, title=self.Title)
    break
  else:
   if self.settingShown: self.VV2V9q()
   else    : self.close("subtExit")
 def VVXUwR(self):
  if self.settingShown: self.VVFx4N()
  else    : self.VVx853()
 def VVefd6(self): self.VV1b6z(-1)
 def VVJDDO(self): self.VV1b6z(1)
 def VV1b6z(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVdWNB()
   if pos == -1: ndx = self.VVAEXP(posVal)
   else  : ndx = self.VVhGke(posVal)
   if   ndx < 0      : FFgjbJ(self, "Not found" , 500)
   elif ndx == 0      : FFgjbJ(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFgjbJ(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVj40z(frmSec)
    if allow:
     self.VV6DNb(delay, True)
     self.VVVpY9(force=True)
    else:
     FFgjbJ(self, "Delay out of range", 800)
 def VVnEqg(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVuorl(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVkegu(self) : self.VVCv7O(5)
 def VVTkXt(self) : self.VVCv7O(6)
 def VVkHH6(self) : self.VVCv7O(-1)
 def VViXuA(self):
  if self.settingShown: self.VVCv7O(1)
  else    : self.VVnEqg(True)
 def VVYUWo(self):
  if self.settingShown: self.VVCv7O(0)
  else    : self.VVnEqg(False)
 def VVCv7O(self, direction):
  if self.settingShown:
   confItem = self.VVYTMN()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVImQS()
   self.VVBoR7()
   self.VVVpY9(True)
 def VVYTMN(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVXfg9(self):
  for confItem in self.VVYTMN(): confItem.cancel()
  self.VVImQS()
  self.VVBoR7()
  self.VV2V9q()
 def VVUMYl(self):
  if self.settingShown:
   FFlEph(self, self.VVWo4r, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVWo4r(self):
  for confItem in self.VVYTMN(): confItem.setValue(confItem.default)
  self.VV2lZ3()
  self.VVImQS()
  self.VVBoR7()
 def VV6DNb(self, delay, force=False):
  if self.settingShown or force:
   FFSmZ2(CFG.subtDelaySec, delay)
   self.VV0qJJ()
   self.VVImQS()
   self.VVBoR7()
   if self.settingShown:
    FFgjbJ(self, 'Reset to "0"', 800, isGrn=True)
 def VVtUVy(self):
  if self.settingShown:
   self.VV2lZ3()
   self.VV2V9q()
 def VV2lZ3(self):
  for confItem in self.VVYTMN(): confItem.save()
  configfile.save()
  self.VV0qJJ()
  FFgjbJ(self, "Saved", 1000, isGrn=True)
 def VVImQS(self):
  cfgLst = self.VVYTMN()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVBoR7(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFvu68(path, fnt, isRepl=1)
  else:
   fnt = VVrbou
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFkk2r(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFmnMn(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFZM4C(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFcg8p(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFkk2r(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFIyPo()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFlPq0(self, winW, winH)
 def VVZ1xL(self):
  sp = "    "
  txt  = "%s\n"   % FFj5YA("Subtitle File:", VVMCs3)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFj5YA("Subtitle Settings:", VVMCs3)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVdWNB()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FF1ZBm(frmSec1)
   time2 = FF1ZBm(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFj5YA("Timing:", VVMCs3)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FF1ZBm(durVal)
   txt += sp + "Progress\t: %s\n" % FF1ZBm(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFj5YA("Subtitle end reached.", VVNNKJ)
  FFcTZL(self, txt, title="Current Subtitle")
 def VVHPyN(self, path="", delay=0, enc=""):
  FFKsz7(self, BF(self.VVxeri, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVxeri(self, path="", delay=0, enc=""):
  FFgjbJ(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVYmio(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVImQS()
     self.VVQ3NW()
   else:
    path, delay, enc = CCfZ0K.VVX6K7(self)
    if path:
     self.VVHPyN(path=path, delay=delay, enc=enc)
    else:
     self.VVFx4N()
  except:
   pass
 def VVQ3NW(self):
  posVal, durVal = self.VVdWNB()
  if self.VVNGuH(posVal):
   return
  CCfZ0K.VVGbcj(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVVpY9)
  except:
   self.timerUpdate.callback.append(self.VVVpY9)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VViwti)
  except:
   self.timerEndText.callback.append(self.VViwti)
  FFgjbJ(self, "Subtitle started", 700, isGrn=True)
 def VVNGuH(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCfZ0K.VVvK1B(self)
   FF9qnP(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVFx4N(self):
  c1, c2, c3, c4, c5 = "", VVMCs3, VVM7JM, VVAjMy, VVNNKJ
  VVGtpd = []
  VVGtpd.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVGtpd.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVGtpd.append(VVttU7)
  VVGtpd.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVGtpd.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVGtpd.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVGtpd.append(VVttU7)
   VVGtpd.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVGtpd.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVGtpd.append(VVttU7)
   VVGtpd.append(("Help (Keys)"        , "help"  ))
  FFINMf(self, self.VVinIY, VVGtpd=VVGtpd, width=700, title='Find Subtitle ".srt" File', VVghW2="#33221111", VVlnMM="#33110011")
 def VVinIY(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVhuRK(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVhuRK(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VV0nF5, BF(CC1TwY, patternMode="srt", VViJ7i=sDir))
   elif item.startswith("sugSrt") : self.VVhuRK(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFKsz7(self, BF(CCoiM6.VVHC0y, self, self.lastSubtFile, self.VVbe29, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFgjbJ(self, "SRT File error", 1000)
   elif item == "disab":
    FF9qnP(CCfZ0K.VVvK1B(self))
    self.close("subtExit")
   elif item == "help"    : FFFaGN(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVbe29(self, item=None):
  if item:
   FFKsz7(self, BF(self.VVHPyN, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VV0nF5(self, path):
  if path:
   FFSmZ2(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVHPyN(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVhuRK(self, defSrt="", mode=0, coeff=0.25):
  FFKsz7(self, BF(self.VV1oYP, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VV1oYP(self, defSrt="", mode=0, coeff=0.25):
  FFgjbJ(self)
  if mode == 1:
   srtList = CCfZ0K.VVwUNe(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFCpSv('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFxM0r(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVLV33(srtList, coeff)
     if err:
      if self.settingShown: FFgjbJ(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVzpbP = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFoR3R(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVzpbP.append((fName, Dir))
   VVLseV  = ("Select"    , self.VV63Lu     , [])
   VVsgQj = self.VVLJ12
   VVXlcT = (""     , self.VV2ee9       , [])
   VVHUGA = (""     , BF(self.VVDf61, defSrt, False) , [])
   VVtaAK = ("Find Current File" , BF(self.VVDf61, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVsmwq=widths, VVdez8=28, VVLseV=VVLseV, VVsgQj=VVsgQj, VVXlcT=VVXlcT, VVHUGA=VVHUGA, VVtaAK=VVtaAK, lastFindConfigObj=CFG.lastFindSubtitle
     , VVghW2="#11002222", VVlnMM="#33001111", VValS2="#33001111", VVRaJ8="#11ffff00", VVKJ4V="#11445544", VVEwGL="#22222222", VVtDKG="#11002233")
  elif self.settingShown : FFgjbJ(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVLJ12(self, VVeDC2):
  VVeDC2.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VV2ee9(self, VVeDC2, title, txt, colList):
  fName, Dir = colList
  FFcTZL(VVeDC2, "%s\n\n%s%s" % (FFj5YA("Path:", VVMCs3), Dir, fName), title=title)
 def VVDf61(self, path, VVjHD0, VVeDC2, title, txt, colList):
  for ndx, row in enumerate(VVeDC2.VVmbqa()):
   if path == row[1].strip() + row[0].strip():
    VVeDC2.VVvFsV(ndx)
    break
  else:
   if VVjHD0:
    FFgjbJ(VVeDC2, "Not in list !", 1000)
 def VV63Lu(self, VVeDC2, title, txt, colList):
  VVeDC2.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVHPyN(path=path)
 def VVLV33(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8SZQ.VVmbsq(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CC8SZQ.VVZTaO(evName, "en")[0] or evName
   lst, err = CCfZ0K.VVaJxW(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVYmio(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFkas1(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF8eQ2(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVrWCS(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVoRy6(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV0qJJ()
  return subtList, ""
 def VVoRy6(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVrWCS(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV0qJJ(self):
  path = CCfZ0K.VVvK1B(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVVpY9(self, force=False):
  posVal, durVal = self.VVdWNB()
  if self.VVNGuH(posVal):
   return
  curIndex = self.VV0ar7(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VViwti()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFmnMn(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVdWNB(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCi57e.VVuXkx(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8SZQ.VVmbsq(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VV0ar7(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVAEXP(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVhGke(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VViwti(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFmnMn(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVnL1K(self):
  FFKsz7(self, self.VVo9vq, title="Loading Lines ...", clearMsg=False)
 def VVo9vq(self):
  FFgjbJ(self)
  VVzpbP = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVzpbP.append((cap, FF1ZBm(frm), str(frm), firstLine))
  if VVzpbP:
   title = "Select Current Subtitle Line"
   VVDXub  = self.VVplkB
   VVsgQj = self.VV60Vg
   VVLseV  = ("Select"   , self.VVmqDr , [title])
   VVtaAK = ("Current Line" , self.VVxaOa , [True])
   VV0q2u = ("Reset Delay" , self.VVA2sX , [])
   VVyNdP = ("New Delay"  , self.VVA9Xm   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVZq8i  = (CENTER , CENTER, CENTER , LEFT    )
   VVeDC2 = FF4zYj(self, None, title=title, header=header, VVkGEY=VVzpbP, VVZq8i=VVZq8i, VVsmwq=widths, VVdez8=28, VVDXub=VVDXub, VVsgQj=VVsgQj, VVLseV=VVLseV, VVtaAK=VVtaAK, VV0q2u=VV0q2u, VVyNdP=VVyNdP
          , VVghW2="#33002222", VVlnMM="#33001111", VValS2="#33110011", VVRaJ8="#11ffff00", VVKJ4V="#0a334455", VVEwGL="#22222222", VVtDKG="#33002233")
  else:
   FFgjbJ(self, "Cannot read lines !", 2000)
 def VVplkB(self, VVeDC2):
  self.subtLinesTable = VVeDC2
  if CFG.subtDelaySec.getValue():
   VVeDC2["keyYellow"].show()
   VVeDC2["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVeDC2["keyYellow"].hide()
  VVeDC2["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFZM4C(VVeDC2["keyBlue"], "#22222222")
  VVeDC2.VVDsgs(BF(self.VVnsIY, VVeDC2))
  self.VVxaOa(VVeDC2, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VViLBt)
  except:
   self.timerSubtLines.callback.append(self.VViLBt)
  self.timerSubtLines.start(1000, False)
 def VV60Vg(self, VVeDC2):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVeDC2.cancel()
 def VViLBt(self):
  if self.subtLinesTable:
   VVeDC2 = self.subtLinesTable
   posVal, durVal = self.VVdWNB()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV0ar7(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVeDC2.VVMpUH(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVeDC2.VVTczo(self.subtLinesTableNdx, row)
     row = VVeDC2.VVMpUH(curIndex)
     row[0] = color + row[0]
     VVeDC2.VVTczo(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVmqDr(self, VVeDC2, Title):
  delay, color, allow = self.VVfvvI(VVeDC2)
  if allow:
   self.VV60Vg(VVeDC2)
   self.VV6DNb(delay, True)
  else:
   FFgjbJ(VVeDC2, "Delay out of range", 1500)
 def VVxaOa(self, VVeDC2, VVjHD0, onlyColor=False):
  if VVeDC2:
   posVal, durVal = self.VVdWNB()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV0ar7(posVal)
    if curIndex > -1:
     VVeDC2.VVvFsV(curIndex)
    else:
     ndx = self.VVAEXP(posVal)
     if ndx > -1:
      VVeDC2.VVvFsV(ndx)
 def VVA2sX(self, VVeDC2, title, txt, colList):
  if VVeDC2["keyYellow"].getVisible():
   self.VV6DNb(0, True)
   VVeDC2["keyYellow"].hide()
   self.VVxaOa(VVeDC2, False)
 def VVnsIY(self, VVeDC2):
  delay, color, allow = self.VVfvvI(VVeDC2)
  VVeDC2["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVfvvI(self, VVeDC2):
  lineTime = float(VVeDC2.VVxY0I()[2].strip())
  return self.VVj40z(lineTime)
 def VVj40z(self, lineTime):
  posVal, durVal = self.VVdWNB()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVlyaF
   else     : allow, color = False, VVNNKJ
   delay = FF5nM6(val, -600, 600)
  return delay, color, allow
 def VVA9Xm(self, VVeDC2, title, txt, colList):
  pass
 @staticmethod
 def VVGOUe(SELF):
  path, delay, enc = CCfZ0K.VVX6K7(SELF)
  return True if path else False
 @staticmethod
 def VVX6K7(SELF):
  path, delay, enc = CCfZ0K.VVfB1N(SELF)
  if not path:
   path = CCfZ0K.VVNSKy(SELF)
  return path, delay, enc
 @staticmethod
 def VVfB1N(SELF):
  srtCfgPath = CCfZ0K.VVvK1B(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF8eQ2(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVvK1B(SELF):
  fPath, fDir, fName = CC1TwY.VV58mN(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC8SZQ.VVmbsq(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFHJhk(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVNSKy(SELF):
  bestRatio = 0
  fPath, fDir, fName = CC1TwY.VV58mN(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCfZ0K.VVwUNe(SELF)
    bLst, err = CCfZ0K.VVaJxW(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVwUNe(SELF):
  fPath, fDir, fName = CC1TwY.VV58mN(SELF)
  if pathExists(fDir):
   files = FFKQDF(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVaJxW(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVEjwj():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVGbcj(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCfZ0K.VVY159()
 @staticmethod
 def VVY159():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCGxqz(ScrollLabel):
 def __init__(self, parentSELF, text="", VV5BxZ=True):
  ScrollLabel.__init__(self, text)
  self.VV5BxZ   = VV5BxZ
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVL4r4  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVdez8    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VV38rt ,
   "green"   : self.VVnzut ,
   "yellow"  : self.VVxwzm ,
   "blue"   : self.VV0fYX ,
   "up"   : self.VVI9hL   ,
   "down"   : self.VVMncE  ,
   "left"   : self.VVI9hL   ,
   "right"   : self.VVMncE  ,
   "last"   : BF(self.VVaWNI, 0) ,
   "0"    : BF(self.VVaWNI, 1) ,
   "next"   : BF(self.VVaWNI, 2) ,
   "pageUp"  : self.VV0c8y   ,
   "chanUp"  : self.VV0c8y   ,
   "pageDown"  : self.VV4bfq   ,
   "chanDown"  : self.VV4bfq
  }, -1)
 def VVP4jT(self, isResizable=True, VVxOd9=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFmnMn(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFZM4C(self.parentSELF["keyRedTop"], "#113A5365")
  FFsHsH(self.parentSELF, True)
  self.isResizable = isResizable
  if VVxOd9:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVdez8  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFZM4C(self, color)
 def VVN2D3(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVL4r4 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVp0Nk()
 def VVI9hL(self):
  if self.VVL4r4 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVMncE(self):
  if self.VVL4r4 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV0c8y(self):
  self.setPos(0)
 def VV4bfq(self):
  self.setPos(self.VVL4r4-self.pageHeight)
 def VVfv4O(self):
  return self.VVL4r4 <= self.pageHeight or self.curPos == self.VVL4r4 - self.pageHeight
 def getText(self):
  return self.message
 def VVp0Nk(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVL4r4, 3))
   start = int((100 - vis) * self.curPos / (self.VVL4r4 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VV4T9O=VVIrLf):
  old_VVfv4O = self.VVfv4O()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVL4r4 = max(self.long_text.calculateSize().height(), self.VVdez8 * len(self.message.splitlines()))
   if self.VV5BxZ and self.VVL4r4 > self.pageHeight:
    self.scrollbar.show()
    self.VVp0Nk()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVL4r4))
   if   VV4T9O == VVOlxm: self.setPos(0)
   elif VV4T9O == VVumOn : self.VV4bfq()
   elif old_VVfv4O    : self.VV4bfq()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VV4T9O=VV4T9O)
 def appendText(self, text, VV4T9O=VVumOn):
  self.setText(self.message + str(text), VV4T9O=VV4T9O)
 def VVxwzm(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVI7sh(size)
 def VV0fYX(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVI7sh(size)
 def VVnzut(self):
  self.VVI7sh(self.VVdez8)
 def VVI7sh(self, VVdez8):
  self.long_text.setFont(gFont(self.fontFamily, VVdez8))
  self.setText(self.message, VV4T9O=VVIrLf)
  self.VVPcFJ(calledFromFontSizer=True)
 def VVaWNI(self, align):
  self.long_text.setHAlign(align)
 def VV38rt(self):
  VVGtpd = []
  VVGtpd.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Align Left" , "left" ))
  VVGtpd.append(("Align Center" , "center" ))
  VVGtpd.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVGtpd.append(VVttU7)
   VVGtpd.append((FFj5YA("Save to File", VVMCs3), "save"))
  VVGtpd.append(VVttU7)
  VVGtpd.append(("Keys (Shortcuts)", "help"))
  FFINMf(self.parentSELF, self.VVz5X1, VVGtpd=VVGtpd, title="Text Option", width=500)
 def VVz5X1(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVaWNI(0)
   elif item == "center" : self.VVaWNI(1)
   elif item == "right" : self.VVaWNI(2)
   elif item == "save"  : self.VVRtFr()
   elif item == "help"  : FFFaGN(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVRtFr(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFoR3R(expPath), self.outputFileToSave, FFbNWS())
   with open(outF, "w") as f:
    f.write(FFg0L0(self.message))
   FFOPTX(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFoFqK(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVPcFJ(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVL4r4 > 0 and self.pageHeight > 0:
   if self.VVL4r4 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVL4r4
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
