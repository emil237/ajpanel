import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV64TL   = "v8.8.6"
VVhmug    = "04-07-2023"
EASY_MODE    = 0
VVEUBz   = 0
VVhr1c   = 0
VV4i8I  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVzDIh  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVVBEw   = "AJPan"
VVYMuP  = "AUTO FIND"
VVTBvr  = "Custom"
VVmc3z    = "/media/usb/"
VVvBaW    = "/usr/share/enigma2/picon/"
VVgBUe   = "/etc/enigma2/"
VVOAlS   = VVgBUe + "settings"
VV0xaO = VVgBUe + "blacklist"
VV98fW  = None
VVArgC    = ""
VVgRwY = "Regular"
VVYr0j = "Fixed"
VVw420  = "AJP_Main"
VVwRfo = "AJP_Terminal"
VVfGl8 = "AJP_System"
VVIXst  = VVgRwY
VV7UWf    = ""
VVH8C3   = " && echo 'Successful' || echo 'Failed!'"
VVUY2M  = "Cannot continue (No Enough Memory) !"
VVX8yS  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VV0Gk9    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVl8Ad  = "utf8"
VVnek4    = ("-" * 100, )
SEP      = "-" * 80
VVTypc  = False
VVwauR  = False
VVwa4P     = 0
VVRmyC    = 1
VVmwjm    = 2
VVmcEm   = 3
VVuXUK    = 4
VVXX1u    = 5
VVhNmI = 6
VViGuf = 7
VVrgIQ  = 8
VVFK3X   = 9
VVGno7  = 10
VVe0nZ  = 11
VVOEQY = 12
VVW1QX = 13
VVHJuQ = 14
VV9kHO  = 15
VV7USz    = 16
VVImHJ   = 17
VVwl4G   = 18
VVEGmB    = 19
VVeieW    = 20
VVHLad  = 21
VVgWTf    = 22
VVfWzW   = 0
VVwuXs   = 1
VVy0vq   = 2
def FF1Pzf():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVIXst
  if VVw420 in lst and CFG.fontPathMain.getValue(): VVIXst = VVw420
  else               : VVIXst = VVgRwY
  return lst
 else:
  return [VVgRwY]
def FFrEiv(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVl8Ad)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVYMuP, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVvBaW, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVmc3z, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVIXst, choices=[(x,  x) for x in FF1Pzf()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFkoyX():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV0Inb  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVgWdT = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV0Inb  : return 0
  elif VVgWdT : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VV7zN3 = FFkoyX()
VVTjYX = VVE7tQ = VVs795 = VVT2Mp = VVEkv6 = VVwWfr = VV5Hia = VVstwU = VV1udq = VVE7n3 = VVc1MO = VV2Bne = VVrWwc = VVXSg2 = VVHksW = VViU6E = ""
def FFnAtq()  : FF81F6(FF9UqU())
def FFBNNs()  : FF81F6(FFGF4i())
def FFXxoR(tDict): FF81F6(iDumps(tDict, indent=4, sort_keys=True))
def FFwLeH(*args): FFXLaP(True, True, *args)
def FF81F6(*args) : FFXLaP(True , False , *args)
def FFvF0T(*args): FFXLaP(False, False, *args)
def FFXLaP(addSep=True, isArray=True, *args):
 if VVEUBz:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFMj2Z(fnc):
 def VVJh45(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FF81F6(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVJh45
def FFuGBP(*args):
 if VVEUBz:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFvF0T("Added to : %s" % path)
def FF5LzL(txt, isAppend=True, ignoreErr=False):
 if VVEUBz:
  tm = FFiKS1()
  err = ""
  if not ignoreErr:
   err = FFGF4i()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF81F6(err)
  FF81F6("Output Log File : %s" % fileName)
def FFGF4i():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFiKS1()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FF9UqU():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVBpND = 0
def FFiuEV():
 global VVBpND
 VVBpND = iTime()
def FFui86(txt=""):
 FF81F6(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVBpND)).rstrip("0"), txt))
VV7EsC = []
def FFgD4Y(win):
 global VV7EsC
 if not win in VV7EsC:
  VV7EsC.append(win)
def FFQbFt(*args):
 global VV7EsC
 for win in VV7EsC:
  try:
   win.close()
  except:
   pass
 VV7EsC = []
def FF5GKV(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFs8ND():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV0OnN = FFs8ND()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFlxIL()    : return PluginDescriptor(fnc=FFzWhZ, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFEc67()      : return getDescriptor(FFUkPq  , [ PluginDescriptor.WHERE_MENU   ] , PLUGIN_NAME     , descr="Main Menu")
def FFNGEF()     : return getDescriptor(FF7mmR   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFN4sy()  : return getDescriptor(FF3bRk , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFyc1D() : return getDescriptor(FFXx2e  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFOm3b()  : return getDescriptor(FFGTno  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFzUy9(): return getDescriptor(FFxXQV, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Plugin Browser"  , descr="Plugin Browser")
def FFiUgy()  : return getDescriptor(FFJMbm   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FF229k() : return getDescriptor(FFFVZu  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FF9ocj()      : return getDescriptor(FFxW1s , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFNGEF() , FFEc67() , FFlxIL() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFN4sy())
  result.append(FFyc1D())
  result.append(FFOm3b())
  result.append(FFzUy9())
  result.append(FFiUgy())
  result.append(FF229k())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF9ocj())
 return result
def FFzWhZ(reason, **kwargs):
 if reason == 0:
  CChPHM.VVqWXT()
  if "session" in kwargs:
   session = kwargs["session"]
   FF3MTZ(session)
   CCi2ew(session)
def FFUkPq(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF7mmR, PLUGIN_NAME, 45)]
 else:
  return []
def FF7mmR(session, **kwargs):
 session.open(Main_Menu)
def FF3bRk(session, **kwargs) : session.open(CCZHbk)
def FFXx2e(session, **kwargs)  : session.open(CCCW9K)
def FFGTno(session, **kwargs)  : CCP76G.VVBpiW(session)
def FFxXQV(session, **kwargs): CCG4Wp.VVgWsr(session)
def FFJMbm(session, **kwargs)   : FFF0Cd(session, reopen=True)
def FFFVZu(session, **kwargs)  : session.open(CCiDWr)
def FFxW1s(session, **kwargs):
 session.open(CCM3PM, fncMode=CCM3PM.VVyGH2)
def FFOIVI():
 FF1pZ7(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFN4sy(), FFyc1D(), FFOm3b(), FFzUy9(), FFiUgy(), FF229k()])
 FF1pZ7(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF9ocj() ])
def FF1pZ7(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FF3MTZ(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FF8rQW, session, "lok")
 hk.actions["longCancel"]= BF(FF8rQW, session, "lesc")
 hk.actions["longRed"] = BF(FF8rQW, session, "lred")
 for k in (CCzLkW.VVOvZx, CCzLkW.VVycb0, CCzLkW.VVNUoY):
  hk.actions[k] = BF(CCzLkW.VVEHrQ, session, k)
def FF8rQW(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CClCF8.VVDwZn:
    CClCF8.VVDwZn.close()
   if not CCP76G.VVOb7V:
    CCP76G.VVBpiW(session)
  except:
   pass
def FFCRXL(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFOUwv(SELF, title="", addLabel=False, addScrollLabel=False, VVGuvj=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFVLF6()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VV5Nch = eTimer()
 try: SELF.VVo0X8 = SELF.VV5Nch.timeout.connect(BF(FF8xpS, SELF))
 except: SELF.VV5Nch.callback.append(BF(FF8xpS, SELF))
 SELF.onClose.append(SELF.VV5Nch.stop)
 FF8xpS(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCtpCB(SELF)
 if VVGuvj:
  SELF["myMenu"] = MenuList(VVGuvj)
  SELF["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok" : SELF.VVTQe0 ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VV0Gk9,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFvOiZ(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFtjtH, SELF, "0"),
  "1" : BF(FFtjtH, SELF, "1"),
  "2" : BF(FFtjtH, SELF, "2"),
  "3" : BF(FFtjtH, SELF, "3"),
  "4" : BF(FFtjtH, SELF, "4"),
  "5" : BF(FFtjtH, SELF, "5"),
  "6" : BF(FFtjtH, SELF, "6"),
  "7" : BF(FFtjtH, SELF, "7"),
  "8" : BF(FFtjtH, SELF, "8"),
  "9" : BF(FFtjtH, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFDJRL, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFtjtH(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VViU6E:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VViU6E + SELF.keyPressed + VVE7tQ)
    txt = VVE7tQ + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF1lLq(SELF, txt)
def FFDJRL(SELF, tableObj, colNum, isMenu):
 FF1lLq(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFWkM4(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVn6An(i)
     else  : SELF.VVAGTP(i)
     break
 except:
  pass
def FFVLF6():
 return ("  %s" % VV7UWf)
def FFtNax(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFWkM4(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFrS08(color):
 return parseColor(color).argb()
def FFeyAJ(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFBHn2(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFBX4o(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFlTM0(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VViU6E)
 else:
  return ""
def FFCIAK(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VViU6E)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FF4aCb(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VViU6E
def FFl8Lk(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFlTM0(SEP, VVc1MO))
 else : return "echo -e '%s';" % SEP
def FFeaY5(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FF4aCb(title, color)
def FFMOVh(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFe65p(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFJVhm(fncCB):
 tCons = CC9YTZ()
 tCons.ePopen(":", BF(FFgFBv, fncCB))
def FFgFBv(fncCB, result, retval):
 fncCB()
def FF4idw(SELF, fnc, title="Processing ...", clearMsg=True):
 FF1lLq(SELF, title)
 tCons = CC9YTZ()
 tCons.ePopen(":", BF(FFA19G, SELF, fnc, clearMsg))
def FFA19G(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF1lLq(SELF)
def FFMNhK(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVUY2M
  else       : return ""
def FFkrzQ(cmd):
 txt = FFMNhK(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFGRiq(cmd):
 lines = FFkrzQ(cmd)
 if lines: return lines[0]
 else : return ""
def FFQgB2(SELF, cmd):
 lines = FFkrzQ(cmd)
 VVJpUa = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVJpUa.append((key, val))
  elif line:
   VVJpUa.append((line, ""))
 if VVJpUa:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFBxNx(SELF, None, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=28)
 else:
  FFjeoA(SELF, cmd)
def FF7Jdu(cmd):
 return os.system(FFTMeZ(cmd)) == 0
def FFbqSU(cmd):
 return os.system(FFSgeq(cmd)) == 0
def FFTMeZ(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFSgeq(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFjeoA(    SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VVJxg1=True, VVXyQm=VVwuXs, **kwargs)
def FF9aYq(  SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, **kwargs)
def FFbHAT(   SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VVeOjh=True, VVKfF6=True, VVXyQm=VVwuXs, **kwargs)
def FFSSlA(  SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VVeOjh=True, VVKfF6=True, VVXyQm=VVy0vq, **kwargs)
def FF1NOx(  SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VV2mDz=True , **kwargs)
def FFBFPP(  session, cmd, **kwargs):      session.open(CCtRvx, VVGrGW=cmd, VV2mDz=True , **kwargs)
def FFIbDL( SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VVzqJs=True   , **kwargs)
def FF0AJe( SELF, cmd, **kwargs): SELF.session.open(CCtRvx, VVGrGW=cmd, VVm3Ly=True  , **kwargs)
def FFGbNH(cmd):
 return FF7Jdu("which %s" % cmd)
def FF9QPZ():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFGRiq(cmd)
def FFOG94(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVaMYp     = 0
VVpuWY      = 1
VVNP8B   = 2
VV2EeW   = 3
VVSyHw      = 4
VVpsdf      = 5
VVhuDL     = 6
VVy8ug     = 7
VVy8Lf     = 8
VVUhs4 = 9
VVnGKI = 10
VVZvdb = 11
VVvSBf  = 12
VVK3Uz     = 13
VV3cr8  = 14
VVphKS  = 15
def FFnws9(parmNum, grepTxt):
 if   parmNum == VVaMYp  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVpuWY   : param = ["list"   , "apt list"    ]
 elif parmNum == VVNP8B: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VV2EeW: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FF9QPZ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFNCOV(parmNum, package):
 if   parmNum == VVSyHw      : param = ["info"      , "apt show"         ]
 elif parmNum == VVpsdf      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVhuDL     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVy8ug     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVy8Lf     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVUhs4 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVnGKI : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVZvdb : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVvSBf  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVK3Uz     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV3cr8  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVphKS  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF9QPZ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF6BOQ():
 result = FFGRiq("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFNCOV(VVy8Lf, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFTMeZ("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFTMeZ("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFlTM0(failed1, VVc1MO))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFlTM0(failed2, VVc1MO))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFlTM0(failed3, VVs795))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFf1mi(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFNCOV(VVy8Lf , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFTMeZ("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFlTM0(failed1, VVc1MO))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFlTM0(failed2, VVs795))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFhqv7(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CC7ZOW.VVgtEC()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF8p4l(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFhqv7(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFXpyW(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFgx6P(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFhqv7(path, maxSize=maxSize, encLst=encLst)
  if lines: FFPaL6(SELF, lines, title=title, VVXyQm=VVwuXs, width=1600, height=1000, titleFontSize=30)
  else : FF5LOj(SELF, path, title=title)
 else:
  FFJBL5(SELF, path, title)
def FF9ePp(SELF, fName, title):
 path = VVqXR1 + fName
 if fileExists(path):
  txt = FFhqv7(path)
  txt = txt.replace("#W#", VViU6E)
  txt = txt.replace("#Y#", VV2Bne)
  txt = txt.replace("#G#", VVE7tQ)
  txt = txt.replace("#C#", VVrWwc)
  txt = txt.replace("#P#", VVEkv6)
  FFPaL6(SELF, txt, title=title)
 else:
  FFJBL5(SELF, path, title)
def FFgLXS(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF78Uj(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFvBW5(parent)
 else    : return FFaYmq(parent)
def FFc02K(path):
 return os.path.basename(os.path.normpath(path))
def FF8rLT(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFgx6P(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFDvFF(path):
 path = FFaYmq(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFicDa(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFQkyh(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFOHeU(path):
 try: os.remove(path)
 except: pass
def FF5wJY(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFjcWV(path):
 return FF7Jdu("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFtbd7(path):
 return FF7Jdu("cp -f '%s' '%s.bak'" % (path, path))
def FFvBW5(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFaYmq(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFCEsN():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VV4i8I)
 paths.append(VV4i8I.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFgLXS(ba)
 for p in list:
  p = ba + p + VV4i8I
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVVBEw, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VV4i8I, VVVBEw , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVSTHA, VVqXR1 = FFCEsN()
def FFHWr6():
 def VVcjXQ(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VV1NQ8   = VVcjXQ(CFG.backupPath, CCE4DO.VVgNWJ())
 VVl0Zs   = VVcjXQ(CFG.downloadedPackagesPath, t)
 VVUqJa  = VVcjXQ(CFG.exportedTablesPath, t)
 VVUqCK  = VVcjXQ(CFG.exportedPIconsPath, t)
 VV56Qi   = VVcjXQ(CFG.packageOutputPath, t)
 global VVmc3z
 VVmc3z = FFvBW5(CFG.backupPath.getValue())
 if VV1NQ8 or VV56Qi or VVl0Zs or VVUqJa or VVUqCK or oldMovieDownloadPath:
  configfile.save()
 return VV1NQ8, VV56Qi, VVl0Zs, VVUqJa, VVUqCK, oldMovieDownloadPath
def FFFCVj(path):
 path = FFaYmq(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFVhm9(SELF, pathList, tarFileName, addTimeStamp=True):
 VVWhjq = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVWhjq.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVWhjq.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVWhjq.append(path)
 if not VVWhjq:
  FFeF28(SELF, "Files not found!")
 elif not pathExists(VVmc3z):
  FFeF28(SELF, "Path not found!\n\n%s" % VVmc3z)
 else:
  VVl3lL = FFvBW5(VVmc3z)
  tarFileName = "%s%s" % (VVl3lL, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFguCY())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVWhjq:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFlTM0(tarFileName, VV1udq))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFlTM0(failed, VV1udq))
  cmd += "fi;"
  cmd +=  sep
  FF9aYq(SELF, cmd)
def FFRBDi(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFc3Lk(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFc3Lk(SELF["keyInfo"], "info")
def FFc3Lk(barObj, fName):
 path = "%s%s%s" % (VVqXR1, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFMVuT(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFwZpN(satNum)
  return satName
def FFwZpN(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFUQ44(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFMVuT(val)
  else  : sat = FFwZpN(val)
 return sat
def FFFBpn(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFMVuT(num)
 except:
  pass
 return sat
def FFFdiF(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFwQYn(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFhH2c(info, iServiceInformation.sServiceref)
   prov = FFhH2c(info, iServiceInformation.sProvider)
   state = str(FFhH2c(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFOXrQ(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFYV5a(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFhH2c(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFbIhH(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFg7sk(refCode):
 info = FFitCM(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFU7aI(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFVTMr(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFitCM(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVlOe7 = eServiceCenter.getInstance()
  if VVlOe7:
   info = VVlOe7.info(service)
 return info
def FF5kbK(SELF, refCode, VVCqYJ=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFYV5a(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCtvHX()
  if pr.VV3U8u(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVGYvI(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFR64J(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVCqYJ:
   FF3NW3(SELF, isFromSession)
 try:
  VVZuLk = InfoBar.instance
  if VVZuLk:
   VV83rW = VVZuLk.servicelist
   if VV83rW:
    servRef = eServiceReference(refCode)
    VV83rW.saveChannel(servRef)
 except:
  pass
def FFR64J(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCtvHX()
    if pr.VV3U8u(refCode, chName, decodedUrl, iptvRef):
     pr.VVGYvI(SELF, isFromSession)
def FFOXrQ(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFjNdl(ref):
 return "FROM BOUQUET " in ref.upper()
def FFyCwy(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFoDQS(url): return FFIC9i(url) or FFLnfq(url)
def FFIC9i(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFLnfq(url): return any(x in url for x in ("/series/", "mode=series"))
def FFYV5a(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFb0uP(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFb0uP(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFhukT(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFHH9F(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFCqMm(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFncwP(txt):
 try:
  return FFHH9F(FFCqMm(txt)) == txt
 except:
  return False
def FF2oot(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFvBW5(newPath), patt))
def FF3NW3(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not FFjNdl(servPath):
   isForPlayer = True
 if iptvRef or isForPlayer: CCP76G.VVBpiW(session)
 else      : FFF0Cd(session, reopen=True)
def FFF0Cd(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFF0Cd, session), CClCF8)
  except:
   try:
    FFYd19(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFwPKf(refCode):
 tp = CCg0iP()
 if tp.VVkE0D(refCode) : return True
 else        : return False
def FFwZjD(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FF9bFs(True)
     return True
 return False
def FF9bFs(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFxqkD()
def FFxqkD():
 VVZuLk = InfoBar.instance
 if VVZuLk:
  VV83rW = VVZuLk.servicelist
  if VV83rW:
   VV83rW.setMode()
def FF7SJo(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVlOe7 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVlOe7.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FF77N5():
 VV9Tj5 = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVHhLZ = list(VV9Tj5)
 return VVHhLZ, VV9Tj5
def FFWolN():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFdn1k(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFrH35(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFfB6C():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFguCY():
 return FFfB6C().replace(" ", "_").replace("-", "").replace(":", "")
def FFZ4gz(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFiKS1():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFl4UT(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCCW9K.VVIysy(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCCW9K.VV8jRk(fName)
     phpFile = tmpDir + fName + ext
     FF7Jdu("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFYFiP(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFtCOg(num):
 return "s" if num > 1 else ""
def FFxrfM(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFpwm6(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFR4NJ(a, b):
 return (a > b) - (a < b)
def FF0T2Q(a, b):
 def VVx3ea(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVx3ea(a)
 b = VVx3ea(b)
 return (a > b) - (a < b)
def FFUUI3(mycmp):
 class CC3XRi(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CC3XRi
def FFDx6X(SELF, message, title="", VVHoAX=None):
 SELF.session.openWithCallback(VVHoAX, CCjeSO, title=title, message=message, VVtq78=True)
def FFPaL6(SELF, message, title="", VVXyQm=VVwuXs, VVHoAX=None, **kwargs):
 SELF.session.openWithCallback(VVHoAX, CCjeSO, title=title, message=message, VVXyQm=VVXyQm, **kwargs)
def FFm0q4(SELF, txt):
 SELF.session.open(CCOTJy, txt)
def FFeF28(SELF, message, title="")  : FFYd19(SELF.session, message, title)
def FFJBL5(SELF, path, title="") : FFYd19(SELF.session, "File not found !\n\n%s" % path, title)
def FF5LOj(SELF, path, title="") : FFYd19(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFDayU(SELF, title="")  : FFYd19(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFYd19(session, message, title="") : session.open(BF(CCpY0X, title=title, message=message))
def FFrwu2(SELF, VVHoAX, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVHoAX, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVHoAX, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFeF28(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFZRvh(SELF, callBack_Yes, VVrAp2, callBack_No=None, title="", VVnBJJ=False, VV6nGE=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFLfxK, callBack_Yes, callBack_No)
         , BF(CCSI3y, title=title, VVrAp2=VVrAp2, VV6nGE=VV6nGE, VVnBJJ=VVnBJJ))
def FFLfxK(callBack_Yes, callBack_No, FFZRvhed):
 if FFZRvhed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF1lLq(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFBHn2(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VV5Nch.start(timeout, True)
  except: pass
 else: FF8xpS(SELF)
def FFFSea(*kargs, **kwargs):
 FFJVhm(BF(FF1lLq, *kargs, **kwargs))
def FF8xpS(SELF):
 try:
  SELF.VV5Nch.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFfNhM(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFBxNx(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCaEfF, **kwargs))
  else   : win = SELF.session.open(BF(CCaEfF, **kwargs))
  FFgD4Y(win)
  return win
 except:
  return None
def FFSiXW(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CC0qOq, **kwargs))
 FFgD4Y(win)
 return win
def FFJ9Ko(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFUHeM(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFw3XJ(SELF, **kwargs):
 SELF.session.open(CCM3PM, **kwargs)
def FFimE3(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFlS3X(SELF[name], "#000000", 3)
  except:
   pass
def FFlS3X(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FF2oUX(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVIXst, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFMHNW(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF2oUX(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFgPni(SELF, winSize.width(), winSize.height())
def FFgPni(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFpkpy():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFbjGD(VVCppa):
 screenSize  = FFpkpy()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVCppa)
 return bodyFontSize
def FFCRJG(VVCppa, extraSpace):
 font = gFont(VVIXst, VVCppa)
 VVQSWB = fontRenderClass.getInstance().getLineHeight(font) or (VVCppa * 1.25)
 return int(VVQSWB + VVQSWB * extraSpace)
def FFhwpa(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFpkpy()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVIXst, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFCRJG(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVIXst, titleFontSize, alignLeftCenter)
 if winType == VVgWTf:
  pass
 elif winType in (VVwa4P, VVRmyC):
  if winType == VVRmyC : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVHLad:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVeieW:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVIXst, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VV7USz:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFDx6XL = b2Left2 + timeW + marginLeft
  FFDx6XW = b2Left3 - marginLeft - FFDx6XL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFDx6XL , b2Top, FFDx6XW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVImHJ:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVuXUK:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVmwjm:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVmcEm:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVIXst, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVIXst, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVGno7:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVIXst, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVwl4G:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVIXst, fontH, alignCenter)
 elif winType in (VVe0nZ, VVOEQY, VVW1QX, VVHJuQ, VV9kHO):
  if   winType == VVe0nZ  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVOEQY : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVW1QX : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVHJuQ : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVe0nZ:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVIXst, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVIXst, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVIXst, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVIXst, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVIXst, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVIXst, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVIXst, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVEGmB:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVXX1u:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VViGuf : align = alignLeftCenter
  elif winType == VVhNmI : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVFK3X:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVIXst
  if usefixedFont and winType == VVhNmI:
   fLst = FF1Pzf()
   if   VVwRfo in fLst and CFG.fontPathTerm.getValue(): fontName = VVwRfo
   elif VVYr0j in fLst         : fontName = VVYr0j
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVCppa = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVIXst, VVCppa, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVIXst, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVX8yS[i], VVIXst, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVhNmI:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVX8yS[i], VVIXst, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VViCXF = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VV64TL)
  VVGuvj = []
  if VVhr1c:
   VVGuvj.append(("-- MY TEST --", "myTest" ))
  VVGuvj.append(("File Manager"  , "fMan" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("IPTV"    , "iptv" ))
  VVGuvj.append(("Movies Browser" , "movie" ))
  VVGuvj.append(("Services/Channels", "chan" ))
  VVGuvj.append(("Bouquet Editor" , "bouq" ))
  VVGuvj.append(("PIcons"   , "picon" ))
  VVGuvj.append(("EPG"    , "epg"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Terminal"   , "term" ))
  VVGuvj.append(("SoftCam"   , "soft" ))
  VVGuvj.append(("Plugins"   , "plug" ))
  VVGuvj.append(("Backup & Restore" , "bakup" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Date/Time"  , "date" ))
  VVGuvj.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVGuvj):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVGuvj[ndx] = tuple(item)
  FFOUwv(self, title=self.Title, VVGuvj=VVGuvj)
  FFtNax(self["keyRed"] , "Exit")
  FFtNax(self["keyGreen"] , "Settings")
  FFtNax(self["keyYellow"], "Dev. Info.")
  FFtNax(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVf8Ol      ,
   "yellow": self.VVsQdm      ,
   "blue" : self.VVMiof     ,
   "info" : BF(FF4idw, self, self.VVzQwF) ,
   "text" : self.VV0a3j      ,
   "menu" : self.VVHiPR    ,
   "0"  : BF(self.VV3taY, 0)   ,
   "1"  : BF(self.VVn6jJ, "fMan")   ,
   "2"  : BF(self.VVn6jJ, "iptv")   ,
   "3"  : BF(self.VVn6jJ, "movie")   ,
   "4"  : BF(self.VVn6jJ, "chan")   ,
   "5"  : BF(self.VVn6jJ, "bouq")   ,
   "6"  : BF(self.VVn6jJ, "picon")   ,
   "7"  : BF(self.VVn6jJ, "epg")   ,
   "8"  : BF(self.VVn6jJ, "term")   ,
   "9"  : BF(self.VVn6jJ, "soft")   ,
   "last" : BF(self.VVn6jJ, "plug")   ,
   "next" : BF(self.VVn6jJ, "bakup")
  })
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
  global VVTypc, VVwauR, VV7rTR
  VVTypc = VVwauR = False
  VV7rTR = True
 def VVTQe0(self):
  self.VVn6jJ(self["myMenu"].l.getCurrentSelection()[1])
 def VVn6jJ(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VV7UWf
   VV7UWf = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVykIJ()
   elif item == "fMan"  : self.session.open(CCZHbk)
   elif item == "iptv"  : self.session.open(CCCW9K)
   elif item == "movie" : FF4idw(self, BF(CCjp5c.VVtbOC, self))
   elif item == "chan"  : self.session.open(CC1mtH)
   elif item == "bouq"  : self.session.open(CC7xD6)
   elif item == "picon" : self.VVGC55()
   elif item == "epg"  : self.session.open(CCTnwS)
   elif item == "term"  : self.session.open(CCiDWr)
   elif item == "soft"  : self.session.open(CCAhZF)
   elif item == "plug"  : self.session.open(CCyvvH)
   elif item == "bakup" : self.session.open(CCjDSw)
   elif item == "date"  : self.session.open(CCGxa6)
   elif item == "net"  : self.session.open(CCzs0y)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
  FFimE3(self)
  FFRBDi(self)
  VV1NQ8, VV56Qi, VVl0Zs, VVUqJa, VVUqCK, oldMovieDownloadPath = FFHWr6()
  if VV1NQ8 or VV56Qi or VVl0Zs or VVUqJa or VVUqCK or oldMovieDownloadPath:
   VV1pWY = lambda path, subj: "%s:\n%s\n\n" % (subj, FF4aCb(path, VVT2Mp)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV1pWY(VV1NQ8   , "Backup/Restore Path"    )
   txt += VV1pWY(VV56Qi  , "Created Package Files (IPK/DEB)" )
   txt += VV1pWY(VVl0Zs  , "Download Packages (from feeds)" )
   txt += VV1pWY(VVUqJa , "Exported Tables"     )
   txt += VV1pWY(VVUqCK , "Exported PIcons"     )
   txt += VV1pWY(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFPaL6(self, txt, title="Settings Paths")
  self.VV6fvW()
  if (EASY_MODE or VVEUBz or VVhr1c):
   FFBHn2(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF1lLq(self, "Welcome", 300)
  FFJVhm(self.VV5gdk)
 def VV5gdk(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCE4DO.VVUYTh()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FF7Jdu("rm -f /tmp/ajp_*")
  global VVTypc, VVwauR
  VVTypc = VVwauR = False
  FF5GKV("VV7rTR")
 def VV3taY(self, digit):
  self.VViCXF += str(digit)
  ln = len(self.VViCXF)
  global VVTypc
  if ln == 4:
   if self.VViCXF == "0" * ln:
    VVTypc = True
    FFBHn2(self["myTitle"], "#11805040")
   else:
    self.VViCXF = "x"
 def VV0a3j(self):
  self.VViCXF += "t"
  if self.VViCXF == "0" * 4 + "t" * 2:
   global VVwauR
   VVwauR = True
   FFBHn2(self["myTitle"], "#dd5588")
 def VVGC55(self):
  found = False
  pPath = CCnBmO.VVYQsq()
  if pathExists(pPath):
   for fName, fType in CCnBmO.VVTWV5(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCnBmO)
  else:
   VVGuvj = []
   VVGuvj.append(("PIcons Tools" , "CCnBmO" ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(CCnBmO.VV5ZML())
   VVGuvj.append(VVnek4)
   VVGuvj += CCnBmO.VVyGUy()
   FFSiXW(self, self.VV1GHS, VVGuvj=VVGuvj)
 def VV1GHS(self, item=None):
  if item:
   if   item == "CCnBmO"   : self.session.open(CCnBmO)
   elif item == "VVUVAh"  : CCnBmO.VVUVAh(self)
   elif item == "VVdSYr"  : CCnBmO.VVdSYr(self)
   elif item == "findPiconBrokenSymLinks" : CCnBmO.VVVExi(self, True)
   elif item == "FindAllBrokenSymLinks" : CCnBmO.VVVExi(self, False)
 def VVzQwF(self):
  changeLogFile = VVqXR1 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF8p4l(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF4aCb("\n%s\n%s\n%s" % (SEP, line, SEP), VVc1MO, VViU6E)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF4aCb(line, VVE7tQ, VViU6E)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFPaL6(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VV64TL, PLUGIN_DESCRIPTION), VVCppa=28, width=1600, height=1000, VVcGiE="#11000011")
 def VVHiPR(self):
  VVGuvj = []
  VVGuvj.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Keys Help"     , "hlp" ))
  FFSiXW(self, self.VVxqtd, VVGuvj=VVGuvj, width=650, title="Options")
 def VVxqtd(self, item=None):
  if item:
   if   item == "libr" : FF4idw(self, BF(self.VVwuFI))
   elif item == "hlp" : FF9ePp(self, "_help_main", "Main Page (Keys Help)")
 def VVf8Ol(self) : self.session.open(CCE4DO)
 def VVsQdm(self) : self.session.open(CCeKGl)
 def VVMiof(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVE7n3, VVT2Mp, VV2Bne, VVwWfr
  VVGuvj = []
  VVGuvj.append((c1 + "Change Title Colors"   , "title"  ))
  VVGuvj.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVGuvj.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVGuvj.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVGuvj.append((c2 + "Reset Colors"    , "resetColor" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVGuvj.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c4 + "Change System Font"    , "sysFont"  ))
  FFSiXW(self, BF(self.VVl25a, title), VVGuvj=VVGuvj, width=600, title=title)
 def VVl25a(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVW3Xy()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVuajm, tDict, item), CCx0wY, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFZRvh(self, self.VVFCxR, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVVpli(VVw420  )
   elif item == "termFont"  : self.VVVpli(VVwRfo)
   elif item == "sysFont"  : self.VVVpli(VVfGl8  )
 def VVwuFI(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVJpUa = self.VV1Iqu()
  VVdyRp = ("Install", BF(self.VV3dfV, title)    , [])
  VV1SrQ  = ("Update Sys. Packages", self.VVCxSo , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVRYg6 = (LEFT  , CENTER , LEFT  )
  VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, width=1350, VVdyRp=VVdyRp, VV1SrQ=VV1SrQ, VVSaWg="#00ffffaa", VV9SwC=1)
 def VV3dfV(self, Title, VVgAw8, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVuEPN, VVgAw8)
   pkgDict = self.VVTfBM()
   pkg = colList[0]
   if   pkg == "requests" : CCYF5X.VVXK5R(self, cbFnc=cbFnc)
   elif pkg == "Imaging" : CCzLkW.VVcpMs(self, Title, False, cbFnc=cbFnc)
   elif pkg == "ar"  : FF1NOx(self, FF6BOQ(), VVdenE=cbFnc, title=Title)
   elif pkg in pkgDict  : FF1NOx(self, FFf1mi(pkgDict[pkg], pkg, pkg.capitalize()), VVdenE=cbFnc, title=Title)
  else:
   FF1lLq(VVgAw8, "Already installed.", 700, isGrn=True)
 def VVCxSo(self, VVgAw8, title, txt, colList):
  CCyvvH.VVxWby(self)
 def VVuEPN(self, VVgAw8):
  VVJpUa = self.VV1Iqu()
  VVgAw8.VVtGmM(VVJpUa[VVgAw8.VVmG96()])
 def VV1Iqu(self):
  tDict = {}
  path = VVqXR1 + "_sup_lib"
  if fileExists(path):
   for line in FF8p4l(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VV1pWY(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF4aCb("Installed", VV1udq), txt)
   else : return (lib, FF4aCb("Not installed", VVs795), txt)
  VVJpUa = []
  VVJpUa.append(VV1pWY("requests", CCYF5X.VVXK5R(self, install=False)))
  VVJpUa.append(VV1pWY("Imaging" , CCzLkW.VVcpMs(self, "", False, install=False)))
  VVJpUa.append(VV1pWY("ar"   , FF7Jdu("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for pkg, cmd in self.VVTfBM().items(): VVJpUa.append(VV1pWY(pkg, FFGbNH(cmd)))
  VVJpUa.sort(key=lambda x: x[0].lower())
  return VVJpUa
 def VVTfBM(self):
  d = {}
  for pkg in ("xz", "zip", "p7zip", "unrar", "bzip2", "ffmpeg"):
   d[pkg] = pkg
  d["p7zip"] = "7za"
  return d
 def VV29DX(self):
  return VVmc3z + "ajpanel_colors"
 def VVW3Xy(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VV29DX()
  if fileExists(p):
   txt = FFhqv7(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVuajm(self, tDict, item, fg, bg):
  if fg:
   self.VVfqB6(item, fg)
   self.VVgHwz(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV7lal(tDict)
 def VV7lal(self, tDict):
   p = self.VV29DX()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVfqB6(self, item, fg):
  if   item == "title" : FFeyAJ(self["myTitle"], fg)
  elif item == "body"  :
   FFeyAJ(self["myMenu"], fg)
   FFeyAJ(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFeyAJ(self[item], fg)
 def VVgHwz(self, item, bg):
  if   item == "title" : FFBHn2(self["myTitle"], bg)
  elif item == "body"  :
   FFBHn2(self["myMenu"], bg)
   FFBHn2(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFBHn2(self["myBar"], bg)
 def VVFCxR(self):
  FF7Jdu("rm '%s'" % self.VV29DX())
  self.close()
 def VV6fvW(self):
  tDict = self.VVW3Xy()
  for item in ("title", "body", "cursor", "bar"):
   self.VVRaCG(tDict, item)
 def VVRaCG(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVfqB6(name, fg)
  if bg: self.VVgHwz(name, bg)
 def VVVpli(self, which):
  if   which == VVw420  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVwRfo : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVfGl8  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCa3Iq.VVCwUY(self, "Change %s Font" % title, defFnt, rest, BF(self.VVAhKM, which))
 def VVAhKM(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVw420  : FFCRXL(CFG.fontPathMain, path)
   elif which == VVwRfo: FFCRXL(CFG.fontPathTerm, path)
   elif which == VVfGl8  : FFCRXL(CFG.fontPathSys , path)
   err = Main_Menu.VVJuAG(which)
   if err          : FFeF28(self, err, title=title)
   elif which == VVw420   : self.close()
   elif which == VVwRfo  : FF1lLq(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVfGl8 and path: FF1lLq(self, "System font applied", 1500, isGrn=True)
   elif which == VVfGl8   : FFZRvh(self, BF(Main_Menu.VVzqJs, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVzqJs(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVJuAG(name):
  if   name == VVw420 : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVwRfo: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVfGl8 : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FF1Pzf()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVfGl8:
   nameLst = []
   for nm in FF1Pzf():
    if not nm in (VVw420, VVwRfo):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFrEiv(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FF1Pzf()
  else    : return "Could not add font"
 def VVykIJ(self):
  self.session.open(CC7xD6)
class CCzs0y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVmc3z, "ajpanel_network")
  c1, c2 = VV2Bne, VVE7n3
  VVGuvj = []
  VVGuvj.append((c1 + "Network Devices"     , "dev" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Network Scanner (ping)"    , "ping"))
  VVGuvj.append(("Port Scanner (scan for famous ports)" , "port"))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Check Internet Connection"  , "intr"))
  FFOUwv(self, title="Network Tools", VVGuvj=VVGuvj)
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FF4idw(self, self.VVVncK, title="Reading Devices ...")
  elif item == "ping" : FF4idw(self, self.VVPizm, title="Scanning ...")
  elif item == "port" : CCGRJR.VVv7Pq(self, self.VV9Jlc, title="Select host to scan")
  elif item == "intr" : self.session.open(CCRMph)
 def VVVncK(self, canCencel=False):
  title = "Network Devices"
  VVJpUa = self.VVSW2c()
  if VVJpUa:
   bg = "#0a223333"
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVJlHN = BF(self.VVwgBE, canCencel)
   VVrjyr  = ("Start FTP"   , self.VVsaUd    , [])
   VVpxmm = ("Entry Options"  , self.VVQmWG  , [])
   VV1SrQ = ("Scan for Devices" , self.VVAHWx , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVRYg6 = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, width=1500, height=900, VVmQwL=widths, VVCppa=28, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ
       , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVSaWg="#11ffff00", VVh96o="#11220000", VV5t00="#00333333", VVO2zv="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVgAw8.VVAGTP(ndx)
  else:
   FFZRvh(self, BF(FF4idw, self, BF(self.VVzPPk, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVwgBE, canCencel), title=title)
 def VVQmWG(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(("Change Username"   , "user"))
  VVGuvj.append(("Change Password"   , "pass"))
  VVGuvj.append(("Change Remarks"   , "rem"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Remove Selected Server" , "del"))
  FFSiXW(self, BF(self.VV3dYE, VVgAw8), VVGuvj=VVGuvj, title="Entry Options")
 def VV3dYE(self, VVgAw8, item=None):
  if item:
   if   item == "user" : self.VVxcNU("u", VVgAw8)
   elif item == "pass" : self.VVxcNU("p", VVgAw8)
   elif item == "rem" : self.VVxcNU("r", VVgAw8)
   elif item == "del" : FFZRvh(self, BF(FF4idw, self, BF(self.VV4nCo, VVgAw8), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVwgBE(self, canCencel, VVgAw8=None):
  if VVgAw8: VVgAw8.cancel()
  if canCencel : self.close()
 def VVsaUd(self, VVgAw8, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFCRXL(CFG.lastNetworkDevice, VVgAw8.VVmG96())
  self.session.openWithCallback(BF(self.VVnDav, entry, VVgAw8), CCV6sJ, entry)
 def VVnDav(self, entry, VVgAw8, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVhWOj("d", newPath, ip, u, p, path, rem)
    self.VViVFY(VVgAw8)
 def VVAHWx(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVzPPk, mainTableInst=VVgAw8), title="Scanning Network ...")
 def VVzPPk(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCGRJR.VVzSU6(CCGRJR.VVftCD)
  if err:
   FFeF28(self, err, title=title)
   return
  telLst, err = CCGRJR.VVzSU6(CCGRJR.VVGj1E)
  if err:
   FFeF28(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVam7o(p1, p2): return FF0T2Q(p1[0], p2[0])
   lst.sort(key=FFUUI3(VVam7o))
   bg = "#0a202020"
   VVJlHN = BF(self.VVwgBE, canCencel)
   VVrjyr  = ("Add to Devices" , BF(self.VVfVWO, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVRYg6 = (LEFT   , CENTER  , CENTER  )
   FFBxNx(self, None, title=title, header=header, VVWhjq=lst, VVRYg6=VVRYg6, VVmQwL=widths, width=1200, VVCppa=30, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VV9SwC=2
     , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#0a225555", VVO2zv="#11403040")
  else:
   FFeF28(self, "No devices found !", title=title)
 def VVPizm(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCGRJR.VVzSU6(-1)
  if err:
   FFeF28(self, err, title=title)
  elif lst:
   def VVam7o(p1, p2): return FF0T2Q(p1[0], p2[0])
   lst.sort(key=FFUUI3(VVam7o))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVRYg6 = (LEFT   , LEFT   )
   FFBxNx(self, None, title=title, header=header, VVWhjq=lst, VVRYg6=VVRYg6, VVmQwL=widths, width=1000, height=700, VVCppa=30
     , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#0a225555", VVO2zv="#11403040")
  else:
   FFeF28(self, "Network scanning failed !", title=title)
 def VV9Jlc(self, ip=None):
  if ip:
   FF4idw(self, BF(self.VVCwqC, ip), title="Scanning %s" % ip)
 def VVCwqC(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCGRJR.VV6ujn(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCGRJR.VVsefu(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFPaL6(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVSW2c(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFhqv7(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVam7o(p1, p2): return FF0T2Q(p1[0], p2[0])
  tLst.sort(key=FFUUI3(VVam7o))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVfVWO(self, mainTableInst, canCencel, VVgAw8, title, txt, colList):
  ip, mac, typ = VVgAw8.VVxnif(VVgAw8.VVmG96())
  if "Own" in ip:
   FF1lLq(VVgAw8, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVSW2c():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FF5wJY(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVceFe(ip, u, p, path, rem))
   if mainTableInst: self.VViVFY(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVVncK(canCencel)
   VVgAw8.cancel()
 def VVceFe(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VV4nCo(self, VVgAw8):
  num, ip, u, p, path, rem = VVgAw8.VVxnif(VVgAw8.VVmG96())
  lst = self.VVSW2c()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVceFe(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VViVFY(VVgAw8)
  else:
   VVgAw8.cancel()
 def VVxcNU(self, col, VVgAw8):
  num, ip, u, p, path, rem = VVgAw8.VVxnif(VVgAw8.VVmG96())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFrwu2(self, BF(self.VV1w9P, col, orig, VVgAw8, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VV1w9P(self, col, orig, VVgAw8, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FF1lLq(VVgAw8, "No change", 1500)
   elif not newTxt and col == "u":
    FF1lLq(VVgAw8, "No user !", 2000)
   else:
    self.VVhWOj(col, newTxt, ip, u, p, path, rem)
    self.VViVFY(VVgAw8)
 def VVhWOj(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVSW2c()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVceFe(ip1, u1, p1, path1, rem1))
 def VViVFY(self, VVgAw8, newEntry=None):
  VVJpUa = self.VVSW2c()
  if VVJpUa : VVgAw8.VVFDhD(VVJpUa, tableRefreshCB=BF(self.VVGtIS, newEntry))
  else  : VVgAw8.cancel()
 def VVGtIS(self, newEntry, VVgAw8, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVgAw8.VVYgJy()):
    if row[1:] == newEntry:
     VVgAw8.VVAGTP(ndx)
 def VVwgBE(self, canCencel, VVgAw8=None):
  if VVgAw8: VVgAw8.cancel()
  if canCencel : self.close()
class CCGRJR():
 VVftCD = 21
 VVGj1E = 23
 def __init__(self):
  self.VVWZPq()
 def VVWZPq(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVhI1q(self, ip, User, Pass, timeout=5):
  myIp = CCGRJR.VVYZTF()
  if ip != myIp:
   if CCGRJR.VVsefu(ip, CCGRJR.VVftCD):
    self.VVWZPq()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVRgFY(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVt1dV(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVFXzZ(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVt1dV()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVY5TH(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVwUip(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVCZT4(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVnLPB(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVmMYN(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVnLPB()
   if self.VVCZT4(path) : typ = "d"
   else      : typ = "b"
   self.VVCZT4(curDir)
   return typ
 def VVgVNB(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVCZT4(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVcXH3(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVIXk9(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVmYYr(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVzQFR(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVgVNB(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFOHeU(locFile)
   return "", sz, str(e)
 def VVEyJG(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVWZPq()
 @staticmethod
 def VVXV5z():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVYZTF():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVG17K():
  myIp = CCGRJR.VVYZTF()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVDZag():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFGRiq("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVh8ne(port=-1):
  lst = []
  def VV7OJR(ip):
   if port > -1: ok = CCGRJR.VVsefu(ip, port)
   else  : ok = CCGRJR.VV6ujn(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCGRJR.VVG17K()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VV7OJR, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVzSU6(port):
  myIp = CCGRJR.VVYZTF()
  myGw = CCGRJR.VVDZag()
  tDict = { myIp: CCGRJR.VVXV5z() }
  devLst, err = CCGRJR.VVh8ne(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFMNhK("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VV2Bne
    elif key == myGw: txt = " %s Gateway" % VV2Bne
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VV6ujn(ip):
  return FF7Jdu("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVsefu(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVeolD(ip="1.1.1.1", timeout=1):
  if CCGRJR.VVsefu(ip, 53, timeout):
   return True
  if CCGRJR.VV6ujn(ip):
   return True
  return FF7Jdu("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVv7Pq(SELF, okFnc, title):
  baseIp = CCGRJR.VVG17K()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFSiXW(SELF, okFnc, VVGuvj=lst, width=600, title=title, VVmEJ8="#222222", VVd8a3="#222222")
class CCV6sJ(Screen, CCGRJR):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVCppa  = self.skinParam["bodyFontSize"]
  self.VVQSWB  = self.skinParam["bodyLineH"]
  self.VVXvTn  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCw3cf.VVtvNC("fil")
  self.png_dir  = CCw3cf.VVtvNC("dir")
  self.png_dirup  = CCw3cf.VVtvNC("dirup")
  self.png_slwfil  = CCw3cf.VVtvNC("slwfil")
  self.png_slbfil  = CCw3cf.VVtvNC("slbfil")
  self.png_slwdir  = CCw3cf.VVtvNC("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCGRJR.__init__(self)
  VVGuvj = [("Item-%d" % x,) for x in range(50)]
  FFOUwv(self, title=self.Title, VVGuvj=VVGuvj)
  FFtNax(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVGuvj, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVIXst, self.VVCppa))
  self["myMenu"].l.setItemHeight(self.VVQSWB)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "red" : BF(self.VV7Dit, True) ,
   "ok" : self.VVTQe0    ,
   "cancel": self.VV7Dit    ,
   "menu" : self.VVa8yq   ,
   "info" : self.VVJzsm  ,
   "pageUp": self.VViu4W    ,
   "chanUp": self.VViu4W
  })
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV6zyz)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
  FFimE3(self)
  FFRBDi(self)
  FFBHn2(self["keyBlue"], "#11333333")
  FF4idw(self, self.VVYZZH, title="Connecting ...")
 def VVYZZH(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVhI1q(ip, u, p)
  if err:
   FFeF28(self, err, title=self.Title)
   FFtNax(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFtNax(self["keyBlue"], self.ftpIp)
   if not self.VVCZT4(path):
    path = "/"
   self.VVXGni(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVt1dV():
   self.VVEyJG()
 def VVTQe0(self):
  if self.VVjcEF():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVXGni(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VViu4W()
    else         : self.VVKQd5(os.path.join(self.curDir, name))
 def VV7Dit(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VViu4W()
 def VVjcEF(self):
  if self.VVt1dV():
   return True
  else:
   FFeF28(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVKQd5(self, path):
  cat = self.VV8mJ2(path)
  if cat in ("pic"):
   FF4idw(self, BF(self.VVN89J, path))
  elif cat in ("mov", "mus"):
   if CCCW9K.VVqEDO("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FF4idw(self, BF(CCZHbk.VVrMz7, self, url, rType=rType), title="Playing Media ...")
 def VVN89J(self, path):
  locFile, size, err = self.VVzQFR(path)
  if err: FFeF28(self, err, title="View Picture File")
  else  : CCKpZj.VVAgYH(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFOHeU))
 def VV6zyz(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCw3cf.VVjFjK else sel[0][0])
  else  : title=  VVs795 + "  No Files Found !"
  self["myTitle"].setText(title)
 def VViu4W(self):
  if self.VVjcEF():
   lastPart = FFc02K(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVXGni(parentDir, lastPart, "d")
 def VVXGni(self, Dir, moveTo="", moveToType=""):
  FF4idw(self, BF(self.VVQ8PO, Dir, moveTo, moveToType))
 def VVQ8PO(self, Dir, moveTo, moveToType):
  files, err = self.VVwUip(Dir, isLong=True)
  self.curDir = self.VVnLPB() or "/"
  self.VVMZVo(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVMZVo(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVHgKs(CCw3cf.VVjFjK, CCw3cf.VVjFjK, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVmMYN(target)
    color = VVs795 if targetState == "b" else VV1udq
    origName = name + VVc1MO + linkSep + color + " "+ target
   self.list.append(self.VVHgKs(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVHgKs(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VV8mJ2(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVqXR1, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCw3cf.VVjFjK: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVQSWB + 10, 0, self.VVXvTn, self.VVQSWB, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCaEfF.VVVu2y(0, 2, self.VVQSWB-4, self.VVQSWB-4, png))
  return tableRow
 def VV8mJ2(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCw3cf.VV81Gw().items():
    if ext in lst:
     return cat
  return ""
 def VVa8yq(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCw3cf.VVjFjK
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VV4rwu(titl, ref, chk, color=""):
   if chk: return VVGuvj.append((color + titl, ref))
   else  : return VVGuvj.append((titl, ))
  VVGuvj = []
  VV4rwu("Properties", "VVJzsm", not isTop)
  c = VV2Bne
  VVGuvj.append(VVnek4)
  VV4rwu("Download Selected File ..."    , "FFl4UTFromServer", isFile, c)
  VV4rwu("Upload a Local File to Remote Server ...", "VV5AW7" , True  , c)
  VVGuvj.append(VVnek4)
  VV4rwu("Create new directory", "VVcFmh", True)
  VV4rwu("Rename", "VVdutL", not isTop)
  VV4rwu("DELETE", "VV6kBF", not isTop, VVEkv6)
  VVGuvj.append(VVnek4)
  VV4rwu("FTP Server Information", "VVCYht", True)
  VVGuvj.append(VVnek4)
  VV4rwu("Refresh File List", "refresh", True)
  FFSiXW(self, self.VVuFXQ, VVGuvj=VVGuvj, title="Options")
 def VVuFXQ(self, item=None):
  if item:
   if   item == "VVJzsm"     : self.VVJzsm()
   elif item == "FFl4UTFromServer"   : self.FFl4UTFromServer()
   elif item == "VV5AW7"   : self.VV5AW7()
   elif item == "VVcFmh"   : self.VVcFmh()
   elif item == "VVdutL"   : self.VVdutL()
   elif item == "VV6kBF"   : self.VV6kBF()
   elif item == "VVCYht"    : self.VVCYht()
   elif item == "refresh" and self.VVjcEF(): self.VVXGni(self.curDir)
 def VVJzsm(self):
  if self.VVjcEF():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FF4aCb("Path", VV2Bne), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVgVNB(path)
    if sz > -1: txt += "Size\t: %s" % CCZHbk.VVi3go(sz)
   else:
    txt = "Nothing selected"
   FFPaL6(self, txt, title="Properties")
 def VVCYht(self):
  if self.VVjcEF():
   Sys  = self.VVRgFY() or " -"
   txt = "%s\n  %s\n\n" % (FF4aCb("System:", VV2Bne), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVY5TH() or " -"
   txt += "%s\n" % (FF4aCb("Status:", VV2Bne))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFPaL6(self, txt, title="FTP Server Information")
 def VVcFmh(self, name=""):
  if self.VVjcEF():
   title = "Add New Directory"
   FFrwu2(self, BF(self.VV7O78, title), defaultText=name, title=title, message="Enter Directory name")
 def VV7O78(self, title, name):
  if name and name.strip():
   if self.VVcXH3(name) : self.VVXGni(self.curDir, name, "d")
   else     : FFeF28(self, "Failed to create : %s" % name, title)
 def VVdutL(self):
  if self.VVjcEF():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFrwu2(self, BF(self.VVefoU, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVefoU(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVmYYr(name, newName.strip()) : self.VVXGni(self.curDir, newName, flag)
   else          : FFeF28(self, "Failed to rename to : %s" % newName, title)
 def VV6kBF(self):
  if self.VVjcEF():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFZRvh(self, BF(FF4idw, self, BF(self.VVD80Q, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVD80Q(self, name, flag):
  if self.VVIXk9(name, flag) : self.VVXGni(self.curDir)
  else         : FFeF28(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFl4UTFromServer(self):
  if self.VVjcEF():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVgVNB(remFile)
    if size == -1:
     FFeF28(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVmc3z
     self.session.openWithCallback(BF(self.VVGlAl, title, remFile, name, size), BF(CCZHbk, mode=CCZHbk.VVms2N, VVdjsL="Download here", VVYYtf=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVGlAl(self, title, remFile, name, size, locPath):
  if locPath:
   FFCRXL(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VV297q, remFile, size, locFile)
       , VVHoAX = BF(self.VVSXpJ, remFile, size, locFile))
 def VV297q(self, remFile, size, locFile, VVXuS2):
  VVXuS2.VVhaSh(size)
  VVXuS2.VVoBtV = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVS4Z9(data):
     if not VVXuS2 or VVXuS2.isCancelled:
      return
     locFileObj.write(data)
     VVXuS2.VVzPku(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVS4Z9)
   except Exception as e:
    VVXuS2.VVoBtV = str(e)
 def VVSXpJ(self, remFile, size, locFile, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVoBtV:
   FFeF28(self, "%s\n\nftp:/%s" % (VVoBtV, remFile), title="Download Error")
   delF = True
  elif not VV2c9g:
   FFeF28(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFgx6P(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFDx6X(self, txt, title=title)
   else:
    FFeF28(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFOHeU(locFile)
 def VV5AW7(self):
  if self.VVjcEF():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVmc3z
   self.session.openWithCallback(self.VV3ZLj, BF(CCZHbk, VVdjsL="Upload selected file", VVYYtf=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VV3ZLj(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFCRXL(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFgx6P(locFile)
   if size == -1:
    FFeF28(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVqCGg, locFile, size, remFile)
        , VVHoAX = BF(self.VVUFLw, locFile, size, remFile))
 def VVqCGg(self, locFile, size, remFile, VVXuS2):
  VVXuS2.VVhaSh(size)
  VVXuS2.VVoBtV = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVUnaO(data):
     if not VVXuS2 or VVXuS2.isCancelled:
      VVXuS2.VVoBtV = "Upload cancelled"
      locFileObj.close()
      return
     VVXuS2.VVzPku(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVUnaO)
   except Exception as e:
    VVXuS2.VVoBtV = VVXuS2.VVoBtV or str(e)
 def VVUFLw(self, locFile, size, remFile, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VV2c9g:
   if size == FFgx6P(locFile) : FFDx6X(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVoBtV : err = "%s\n\n%s" % (VVoBtV, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFeF28(self, err, title=title)
   self.VVFXzZ()
   self.VVIXk9(remFile, "")
  self.VVXGni(self.curDir)
class CCzLkW():
 VVOvZx  = "all"
 VVycb0 = "vid"
 VVNUoY  = "osd"
 @staticmethod
 def VVEHrQ(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFGbNH("grab"):
    winShown = session.current_dialog.shown
    if k == CCzLkW.VVycb0 and winShown: session.current_dialog.hide()
    FFJVhm(BF(CCzLkW.VVAvP6, title, session, k, winShown))
   else:
    FFYd19(session, "No Grab command !", title=title)
 @staticmethod
 def VVAvP6(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCzLkW.VVNUoY:
   if not winShown:
    FFYd19(session, "No Window to capture !", title=title)
    return
   if not CCzLkW.VVcpMs(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCzLkW.VVEQmt(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFYd19(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFvBW5(CFG.exportedPIconsPath.getValue()), fTitle, FFguCY(), ext)
  ok = FFbqSU("grab -q -s %s > '%s'" % (typ, path))
  if k == CCzLkW.VVycb0 and winShown:
   session.current_dialog.show()
  elif k == CCzLkW.VVNUoY:
   ok = CCzLkW.VVO633(path, x, y, w, h)
   if not ok:
    FFOHeU(path)
    FFYd19(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCKpZj, title=path, VVPWSw=path))
  else      : FFYd19(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVcpMs(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFZRvh(SELF, BF(CCzLkW.VVgxdp, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVgxdp(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFBFPP, VVdenE=cbFnc)
  else    : fnc = BF(FF1NOx , VVdenE=cbFnc)
  fnc(SELF, FFNCOV(VVy8Lf, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVEQmt(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVO633(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFpkpy()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFpwm6(x , 0, scrW, 0, w)
     y  = FFpwm6(y , 0, scrH, 0, h)
     x1 = FFpwm6(x1, 0, scrW, 0, w)
     y1 = FFpwm6(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVPpnu(path):
  size = FFgx6P(path)
  sizeTxt = CCZHbk.VVi3go(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCa3Iq(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF4aCb(" (Requires GUI Restart)", VVwWfr) if withRestart else ""
  VVGuvj = []
  for path in self.fontsList:
   VVGuvj.append((os.path.splitext(os.path.basename(path))[0], path))
  VVGuvj.sort(key=lambda x: x[0].lower())
  VVGuvj.insert(0, VVnek4)
  VVGuvj.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVGuvj):
    if len(item) == 2 and item[1] == self.defFnt:
     VVGuvj[ndx] = (VV1udq + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVGuvj[curIndex] = (VV1udq + VVGuvj[curIndex][0], VVGuvj[curIndex][1])
  FFOUwv(self, VVGuvj=VVGuvj, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
  self["myBar"].setText(self.VV6u9Y())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVzXwC)
  self.VVzXwC()
 def VVTQe0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVzXwC(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFrEiv(path, fnt, isRepl=1)
  else:
   fnt = VVgRwY
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VV6u9Y(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVCwUY(SELF, title, defFnt, rest, VVHoAX):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FF2oot(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVHoAX, CCa3Iq, title, fontsList, defFnt, rest)
  else  : FFeF28(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCOL0v(Screen):
 def __init__(self, session, path, VVGuvj, title):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFOUwv(self, VVGuvj=VVGuvj, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.VVTQe0   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVJ5Bs,
   "chanUp" : self.VVJ5Bs,
   "pageDown" : self.VVHo0X ,
   "chanDown" : self.VVHo0X ,
  }, -1)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
  FFBHn2(self["myLabelFrm"], "#11110000")
  FFBHn2(self["myLabelTit"], "#11663322")
  FFBHn2(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVULLC)
  self.VVULLC()
 def VVULLC(self):
  if fileExists(self.path): txt = FFhqv7(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVTQe0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVJ5Bs(self) : self["myMenu"].moveToIndex(0)
 def VVHo0X(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC7ZOW():
 @staticmethod
 def VVgtEC():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVCudt(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFBxNx(SELF, None, VVWhjq=lst, VVCppa=30, VV9SwC=1)
 @staticmethod
 def VVG0aP(path, SELF=None):
  for enc in CC7ZOW.VVgtEC():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFeF28(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVJ3oI(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVdRlj(SELF, path, cbFnc, curEnc=VVl8Ad, title="Select Encoding"):
  lst = CC7ZOW.VVeFhn(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCOL0v, path, lst, title)
 @staticmethod
 def VV28g2(SELF, cbFnc, curEnc=VVl8Ad, title="Select Encoding"):
  lst = CC7ZOW.VVeFhn(SELF, "", "")
  if lst:
   FFSiXW(SELF, cbFnc, title=title, VVGuvj=lst, width=1000, height=1000, VVmEJ8="#22220000", VVd8a3="#22220000", VVYJYo=True)
 @staticmethod
 def VVeFhn(SELF, path, curEnc):
  lst = CC7ZOW.VVlT4z(path)
  if lst:
   VVGuvj = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VV1udq
    elif enc == VVl8Ad: c = VVc1MO
    else      : c = ""
    VVGuvj.append((c + txt, enc))
   return VVGuvj
  else:
   FFFSea(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVlT4z(path=""):
  encLst = []
  cPath = VVqXR1 + "_sup_codecs"
  if fileExists(cPath):
   lines = FF8p4l(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CC7ZOW.VVgtEC())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCeKGl(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGuvj = []
  VVGuvj.append(("Settings File"   , "SettingsFile"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Box Info"     , "VVgsPU"   ))
  VVGuvj.append(("Tuners Info"    , "VVmne3"  ))
  VVGuvj.append(("Python Version"   , "VVWeg9"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Screen Size"    , "ScreenSize"   ))
  VVGuvj.append(("Language/Locale"   , "Locale"    ))
  VVGuvj.append(("Processor"    , "Processor"   ))
  VVGuvj.append(("Operating System"   , "OperatingSystem"  ))
  VVGuvj.append(("Drivers"     , "drivers"    ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("System Users"    , "SystemUsers"   ))
  VVGuvj.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVGuvj.append(("Uptime"     , "Uptime"    ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Host Name"    , "HostName"   ))
  VVGuvj.append(("MAC Address"    , "MACAddress"   ))
  VVGuvj.append(("Network Configuration" , "NetworkConfiguration"))
  VVGuvj.append(("Network Status"   , "NetworkStatus"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Disk Usage"    , "VVjWkE"   ))
  VVGuvj.append(("Mount Points"    , "MountPoints"   ))
  VVGuvj.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVGuvj.append(("USB Devices"    , "USB_Devices"   ))
  VVGuvj.append(("List Block-Devices"  , "listBlockDevices" ))
  VVGuvj.append(("Directory Size"   , "DirectorySize"  ))
  VVGuvj.append(("Memory"     , "Memory"    ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVGuvj.append(("Running Processes"  , "RunningProcesses" ))
  VVGuvj.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFOUwv(self, VVGuvj=VVGuvj, title="Device Information")
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCqaln)
   elif item == "VVgsPU"   : self.VVgsPU()
   elif item == "VVmne3"  : self.VVmne3()
   elif item == "VVWeg9"  : self.VVWeg9()
   elif item == "ScreenSize"   : FFPaL6(self, "Width\t: %s\nHeight\t: %s" % (FFpkpy()[0], FFpkpy()[1]))
   elif item == "Locale"    : CC7ZOW.VVCudt(self)
   elif item == "Processor"   : self.VVxtIC()
   elif item == "OperatingSystem"  : FFjeoA(self, "uname -a")
   elif item == "drivers"    : self.VVpsrZ()
   elif item == "SystemUsers"   : FFjeoA(self, "id")
   elif item == "LoggedInUsers"  : FFjeoA(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFjeoA(self, "uptime")
   elif item == "HostName"    : FFjeoA(self, "hostname")
   elif item == "MACAddress"   : self.VVlt53()
   elif item == "NetworkConfiguration" : FFjeoA(self, "ifconfig %s %s" % (FFlTM0("HWaddr", VVHksW), FFlTM0("addr:", VVc1MO)))
   elif item == "NetworkStatus"  : FFjeoA(self, "netstat -tulpn", VVCppa=24, consFont=True)
   elif item == "VVjWkE"   : self.VVjWkE()
   elif item == "MountPoints"   : FFjeoA(self, "mount %s" % (FFlTM0(" on ", VVc1MO)))
   elif item == "FileSystemTable"  : FFjeoA(self, "cat /etc/fstab", VVCppa=24, consFont=True)
   elif item == "USB_Devices"   : FFjeoA(self, "lsusb")
   elif item == "listBlockDevices"  : FFjeoA(self, "blkid")
   elif item == "DirectorySize"  : FFjeoA(self, "du -shc /* 2>/dev/null | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVWeeE="Reading size ...")
   elif item == "Memory"    : FFjeoA(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVzywi()
   elif item == "RunningProcesses"  : FFjeoA(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFjeoA(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVjQqu()
   else        : self.close()
 def VVlt53(self):
  res = FFMNhK("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFPaL6(self, txt)
  else:
   FFjeoA(self, "ip link")
 def VVSr96(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFkrzQ(cmd)
  return lines
 def VVJKxb(self, lines, headerRepl, widths, VVRYg6):
  VVJpUa = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVJpUa.append(parts)
  if VVJpUa and len(header) == len(widths):
   VVJpUa.sort(key=lambda x: x[0].lower())
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VV9SwC=1)
   return True
  else:
   return False
 def VVjWkE(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFMNhK(cmd)
  if not "invalid option" in txt:
   lines  = self.VVSr96(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVRYg6 = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVJKxb(lines, headerRepl, widths, VVRYg6)
  else:
   cmd = "df -h"
   lines  = self.VVSr96(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVRYg6 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVJKxb(lines, headerRepl, widths, VVRYg6)
  if not allOK:
   lines = FFkrzQ(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFaYmq(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV1udq:
     note = "\n%s" % FF4aCb("Green = Mounted Partitions", VV1udq)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVc1MO
     elif line.endswith(mountList) : color = VV1udq
     else       : color = VVE7tQ
     txt += FF4aCb(line, color) + "\n"
    FFPaL6(self, txt + note)
   else:
    FFeF28(self, "Not data from system !")
 def VVzywi(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVSr96(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVRYg6 = (LEFT , CENTER, LEFT )
  allOK = self.VVJKxb(lines, headerRepl, widths, VVRYg6)
  if not allOK:
   FFjeoA(self, cmd)
 def VVpsrZ(self):
  cmd = FFnws9(VVNP8B, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFjeoA(self, cmd)
  else : FFDayU(self)
 def VVxtIC(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFjeoA(self, cmd)
 def VVjQqu(self):
  cmd = FFnws9(VVpuWY, "| grep secondstage")
  if cmd : FFjeoA(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFDayU(self)
 def VVgsPU(self):
  c = VV1udq
  VVWhjq = []
  VVWhjq.append((FF4aCb("Box Type"  , c), FF4aCb(self.VVVCiU("boxtype").upper(), c)))
  VVWhjq.append((FF4aCb("Board Version", c), FF4aCb(self.VVVCiU("board_revision") , c)))
  VVWhjq.append((FF4aCb("Chipset"  , c), FF4aCb(self.VVVCiU("chipset")  , c)))
  VVWhjq.append((FF4aCb("S/N"   , c), FF4aCb(self.VVVCiU("sn")    , c)))
  VVWhjq.append((FF4aCb("Version"  , c), FF4aCb(self.VVVCiU("version")  , c)))
  VVi3la   = []
  VVnfpy = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVnfpy = SystemInfo[key]
     else:
      VVi3la.append((FF4aCb(str(key), VVrWwc), FF4aCb(str(SystemInfo[key]), VVrWwc)))
  except:
   pass
  if VVnfpy:
   VVjXYb = self.VVFdh8(VVnfpy)
   if VVjXYb:
    VVjXYb.sort(key=lambda x: x[0].lower())
    VVWhjq += VVjXYb
  if VVi3la:
   VVi3la.sort(key=lambda x: x[0].lower())
   VVWhjq += VVi3la
  if VVWhjq:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFBxNx(self, None, header=header, VVWhjq=VVWhjq, VVmQwL=widths, VVCppa=28, VV9SwC=1)
  else:
   FFPaL6(self, "Could not read info!")
 def VVVCiU(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF8p4l(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVFdh8(self, mbDict):
  try:
   mbList = list(mbDict)
   VVWhjq = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVWhjq.append((FF4aCb(subject, VVc1MO), FF4aCb(value, VVc1MO)))
  except:
   pass
  return VVWhjq
 def VVmne3(self):
  txt = self.VVJf9i("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVJf9i("/proc/bus/nim_sockets")
  if not txt: txt = self.VV1kb6()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFPaL6(self, txt)
 def VV1kb6(self):
  txt = ""
  VV1pWY = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV1pWY("Slot Name" , slot.getSlotName())
     txt += FF4aCb(slotName, VVc1MO)
     txt += VV1pWY("Description"  , slot.getFullDescription())
     txt += VV1pWY("Frontend ID"  , slot.frontend_id)
     txt += VV1pWY("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVJf9i(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF8p4l(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF4aCb(line, VVc1MO)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVWeg9(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFPaL6(self, txt)
 @staticmethod
 def VVb5st():
  def VV1pWY(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VV1pWY(v,0), "/etc/issue.net": VV1pWY(v,1), "/etc/image-version": VV1pWY(v,2)}
  for p1, d in v.items():
   img = CCeKGl.VVzCw8(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VV1pWY(v,0), p + "Plugins/": VV1pWY(v,1), VVzDIh: VV1pWY(v,2), VV4i8I: VV1pWY(v,3)}
  for p1, d in v.items():
   img = CCeKGl.VVeT4S(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVzCw8(path, d):
  if fileExists(path):
   txt = FFhqv7(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVeT4S(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCqaln(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGuvj = []
  VVGuvj.append(("Settings (All)"   , "Settings_All"   ))
  VVGuvj.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVGuvj.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVGuvj.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVGuvj.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVGuvj.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVGuvj.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVwauR:
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVGuvj.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %s" % VVOAlS
   grep = " | grep "
   if   item == "Settings_All"   : FFjeoA(self, cmd)
   elif item == "Settings_HotKeys"  : FFjeoA(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFjeoA(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFjeoA(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFjeoA(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFjeoA(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFjeoA(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFjeoA(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFjeoA(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCAhZF(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVTxUQ, VV9xUO, VVu1oA, camCommand = CCAhZF.VVSt46()
  self.VV9xUO = VV9xUO
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VV9xUO:
   c = VVE7n3 if VVu1oA else VVXSg2
   if   "oscam" in VV9xUO : camName, oC = "OSCam", c
   elif "ncam"  in VV9xUO : camName, nC = "NCam" , c
  VVGuvj = []
  VVGuvj.append(("OSCam Files" , "OSCamFiles" ))
  VVGuvj.append(("NCam Files" , "NCamFiles" ))
  VVGuvj.append(("CCcam Files" , "CCcamFiles" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((VV2Bne + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VV1cFt" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVGuvj.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVGuvj.append(VVnek4)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVGuvj.append(FFUHeM(txt, "camInfo", VV9xUO, c))
  VVGuvj.append(VVnek4)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VV9xUO:
   for item in camLst: VVGuvj.append(item)
  else:
   for item in camLst: VVGuvj.append((item[0], ))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCXdEX, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCXdEX, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCXdEX, "cccam"))
   elif item == "VV1cFt" : self.VV1cFt()
   elif item == "OSCamReaders"  : self.VVyl6n("os")
   elif item == "NSCamReaders"  : self.VVyl6n("n")
   elif item == "camInfo"   : FFQgB2(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCAhZF.VVZF6j(self.session, CCLwqj.VVer2e)
   elif item == "camLiveReaders" : CCAhZF.VVZF6j(self.session, CCLwqj.VVUc6p)
   elif item == "camLiveLog"  : CCAhZF.VVZF6j(self.session, CCLwqj.VVlTzE)
   else       : self.close()
 def VV1cFt(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVmc3z, FFguCY())
  if fileExists(path):
   lines = FF8p4l("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VV1pWY = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VV1pWY("label"    , "CCcam-Line-%d" % ndx))
      f.write(VV1pWY("description"  , "CCcam-Line-%d" % ndx))
      f.write(VV1pWY("protocol"   , "cccam"))
      f.write(VV1pWY("device"    , "%s,%s" % (host, port)))
      f.write(VV1pWY("user"    , User))
      f.write(VV1pWY("password"   , Pass))
      f.write(VV1pWY("fallback"   , "1"))
      f.write(VV1pWY("group"    , "64"))
      f.write(VV1pWY("cccversion"   , "2.3.2"))
      f.write(VV1pWY("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFDx6X(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFtCOg(tot), outFile))
   else:
    FF1lLq(self, "No valid CCcam lines", 1500)
  else:
   FF1lLq(self, "%s not found" % path, 1500)
 def VVyl6n(self, camPrefix):
  VVJpUa = self.VV6lA1(camPrefix)
  if VVJpUa:
   VVJpUa.sort(key=lambda x: int(x[0]))
   if self.VV9xUO and self.VV9xUO.startswith(camPrefix):
    VVdyRp = ("Toggle State", self.VVEYwf, [camPrefix], "Changing State ...")
   else:
    VVdyRp = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVRYg6  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVdyRp=VVdyRp, VVOisu=True)
 def VV6lA1(self, camPrefix):
  readersFile = self.VVTxUQ + camPrefix + "cam.server"
  VVJpUa = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF8p4l(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVJpUa.append((str(len(VVJpUa) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVJpUa:
    FFeF28(self, "No readers found !")
  else:
   FFJBL5(self, readersFile)
  return VVJpUa
 def VVEYwf(self, VVgAw8, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVTxUQ, camPrefix)
  readerState  = VVgAw8.VVhkzh(1)
  readerLabel  = VVgAw8.VVhkzh(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCAhZF.VVgP6W(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVgAw8.VVOvTL()
    FFeF28(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVJpUa = self.VV6lA1(camPrefix)
   if VVJpUa:
    VVgAw8.VVFDhD(VVJpUa)
  else:
   VVgAw8.VVOvTL()
 @staticmethod
 def VVgP6W(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF8p4l(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFeF28(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFeF28(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFJBL5(SELF, confFile)
   return None
  if not iRequest:
   FFeF28(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCAhZF.VVWJ4w(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFeF28(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVWJ4w(SELF):
  if iElem:
   return True
  else:
   FFeF28(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVZF6j(session, VVSXen):
  VVTxUQ, VV9xUO, VVu1oA, camCommand = CCAhZF.VVSt46()
  if VV9xUO:
   runLog = False
   if   VVSXen == CCLwqj.VVer2e : runLog = True
   elif VVSXen == CCLwqj.VVUc6p : runLog = True
   elif not VVu1oA          : FFYd19(session, message="SoftCam not started yet!")
   elif fileExists(VVu1oA)        : runLog = True
   else             : FFYd19(session, message="File not found !\n\n%s" % VVu1oA)
   if runLog:
    session.open(BF(CCLwqj, VVTxUQ=VVTxUQ, VV9xUO=VV9xUO, VVu1oA=VVu1oA, VVSXen=VVSXen))
  else:
   FFYd19(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVSt46():
  VVTxUQ = "/etc/tuxbox/config/"
  VV9xUO = None
  VVu1oA  = None
  camCommand = FFGRiq("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VV9xUO = "oscam"
   elif camCmd.startswith("ncam") : VV9xUO = "ncam"
  if VV9xUO:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFhqv7(path), IGNORECASE)
     if span:
      VVTxUQ = FFvBW5(span.group(1))
      break
   else:
    path = FFGRiq(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFvBW5(path)
    if pathExists(path):
     VVTxUQ = path
   tFile = FFvBW5(VVTxUQ) + VV9xUO + ".conf"
   tFile = FFGRiq("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVu1oA = tFile
  return VVTxUQ, VV9xUO, VVu1oA, camCommand
class CCXdEX(Screen):
 def __init__(self, VVIPcB, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVTxUQ, VV9xUO, VVu1oA, camCommand = CCAhZF.VVSt46()
  if   VVIPcB == "ncam" : self.prefix = "n"
  elif VVIPcB == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVGuvj = []
  if self.prefix == "":
   VVGuvj.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVGuvj.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVGuvj.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVGuvj.append(("constant.cw"         , "x_constant_cw" ))
   VVGuvj.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVGuvj.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVGuvj.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVGuvj.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVGuvj.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVGuvj.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVGuvj.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVGuvj.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVGuvj.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVGuvj.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVGuvj.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFXpyW(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFXpyW(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFXpyW(self, self.VVTxUQ + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFXpyW(self, self.VVTxUQ + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVhg0D("cam.ccache")
   elif item == "x_cam_conf"  : self.VVhg0D("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVhg0D("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVhg0D("cam.provid")
   elif item == "x_cam_server"  : self.VVhg0D("cam.server")
   elif item == "x_cam_services" : self.VVhg0D("cam.services")
   elif item == "x_cam_srvid2"  : self.VVhg0D("cam.srvid2")
   elif item == "x_cam_user"  : self.VVhg0D("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVI3S3()
   elif item == "x_CCcam_cfg"  : FFXpyW(self, self.VVTxUQ + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFXpyW(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFXpyW(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFXpyW(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVhg0D(self, fileName):
  FFXpyW(self, self.VVTxUQ + self.prefix + fileName)
 def VVI3S3(self):
  path = self.VVTxUQ + "SoftCam.Key"
  if fileExists(path) : FFXpyW(self, path)
  else    : FFXpyW(self, path.replace(".Key", ".key"))
class CCLwqj(Screen):
 VVer2e  = 0
 VVUc6p = 1
 VVlTzE = 2
 def __init__(self, session, VVTxUQ="", VV9xUO="", VVu1oA="", VVSXen=VVer2e):
  self.skin, self.skinParam = FFhwpa(VVhNmI, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVu1oA   = VVu1oA
  self.VVSXen  = VVSXen
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVTxUQ + VV9xUO + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV9xUO : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVTxUQ, self.camPrefix)
  if self.VVSXen == self.VVer2e:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVSXen == self.VVUc6p:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFOUwv(self, self.Title, addScrollLabel=True)
  FFtNax(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVWjP2
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self["myLabel"].VVyzBh(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFimE3(self)
  self.VVWjP2()
 def onExit(self):
  self.timer.stop()
 def VVUZld(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvcQO)
  except:
   self.timer.callback.append(self.VVvcQO)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF1lLq(self, "Started", 1000)
 def VVYY9U(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVvcQO)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF1lLq(self, "Stopped", 1000)
 def VVWjP2(self):
  if self.timerRunning:
   self.VVYY9U()
  else:
   self.VVUZld()
   if self.VVSXen == self.VVer2e or self.VVSXen == self.VVUc6p:
    if self.VVSXen == self.VVer2e : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCAhZF.VVgP6W(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFJVhm(self.VVqsw8)
    else:
     self.close()
   else:
    self.VVt675()
 def VVvcQO(self):
  if self.timerRunning:
   if   self.VVSXen == self.VVer2e : self.VVjITK()
   elif self.VVSXen == self.VVUc6p : self.VVjITK()
   else            : self.VVt675()
 def VVt675(self):
  if fileExists(self.VVu1oA):
   fTime = FFrH35(os.path.getmtime(self.VVu1oA))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV7yOx(), VVXyQm=VVy0vq)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVu1oA)
 def VVqsw8(self):
  self.VVjITK()
 def VVjITK(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF4aCb("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVEkv6))
   self.camWebIfErrorFound = True
   self.VVYY9U()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVSXen == self.VVer2e : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF4aCb("Error while parsing data elements !\n\nError = %s" % str(e), VVs795)
   self.camWebIfErrorFound = True
   self.VVYY9U()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVc7Ex(root)
  self["myLabel"].setText(txt, VVXyQm=VVy0vq)
  self["myBar"].setText("Last Update : %s" % FFfB6C())
 def VVc7Ex(self, rootElement):
  def VV1pWY(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVSXen == self.VVer2e:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF4aCb(status, VV1udq)
    else          : status = FF4aCb(status, VVs795)
    txt += SEP + "\n"
    txt += VV1pWY("Name"  , name)
    txt += VV1pWY("Description" , desc)
    txt += VV1pWY("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV1pWY("Protocol" , protocol)
    txt += VV1pWY("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF4aCb("Yes", VV1udq)
    else    : enabTxt = FF4aCb("No", VVs795)
    txt += SEP + "\n"
    txt += VV1pWY("Label"  , label)
    txt += VV1pWY("Protocol" , protocol)
    txt += VV1pWY("Enabled" , enabTxt)
  return txt
 def VV7yOx(self):
  lines = FFkrzQ("tail -n %d %s" % (100, self.VVu1oA))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVwWfr + line[:19] + VVE7tQ + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VV5Hia + "WebIf" + VVE7tQ)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVrWwc + h1 + h2 + VVE7tQ + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VV1udq + span.group(2) + VV2Bne + span.group(3) + VVE7tQ + span.group(4)
    line = self.VV7cBl(line, VV2Bne, ("(webif)", ))
    line = self.VV7cBl(line, VV2Bne, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV7cBl(line, VV1udq, ("OSCam", "NCam", "log switched"))
    line = self.VV7cBl(line, VVT2Mp, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVc1MO + line[ndx + 3:] + VVE7tQ
   elif line.startswith("----") or ">>" in line:
    line = FF4aCb(line, VViU6E)
   txt += line + "\n"
  return txt
 def VV7cBl(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVE7tQ + t3
  return line
class CCjDSw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVGuvj = []
  VVGuvj.append(("Backup Channels"    , "VVd5hO"   ))
  VVGuvj.append(("Restore Channels"    , "Restore_Channels"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Backup SoftCAM Files"   , "VVhjFs" ))
  VVGuvj.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVGuvj.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVGuvj.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Backup Network Settings"  , "VVrC5U"   ))
  VVGuvj.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVwauR:
   VVGuvj.append(VVnek4)
   VVGuvj.append((VVEkv6 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVz7nQ"   ))
   VVGuvj.append((VV1udq + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVhmug), "createMyIpk"   ))
   VVGuvj.append((VV1udq + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVhmug), "createMyDeb"   ))
   VVGuvj.append((VVrWwc + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVGuvj.append((VVrWwc + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVn5Cz" ))
   VVGuvj.append((VVrWwc + "Show Windows Stats"           , "VV0A7O" ))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVd5hO"    : self.VVd5hO()
   elif item == "Restore_Channels"    : self.VVCpEd("channels_backup*.tar.gz", self.VV8vkg, isChan=True)
   elif item == "VVhjFs"   : self.VVhjFs()
   elif item == "Restore_SoftCAM_Files"  : self.VVCpEd("softcam_backup*.tar.gz", self.VV7q5I)
   elif item == "Backup_TunerDiSEqC"   : self.VVrKhw("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVCpEd("tuner_backup*.backup", BF(self.VVxZID, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVrKhw("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVCpEd("hotkey_*backup*.backup", BF(self.VVxZID, "misc"))
   elif item == "VVrC5U"    : self.VVrC5U()
   elif item == "Restore_Network"    : self.VVCpEd("network_backup*.tar.gz", self.VV82uI)
   elif item == "VVz7nQ"     : FFZRvh(self, BF(FF4idw, self, BF(CCjDSw.VVz7nQ, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVOuGp(False)
   elif item == "createMyDeb"     : self.VVOuGp(True)
   elif item == "createMyTar"     : self.VV1wE7()
   elif item == "VVn5Cz"   : self.VVn5Cz()
   elif item == "VV0A7O"    : CCjDSw.VV0A7O(self)
 @staticmethod
 def VVg2jS(SELF):
  OBF_Path = VVSTHA + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFJBL5(SELF, OBF_Path)
   return None
 @staticmethod
 def VV0A7O(SELF):
  obf = CCjDSw.VVg2jS(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFPaL6(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVz7nQ(SELF):
  obf = CCjDSw.VVg2jS(SELF)
  if obf:
   txt, err = obf.fixCode(VVSTHA, VV64TL, VVhmug)
   if err : FFeF28(SELF, err)
   else : FFPaL6(SELF, txt)
 def VVOuGp(self, VVB3L1):
  OBF_Path = VVSTHA + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFeF28(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FF7Jdu("rm -f %s__pycache__/" % VVSTHA)
  FF7Jdu("mv -f '%smain.py' '%s'" % (VVSTHA, OBF_Path))
  FF7Jdu("mv -f '%splugin.py' '%s'" % (VVSTHA, OBF_Path))
  FF7Jdu("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVSTHA))
  self.session.openWithCallback(self.VVIszD, BF(CC5LSv, path=VVSTHA, VVB3L1=VVB3L1))
 def VVIszD(self):
  FF7Jdu("mv -f %s %s" % (VVSTHA + "OBF/main.py" , VVSTHA))
  FF7Jdu("mv -f %s %s" % (VVSTHA + "OBF/plugin.py", VVSTHA))
 def VVn5Cz(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFeF28(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFeF28(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVddZR("%s*.list" % path)
  if err:
   FFJBL5(self, path + "*.list")
   return
  srcF, err = self.VVddZR("%s*main_final.py" % path)
  if err:
   FFJBL5(self, path + "*.final.py")
   return
  VVWhjq = []
  for f in files:
   f = os.path.basename(f)
   VVWhjq.append((f, f))
  FFSiXW(self, BF(self.VV6aFG, path, codF, srcF), VVGuvj=VVWhjq)
 def VV6aFG(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFJBL5(self, logF)
   else     : FF4idw(self, BF(self.VV61Dv, logF, codF, srcF))
 def VV61Dv(self, logF, codF, srcF):
  lst  = []
  lines = FF8p4l(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFeF28(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVsAKY(lst, logF, newLogF)
  totSrc  = self.VVsAKY(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFPaL6(self, txt)
 def VVddZR(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVsAKY(self, lst, f1, f2):
  txt = FFhqv7(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VV1wE7(self):
  VVWhjq = []
  VVWhjq.append("%s%s" % (VVSTHA, "*.py"))
  VVWhjq.append("%s%s" % (VVSTHA, "*.png"))
  VVWhjq.append("%s%s" % (VVSTHA, "*.xml"))
  VVWhjq.append("%s"  % (VVqXR1))
  FFVhm9(self, VVWhjq, "%s_%s" % (PLUGIN_NAME, VV64TL), addTimeStamp=False)
 def VVd5hO(self):
  path1 = VVgBUe
  path2 = "/etc/tuxbox/"
  VVWhjq = []
  VVWhjq.append("%s%s" % (path1, "*.tv"))
  VVWhjq.append("%s%s" % (path1, "*.radio"))
  VVWhjq.append("%s%s" % (path1, "*list"))
  VVWhjq.append("%s%s" % (path1, "lamedb*"))
  VVWhjq.append("%s%s" % (path2, "*.xml"))
  FFVhm9(self, VVWhjq, self.VVIapj("channels_backup"), addTimeStamp=True)
 def VVhjFs(self):
  VVWhjq = []
  VVWhjq.append("/etc/tuxbox/config/")
  VVWhjq.append("/usr/keys/")
  VVWhjq.append("/usr/scam/")
  VVWhjq.append("/etc/CCcam.cfg")
  FFVhm9(self, VVWhjq, self.VVIapj("softcam_backup"), addTimeStamp=True)
 def VVrC5U(self):
  VVWhjq = []
  VVWhjq.append("/etc/hostname")
  VVWhjq.append("/etc/default_gw")
  VVWhjq.append("/etc/resolv.conf")
  VVWhjq.append("/etc/wpa_supplicant*.conf")
  VVWhjq.append("/etc/network/interfaces")
  VVWhjq.append("%snameserversdns.conf" % VVgBUe)
  FFVhm9(self, VVWhjq, self.VVIapj("network_backup"), addTimeStamp=True)
 def VVIapj(self, fName):
  img = CCeKGl.VVb5st()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VV8vkg(self, fileName=None):
  if fileName:
   FFZRvh(self, BF(FF4idw, self, BF(self.VV2PvT, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VV2PvT(self, fileName):
  path = "%s%s" % (VVmc3z, fileName)
  if fileExists(path):
   if CCZHbk.VVFwUk(path):
    VV6Klt , VVJSdi = CC1mtH.VV1ktS()
    VVcIbu, VVydMo = CC1mtH.VVGJTW()
    cmd  = FFTMeZ("cd %s" % VVgBUe)
    cmd += FFTMeZ("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVJSdi, VVydMo))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FF7Jdu(cmd)
    FF9bFs()
    if ok: FFDx6X(self, "Channels Restored.")
    else : FFeF28(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFeF28(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFJBL5(self, path)
 def VV7q5I(self, fileName=None):
  if fileName:
   FFZRvh(self, BF(self.VVmhBe, fileName), "Overwrite SoftCAM files ?")
 def VVmhBe(self, fileName):
  fileName = "%s%s" % (VVmc3z, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FFSSlA(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFlTM0(note, VVc1MO), sep))
  else:
   FFJBL5(self, fileName)
 def VV82uI(self, fileName=None):
  if fileName:
   FFZRvh(self, BF(self.VVPJRs, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVPJRs(self, fileName):
  fileName = "%s%s" % (VVmc3z, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF1NOx(self,  cmd)
  else:
   FFJBL5(self, fileName)
 def VVCpEd(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFVLF6()
  if pathExists(VVmc3z):
   myFiles = FF2oot(VVmc3z, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVWhjq = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVWhjq.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVIY0g = ("Sat. List", self.VVokiz)
    elif isChan and iTar: VVIY0g = ("Bouquets Importer", CCVnOk.VV63oW)
    else    : VVIY0g = None
    FFSiXW(self, callBackFunction, title=title, width=1200, VVGuvj=VVWhjq, VVIY0g=VVIY0g, VV51Jr=VVmc3z)
   else:
    FFeF28(self, "No files found in:\n\n%s" % VVmc3z, title)
  else:
   FFeF28(self, "Path not found:\n\n%s" % VVmc3z, title)
 def VVrKhw(self, filePrefix, wordsFilter):
  title = FFVLF6()
  if fileExists(VVOAlS):
   tCons = CC9YTZ()
   tCons.ePopen("cat %s | grep '%s'" % (VVOAlS, wordsFilter), BF(self.VVrggV, title, filePrefix))
  else:
   FFeF28(self, "Cannot read settings file", title)
 def VVrggV(self, title, filePrefix, result, retval):
  if pathExists(VVmc3z):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFeF28(self, "No settings found to backup !", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVmc3z, filePrefix, self.VVIapj(""), FFguCY())
    try:
     VVWhjq = str(result.strip()).split()
     if VVWhjq:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVWhjq:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FF4aCb(fName, VVc1MO), SEP)
       FFPaL6(self, txt, title=title, VVXyQm=VVy0vq)
      else:
       FFeF28(self, "File creation failed!", title)
     else:
      FFeF28(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FF7Jdu("rm %s" % fName)
     FFeF28(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FF7Jdu("rm %s" % fName)
     FFeF28(self, "Error while writing file.")
  else:
   FFeF28(self, "Path not found:\n\n%s" % VVmc3z, title)
 def VVxZID(self, mode, path=None):
  if path:
   path = "%s%s" % (VVmc3z, path)
   if fileExists(path):
    lines = FF8p4l(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFZRvh(self, BF(self.VVV3Fr, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF5LOj(self, path, title=FFVLF6())
   else:
    FFJBL5(self, path)
 def VVV3Fr(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVGrGW = []
  tFile = "/tmp/ajp_tmp"
  VVGrGW.append("echo -e 'Reading current settings ...'")
  VVGrGW.append("cat %s | grep -v '%s' > %s" % (VVOAlS, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVGrGW.append("echo -e 'Preparing new settings ...'")
  VVGrGW.append(settingsLines)
  VVGrGW.append("echo -e 'Applying new settings ...'")
  VVGrGW.append("mv -f %s %s" % (tFile, VVOAlS))
  FF0AJe(self, VVGrGW)
 def VVokiz(self, selectionObj, path):
  if not path:
   return
  path = VVmc3z + path
  if not fileExists(path):
   FFJBL5(self, path)
   return
  txt = FFhqv7(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFMVuT(item[1]))
   FFPaL6(self, txt, title="Satellites List")
  else:
   FFeF28(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCVnOk():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VV63oW(SELF, fName):
  bi = CCVnOk(SELF)
  bi.instance = bi
  bi.VVU06U(SELF, fName)
 @staticmethod
 def VVHScl(SELF):
  bi = CCVnOk(SELF)
  bi.instance = bi
  bi.VVkzxK()
 def VVU06U(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVmc3z + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF4idw(waitObg, self.VV2pI3, title="Reading bouquets ...")
  else      : self.VVqqai(self.filePath)
 def VVRGGb(self, txt) : FFeF28(self.SELF, txt, title=self.Title)
 def VVhghQ(self, txt)  : FF1lLq(self, txt, 1500)
 def VVqqai(self, path) : FFJBL5(self.SELF, path, title=self.Title)
 def VVkzxK(self):
  if pathExists(VVmc3z):
   lst = FF2oot(VVmc3z, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VV8jxQ())
   if len(lst) > 0:
    VVGuvj = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF4aCb(item, VV2Bne) if item.endswith(".zip") else item
     VVGuvj.append((txt, item))
    VVGuvj.sort(key=lambda x: x[1].lower())
    VVwpVu = self.VV3f5l
    FFSiXW(self.SELF, self.VVoT9R, minRows=3, title=self.Title, width=1200, VVGuvj=VVGuvj, VVwpVu=VVwpVu, VV51Jr=VVmc3z, VVmEJ8="#22111111", VVd8a3="#22111111")
   else:
    self.VVRGGb("No valid backup files found in:\n\n%s" % VVmc3z)
  else:
   self.VVRGGb("Backup Directory not found:\n\n%s" % VVmc3z)
 def VV3f5l(self, item=None):
  if item:
   VVUD8b, txt, fName, ndx = item
   self.VVU06U(VVUD8b, fName)
 def VVoT9R(self, item=None):
  if not item and self.instance:
   del self.instance
 def VV8jxQ(self):
  files = FF2oot(VVmc3z, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VV2pI3(self):
  lines, err = CCVnOk.VVYmvg(self.filePath, "bouquets.tv")
  if err:
   self.VVRGGb(err)
   return
  bTvSortLst  = self.VVdWHp(lines)
  lines, err = CCVnOk.VVYmvg(self.filePath, "bouquets.radio")
  if err:
   self.VVRGGb(err)
   return
  bRadSortLst = self.VVdWHp(lines)
  VVJpUa = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VV0hoF(f, mode, len(VVJpUa), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVJpUa.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VV0hoF(f, mode, len(VVJpUa), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VV0hoF(f, mode, len(VVJpUa), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVJpUa.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VV0hoF(f, mode, len(VVJpUa), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVJpUa:
   VVJpUa.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVJpUa): VVJpUa[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVJpUa):
     if key == os.path.basename(row[9]):
      VVJpUa = VVJpUa[:ndx+1] + lst + VVJpUa[ndx+1:]
      break
   for ndx, item in enumerate(VVJpUa): VVJpUa[ndx][0] = str(ndx + 1)
   VVcGiE = "#11000600"
   VVrjyr  = ("Show Services" , self.VVNc6a  , [], "Reading ..." )
   VVGySq = (""    , self.VV0Ywe, [])
   VVpxmm = ("Options"  , self.VVLVb4, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVRYg6  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFBxNx(self.SELF, None, title=self.Title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=24, VVrjyr=VVrjyr, VVGySq=VVGySq, VVpxmm=VVpxmm, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVmEJ8=VVcGiE, VVd8a3=VVcGiE, VVcGiE=VVcGiE, VVh96o="#00004455", VV5t00="#0a282828")
  else:
   self.VVRGGb("No valid bouquets in:\n\n%s" % self.filePath)
 def VVdWHp(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VV0Ywe(self, VVgAw8, title, txt, colList):
  FFPaL6(self.SELF, FFWkM4(txt), title=title)
 def VVLVb4(self, VVgAw8, title, txt, colList):
  mSel = CCwZHL(self.SELF, VVgAw8)
  if VVgAw8.VVhXSW:
   totSel = VVgAw8.VVeEeJ()
   if totSel: VVGuvj = [("Import %s Bouquet%s" % (FF4aCb(str(totSel), VV1udq), FFtCOg(totSel)), "imp")]
   else  : VVGuvj = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF4aCb(bName, VV1udq)
   VVGuvj = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF4idw, VVgAw8, BF(CCVnOk.VVAUCE, self.SELF, VVgAw8, self.filePath))}
  mSel.VV71Gx(VVGuvj, cbFncDict)
 def VVNc6a(self, VVgAw8, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCVnOk.VVYmvg(self.filePath, "lamedb")
   if err:
    self.VVRGGb(err)
    return
   dbServLst = CC1mtH.VV6ACj(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVgAw8.VVi9QZ()
   lines, err = CCVnOk.VVYmvg(self.filePath, os.path.basename(fName))
   if err:
    self.VVRGGb(err)
    return
   VVJpUa = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVJpUa.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVJpUa.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVJpUa.append((span.group(1).strip() or "-", "Stream Relay" if FFyCwy(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVJpUa.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVJpUa.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CC1mtH.VVCNeb(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVJpUa.append((name.strip() or "-", FFUQ44(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVJpUa):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCVnOk.VVYmvg(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVJpUa[ndx] = (bName, descr)
   if VVJpUa:
    VVcGiE = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVRYg6 = (LEFT  , CENTER)
    FFBxNx(self.SELF, None, title="Services in : %s" % bName, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VVmEJ8=VVcGiE, VVd8a3=VVcGiE, VVcGiE=VVcGiE, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FF1lLq(VVgAw8, err, 1500)
  else : VVgAw8.VVOvTL()
 def VV0hoF(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVRGGb("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFyCwy(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV5Sg6(var):
   return str(var) if var else VVTjYX + str(var)
  totItem = VVc1MO + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVEkv6   , str(totBnb)
  elif isSubB : bColor, totBnb  = VV2Bne, "Sub-B."
  else  : bColor, totBnb = ""      , VV5Sg6(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV5Sg6(totDVB), VV5Sg6(totIptv), VV5Sg6(totSRelay), VV5Sg6(totLoc), VV5Sg6(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVAUCE(SELF, VVgAw8, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVgBUe + "bouquets.tv"
  radBouquetFile = VVgBUe + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFJBL5(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFJBL5(SELF, radBouquetFile, title=title)
   return
  isMulti = VVgAw8.VVhXSW
  if isMulti : rows = VVgAw8.VVXyrA()
  else  : rows = [VVgAw8.VVi9QZ()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFeF28(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFWkM4(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFWkM4(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVgBUe + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVgBUe + newFile
    CCVnOk.VVSANj(archPath, fName, VVgBUe, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FF5wJY(tvBouquetFile)
   FF5wJY(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCVnOk.VVTKkT(SELF, archPath, bList)
   FF9bFs()
  txt  = FF4aCb("Added:\n", VV2Bne)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF4aCb("Imported to lamedab:\n", VV2Bne)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF4aCb("Missing from archived lamedb:\n", VVEkv6)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFPaL6(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVTKkT(SELF, archPath, bList):
  VV6Klt, err = CC1mtH.VVnpAH(SELF, VVgAsb=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CC1mtH.VVBLdE(VV6Klt, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF8p4l(VVgBUe + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CC1mtH.VVCNeb(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CC1mtH.VV7crU(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCVnOk.VVFR5z(archPath, dbName)
   CCVnOk.VVSANj(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CC1mtH.VVBLdE(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CC1mtH.VVBLdE(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CC1mtH.VVBLdE(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CC1mtH.VVBLdE(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFOHeU(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VV6Klt + ".tmp"
   lines   = FF8p4l(VV6Klt)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FF7Jdu("mv -f '%s' '%s'" % (tmpDbFile, VV6Klt))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVXPUo(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVFR5z(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVSANj(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVYmvg(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCsx09():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVBJsL()
 def VVBJsL(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVUQaR(self):
  FF4idw(self, self.VVYsu8)
 def VVYsu8(self):
  if pathExists(self.projMainPath):
   lst = FFgLXS(self.projMainPath)
   VVGuvj = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVGuvj.append((prName, prName))
   if VVGuvj:
    VVGuvj.sort(key=lambda x: x[1].lower())
    VVwpVu = self.VVh3mb
    VVIY0g = ("Add new project", self.VVllR1)
    VVBLXn= ("Delete Project" , self.VVtzO1)
    self.projMenu = FFSiXW(self, None, VVGuvj=VVGuvj, width=1100, VVwpVu=VVwpVu, VVIY0g=VVIY0g, VVBLXn=VVBLXn, minRows=5, VVmEJ8="#22111133", VVd8a3="#22111133")
   else:
    FFZRvh(self, self.VV2VcW, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVuM7o("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VV2VcW(self)    : FF4idw(self, BF(self.VVQBVk))
 def VVllR1(self, VVUD8b, item) : FF4idw(self.projMenu, BF(self.VVQBVk))
 def VVQBVk(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVpopy(name)
 def VVpopy(self, name, cbFnc=None):
  FFrwu2(self, cbFnc or self.VVWLJZ, defaultText=name, title="New Project Name", message="Enter project name")
 def VVWLJZ(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFZRvh(self, BF(self.VVpopy, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FF8rLT(path)
    if err:
     self.VVuM7o("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVxPHN((item, item), isSort=True)
     else   : self.VVUQaR()
 def VVtzO1(self, VVUD8b, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFQkyh(path)
    FFZRvh(self, BF(self.VVTKRI, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVTKRI(self, path):
  if FF7Jdu("rm -rf '%s'" % path):
   self.projMenu.VVTTLJ()
 def VVh3mb(self, item=None):
  if item:
   VVUD8b, txt, Dir, ndx = item
   self.VVBJsL()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVqXR1
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF8p4l(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFfB6C()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVdH60()
   else      : self.VVuM7o("Cannot create project file:\n\n%s" % self.projFile)
 def VVdH60(self, VVUD8b=None, jmpDict=None):
  FF4idw(VVUD8b or self.projTable or self, BF(self.VVzEIJ, jmpDict))
 def VVzEIJ(self, jmpDict):
  self.VVBJsL()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF8p4l(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVGrCN(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVuM7o('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFgx6P(path)
    if sz > -1: size = CCZHbk.VVi3go(sz, mode=4)
    else   : size = FF4aCb("Size error", VVEkv6)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF8p4l(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VV5LbE(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVb95O(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FF4aCb("Unknown value", VVEkv6), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FF4aCb(rem, VVEkv6), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVJpUa = pkgRows
  VVJpUa.extend(actnRows)
  VVJpUa.extend(ctrlRows)
  VVJpUa.extend(fileRows)
  VVJpUa.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVJpUa):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FF4aCb("Valid", VV1udq), " ... " + Remarks if Remarks else "")
    VVJpUa[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVFDhD(VVJpUa, tableRefreshCB=BF(self.VVI4Y7, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVGySq = (""     , self.VV6tnb   , [])
   menuButtonFnc = (""     , self.VVbgP0   , [])
   VVFkw1 = ("Create Package"  , self.VVJqV3 , [])
   VVpxmm = ("Post Install Action", self.VVLCWx, [])
   VV1SrQ = ("Edit File"   , self.VVY9zO  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVRYg6 = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, width=1850, height=1040, VVCppa=26, VVGySq=VVGySq, menuButtonFnc=menuButtonFnc, VVFkw1=VVFkw1, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, searchCol=2
         , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#00664411", VV5t00="#00444444", VVO2zv="#08442211")
   self.projTable.VVbjQL(self.VVelUU, True)
 def VVI4Y7(self, jmpDict, VVgAw8, title, txt, colList):
  self.projTable.VVAyL9(jmpDict)
 def VVelUU(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVi9QZ()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVGrCN(self, line):
  def VV7OJR(patt, val, Len):
   if len(val) < Len   : return FF4aCb("Length error" , VVEkv6)
   elif not iMatch(patt, val) : return FF4aCb("Invalid format" , VVEkv6)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VV7OJR(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VV7OJR(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VV5LbE(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFDvFF(path)
  path = FFaYmq(path)
  c = VVEkv6
  if   typ == "Mount" : rem = FF4aCb("Not allowed", c)
  elif not typ  : rem = FF4aCb("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FF4aCb("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFicDa(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFDvFF(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FF4aCb("Not allowed", c)
     elif targetType == "Directory" : sz = FFicDa(targetPath)
     elif targetType == "File"  : sz = FFgx6P(targetPath)
     else       : sz, rem = FFgx6P(path), FF4aCb("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFgx6P(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCZHbk.VVi3go(sz, mode=4)
     else:
      size = FF4aCb("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVb95O(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVY9zO(self, VVgAw8, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCrb0k(self, path, VVHoAX=self.VVpnK2, curRowNum=lineNdx)
  else    : FFJBL5(self, path)
 def VVpnK2(self, fileChanged):
  if fileChanged:
   self.VVdH60()
 def VVuM7o(self, txt):
  FFeF28(self, txt, title=self.projTitle)
 def VV6tnb(self, VVgAw8, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VV2Bne
  s  = FFeaY5("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFeaY5("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCZHbk.VVi3go(self.projFilesSize))
  FFPaL6(self, s, title="Project Info", width=1600)
 def VVbgP0(self, VVgAw8, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVE7n3, VVXSg2, VV2Bne
  VVGuvj = []
  VVGuvj.append((c1 + "Add Resource File"  , "addFile" ))
  VVGuvj.append((c1 + "Add Resource Directory" , "addDir" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Package Name"   , "pkgNam" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Add Dependency"   , "addDep" ))
  VVGuvj.append((c2 + "Remove Dependency"  , "delDep" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVGuvj.append(FFUHeM('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVEkv6))
  FFSiXW(self, self.VVIZAC, VVGuvj=VVGuvj, width=1050, title="Options", VVmEJ8="#11001122", VVd8a3="#11001122")
 def VVIZAC(self, item=None):
  if item:
   if   item == "addFile" : self.VVpxPd(False)
   elif item == "addDir" : self.VVpxPd(True)
   elif item == "pkgNam" : self.VVgZZq()
   elif item == "addDep" : FF4idw(self.projTable, self.VVIZJL)
   elif item == "delDep" : self.VV01yw()
   elif item == "ctrlFMan" : self.VVGInC()
   elif item == "ctrlImprt": FF4idw(self.projTable, self.VVXeTs)
   elif item == "ctrlUndo" : self.VVa6KO()
   elif item == "delRow" : self.VV5CWI()
 def VVpxPd(self, isDir):
  Dir = FF78Uj(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVFstd, BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=Dir))
  else : self.session.openWithCallback(self.VVFstd, BF(CCZHbk, patternMode="all", VVYYtf=Dir))
 def VVFstd(self, path):
  if path:
   FFCRXL(CFG.lastPkgProjDir, path)
   self.VV0kuR(path, 2)
 def VVGInC(self):
  Dir = FF78Uj(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVIGOI, BF(CCZHbk, patternMode="pkgCtrl", VVYYtf=Dir))
 def VVIGOI(self, path):
  if path:
   FFCRXL(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FF7Jdu("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVdH60()
    self.projTable.VVAyL9({1:"Script", 2:fName})
 def VVXeTs(self):
  cmd = FFnws9(VVNP8B, "")
  if not cmd:
   FFDayU(self)
   return
  lst = FFkrzQ(cmd)
  if lst:
   err = CCZHbk.VVdoWo(lst, fromFind=False)
   if err:
    self.VVuM7o(err)
    return
   lst.sort()
   VVJpUa = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVJpUa.append(("", span.group(1), span.group(2)))
   if VVJpUa:
    VVdyRp = ("Import 'control' data", self.VVTv0C, [])
    VVpxmm = ("Package Info.", self.VVfWY0     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=30, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVwpP6=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVmEJ8="#22110011", VVd8a3="#22191111", VVcGiE="#22191111", VVh96o="#00003030", VV5t00="#00333333")
   else:
    self.VVuM7o("Cannot process installed packages !")
  else:
   self.VVuM7o("Cannot read installed packages !")
 def VVa6KO(self):
  if FF7Jdu("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVdH60(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVuM7o("Process Failed !")
 def VVTv0C(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VV6S1J, VVgAw8, colList[1]))
 def VV6S1J(self, VVgAw8, pkg):
  lines = []
  for line in FFkrzQ(FFNCOV(VVSyHw, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFZRvh(self, BF(self.VVAKeK, VVgAw8, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVuM7o("Cannot import from this package:\n\n%s" % pkg)
 def VVAKeK(self, VVgAw8, lines):
  VVgAw8.cancel()
  FFtbd7(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVdH60(jmpDict={1:"Control", 2:"Package"})
 def VV5CWI(self):
  lineNum = int(self.projTable.VVi9QZ()[0]) + 1
  FF7Jdu("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVdH60()
 def VV0kuR(self, line, jmp):
  if fileExists(self.projFile):
   FFtbd7(self.projFile)
   FF5wJY(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVdH60(jmpDict=jmpDict)
  else:
   FFJBL5(self, self.projFile, title=self.projTitle)
 def VVLCWx(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(FFUHeM("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVGuvj.append(FFUHeM("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVGuvj.append(FFUHeM("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVGuvj.append(FFUHeM("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVGuvj.append(FFUHeM("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFSiXW(self, self.VVzdhH, VVGuvj=VVGuvj, title="Action (after the package is installed/removed)")
 def VVzdhH(self, item=None):
  if item:
   if   item == "instNon" : self.VVrJy1("postinst", 0)
   elif item == "instRes" : self.VVrJy1("postinst", 1)
   elif item == "instReb" : self.VVrJy1("postinst", 2)
   elif item == "rmNon" : self.VVrJy1("postrm", 0)
   elif item == "rmRes" : self.VVrJy1("postrm", 1)
   elif item == "rmReb" : self.VVrJy1("postrm", 2)
 def VVrJy1(self, subj, val):
  if fileExists(self.projFile):
   lines = FF8p4l(self.projFile)
   FFtbd7(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VV0kuR("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVdH60()
 def VVgZZq(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVGuvj = []
  VVGuvj.append((pkg, pkg))
  VVGuvj.append(VVnek4)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VV2Bne if name == self.projPkg else ""
    VVGuvj.append((c + name, name))
   else:
    VVGuvj.append(VVnek4)
  FFSiXW(self, self.VV6aZV, VVGuvj=VVGuvj, title="Package Name")
 def VV6aZV(self, item=None):
  if item:
   self.VVFbN6("Package", item)
 def VVIZJL(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVGuvj = []
   for item in lst: VVGuvj.append((item, item))
   VVGuvj.sort(key=lambda x: x[0].lower())
   VVUD8b = FFSiXW(self, self.VViUYg, VVGuvj=VVGuvj, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVUD8b.VVgve4(self.projLastDepends)
  else:
   self.VVuM7o("Cannot read dependencies list !")
 def VViUYg(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF8p4l(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVFbN6("Depends", ", ".join(lst))
   else:
    FF1lLq(self.projTable, "Already added", 1500)
    self.projTable.VVAyL9({1:"Control", 2:"Depends"})
 def VV01yw(self):
  lst = []
  for row in self.projTable.VVYgJy():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVGuvj = []
   for item in lst: VVGuvj.append((item, item))
   FFSiXW(self, BF(self.VVe0Nx, lst), VVGuvj=VVGuvj, title="Remove Dependency")
  else:
   self.VVuM7o("No dependencies to remove !")
 def VVe0Nx(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVFbN6("Depends", ", ".join(lst))
   else:
    FF7Jdu("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVdH60()
 def VVFbN6(self, subj, val):
  lines = FF8p4l(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVdH60(jmpDict={1:"Control", 2:subj})
 def VVJqV3(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(("Create .ipk"  , "ipk"))
  VVGuvj.append(("Create .deb"  , "deb"))
  VVGuvj.append(("Create .tar.gz" , "tar"))
  FFSiXW(self, self.VVKpvP, VVGuvj=VVGuvj, width=500, title=self.projTitle)
 def VVKpvP(self, item=None):
  if item:
   FF4idw(self.projTable, BF(self.VVKGq4, item))
 def VVKGq4(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVuM7o("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVB3L1, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVB3L1, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVuM7o(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFTMeZ("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFlTM0(result  , VV1udq))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFlTM0(failed, VVs795))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFTMeZ("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVYgJy()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FF1NOx(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FF7Jdu(cmd) or not pathExists(ctrlDir):
   VVuM7o(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VV7OJR(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FF7Jdu("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VV7OJR(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FF5wJY(dstF)
   FF7Jdu("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FF6BOQ()
  if VVB3L1:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFf1mi("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FF1NOx(self, cmd)
class CCyvvH(Screen, CCsx09):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCsx09.__init__(self)
  c1, c2, c3, c4 = VVE7n3, VVXSg2, VVwWfr, VV2Bne
  VVGuvj = []
  VVGuvj.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c3 + "Remove Packages (show all)"     , "VVPVngsAll"  ))
  VVGuvj.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Update Packages List from Feed"    , "VVxWby"  ))
  VVGuvj.append((c2 + "Upgradable Packages"       , "VVa0mP" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Packaging Tool"         , "VVqOne"   ))
  VVGuvj.append(("Active Feeds"          , "VVYLa6"   ))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCG4Wp.VVgWsr(self.session)
   elif item == "downloadInstallPackages"  : FF4idw(self, BF(self.VVLjyJ, 0, ""))
   elif item == "VVPVngsAll"   : FF4idw(self, BF(self.VVLjyJ, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF4idw(self, BF(self.VVLjyJ, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVxWby"   : CCyvvH.VVxWby(self)
   elif item == "VVa0mP"  : FF4idw(self, self.VVa0mP)
   elif item == "packageCreator"    : self.VVUQaR()
   elif item == "VVqOne"    : self.VVqOne()
   elif item == "VVYLa6"    : FF4idw(self, self.VVYLa6)
   else          : self.close()
 def VVYLa6(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVJpUa = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVJpUa.append((os.path.basename(path), str(tot)))
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVRYg6 = (LEFT  , CENTER )
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, width=1000, VVCppa=26, VV9SwC=2)
  else:
   self.VVuM7o("Cannot read packages list !")
 def VVa0mP(self, VVgAw8=None):
  lst = FFkrzQ(FFnws9(VV2EeW, ""))
  VVJpUa = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVJpUa.append((str(len(VVJpUa) + 1), pkg, curV, newVer))
   if VVJpUa:
    if VVgAw8:
     VVgAw8.VVFDhD(VVJpUa, VVLMQ5Msg=True)
    else:
     bg = "#00221111"
     VVdyRp = ("Upgrade", self.VVUMXD   , [])
     VVpxmm = ("Package Info.", self.VVfWY0 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVRYg6 = (CENTER , LEFT  , LEFT  , LEFT   )
     FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, width=1700, VVCppa=26, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVOisu=True, VVAAbT=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVSaWg="#00ffff55", VVh96o="#00003040")
  if not VVJpUa:
   FFFSea(self, "Nothing to upgrade", 1500)
   if VVgAw8: VVgAw8.cancel()
 def VVUMXD(self, VVgAw8, title, txt, colList):
  pkg = colList[1]
  cmd = FFNCOV(VVy8Lf, pkg)
  if cmd : FF1NOx(self, cmd, title="Installing : %s" % pkg, VVdenE=BF(self.VVa0mP, VVgAw8))
  else : FFDayU(SELF)
 def VVqOne(self):
  pkg = FF9QPZ()
  aptT = "apt - Advanced Package Tool" if FFGbNH("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFDx6X(self, txt or "No packaging tools found!")
 def VVLjyJ(self, mode, grep, VVgAw8=None, title=""):
  if   mode == 0: cmd = FFnws9(VVpuWY    , grep)
  elif mode == 1: cmd = FFnws9(VVNP8B , grep)
  elif mode == 2: cmd = FFnws9(VVNP8B , grep)
  if not cmd:
   FFDayU(self)
   return
  VVJpUa = FFkrzQ(cmd)
  if VVJpUa:
   err = CCZHbk.VVdoWo(VVJpUa, fromFind=False)
   if err:
    FFeF28(self, err)
    return
  else:
   if VVgAw8: VVgAw8.VVOvTL()
   FFeF28(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVWhjq  = []
  for item in VVJpUa:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVWhjq.append((name, package, version))
  if mode > 0:
   extensions = FFkrzQ("ls %s -l | grep '^d' | awk '{print $9}'" % VV4i8I)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVWhjq:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVVBEw: name += "el"
      VVWhjq.append((name, VV4i8I + item, "-"))
   systemPlugins = FFkrzQ("ls %s -l | grep '^d' | awk '{print $9}'" % VVzDIh)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVWhjq:
      if item.lower() == row[0].lower():
       break
     else:
      VVWhjq.append((item, VVzDIh + item, "-"))
  if not VVWhjq:
   FFeF28(self, "No packages found!")
   return
  if VVgAw8:
   VVWhjq.sort(key=lambda x: x[0].lower())
   VVgAw8.VVFDhD(VVWhjq, title)
  else:
   widths = (20, 50, 30)
   VVdyRp = None
   VV1SrQ = None
   if mode == 0:
    VVFkw1 = ("Install" , self.VVRsAd   , [])
    VVdyRp = ("Download" , self.VVPA3o   , [])
    VV1SrQ = ("Filter"  , self.VVgJkq , [])
   elif mode == 1:
    VVFkw1 = ("Uninstall", self.VVPVng, [])
   elif mode == 2:
    VVFkw1 = ("Uninstall", self.VVPVng, [])
    widths= (18, 57, 25)
   VVWhjq.sort(key=lambda x: x[0].lower())
   VVpxmm = ("Package Info.", self.VVfWY0, [])
   header   = ("Name" ,"Package" , "Version" )
   FFBxNx(self, None, header=header, VVWhjq=VVWhjq, VVmQwL=widths, VVCppa=28, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVwpP6=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVmEJ8="#22110011", VVd8a3="#22191111", VVcGiE="#22191111", VVh96o="#00003030", VV5t00="#00333333")
 def VVfWY0(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVEwSC, VVgAw8, colList[1]))
 def VVEwSC(self, VVgAw8, pkg):
  if pathExists(pkg):
   pkg, err = CCyvvH.VV90G2(pkg)
   if err:
    FFFSea(VVgAw8, err, 1000)
    return
  CCyvvH.VVPWOb(self, pkg)
 def VVgJkq(self, VVgAw8, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVGuvj = []
  VVGuvj.append(("All Packages", "all"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVGuvj.append(VVnek4)
  for word in words:
   VVGuvj.append((word, word))
  FFSiXW(self, BF(self.VV4RzE, VVgAw8), VVGuvj=VVGuvj, title="Select Filter")
 def VV4RzE(self, VVgAw8, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF4idw(VVgAw8, BF(self.VVLjyJ, 0, grep, VVgAw8, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVPVng(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VV9UzV, VVgAw8, colList[1]))
 def VV9UzV(self, VVgAw8, package):
  if pathExists(package):
   pkg, err = CCyvvH.VV90G2(package)
   if pkg:
    package = pkg
  if package.startswith((VV4i8I, VVzDIh)):
   FFZRvh(self, BF(self.VVRCZl, VVgAw8, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVGuvj = []
   VVGuvj.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVGuvj.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVGuvj.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFSiXW(self, BF(self.VVxjUz, VVgAw8, package), VVGuvj=VVGuvj)
 def VVRCZl(self, VVgAw8, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVH8C3)
  FF1NOx(self, cmd, VVdenE=BF(self.VVEZ6z, VVgAw8))
 def VVxjUz(self, VVgAw8, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVK3Uz
   elif item == "remove_ForceRemove"  : cmdOpt = VV3cr8
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVphKS
   FFZRvh(self, BF(self.VV7u4e, VVgAw8, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV7u4e(self, VVgAw8, package, cmdOpt):
  self.lastSelectedRow = VVgAw8.VVmG96()
  cmd = FFNCOV(cmdOpt, package)
  if cmd : FF1NOx(self, cmd, VVdenE=BF(self.VVEZ6z, VVgAw8))
  else : FFDayU(self)
 def VVEZ6z(self, VVgAw8):
  VVgAw8.cancel()
  FFWolN()
 def VVRsAd(self, VVgAw8, title, txt, colList):
  package  = colList[1]
  VVGuvj = []
  VVGuvj.append(("Install Package"        , "install_CheckVersion" ))
  VVGuvj.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVGuvj.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVGuvj.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVGuvj.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFSiXW(self, BF(self.VVwUzH, package), VVGuvj=VVGuvj)
 def VVwUzH(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVy8Lf
   elif item == "install_ForceReinstall" : cmdOpt = VVUhs4
   elif item == "install_ForceOverwrite" : cmdOpt = VVnGKI
   elif item == "install_ForceDowngrade" : cmdOpt = VVZvdb
   elif item == "install_IgnoreDepends" : cmdOpt = VVvSBf
   FFZRvh(self, BF(self.VVeXXX, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVeXXX(self, package, cmdOpt):
  cmd = FFNCOV(cmdOpt, package)
  if cmd : FF1NOx(self, cmd, VVdenE=FFWolN, checkNetAccess=True)
  else : FFDayU(self)
 def VVPA3o(self, VVgAw8, title, txt, colList):
  package  = colList[1]
  FFZRvh(self, BF(self.VVV0Vi, package), "Download Package ?\n\n%s" % package)
 def VVV0Vi(self, package):
  if CCGRJR.VVeolD():
   cmd = FFNCOV(VVy8ug, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFlTM0(success, VV1udq))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFlTM0(fail, VVs795))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF1NOx(self, cmd, VVRc2Y=[VVs795, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFDayU(self)
  else:
   FFeF28(self, "No internet connection !")
 @staticmethod
 def VVxWby(SELF):
  cmd = FFnws9(VVaMYp, "")
  if cmd : FF1NOx(SELF, cmd, checkNetAccess=True, title="Available Packages List Upadate")
  else : FFDayU(SELF)
 @staticmethod
 def VV90G2(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFkrzQ(FFNCOV(VVhuDL, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVPWOb(SELF, package, title=""):
  title = title or package
  infoCmd  = FFNCOV(VVSyHw, package)
  filesCmd = FFNCOV(VVpsdf, package)
  listInstCmd = FFnws9(VVNP8B, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFl8Lk(VVc1MO)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFlTM0(notInst, VVEkv6))
   cmd += "else "
   cmd +=   FFCIAK("System Info", VVc1MO)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFCIAK("Related Files", VVc1MO)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFbHAT(SELF, cmd, title=title)
  else:
   FFDayU(SELF, title=title)
class CCRasO():
 def VV7Cff(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVLCU5()
 def VVLCU5(self):
  files = FF2oot(VVmc3z, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVGuvj = []
   for fil in files:
    VVGuvj.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVmEJ8, VVd8a3 = "#22221133", "#22221133"
   else    : VVmEJ8, VVd8a3 = "#22003344", "#22002233"
   VVIY0g  = ("Add new File", self.VVGZt9)
   FFSiXW(self, self.VVTHk3, VVGuvj=VVGuvj, width=1100, VVIY0g=VVIY0g, VV51Jr="", minRows=4, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3)
  else:
   FFZRvh(self, self.VVbGAE, "No files found.\n\nCreate a new file ?")
 def VVbGAE(self):
  path = self.VVAFbN()
  if fileExists(path) : self.VVLCU5()
  else    : FF1lLq(self, "Cannot create file", 1500)
 def VVGZt9(self, VVUD8b, path):
  path = self.VVAFbN()
  VVUD8b.VVxPHN((os.path.basename(path), path), isSort=True)
 def VVAFbN(self):
  path = "%s%s%s.xml" % (VVmc3z, self.shareFilePrefix, FFguCY())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVTHk3(self, path=None):
  if path:
   FF4idw(self, BF(self.VVTOEW, path))
 def VVTOEW(self, path):
  if not fileExists(path):
   FFJBL5(self, path)
   return
  elif not CCZHbk.VVWzKq(self, path, FFVLF6()):
   return
  else:
   self.shareFilePath = path
  if not CCAhZF.VVWJ4w(self):
   return
  tree = CC1mtH.VVoOLm(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCQrUI.VVnGLs()
  def VV1pWY(refCode):
   if   FFwPKf(refCode): return FF4aCb("DVB", VVE7n3)
   elif refCode in refLst     : return FF4aCb("IPTV", VVE7n3)
   else         : return ""
  VVJpUa= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVArUM(ch)
   if ok:
    srcTxt = VV1pWY(srcRef)
    dstTxt = VV1pWY(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVJpUa:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVJpUa.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVJpUa:
   if self.shareIsRef : VVmEJ8, VVd8a3, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVmEJ8, VVd8a3, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VViila = (""    , BF(self.VVw667, dupl), [])
   VVGySq = (""    , self.VVeAwg    , [])
   VVFkw1 = ("Delete Entry" , self.VVCk4L   , [])
   VVdyRp = ("Add Entry"  , self.VVEpUS   , [])
   VVpxmm = (optTxt   , self.VVDF25  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVRYg6 = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVgAw8 = FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=24, VViila=VViila, VVGySq=VVGySq, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVOisu=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVd8a3, VVh96o="#0a000000")
  else:
   FFeF28(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVw667(self, dupl, VVgAw8, title, txt, colList):
  if dupl:
   VVgAw8.VVmaQr("Skipped %d duplicate%s" % (dupl, FFtCOg(dupl)), 2000)
 def VVeAwg(self, VVgAw8, title, txt, colList):
  def VV1pWY(key, val): return "%s\t: %s\n" % (key, val or FF4aCb("?", VVT2Mp))
  Keys = VVgAw8.VVXWkC()
  Vals = VVgAw8.VVi9QZ()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VV1pWY(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VV1udq, VVT2Mp
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFPaL6(self, txt + txt1, title=title)
 def VVArUM(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVCk4L(self, VVgAw8, title, txt, colList):
  if VVgAw8.VVmG96() == 0 and VVgAw8.VVPGr2() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFZRvh(self, BF(self.VVfdtM, isLast, VVgAw8), ques)
 def VVfdtM(self, isLast, VVgAw8):
  if isLast:
   FFOHeU(self.shareFilePath)
   VVgAw8.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVgAw8.VVi9QZ()
   if self.VVg660(srcName, srcRef, dstName, dstRef):
    VVgAw8.VVGSM2()
    VVgAw8.VVzOTd()
    FF1lLq(VVgAw8, "Deleted", 500, isGrn=True)
   else:
    FF1lLq(VVgAw8, "Cannot delete from file", 2000)
 def VVEpUS(self, VVgAw8, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVbTkS(VVgAw8, isDvb=True)
  else    : self.VVwnN0(VVgAw8, "Source Channel", "#22003344", "#22002233")
 def VVwnN0(self, mainTableInst, title, VVmEJ8, VVd8a3):
  FFSiXW(self, BF(self.VVqXiZ, mainTableInst, title), VVGuvj=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3)
 def VVqXiZ(self, mainTableInst, title, item=None):
  if item:
   FF4idw(mainTableInst, BF(self.VV40E1, mainTableInst, title, item), clearMsg=False)
 def VV40E1(self, mainTableInst, title, item):
  FF1lLq(mainTableInst)
  if item == "DVB": self.VVbTkS(mainTableInst, isDvb=True)
  else   : self.VVbTkS(mainTableInst, isDvb=False)
 def VVM4Wt(self, mainTableInst, chType, VVgAw8, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVgAw8.VVmG96()
  if   chType == "DVB" : FFCRXL(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFCRXL(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVYgJy()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFeF28(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVthH7(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVFU6P((str(mainTableInst.VVPGr2() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FF1lLq(mainTableInst, "Added", 500, isGrn=True)
     else:
      FF1lLq(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FF1lLq(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVbTkS(mainTableInst, isDvb=False)
   else    : FFJVhm(BF(self.VVwnN0, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVgAw8.cancel()
 def VVrOob(self, item, VVgAw8, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVgAw8.VVAGTP(ndx)
 def VVbTkS(self, VVgAw8, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVM4Wt, VVgAw8, typ)
  doneFnc = BF(self.VVrOob, typ)
  if isDvb: CCRasO.VVgZlf(VVgAw8 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCRasO.VVQbts(VVgAw8, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVgZlf(SELF, title, okFnc, doneFnc=None):
  FF4idw(SELF, BF(CCRasO.VV2Q1O, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VV2Q1O(SELF, title, okFnc, doneFnc=None):
  VVJpUa, err = CC1mtH.VVb6EG(SELF, CC1mtH.VVNvWx)
  if VVJpUa:
   color = "#0a000022"
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVrjyr = ("Select" , okFnc, [])
   VViila= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVRYg6 = (LEFT  , LEFT  , CENTER, LEFT    )
   FFBxNx(SELF, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVmEJ8=color, VVd8a3=color, VVcGiE=color, VVrjyr=VVrjyr, VViila=VViila, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFeF28(SELF, "No DVB Services !")
 @staticmethod
 def VVQbts(SELF, title, okFnc, doneFnc=None):
  FF4idw(SELF, BF(CCRasO.VVPELT, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVPELT(SELF, title, okFnc, doneFnc=None):
  VVJpUa = CCRasO.VVSB4c()
  if VVJpUa:
   color = "#0a112211"
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVrjyr = ("Select" , okFnc, [])
   VViila= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFBxNx(SELF, None, title=title, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=26, VVmEJ8=color, VVd8a3=color, VVcGiE=color, VVrjyr=VVrjyr, VViila=VViila, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFeF28(SELF, "No IPTV Services !")
 @staticmethod
 def VVSB4c():
  VVJpUa = []
  files  = CCCW9K.VVEC3O()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFhqv7(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVQdU6 = span.group(1)
    else : VVQdU6 = ""
    VVQdU6_lCase = VVQdU6.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVJpUa.append((chName, VVQdU6, url, refCode))
  return VVJpUa
 def VVthH7(self, srcName, srcRef, dstName, dstRef):
  tree = CC1mtH.VVoOLm(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVswIg(tree, root)
  return True
 def VVg660(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CC1mtH.VVoOLm(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVArUM(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVswIg(tree, root)
  return found
 def VVswIg(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CC1mtH.VV8UdP(xmlTxt)
  parser = CC1mtH.CCkw7N()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVDF25(self, VVgAw8, title, txt, colList):
  if self.onlyEpg:
   self.VVSaGI(VVgAw8, "epg")
  else:
   if self.shareIsRef:
    FFZRvh(self, BF(FF4idw, VVgAw8, BF(self.VVKjxe, VVgAw8)), "Copy all References from Source to Destination ?")
   else:
    VVGuvj = []
    VVGuvj.append(("Copy EPG\t (All List)" , "epg"  ))
    VVGuvj.append(("Copy Picons\t (All List)" , "picon" ))
    FFSiXW(self, BF(self.VVSaGI, VVgAw8), VVGuvj=VVGuvj, width=1000)
 def VVSaGI(self, VVgAw8, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVv4Kq  , "EPG"
   elif item == "picon": fnc, txt = self.VVc77R , "PIcons"
   title = "Copy %s" % txt
   tot   = VVgAw8.VVPGr2()
   FFZRvh(self, BF(FF4idw, VVgAw8, BF(fnc, VVgAw8, title)), "Overwrite %s for %d Service%s ?" % (FF4aCb(txt, VVc1MO), tot, FFtCOg(tot)), title=title)
 def VVKjxe(self, VVgAw8):
  files = CCCW9K.VVEC3O()
  totChange = 0
  if files:
   for path in files:
    txt = FFhqv7(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgAw8.VVYgJy():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FF9bFs()
  tot = VVgAw8.VVPGr2()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFPaL6(self, txt)
 def VVc77R(self, VVgAw8, title):
  if not iCopyfile:
   FFeF28(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCnBmO.VVYQsq()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgAw8.VVYgJy():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVgAw8.VVPGr2()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFPaL6(self, txt, title=title)
 def VVv4Kq(self, VVgAw8, title):
  txt, err = CCTnwS.VVktyd(VVgAw8, title)
  if err : FFeF28(self, err, title=title)
  else : FFPaL6(self, txt, title=title)
 class CCkw7N(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVoOLm(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CC1mtH.CCkw7N())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF4aCb("XML Parse Error in:", VVT2Mp), path)
   txt += "%s\n%s\n\n" % (FF4aCb("Error:", VVT2Mp), str(e))
   FFPaL6(SELF, txt, VVcGiE="#11220000", title=title)
   return None
 @staticmethod
 def VV8UdP(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCTnwS(Screen, CCRasO):
 VV2nFy  = "BDTSE"
 VVlosd   = "save"
 VV6qO7   = "load"
 VVwK9Q  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCTnwS.VVgSm7()
  qUrl, decodedUrl, iptvRef = CCCW9K.VVFm8X(self)
  VVGuvj = []
  VVGuvj.append((VVE7n3 + "Cache File Info." , "inf"))
  VVGuvj.append(VVnek4)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVGuvj.append(FFUHeM("Save EPG to File%s" % fTxt , self.VVlosd, valid))
  VVGuvj.append(FFUHeM("Load EPG from File%s" % fTxt , self.VV6qO7, valid))
  VVGuvj.append(VVnek4)
  VVGuvj.append((VVEkv6 + "Delete EPG (from RAM only)", self.VVwK9Q))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVGuvj.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Translate Current Channel EPG %s(Experimental)" % VVEkv6, "VV5jyM"))
  FFOUwv(self, VVGuvj=VVGuvj)
  self.onShown.append(self.VVy4Yl)
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVYhZY()
   elif item in (self.VVlosd, self.VV6qO7, self.VVwK9Q):
    reset = item == self.VV6qO7
    FFZRvh(self, BF(FF4idw, self, BF(self.VVJIZu, item, reset)), VVrAp2="Continue ?")
   elif item == "refreshIptvEPG"  : CCCW9K.VVM8NU(self)
   elif item == "VV5jyM" : self.VV5jyM()
   elif item == "copyEpg"    : self.VV7Cff(False, onlyEpg=True)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VVJIZu(self, act, reset=False):
  ok = CCTnwS.VVSDdz(act)
  if ok:
   if reset:
    CCTnwS.VVwCcz(self)
   FFDx6X(self, "Done")
  else:
   FFDx6X(self, "Failed!")
 def VVYhZY(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCTnwS.VVgSm7()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF4aCb("File not found (check System EPG settings).", VVEkv6))
   FFPaL6(self, txt, title=title)
  else:
   FFeF28(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVLUpB():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VV5jyM(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVrjyr  = (""  , BF(self.VVXjkD, title, True) , [])
  VVdyRp = ("Start" , BF(self.VVXjkD, title, False), [])
  VV1SrQ = ("Change Language", self.VVpAGs      , [])
  widths  = (70 , 30)
  VVRYg6 = (LEFT , CENTER)
  FFBxNx(self, None, title=title, VVWhjq=self.VV9FJx(), VVRYg6=VVRYg6, VVmQwL=widths, width=1200, vMargin=20, VVCppa=30, VVrjyr=VVrjyr, VVdyRp=VVdyRp, VV1SrQ=VV1SrQ, VV9SwC=2
    , VVmEJ8="#11201010", VVd8a3=bg, VVcGiE=bg, VVh96o="#00004455", VV5t00=bg)
 def VV9FJx(self):
  Def, ch = "DISABLED", dict(CCTnwS.VVLUpB())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVWhjq = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVWhjq
 def VVpAGs(self, VVgAw8, title, txt, colList):
  ndx = VVgAw8.VVmG96()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCE4DO.VV4APY(self, confItem, title, lst=CCTnwS.VVLUpB(), cbFnc=BF(self.VV7kb3, VVgAw8), isSave=True)
 def VV7kb3(self, VVgAw8):
  for ndx, row in enumerate(self.VV9FJx()):
   VVgAw8.VV9eWy(ndx, row)
 def VVXjkD(self, Title, isAsk, VVgAw8, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FF1lLq(VVgAw8, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
   refCode, evList, err = CCTnwS.VVwFuK(refCode)
   fnc = BF(self.VVvFR6, Title, refCode, evList, VVgAw8)
   if   err : FFeF28(self, err, title=Title)
   elif isAsk : FFZRvh(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVvFR6(self, title, refCode, evList, VVgAw8):
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVLqMN, evList)
      , VVHoAX = BF(self.VVwP37, title, refCode))
  VVgAw8.cancel()
 def VVLqMN(self, evList, VVXuS2):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVXuS2.VVhaSh(totEv)
  VVXuS2.VVoBtV = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCTnwS.VVfo56(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1)
   VVXuS2.VVDtzG(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVXuS2.VVoBtV = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVwP37(self, title, refCode, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVoBtV
  if newLst: totEv, totOK = CCTnwS.VVKa2B(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCTnwS.VVHTH6()
   CCTnwS.VVwCcz(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFPaL6(self, txt, title=title)
 @staticmethod
 def VVfo56(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VV1pWY(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCTnwS.VVyOnl(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VV1pWY, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVyOnl(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFhukT(txt))
   txt, err = CCCW9K.VVxp5A(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFb0uP(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCTnwS.VV6jKN(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVgSm7():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFgx6P(path)
   szTxt = CCZHbk.VVi3go(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVk585():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVHTH6(): CCTnwS.VVSDdz(CCTnwS.VVlosd)
 @staticmethod
 def VVSDdz(act):
  ec, inst = CCTnwS.VVk585()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVwCcz(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVwFuK(refCode):
  ec, inst = CCTnwS.VVk585()
  if inst:
   try:
    evList = inst.lookupEvent([CCTnwS.VV2nFy, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVKa2B(refCode, events, longDescDays=0):
  ec, inst = CCTnwS.VVk585()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVO3yi(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCTnwS.VVk585()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCTnwS.VVa30s(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCM3PM.CCTnwS(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVa30s(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCTnwS.VVJ932(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VV0Kq4(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCTnwS.VVk585()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCTnwS.VVa30s(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFrH35(evTime)
       evEndTxt  = FFrH35(evEnd)
       evDurTxt  = FFZ4gz(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFZ4gz(evPos)
        evRem = evEnd - now
        evRemTxt = FFZ4gz(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFZ4gz(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVJ932(event):
  genre = PR = ""
  try:
   genre  = CCTnwS.VVLEiV(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCTnwS.VVHL0O(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVHL0O(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVLEiV(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCTnwS.VVBoFa()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVBoFa():
  path = VVqXR1 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFhqv7(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFhqv7(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVktyd(VVgAw8, title):
  ec, inst = CCTnwS.VVk585()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgAw8.VVYgJy():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCTnwS.VV2nFy, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCTnwS.VVKa2B(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCTnwS.VVHTH6()
  txt  = "Services\t: %d\n"  % VVgAw8.VVPGr2()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VV4WHJ(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCTnwS.VV0sQt(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCTnwS.VV0sQt(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCTnwS.VV0sQt(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VV0sQt(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTnwS.VVa30s(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCTnwS.VVfo56(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF4aCb(evName, VV2Bne)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF4aCb(evNameTransl, VV2Bne))
    if evTime           : txt += "Start Time\t: %s\n" % FFrH35(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFrH35(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFZ4gz(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFZ4gz(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFZ4gz(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF4aCb(evShort, VVXSg2)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF4aCb(evDesc , VVXSg2)
    if txt:
     txt = FF4aCb("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VV2Bne) + txt
  return txt
 @staticmethod
 def VV6jKN(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CC1mtH(Screen, CCRasO):
 VVprEj  = 0
 VVv86I = 1
 VVfrtM  = 2
 VVMWrd  = 3
 VVeHdb = 4
 VVUq4c = 5
 VVzVs0 = 6
 VVNvWx   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVCeUI = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVGuvj = self.VV6wFG()
  FFOUwv(self, VVGuvj=VVGuvj, title="Services/Channels")
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self["myMenu"].setList(self.VV6wFG())
  FFMOVh(self["myMenu"])
  FFMHNW(self)
 def VV6wFG(self):
  VVGuvj = []
  c = VVE7n3
  VVGuvj.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVGuvj.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVGuvj.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVGuvj.append(VVnek4)
  c = VV2Bne
  VVGuvj.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVGuvj.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVGuvj.append((VVT2Mp + "More tables ..."     , "VVit6Z"    ))
  c = VVXSg2
  VVGuvj.append(VVnek4)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVGuvj.append((c + txt          , "VVHScl"  ))
  else : VVGuvj.append((txt           ,          ))
  VVGuvj.append((c + 'Export Services to "channels.xml"'    , "VVLfpw"      ))
  VVGuvj.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVwWfr
  VVGuvj.append(VVnek4)
  VVGuvj.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVGuvj.append((c + "Invalid Services Cleaner"       , "VVtARJ"    ))
  c = VVwWfr
  VVGuvj.append(VVnek4)
  VVGuvj.append((c + "Delete Channels with no names"     , "VVBq6i"    ))
  VVGuvj.append((c + "Delete Empty Bouquets"       , "VVBN4a"     ))
  VVGuvj.append(VVnek4)
  VV6Klt, VVJSdi = CC1mtH.VV1ktS()
  if fileExists(VV6Klt):
   enab = fileExists(VVJSdi)
   if enab: VVGuvj.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVGuvj.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVGuvj.append(("Reset Parental Control Settings"      , "VVESHP"    ))
  VVGuvj.append(("Reload Channels and Bouquets"       , "VVEVlf"      ))
  return VVGuvj
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCP76G.VVBpiW(self.session)
   elif item == "openSignal"       : FFF0Cd(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFw3XJ(self, fncMode=CCM3PM.VVyGH2)
   elif item == "lameDB_allChannels_with_refCode"  : FF4idw(self, self.VV2GM8)
   elif item == "lameDB_allChannels_with_tranaponder" : FF4idw(self, self.VVKOzz)
   elif item == "VVit6Z"     : self.VVit6Z()
   elif item == "VVHScl"  : CCVnOk.VVHScl(self)
   elif item == "VVLfpw"      : self.VVLfpw()
   elif item == "copyEpgPicons"      : self.VV7Cff(False)
   elif item == "SatellitesCleaner"     : FF4idw(self, self.FF4idw_SatellitesCleaner)
   elif item == "VVtARJ"    : FF4idw(self, BF(self.VVtARJ))
   elif item == "VVBq6i"    : FF4idw(self, self.VVBq6i)
   elif item == "VVBN4a"     : self.VVBN4a(self)
   elif item == "enableHiddenChannels"     : self.VVdot7(True)
   elif item == "disableHiddenChannels"    : self.VVdot7(False)
   elif item == "VVESHP"    : FFZRvh(self, self.VVESHP, "Reset and Restart ?")
   elif item == "VVEVlf"      : FF4idw(self, BF(CC1mtH.VVEVlf, self))
 def VVit6Z(self):
  VVGuvj = []
  VVGuvj.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVGuvj.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVGuvj.append(("Services with PIcons for the System"  , "VVJ4yR"    ))
  VVGuvj.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVGuvj.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFSiXW(self, self.VViGmU, VVGuvj=VVGuvj, title="Service Information", VVYJYo=True)
 def VViGmU(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF4idw(self, BF(self.VVskLI, title))
   elif ref == "parentalControlChannels"   : FF4idw(self, BF(self.VV3Omr, title))
   elif ref == "showHiddenChannels"    : FF4idw(self, BF(self.VVcCxs, title))
   elif ref == "VVJ4yR"    : FF4idw(self, BF(self.VV15P9, title))
   elif ref == "servicesWithMissingPIcons"   : FF4idw(self, BF(self.VVBZZ6, title))
   elif ref == "TranspondersStats"     : FF4idw(self, BF(self.VVjhIo, title))
   elif ref == "SatellitesXmlStats"    : FF4idw(self, BF(self.VVRwDN, title))
 def VVLfpw(self):
  VVGuvj = []
  VVGuvj.append(("All DVB-S/C/T Services", "all"))
  VVGuvj.extend(CCQrUI.VVbmna())
  FFSiXW(self, self.VViBSD, VVGuvj=VVGuvj, title="", VVYJYo=True)
 def VViBSD(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CC1mtH.VVZAIa("1:7:")
   else   : lst = FF7SJo(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFUQ44(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFyCwy(r)  : sat = "Stream Relay"
       elif FFOXrQ(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFvBW5(CFG.exportedTablesPath.getValue()), FFguCY())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFDx6X(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FF1lLq(self, "No Services found !", 1500)
 @staticmethod
 def VVEVlf(SELF):
  FF9bFs()
  FFDx6X(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV2GM8(self):
  self.VVCeUI = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiRFn(self)
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVprEj)
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVrjyr  = ("Zap"   , self.VVMhkK     , [])
   VVGySq = (""    , self.VVbe1I   , [])
   VVpxmm = ("Options"  , self.VVtlyw , [])
   VVdyRp = ("Current Service", self.VVtYyP , [])
   VV1SrQ = ("Filter"   , self.VVpJbG  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVRYg6  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVGySq=VVGySq, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindServices)
 def VVKOzz(self):
  self.VVCeUI = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiRFn(self)
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVv86I)
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVrjyr  = ("Zap"   , self.VVMhkK      , [])
   VVGySq = (""    , self.VVbe1I    , [])
   VVdyRp = ("Current Service", self.VVtYyP  , [])
   VVpxmm = ("Options"  , self.VVNaId , [])
   VV1SrQ = ("Filter"   , self.VVBQMN  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVRYg6  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVGySq=VVGySq, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindServices)
 def VVtlyw(self, VVgAw8, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCwZHL(self, VVgAw8)
  VVGuvj = []
  isMulti = VVgAw8.VVhXSW
  if isMulti:
   refCodeList = VVgAw8.VVqz25(3)
   if refCodeList:
    VVGuvj.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVGuvj.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVGuvj.append(VVnek4)
    VVGuvj.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVGuvj.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVGuvj.append(VVnek4)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVGuvj.append((txt1, "parentalControl_add" ))
    VVGuvj.append((txt2,        ))
   else:
    VVGuvj.append((txt1,       ))
    VVGuvj.append((txt2, "parentalControl_remove" ))
   VVGuvj.append(VVnek4)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVGuvj.append((txt1, "hiddenServices_add"  ))
    VVGuvj.append((txt2,       ))
   else:
    VVGuvj.append((txt1,        ))
    VVGuvj.append((txt2, "hiddenServices_remove" ))
   VVGuvj.append(VVnek4)
  cbFncDict = { "parentalControl_add"   : BF(self.VVI8Rk, VVgAw8, refCode, True)
     , "parentalControl_remove"  : BF(self.VVI8Rk, VVgAw8, refCode, False)
     , "hiddenServices_add"   : BF(self.VVO41b, VVgAw8, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVO41b, VVgAw8, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVtEXn, VVgAw8, True)
     , "parentalControl_sel_remove" : BF(self.VVtEXn, VVgAw8, False)
     , "hiddenServices_sel_add"  : BF(self.VVwadA, VVgAw8, True)
     , "hiddenServices_sel_remove" : BF(self.VVwadA, VVgAw8, False)
     }
  VVGuvj1, cbFncDict1 = CC1mtH.VVKCFd(self, VVgAw8, servName, 3)
  VVGuvj.extend(VVGuvj1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VV71Gx(VVGuvj, cbFncDict)
 def VVNaId(self, VVgAw8, title, txt, colList):
  servName = colList[0]
  mSel = CCwZHL(self, VVgAw8)
  VVGuvj, cbFncDict = CC1mtH.VVKCFd(self, VVgAw8, servName, 3)
  mSel.VV71Gx(VVGuvj, cbFncDict)
 @staticmethod
 def VVKCFd(SELF, VVgAw8, servName, refCodeCol):
  tot = VVgAw8.VVeEeJ()
  if tot > 0:
   sTxt = FF4aCb("%d Service%s" % (tot, FFtCOg(tot)), VV2Bne)
   VVGuvj = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFWkM4(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF4aCb(servName, VV2Bne)
   VVGuvj = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CC1mtH.VVg9CG, SELF, VVgAw8, refCodeCol, True)
     , "addToBouquet_one" : BF(CC1mtH.VVg9CG, SELF, VVgAw8, refCodeCol, False)
     }
  return VVGuvj, cbFncDict
 @staticmethod
 def VVg9CG(SELF, VVgAw8, refCodeCol, isMulti):
  picker = CCQrUI(SELF, VVgAw8, "Add to Bouquet", BF(CC1mtH.VVgICG, VVgAw8, refCodeCol, isMulti))
 @staticmethod
 def VVgICG(VVgAw8, refCodeCol, isMulti):
  if isMulti : refCodeList = VVgAw8.VVqz25(refCodeCol)
  else  : refCodeList = [VVgAw8.VVi9QZ()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVI8Rk(self, VVgAw8, refCode, isAddToBlackList):
  VVgAw8.VV7K9Z("Processing ...")
  FFJVhm(BF(self.VVMGZg, VVgAw8, [refCode], isAddToBlackList))
 def VVtEXn(self, VVgAw8, isAddToBlackList):
  refCodeList = VVgAw8.VVqz25(3)
  if not refCodeList:
   FFeF28(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVgAw8.VV7K9Z("Processing ...")
  FFJVhm(BF(self.VVMGZg, VVgAw8, refCodeList, isAddToBlackList))
 def VVMGZg(self, VVgAw8, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV0xaO, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV0xaO):
   lines = FF8p4l(VV0xaO)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV0xaO, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVgAw8.VVhXSW
   if isMulti:
    self.VVoVcJ(VVgAw8, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVdQIN(VVgAw8, refCode)
    VVgAw8.VVOvTL()
  else:
   VVgAw8.VVmaQr("No changes")
 def VVO41b(self, VVgAw8, refCode, isHide):
  title = "Change Hidden State"
  if FFwPKf(refCode):
   VVgAw8.VV7K9Z("Processing ...")
   ret = FFwZjD(refCode, isHide)
   if ret : FF4idw(self, BF(self.VVdQIN, VVgAw8, refCode))
   else : FFeF28(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFeF28(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVdQIN(self, VVgAw8, refCode):
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVprEj, VVoIgz=[3, [refCode], False])
  done = False
  if VVJpUa:
   data = VVJpUa[0]
   if data[3] == refCode:
    done = VVgAw8.VVtGmM(data)
  if not done:
   self.VVuSCX(VVgAw8, VVgAw8.VVgH9X(), self.VVprEj)
  VVgAw8.VVOvTL()
 def VVoVcJ(self, VVgAw8, totRefCodes):
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVprEj, VVoIgz=self.VVCeUI)
  VVgAw8.VVFDhD(VVJpUa)
  VVgAw8.VVIgTe(False)
  VVgAw8.VVmaQr("%d Processed" % totRefCodes)
 def VVwadA(self, VVgAw8, isHide):
  refCodeList = VVgAw8.VVqz25(3)
  if not refCodeList:
   FFeF28(self, "Nothing selected", title="Change Hidden State")
   return
  VVgAw8.VV7K9Z("Processing ...")
  FFJVhm(BF(self.VVGCXg, VVgAw8, refCodeList, isHide))
 def VVGCXg(self, VVgAw8, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFwZjD(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FF9bFs(True)
   self.VVoVcJ(VVgAw8, len(refCodeList))
  else:
   VVgAw8.VVmaQr("No changes")
 def VVpJbG(self, VVgAw8, title, txt, colList):
  inFilterFnc = BF(self.VVwU4R, VVgAw8) if self.VVCeUI else None
  self.filterObj.VV2trc(1, VVgAw8, 2, BF(self.VVxJ9F, VVgAw8), inFilterFnc=inFilterFnc)
 def VVxJ9F(self, VVgAw8, item):
  self.VVBsX1(VVgAw8, False, item, 2, self.VVprEj)
 def VVwU4R(self, VVgAw8, VVUD8b, item):
  self.VVBsX1(VVgAw8, True, item, 2, self.VVprEj)
 def VVBQMN(self, VVgAw8, title, txt, colList):
  inFilterFnc = BF(self.VVPaZw, VVgAw8) if self.VVCeUI else None
  self.filterObj.VV2trc(2, VVgAw8, 4, BF(self.VVokYR, VVgAw8), inFilterFnc=inFilterFnc)
 def VVokYR(self, VVgAw8, item):
  self.VVBsX1(VVgAw8, False, item, 4, self.VVv86I)
 def VVPaZw(self, VVgAw8, VVUD8b, item):
  self.VVBsX1(VVgAw8, True, item, 4, self.VVv86I)
 def VVYt0H(self, VVgAw8, title, txt, colList):
  inFilterFnc = BF(self.VVonUW, VVgAw8) if self.VVCeUI else None
  self.filterObj.VV2trc(0, VVgAw8, 4, BF(self.VVadSD, VVgAw8), inFilterFnc=inFilterFnc)
 def VVadSD(self, VVgAw8, item):
  self.VVBsX1(VVgAw8, False, item, 4, self.VVfrtM)
 def VVonUW(self, VVgAw8, VVUD8b, item):
  self.VVBsX1(VVgAw8, True, item, 4, self.VVfrtM)
 def VVBsX1(self, VVgAw8, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVgAw8.VVhkzh(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVCeUI = None
  else:
   words, asPrefix = CCiRFn.VVAtaF(words)
   self.VVCeUI = [col, words, asPrefix]
  if words: FF4idw(VVgAw8, BF(self.VVuSCX, VVgAw8, title, mode), clearMsg=False)
  else : FF1lLq(VVgAw8, "Incorrect filter", 2000)
 def VVuSCX(self, VVgAw8, title, mode):
  VVJpUa, err = CC1mtH.VVb6EG(self, mode, VVoIgz=self.VVCeUI, VVpuYC=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVgAw8.VVYgJy():
    try:
     ndx = VVJpUa.index(tuple(list(map(str.strip, row))))
     lst.append(VVJpUa[ndx])
    except:
     pass
   VVJpUa = lst
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVgAw8.VVFDhD(VVJpUa, title, VVLMQ5Msg=True)
  else:
   FF1lLq(VVgAw8, "Not found!", 1500)
 def VVGtSl(self, title, VVWhjq, VVrjyr=None, VVGySq=None, VVFkw1=None, VVdyRp=None, VVpxmm=None, VV1SrQ=None):
  VVdyRp = ("Current Service", self.VVtYyP, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVRYg6 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFBxNx(self, None, title=title, header=header, VVWhjq=VVWhjq, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVGySq=VVGySq, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindServices)
 def VVtYyP(self, VVgAw8, title, txt, colList):
  self.VVUCbh(VVgAw8)
 def VVwirD(self, VVgAw8, title, txt, colList):
  self.VVUCbh(VVgAw8, True)
 def VVUCbh(self, VVgAw8, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVgAw8.VVAyL9(colDict, VVhghQ=True)
   else:
    VVgAw8.VVIvlb(3, refCode, True)
   return
  FFeF28(self, "Cannot read current Reference Code !")
 def VVskLI(self, title):
  self.VVCeUI = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiRFn(self)
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVfrtM)
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVGySq = (""    , self.VVkOgp , []      )
   VVdyRp = ("Current Service", self.VVwirD  , []      )
   VV1SrQ = ("Filter"   , self.VVYt0H   , [], "Loading Filters ..." )
   VVrjyr  = ("Zap"   , self.VV6T6w      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVRYg6  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVGySq=VVGySq, VVdyRp=VVdyRp, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindServices)
 def VVkOgp(self, VVgAw8, title, txt, colList):
  refCode  = self.VVUK93(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFw3XJ(self, fncMode=CCM3PM.VVkPDU, refCode=refCode, chName=chName, text=txt)
 def VV6T6w(self, VVgAw8, title, txt, colList):
  refCode = self.VVUK93(colList)
  FF5kbK(self, refCode)
 def VVMhkK(self, VVgAw8, title, txt, colList):
  FF5kbK(self, colList[3])
 def VVUK93(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVBLdE(VV6Klt, mode=0):
  lines = FF8p4l(VV6Klt, encLst=["UTF-8"])
  return CC1mtH.VV6ACj(lines, mode)
 @staticmethod
 def VV6ACj(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVb6EG(SELF, mode, VVoIgz=None, VVpuYC=True, VVgAsb=True):
  VV6Klt, err = CC1mtH.VVnpAH(SELF, VVgAsb)
  if err:
   return None, err
  asPrefix = False
  if VVoIgz:
   filterCol = VVoIgz[0]
   filterWords = VVoIgz[1]
   asPrefix = VVoIgz[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CC1mtH.VVprEj:
   blackList = None
   if fileExists(VV0xaO):
    blackList = FF8p4l(VV0xaO)
    if blackList:
     blackList = set(blackList)
  elif mode == CC1mtH.VVv86I:
   tp = CCg0iP()
  VVHhLZ, VV9Tj5 = FF77N5()
  if mode in (CC1mtH.VVUq4c, CC1mtH.VVzVs0):
   VVJpUa = {}
  else:
   VVJpUa = []
  tagFound = False
  with ioOpen(VV6Klt, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFwZpN(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CC1mtH.VVfrtM:
       if sTypeInt in VVHhLZ:
        STYPE = VV9Tj5[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVJpUa.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVJpUa.append(tRow)
       else:
        VVJpUa.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CC1mtH.VVNvWx:
        VVJpUa.append((chName, chProv, sat, refCode))
       elif mode == CC1mtH.VVUq4c:
        VVJpUa[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CC1mtH.VVzVs0:
        VVJpUa[chName] = refCode
       elif mode == CC1mtH.VVprEj:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJpUa.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJpUa.append(tRow)
        else:
         VVJpUa.append(tRow)
       elif mode == CC1mtH.VVv86I:
        if sTypeInt in VVHhLZ:
         STYPE = VV9Tj5[sTypeInt]
        freq, pol, fec, sr, syst = tp.VV8PWd(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJpUa.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJpUa.append(tRow)
        else:
         VVJpUa.append(tRow)
       elif mode == CC1mtH.VVMWrd:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVJpUa.append((chName, chProv, sat, refCode))
       elif mode == CC1mtH.VVeHdb:
        VVJpUa.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVJpUa and VVpuYC:
   FFeF28(SELF, "No services found!")
  return VVJpUa, ""
 def VV3Omr(self, title):
  if fileExists(VV0xaO):
   lines = FF8p4l(VV0xaO)
   if lines:
    newRows = []
    VVJpUa, err = CC1mtH.VVb6EG(self, self.VVeHdb)
    if VVJpUa:
     lines = set(lines)
     for item in VVJpUa:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVJpUa = newRows
      VVJpUa.sort(key=lambda x: x[0].lower())
      VVGySq = ("", self.VVbe1I, [])
      VVrjyr = ("Zap", self.VVMhkK, [])
      self.VVGtSl(title, VVJpUa, VVrjyr=VVrjyr, VVGySq=VVGySq)
     else:
      FFPaL6(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVJpUa)))
   else:
    FFDx6X(self, "No active Parental Control services.", FFVLF6())
  else:
   FFJBL5(self, VV0xaO)
 def VVcCxs(self, title):
  VVJpUa, err = CC1mtH.VVb6EG(self, self.VVMWrd)
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVGySq = ("" , self.VVbe1I, [])
   VVrjyr  = ("Zap", self.VVMhkK, [])
   self.VVGtSl(title, VVJpUa, VVrjyr=VVrjyr, VVGySq=VVGySq)
  elif err:
   pass
  else:
   FFDx6X(self, "No hidden services.", FFVLF6())
 def VVtARJ(self):
  title = "Services unused in Tuner Configuration"
  VV6Klt, err = CC1mtH.VVnpAH(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CC1mtH.VVXozB()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVcszO(str(item[0]))
    nsLst.add(ns)
  sysLst = CC1mtH.VVZAIa("1:7:")
  tpLst  = CC1mtH.VVBLdE(VV6Klt, mode=1)
  VVJpUa = []
  for refCode, chName in sysLst:
   servID = CC1mtH.VVCNeb(refCode)
   tpID = CC1mtH.VV7crU(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVJpUa.append((chName, FFUQ44(refCode, False), refCode, servID))
  if VVJpUa:
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVpxmm = ("Options"   , BF(self.VVbb9t, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVRYg6  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVpxmm=VVpxmm, VVmEJ8="#0a001122", VVd8a3="#0a001122", VVcGiE="#0a001122", VVh96o="#00004455", VV5t00="#0a333333", VVO2zv="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFDx6X(self, "No invalid service found !", title=title)
 def VVbb9t(self, Title, VVgAw8, title, txt, colList):
  mSel = CCwZHL(self, VVgAw8)
  isMulti = VVgAw8.VVhXSW
  if isMulti : txt = "Remove %s Services" % FF4aCb(str(VVgAw8.VVeEeJ()), VVT2Mp)
  else  : txt = "Remove : %s" % FF4aCb(VVgAw8.VVi9QZ()[0], VVT2Mp)
  VVGuvj = [(txt, "del")]
  cbFncDict = {"del": BF(FF4idw, VVgAw8, BF(self.VVWq7y, VVgAw8, Title))}
  mSel.VV71Gx(VVGuvj, cbFncDict)
 def VVWq7y(self, VVgAw8, title):
  VV6Klt, err = CC1mtH.VVnpAH(self, title=title)
  if err:
   return
  isMulti = VVgAw8.VVhXSW
  skipLst = []
  if isMulti : skipLst = VVgAw8.VVqz25(3)
  else  : skipLst = [VVgAw8.VVi9QZ()[3]]
  tpLst = CC1mtH.VVBLdE(VV6Klt, mode=0)
  servLst = CC1mtH.VVBLdE(VV6Klt, mode=10)
  tmpDbFile = VV6Klt + ".tmp"
  lines   = FF8p4l(VV6Klt)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FF7Jdu("mv -f '%s' '%s'" % (tmpDbFile, VV6Klt))
  VVJpUa = []
  for row in VVgAw8.VVYgJy():
   if not row[3] in skipLst:
    VVJpUa.append(row)
  FF9bFs()
  FFPaL6(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVJpUa:
   VVgAw8.VVFDhD(VVJpUa, title)
   VVgAw8.VVIgTe(False)
  else:
   VVgAw8.cancel()
 def VVjhIo(self, title):
  VV6Klt, err = CC1mtH.VVnpAH(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV08sD(VV6Klt)
  txt = FF4aCb("Total Transponders:\n\n", VVrWwc)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF4aCb("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVrWwc)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFFdiF(item), satList.count(item))
  FFPaL6(self, txt, title)
 def VV08sD(self, VV6Klt):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VV6Klt, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVRwDN(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFJBL5(self, path, title=title)
   return
  elif not CCZHbk.VVWzKq(self, path, title):
   return
  if not CCAhZF.VVWJ4w(self):
   return
  tree = CC1mtH.VVoOLm(self, path, title=title)
  if not tree:
   return
  VVJpUa = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFwZpN(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVJpUa.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVJpUa:
   VVJpUa.sort(key=lambda x: int(x[1]))
   VVdyRp = ("Current Satellite", BF(self.VVh37C, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVRYg6  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=25, VVAAbT=1, VVdyRp=VVdyRp, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFeF28(self, "No data found !", title=title)
 def VVh37C(self, satCol, VVgAw8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  sat = FFUQ44(refCode, False)
  for ndx, row in enumerate(VVgAw8.VVYgJy()):
   if sat == row[satCol].strip():
    VVgAw8.VVAGTP(ndx)
    break
  else:
   FF1lLq(VVgAw8, "No listed !", 1500)
 def FF4idw_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFeF28(self, "No Satellites found !")
   return
  usedSats = CC1mtH.VVXozB()
  VVJpUa = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVJpUa.append((sat[1], posTxt, FFwZpN(sat[0]), tuners, str(posVal)))
  if VVJpUa:
   VVcGiE = "#11222222"
   VVJpUa.sort(key=lambda x: int(x[1]))
   VVdyRp = ("Current Satellite" , BF(self.VVh37C, 2) , [])
   VVpxmm = ("Options"   , self.VVwxFT  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVRYg6  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVmEJ8=VVcGiE, VVd8a3=VVcGiE, VVcGiE=VVcGiE, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFeF28(self, "No data found !")
 def VVwxFT(self, VVgAw8, title, txt, colList):
  mSel = CCwZHL(self, VVgAw8)
  isMulti = VVgAw8.VVhXSW
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF4aCb(str(VVgAw8.VVeEeJ()), VVT2Mp)
  else  : txt = "Remove ALL Services on : %s" % FF4aCb(VVgAw8.VVi9QZ()[0], VVT2Mp)
  VVGuvj = []
  VVGuvj.append((txt, "deleteSat"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Delete Empty Bouquets", "VVBN4a"))
  cbFncDict = { "deleteSat"   : BF(FF4idw, VVgAw8, BF(self.VV2V6W, VVgAw8))
     , "VVBN4a" : BF(self.VVBN4a, VVgAw8)
     }
  mSel.VV71Gx(VVGuvj, cbFncDict)
 def VV2V6W(self, VVgAw8):
  posLst = []
  isMulti = VVgAw8.VVhXSW
  posLst = []
  if isMulti : posLst = VVgAw8.VVqz25(4)
  else  : posLst = [VVgAw8.VVi9QZ()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVcszO(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVs86R(nsLst)
  FF9bFs(True)
  FFPaL6(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVBN4a(self, winObj):
  title = "Delete Empty Bouquets"
  FFZRvh(self, BF(FF4idw, winObj, BF(self.VVA1kU, title)), "Delete bouquets with no services ?", title=title)
 def VVA1kU(self, title):
  bList = CCQrUI.VVvnbE()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCQrUI.VVFdHs(bRef)
    bPath = VVgBUe + bFile
    FFOHeU(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVgBUe + fil
     if fileExists(path):
      lines = FF8p4l(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FF9bFs(True)
  if bNames: txt = "%s\n\n%s" % (FF4aCb("Deleted Bouquets:", VV2Bne), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFPaL6(self, txt, title=title)
 def VVcszO(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVs86R(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVgBUe)
  for srcF in files:
   if fileExists(srcF):
    lines = FF8p4l(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFU7aI(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV15P9(self, title)   : self.VVJ4yR(title, True)
 def VVBZZ6(self, title) : self.VVJ4yR(title, False)
 def VVJ4yR(self, title, isWithPIcons):
  piconsPath = CCnBmO.VVYQsq()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCnBmO.VVTWV5(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVJpUa, err = CC1mtH.VVb6EG(self, self.VVeHdb)
    if VVJpUa:
     channels = []
     for (chName, chProv, sat, refCode) in VVJpUa:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFVTMr(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVJpUa)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV1pWY(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV1pWY("PIcons Path"  , piconsPath)
     txt += VV1pWY("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV1pWY("Total services" , totalServices)
     txt += VV1pWY("With PIcons"  , totalWithPIcons)
     txt += VV1pWY("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFPaL6(self, txt)
     else:
      VVGySq     = (""      , self.VVbe1I , [])
      if isWithPIcons : VV1SrQ = ("Export Current PIcon", self.VVmQEF  , [])
      else   : VV1SrQ = None
      VVpxmm     = ("Statistics", FFPaL6, [txt])
      VVrjyr      = ("Zap", self.VVMhkK, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVGtSl(title, channels, VVrjyr=VVrjyr, VVGySq=VVGySq, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ)
   else:
    FFeF28(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFeF28(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVbe1I(self, VVgAw8, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFw3XJ(self, fncMode=CCM3PM.VVkPDU, refCode=refCode, chName=chName, text=txt)
 def VVmQEF(self, VVgAw8, title, txt, colList):
  png, path = CCnBmO.VVFPhh(colList[3], colList[0])
  if path:
   CCnBmO.VVbHLl(self, png, path)
 @staticmethod
 def VV1ktS():
  VV6Klt  = "%slamedb" % VVgBUe
  VVJSdi = "%slamedb.disabled" % VVgBUe
  return VV6Klt, VVJSdi
 @staticmethod
 def VVGJTW():
  VVcIbu  = "%slamedb5" % VVgBUe
  VVydMo = "%slamedb5.disabled" % VVgBUe
  return VVcIbu, VVydMo
 def VVdot7(self, isEnable):
  VV6Klt, VVJSdi = CC1mtH.VV1ktS()
  if isEnable and not fileExists(VVJSdi):
   FFDx6X(self, "Aready enabled.")
  elif not isEnable and not fileExists(VV6Klt):
   FFeF28(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFZRvh(self, BF(self.VVu1zJ, isEnable), "%s Hidden Channels ?" % word)
 def VVu1zJ(self, isEnable):
  VV6Klt , VVJSdi = CC1mtH.VV1ktS()
  VVcIbu, VVydMo = CC1mtH.VVGJTW()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVJSdi, VVJSdi, VV6Klt)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVydMo, VVydMo, VVcIbu)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VV6Klt  , VV6Klt , VVJSdi)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVcIbu , VVcIbu, VVydMo)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVJSdi, VV6Klt )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVydMo, VVcIbu)
  ok = FF7Jdu(cmd)
  FF9bFs()
  if ok: FFDx6X(self, "Hidden List %s" % word)
  else : FFeF28(self, "Error while restoring:\n\n%s" % fileName)
 def VVESHP(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %s | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVOAlS
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %s" % VVOAlS
  FF0AJe(self, cmd)
 def VVBq6i(self):
  VV6Klt, err = CC1mtH.VVnpAH(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFOHeU(tmpFile)
  totChan = totRemoved = 0
  lines = FF8p4l(VV6Klt, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFZRvh(self, BF(FF4idw, self, BF(self.VVjhuS, tmpFile, VV6Klt, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFtCOg(totRemoved), totChan, FFtCOg(totChan))
      , callBack_No=BF(self.VVkyGT, tmpFile))
  else:
   FFPaL6(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVjhuS(self, tmpFile, VV6Klt, totRemoved, totChan):
  FF7Jdu("mv -f '%s' '%s'" % (tmpFile, VV6Klt))
  FF9bFs()
  FFPaL6(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVkyGT(self, tmpFile):
  FFOHeU(tmpFile)
 @staticmethod
 def VVnpAH(SELF, VVgAsb=True, title=""):
  VV6Klt, VVJSdi = CC1mtH.VV1ktS()
  if   not fileExists(VV6Klt)       : err = "File not found !\n\n%s" % VV6Klt
  elif not CCZHbk.VVWzKq(SELF, VV6Klt) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVgAsb:
   FFeF28(SELF, err, title=title)
  return VV6Klt, err
 @staticmethod
 def VV7crU(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVCNeb(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVZAIa(servTypes):
  VVlOe7  = eServiceCenter.getInstance()
  VVyXLg   = '%s ORDER BY name' % servTypes
  VVXsWH   = eServiceReference(VVyXLg)
  VVmSks = VVlOe7.list(VVXsWH)
  if VVmSks: return VVmSks.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVXozB():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCM3PM(Screen):
 VVyGH2  = 0
 VVAOjG   = 1
 VVcWUD   = 2
 VVkPDU    = 3
 VVipqo    = 4
 VVVynW   = 5
 VVQW0q   = 6
 VVP8uW    = 7
 VVz8xJ   = 8
 VVSF0r   = 9
 VVMNyu   = 10
 VV5NDk   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFhwpa(VVhNmI, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVyGH2)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FF4aCb("%s\n", VVTjYX) % SEP
  self.picViewer  = None
  FFOUwv(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVEXEL })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self["myLabel"].VVyzBh(outputFileToSave="chann_info")
  if   self.fncMode == self.VVyGH2 : fnc = self.VVRD7O
  elif self.fncMode == self.VVAOjG  : fnc = self.VVRD7O
  elif self.fncMode == self.VVcWUD  : fnc = self.VVRD7O
  elif self.fncMode == self.VVkPDU  : fnc = self.VVrS7U
  elif self.fncMode == self.VVipqo  : fnc = self.VVloDs
  elif self.fncMode == self.VVVynW  : fnc = self.VVteJa
  elif self.fncMode == self.VVQW0q  : fnc = self.VVYvcX
  elif self.fncMode == self.VVP8uW  : fnc = self.VVWbER
  elif self.fncMode == self.VVz8xJ  : fnc = self.VVBPyn
  elif self.fncMode == self.VVSF0r : fnc = self.VVYWvX
  elif self.fncMode == self.VVMNyu  : fnc = self.VVINnR
  elif self.fncMode == self.VV5NDk : fnc = self.VVQpxH
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVpv2q
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VV6qAa()
  FFJVhm(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVgNN3()
 def VVE6bX(self, err):
  self["myLabel"].setText(err)
  FFBHn2(self["myTitle"], "#22200000")
  FFBHn2(self["myBody"], "#22200000")
  self["myLabel"].VV5YbJ("#22200000")
  self["myLabel"].VV6qAa()
 def VVRD7O(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  self.refCode = refCode
  self.VVuAQz(chName)
 def VVrS7U(self):
  self.VVuAQz(self.chName)
 def VVloDs(self):
  self.VVuAQz(self.chName)
 def VVteJa(self):
  self.VVuAQz(self.chName)
 def VVYvcX(self):
  self.VVuAQz("Picon Info")
 def VVWbER(self):
  self.VVuAQz(self.chName)
 def VVBPyn(self):
  self.VVuAQz(self.chName)
 def VVYWvX(self):
  self.VVuAQz(self.chName)
 def VVINnR(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFCqMm(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVuBqA(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVuAQz(self.chName)
 def VVQpxH(self):
  self.VVuAQz(self.chName)
 def VVpv2q(self):
  self.VVQDsk(self.picPath)
  self.VVVyXb()
 def VVuAQz(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFwQYn(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVeshu(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FF4aCb(self.VVInuN(tUrl), VVE7tQ)
  if not self.epg:
   epg = CCTnwS.VV4WHJ(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVQDsk(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCnBmO.VVFPhh(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVQDsk(path)
  self.VVk7zv()
  self.VVG3Lp(decodedUrl)
  self.VVVyXb()
 def VVVyXb(self):
  self["myLabel"].setText(self.text or "   No active service", VVXyQm=VVwuXs)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV6qAa(minHeight=minH)
 def VVG3Lp(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFOXrQ(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVZ1ID(FFb0uP(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCqssj.VVZ8DC(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCqssj.VVZ8DC(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFeaY5("EPG:", VV2Bne) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVk7zv()
 def VVk7zv(self):
  if not self.piconShown and self.picUrl:
   path, err = FFl4UT(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVQDsk(path)
    if self.piconShown and self.refCode:
     self.VV7VT6(path, self.refCode)
 def VV7VT6(self, path, refCode):
  if path and fileExists(path) and FFGbNH("ffmpeg"):
   pPath = CCnBmO.VVYQsq()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCM3PM.VVuDvo(path)
    cmd += FFTMeZ("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FF7Jdu(cmd)
 def VVQDsk(self, path):
  if path and fileExists(path):
   err, w, h = self.VVMfX2(path)
   if not err:
    if h > w:
     self.VVa1w8(self["myPicF"], w, h, True)
     self.VVa1w8(self["myPicB"], w, h, False)
     self.VVa1w8(self["myPic"] , w, h, False)
   self.picViewer = CCAJ4M.VVh183(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVa1w8(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVMfX2(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFGRiq(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVeshu(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF4aCb(chName, VV2Bne)
  txt += self.VV1pWY(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF4aCb(state, VVEkv6)
   txt += "State\t: %s\n" % state
  w = FFhH2c(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFhH2c(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVwRIi(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV1pWY(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV1pWY(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV1pWY(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVLxGl()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVQd92()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCM3PM.VVnRhL(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF4aCb("Stream-Relay" if FFyCwy(decodedUrl) else "IPTV", VVrWwc)
   txt += self.VVem5B(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVeX5h(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCg0iP()
    tpTxt, namespace = tp.VVPQwG(refCode)
    if tpTxt:
     txt += FF4aCb("Tuner:\n", VV2Bne)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF4aCb("Codes:\n", VV2Bne)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV1pWY(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV1pWY(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV1pWY(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV1pWY(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV1pWY(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV1pWY(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV1pWY(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV1pWY(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV1pWY(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVwRIi(info):
  if info:
   aspect = FFhH2c(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV1pWY(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFhH2c(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVevfq(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVevfq(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVLxGl(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVQd92(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVeX5h(self, refCode, iptvRef, chName):
  refCode = FFbIhH(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFhqv7(VVgBUe + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFhqv7(VVgBUe + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVWhjq = []
  tmpRefCode = FFb0uP(refCode)
  for item in fList:
   path = VVgBUe + item
   if fileExists(path):
    txt = FFhqv7(path)
    if tmpRefCode in FFb0uP(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVWhjq.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVWhjq:
   if len(VVWhjq) == 1:
    txt += "%s\t: %s%s\n" % (FF4aCb("Bouquet", VV2Bne), VVWhjq[0][0], " (%s)" % VVWhjq[0][1] if VVTypc else "")
   else:
    txt += FF4aCb("Bouquets:\n", VV2Bne)
    for ndx, item in enumerate(VVWhjq):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVTypc else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVem5B(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFYV5a(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCqssj()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF4aCb("URL:", VVrWwc) + "\n%s\n" % self.VVInuN(decodedUrl)
  else:
   txt = "\n"
   txt += FF4aCb("Reference:", VVrWwc) + "\n%s\n" % refCode
  return txt
 def VVInuN(self, url):
  if not FFyCwy(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVwauR:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFb0uP(url)
 def VVZ1ID(self, decodedUrl):
  if not CCGRJR.VVeolD():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCCW9K.VVxp5A(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVTPNf(tDict)
   elif uType == "movie" : epg, picUrl = CCM3PM.VVCCf7(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVTPNf(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCCW9K.VVoNAp(item, "title"    , is_base64=True )
     lang    = CCCW9K.VVoNAp(item, "lang"         ).upper()
     description   = CCCW9K.VVoNAp(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCCW9K.VVoNAp(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCCW9K.VVoNAp(item, "start_timestamp"      )
     stop_timestamp  = CCCW9K.VVoNAp(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCCW9K.VVoNAp(item, "stop_timestamp"       )
     now_playing   = CCCW9K.VVoNAp(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VViU6E, ""
      else     : color, txt = VVEkv6 , "    (CURRENT EVENT)"
      epg += FF4aCb("_" * 32 + "\n", VVTjYX)
      epg += FF4aCb("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF4aCb(description, VVE7tQ)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCTnwS.VVKa2B(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVCCf7(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCCW9K.VVoNAp(item, "movie_image" )
    genre  = CCCW9K.VVoNAp(item, "genre"   ) or "-"
    plot  = CCCW9K.VVoNAp(item, "plot"   ) or "-"
    country  = CCCW9K.VVoNAp(item, "country"  ) or "-"
    actors  = CCCW9K.VVoNAp(item, "actors"   ) or "-"
    cast  = CCCW9K.VVoNAp(item, "cast"   ) or "-"
    rating  = CCCW9K.VVoNAp(item, "rating"   ) or "-"
    director = CCCW9K.VVoNAp(item, "director"  ) or "-"
    releasedate = CCCW9K.VVoNAp(item, "releasedate" ) or "-"
    duration = CCCW9K.VVoNAp(item, "duration"  ) or "-"
    try:
     lang = CCCW9K.VVoNAp(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF4aCb(cast if cast != "-" else actors, VVE7tQ)
    epg += "Plot:\n%s"    % FF4aCb(plot, VVE7tQ)
   except:
    pass
  return epg, movie_image
 def VVEXEL(self):
  if VVwauR:
   def VV1pWY(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV1pWY(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCqssj()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV1pWY(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FF1lLq(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVxjNe(SELF):
  if not CCYF5X.VVXK5R(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF)
  err = url =  fSize = resumable = ""
  if FFoDQS(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCqssj.VVHmzS(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCqssj.VVrEVj(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFeF28(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCZHbk.VVi3go(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF4aCb(" (M3U/M3U8 File)", VVE7tQ)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCATpC.VVd9Yv(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV5Sg6(subj, val):
   return "%s\n%s\n\n" % (FF4aCb("%s:" % subj, VV2Bne), val)
  title = "File Size"
  txt  = VV5Sg6(title , fSize or "?")
  txt += VV5Sg6("Name" , chName)
  txt += VV5Sg6("URL" , url)
  if resumable: txt += VV5Sg6("Supports Download-Resume", resumable)
  if err  : txt += FF4aCb("Error:\n", VVEkv6) + err
  FFPaL6(SELF, txt, title=title)
 @staticmethod
 def VVnRhL(SELF):
  fPath, fDir, fName = CCZHbk.VVuryx(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVuDvo(path):
  return FFTMeZ("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVWDNI(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCnBmO.VVYQsq() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVFrTq(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFOXrQ(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFU7aI(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCqssj():
 def __init__(self):
  self.VViZTK()
  self.VVgtza    = ""
  self.VVV6L6   = "#f#11ffffaa#User"
  self.VVJ9YW   = "#f#11aaffff#Server"
 def VViZTK(self):
  self.VVFKbR   = ""
  self.VV8jm3    = ""
  self.VVCU58   = ""
  self.VV0kVH = ""
  self.VVxSMk  = ""
  self.VVrQHb = 0
 def VVouTo(self, url, mac, ph1="", VVhghQ=True):
  self.VViZTK()
  self.VVgtza = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVm3gE(url)
  if not host:
   if VVhghQ:
    self.VVRGGb("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVPh0F(mac)
  if not host:
   if VVhghQ:
    self.VVRGGb("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVFKbR = host
  self.VV8jm3  = mac
  return True
 def VVBCiN(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVgtza, "")
 def VVm3gE(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVPh0F(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVvsUC(self):
  res, err = self.VVpJfv(self.VVhKU5())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVFKbR.endswith("/c"):
    self.VVFKbR = self.VVFKbR[:-2]
    res, err = self.VVpJfv(self.VVhKU5())
   elif self.VVFKbR.endswith("/stalker_portal"):
    self.VVFKbR = self.VVFKbR[:-15]
    res, err = self.VVpJfv(self.VVhKU5())
   else:
    self.VVFKbR += "/c"
    res, err = self.VVpJfv(self.VVhKU5())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCCW9K.VVoNAp(tDict["js"], "token")
    rand  = CCCW9K.VVoNAp(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVp5NQ(self, VVhghQ=True):
  if not self.VVgtza:
   self.VVdWvG()
  err = blkMsg = FFDx6XTxt = ""
  try:
   token, rand, err = self.VVvsUC()
   if token:
    self.VVCU58 = token
    self.VV0kVH = rand
    if rand:
     self.VVrQHb = 2
    prof, retTxt = self.VV4pcV(True)
    if prof:
     self.VVxSMk = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVrQHb = 3
      prof, retTxt = self.VV4pcV(False)
      if retTxt:
       self.VVxSMk = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFDx6XTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFDx6XTxt: tErr += "\n%s" % FFDx6XTxt
  if VVhghQ:
   self.VVRGGb(tErr)
  return "", "", tErr
 def VVdWvG(self):
  try:
   import requests
   url = self.VVGVwj()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCqssj.VVrEVj(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCqssj.VVrEVj(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVFKbR = url
       self.VVgtza = span.group(1)
       return
  except:
   pass
  self.VVgtza = "/server/load.php"
 def VVGVwj(self):
  url = self.VVFKbR.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VV2LrZ(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVpJfv("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVpJfv("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VV4pcV(self, capMac):
  res, err = self.VVpJfv(self.VVMsrS(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCCW9K.VVoNAp(tDict["js"], "block_%s" % word)
    FFDx6XTxt = CCCW9K.VVoNAp(tDict["js"], word)
    return tDict, FFDx6XTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVMsrS(self, capMac):
  param = ""
  if self.VVxSMk or self.VV0kVH:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VV8jm3.upper() if capMac else self.VV8jm3.lower(), self.VV0kVH))
  return self.VV2Ewj() + "type=stb&action=get_profile" + param
 exec(FFCqMm("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVUGdF(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVrRoA()
  if len(rows) < 10:
   rows = self.VV0Avv()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVFKbR ))
   rows.append(("MAC (from URL)" , self.VV8jm3 ))
   rows.append(("Token"   , self.VVCU58 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVV6L6  , "MAC" , self.VV8jm3 ))
   rows.append(("2", self.VVJ9YW, "Host" , self.VVFKbR ))
   rows.append(("2", self.VVJ9YW, "Token" , self.VVCU58 ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV5xpi(self, isPhp=True, VVhghQ=False):
  token, profile, tErr = self.VVp5NQ(VVhghQ)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVpSzf()
  res, err = self.VVpJfv(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCCW9K.VVoNAp(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFhukT(span.group(2))
     pass1 = FFhukT(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVrRoA(self):
  m3u_Url, host, user1, pass1, err = self.VV5xpi()
  rows = []
  if m3u_Url:
   res, err = self.VVpJfv(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFrH35(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVV6L6, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFrH35(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVJ9YW, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV0Avv(self):
  token, profile, tErr = self.VVp5NQ()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFncwP(val): val = FFCqMm(val.decode("UTF-8"))
     else     : val = self.VV8jm3
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFrH35(int(parts[1]))
      if parts[2] : ends = FFrH35(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFrH35(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVuBqA(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVp5NQ(VVhghQ=False)
  if not token:
   return ""
  crLinkUrl = self.VVvnCU(mode, chCm, epNum, epId)
  res, err = self.VVpJfv(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCCW9K.VVoNAp(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV2Ewj(self):
  return self.VVFKbR + self.VVgtza + "?"
 def VVhKU5(self):
  return self.VV2Ewj() + "type=stb&action=handshake&token=&mac=%s" % self.VV8jm3
 def VVx1xy(self, mode):
  url = self.VV2Ewj() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVyLZZ(self, catID):
  return self.VV2Ewj() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVZ3x3(self, mode, catID, page):
  url = self.VV2Ewj() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVdZud(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV2Ewj() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVHBnd(self, stID):
  return self.VV2Ewj() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVvnCU(self, mode, chCm, serCode, serId):
  url = self.VV2Ewj() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVpSzf(self):
  return self.VV2Ewj() + "type=itv&action=create_link"
 def VVoW2o(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVBIYw(catID, stID, chNum)
  query = self.VVUhPX(mode, self.VVBCiN(), FFHH9F(host), FFHH9F(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVUhPX(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVe1Ii(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVUhPX(mode, ph1, host, mac, epNum, epId, FFhukT(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFCqMm(host)
  mac   = FFCqMm(mac)
  valid = False
  if self.VVm3gE(playHost) and self.VVm3gE(host) and self.VVm3gE(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVpJfv(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCqssj.VVrEVj()
   if self.VVCU58:
    headers["Authorization"] = "Bearer %s" % self.VVCU58
   if useCookies : cookies = {"mac": self.VV8jm3, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVeU64(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCqssj.VVrEVj(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVrEVj():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVRGGb(self, err, title="Portal Browser"):
  FFeF28(self, str(err), title=title)
 def VVFAhu(self, mode):
  if   mode in ("itv"  , CCCW9K.VVwPpy , CCCW9K.VVMAzw)  : return "Live"
  elif mode in ("vod"  , CCCW9K.VVSStX , CCCW9K.VVDm2k)  : return "VOD"
  elif mode in ("series" , CCCW9K.VVJe7g , CCCW9K.VVwpUk) : return "Series"
  else                          : return "IPTV"
 def VVhmF2(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVFAhu(mode), FF4aCb(searchName, VVE7tQ))
 def VVAVi1(self, catchup=False):
  VVGuvj = []
  VVGuvj.append(("Live"    , "live"  ))
  VVGuvj.append(("VOD"    , "vod"   ))
  VVGuvj.append(("Series"   , "series"  ))
  if catchup:
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Catch-up TV" , "catchup"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Account Info." , "accountInfo" ))
  return VVGuvj
 @staticmethod
 def VV0YYT(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCqssj()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
  if valid:
   ok = p.VVouTo(host, mac, ph1, VVhghQ=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VV5xpi(isPhp=False, VVhghQ=False)
    streamId = CCqssj.VVIjao(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVIjao(decodedUrl):
  p = CCqssj()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFCqMm(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVHmzS(decodedUrl):
  p = CCqssj()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
  if valid:
   if CCqssj.VVKAyG(chCm):
    return FFb0uP(chCm)
   else:
    ok = p.VVouTo(host, mac, ph1, VVhghQ=False)
    if ok:
     try:
      chUrl = p.VVuBqA(mode, chCm, epNum, epId)
      return FFb0uP(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVKAyG(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVZ8DC(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCqssj()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
   if valid:
    if not stID:
     stID = CCqssj.VVIjao(decodedUrl)
    if stID:
     if p.VVouTo(host, mac, ph1, VVhghQ=False):
      token, profile, tErr = p.VVp5NQ(VVhghQ=False)
      if token:
       res, err = p.VVpJfv(p.VVHBnd(stID))
       if res:
        epg, err = CCqssj.VVtAyK(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCqssj.VVtAyK(res.text, retLst=True)
         if pList:
          totEv, totOK = CCTnwS.VVKa2B(refCode, pList)
  return epg, err
 @staticmethod
 def VVtAyK(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCCW9K.VVoNAp(item, "actor"       )
    category   = CCCW9K.VVoNAp(item, "category"      )
    descr    = CCCW9K.VVoNAp(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCCW9K.VVoNAp(item, "director"      )
    name    = CCCW9K.VVoNAp(item, "name"   , is_base64=True)
    start_timestamp  = CCCW9K.VVoNAp(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCCW9K.VVoNAp(item, "start_timestamp"    )
    stop_timestamp  = CCCW9K.VVoNAp(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCCW9K.VVoNAp(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FF4aCb("    (CURRENT EVENT)", VVE7n3)
     except:
      pass
     if not skip:
      epg += FF4aCb("_" * 32 + "\n", VVTjYX)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FF4aCb(name, VV2Bne)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FF4aCb(descr , VVE7tQ) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FF4aCb(category, VVE7tQ) if category else ""
      epg += "Actors:\n%s\n"  % FF4aCb(actor , VVE7tQ) if actor else ""
      epg += "Director:\n%s\n" % FF4aCb(director, VVE7tQ) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCtvHX(CCqssj):
 def __init__(self):
  CCqssj.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV3U8u(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVe1Ii(decodedUrl)
  if valid:
   if self.VVouTo(host, mac, ph1, VVhghQ=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVGYvI(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   if self.chCm.startswith("Zz1"):
    self.chCm = FFCqMm(self.chCm[3:])
   else:
    chUrl = self.VVuBqA(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCqssj.VVKAyG(self.chCm):
   chUrl = FFb0uP(self.chCm)
   chUrl = FFhukT(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVJ6wD(chUrl)
  bPath = CCQrUI.VVtUCc()
  if newIptvRef:
   if passedSELF:
    FF5kbK(passedSELF, newIptvRef, VVCqYJ=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FF5kbK(self, newIptvRef, VVCqYJ=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VV64ti(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVJ6wD(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV64ti(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF8p4l(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FF9bFs()
class CCi2ew(CCtvHX):
 def __init__(self, passedSession):
  CCtvHX.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVJuAG(VVw420  )
  Main_Menu.VVJuAG(VVwRfo)
  Main_Menu.VVJuAG(VVfGl8  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVxSI7, iPlayableService.evEOF: self.VVlG8L, iPlayableService.evEnd: self.VVFH3T})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVLM8b)
  except:
   self.timer2.callback.append(self.VVLM8b)
  self.timer2.start(3000, False)
  self.VVLM8b()
 def VVLM8b(self):
  if not CFG.downloadMonitor.getValue():
   self.VV7Tbb()
   return
  lst = CCATpC.VVdL1g()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFgx6P(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCATpC.VVO1eC(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCJ2zH.VVaSqo(self.passedSession, txt, 30)
   else    : CCJ2zH.VVwfPO(self.dnldWin, txt)
  elif self.dnldWin:
   self.VV7Tbb()
 def VV7Tbb(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVxSI7(self):
  self.startTime = iTime()
 def VVlG8L(self):
  global VVyONK
  VVyONK = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFoDQS(decodedUrl):
     self.isFromEOF = True
     CCJ2zH(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVFH3T(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVTem6)
  except:
   self.timer1.callback.append(self.VVTem6)
  self.timer1.start(100, True)
 def VVTem6(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VV3U8u(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCP76G.VVOb7V:
       self.isFromEOF = False
       self.VVGYvI(self.passedSession, isFromSession=True)
       InfoBar.instance.hide()
class CCi04I():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VV1BkA(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VV1BkA(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VV1BkA(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVqXR1, VVmc3z):
    path += fName
    if fileExists(path):
     for line in FF8p4l(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVtiCk(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCCW9K.VVGjvA(name):
   return CCCW9K.VVSyp1(name)
  return self.VVqL6b(name)
 def VVqL6b(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVOBp7(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVqL6b(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVz8Bv(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVdiPK(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VV5XOF(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCYF5X(CCqssj):
 def __init__(self):
  self.curPortalCatId = ""
  CCqssj.__init__(self)
 def VV0A7K(self):
  if CCYF5X.VVXK5R(self):
   FF4idw(self, BF(self.VVlAf8, 2), title="Searching ...")
 def VVYM78(self, winSession, url, mac):
  self.curUrl = url
  if CCYF5X.VVXK5R(self):
   if self.VVouTo(url, mac):
    FF4idw(winSession, self.VVAsLe, title="Checking Server ...")
   else:
    FFeF28(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVaTL8(self, item=None):
  if item:
   VVUD8b, txt, path, ndx = item
   enc = CC7ZOW.VVG0aP(path, self)
   if enc == -1:
    return
   self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVD4gY, path, enc)
       , VVHoAX = BF(self.VVX5sd, VVUD8b, path))
 def VVD4gY(self, path, enc, VVXuS2):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVXuS2.VVhaSh(totLines)
  VVXuS2.VVoBtV = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVXuS2 or VVXuS2.isCancelled:
     return
    VVXuS2.VVzPku(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip().strip('"') or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(';"') or "-"
     host = self.VVm3gE(url).strip('"')
     mac  = self.VVPh0F(mac)
     if host and mac and VVXuS2:
      VVXuS2.VVoBtV.append((str(c), str(lineNum), subj, host, mac, info))
     url = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip().strip('"') or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(';"') or "-"
      host = self.VVm3gE(url).strip('"')
      mac  = self.VVPh0F(mac)
      if host and mac and not mac.startswith("AC") and VVXuS2:
       VVXuS2.VVoBtV.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVX5sd(self, VVUD8b, path, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVoBtV:
   VVFkw1  = ("Home Menu"  , FFQbFt            , [])
   VVpxmm = ("Edit File"  , BF(self.VVyaoR, path)       , [])
   VVdyRp = ("M3U Options" , self.VVpYkj         , [])
   VV1SrQ = ("Check & Filter" , BF(self.VV4EcD, VVUD8b, path), [])
   VVrjyr  = ("Select"   , self.VVoUjV      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVRYg6  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVoBtV, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVmEJ8="#0a001122", VVd8a3="#0a001122", VVcGiE="#0a001122", VVh96o="#00004455", VV5t00="#0a333333", VVO2zv="#11331100", VVOisu=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VV2c9g:
    FF1lLq(VVgAw8, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV2c9g:
    FFeF28(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVpYkj(self, VVgAw8, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVGuvj = []
  VVGuvj.append(("Browse as M3U"  , "browse"))
  VVGuvj.append(("Download M3U File" , "downld"))
  FFSiXW(self, BF(self.VVv5eA, VVgAw8, host, mac), title=title, VVGuvj=VVGuvj, width=600, VVYJYo=True)
 def VVv5eA(self, VVgAw8, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF4idw(VVgAw8, BF(self.VVSfsA, VVgAw8, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFZRvh(self, BF(FF4idw, VVgAw8, BF(self.VVSfsA, VVgAw8, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVSfsA(self, VVgAw8, title, host, mac, item):
  p = CCqssj()
  m3u_Url = ""
  ok = p.VVouTo(host, mac, VVhghQ=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV5xpi(VVhghQ=False)
  if m3u_Url:
   if   item == "browse": self.VVcW0E(title, m3u_Url)
   elif item == "downld": self.VVzVpu(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFeF28(self, err or "No response from Server !", title=title)
 def VVoUjV(self, VVgAw8, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVYM78(VVgAw8, url, mac)
 def VVyaoR(self, path, VVgAw8, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCrb0k(self, path, VVHoAX=BF(self.VVF3Bh, VVgAw8), curRowNum=rowNum)
  else    : FFJBL5(self, path)
 def VV4EcD(self, VVUD8b, path, VVgAw8, title, txt, colList):
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVmyaE, VVgAw8)
      , VVHoAX = BF(self.VV7cDQ, VVUD8b, VVgAw8, path))
 def VVmyaE(self, VVgAw8, VVXuS2):
  VVXuS2.VVoBtV = []
  VVXuS2.VVhaSh(VVgAw8.VVPGr2())
  for row in VVgAw8.VVYgJy():
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVouTo(host, mac, VVhghQ=False):
    token, profile, tErr = self.VVp5NQ(VVhghQ=False)
    if token and VVXuS2 and not VVXuS2.isCancelled:
     res, err = self.VVpJfv(self.VVx1xy("itv"))
     if res and VVXuS2 and not VVXuS2.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVXuS2.VVzPku(0, showFound=True)
       VVXuS2.VVoBtV.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVXuS2:
    return
 def VV7cDQ(self, VVUD8b, VVgAw8, path, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VVoBtV:
   VVgAw8.close()
   VVUD8b.close()
   newPath = "%s_OK_%s.txt" % (path, FFguCY())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVoBtV:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF4aCb(str(threadCounter), VVEkv6)
    skipped = FF4aCb(str(threadTotal - threadCounter), VVEkv6)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVoBtV)
   txt += "%s\n\n%s"    %  (FF4aCb("Result File:", VV2Bne), newPath)
   FFPaL6(self, txt, title="Accessible Portals")
  elif VV2c9g:
   FFeF28(self, "No portal access found !", title="Accessible Portals")
 def VVq8pN(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFCqMm(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVAsLe(self):
  token, profile, tErr = self.VVp5NQ()
  if token:
   dots = "." * self.VVrQHb
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVBCiN(), "")
   dots += "*" if not self.VVFKbR == self.curUrl else ""
   VVGuvj  = self.VVAVi1()
   VVwpVu = self.VV7OhQ
   VVrN3L = self.VV4mV9
   VV91zg = ("Home Menu", FFQbFt)
   VVBLXn= ("Add to Menu", BF(CCCW9K.VVyn9s, self, True, self.VVFKbR + "\t" + self.VV8jm3))
   VVLIPG = ("Bookmark Server", BF(CCCW9K.VVCwh6, self, True, self.VVFKbR + "\t" + self.VV8jm3))
   VVUD8b = FFSiXW(self, None, title="Portal Resources (MAC=%s) %s" % (self.VV8jm3, dots), VVGuvj=VVGuvj, VVwpVu=VVwpVu, VVrN3L=VVrN3L, VV91zg=VV91zg, VVBLXn=VVBLXn, VVLIPG=VVLIPG)
   self.VVvi6Z(VVUD8b)
 def VV7OhQ(self, item=None):
  if item:
   VVUD8b, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF4idw(VVUD8b, BF(self.VVpGkn, mode), title="Reading Categories ...")
   else : FF4idw(VVUD8b, BF(self.VVz9Ml, VVUD8b, title), title="Reading Account ...")
 def VVz9Ml(self, VVUD8b, title, forceMoreInfo=False):
  rows, totCols = self.VVUGdF(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV8jm3)
  VVFkw1  = ("Home Menu" , FFQbFt           , [])
  VVdyRp  = None
  if VVwauR:
   VVdyRp = ("Get JS"  , BF(self.VVjfCk, self.VVGVwj()) , [])
  if totCols == 2:
   VV1SrQ = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VV1SrQ = ("More Info.", BF(self.VVh1t2, VVUD8b)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFBxNx(self, None, title=title, width=1200, header=header, VVWhjq=rows, VVmQwL=widths, VVCppa=26, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VV1SrQ=VV1SrQ, VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000", searchCol=searchCol)
 def VVjfCk(self, url, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVQ9FY, url), title="Getting JS ...")
 def VVQ9FY(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VV8jm3)
  ver, err = self.VV2LrZ(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VV2LrZ(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFPaL6(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVh1t2(self, VVUD8b, VVgAw8, title, txt, colList):
  VVgAw8.cancel()
  FF4idw(VVUD8b, BF(self.VVz9Ml, VVUD8b, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVpGkn(self, mode):
  token, profile, tErr = self.VVp5NQ()
  if not token:
   return
  res, err = self.VVpJfv(self.VVx1xy(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCCW9K.VVoNAp(item, "id"       )
      Title  = CCCW9K.VVoNAp(item, "title"      )
      censored = CCCW9K.VVoNAp(item, "censored"     )
      Title = self.VVz8Bv(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVTypc:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVFAhu(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm(mode)
   mName = self.VVFAhu(mode)
   VViila  = (""     , BF(self.VVMg2g, mode), [])
   VVrjyr   = ("Show List"   , BF(self.VV93y3, mode)   , [])
   VVFkw1  = ("Home Menu"   , FFQbFt        , [])
   if mode in ("vod", "series"):
    VVpxmm = ("Find in %s" % mName , BF(self.VV818J, mode, False), [])
    VV1SrQ = ("Find in Selected" , BF(self.VV818J, mode, True) , [])
   else:
    VVpxmm = None
    VV1SrQ = None
   header   = None
   widths   = (100   , 0  )
   FFBxNx(self, None, title=title, width=1200, header=header, VVWhjq=list, VVmQwL=widths, VVCppa=30, VVFkw1=VVFkw1, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VViila=VViila, VVrjyr=VVrjyr, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVxSMk:
     txt += "\n\n( %s )" % self.VVxSMk
   else:
    txt = "Could not get Categories from server!"
   FFeF28(self, txt, title=title)
 def VV5khd(self, mode, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VV4bOD, mode, VVgAw8, title, txt, colList), title="Downloading ...")
 def VV4bOD(self, mode, VVgAw8, title, txt, colList):
  token, profile, tErr = self.VVp5NQ()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVpJfv(self.VVyLZZ(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCCW9K.VVoNAp(item, "id"    )
      actors   = CCCW9K.VVoNAp(item, "actors"   )
      added   = CCCW9K.VVoNAp(item, "added"   )
      age    = CCCW9K.VVoNAp(item, "age"   )
      category_id  = CCCW9K.VVoNAp(item, "category_id" )
      description  = CCCW9K.VVoNAp(item, "description" )
      director  = CCCW9K.VVoNAp(item, "director"  )
      genres_str  = CCCW9K.VVoNAp(item, "genres_str"  )
      name   = CCCW9K.VVoNAp(item, "name"   )
      path   = CCCW9K.VVoNAp(item, "path"   )
      screenshot_uri = CCCW9K.VVoNAp(item, "screenshot_uri" )
      series   = CCCW9K.VVoNAp(item, "series"   )
      cmd    = CCCW9K.VVoNAp(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VViila = (""     , BF(self.VVTpWu, mode, True)  , [])
   VVrjyr  = ("Play"    , BF(self.VVF89f, mode)       , [])
   VVGySq = (""     , BF(self.VV0NCW, mode)     , [])
   VVFkw1 = ("Home Menu"   , FFQbFt            , [])
   VVdyRp = ("Download Options" , BF(self.VVefr7, mode, "sp", seriesName) , [])
   VVpxmm = ("Options"   , BF(self.VVg3sr, "pEp", mode, seriesName) , [])
   VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVRYg6  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFBxNx(self, None, title=seriesName, width=1200, header=header, VVWhjq=list, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VViila=VViila, VVrjyr=VVrjyr, VVGySq=VVGySq, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindIptv, VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000")
  else:
   FFeF28(self, "Could not get Episodes from server!", title=seriesName)
 def VV818J(self, mode, searchInCat, VVgAw8, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVGuvj = []
  VVGuvj.append(("Keyboard"  , "manualEntry"))
  VVGuvj.append(("From Filter" , "fromFilter"))
  FFSiXW(self, BF(self.VV9g5t, VVgAw8, mode, searchCatId), title="Input Type", VVGuvj=VVGuvj, width=400)
 def VV9g5t(self, VVgAw8, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFrwu2(self, BF(self.VVpagy, VVgAw8, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCiRFn(self)
    filterObj.VVi7C2(BF(self.VVpagy, VVgAw8, mode, searchCatId))
 def VVpagy(self, VVgAw8, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFCRXL(CFG.lastFindIptv, searchName)
   title = self.VVhmF2(mode, searchName)
   if "," in searchName : FFeF28(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFeF28(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVdiPK([searchName]):
     FFeF28(self, self.VV5XOF(), title=title)
    else:
     self.VVDtnX(mode, searchName, "", searchName, searchCatId)
 def VV93y3(self, mode, VVgAw8, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVDtnX(mode, bName, catID, "", "")
 def VVDtnX(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVwMvh, mode, bName, catID, searchName, searchCatId)
      , VVHoAX = BF(self.VV4Q1C, mode, bName, catID, searchName, searchCatId))
 def VV4Q1C(self, mode, bName, catID, searchName, searchCatId, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVhmF2(mode, searchName)
  else   : title = "%s : %s" % (self.VVFAhu(mode), bName)
  if VVoBtV:
   VVdyRp = None
   VVpxmm = None
   if mode == "series":
    VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm("series2")
    VVrjyr  = ("Episodes"   , BF(self.VV5khd, mode)           , [])
   else:
    VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm("")
    VVrjyr  = ("Play"    , BF(self.VVF89f, mode)           , [])
    VVdyRp = ("Download Options" , BF(self.VVefr7, mode, "vp" if mode == "vod" else "", "") , [])
    VVpxmm = ("Options"   , BF(self.VVg3sr, "pCh", mode, bName)      , [])
   VViila = (""      , BF(self.VVTpWu, mode, False)      , [])
   VVGySq = (""      , BF(self.VV75ZD, mode)         , [])
   VVFkw1 = ("Home Menu"    , FFQbFt                , [])
   VV1SrQ = ("Posters Mode"   , BF(self.VVvNPX, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVRYg6  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVoBtV, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindIptv, VVrjyr=VVrjyr, VViila=VViila, VVGySq=VVGySq, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o, VVOisu=True, searchCol=1)
   if not VV2c9g:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVgAw8.VVtnNY(VVgAw8.VVgH9X() + tot)
    if threadErr: FF1lLq(VVgAw8, "Error while reading !", 2000)
    else  : FF1lLq(VVgAw8, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFeF28(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFeF28(self, "Could not get list from server !", title=title)
 def VV75ZD(self, mode, VVgAw8, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF4aCb(x, VV2Bne), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFw3XJ(self, fncMode=CCM3PM.VV5NDk, portalHost=self.VVFKbR, portalMac=self.VV8jm3, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVcthp(mode, VVgAw8, title, txt, colList)
 def VV0NCW(self, mode, VVgAw8, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF4aCb(colList[10], VVE7tQ)
  txt += "Description:\n%s" % FF4aCb(colList[11], VVE7tQ)
  self.VVcthp(mode, VVgAw8, title, txt, colList)
 def VVcthp(self, mode, VVgAw8, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, colList)
  refCode, chUrl = self.VVoW2o(self.VVFKbR, self.VV8jm3, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFw3XJ(self, fncMode=CCM3PM.VVMNyu, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVwMvh(self, mode, bName, catID, searchName, searchCatId, VVXuS2):
  try:
   token, profile, tErr = self.VVp5NQ()
   if not token:
    return
   if VVXuS2.isCancelled:
    return
   VVXuS2.VVoBtV, total_items, max_page_items, err = self.VVeT4z(mode, catID, 1, 1, searchName, searchCatId)
   if VVXuS2.isCancelled:
    return
   if VVXuS2.VVoBtV and total_items > -1 and max_page_items > -1:
    VVXuS2.VVhaSh(total_items)
    VVXuS2.VVzPku(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVXuS2.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVeT4z(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVXuS2.VVJR10()
     if VVXuS2.isCancelled:
      return
     if list:
      VVXuS2.VVoBtV += list
      VVXuS2.VVzPku(len(list), True)
  except:
   pass
 def VVeT4z(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVdZud(mode, searchName, searchCatId, page)
  else   : url = self.VVZ3x3(mode, catID, page)
  res, err = self.VVpJfv(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVhaKT(CCCW9K.VVoNAp(item, "total_items" ))
     max_page_items = self.VVhaKT(CCCW9K.VVoNAp(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCCW9K.VVoNAp(item, "id"    )
      name   = CCCW9K.VVoNAp(item, "name"   )
      o_name   = CCCW9K.VVoNAp(item, "o_name"   )
      category_id  = CCCW9K.VVoNAp(item, "category_id" )
      tv_genre_id  = CCCW9K.VVoNAp(item, "tv_genre_id" )
      number   = CCCW9K.VVoNAp(item, "number"   ) or str(counter)
      logo   = CCCW9K.VVoNAp(item, "logo"   )
      screenshot_uri = CCCW9K.VVoNAp(item, "screenshot_uri" )
      pic    = CCCW9K.VVoNAp(item, "pic"   )
      cmd    = CCCW9K.VVoNAp(item, "cmd"   )
      censored  = CCCW9K.VVoNAp(item, "censored"  )
      genres_str  = CCCW9K.VVoNAp(item, "genres_str"  )
      curPlay   = CCCW9K.VVoNAp(item, "cur_playing" )
      actors   = CCCW9K.VVoNAp(item, "actors"   )
      descr   = CCCW9K.VVoNAp(item, "description" )
      director  = CCCW9K.VVoNAp(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFHH9F(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVFKbR + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVtiCk(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVhaKT(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVF89f(self, mode, VVgAw8, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, colList)
  refCode, chUrl = self.VVoW2o(self.VVFKbR, self.VV8jm3, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVGjvA(chName):
   FF1lLq(VVgAw8, "This is a marker!", 300)
  else:
   FF4idw(VVgAw8, BF(self.VVl23Y, mode, VVgAw8, chUrl), title="Playing ...")
 def VVl23Y(self, mode, VVgAw8, chUrl):
  FF5kbK(self, chUrl, VVCqYJ=False)
  CCP76G.VVBpiW(self.session, iptvTableParams=(self, VVgAw8, mode))
 def VV1haT(self, mode, VVgAw8, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, colList)
  refCode, chUrl = self.VVoW2o(self.VVFKbR, self.VV8jm3, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV8REu(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVXK5R(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVGuvj = []
    VVGuvj.append((title        , "inst" ))
    VVGuvj.append(("Update Packages then %s" % title , "updInst" ))
    FFSiXW(SELF, BF(CCYF5X.VVYOdQ, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVGuvj=VVGuvj)
   return False
 @staticmethod
 def VVYOdQ(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFnws9(VVaMYp, "")
   if cmdUpd:
    cmdInst = FFNCOV(VVy8Lf, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF1NOx(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVdenE=cbFnc)
   else:
    FFDayU(SELF)
 def VVCFxT(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVe1Ii(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVvi6Z(self, VVUD8b):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCFxT()
  if all((curMode, curHost, curCat)) and curHost == self.VVFKbR:
   VVUD8b.VVn6An({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVMg2g(self, mode, VVgAw8, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCFxT()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVFKbR:
   VVgAw8.VVAyL9({1:curCat})
 def VVTpWu(self, mode, isEp, VVgAw8, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCFxT()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVFKbR:
   if mode in ("itv", "vod"):
    VVgAw8.VVAyL9({2:curStID})
   else: #series
    if isEp:
     VVgAw8.VVAyL9({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVgAw8.VVAyL9({2:ser2})
     if not ok: VVgAw8.VVAyL9({2:ser1})
class CCCW9K(Screen, CCYF5X, CCi04I, CCRasO):
 VV0Z6Q    = 0
 VVf4DH    = 1
 VV1wnY    = 2
 VV6lZY    = 3
 VVYMfp     = 4
 VVfVqa     = 5
 VVKHYe     = 6
 VVSA6Y     = 7
 VVdpO3     = 8
 VVAD9l     = 9
 VVpWMB      = 10
 VVkc1E     = 11
 VV1y43     = 12
 VVu7y4     = 13
 VVbPYG     = 14
 VV1qV4      = 15
 VVkSSJ      = 16
 VVlnEv      = 17
 VVWLk5      = 18
 VVJ1l2      = 19
 VVYl8o    = 0
 VVwPpy   = 1
 VVSStX   = 2
 VVJe7g   = 3
 VV9Zmj  = 4
 VVUUnH  = 5
 VVMAzw   = 6
 VVDm2k   = 7
 VVwpUk  = 8
 VV2GkZ  = 9
 VVz13U  = 10
 VVZUHT = 0
 VVgs4B = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVgAw8    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVkKctData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCCW9K.VVEC3O(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCYF5X.__init__(self)
  CCi04I.__init__(self)
  VVGuvj = self.VV6wFG()
  FFOUwv(self, title="IPTV", VVGuvj=VVGuvj)
  self["myActionMap"].actions.update({
   "menu" : self.VVK7FY
  })
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVkrmw)
  global VVs06X
  VVs06X = True
 def VVy4Yl(self):
  self["myMenu"].setList(self.VV6wFG())
  FFMHNW(self)
  FFRBDi(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFMOVh(self["myMenu"])
   FFgD4Y(self)
   if self.m3uOrM3u8File:
    self.VVRP2Y(self.m3uOrM3u8File)
   else:
    self.VVTD4q()
 def VVTD4q(self):
  qUrl, decodedUrl, iptvRef = CCCW9K.VVFm8X(self)
  if qUrl or "chCode" in iptvRef:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FF5GKV("VVs06X")
 def VVkrmw(self):
  if self["myMenu"].getCurrent()[1] in ("VVxqas", "VVqwwXPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVK7FY(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVqwwXPortal" : confItem = CFG.favServerPortal
   elif item == "VVxqas" : confItem = CFG.favServerPlaylist
   else         : return
   FFZRvh(self, BF(self.VVQ89U, confItem), 'Remove from menu ?', title=title)
 def VVQ89U(self, confItem):
  FFCRXL(confItem, "")
  self.VVy4Yl()
 def VV6wFG(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVwWfr
  VVGuvj = []
  if isFav1: VVGuvj.append((c +  "Favourite Playlist Server"   , "VVxqas" ))
  if isFav2: VVGuvj.append((c +  "Favourite Portal Server"    , "VVqwwXPortal" ))
  VVGuvj.append(("IPTV Server Browser (from Playlists)"     , "VVkKct_fromPlayList" ))
  VVGuvj.append(("IPTV Server Browser (from Portal List)"    , "VVkKct_fromMac"  ))
  VVGuvj.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVkKct_fromM3u"  ))
  qUrl, decodedUrl, iptvRef = CCCW9K.VVFm8X(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVGuvj.append(FFUHeM("IPTV Server Browser (from Current Channel)", "VVkKct_fromCurrChan", fromCurCond))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("M3U/M3U8 File Browser"        , "VVMmFi"   ))
  if self.iptvFileAvailable:
   VVGuvj.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVGuvj.append(FFUHeM("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVGuvj.append(VVnek4)
   c1, c2 = VVXSg2, VV2Bne
   t1 = FF4aCb("auto-match names", VVwWfr)
   t2 = FF4aCb("from xml file"  , VVwWfr)
   VVGuvj.append((c1 + "Count Available IPTV Channels"    , "VV5cfB"    ))
   VVGuvj.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVGuvj.append(VVnek4)
   VVGuvj.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVGuvj.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVWXR8" ))
   VVGuvj.append((VVT2Mp + "More Reference Tools ..."  , "VVbMZV"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Reload Channels and Bouquets"       , "VVEVlf"   ))
  VVGuvj.append(VVnek4)
  if not CCATpC.VVbPjj():
   VVGuvj.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVGuvj.append(("Download Manager ... No downloads"    ,       ))
  return VVGuvj
 def VVn6jJ(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVxmEz"   : self.VVxmEz()
   elif item == "VVXGZH" : FFZRvh(self, self.VVXGZH, "Change Current List References to Unique Codes ?")
   elif item == "VVHR4D_rows" : FFZRvh(self, BF(FF4idw, self.VVgAw8, self.VVHR4D), "Change Current List References to Identical Codes ?")
   elif item == "VVS0GD"   : self.VVS0GD(tTitle)
   elif item == "VV1M8m"   : self.VV1M8m(tTitle)
   elif item == "VVxqas" : self.VVqwwX(False)
   elif item == "VVqwwXPortal" : self.VVqwwX(True)
   elif item == "VVkKct_fromPlayList" : FF4idw(self, BF(self.VVlAf8, 1), title=title)
   elif item == "VVkKct_fromM3u"  : FF4idw(self, BF(self.VVUGyS, CCCW9K.VVZUHT), title=title)
   elif item == "VVkKct_fromMac"  : self.VV0A7K()
   elif item == "VVkKct_fromCurrChan" : self.VV8INc()
   elif item == "VVMmFi"   : self.VVMmFi()
   elif item == "iptvTable_all"   : FF4idw(self, BF(self.VVU8HB, self.VV0Z6Q), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCCW9K.VVM8NU(self)
   elif item == "refreshIptvPicons"  : self.VV0RiN()
   elif item == "VV5cfB"    : FF4idw(self, self.VV5cfB)
   elif item == "copyEpgPicons"   : self.VV7Cff(False)
   elif item == "renumIptvRef_fromFile" : self.VV7Cff(True)
   elif item == "VVWXR8" : FFZRvh(self, BF(FF4idw, self, self.VVWXR8), VVrAp2="Continue ?")
   elif item == "VVbMZV"    : self.VVbMZV()
   elif item == "VVEVlf"   : FF4idw(self, BF(CC1mtH.VVEVlf, self))
   elif item == "dload_stat"    : CCATpC.VVjqqb(self)
 def VVMmFi(self):
  if CCYF5X.VVXK5R(self):
   FF4idw(self, BF(self.VVUGyS, CCCW9K.VVgs4B), title="Searching ...")
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVn6jJ(item)
 def VVU8HB(self, mode):
  VVJpUa = self.VVMHg1(mode)
  if VVJpUa:
   VVdyRp = ("Current Service", self.VVVioP , [])
   VVpxmm = ("Options"  , self.VVImS2   , [])
   VV1SrQ = ("Filter"   , self.VVmTHu   , [])
   VVrjyr  = ("Play"   , BF(self.VVL0Ek)  , [])
   VVGySq = (""    , self.VVnTM9    , [])
   VViila = (""    , self.VVegTD     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVRYg6  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFBxNx(self, None, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26
     , VVrjyr=VVrjyr, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVGySq=VVGySq, VViila=VViila
     , VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000", VVOisu=True, searchCol=1)
  else:
   if mode == self.VVAD9l: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFeF28(self, err)
 def VVegTD(self, VVgAw8, title, txt, colList):
  self.VVgAw8 = VVgAw8
 def VVImS2(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(("Add Current List to a New Bouquet"    , "VVxmEz"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Current List References to Unique Codes" , "VVXGZH"))
  VVGuvj.append(("Change Current List References to Identical Codes", "VVHR4D_rows" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Share Reference with DVB Service (manual entry)" , "VVS0GD"   ))
  VVGuvj.append(("Share Reference with DVB Service (auto-find)"  , "VV1M8m"   ))
  FFSiXW(self, self.VVn6jJ, title="IPTV Tools", VVGuvj=VVGuvj)
 def VVmTHu(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVUdXk, VVgAw8))
 def VVUdXk(self, VVgAw8):
  VVGuvj = []
  VVGuvj.append(("All"         , "all"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Prefix of Selected Channel"   , "sameName" ))
  VVGuvj.append(("Suggest Words from Selected Channel" , "partName" ))
  VVGuvj.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVGuvj.append(("Duplicate References"     , "depRef"  ))
  VVGuvj.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVGuvj.append(("Stream Relay"       , "SRelay"  ))
  VVGuvj.append(FFJ9Ko("Category"))
  VVGuvj.append(("Live TV"        , "live"  ))
  VVGuvj.append(("VOD"         , "vod"   ))
  VVGuvj.append(("Series"        , "series"  ))
  VVGuvj.append(("Uncategorised"      , "uncat"  ))
  VVGuvj.append(FFJ9Ko("Media"))
  VVGuvj.append(("Video"        , "video"  ))
  VVGuvj.append(("Audio"        , "audio"  ))
  VVGuvj.append(FFJ9Ko("File Type"))
  VVGuvj.append(("MKV"         , "MKV"   ))
  VVGuvj.append(("MP4"         , "MP4"   ))
  VVGuvj.append(("MP3"         , "MP3"   ))
  VVGuvj.append(("AVI"         , "AVI"   ))
  VVGuvj.append(("FLV"         , "FLV"   ))
  VVGuvj.extend(CCQrUI.VVbmna(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVyXvi, VVgAw8) if VVgAw8.VVgH9X().startswith("IPTV Filter ") else None
  filterObj = CCiRFn(self)
  filterObj.VVhJnM(VVGuvj, VVGuvj, BF(self.VV15GS, VVgAw8, False), inFilterFnc=inFilterFnc)
 def VVyXvi(self, VVgAw8, VVUD8b, item):
  self.VV15GS(VVgAw8, True, item)
 def VV15GS(self, VVgAw8, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVgAw8.VVhkzh(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV0Z6Q , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVf4DH , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV1wnY , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV6lZY , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVKHYe  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVSA6Y  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVdpO3  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVAD9l  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVpWMB   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVkc1E  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV1y43  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVu7y4  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVbPYG  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV1qV4   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVkSSJ   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVlnEv   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVWLk5   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVJ1l2   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVYMfp  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVfVqa  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV1wnY:
   VVGuvj = []
   chName = VVgAw8.VVhkzh(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVGuvj.append((item, item))
    if not VVGuvj and chName:
     VVGuvj.append((chName, chName))
    FFSiXW(self, BF(self.VVS5UC, title), title="Words from Current Selection", VVGuvj=VVGuvj)
   else:
    VVgAw8.VVmaQr("Invalid Channel Name")
  else:
   words, asPrefix = CCiRFn.VVAtaF(words)
   if not words and mode in (self.VVYMfp, self.VVfVqa):
    FF1lLq(self.VVgAw8, "Incorrect filter", 2000)
   else:
    FF4idw(self.VVgAw8, BF(self.VVPNEY, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVS5UC(self, title, word=None):
  if word:
   words = [word.lower()]
   FF4idw(self.VVgAw8, BF(self.VVPNEY, self.VV1wnY, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVSyp1(txt):
  return "#f#11ffff00#" + txt
 def VVPNEY(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVJpUa = self.VVGSUk(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVJpUa = self.VVMHg1(mode=mode, words=words, asPrefix=asPrefix)
  if VVJpUa : self.VVgAw8.VVFDhD(VVJpUa, title)
  else  : self.VVgAw8.VVmaQr("Not found")
 def VVGSUk(self, mode=0, words=None, asPrefix=False):
  VVJpUa = []
  for row in self.VVgAw8.VVYgJy():
   row = list(map(str.strip, row))
   chNum, chName, VVQdU6, chType, refCode, url = row
   if self.VVYRve(mode, refCode, FFb0uP(url).lower(), chName, words, VVQdU6.lower(), asPrefix):
    VVJpUa.append(row)
  VVJpUa = self.VVduQH(mode, VVJpUa)
  return VVJpUa
 def VVMHg1(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVJpUa = []
  files = CCCW9K.VVEC3O()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFhqv7(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVQdU6 = span.group(1)
    else : VVQdU6 = ""
    VVQdU6_lCase = VVQdU6.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVGjvA(chName): chNameMod = self.VVSyp1(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVQdU6, chType + (" SRel" if FFyCwy(url) else ""), refCode, url)
     if self.VVYRve(mode, refCode, FFb0uP(url).lower(), chName, words, VVQdU6_lCase, asPrefix):
      VVJpUa.append(row)
      chNum += 1
  VVJpUa = self.VVduQH(mode, VVJpUa)
  return VVJpUa
 def VVduQH(self, mode, VVJpUa):
  newRows = []
  if VVJpUa and mode == self.VVKHYe:
   counted  = iCounter(elem[4] for elem in VVJpUa)
   for item in VVJpUa:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVJpUa
 def VVYRve(self, mode, refCode, tUrl, chName, words, VVQdU6_lCase, asPrefix):
  if   mode == self.VV0Z6Q : return True
  elif mode == self.VVKHYe : return True
  elif mode == self.VVSA6Y  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVdpO3 : return FFyCwy(tUrl)
  elif mode == self.VVu7y4  : return CCCW9K.VVIysy(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVbPYG  : return CCCW9K.VVIysy(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVAD9l  : return CCCW9K.VVIysy(tUrl, compareType="live")
  elif mode == self.VVpWMB  : return CCCW9K.VVIysy(tUrl, compareType="movie")
  elif mode == self.VVkc1E : return CCCW9K.VVIysy(tUrl, compareType="series")
  elif mode == self.VV1y43  : return CCCW9K.VVIysy(tUrl, compareType="")
  elif mode == self.VV1qV4  : return CCCW9K.VVIysy(tUrl, compareExt="mkv")
  elif mode == self.VVkSSJ  : return CCCW9K.VVIysy(tUrl, compareExt="mp4")
  elif mode == self.VVlnEv  : return CCCW9K.VVIysy(tUrl, compareExt="mp3")
  elif mode == self.VVWLk5  : return CCCW9K.VVIysy(tUrl, compareExt="avi")
  elif mode == self.VVJ1l2  : return CCCW9K.VVIysy(tUrl, compareExt="flv")
  elif mode == self.VVf4DH: return chName.lower().startswith(words[0])
  elif mode == self.VV1wnY: return words[0] in chName.lower()
  elif mode == self.VV6lZY: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVYMfp : return words[0] == VVQdU6_lCase
  elif mode == self.VVfVqa :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVxmEz(self):
  picker = CCQrUI(self, self.VVgAw8, "Add to Bouquet", self.VVj7Jg)
 def VVj7Jg(self):
  chUrlLst = []
  for row in self.VVgAw8.VVYgJy():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVbMZV(self):
  t1 = FF4aCb("Bouquet" , VV2Bne)
  t2 = FF4aCb("ALL"  , VVT2Mp)
  t3 = FF4aCb("Unique"  , VVXSg2)
  t4 = FF4aCb("Identical" , VVwWfr)
  VVGuvj = []
  VVGuvj.append((VVE7n3 + "Check System Acceptable Reference Types", "VVUdKX"))
  VVGuvj.append(FFUHeM("Check Reference Codes Format", "VVh3c4", self.iptvFileAvailable, VVE7n3))
  VVGuvj.append(VVnek4)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVGuvj.append((txt % t1, "VVYQIC" ))
  VVGuvj.append((txt % t2, "VV3Gda_all"  ))
  VVGuvj.append(VVnek4)
  txt = "Change %s References to %s Codes .."
  VVGuvj.append((txt % (t1, t3), "VV6QtJ" ))
  VVGuvj.append((txt % (t2, t3), "VViH7V"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change %s References to %s Codes" % (t2, t4) , "VVHR4D_all"))
  VVwpVu = self.VVyXNu
  FFSiXW(self, None, width=1150, title="IPTV Reference Tools", VVGuvj=VVGuvj, VVwpVu=VVwpVu, VVmEJ8="#22002233", VVd8a3="#22001122")
 def VVyXNu(self, item=None):
  if item:
   ques = "Continue ?"
   VVUD8b, txt, item, ndx = item
   if   item == "VVUdKX"    : FF4idw(VVUD8b, self.VVUdKX)
   elif item == "VVh3c4"     : FF4idw(VVUD8b, self.VVh3c4)
   elif item == "VVYQIC" : self.VV68mt(VVUD8b, self.VVx0ZS)
   elif item == "VV3Gda_all"  : self.VVx0ZS(VVUD8b, None, None)
   elif item == "VV6QtJ" : self.VV6QtJ(VVUD8b, txt)
   elif item == "VViH7V"  : FFZRvh(self, BF(self.VViH7V , VVUD8b, txt), title=txt, VVrAp2=ques)
   elif item == "VVHR4D_all"  : FFZRvh(self, BF(FF4idw, VVUD8b, self.VVHR4D), title=txt, VVrAp2=ques)
 def VVx0ZS(self, VVUD8b, bName, bPath):
  VVGuvj = []
  for rt in CCCW9K.VVDY0z():
   VVGuvj.append(("%s\t ... %s" % (rt, CCCW9K.VVKeHC(rt)), rt))
  FFSiXW(self, BF(self.VV2uk0, VVUD8b, bName, bPath), VVGuvj=VVGuvj, width=800, title="Change Reference Types to:")
 def VV2uk0(self, VVUD8b, bName, bPath, rType=None):
  if rType:
   self.VV4KDp(VVUD8b, bName, bPath, rType)
 def VV68mt(self, VVUD8b, fnc):
  VVGuvj = CCQrUI.VVbmna()
  if VVGuvj:
   FFSiXW(self, BF(self.VVQspc, VVUD8b, fnc), VVGuvj=VVGuvj, title="IPTV Bouquets", VVYJYo=True)
  else:
   FF1lLq(VVUD8b, "No bouquets Found !", 1500)
 def VVQspc(self, VVUD8b, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVgBUe + span.group(1)
    if fileExists(bPath): fnc(VVUD8b, bName, bPath)
    else    : FF1lLq(VVUD8b, "Bouquet file not found!", 2000)
   else:
    FF1lLq(VVUD8b, "Cannot process bouquet !", 2000)
 def VV4KDp(self, VVUD8b, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF4aCb(bName, VVc1MO)
  else : title = "Change for %s" % FF4aCb("All IPTV Services", VVc1MO)
  FFZRvh(self, BF(FF4idw, VVUD8b, BF(self.VVZ5iB, VVUD8b, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF4aCb(rType, VVc1MO), title=title)
 def VVZ5iB(self, VVUD8b, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCCW9K.VVEC3O()
  if files:
   newRType = rType + ":"
   piconPath = CCnBmO.VVYQsq()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCZHbk.VVWzKq(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFeF28(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FF7Jdu("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FF7Jdu(cmd)
  self.VVR5Q7(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VV5cfB(self):
  totFiles = 0
  files  = CCCW9K.VVEC3O()
  if files:
   totFiles = len(files)
  totChans = 0
  VVJpUa = self.VVMHg1()
  if VVJpUa:
   totChans = len(VVJpUa)
  FFPaL6(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVh3c4(self):
  files = CCCW9K.VVEC3O()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFhqv7(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV1udq
   else    : color = VVEkv6
   totInvalid = FF4aCb(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF4aCb("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFPaL6(self, txt, title="Check IPTV References")
 def VVUdKX(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCCW9K.VVDY0z()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCQrUI.VVMfMj(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VV9fAX = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV9fAX:
   VV2G1l = FF7SJo(VV9fAX)
   if VV2G1l:
    for service in VV2G1l:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVgBUe + userBName
  bFile = VVgBUe + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFTMeZ("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFTMeZ("rm -f '%s'" % path)
  FF7Jdu(cmd)
  FF9bFs()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV1udq
    else     : res, color = "No" , VVEkv6
    pl = CCCW9K.VVKeHC(item)
    txt += "    %s\t: %s%s\n" % (item, FF4aCb(res, color), FF4aCb("\t... %s" % pl, VVE7tQ) if pl else "")
   FFPaL6(self, txt, title=title)
  else:
   txt = FFeF28(self, "Could not complete the test on your system!", title=title)
 def VVWXR8(self):
  VVAvkb, err = CC1mtH.VVb6EG(self, CC1mtH.VVzVs0)
  if VVAvkb:
   totChannels = 0
   totChange = 0
   for path in CCCW9K.VVEC3O():
    toSave = False
    txt = FFhqv7(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVAvkb.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVR5Q7(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFeF28(self, 'No channels in "lamedb" !')
 def VViH7V(self, VVUD8b, title):
  bFiles = CCCW9K.VVEC3O()
  if bFiles: self.VVrSgD(bFiles, title)
  else  : FF1lLq(VVUD8b, "No bouquets files !", 1500)
 def VV6QtJ(self, VVUD8b, title):
  self.VV68mt(VVUD8b, BF(self.VVmeWZ, title))
 def VVmeWZ(self, title, VVUD8b, bName, bPath):
  self.VVrSgD([bPath], title)
 def VVrSgD(self, bFiles, title):
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVe8je, bFiles)
      , VVHoAX = BF(self.VVJ87q, title))
 def VVe8je(self, bFiles, VVXuS2):
  VVXuS2.VVoBtV = ""
  VVXuS2.VVvANc("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF8p4l(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVXuS2 or VVXuS2.isCancelled:
   return
  elif not totLines:
   VVXuS2.VVoBtV = "No IPTV Services !"
   return
  else:
   VVXuS2.VVhaSh(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF8p4l(path)
    for ndx, line in enumerate(lines):
     if not VVXuS2 or VVXuS2.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVXuS2:
       VVXuS2.VVvANc("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVXuS2:
       VVXuS2.VVzPku(1)
      refCode, startId, startNS = CCQrUI.VVOzvp(rType, CCQrUI.VVgGXY, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVXuS2:
        VVXuS2.VVoBtV = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVJ87q(self, title, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVoBtV:
   txt += "\n\n%s\n%s" % (FF4aCb("Ended with Error:", VVEkv6), VVoBtV)
  self.VVR5Q7(True, title, txt)
 def VVXGZH(self):
  bFiles = CCCW9K.VVEC3O()
  if not bFiles:
   FF1lLq(self.VVgAw8, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVgAw8.VVYgJy():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FF1lLq(self.VVgAw8, "Cannot read list", 1500)
   return
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VV08Ym, bFiles, tableRefList)
      , VVHoAX = BF(self.VVJ87q, "Change Current List References to Unique Codes"))
 def VV08Ym(self, bFiles, tableRefList, VVXuS2):
  VVXuS2.VVoBtV = ""
  VVXuS2.VVvANc("Reading System References ...")
  refLst = CCQrUI.VV5NMM(CCQrUI.VVgGXY, stripRType=True)
  if not VVXuS2 or VVXuS2.isCancelled:
   return
  VVXuS2.VVhaSh(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFhqv7(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVXuS2 or VVXuS2.isCancelled:
     return
    VVXuS2.VVvANc("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVXuS2 or VVXuS2.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVXuS2.VVzPku(1)
      refCode, startId, startNS = CCQrUI.VVOzvp(rType, CCQrUI.VVgGXY, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVXuS2:
        VVXuS2.VVoBtV = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVHR4D(self):
  list = None
  if self.VVgAw8:
   list = []
   for row in self.VVgAw8.VVYgJy():
    list.append(row[4] + row[5])
  files = CCCW9K.VVEC3O()
  totChange = 0
  if files:
   for path in files:
    lines = FF8p4l(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVR5Q7(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVR5Q7(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF9bFs()
   if refreshTable and self.VVgAw8:
    VVJpUa = self.VVMHg1()
    if VVJpUa and self.VVgAw8:
     self.VVgAw8.VVFDhD(VVJpUa, self.tableTitle)
     self.VVgAw8.VVmaQr(txt)
   FFPaL6(self, txt, title=title)
  else:
   FFDx6X(self, "No changes.")
 @staticmethod
 def VVEC3O(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVgBUe + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFhqv7(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVnTM9(self, VVgAw8, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFb0uP(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFw3XJ(self, fncMode=CCM3PM.VVP8uW, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVmmgY(self, VVgAw8, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVL0Ek(self, VVgAw8, title, txt, colList):
  chName, chUrl = self.VVmmgY(VVgAw8, colList)
  self.VVrElG(VVgAw8, chName, chUrl, "localIptv")
 def VVHDBn(self, mode, VVgAw8, colList):
  chName, chUrl, picUrl, refCode = self.VVf0BE(mode, colList)
  return chName, chUrl
 def VV8v4H(self, mode, VVgAw8, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVf0BE(mode, colList)
  self.VVrElG(VVgAw8, chName, chUrl, mode)
 def VVrElG(self, VVgAw8, chName, chUrl, playerFlag):
  chName = FFWkM4(chName)
  if self.VVGjvA(chName):
   FF1lLq(VVgAw8, "This is a marker!", 300)
  else:
   FF4idw(VVgAw8, BF(self.VVflsF, VVgAw8, chUrl, playerFlag), title="Playing ...")
 def VVflsF(self, VVgAw8, chUrl, playerFlag):
  FF5kbK(self, chUrl, VVCqYJ=False)
  CCP76G.VVBpiW(self.session, iptvTableParams=(self, VVgAw8, playerFlag))
 @staticmethod
 def VVGjvA(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVVioP(self, VVgAw8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if refCode:
   url1 = FFb0uP(origUrl.strip())
   for ndx, row in enumerate(VVgAw8.VVYgJy()):
    if refCode in row[4]:
     tableRow = FFb0uP(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVgAw8.VVAGTP(ndx)
      break
   else:
    FF1lLq(VVgAw8, "No found", 1000)
 def VVUGyS(self, m3uMode):
  lines = self.VVCSfu(3)
  if lines:
   lines.sort()
   VVGuvj = []
   for line in lines:
    VVGuvj.append((line, line))
   if m3uMode == CCCW9K.VVZUHT:
    title = "Browse Server from M3U URLs"
    VVLIPG = ("All to Playlist", self.VV3HHm)
   else:
    title = "M3U/M3U8 File Browser"
    VVLIPG = None
   VVwpVu = BF(self.VVLEwt, m3uMode, title)
   VVrN3L = self.VVRHXy
   FFSiXW(self, None, title=title, VVGuvj=VVGuvj, width=1200, VVwpVu=VVwpVu, VVrN3L=VVrN3L, VV51Jr="", VVLIPG=VVLIPG, VVmEJ8="#11221122", VVd8a3="#11221122")
 def VVLEwt(self, m3uMode, title, item=None):
  if item:
   VVUD8b, txt, path, ndx = item
   if m3uMode == CCCW9K.VVZUHT:
    FF4idw(VVUD8b, BF(self.VVe7pM, title, path))
   else:
    FF4idw(VVUD8b, BF(self.VVRP2Y, path))
 def VVRP2Y(self, path, m3uFilterParam=None, VVgAw8=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFhqv7(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVhKVz(propLine, "group-title") or "-"
   if not group == "-" and self.VVz8Bv(group):
    if not chName or self.VVtiCk(chName):
     if self.VVYRve(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVJpUa = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVJpUa.append((name, str(tot), name))
    totAll += tot
   VVJpUa.sort(key=lambda x: x[0].lower())
   VVJpUa.insert(0, ("ALL", str(totAll), ""))
  if VVJpUa:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVgAw8:
    VVgAw8.VVFDhD(VVJpUa, newTitle=title, VVLMQ5Msg=True)
   else:
    VVJlHN = self.VViE4h
    VVrjyr  = ("Select" , BF(self.VVjzeo, path, m3uFilterParam)  , [])
    VV1SrQ = ("Filter" , BF(self.VVqUPB, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVRYg6  = (LEFT  , CENTER , LEFT )
    FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, width= 1400, height= 1000, VVCppa=28, VVrjyr=VVrjyr, VV1SrQ=VV1SrQ, VVJlHN=VVJlHN, lastFindConfigObj=CFG.lastFindIptv
      , VVmEJ8="#11110022", VVd8a3="#11110022", VVcGiE="#11110022", VVh96o="#00444400")
  elif VVgAw8:
   FFFSea(VVgAw8, "Not found !", 1500)
  else:
   self.VVme6c(FFhqv7(path), "", m3uFilterParam)
 def VVjzeo(self, path, m3uFilterParam, VVgAw8, title, txt, colList):
  self.VVme6c(FFhqv7(path), colList[2], m3uFilterParam)
 def VVqUPB(self, path, m3uFilterParam, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(("All"      , "all"  ))
  VVGuvj.append(FFJ9Ko("Category"))
  VVGuvj.append(("Live TV"     , "live" ))
  VVGuvj.append(("VOD"      , "vod"  ))
  VVGuvj.append(("Series"     , "series" ))
  VVGuvj.append(("Uncategorised"   , "uncat" ))
  VVGuvj.append(FFJ9Ko("Media"))
  VVGuvj.append(("Video"     , "video" ))
  VVGuvj.append(("Audio"     , "audio" ))
  VVGuvj.append(FFJ9Ko("File Type"))
  VVGuvj.append(("MKV"      , "MKV"  ))
  VVGuvj.append(("MP4"      , "MP4"  ))
  VVGuvj.append(("MP3"      , "MP3"  ))
  VVGuvj.append(("AVI"      , "AVI"  ))
  VVGuvj.append(("FLV"      , "FLV"  ))
  filterObj = CCiRFn(self, VVmEJ8="#11332244", VVd8a3="#11222244")
  filterObj.VVhJnM(VVGuvj, [], BF(self.VVS072, VVgAw8, path), inFilterFnc=None)
 def VVS072(self, VVgAw8, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV0Z6Q , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVAD9l  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVpWMB  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVkc1E  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VV1y43  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVu7y4  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVbPYG  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VV1qV4  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVkSSJ  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVlnEv  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVWLk5  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVJ1l2  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVfVqa  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCiRFn.VVAtaF(words)
   if not mode == self.VV0Z6Q:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF4aCb(fTitle, VVE7tQ)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF4idw(VVgAw8, BF(self.VVRP2Y, path, m3uFilterParam, VVgAw8), title="Filtering ...")
 def VVme6c(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVwFdx, lst, filterGroup, m3uFilterParam)
       , VVHoAX = BF(self.VV3PMZ, title, bName))
  else:
   self.VV6SIS("No valid lines found !", title)
 def VVwFdx(self, lst, filterGroup, m3uFilterParam, VVXuS2):
  VVXuS2.VVoBtV = []
  VVXuS2.VVhaSh(len(lst))
  num = 0
  for cols in lst:
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVhKVz(propLine, "group-title") or "-"
   picon = self.VVhKVz(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVz8Bv(group) : skip = True
    elif chName and not self.VVtiCk(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVYRve(mode, "", FFb0uP(url).lower(), chName, words, "", asPrefix)
    if not skip and VVXuS2:
     num += 1
     VVXuS2.VVoBtV.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VV3PMZ(self, title, bName, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VVoBtV:
   VVJlHN = self.VViE4h
   VVrjyr  = ("Select"   , BF(self.VVOEgQ, title)   , [])
   VVGySq = (""    , self.VVfB7n        , [])
   VVdyRp = ("Download PIcons", self.VVJYCz       , [])
   VVpxmm = ("Options"  , BF(self.VVg3sr, "m3Ch", "", bName) , [])
   VV1SrQ = ("Posters Mode" , BF(self.VVvNPX, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVRYg6  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVoBtV, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VVGySq=VVGySq, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindIptv, VVOisu=True, searchCol=1
     , VVmEJ8="#0a00192B", VVd8a3="#0a00192B", VVcGiE="#0a00192B", VVh96o="#00000000")
  else:
   self.VV6SIS("Not found !", title)
 def VVJYCz(self, VVgAw8, title, txt, colList):
  self.VVzeBx(VVgAw8, "m3u/m3u8")
 def VVcEM5(self, rowNum, url, chName):
  refCode = self.VVO5yQ(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFhukT(url), chName)
  return chUrl
 def VVO5yQ(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVBIYw(catID, stID, chNum)
  return refCode
 def VVhKVz(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVOEgQ(self, Title, VVgAw8, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF4idw(VVgAw8, BF(self.VVZmDi, Title, VVgAw8, colList), title="Checking Server ...")
  else:
   self.VVyNG1(VVgAw8, url, chName)
 def VVZmDi(self, title, VVgAw8, colList):
  if not CCYF5X.VVXK5R(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCqssj.VVeU64(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVGuvj = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCCW9K.VV0BUk(url, fPath)
     VVGuvj.append((resol, fullUrl))
    if VVGuvj:
     if len(VVGuvj) > 1:
      FFSiXW(self, BF(self.VVndFg, VVgAw8, chName), VVGuvj=VVGuvj, title="Resolution", VVYJYo=True, VVvfDN=True)
     else:
      self.VVyNG1(VVgAw8, VVGuvj[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVyNG1(VVgAw8, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCCW9K.VV0BUk(url, span.group(1))
       self.VVyNG1(VVgAw8, fullUrl, chName)
      else:
       self.VVRGGb("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVme6c(txt, filterGroup="")
      return
    self.VVyNG1(VVgAw8, url, chName)
   else:
    self.VV6SIS("Cannot process this channel !", title)
  else:
   self.VV6SIS(err, title)
 def VVndFg(self, VVgAw8, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVyNG1(VVgAw8, resolUrl, chName)
 def VVyNG1(self, VVgAw8, url, chName):
  FF4idw(VVgAw8, BF(self.VVACzz, VVgAw8, url, chName), title="Playing ...")
 def VVACzz(self, VVgAw8, url, chName):
  chUrl = self.VVcEM5(VVgAw8.VVmG96(), url, chName)
  FF5kbK(self, chUrl, VVCqYJ=False)
  CCP76G.VVBpiW(self.session, iptvTableParams=(self, VVgAw8, "m3u/m3u8"))
 def VVuAZs(self, VVgAw8, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVcEM5(VVgAw8.VVmG96(), url, chName)
  return chName, chUrl
 def VVfB7n(self, VVgAw8, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFw3XJ(self, fncMode=CCM3PM.VVP8uW, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV6SIS(self, err, title):
  FFeF28(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VViE4h(self, VVgAw8):
  if self.m3uOrM3u8File:
   self.close()
  VVgAw8.cancel()
 def VV3HHm(self, selectionObj, item=None):
  FF4idw(selectionObj, BF(self.VVr6s5, selectionObj, item))
 def VVr6s5(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVGuvj):
    path = item[1]
    if fileExists(path):
     enc = CC7ZOW.VVG0aP(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCCW9K.VVwI13(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCCW9K.VV5bfA()
    pListF = "%sPlaylist_%s.txt" % (path, FFguCY())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVGuvj)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFPaL6(self, txt, title=title)
   else:
    FFeF28(self, "Could not obtain URLs from this file list !", title=title)
 def VVlAf8(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVqp2n
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVaTL8
  lines = self.VVCSfu(mode)
  if lines:
   lines.sort()
   VVGuvj = []
   for line in lines:
    VVGuvj.append((FF4aCb(line, VV2Bne) if "Bookmarks" in line else line, line))
   VVrN3L = self.VVRHXy
   FFSiXW(self, None, title=title, VVGuvj=VVGuvj, width=1200, VVwpVu=okFnc, VVrN3L=VVrN3L, VV51Jr="")
 def VVRHXy(self, VVUD8b, txt, ref, ndx):
  txt = ref
  sz = FFgx6P(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCZHbk.VVi3go(sz)
  FFPaL6(self, txt, title="File Path")
 def VVqp2n(self, item=None):
  if item:
   VVUD8b, txt, path, ndx = item
   FF4idw(VVUD8b, BF(self.VVE1DM, VVUD8b, path), title="Processing File ...")
 def VVE1DM(self, VVZpZy, path):
  enc = CC7ZOW.VVG0aP(path, self)
  if enc == -1:
   return
  VVJpUa = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFvBW5(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCW9K.VVxKtK(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVJpUa:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVJpUa.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVJpUa:
   title = "Playlist File : %s" % os.path.basename(path)
   VVrjyr  = ("Start"    , BF(self.VV1OBA, "Playlist File")      , [])
   VVFkw1 = ("Home Menu"   , FFQbFt             , [])
   VVdyRp = ("Download M3U File" , self.VV75iG         , [])
   VVpxmm = ("Edit File"   , BF(self.VVm1Hi, path)        , [])
   VV1SrQ = ("Check & Filter"  , BF(self.VV1x9t, VVZpZy, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVRYg6  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVFkw1=VVFkw1, VV1SrQ=VV1SrQ, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVmEJ8="#11001116", VVd8a3="#11001116", VVcGiE="#11001116", VVh96o="#00003635", VV5t00="#0a333333", VVO2zv="#11331100", VVOisu=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFeF28(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV75iG(self, VVgAw8, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFZRvh(self, BF(FF4idw, VVgAw8, BF(self.VVzVpu, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVzVpu(self, title, url):
  path, err = FFl4UT(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFeF28(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFhqv7(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFOHeU(path)
    FFeF28(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFOHeU(path)
    FFeF28(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCCW9K.VV5bfA() + fName
    FF7Jdu("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFDx6X(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFeF28(self, "Could not download the M3U file!", title=errTitle)
 def VV1OBA(self, Title, VVgAw8, title, txt, colList):
  url = colList[6]
  FF4idw(VVgAw8, BF(self.VVcW0E, Title, url), title="Checking Server ...")
 def VVm1Hi(self, path, VVgAw8, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCrb0k(self, path, VVHoAX=BF(self.VVF3Bh, VVgAw8), curRowNum=rowNum)
  else    : FFJBL5(self, path)
 def VVF3Bh(self, VVgAw8, fileChanged):
  if fileChanged:
   VVgAw8.cancel()
 def VVS0GD(self, title):
  curChName = self.VVgAw8.VVhkzh(1)
  FFrwu2(self, BF(self.VVVYZP, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVVYZP(self, title, name):
  if name:
   VVAvkb, err = CC1mtH.VVb6EG(self, CC1mtH.VVeHdb, VVpuYC=False, VVgAsb=False)
   list = []
   if VVAvkb:
    name = self.VVOBp7(name)
    ratio = "1"
    for item in VVAvkb:
     if name in item[0].lower():
      list.append((item[0], FFFBpn(item[2]), item[3], ratio))
   if list : self.VVhVpa(list, title)
   else : FFeF28(self, "Not found:\n\n%s" % name, title=title)
 def VV1M8m(self, title):
  curChName = self.VVgAw8.VVhkzh(1)
  self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVvKJt
      , VVHoAX = BF(self.VV8w5x, title, curChName))
 def VVvKJt(self, VVXuS2):
  curChName = self.VVgAw8.VVhkzh(1)
  VVAvkb, err = CC1mtH.VVb6EG(self, CC1mtH.VVUq4c, VVpuYC=False, VVgAsb=False)
  if not VVAvkb or not VVXuS2 or VVXuS2.isCancelled:
   return
  VVXuS2.VVoBtV = []
  VVXuS2.VVhaSh(len(VVAvkb))
  curCh = self.VVOBp7(curChName)
  for refCode in VVAvkb:
   chName, sat, inDB = VVAvkb.get(refCode, ("", "", 0))
   ratio = CCnBmO.VVcA0S(chName.lower(), curCh)
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1, True)
   if VVXuS2 and ratio > 50:
    VVXuS2.VVoBtV.append((chName, FFFBpn(sat), refCode.replace("_", ":"), str(ratio)))
 def VV8w5x(self, title, curChName, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VVoBtV: self.VVhVpa(VVoBtV, title)
  elif VV2c9g: FFeF28(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVhVpa(self, VVJpUa, title):
  curChName = self.VVgAw8.VVhkzh(1)
  VVIX6E = self.VVgAw8.VVhkzh(4)
  curUrl  = self.VVgAw8.VVhkzh(5)
  VVJpUa.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVrjyr  = ("Share Sat/C/T Ref.", BF(self.VVw04A, title, curChName, VVIX6E, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVmEJ8="#0a00112B", VVd8a3="#0a001126", VVcGiE="#0a001126", VVh96o="#00000000")
 def VVw04A(self, newtitle, curChName, VVIX6E, curUrl, VVgAw8, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVIX6E, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFZRvh(self.VVgAw8, BF(FF4idw, self.VVgAw8, BF(self.VVIcxj, VVgAw8, data)), ques, title=newtitle, VVnBJJ=True)
 def VVIcxj(self, VVgAw8, data):
  VVgAw8.cancel()
  title, curChName, VVIX6E, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVIX6E = VVIX6E.strip()
  newRefCode = newRefCode.strip()
  if not VVIX6E.endswith(":") : VVIX6E += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVIX6E, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVIX6E + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCCW9K.VVEC3O():
    txt = FFhqv7(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF9bFs()
    newRow = []
    for i in range(6):
     newRow.append(self.VVgAw8.VVhkzh(i))
    newRow[4] = newRefCode
    done = self.VVgAw8.VVtGmM(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFJVhm(BF(FFDx6X , self, resTxt, title=title))
  elif resErr: FFJVhm(BF(FFeF28, self, resErr, title=title))
 def VV1x9t(self, VVZpZy, path, VVgAw8, title, txt, colList):
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVYcTm, VVgAw8)
      , VVHoAX = BF(self.VVSSxy, VVZpZy, path, VVgAw8))
 def VVYcTm(self, VVgAw8, VVXuS2):
  VVXuS2.VVhaSh(VVgAw8.VVKzij())
  VVXuS2.VVoBtV = []
  for row in VVgAw8.VVYgJy():
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1, True)
   qUrl = self.VVLqJZ(self.VVYl8o, row[6])
   txt, err = self.VVxp5A(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVoNAp(item, "auth") == "0":
       VVXuS2.VVoBtV.append(qUrl)
    except:
     pass
 def VVSSxy(self, VVZpZy, path, VVgAw8, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VV2c9g:
   list = VVoBtV
   title = "Authorized Servers"
   if list:
    totChk = VVgAw8.VVKzij()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFguCY()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVlAf8(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF4aCb(str(totAuth), VV1udq)
     txt += "%s\n\n%s"    %  (FF4aCb("Result File:", VV2Bne), newPath)
     FFPaL6(self, txt, title=title)
     VVgAw8.close()
     VVZpZy.close()
    else:
     FFDx6X(self, "All URLs are authorized.", title=title)
   else:
    FFeF28(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVxp5A(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVxKtK(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVIysy(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCw3cf.VV81Gw()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVvImY(decodedUrl):
  return CCCW9K.VVIysy(decodedUrl, justRetDotExt=True)
 def VVLqJZ(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVxKtK(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVYl8o   : return "%s"            % url
  elif mode == self.VVwPpy   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVSStX   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVJe7g  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV9Zmj  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVUUnH : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVMAzw   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVDm2k    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVwpUk  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVz13U : return "%s&action=get_live_streams"      % url
  elif mode == self.VV2GkZ  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVoNAp(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFrH35(int(val))
    elif is_base64 : val = FFCqMm(val)
    elif isToHHMMSS : val = FFZ4gz(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVe7pM(self, title, path):
  if fileExists(path):
   enc = CC7ZOW.VVG0aP(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCCW9K.VVwI13(line)
     if qUrl:
      break
   if qUrl : self.VVcW0E(title, qUrl)
   else : FFeF28(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFeF28(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV8INc(self):
  title = "Current Channel Server"
  qUrl, decodedUrl, iptvRef = CCCW9K.VVFm8X(self)
  if qUrl or "chCode" in iptvRef:
   p = CCqssj()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVe1Ii(decodedUrl)
   if valid:
    self.VVYM78(self, host, mac)
    return
   elif qUrl:
    FF4idw(self, BF(self.VVcW0E, title, qUrl), title="Checking Server ...")
    return
  FFeF28(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVFm8X(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF)
  qUrl = CCCW9K.VVwI13(decodedUrl)
  return qUrl, decodedUrl, iptvRef
 @staticmethod
 def VVwI13(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVcW0E(self, title, url):
  self.curUrl = url
  self.VVkKctData = {}
  qUrl = self.VVLqJZ(self.VVYl8o, url)
  txt, err = self.VVxp5A(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVkKctData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVkKctData["username"    ] = self.VVoNAp(item, "username"        )
    self.VVkKctData["password"    ] = self.VVoNAp(item, "password"        )
    self.VVkKctData["message"    ] = self.VVoNAp(item, "message"        )
    self.VVkKctData["auth"     ] = self.VVoNAp(item, "auth"         )
    self.VVkKctData["status"    ] = self.VVoNAp(item, "status"        )
    self.VVkKctData["exp_date"    ] = self.VVoNAp(item, "exp_date"    , isDate=True )
    self.VVkKctData["is_trial"    ] = self.VVoNAp(item, "is_trial"        )
    self.VVkKctData["active_cons"   ] = self.VVoNAp(item, "active_cons"       )
    self.VVkKctData["created_at"   ] = self.VVoNAp(item, "created_at"   , isDate=True )
    self.VVkKctData["max_connections"  ] = self.VVoNAp(item, "max_connections"      )
    self.VVkKctData["allowed_output_formats"] = self.VVoNAp(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVkKctData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVkKctData["url"    ] = self.VVoNAp(item, "url"        )
    self.VVkKctData["port"    ] = self.VVoNAp(item, "port"        )
    self.VVkKctData["https_port"  ] = self.VVoNAp(item, "https_port"      )
    self.VVkKctData["server_protocol" ] = self.VVoNAp(item, "server_protocol"     )
    self.VVkKctData["rtmp_port"   ] = self.VVoNAp(item, "rtmp_port"       )
    self.VVkKctData["timezone"   ] = self.VVoNAp(item, "timezone"       )
    self.VVkKctData["timestamp_now"  ] = self.VVoNAp(item, "timestamp_now"  , isDate=True )
    self.VVkKctData["time_now"   ] = self.VVoNAp(item, "time_now"       )
    VVGuvj  = self.VVAVi1(True)
    VVwpVu = self.VVX2dl
    VVrN3L = self.VV4mV9
    VV91zg = ("Home Menu", FFQbFt)
    VVBLXn= ("Add to Menu", BF(CCCW9K.VVyn9s, self, False, self.VVkKctData["playListURL"]))
    VVLIPG = ("Bookmark Server", BF(CCCW9K.VVCwh6, self, False, self.VVkKctData["playListURL"]))
    VVUD8b = FFSiXW(self, None, title="IPTV Server Resources", VVGuvj=VVGuvj, VVwpVu=VVwpVu, VVrN3L=VVrN3L, VV91zg=VV91zg, VVBLXn=VVBLXn, VVLIPG=VVLIPG)
    self.VVNOhT(VVUD8b)
   else:
    err = "Could not get data from server !"
  if err:
   FFeF28(self, err, title=title)
  FF1lLq(self)
 def VVX2dl(self, item=None):
  if item:
   VVUD8b, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF4idw(VVUD8b, BF(self.VVs42t, self.VVwPpy  , title=title), title=wTxt)
   elif ref == "vod"   : FF4idw(VVUD8b, BF(self.VVs42t, self.VVSStX  , title=title), title=wTxt)
   elif ref == "series"  : FF4idw(VVUD8b, BF(self.VVs42t, self.VVJe7g , title=title), title=wTxt)
   elif ref == "catchup"  : FF4idw(VVUD8b, BF(self.VVs42t, self.VV9Zmj , title=title), title=wTxt)
   elif ref == "accountInfo" : FF4idw(VVUD8b, BF(self.VVMQgM           , title=title), title=wTxt)
 def VVNOhT(self, VVUD8b):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if   FFIC9i(decodedUrl) : VVUD8b.VVn6An(1)
  elif FFLnfq(decodedUrl): VVUD8b.VVn6An(2)
 def VV4mV9(self, VVUD8b, txt, ref, ndx):
  FF4idw(VVUD8b, self.VVvNvw)
 def VVvNvw(self):
  txt = self.curUrl
  if VVwauR:
   ver, err = self.VV2LrZ(self.VVGVwj())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVFKbR
   txt += "PHP\t: %s\n"  % self.VVgtza
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVrQHb, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFPaL6(self, txt, title="Current Server URL")
 def VVMQgM(self, title):
  rows = []
  for key, val in self.VVkKctData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVJ9YW
   else:
    num, part = "1", self.VVV6L6
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVFkw1  = ("Home Menu", FFQbFt, [])
  VVdyRp  = None
  if VVwauR:
   VVdyRp = ("Get JS" , BF(self.VVjfCk, "/".join(self.VVkKctData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFBxNx(self, None, title=title, width=1200, header=header, VVWhjq=rows, VVmQwL=widths, VVCppa=26, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000", searchCol=2)
 def VV7QuU(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVMAzw, self.VV2GkZ):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVoNAp(item, "num"         )
      name     = self.VVoNAp(item, "name"        )
      stream_id    = self.VVoNAp(item, "stream_id"       )
      stream_icon    = self.VVoNAp(item, "stream_icon"       )
      epg_channel_id   = self.VVoNAp(item, "epg_channel_id"      )
      added     = self.VVoNAp(item, "added"    , isDate=True )
      is_adult    = self.VVoNAp(item, "is_adult"       )
      category_id    = self.VVoNAp(item, "category_id"       )
      tv_archive    = self.VVoNAp(item, "tv_archive"       )
      direct_source   = self.VVoNAp(item, "direct_source"      )
      tv_archive_duration  = self.VVoNAp(item, "tv_archive_duration"     )
      name = self.VVtiCk(name, is_adult)
      if name:
       if mode == self.VVMAzw or mode == self.VV2GkZ and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVDm2k:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVoNAp(item, "num"         )
      name    = self.VVoNAp(item, "name"        )
      stream_id   = self.VVoNAp(item, "stream_id"       )
      stream_icon   = self.VVoNAp(item, "stream_icon"       )
      added    = self.VVoNAp(item, "added"    , isDate=True )
      is_adult   = self.VVoNAp(item, "is_adult"       )
      category_id   = self.VVoNAp(item, "category_id"       )
      container_extension = self.VVoNAp(item, "container_extension"     ) or "mp4"
      name = self.VVtiCk(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVwpUk:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVoNAp(item, "num"        )
      name    = self.VVoNAp(item, "name"       )
      series_id   = self.VVoNAp(item, "series_id"      )
      cover    = self.VVoNAp(item, "cover"       )
      genre    = self.VVoNAp(item, "genre"       )
      episode_run_time = self.VVoNAp(item, "episode_run_time"    )
      category_id   = self.VVoNAp(item, "category_id"      )
      container_extension = self.VVoNAp(item, "container_extension"    ) or "mp4"
      name = self.VVtiCk(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVs42t(self, mode, title):
  cList, err = self.VVaca2(mode)
  if cList and mode == self.VV9Zmj:
   cList = self.VVxKJE(cList)
  if err:
   FFeF28(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm(mode)
   mName = self.VVFAhu(mode)
   if   mode == self.VVwPpy  : fMode = self.VVMAzw
   elif mode == self.VVSStX  : fMode = self.VVDm2k
   elif mode == self.VVJe7g : fMode = self.VVwpUk
   elif mode == self.VV9Zmj : fMode = self.VV2GkZ
   if mode == self.VV9Zmj:
    VVpxmm = None
    VV1SrQ = None
   else:
    VVpxmm = ("Find in %s" % mName , BF(self.VVw4zw, fMode, True) , [])
    VV1SrQ = ("Find in Selected" , BF(self.VVw4zw, fMode, False) , [])
   VVrjyr   = ("Show List"   , BF(self.VVKirb, mode)  , [])
   VVFkw1  = ("Home Menu"   , FFQbFt         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFBxNx(self, None, title=title, width=1200, header=header, VVWhjq=cList, VVmQwL=widths, VVCppa=30, VVFkw1=VVFkw1, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVrjyr=VVrjyr, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFeF28(self, "No list from server !", title=title)
  FF1lLq(self)
 def VVaca2(self, mode):
  qUrl  = self.VVLqJZ(mode, self.VVkKctData["playListURL"])
  txt, err = self.VVxp5A(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVoNAp(item, "category_id"  )
     category_name = self.VVoNAp(item, "category_name" )
     parent_id  = self.VVoNAp(item, "parent_id"  )
     category_name = self.VVz8Bv(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVxKJE(self, catList):
  mode  = self.VV2GkZ
  qUrl  = self.VVLqJZ(mode, self.VVkKctData["playListURL"])
  txt, err = self.VVxp5A(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV7QuU(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVKirb(self, mode, VVgAw8, title, txt, colList):
  title = colList[1]
  FF4idw(VVgAw8, BF(self.VVltDQ, mode, VVgAw8, title, txt, colList), title="Downloading ...")
 def VVltDQ(self, mode, VVgAw8, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVFAhu(mode) + " : "+ bName
  if   mode == self.VVwPpy  : mode = self.VVMAzw
  elif mode == self.VVSStX  : mode = self.VVDm2k
  elif mode == self.VVJe7g : mode = self.VVwpUk
  elif mode == self.VV9Zmj : mode = self.VV2GkZ
  qUrl  = self.VVLqJZ(mode, self.VVkKctData["playListURL"], catID)
  txt, err = self.VVxp5A(qUrl)
  list  = []
  if not err and mode in (self.VVMAzw, self.VVDm2k, self.VVwpUk, self.VV2GkZ):
   list, err = self.VV7QuU(mode, txt)
  if err:
   FFeF28(self, err, title=title)
  elif list:
   VVFkw1  = ("Home Menu"   , FFQbFt            , [])
   if mode in (self.VVMAzw, self.VV2GkZ):
    VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm(mode)
    VVGySq = (""     , BF(self.VVAUU5, mode)      , [])
    VVdyRp = ("Download Options" , BF(self.VVefr7, mode, "", "")   , [])
    VVpxmm = ("Options"   , BF(self.VVg3sr, "lv", mode, bName)   , [])
    VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, False)     , [])
    if mode == self.VVMAzw:
     VVrjyr = ("Play"    , BF(self.VV8v4H, mode)       , [])
    else:
     VVrjyr = ("Programs"   , BF(self.VVt9Lh, mode, bName) , [])
   elif mode == self.VVDm2k:
    VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm(mode)
    VVrjyr  = ("Play"    , BF(self.VV8v4H, mode)       , [])
    VVGySq = (""     , BF(self.VVAUU5, mode)      , [])
    VVdyRp = ("Download Options" , BF(self.VVefr7, mode, "v", "")   , [])
    VVpxmm = ("Options"   , BF(self.VVg3sr, "v", mode, bName)   , [])
    VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, False)     , [])
   elif mode == self.VVwpUk:
    VVmEJ8, VVd8a3, VVcGiE, VVh96o = self.VVTwCm("series2")
    VVrjyr  = ("Show Seasons"  , BF(self.VVUFMX, mode)       , [])
    VVGySq = (""     , BF(self.VVMKKN, mode)     , [])
    VVdyRp = None
    VVpxmm = None
    VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, True)      , [])
   header, widths, VVRYg6 = self.VVfs38(mode)
   FFBxNx(self, None, title=title, header=header, VVWhjq=list, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindIptv, VVGySq=VVGySq, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o, VVOisu=True, searchCol=1)
  else:
   FFeF28(self, "No Channels found !", title=title)
  FF1lLq(self)
 def VVfs38(self, mode):
  if mode in (self.VVMAzw, self.VV2GkZ):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVRYg6  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVDm2k:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVRYg6  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVwpUk:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVRYg6  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVRYg6
 def VVt9Lh(self, mode, bName, VVgAw8, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVkKctData["playListURL"]
  ok_fnc  = BF(self.VVinKz, hostUrl, chName, catId, streamId)
  FF4idw(VVgAw8, BF(CCCW9K.VVocf4, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVinKz(self, chUrl, chName, catId, streamId, VVgAw8, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCW9K.VVxKtK(chUrl)
   chNum = "333"
   refCode = CCCW9K.VVBIYw(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FF5kbK(self, chUrl, VVCqYJ=False)
   CCP76G.VVBpiW(self.session)
  else:
   FFeF28(self, "Incorrect Timestamp", pTitle)
 def VVUFMX(self, mode, VVgAw8, title, txt, colList):
  title = colList[1]
  FF4idw(VVgAw8, BF(self.VV28Q1, mode, VVgAw8, title, txt, colList), title="Downloading ...")
 def VV28Q1(self, mode, VVgAw8, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVLqJZ(self.VVUUnH, self.VVkKctData["playListURL"], series_id)
  txt, err = self.VVxp5A(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVoNAp(tDict["info"], "name"   )
      category_id = self.VVoNAp(tDict["info"], "category_id" )
      icon  = self.VVoNAp(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVoNAp(EP, "id"     )
        episode_num   = self.VVoNAp(EP, "episode_num"   )
        epTitle    = self.VVoNAp(EP, "title"     )
        container_extension = self.VVoNAp(EP, "container_extension" )
        seasonNum   = self.VVoNAp(EP, "season"    )
        epTitle = self.VVtiCk(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFeF28(self, err, title=title)
  elif list:
   VVFkw1 = ("Home Menu"   , FFQbFt          , [])
   VVdyRp = ("Download Options" , BF(self.VVefr7, mode, "s", title), [])
   VVpxmm = ("Options"   , BF(self.VVg3sr, "s", mode, title) , [])
   VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, False)   , [])
   VVGySq = (""     , BF(self.VVAUU5, mode)    , [])
   VVrjyr  = ("Play"    , BF(self.VV8v4H, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVRYg6  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFBxNx(self, None, title=title, header=header, VVWhjq=list, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVrjyr=VVrjyr, VVGySq=VVGySq, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, lastFindConfigObj=CFG.lastFindIptv, VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000")
  else:
   FFeF28(self, "No Channels found !", title=title)
  FF1lLq(self)
 def VVw4zw(self, mode, isAll, VVgAw8, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVGuvj = []
  VVGuvj.append(("Keyboard"  , "manualEntry"))
  VVGuvj.append(("From Filter" , "fromFilter"))
  FFSiXW(self, BF(self.VVYhqP, VVgAw8, mode, onlyCatID), title="Input Type", VVGuvj=VVGuvj, width=400)
 def VVYhqP(self, VVgAw8, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFrwu2(self, BF(self.VV5MbL, VVgAw8, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCiRFn(self)
    filterObj.VVi7C2(BF(self.VV5MbL, VVgAw8, mode, onlyCatID))
 def VV5MbL(self, VVgAw8, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFCRXL(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCiRFn.VVAtaF(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFeF28(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFeF28(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVdiPK(words):
      FFeF28(self, self.VV5XOF(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVTWVl, VVgAw8, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVHoAX = BF(self.VVGQBp, mode, toFind, title))
   if not words:
    FF1lLq(VVgAw8, "Nothing to find !", 1500)
 def VVTWVl(self, VVgAw8, mode, onlyCatID, title, words, toFind, asPrefix, VVXuS2):
  VVXuS2.VVhaSh(VVgAw8.VVPGr2() if onlyCatID is None else 1)
  VVXuS2.VVoBtV = []
  for row in VVgAw8.VVYgJy():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVzPku(1)
   VVXuS2.VV78vS(catName)
   qUrl  = self.VVLqJZ(mode, self.VVkKctData["playListURL"], catID)
   txt, err = self.VVxp5A(qUrl)
   if not err:
    tList, err = self.VV7QuU(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVtiCk(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVXuS2 or VVXuS2.isCancelled:
        return
       VVXuS2.VVoBtV.append(item)
       VVXuS2.VV78vS(catName)
 def VVGQBp(self, mode, toFind, title, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VVoBtV:
   title = self.VVhmF2(mode, toFind)
   if mode == self.VVMAzw or mode == self.VVDm2k:
    if mode == self.VVDm2k : typ = "v"
    else          : typ = ""
    bName   = CCCW9K.VV8jRk(toFind)
    VVrjyr  = ("Play"     , BF(self.VV8v4H, mode)     , [])
    VVdyRp = ("Download Options" , BF(self.VVefr7, mode, typ, "") , [])
    VVpxmm = ("Options"   , BF(self.VVg3sr, "fnd", mode, bName), [])
    VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, False)   , [])
    VVGySq = (""     , BF(self.VVAUU5, mode)    , [])
   elif mode == self.VVwpUk:
    VVrjyr  = ("Show Seasons"  , BF(self.VVUFMX, mode)     , [])
    VVpxmm = None
    VVdyRp = None
    VV1SrQ = ("Posters Mode"  , BF(self.VVvNPX, mode, True)    , [])
    VVGySq = (""     , BF(self.VVMKKN, mode)   , [])
   VVFkw1  = ("Home Menu"   , FFQbFt          , [])
   header, widths, VVRYg6 = self.VVfs38(mode)
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVoBtV, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVGySq=VVGySq, VVmEJ8="#0a00292B", VVd8a3="#0a002126", VVcGiE="#0a002126", VVh96o="#00000000", VVOisu=True, searchCol=1)
   if not VV2c9g:
    FF1lLq(VVgAw8, "Stopped" , 1000)
  else:
   if VV2c9g:
    FFeF28(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVf0BE(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVMAzw, self.VV2GkZ):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVDm2k:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFWkM4(chName)
  url = self.VVkKctData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVxKtK(url)
  refCode = self.VVBIYw(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVAUU5(self, mode, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VV4i07, mode, VVgAw8, title, txt, colList))
 def VV4i07(self, mode, VVgAw8, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVf0BE(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFw3XJ(self, fncMode=CCM3PM.VVz8xJ, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVMKKN(self, mode, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVwPoc, mode, VVgAw8, title, txt, colList))
 def VVwPoc(self, mode, VVgAw8, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFw3XJ(self, fncMode=CCM3PM.VVSF0r, chName=name, text=txt, picUrl=Cover)
 def VVvNPX(self, mode, isSerNames, VVgAw8, title, txt, colList):
  if   mode in ("itv"  , CCCW9K.VVMAzw, CCCW9K.VV2GkZ): category = "live"
  elif mode in ("vod"  , CCCW9K.VVDm2k )          : category = "vod"
  elif mode in ("series" , CCCW9K.VVwpUk)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVMAzw : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV2GkZ : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVDm2k  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVwpUk : picCol, descCol, descTxt = 5, 0, "Season"
  FF4idw(VVgAw8, BF(self.session.open, CCaOhY, VVgAw8, category, nameCol, picCol, descCol, descTxt))
 def VVefr7(self, mode, typ, seriesName, VVgAw8, title, txt, colList):
  VVGuvj = []
  isMulti = VVgAw8.VVhXSW
  tot  = VVgAw8.VVeEeJ()
  if isMulti:
   if tot < 1:
    FF1lLq(VVgAw8, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVGuvj.append(("Download %s PIcon%s" % (name, FFtCOg(tot)), "dnldPicons" ))
  if typ:
   VVGuvj.append(VVnek4)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVGuvj.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVGuvj.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVGuvj.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCATpC.VVbPjj():
    VVGuvj.append(VVnek4)
    VVGuvj.append(("Download Manager"      , "dload_stat" ))
  FFSiXW(self, BF(self.VVcYZA, VVgAw8, mode, typ, seriesName, colList), title="Download Options", VVGuvj=VVGuvj)
 def VVcYZA(self, VVgAw8, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVzeBx(VVgAw8, mode)
   elif item == "dnldSel"  : self.VVXZjc(VVgAw8, mode, typ, colList, True)
   elif item == "addSel"  : self.VVXZjc(VVgAw8, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVM5Ii(VVgAw8, mode, typ, seriesName)
   elif item == "dload_stat" : CCATpC.VVjqqb(self, VVgAw8)
 def VVXZjc(self, VVgAw8, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVkF7h(mode, typ, colList)
  if startDnld:
   CCATpC.VV8QKh(self, decodedUrl)
  else:
   self.VVu0Rc(VVgAw8, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVM5Ii(self, VVgAw8, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVgAw8.VVYgJy():
   chName, decodedUrl = self.VVkF7h(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVu0Rc(VVgAw8, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVu0Rc(self, VVgAw8, title, chName, decodedUrl_list, startDnld):
  FFZRvh(self, BF(self.VVZTR8, VVgAw8, decodedUrl_list, startDnld), chName, title=title)
 def VVZTR8(self, VVgAw8, decodedUrl_list, startDnld):
  added, skipped = CCATpC.VVeTCV(decodedUrl_list)
  FF1lLq(VVgAw8, "Added", 1000)
 def VVkF7h(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVf0BE(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, colList)
   refCode, chUrl = self.VVoW2o(self.VVFKbR, self.VV8jm3, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFYV5a(chUrl)
  return chName, decodedUrl
 def VVzeBx(self, VVgAw8, mode):
  if FFGbNH("ffmpeg"):
   self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVaMmS, VVgAw8, mode)
       , VVHoAX = self.VVULJh)
  else:
   FFZRvh(self, BF(CCCW9K.VVuecr, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVULJh(self, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVoBtV["proces"], VVoBtV["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVoBtV["ok"], VVoBtV["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVoBtV["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVoBtV["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVoBtV["badURL"]
  txt += "Download Failure\t: %d\n"   % VVoBtV["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVoBtV["path"]
  if not VV2c9g  : color = "#11402000"
  elif VVoBtV["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVoBtV["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVoBtV["err"], txt)
  title = "PIcons Download Result"
  if not VV2c9g:
   title += "  (cancelled)"
  FFPaL6(self, txt, title=title, VVcGiE=color)
 def VVaMmS(self, VVgAw8, mode, VVXuS2):
  isMulti = VVgAw8.VVhXSW
  if isMulti : totRows = VVgAw8.VVeEeJ()
  else  : totRows = VVgAw8.VVPGr2()
  VVXuS2.VVhaSh(totRows)
  VVXuS2.VVMLhu(0)
  counter     = VVXuS2.counter
  maxValue    = VVXuS2.maxValue
  pPath     = CCnBmO.VVYQsq()
  VVXuS2.VVoBtV = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVgAw8.VVYgJy()):
    if VVXuS2.isCancelled:
     break
    if not isMulti or VVgAw8.VVOTHx(rowNum):
     VVXuS2.VVoBtV["proces"] += 1
     VVXuS2.VVzPku(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, row)
      refCode = CCCW9K.VVBIYw(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVO5yQ(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVf0BE(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVXuS2.VVoBtV["attempt"] += 1
       path, err = FFl4UT(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVXuS2:
         VVXuS2.VVoBtV["ok"] += 1
         VVXuS2.VVMLhu(VVXuS2.VVoBtV["ok"])
        if FFgx6P(path) > 0:
         cmd = CCM3PM.VVuDvo(path)
         cmd += FFTMeZ("mv -f '%s' '%s'" % (path, pPath))
         FF7Jdu(cmd)
        else:
         if VVXuS2:
          VVXuS2.VVoBtV["size0"] += 1
         FFOHeU(path)
       elif err:
        if VVXuS2:
         VVXuS2.VVoBtV["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVXuS2:
          VVXuS2.VVoBtV["err"] = err.title()
         break
      else:
       if VVXuS2:
        VVXuS2.VVoBtV["exist"] += 1
     else:
      if VVXuS2:
       VVXuS2.VVoBtV["badURL"] += 1
  except:
   pass
 def VV0RiN(self):
  title = "Download PIcons for Current Bouquet"
  if FFGbNH("ffmpeg"):
   self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
       , titlePrefix = ""
       , fncToRun  = self.VVC4U9
       , VVHoAX = BF(self.VV9ZLo, title))
  else:
   FFZRvh(self, BF(CCCW9K.VVuecr, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVC4U9(self, VVXuS2):
  bName = CCQrUI.VV3Lcf()
  pPath = CCnBmO.VVYQsq()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVXuS2.VVoBtV = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCQrUI.VVAp70()
  if not VVXuS2 or VVXuS2.isCancelled:
   return
  if not services or len(services) == 0:
   VVXuS2.VVoBtV = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVXuS2.VVhaSh(totCh)
  VVXuS2.VVMLhu(0)
  for serv in services:
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   VVXuS2.VVoBtV = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVXuS2.VVzPku(1)
   VVXuS2.VVMLhu(totPic)
   fullRef  = serv[0]
   if FFOXrQ(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFYV5a(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCqssj.VV0YYT(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCW9K.VVxp5A(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCM3PM.VVCCf7(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFl4UT(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVXuS2:
     VVXuS2.VVMLhu(totPic)
    if FFgx6P(path) > 0:
     cmd = CCM3PM.VVuDvo(path)
     cmd += FFTMeZ("mv -f '%s' '%s'" % (path, pPath))
     FF7Jdu(cmd)
     totPicOK += 1
    else:
     totSize0
     FFOHeU(path)
  if VVXuS2:
   VVXuS2.VVoBtV = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VV9ZLo(self, title, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVoBtV
  if err:
   FFeF28(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF4aCb(str(totExist)  , VVEkv6)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF4aCb(str(totNotIptv)  , VVEkv6)
    if totServErr : txt += "Server Errors\t: %s\n" % FF4aCb(str(totServErr) + t1, VVEkv6)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF4aCb(str(totParseErr) , VVEkv6)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF4aCb(str(totInvServ)  , VVEkv6)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF4aCb(str(totInvPicUrl) , VVEkv6)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF4aCb(str(totSize0)  , VVEkv6)
   if not VV2c9g:
    title += "  (stopped)"
   FFPaL6(self, txt, title=title)
 @staticmethod
 def VVuecr(SELF):
  cmd = FFNCOV(VVy8Lf, "ffmpeg")
  if cmd : FF1NOx(SELF, cmd, title="Installing FFmpeg")
  else : FFDayU(SELF)
 @staticmethod
 def VVM8NU(SELF):
  SELF.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3
      , titlePrefix = ""
      , fncToRun  = CCCW9K.VVGEuo
      , VVHoAX = BF(CCCW9K.VVePRw, SELF))
 @staticmethod
 def VVGEuo(VVXuS2):
  bName = CCQrUI.VV3Lcf()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVXuS2.VVoBtV = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCQrUI.VVAp70()
  if not VVXuS2 or VVXuS2.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVXuS2.VVhaSh(totCh)
   for serv in services:
    if not VVXuS2 or VVXuS2.isCancelled:
     return
    VVXuS2.VVzPku(1)
    fullRef = serv[0]
    if FFOXrQ(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFYV5a(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCqssj.VVZ8DC(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCCW9K.VVkogC(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVXuS2:
      VVXuS2.VViKgT(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCTnwS.VVKa2B(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVXuS2:
     VVXuS2.VVoBtV = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVXuS2.VVoBtV = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVePRw(SELF, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVoBtV
  title = "IPTV EPG Import"
  if err:
   FFeF28(SELF, err, title=title)
  else:
   if VV2c9g and totEpgOK > 0:
    CCTnwS.VVHTH6()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF4aCb(str(totNotIptv), VVEkv6)
    if totServErr : txt += "Server Errors\t: %s\n" % FF4aCb(str(totServErr) + t1, VVEkv6)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF4aCb(str(totInv), VVEkv6)
   if not VV2c9g:
    title += "  (stopped)"
   FFPaL6(SELF, txt, title=title)
 @staticmethod
 def VVkogC(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCW9K.VVxKtK(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCCW9K.VVxp5A(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCCW9K.VVoNAp(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCCW9K.VVoNAp(item, "lang"        ).upper()
    now_playing   = CCCW9K.VVoNAp(item, "now_playing"      )
    start    = CCCW9K.VVoNAp(item, "start"        )
    start_timestamp  = CCCW9K.VVoNAp(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCCW9K.VVoNAp(item, "start_timestamp"     )
    stop_timestamp  = CCCW9K.VVoNAp(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCCW9K.VVoNAp(item, "stop_timestamp"      )
    tTitle    = CCCW9K.VVoNAp(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVBIYw(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCCW9K.VV1L3t(catID, MAX_4b)
  TSID = CCCW9K.VV1L3t(chNum, MAX_4b)
  ONID = CCCW9K.VV1L3t(chNum, MAX_4b)
  NS  = CCCW9K.VV1L3t(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VV1L3t(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV8jRk(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVTwCm(mode):
  if   mode in ("itv"  , CCCW9K.VVwPpy)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCCW9K.VVSStX)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCCW9K.VVJe7g) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCCW9K.VV9Zmj) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCCW9K.VV2GkZ    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVCSfu(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVYMuP:
   excl = FFOG94(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFeF28(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf\|\.json"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFkrzQ('find %s %s %s' % (path, excl, par))
  if files:
   err = CCZHbk.VVdoWo(files)
   if err : FFeF28(self, err + FF4aCb('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VV2Bne))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFeF28(self, err)
  return []
 @staticmethod
 def VV5bfA():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFvBW5(path)
  return "/"
 @staticmethod
 def VVocf4(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCCW9K.VVkogC(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFeF28(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVmEJ8, VVd8a3, VVcGiE, VVh96o = CCCW9K.VVTwCm("")
   VVFkw1 = ("Home Menu" , FFQbFt, [])
   VVrjyr  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVRYg6  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFBxNx(SELF, None, title="Programs for : " + chName, header=header, VVWhjq=pList, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=24, VVrjyr=VVrjyr, VVFkw1=VVFkw1, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o)
  else:
   FFeF28(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV0BUk(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVyn9s(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFZRvh(self, BF(self.VVSZoN, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFCRXL(confItem, line)
   FFDx6X(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVSZoN(self, title, confItem):
  FFCRXL(confItem, "")
  FFDx6X(self, "Removed from IPTV Menu.", title=title)
 def VVqwwX(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVYM78(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF4idw(self, BF(self.VVcW0E, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFeF28(self, "Incorrect server data !")
 @staticmethod
 def VVCwh6(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCCW9K.VV5bfA()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFeF28(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFDx6X(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFeF28(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVg3sr(self, source, mode, curBName, VVgAw8, title, txt, colList):
  isMulti = VVgAw8.VVhXSW
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVgAw8.VVeEeJ()
   totTxt = "%d Service%s" % (tot, FFtCOg(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF4aCb(totTxt, VV2Bne)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCwZHL(self, VVgAw8, addSep=False)
  thTxt = "Adding Services ..."
  VVGuvj, cbFncDict = [], None
  VVGuvj.append(VVnek4)
  if itemsOK:
   VVGuvj.append(("Add %s to New Bouquet : %s"    % (totTxt, FF4aCb(curBName , VV1udq)), "addToCur1"))
   if curBName2: VVGuvj.append(("Add %s to New Bouquet : %s" % (totTxt, FF4aCb(curBName2, VVrWwc)) , "addToCur2"))
   VVGuvj.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF4idw, mSel.VVgAw8, BF(self.VVjYSo,source, mode, curBName , VVgAw8, title), title=thTxt)
      , "addToCur2": BF(FF4idw, mSel.VVgAw8, BF(self.VVjYSo,source, mode, curBName2, VVgAw8, title), title=thTxt)
      , "addToNew" : BF(self.VVJ5il, source, mode, curBName, VVgAw8, title)
      }
  else:
   VVGuvj.append(("Add to Bouquet (nothing selected)", ))
  mSel.VV71Gx(VVGuvj, cbFncDict, width=1400)
 def VVjYSo(self, source, mode, curBName, VVgAw8, Title):
  chUrlLst = self.VVcAPC(source, mode, VVgAw8)
  CCQrUI.VVMfMj(self, Title, curBName, "", chUrlLst)
 def VVJ5il(self, source, mode, curBName, VVgAw8, Title):
  picker = CCQrUI(self, VVgAw8, Title, BF(self.VVcAPC, source, mode, VVgAw8), defBName=curBName)
 def VVcAPC(self, source, mode, VVgAw8):
  totChange = 0
  isMulti = VVgAw8.VVhXSW
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVgAw8.VVYgJy()):
   if not isMulti or VVgAw8.VVOTHx(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8REu(mode, row)
     refCode, chUrl = self.VVoW2o(self.VVFKbR, self.VV8jm3, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVcEM5(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVf0BE(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVwFrb():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVDY0z():
  return sorted(tuple(CCCW9K.VVwFrb()))
 @staticmethod
 def VVKeHC(rt):
  return CCCW9K.VVwFrb().get(str(rt), "")
 @staticmethod
 def VVtDTH(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCCW9K.VVKeHC(span.group(1)) if span else ""
 @staticmethod
 def VVqEDO(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVUruy():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVGuvj = []
  for ndx, rt in enumerate(CCCW9K.VVDY0z()):
   VVGuvj.append(FFUHeM("%s\t... %s" % (CCCW9K.VVKeHC(rt), rt), rt, CCCW9K.VVqEDO(rt), VVE7n3 if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVGuvj.append(VVnek4)
  return VVGuvj
class CCEzp3(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVWEuV(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFBHn2(self.frm, frmColor)
  FFBHn2(self.bak, bakColor)
  FFBHn2(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVMojK(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFpwm6(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCU3LA(CCEzp3):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCEzp3.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VVBKxc()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "up" : self.VVrXee   ,
   "down" : self.VVraks  ,
   "left" : self.VVUT8S  ,
   "right" : self.VVeKbm  ,
   "next" : self.VVoamW ,
   "last" : self.VVgc5l
  }, -1)
 def VVIe5F(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVWEuV(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VV5Sd7()
  self["myPiconPtr"].hide()
 def VVuRsD(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVrXee(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVtsBh()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVJO6O()
 def VVraks(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV5QEg()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVJO6O()
 def VVUT8S(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVtsBh()
  else:
   self.curCol -= 1
   self.VVJO6O()
 def VVeKbm(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV5QEg()
  else:
   self.curCol += 1
   self.VVJO6O()
 def VVgc5l(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVJO6O(oldPage != self.curPage)
 def VVoamW(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVJO6O(oldPage != self.curPage)
 def VV5QEg(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVJO6O(force)
 def VVtsBh(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVJO6O(force)
 def VVJO6O(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVkClb = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVkClb: self.curPage = VVkClb
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVYFDn()
  self["myPiconPtr"].hide()
  self.VVMojK(self.curPage + 1, self.totalPages)
  FFJVhm(BF(self.VVXLgh, force or not oldPage == self.curPage, VVkClb))
 def VVXLgh(self, force, VVkClb):
  try:
   if force:
    self.VV4zLS()
   if self.curPage == VVkClb:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVYFDn()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVRtr4(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVJO6O(False if oldPage == self.curPage else True)
  else:
   FF1lLq(self, "Not found", 1000)
 def VV0TfD(self):
  self.VVRtr4(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVBKxc(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVqa8Z(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVdHsF, CCx0wY, defFG=fg, defBG=bg, onlyBG=True)
 def VVdHsF(self, fg, bg):
  if self.colorCfg and bg:
   FFCRXL(self.colorCfg, bg)
   self.VV5Sd7()
 def VV5Sd7(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFBHn2(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVVTYR(self, lbl, txt, color=""):
  CCU3LA.VVUXIP(lbl, txt, color)
 @staticmethod
 def VVUXIP(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VV4fhS(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCaOhY(Screen, CCU3LA):
 def __init__(self, session, VVgAw8, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFhwpa(VVOEQY, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVgAw8  = VVgAw8
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVWhjq    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFOUwv(self, self.Title)
  CCU3LA.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVmc3z, subPath)
  if not pathExists(self.pPath):
   FF7Jdu("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVTQe0    ,
   "cancel": self.close    ,
   "menu" : self.VVIrFQ ,
   "info" : self.VVyxcL  ,
   "0"  : self.VV0TfD
  })
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  FFimE3(self)
  self.VVIe5F()
  self.VVu2uG()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVIrFQ(self):
  chName, subj, desc, fName, picUrl = self.VVWhjq[self.curIndex]
  VVGuvj = []
  VVGuvj.append(FFUHeM("Show Selected Picture"        , "VV27jP"  , fName))
  VVGuvj.append(FFUHeM("Copy Selected Picture to Export-Directory"   , "VViQxr" , fName))
  VVGuvj.append(FFUHeM("Set Selected Picture as a Poster for a Local Media" , "VV5mdN", fName))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Cache details"       , "VV6HF0"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Poster/Picon Transparency Color" , "VVqa8Z" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Help (Keys)"        , "help"     ))
  FFSiXW(self, self.VVZ3XF, title=self.Title, VVGuvj=VVGuvj)
 def VVZ3XF(self, item=None):
  if item is not None:
   if   item == "VV27jP"   : self.VV27jP()
   elif item == "VViQxr"   : self.VViQxr()
   elif item == "VV5mdN"  : self.VV5mdN()
   elif item == "VV6HF0"  : FF4idw(self, self.VV6HF0, title="Calculating ...")
   elif item == "VVqa8Z": self.VVqa8Z()
   elif item == "help"     : FF9ePp(self, "_help_servBr", "Server Browser (Keys)")
 def VVTQe0(self):
  self.VVgAw8.VVAGTP(self.curIndex)
  self.VVgAw8.VVZuIc()
 def VVyxcL(self):
  self.VVgAw8.VVAGTP(self.curIndex)
  self.VVgAw8.VVIMAf()
 def VVu2uG(self):
  for colList in self.VVgAw8.VVYgJy():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = self.VVC1fn(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVWhjq.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVWhjq)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVgAw8.VVmG96()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVJO6O(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV6JHb)
  except:
   self.timer.callback.append(self.VV6JHb)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVxkGl)
  self.myThread.start()
 def VVC1fn(self, url):
  fName = os.path.basename(url)
  span = iSearch(r'(.+\.(?:png|jpg))', fName, IGNORECASE)
  return span.group(1) if span else fName
 def VVxkGl(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVWhjq):
    if not self.stopThread:
     if picUrl and not fName:
      fName = self.VVC1fn(picUrl)
      path, err = FFl4UT(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FF7Jdu("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVWhjq[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV6JHb(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVs795 + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVWhjq[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVWhjq[ndx] = (chName, subj, desc, fName, "")
     CCU3LA.VV4fhS(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV4zLS(self):
  self.VVBKxc()
  f1, f2 = self.VVuRsD()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVWhjq[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVTYR(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVqXR1 + "iptv.png"
   CCU3LA.VV4fhS(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVYFDn(self):
  chName, subj, desc, fName, picUrl = self.VVWhjq[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV27jP(self):
  chName, subj, desc, fName, picUrl = self.VVWhjq[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCKpZj.VVAgYH(self, self.pPath + fName)
  else          : FF1lLq(self, "File not found", 1500)
 def VViQxr(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVWhjq[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FF7Jdu("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFDx6X(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFeF28(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFeF28(self, "No Poster/PIcon found", title=title)
 def VV5mdN(self):
  self.session.openWithCallback(self.VVuAlo, BF(CCZHbk, patternMode="movies", VVYYtf=CFG.MovieDownloadPath.getValue()))
 def VVuAlo(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVWhjq[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FF7Jdu("cp -f '%s' '%s'" % (srcF, dstF)):
     FFDx6X(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFeF28(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCjp5c.VVtQ3d(dstF)
   else:
    FFeF28(self, "No Poster/PIcon found", title=title)
 def VV6HF0(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVmc3z, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFGRiq("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCZHbk.VVi3go(size)
   txt += "%s\n    %s\n\n" % (FF4aCb(path, VV2Bne), size)
  mainPath = "%sPosters" % VVmc3z
  totFiles = FFGRiq("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFtCOg(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF4aCb("Total space used by Posters/PIcons%s:" % totFTxt, VVc1MO), CCZHbk.VVi3go(totSize))
  mountPath = CCZHbk.VVfWtD(mainPath)
  if pathExists(mountPath):
   totSize  = CCZHbk.VVGOxo(mountPath)
   freeSize = CCZHbk.VV0ZbU(mountPath)
   usedSize = CCZHbk.VVi3go(totSize - freeSize)
   totSize  = CCZHbk.VVi3go(totSize)
   freeSize = CCZHbk.VVi3go(freeSize)
   txt += "%s\n" % SEP
   txt += FF4aCb("Media Space:\n", VVwWfr)
   txt += "    Media Path\t: %s\n" % FF4aCb(mountPath, VVXSg2)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFPaL6(self, txt, title="Cache Used Size", height=1000)
class CCjp5c(Screen, CCU3LA):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFhwpa(VVW1QX, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVWhjq    = lst
  FFOUwv(self, self.Title)
  CCU3LA.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVTQe0    ,
   "cancel": self.close    ,
   "menu" : self.VVd6NV ,
   "info" : self.VVeyxA  ,
   "0"  : self.VV0TfD
  })
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  FFimE3(self)
  self.VVIe5F()
  self.totalItems = len(self.VVWhjq)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVJO6O(True)
 def VV4zLS(self):
  self.VVBKxc()
  f1, f2 = self.VVuRsD()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVWhjq[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVqXR1 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVTYR(lbl, os.path.splitext(os.path.basename(path))[0])
   CCU3LA.VV4fhS(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVxAdI(self):
  path, movie, poster = self.VVWhjq[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVYFDn(self):
  path, poster = self.VVxAdI()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVd6NV(self):
  path, poster = self.VVxAdI()
  VVGuvj = []
  VVGuvj.append(("Go to movie ...", "VVYF6q"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("Show Poster"      , "VV27jP" , poster))
  VVGuvj.append(FFUHeM("Copy Poster to Export-Directory" , "VViQxr", poster))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Poster/Picon Transparency Color"  , "VVqa8Z" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Poster (from current movie path) ..." , "VVaPUW1"  ))
  VVGuvj.append(("Change Poster (locate manually) ..."   , "VVaPUW2"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Help (Keys)"         , "help"     ))
  FFSiXW(self, self.VV6NhO, title=self.Title, VVGuvj=VVGuvj)
 def VV6NhO(self, item=None):
  if item is not None:
   if   item == "VVYF6q"    : self.VVYF6q()
   elif item == "VViQxr"    : self.VViQxr()
   elif item == "VV27jP"    : self.VV27jP()
   elif item == "VVqa8Z" : self.VVqa8Z()
   elif item == "VVaPUW1"  : self.VVaPUW()
   elif item == "VVaPUW2"  : self.VVaPUW(True)
   elif item == "help"      : FF9ePp(self, "_help_movBr", "Movies Browser (Keys)")
 def VVYF6q(self):
  VVJpUa = []
  for ndx, item in enumerate(self.VVWhjq):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVJpUa.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVJpUa.sort(key=lambda x: x[0].lower())
  VVrjyr = ("Select" , self.VVDk4d, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFBxNx(self, None, title="Select Movie", width=1800, height=1000, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, lastFindConfigObj=CFG.lastFindMovie)
 def VVDk4d(self, VVgAw8, title, txt, colList):
  self.VVRtr4(int(colList[2].strip()))
  VVgAw8.cancel()
 def VVTQe0(self):
  path, poster = self.VVxAdI()
  FF4idw(self, BF(CCZHbk.VVrMz7, self, path), title="Playing Media ...")
 def VVeyxA(self):
  path, poster = self.VVxAdI()
  txt = "%s:\n%s\n\n" % (FF4aCb("Path", VV2Bne), path)
  size = FFgx6P(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF4aCb("File Size", VV2Bne), CCZHbk.VVi3go(size))
  if poster:
   txt += "%s:\n%s" % (FF4aCb("Poster", VV2Bne), poster)
  FFPaL6(self, txt, title="Media File Information")
 def VV27jP(self):
  path, poster = self.VVxAdI()
  if fileExists(poster): CCKpZj.VVAgYH(self, poster)
  else     : FF1lLq(self, "No Poster", 1500)
 def VViQxr(self):
  title = "Copy Poster"
  path, poster = self.VVxAdI()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FF7Jdu("cp -f '%s' '%s'" % (poster, dstF)):
    FFDx6X(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFeF28(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FF1lLq(self, "No Poster", 1500)
 def VVaPUW(self, isManual=False):
  path, poster = self.VVxAdI()
  sDir = FFvBW5(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VV0sn2, sDir, path), BF(CCZHbk, patternMode="poster", VVYYtf=sDir))
  else:
   VVGuvj = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVGuvj.append((os.path.basename(item), sDir + item))
   if VVGuvj:
    VVGuvj.sort(key=lambda x: x[0].lower())
    VVrN3L = self.VVyHDU
    FFSiXW(self, BF(self.VV0sn2, sDir, path), VVGuvj=VVGuvj, title="Posters", VVrN3L=VVrN3L, VV51Jr=sDir)
   else:
    FF1lLq(self, "No jpg/png in current dir", 1500)
 def VVyHDU(self, VVUD8b, txt, ref, ndx):
  CCKpZj.VVAgYH(self, VVPWSw=ref)
 def VV0sn2(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FF7Jdu("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVWhjq[self.curIndex] = (self.VVWhjq[self.curIndex][0], self.VVWhjq[self.curIndex][1], os.path.basename(newPath))
    FF4idw(self, self.VV4zLS)
    CCjp5c.VVtQ3d(newPath)
   else:
    FF1lLq(self, "Cannot copy file", 1000)
 @staticmethod
 def VVtQ3d(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FF7Jdu("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVtbOC(SELF):
  eLst = CCw3cf.VV81Gw()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCjp5c, title, lst)
  else  : FFeF28(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCSdjT(Screen, CCU3LA):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFhwpa(VVHJuQ, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVWhjq    = lst
  self.pPath    = CCnBmO.VVYQsq()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFOUwv(self, self.Title)
  FFtNax(self["keyRed"] , "OK = Zap (Review)")
  FFtNax(self["keyGreen"] , "Zap & Exit")
  FFtNax(self["keyYellow"], "Find Current Service")
  CCU3LA.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VV7Mus, False),
   "cancel" : self.VV7Dit      ,
   "menu"  : self.VVeNoC   ,
   "red"  : self.VV7Dit      ,
   "green"  : BF(self.VV7Mus, True) ,
   "yellow" : BF(self.VVIxV9, True)  ,
   "0"   : self.VV0TfD
  })
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFRBDi(self)
   FFimE3(self)
   FFBHn2(self["keyRed"], "#0a333333")
   self.VVIe5F()
  else:
   pName, srvLst = CCSdjT.VVdyIE()
   if srvLst and not srvLst == self.VVWhjq:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVWhjq = srvLst
   else:
    force = False
  self.totalItems = len(self.VVWhjq)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVJO6O(force)
  self.VVIxV9()
 def VVeNoC(self):
  VVGuvj = []
  VVGuvj.append(("Find Name (sorted list)" , "findSrt"  ))
  VVGuvj.append(("Find Name (as listed)" , "findNoSrt"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Change Background Color" , "VVqa8Z"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Help (Keys)", "help"))
  FFSiXW(self, self.VVyVPE, title="Options", VVGuvj=VVGuvj)
 def VVyVPE(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVaCHD(True)
   elif item == "findNoSrt"   : self.VVaCHD(False)
   elif item == "VVqa8Z": self.VVqa8Z()
   elif item == "help"     : FF9ePp(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVaCHD(self, isSort):
  VVGuvj = []
  for ndx, item in enumerate(self.VVWhjq):
   VVGuvj.append((item[1], ndx))
  if isSort:
   VVGuvj.sort(key=lambda x: x[0].lower())
  FFSiXW(self, self.VVcdr6, title="Find Name", VVGuvj=VVGuvj, width=1300)
 def VVcdr6(self, ndx=None):
  if ndx is not None:
   self.VVRtr4(ndx)
 def VV7Dit(self):
  if self.shown: self.close()
  else   : self.show()
 def VV7Mus(self, isExit):
  FF4idw(self, BF(self.VVuEj3, isExit), title="Starting ...")
 def VVuEj3(self, isExit):
  try:
   if self.shown:
    FF5kbK(self, self.VVWhjq[self.curIndex][0], VVCqYJ=False)
    if isExit: self.close()
    else  : CCP76G.VVBpiW(self.session)
   else:
    self.show()
  except:
   pass
 def VVIxV9(self, VVhghQ=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVWhjq):
    if curRef == item[0]:
     self.VVRtr4(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVhghQ and err:
   FF1lLq(self, err, 500)
  return -1
 def VV4zLS(self):
  self.VVBKxc()
  f1, f2 = self.VVuRsD()
  row = col = 0
  noPos = VVqXR1 + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVWhjq[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVTYR(lbl, name)
   path = CCnBmO.VVPcUO(self.pPath, ref, name) or noPos
   CCU3LA.VV4fhS(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVYFDn(self):
  ref, name = self.VVWhjq[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVPkjD():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVZuLk = InfoBar.instance
  if VVZuLk:
   csel = VVZuLk.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFg7sk(rootRef)
    refName  = FFg7sk(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVdyIE(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCSdjT.VVPkjD()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FF7SJo(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCQrUI.VVAp70()
   pName  = CCQrUI.VV3Lcf() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVxpCE(SELF):
  pName, srvLst = CCSdjT.VVdyIE()
  if srvLst: SELF.session.open(CCSdjT, pName, srvLst)
  else  : FFeF28(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCG4Wp(Screen, CCU3LA):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFhwpa(VV9kHO, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVWhjq    = CCG4Wp.VVP3wO(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  self.firstTime   = True
  FFOUwv(self, self.Title)
  FFtNax(self["keyRed"] , "Remove Plugins")
  FFtNax(self["keyGreen"] , "Download New Plugins")
  FFtNax(self["keyYellow"], "Package Info.")
  FFtNax(self["keyBlue"] , "Plugins Group")
  CCU3LA.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVdY9W   ,
   "cancel" : self.close    ,
   "menu"  : self.VVsehO ,
   "info"  : self.VVB1QR  ,
   "red"  : BF(self.VVHQFz, False)   ,
   "green"  : BF(self.VVHQFz, True)   ,
   "yellow" : BF(FF4idw, self, self.VVeghC),
   "blue"  : self.VVv74q  ,
   "0"   : self.VV0TfD
  })
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  FFimE3(self)
  self.VVIe5F()
  self.VVD5OH()
 def VVD5OH(self):
  self.totalItems = len(self.VVWhjq)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVJO6O(True)
 def VV1Vkp(self):
  lst = CCG4Wp.VVj9GX(PluginDescriptor.WHERE_PLUGINMENU)
  if lst:
   lst = CCG4Wp.VVP3wO(lst)
   if lst != self.VVWhjq:
    self.VVWhjq = lst
    self.VVD5OH()
  else:
   self.close()
 def VVHQFz(self, isInstall):
  try:
   from Screens.PluginBrowser import PluginDownloadBrowser as pb
   if isInstall:
    self.session.openWithCallback(self.VV1Vkp, pb, pb.DOWNLOAD, self.firstTime)
    self.firstTime = False
   else:
    self.session.openWithCallback(self.VV1Vkp, pb, pb.REMOVE)
  except:
   try:
    from Plugins.SystemPlugins.SoftwareManager.plugin import PluginManager as pb
    self.session.openWithCallback(self.VV1Vkp, pb)
   except:
    FFeF28(self, 'Cannot open "Extensions Management" !', title=self.Title)
 def VVdY9W(self):
  name, desc = self.VVwhiW(self.curIndex)
  if name == PLUGIN_NAME and "VV7rTR" in globals() and VV7rTR:
   FF1lLq(self, "Already running.", 500)
  else:
   try:
    p = self.VVWhjq[self.curIndex]
    p(session=self.session)
   except:
    FFeF28(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVB1QR(self):
  def VV1pWY(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVWhjq[self.curIndex]
  txt = ""
  try:
   txt += VV1pWY("Path"  , p.path  )
   txt += VV1pWY("Description" , p.description )
   txt += VV1pWY("Icon"  , p.iconstr  )
   txt += VV1pWY("Wakeup Fnc" , p.wakeupfnc )
   txt += VV1pWY("NeedsRestart", p.needsRestart)
   txt += VV1pWY("Internal" , p.internal )
   txt += VV1pWY("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVwhiW(self.curIndex)
  if txt : FFPaL6(self, txt, title=name)
  else : FFeF28(self, "Could not read plugin info.", title=name)
 def VVeghC(self):
  p = self.VVWhjq[self.curIndex]
  name, desc = self.VVwhiW(self.curIndex)
  path = p.path
  pkg, err = CCyvvH.VV90G2(path)
  if pkg : CCyvvH.VVPWOb(self, pkg, name)
  else : FFFSea(self, err, 1000)
 def VVsehO(self):
  path = self.VVWhjq[self.curIndex].path
  VVGuvj = []
  txt = "Open Plugin Path in File Manager"
  VVGuvj.append(FFUHeM("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Use Original Icon Size", "setOrigSize"))
  FFSiXW(self, self.VVS69o, title="Plugins Group", VVGuvj=VVGuvj)
 def VVS69o(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCZHbk, mode=CCZHbk.VV74nh, VVYYtf=self.VVWhjq[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVJO6O(True)
 def VVv74q(self):
  FFSiXW(self, self.VVMxj7, title="Plugins Group", VVGuvj=CCG4Wp.VVgbx3(True, True), width=700, VVYJYo=True)
 def VVMxj7(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCG4Wp.VVj9GX(where)
   if lst:
    self.VVWhjq = CCG4Wp.VVP3wO(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVWhjq)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVJO6O(True)
   else:
    FFeF28(self, "Not found !", title=self.Title)
 def VV4zLS(self):
  self.VVBKxc()
  f1, f2 = self.VVuRsD()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVwhiW(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVVTYR(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVWhjq[ndx].icon:
    try:
     pngSz = self.VVWhjq[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVWhjq[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVWhjq[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVqXR1 + "plugin.png")
    for path in icons:
     pixMap = CCU3LA.VV4fhS(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVwhiW(self, ndx):
  name = str(self.VVWhjq[ndx].name).strip()
  desc = str(self.VVWhjq[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFc02K(self.VVWhjq[ndx].path)
  return name, desc
 def VVYFDn(self):
  name, desc = self.VVwhiW(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVgbx3(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCG4Wp.VVj9GX(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVE7tQ, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVnek4)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVj9GX(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVP3wO(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFc02K(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVgWsr(session):
  title = "Plugins Browser"
  lst = CCG4Wp.VVj9GX(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : session.open(CCG4Wp, title, lst)
  else : FFYd19(session, "No plugins found !", title=title)
class CChPHM(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFhwpa(VVwa4P, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVii2f  = 0
  self.VVNngL = 1
  self.VV5VHN  = 2
  VVGuvj = []
  VVGuvj.append(("Find in All Service (from filter)" , "VVRuUU" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Find in All (Manual Entry)"   , "VVDhQN"    ))
  VVGuvj.append(("Find in TV"       , "VVVOaE"    ))
  VVGuvj.append(("Find in Radio"      , "VVEdpc"   ))
  if self.VVidgu():
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Hide Channel: %s" % self.servName , "VVcP8x"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Zap History"       , "VVNDKx"    ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("IPTV Tools"       , "iptv"      ))
  VVGuvj.append(("PIcons Tools"       , "PIconsTools"     ))
  VVGuvj.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVGuvj.append(("EPG Tools"       , "epgTools"     ))
  FFOUwv(self, VVGuvj=VVGuvj, title=title)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self)
  if self.isFindMode:
   self.VV6RtB(self.VVcMhS())
 def VVTQe0(self):
  global VV7UWf
  VV7UWf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVDhQN"    : self.VVDhQN()
   elif item == "VVRuUU" : self.VVRuUU()
   elif item == "VVVOaE"    : self.VVVOaE()
   elif item == "VVEdpc"   : self.VVEdpc()
   elif item == "VVcP8x"   : self.VVcP8x()
   elif item == "VVNDKx"    : self.VVNDKx()
   elif item == "iptv"       : self.session.open(CCCW9K)
   elif item == "PIconsTools"     : self.session.open(CCnBmO)
   elif item == "ChannelsTools"    : self.session.open(CC1mtH)
   elif item == "epgTools"      : self.session.open(CCTnwS)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVVOaE(self) : self.VV6RtB(self.VVii2f)
 def VVEdpc(self) : self.VV6RtB(self.VVNngL)
 def VVDhQN(self) : self.VV6RtB(self.VV5VHN)
 def VV6RtB(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFrwu2(self, BF(self.VVWyNp, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVRuUU(self):
  filterObj = CCiRFn(self)
  filterObj.VVi7C2(self.VVRLwN)
 def VVRLwN(self, item):
  self.VVWyNp(self.VV5VHN, item)
 def VVidgu(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFOXrQ(self.refCode)        : return False
  return True
 def VVWyNp(self, mode, VVHuuk):
  FF4idw(self, BF(self.VVDM5B, mode, VVHuuk), title="Searching ...")
 def VVDM5B(self, mode, VVHuuk):
  if VVHuuk:
   VVHuuk = VVHuuk.strip()
  if VVHuuk:
   self.findTxt = VVHuuk
   CFG.lastFindContextFind.setValue(VVHuuk)
   if   mode == self.VVii2f  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVNngL : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVHuuk)
   if len(title) > 55:
    title = title[:55] + ".."
   VVJpUa = self.VV8Clr(VVHuuk, servTypes)
   if self.isFindMode or mode == self.VV5VHN:
    VVJpUa += self.VVfnWe(VVHuuk)
   if VVJpUa:
    VVJpUa.sort(key=lambda x: x[0].lower())
    VVJlHN = self.VVQvwE
    VVrjyr  = ("Zap"   , self.VVKiTy    , [])
    VVdyRp = ("Current Service", self.VVJZQl , [])
    VVpxmm = ("Options"  , self.VVQ2RY , [])
    VVGySq = (""    , self.VVcXcg , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVRYg6  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VVGySq=VVGySq, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VV6RtB(self.VVcMhS())
    FFDx6X(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV8Clr(self, VVHuuk, servTypes):
  VVWhjq = CC1mtH.VVZAIa(servTypes)
  VVJpUa = []
  if VVWhjq:
   VVHhLZ, VV9Tj5 = FF77N5()
   tp = CCg0iP()
   words, asPrefix = CCiRFn.VVAtaF(VVHuuk)
   colorYellow  = CC3JT1.VVKluA(VVc1MO)
   colorWhite  = CC3JT1.VVKluA(VViU6E)
   for s in VVWhjq:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFUQ44(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVHhLZ:
        STYPE = VV9Tj5[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV8PWd(refCode)
       if not "-S" in syst:
        sat = syst
       VVJpUa.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVJpUa
 def VVfnWe(self, VVHuuk):
  VVHuuk = VVHuuk.lower()
  VVJpUa = []
  colorYellow  = CC3JT1.VVKluA(VVc1MO)
  colorWhite  = CC3JT1.VVKluA(VViU6E)
  for b in CCQrUI.VVnAje():
   VVQdU6  = b[0]
   VVXxCt  = b[1].toString()
   VV9fAX = eServiceReference(VVXxCt)
   VV2G1l = FF7SJo(VV9fAX)
   for service in VV2G1l:
    refCode  = service[0]
    if FFOXrQ(refCode):
     servName = service[1]
     if VVHuuk in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVHuuk), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVJpUa.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVJpUa
 def VVcMhS(self):
  mode = CC7xD6.VVNbTy(default=-1)
  return self.VV5VHN if mode == -1 else mode
 def VVQvwE(self, VVgAw8):
  self.close()
  VVgAw8.cancel()
 def VVKiTy(self, VVgAw8, title, txt, colList):
  FF5kbK(VVgAw8, colList[2], VVCqYJ=False, checkParentalControl=True)
 def VVJZQl(self, VVgAw8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(VVgAw8)
  if refCode:
   VVgAw8.VVIvlb(2, FFbIhH(refCode, iptvRef, chName), True)
 def VVQ2RY(self, VVgAw8, title, txt, colList):
  servName = colList[0]
  mSel = CCwZHL(self, VVgAw8)
  VVGuvj, cbFncDict = CC1mtH.VVKCFd(self, VVgAw8, servName, 2)
  mSel.VV71Gx(VVGuvj, cbFncDict)
 def VVcXcg(self, VVgAw8, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFw3XJ(self, fncMode=CCM3PM.VVipqo, refCode=refCode, chName=chName, text=txt)
 def VVcP8x(self):
  FFZRvh(self, self.VVG8kg, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVG8kg(self):
  ret = FFwZjD(self.refCode, True)
  if ret:
   self.VV0IET()
   self.close()
  else:
   FF1lLq(self, "Cannot change state" , 1000)
 def VV0IET(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVacBw()
  except:
   self.VVzrmM()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFR64J(self, serviceRef)
 def VVacBw(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVZuLk = InfoBar.instance
   if VVZuLk:
    VV83rW = VVZuLk.servicelist
    if VV83rW:
     hList = VV83rW.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV83rW.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV83rW.history  = newList
       VV83rW.history_pos = pos
 def VVzrmM(self):
  VVZuLk = InfoBar.instance
  if VVZuLk:
   VV83rW = VVZuLk.servicelist
   if VV83rW:
    VV83rW.history  = []
    VV83rW.history_pos = 0
 def VVNDKx(self):
  VVZuLk = InfoBar.instance
  VVJpUa = []
  if VVZuLk:
   VV83rW = VVZuLk.servicelist
   if VV83rW:
    VVHhLZ, VV9Tj5 = FF77N5()
    for serv in VV83rW.history:
     refCode = serv[-1].toString()
     chName = FFg7sk(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFOXrQ(refCode)
     isSRel = FFyCwy(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFUQ44(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVHhLZ:
       STYPE = VV9Tj5[sTypeInt]
     VVJpUa.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVJpUa:
   VVrjyr  = ("Zap"   , self.VVdoDj   , [])
   VVpxmm = ("Clear History" , self.VVCgKS   , [])
   VVGySq = (""    , self.VV23MK , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVRYg6  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VVrjyr=VVrjyr, VVpxmm=VVpxmm, VVGySq=VVGySq)
  else:
   FFDx6X(self, "History is empty.", title=title)
 def VVdoDj(self, VVgAw8, title, txt, colList):
  FF5kbK(VVgAw8, colList[3], VVCqYJ=False, checkParentalControl=True)
 def VVCgKS(self, VVgAw8, title, txt, colList):
  FFZRvh(self, BF(self.VVSc75, VVgAw8), "Clear Zap History ?")
 def VVSc75(self, VVgAw8):
  self.VVzrmM()
  VVgAw8.cancel()
 def VV23MK(self, VVgAw8, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFw3XJ(self, fncMode=CCM3PM.VVVynW, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVqWXT():
  try:
   global VV98fW
   if VV98fW is None:
    VV98fW    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CChPHM.VVDSmD
   ChannelContextMenu.VVM2TR = CChPHM.VVM2TR
  except:
   pass
 @staticmethod
 def VVDSmD(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VV98fW(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVM2TR, csel, ndx, title))))
 @staticmethod
 def VVM2TR(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFg7sk(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCSdjT.VVxpCE(SELF)
  elif mode == 2: SELF.session.open(CC7xD6)
  else    : SELF.session.open(CChPHM, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CC7xD6(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFhwpa(VVgWTf, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCnBmO.VVYQsq()
  self.bTables = []
  FFOUwv(self)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.VVfVMS()
 def VVkJPc(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVfVMS(self):
  rootStr = CC7xD6.VVvcrT()
  rows = self.VVXnUi(rootStr)
  if rows :
   self.VVMQl4(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCSdjT.VVPkjD()
   if not self.bTables[-1].VVAyL9({3:refCode}):
    self.bTables[-1].VVAyL9({3:rootRef})
  else:
   FFeF28(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVffJC(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVXnUi(self, bRef=None):
  blkLst = CC7xD6.VVuUMR()
  rows = []
  for ndx, row in enumerate(FF7SJo(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CC7xD6.VVb5KP(flags)
   lck = "1" if CC7xD6.VVQHVp(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVMQl4(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FF4aCb("Fav: ", VVE7tQ), bName), 2:"%s %s" % (FF4aCb("Sub: ", VVE7tQ), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVJlHN = self.VVuLnl
  VVGySq = (""    , self.VVBJuO  , [])
  VVrjyr  = ("Enter Bouquet" , self.VVZhwM , [])
  VVFkw1 = ("Delete"   , self.VVz9C4 , [])
  VVpxmm = ("Options"  , self.VVQ2AO , [])
  VV1SrQ = ("Move Here"  , self.VVzQTY , [])
  picParams  = (1, self.VV828B, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVRYg6 = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFBxNx(self, None, title=title, VVWhjq=rows, VVRYg6=VVRYg6, width=1500, height=1000, VVmQwL=widths, VVCppa=28, addSort=False, VVGySq=VVGySq, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VVFkw1=VVFkw1, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVOisu=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#0a442200", borderWidth=0, VVO2zv="#11330000")
  tbl.VVbjQL(BF(self.VVxB7O, tbl), True)
  self.VVkJPc(tbl, bName, bRef)
 def VVP6do(self, VVgAw8, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FF9bFs()
   rows = self.VVXnUi(VVgAw8.bouqRef)
   if rows:
    VVgAw8.VVIgTe(False)
    VVgAw8.VVFDhD(rows, VVLMQ5Msg=True, isSort=False, tableRefreshCB=BF(self.VV5d05, jumpDict))
   else:
    self.VVffJC()
    totTbl = len(self.bTables)
    FF1lLq(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFFSea(VVgAw8, "No change !", 1500)
 def VV5d05(self, jumpDict, VVgAw8, title, txt, colList):
  if jumpDict:
   VVgAw8.VVAyL9(jumpDict)
 def VVxB7O(self, VVgAw8):
  VVgAw8["keyRed"].hide()
  VVgAw8["keyBlue"].hide()
  if VVgAw8.VVhXSW:
   if VVgAw8.VVeEeJ() > 0:
    VVgAw8["keyRed"].show()
    VVgAw8["keyBlue"].show()
  else:
   VVgAw8["keyRed"].show()
 def VVBJuO(self, VVgAw8, title, txt, colList):
  c1, c2, c3 = VVc1MO, VVrWwc, VVEkv6
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FF4aCb(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CC7xD6.VVCn8x(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVgAw8.bouqName, c2)
  txt += ttl("Parent Bouquet File", CC7xD6.VVCn8x(VVgAw8.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVwauR else ""
  txt += ttl("Remarks"   , rem, c3) if VVwauR else ""
  path = CCnBmO.VVPcUO(self.pPath, ref, name)
  FFw3XJ(self, fncMode=CCM3PM.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVZhwM(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVA1NF, VVgAw8, colList) )
 def VVA1NF(self, VVgAw8, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if FFjNdl(ref):
   if len(self.bTables) <= maxLev:
    rows = self.VVXnUi(ref)
    if rows : self.VVMQl4(VVgAw8, name, ref, rows)
    else : FFFSea(VVgAw8, "Empty list !", 1500)
   else:
    FFeF28(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CC7xD6.VV2rzj(ref) == 0:
   FF5kbK(self, ref, VVCqYJ=False)
   FFm0q4(self, "Cancel to go back to table")
  else:
   FF1lLq(VVgAw8, "No action", 300)
 def VVuLnl(self, VVgAw8):
  if VVgAw8.VVhXSW:
   VVgAw8.VVIgTe(False)
   self.VVxB7O(VVgAw8)
  else:
   self.VVffJC()
 def VVQ2AO(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  iMulSel = VVgAw8.VVn6p1()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVgAw8.VVeEeJ()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFtCOg(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  okToMain = False
  if not inMain:
   for ref in self.VVZ1mC(VVgAw8):
    if not FFjNdl(ref) and not ref.startswith("1:64:"): break
   else:
    okToMain = True
  totDel = len(self.VVSepm())
  c1, c2, c3, c4 = VVrWwc, VVE7n3, VV2Bne, VVEkv6
  VVGuvj.append(FFUHeM("Rename"   , "renm" , not iMulSel, c1))
  VVGuvj.append(VVnek4)
  VVGuvj.append(FFUHeM("Add Marker"  , "mrkr" , not iMulSel, c2))
  VVGuvj.append(FFUHeM("Add Empty Bouquet", "addBouq" , not iMulSel and inMain, c2))
  if totDel:
   VVGuvj.append(VVnek4)
   VVGuvj.append((c4 + 'Delete %d Unused ".del" Bouquets File%s' % (totDel, FFtCOg(totDel)), "unused"))
  if inMain:
   VVGuvj.append(VVnek4)
   VVGuvj.append(FFUHeM("Hide %s" % bTxt , "hidOn" , isSel, c3))
   VVGuvj.append(FFUHeM("Unhide %s" % bTxt , "hidOff" , isSel, c3))
   VVGuvj.append(VVnek4)
   VVGuvj.append(FFUHeM("Protect %s" % bTxt , "lckOn" , isSel, c3))
   VVGuvj.append(FFUHeM("Unprotect %s" % bTxt , "lckOff" , isSel, c3))
   VVmEJ8, VVd8a3 = "#22001122", "#22000a15"
  else:
   VVmEJ8, VVd8a3 = "#2200120a", "#2200120a"
  VVGuvj.append(VVnek4)
  VVGuvj.append(sortItem)
  VVGuvj.append(FFUHeM("Copy to Main Bouquets List" , "toMain", okToMain))
  VVGuvj.append(FFUHeM("Copy to a Bouquet"   , "toBouq", isSel))
  cbFncDict = { "renm" : BF(self.VVx6Wr  , VVgAw8)
     , "mrkr" : BF(self.VVJ39G , VVgAw8)
     , "addBouq" : BF(self.VVEZdh, VVgAw8)
     , "unused" : BF(self.VVcK8i , VVgAw8)
     , "hidOn" : BF(self.VVbTFt  , VVgAw8, True)
     , "hidOff" : BF(self.VVbTFt  , VVgAw8, False)
     , "lckOn" : BF(self.VVQ4S3  , VVgAw8, True)
     , "lckOff" : BF(self.VVQ4S3  , VVgAw8, False)
     , "sort" : BF(self.VVvqMq  , VVgAw8)
     , "toMain" : BF(self.VVjBmg , VVgAw8)
     , "toBouq" : BF(self.VVAuai , VVgAw8) }
  fnc = BF(self.VVxB7O, VVgAw8)
  mSel = CCwZHL(self, VVgAw8)
  mSel.VV71Gx(VVGuvj, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc, height=1000, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3)
 def VVz9C4(self, VVgAw8, title, txt, colList):
  txt, totSel = "", 0
  if VVgAw8.VVn6p1():
   totSel = VVgAw8.VVeEeJ()
   if totSel:
    txt = "Delete %s item%s" % (FF4aCb(str(totSel), VVc1MO), FFtCOg(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FF4aCb(name, VVc1MO)
  if txt:
   FFZRvh(self, BF(self.VVahRU, VVgAw8), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVahRU(self, VVgAw8):
  FF4idw(VVgAw8, BF(self.VVAPE1, VVgAw8))
 def VVAPE1(self, VVgAw8):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCQrUI.VVFdHs(ref)
     if bFile:
      bFile = VVgBUe + bFile
      FF7Jdu("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VVP6do(VVgAw8, mutableList, tot)
 def VVzQTY(self, VVgAw8, title, txt, colList):
  FF4idw(VVgAw8, BF(self.VVJICe, VVgAw8))
 def VVJICe(self, VVgAw8):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  if mutableList is not None:
   curNdx = VVgAw8.VVmG96()
   if curNdx <= VVgAw8.VVRrCX(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVP6do(VVgAw8, mutableList, tot)
 def VVvqMq(self, VVgAw8):
  FF4idw(VVgAw8, BF(self.VVxHdO, VVgAw8))
 def VVxHdO(self, VVgAw8):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  if mutableList is not None:
   nmlst = VVgAw8.VVqz25(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVgAw8.VVRrCX()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVP6do(VVgAw8, mutableList, tot)
 def VVx6Wr(self, VVgAw8, item=None):
  name = VVgAw8.VVi9QZ()[2]
  FFrwu2(self, BF(self.VVB1kR, VVgAw8), defaultText=name, title="Rename", message="Enter new name")
 def VVB1kR(self, VVgAw8, name):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVgAw8.VVi9QZ()[3]
    if FFjNdl(ref):
     CCQrUI.VVIf9f(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVgAw8.VVmG96())
    self.VVP6do(VVgAw8, mutableList, 1)
 def VVJ39G(self, VVgAw8):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FF4idw(VVgAw8, BF(self.VVj3yt, VVgAw8, name))
 def VVj3yt(self, VVgAw8, name):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  if mutableList is not None:
   curServ = eServiceReference(VVgAw8.VVi9QZ()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VVP6do(VVgAw8, mutableList, tot)
 def VVEZdh(self, VVgAw8):
  names = VVgAw8.VVzb09(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFrwu2(self, BF(self.VVEkk7, VVgAw8), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VVEkk7(self, VVgAw8, name=None):
  if name and name.strip():
   FF4idw(VVgAw8, BF(self.VVbjus, VVgAw8, name.strip()))
 def VVbjus(self, VVgAw8, bName):
  CCQrUI.VVdei8(bName)
  self.VVP6do(VVgAw8, None, 1, jumpDict={2:bName})
 def VVSepm(self):
  lst = []
  for fil in os.listdir(VVgBUe):
   if fil.endswith(".tv.del") or fil.endswith(".radio.del"):
    lst.append(fil)
  return lst
 def VVcK8i(self, VVgAw8):
  lst = self.VVSepm()
  for fil in lst:
   FFOHeU(VVgBUe + fil)
  VVgAw8.VVmaQr("Done")
 def VVZ1mC(self, VVgAw8):
  if VVgAw8.VVhXSW : return VVgAw8.VVqz25(3)
  else        : return [VVgAw8.VVi9QZ()[3]]
 def VVjBmg(self, VVgAw8):
  dstFile = "bouquets.%s" % ("tv" if CC7xD6.VVNbTy() == 0 else "radio")
  FF4idw(VVgAw8, BF(self.VVQkra, VVgAw8, "Main Bouquets List", dstFile, True))
 def VVAuai(self, VVgAw8):
  bRows = CCQrUI.VV5xN1()
  lst = self.VVZ1mC(VVgAw8)
  VVGuvj = []
  for name, ref in bRows:
   if not ref in lst:
    VVGuvj.append((name, ref))
  if VVGuvj : FFSiXW(self,  BF(self.VV8zuz, VVgAw8), VVGuvj=VVGuvj, width=1100, height=900, VVmEJ8="#22220000", VVd8a3="#22110000", title="Destination Bouquet", VVYJYo=True)
  else  : FF1lLq(VVgAw8, "No bouquets left !", 1000)
 def VV8zuz(self, VVgAw8, item=None):
  if item:
   bName, bRef, ndx = item
   dstFile = CCQrUI.VVFdHs(bRef)
   FF4idw(VVgAw8, BF(self.VVQkra, VVgAw8, bName, dstFile))
 def VVQkra(self, VVgAw8, bName, dstFile, mainToo=False):
  lst = self.VVZ1mC(VVgAw8)
  tot = 0
  for ref in lst:
   ok = CCQrUI.VVUBPJ(ref, dstFile)
   if ok:
    tot += 1
  self.VVP6do(VVgAw8, None, tot)
  if mainToo:
   rootStr = CC7xD6.VVvcrT()
   rows = self.VVXnUi(rootStr)
   self.bTables[0].VVFDhD(rows, VVLMQ5Msg=True)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF4aCb(x, VV2Bne), y)
  txt  = ttl("Source Bouquet"  , VVgAw8.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFPaL6(VVgAw8, txt, title="Copy Services")
 def VVbTFt(self, VVgAw8, isHide):
  FF4idw(VVgAw8, BF(self.VVQoXN, VVgAw8, isHide))
 def VVQoXN(self, VVgAw8, isHide):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  mode = CC7xD6.VVNbTy()
  path = VVgBUe + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF8p4l(path)))
   for ref in lst:
    if FFjNdl(ref):
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VVP6do(VVgAw8, None, tot)
 def VVQ4S3(self, VVgAw8, isLck):
  FF4idw(VVgAw8, BF(self.VV5wel, VVgAw8, isLck))
 def VV5wel(self, VVgAw8, isLck):
  lst, mutableList, csel, bServ = self.VV7aRV(VVgAw8)
  blkLst = CC7xD6.VVuUMR()
  tot = 0
  for ref in lst:
   if FFjNdl(ref):
    ndx = CC7xD6.VVQHVp(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VV0xaO, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VVP6do(VVgAw8, None, tot)
 def VV7aRV(self, VVgAw8, bServ=None):
  lst = self.VVZ1mC(VVgAw8)
  mutableList = csel = None
  VVZuLk = InfoBar.instance
  if VVZuLk:
   csel = VVZuLk.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVgAw8.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VV828B(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VVqXR1, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif FFjNdl(ref):
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCnBmO.VVPcUO(self.pPath, ref, name)
 @staticmethod
 def VVb5KP(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.isNumberedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVCn8x(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVwauR:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVgBUe + span.group(1)
  return path
 @staticmethod
 def VV2rzj(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVNbTy(default=0):
  VVZuLk = InfoBar.instance
  if VVZuLk:
   csel = VVZuLk.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVvcrT():
  VVZuLk = InfoBar.instance
  if VVZuLk:
   csel = VVZuLk.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVuUMR():
  return FF8p4l(VV0xaO) if fileExists(VV0xaO) else []
 @staticmethod
 def VVQHVp(ref, lst=None):
  if not lst:
   lst = CC7xD6.VVuUMR()
  if FFjNdl(ref):
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCnBmO(Screen, CCU3LA, CCi04I):
 VVVe3U   = 0
 VVIGQ9  = 1
 VV7l0P  = 2
 VVFere  = 3
 VVnWOI  = 4
 VVaLRF  = 5
 VVJ6pu  = 6
 VVCRBG  = 7
 VVLZKp = 8
 VVZBbC = 9
 VV8nWo = 10
 VVneMN = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVe0nZ, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCnBmO.VVYQsq()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVWhjq    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFOUwv(self, self.Title)
  FFtNax(self["keyRed"] , "OK = Zap")
  FFtNax(self["keyGreen"] , "Current Service")
  FFtNax(self["keyYellow"], "Page Options")
  FFtNax(self["keyBlue"] , "Filter")
  CCU3LA.__init__(self, 5, 7, CFG.transpColorPicons)
  CCi04I.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVkg0V     ,
   "green"  : self.VV0bba    ,
   "yellow" : self.VVKmoy     ,
   "blue"  : self.VVjN2j     ,
   "menu"  : self.VVE023     ,
   "info"  : self.VVK7dI    ,
   "pageUp" : BF(self.VVdd8v, True) ,
   "chanUp" : BF(self.VVdd8v, True) ,
   "pageDown" : BF(self.VVdd8v, False) ,
   "chanDown" : BF(self.VVdd8v, False) ,
   "0"   : self.VV0TfD  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  FFimE3(self)
  FFBHn2(self["keyRed"], "#0a333333")
  self.VVIe5F()
  FF4idw(self, BF(self.VVNEGe, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVE023(self):
  if not self.isBusy:
   VVGuvj = []
   VVGuvj.append(("Statistics"           , "VVE2R7"    ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Suggest PIcons for Current Channel"     , "VVUzgy"   ))
   VVGuvj.append(("Set to Current Channel (copy file)"     , "VV3YMp_file"  ))
   VVGuvj.append(("Set to Current Channel (as SymLink)"     , "VV3YMp_link"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Export Current File Names List"      , "VVoyWK" ))
   VVGuvj.append(CCnBmO.VV5ZML())
   VVGuvj.append(VVnek4)
   c, cond = VVT2Mp, self.filterTitle == "PIcons without Channels"
   VVGuvj.append(FFUHeM("Move Unused PIcons to a Directory", "VVEkt5" , cond, c))
   VVGuvj.append(FFUHeM("DELETE Unused PIcons"    , "VVHZvY" , cond, c))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVMN7t"  ))
   VVGuvj.append(VVnek4)
   VVGuvj += CCnBmO.VVyGUy()
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Change Poster/Picon Transparency Color"    , "VVqa8Z" ))
   VVGuvj.append(("Keys Help"           , "VVhe2i"    ))
   FFSiXW(self, self.VVn6jJ, width=1100, height=1050, title=self.Title, VVGuvj=VVGuvj)
 def VVn6jJ(self, item=None):
  if item is not None:
   if   item == "VVE2R7"    : self.VVE2R7()
   elif item == "VVUzgy"   : self.VVUzgy()
   elif item == "VV3YMp_file"  : self.VV3YMp(0)
   elif item == "VV3YMp_link"  : self.VV3YMp(1)
   elif item == "VVoyWK"  : self.VVoyWK()
   elif item == "VVUVAh"  : CCnBmO.VVUVAh(self)
   elif item == "VVEkt5"   : self.VVEkt5()
   elif item == "VVHZvY"  : self.VVHZvY()
   elif item == "VVMN7t"  : self.VVMN7t()
   elif item == "VVdSYr"  : CCnBmO.VVdSYr(self)
   elif item == "findPiconBrokenSymLinks" : CCnBmO.VVVExi(self, True)
   elif item == "FindAllBrokenSymLinks" : CCnBmO.VVVExi(self, False)
   elif item == "VVqa8Z" : self.VVqa8Z()
   elif item == "VVhe2i"     : FF9ePp(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVKmoy(self):
  if not self.isBusy:
   VVGuvj = []
   VVGuvj.append(("Go to First PIcon"  , "VV5QEg"  ))
   VVGuvj.append(("Go to Last PIcon"   , "VVtsBh"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Sort by Channel Name"     , "sortByChan" ))
   VVGuvj.append(("Sort by File Name"  , "sortByFile" ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Find from File List .." , "VVxzZL" ))
   FFSiXW(self, self.VVcHqq, title=self.Title, VVGuvj=VVGuvj)
 def VVcHqq(self, item=None):
  if item is not None:
   if   item == "VV5QEg"   : self.VV5QEg()
   elif item == "VVtsBh"   : self.VVtsBh()
   elif item == "sortByChan"  : self.VV5lQS(2)
   elif item == "sortByFile"  : self.VV5lQS(0)
   elif item == "VVxzZL"  : self.VVxzZL()
 def VVxzZL(self):
  VVGuvj = []
  for item in self.VVWhjq:
   VVGuvj.append((item[0], item[0]))
  FFSiXW(self, self.VVgqsm, title='PIcons ".png" Files', VVGuvj=VVGuvj, VVYJYo=True)
 def VVgqsm(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVRtr4(ndx)
 def VVkg0V(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVWpmm()
   if refCode:
    FF5kbK(self, refCode)
    self.VViHNm()
    self.VVYFDn()
 def VVdd8v(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VViHNm()
   self.VVYFDn()
  except:
   pass
 def VV0bba(self):
  if self["keyGreen"].getVisible():
   self.VVRtr4(self.curChanIndex)
 def VV5lQS(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF4idw(self, BF(self.VVNEGe, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV3YMp(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVWpmm()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVGuvj = []
     VVGuvj.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVGuvj.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFSiXW(self, BF(self.VVFLZB, mode, curChF, selPiconF), VVGuvj=VVGuvj, title="Current Channel PIcon (already exists)")
    else:
     self.VVFLZB(mode, curChF, selPiconF, "overwrite")
   else:
    FFeF28(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFeF28(self, "Could not read current channel info. !", title=title)
 def VVFLZB(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FF7Jdu(cmd)
   FF4idw(self, BF(self.VVNEGe, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVEkt5(self):
  defDir = FFvBW5(CCnBmO.VVYQsq() + "picons_backup")
  FF7Jdu("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVzdKW, defDir), BF(CCZHbk
         , mode=CCZHbk.VVms2N, VVYYtf=CCnBmO.VVYQsq()))
 def VVzdKW(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCnBmO.VVYQsq():
    FFeF28(self, "Cannot move to same directory !", title=title)
   else:
    if not FFvBW5(path) == FFvBW5(defDir):
     self.VVnDAO(defDir)
    FFZRvh(self, BF(FF4idw, self, BF(self.VVNYzS, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVWhjq), path), title=title)
  else:
   self.VVnDAO(defDir)
 def VVNYzS(self, title, defDir, toPath):
  if not iMove:
   self.VVnDAO(defDir)
   FFeF28(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFvBW5(toPath)
  pPath = CCnBmO.VVYQsq()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVWhjq:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVWhjq)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFPaL6(self, txt, title=title, VVcGiE="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVTsZb("all")
 def VVnDAO(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVHZvY(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVWhjq)
  FFZRvh(self, BF(FF4idw, self, BF(self.VVjIYz, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFtCOg(tot)), title=title)
 def VVjIYz(self, title):
  pPath = CCnBmO.VVYQsq()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVWhjq:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVWhjq)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF4aCb(str(totErr), VVEkv6)
  FFPaL6(self, txt, title=title)
 def VVMN7t(self):
  lines = FFkrzQ("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFZRvh(self, BF(self.VVB3Bw, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFtCOg(tot)), VVnBJJ=True)
  else:
   FFDx6X(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVB3Bw(self, fList):
  FF7Jdu("find -L '%s' -type l -delete" % self.pPath)
  FFDx6X(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVK7dI(self):
  FF4idw(self, self.VVEqmW)
 def VVEqmW(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVWpmm()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF4aCb("PIcon Directory:\n", VVrWwc)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFFCVj(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFFCVj(path)
   txt += FF4aCb("PIcon File:\n", VVrWwc)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF4aCb("Found %d SymLink%s to this file from:\n" % (tot, FFtCOg(tot)), VVrWwc)
     for fPath in slLst:
      txt += "  %s\n" % FF4aCb(fPath, VVE7tQ)
     txt += "\n"
   if chName:
    txt += FF4aCb("Channel:\n", VVrWwc)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF4aCb(chName, VV1udq)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF4aCb("Remarks:\n", VVrWwc)
    txt += "  %s\n" % FF4aCb("Unused", VVEkv6)
  else:
   txt = "No info found"
  FFw3XJ(self, fncMode=CCM3PM.VVQW0q, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVWpmm(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVWhjq[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFFBpn(sat)
  return fName, refCode, chName, sat, inDB
 def VViHNm(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVWhjq):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVYFDn(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVWpmm()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF4aCb("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVrWwc))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVWpmm()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFyCwy(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF4aCb(self.curChanName, VVc1MO)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVWpmm()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVE2R7(self):
  VVHhLZ, VV9Tj5 = FF77N5()
  sTypeNameDict = {}
  for key, val in VV9Tj5.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVWhjq:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VV9Tj5: sTypeDict[VV9Tj5[stNum]] = sTypeDict.get(VV9Tj5[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFGRiq("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVJpUa = []
  c = "#b#11003333#"
  VVJpUa.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVJpUa.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVJpUa.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVJpUa.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVJpUa.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVJpUa.append((c + "Satellites"    , str(len(self.nsList))))
  VVJpUa.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVJpUa.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVJpUa.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVJpUa.extend(sTypeRows)
  FFBxNx(self, None, title=self.Title, VVWhjq=VVJpUa, VVCppa=28, VVh96o="#00003333", VV5t00="#00222222")
 def VVoyWK(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFvBW5(CFG.exportedTablesPath.getValue()), txt, FFguCY())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVWhjq:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFDx6X(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVjN2j(self):
  if not self.isBusy:
   VVGuvj = []
   VVGuvj.append(("All"        , "all"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Used by Channels"     , "used" ))
   VVGuvj.append(("Unused PIcons"     , "unused" ))
   VVGuvj.append(("IPTV PIcons"      , "iptv" ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("PIcons Files"      , "pFiles" ))
   VVGuvj.append(("SymLinks to PIcons"    , "pLinks" ))
   VVGuvj.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVGuvj.append(("By Files Date ..."    , "pDate" ))
   VVGuvj.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVGuvj.append(FFJ9Ko("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFwZpN(val)
      VVGuvj.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCiRFn(self)
   filterObj.VVhJnM(VVGuvj, self.nsList, self.VVmfHx)
 def VVmfHx(self, item=None):
  if item is not None:
   self.VVTsZb(item)
 def VVTsZb(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVVe3U   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVIGQ9   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV7l0P  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVJ6pu   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVFere  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVnWOI  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVaLRF  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV8nWo , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVneMN , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVCRBG   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVLZKp , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVaLRF:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFkrzQ("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFc02K(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF1lLq(self, "Not found", 1000)
     return
   elif mode == self.VV8nWo:
    self.VVM5IJ(mode)
    return
   elif mode == self.VVneMN:
    self.VVDTHt(mode)
    return
   elif mode == self.VVZBbC:
    return
   else:
    words, asPrefix = CCiRFn.VVAtaF(words)
   if not words and mode in (self.VVCRBG, self.VVLZKp):
    FF1lLq(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF4idw(self, BF(self.VVNEGe, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVM5IJ(self, mode):
  VVGuvj = []
  VVGuvj.append(("Today"   , "today" ))
  VVGuvj.append(("Since Yesterday" , "yest" ))
  VVGuvj.append(("Since 7 days"  , "week" ))
  FFSiXW(self, BF(self.VVmDzn, mode), VVGuvj=VVGuvj, title="Filter by Added/Modified Date")
 def VVmDzn(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFdn1k(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFdn1k(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFdn1k(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF4idw(self, BF(self.VVNEGe, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVDTHt(self, mode):
  VVHhLZ, VV9Tj5 = FF77N5()
  lst = set()
  for key, val in VV9Tj5.items():
   lst.add(val)
  VVGuvj = []
  for item in lst:
   VVGuvj.append((item, item))
  VVGuvj.sort(key=lambda x: x[0])
  FFSiXW(self, BF(self.VVcXY8, mode), VVGuvj=VVGuvj, title="Filter by Service Type")
 def VVcXY8(self, mode, item=None):
  if item:
   VVHhLZ, VV9Tj5 = FF77N5()
   sTypeList = []
   for key, val in VV9Tj5.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF4idw(self, BF(self.VVNEGe, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVUzgy(self):
  self.session.open(CCYPVd, barTheme=CCYPVd.VVCXsd
      , titlePrefix = ""
      , fncToRun  = self.VVQiin
      , VVHoAX = self.VV1iyE)
 def VVQiin(self, VVXuS2):
  VVAvkb, err = CC1mtH.VVb6EG(self, CC1mtH.VVUq4c, VVpuYC=False, VVgAsb=False)
  files = []
  words = []
  if not VVXuS2 or VVXuS2.isCancelled:
   return
  VVXuS2.VVoBtV = []
  VVXuS2.VVhaSh(len(VVAvkb))
  if VVAvkb:
   curCh = self.VVOBp7(self.curChanName)
   for refCode in VVAvkb:
    if not VVXuS2 or VVXuS2.isCancelled:
     return
    VVXuS2.VVzPku(1, True)
    chName, sat, inDB = VVAvkb.get(refCode, ("", "", 0))
    ratio = CCnBmO.VVcA0S(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCnBmO.VVgrYH(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFc02K(f)
       fil = f.replace(".png", "")
       if not fil in VVXuS2.VVoBtV:
        VVXuS2.VVoBtV.append(fil)
 def VV1iyE(self, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  if VVoBtV : FF4idw(self, BF(self.VVNEGe, mode=self.VVZBbC, words=VVoBtV), title="Loading ...")
  else   : FF1lLq(self, "Not found", 2000)
 def VVNEGe(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVdmNa(isFirstTime):
   return
  self.isBusy = True
  VVgAsb = True if isFirstTime else False
  VVAvkb, err = CC1mtH.VVb6EG(self, CC1mtH.VVUq4c, VVpuYC=False, VVgAsb=VVgAsb)
  if err:
   self.close()
  iptvRefList = self.VVVu03()
  tList = []
  for fName, fType in CCnBmO.VVTWV5(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVAvkb:
    if fName in VVAvkb:
     chName, sat, inDB = VVAvkb.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVVe3U:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVIGQ9  and chName         : isAdd = True
   elif mode == self.VV7l0P and not chName        : isAdd = True
   elif mode == self.VVFere  and fType == 0        : isAdd = True
   elif mode == self.VVnWOI  and fType == 1        : isAdd = True
   elif mode == self.VVaLRF  and fName in words       : isAdd = True
   elif mode == self.VVZBbC and fName in words       : isAdd = True
   elif mode == self.VVJ6pu  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVCRBG  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVLZKp:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV8nWo:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVneMN:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVWhjq   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FF1lLq(self)
  else:
   self.isBusy = False
   FF1lLq(self, "Not found", 1000)
   return
  self.VVWhjq.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VViHNm()
  self.totalItems = len(self.VVWhjq)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVJO6O(True)
 def VVdmNa(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCnBmO.VVTWV5(self.pPath):
    if fName:
     return True
   if isFirstTime : FFeF28(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF1lLq(self, "Not found", 1000)
  else:
   FFeF28(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVVu03(self):
  VVJpUa = {}
  files  = CCCW9K.VVEC3O()
  if files:
   for path in files:
    txt = FFhqv7(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVJpUa[refCode] = item[1]
  return VVJpUa
 def VV4zLS(self):
  self.VVBKxc()
  f1, f2 = self.VVuRsD()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVWhjq[ndx]
   fName = self.VVWhjq[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCU3LA.VV4fhS(pic, path) : color = VV1udq if inDB else ""
   elif not chName           : color = ""
   else             : color = VVHksW
   self.VVVTYR(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVcA0S(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV5ZML():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVUVAh")
 @staticmethod
 def VVyGUy():
  VVGuvj = []
  VVGuvj.append(("Find SymLinks (to PIcon Directory)"   , "VVdSYr"  ))
  VVGuvj.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVGuvj.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVGuvj
 @staticmethod
 def VVUVAh(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF)
  png, path = CCnBmO.VVFPhh(refCode)
  if path : CCnBmO.VVbHLl(SELF, png, path)
  else : FFeF28(SELF, "No PIcon found for current channel in:\n\n%s" % CCnBmO.VVYQsq())
 @staticmethod
 def VVdSYr(SELF):
  if VVc1MO:
   sed1 = FFlTM0("->", VVc1MO)
   sed2 = FFlTM0("picon", VVEkv6)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVHksW, VViU6E)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFbHAT(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFOG94(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVVExi(SELF, isPIcon):
  sed1 = FFlTM0("->", VVHksW)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFlTM0("picon", VVEkv6)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFbHAT(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFOG94(), grep, sed1, sed2))
 @staticmethod
 def VVbHLl(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFlTM0("%s%s" % (dest, png), VV1udq))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFlTM0(errTxt, VVs795))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFjeoA(SELF, cmd)
 @staticmethod
 def VVTWV5(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVYQsq():
  path = CFG.PIconsPath.getValue()
  return FFvBW5(path)
 @staticmethod
 def VVFPhh(refCode, chName=None):
  if FFOXrQ(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFYV5a(refCode)
  allPath, fName, refCodeFile, pList = CCnBmO.VVgrYH(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVPcUO(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCCW9K.VVDY0z():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFWkM4(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVgrYH(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCnBmO.VVYQsq()
   pList = []
   lst = FF2oot(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFWkM4(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFc02K(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCFVx6():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV0ckI  = None
  self.VVElyr = ""
  self.VVN1qi  = noService
  self.VVPLAk = 0
  self.VVfRjl  = noService
  self.VVwqnM = 0
  self.VVXSlJ  = "-"
  self.VVf3LJ = 0
  self.VVZZCn  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVUqwr(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV0ckI = frontEndStatus
     self.VVriPE()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVriPE(self):
  if self.VV0ckI:
   val = self.VV0ckI.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVElyr = "%3.02f dB" % (val / 100.0)
   else         : self.VVElyr = ""
   val = self.VV0ckI.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVPLAk = int(val)
   self.VVN1qi  = "%d%%" % val
   val = self.VV0ckI.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVwqnM = int(val)
   self.VVfRjl  = "%d%%" % val
   val = self.VV0ckI.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVXSlJ  = "%d" % val
   val = int(val * 100 / 500)
   self.VVf3LJ = min(500, val)
   val = self.VV0ckI.get("tuner_locked", 0)
   if val == 1 : self.VVZZCn = "Locked"
   else  : self.VVZZCn = "Not locked"
 def VVEpVd(self)   : return self.VVElyr
 def VVFLNX(self)   : return self.VVN1qi
 def VVu6Sa(self)  : return self.VVPLAk
 def VVvcwD(self)   : return self.VVfRjl
 def VVoKj1(self)  : return self.VVwqnM
 def VVtIUx(self)   : return self.VVXSlJ
 def VVnD0Q(self)  : return self.VVf3LJ
 def VV8SME(self)   : return self.VVZZCn
 def VVzgQf(self) : return self.serviceName
class CCg0iP():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVRjUe(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFU7aI(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VViZ69(self.ORPOS  , mod=1   )
      self.sat2  = self.VViZ69(self.ORPOS  , mod=2   )
      self.freq  = self.VViZ69(self.FREQ  , mod=3   )
      self.sr   = self.VViZ69(self.SR   , mod=4   )
      self.inv  = self.VViZ69(self.INV  , self.D_PIL_INV)
      self.pol  = self.VViZ69(self.POL  , self.D_POL )
      self.fec  = self.VViZ69(self.FEC  , self.D_FEC )
      self.syst  = self.VViZ69(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VViZ69("modulation" , self.D_MOD )
       self.rolof = self.VViZ69("rolloff"  , self.D_ROLOF )
       self.pil = self.VViZ69("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VViZ69("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VViZ69("pls_code"  )
       self.iStId = self.VViZ69("is_id"   )
       self.t2PlId = self.VViZ69("t2mi_plp_id" )
       self.t2PId = self.VViZ69("t2mi_pid"  )
 def VViZ69(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFwZpN(val)
  elif mod == 2   : return FFMVuT(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVPQwG(self, refCode):
  txt = ""
  self.VVRjUe(refCode)
  if self.data:
   def VV1pWY(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV1pWY("System"   , self.syst)
    txt += VV1pWY("Satellite"  , self.sat2)
    txt += VV1pWY("Frequency"  , self.freq)
    txt += VV1pWY("Inversion"  , self.inv)
    txt += VV1pWY("Symbol Rate"  , self.sr)
    txt += VV1pWY("Polarization" , self.pol)
    txt += VV1pWY("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV1pWY("Modulation" , self.mod)
     txt += VV1pWY("Roll-Off" , self.rolof)
     txt += VV1pWY("Pilot"  , self.pil)
     txt += VV1pWY("Input Stream", self.iStId)
     txt += VV1pWY("T2MI PLP ID" , self.t2PlId)
     txt += VV1pWY("T2MI PID" , self.t2PId)
     txt += VV1pWY("PLS Mode" , self.plsMod)
     txt += VV1pWY("PLS Code" , self.plsCod)
   else:
    txt += VV1pWY("System"   , self.txMedia)
    txt += VV1pWY("Frequency"  , self.freq)
  return txt, self.namespace
 def VVuQOk(self, refCode):
  txt = "Transpoder : ?"
  self.VVRjUe(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VV8PWd(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFU7aI(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VViZ69(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VViZ69(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VViZ69(self.SYST, self.D_SYS_S)
     freq = self.VViZ69(self.FREQ , mod=3  )
     if isSat:
      pol = self.VViZ69(self.POL , self.D_POL)
      fec = self.VViZ69(self.FEC , self.D_FEC)
      sr = self.VViZ69(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVkE0D(self, refCode):
  self.data = None
  self.VVRjUe(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCrb0k():
 def __init__(self, VVantF, path, VVHoAX=None, curRowNum=-1):
  self.VVantF  = VVantF
  self.origFile   = path
  self.Title    = "File Editor: " + FFc02K(path)
  self.VVHoAX  = VVHoAX
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FF7Jdu("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FF4idw(self.VVantF, BF(self.VVfzyJ, curRowNum), title="Loading file ...")
  else:
   FFeF28(self.VVantF, "Error while preparing edit!")
 def VVfzyJ(self, curRowNum):
  VVJpUa = self.VVZkGg()
  VVdyRp = ("Save Changes" , self.VVxw72   , [])
  VVrjyr  = ("Edit Line"  , self.VVW7ue    , [])
  VVpxmm = ("Options"  , self.VVeaEy  , [])
  VV1SrQ = ("Line Options" , self.VVef0d   , [])
  VViila = (""    , self.VV8BkE , [])
  VVJlHN = self.VV4MQW
  VV9B40  = self.VV3Xku
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVRYg6  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFBxNx(self.VVantF, None, title=self.Title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, width=1600, height=1000, VVCppa=26, isEditor=True, VVdyRp=VVdyRp, VVrjyr=VVrjyr, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVJlHN=VVJlHN, VV9B40=VV9B40, VViila=VViila, VVOisu=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#05333333", VV5t00="#00303030", VVO2zv="#11331133")
  self.editorTable.VVAGTP(curRowNum)
 def VV3Xku(self, VVgAw8):
  VVgAw8.VVxjoW()
 def VVeaEy(self, VVgAw8, title, txt, colList):
  VVGuvj = []
  VVGuvj.append(("Go to Line Num" , "toLine"))
  VVGuvj.append(("Find & Replace" , "repl"))
  FFSiXW(self.VVantF, self.VVHCGN, VVGuvj=VVGuvj, width=500, title="Options", VVYJYo=True)
 def VVHCGN(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVYRaL()
   elif ref == "repl"  : self.VVqqRQ(title)
 def VVqqRQ(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVrjyr  = ("Change" , BF(self.VVHb6j, title, lst) , [])
  VVdyRp = ("Start" , BF(self.VVznRQ, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVRYg6 = (LEFT   , LEFT  , CENTER)
  FFBxNx(self.VVantF, None, title=title, VVWhjq=lst, header=header, VVRYg6=VVRYg6, VVmQwL=widths, width=1200, VVCppa=30, isEditor=True, VVrjyr=VVrjyr, VVdyRp=VVdyRp, VV9SwC=2
    , VVmEJ8=bg, VVd8a3=bg, VVcGiE=bg, VVh96o="#06224455", VV5t00="#0a303030")
 def VVHb6j(self, Title, lst, VVgAw8, title, txt, colList):
  title = VVgAw8.VVhkzh(0)
  ndx = VVgAw8.VVmG96()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFrwu2(self.VVantF, BF(self.VVaCm9, VVgAw8, ndx), title=title, defaultText=txt, message="New entry")
 def VVaCm9(self, VVgAw8, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FFCRXL(CFG.lastFindRepl_fnd, newTxt)
   else  : FFCRXL(CFG.lastFindRepl_rpl, newTxt)
   VVgAw8.VVzPbQ({1:newTxt, 2:len(newTxt)})
 def VVznRQ(self, Title, VVgAw8, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFhqv7(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFZRvh(self.VVantF, BF(FF4idw, VVgAw8, BF(self.VVW4zL, VVgAw8, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FF1lLq(VVgAw8, "Not found in file !", 1000)
    VVgAw8.VVAGTP(0)
  else:
   FF1lLq(VVgAw8, "Nothing to find", 1000)
 def VVW4zL(self, VVgAw8, fnd, rpl):
  txt = FFhqv7(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVgAw8.cancel()
  self.fileChanged = True
  self.editorTable.VVEafy()
  VVJpUa = self.VVZkGg()
  self.editorTable.VVFDhD(VVJpUa)
 def VVYRaL(self):
  totRows = self.editorTable.VVPGr2()
  lineNum = self.editorTable.VVmG96() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFrwu2(self.VVantF, BF(self.VV3OK9, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VV3OK9(self, lineNum, totRows, VVNyo5):
  if VVNyo5:
   VVNyo5 = VVNyo5.strip()
   if VVNyo5.isdigit():
    num = FFxrfM(int(VVNyo5) - 1, 0, totRows)
    self.editorTable.VVAGTP(num)
    self.lastLineNum = num + 1
   else:
    FF1lLq(self.editorTable, "Incorrect number", 1500)
 def VVef0d(self, VVgAw8, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVgAw8.VVKzij()
  VVGuvj = []
  VVGuvj.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVGuvj.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVxF60"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVArgC:
   VVGuvj.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(  ("Delete Line"         , "deleteLine"   ))
  FFSiXW(self.VVantF, BF(self.VVAZFg, lineNum), VVGuvj=VVGuvj, title="Line Options")
 def VVAZFg(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVHqTV("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVxF60"  : self.VVxF60(lineNum)
   elif item == "copyToClipboard"  : self.VVxe7Y(lineNum)
   elif item == "pasteFromClipboard" : self.VVhInh(lineNum)
   elif item == "deleteLine"   : self.VVHqTV("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VV8BkE(self, VVgAw8, title, txt, colList):
  if   self.insertMode == 1: VVgAw8.VV0qHy()
  elif self.insertMode == 2: VVgAw8.VV0X92()
  self.insertMode = 0
 def VVxF60(self, lineNum):
  if lineNum == self.editorTable.VVKzij():
   self.insertMode = 1
   self.VVHqTV("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVHqTV("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVxe7Y(self, lineNum):
  global VVArgC
  VVArgC = FFGRiq("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVmaQr("Copied to clipboard")
 def VVxw72(self, VVgAw8, title, txt, colList):
  if self.fileChanged:
   if FFtbd7(self.origFile):
    if FF7Jdu("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVgAw8.VVmaQr("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVgAw8.VVxjoW()
    else:
     FFeF28(self.VVantF, "Cannot save file!")
   else:
    FFeF28(self.VVantF, "Cannot create backup copy of original file!")
 def VV4MQW(self, VVgAw8):
  if self.fileChanged:
   FFZRvh(self.VVantF, BF(self.VV05Ts, VVgAw8), "Cancel changes ?")
  else:
   FF7Jdu("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VV05Ts(VVgAw8)
 def VV05Ts(self, VVgAw8):
  VVgAw8.cancel()
  FFOHeU(self.tmpFile)
  if self.VVHoAX:
   self.VVHoAX(self.fileSaved)
 def VVW7ue(self, VVgAw8, title, txt, colList):
  lineNum = int(VVgAw8.VVhkzh(0))
  lineTxt = VVgAw8.VVhkzh(1, isStrip=False)
  message = VViU6E + "ORIGINAL TEXT:\n" + VVE7tQ + lineTxt
  FFrwu2(self.VVantF, BF(self.VVzEMQ, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVzEMQ(self, lineNum, VVNyo5):
  if not VVNyo5 is None:
   if self.editorTable.VVKzij() <= 1:
    self.VVHqTV("echo %s > '%s'" % (VVNyo5, self.tmpFile))
   else:
    self.VVBnh4(lineNum, VVNyo5)
 def VVhInh(self, lineNum):
  if lineNum == self.editorTable.VVKzij() and self.editorTable.VVKzij() == 1:
   self.VVHqTV("echo %s >> '%s'" % (VVArgC, self.tmpFile))
  else:
   self.VVBnh4(lineNum, VVArgC)
 def VVBnh4(self, lineNum, newTxt):
  self.editorTable.VV7K9Z("Saving ...")
  lines = FF8p4l(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVEafy()
  VVJpUa = self.VVZkGg()
  self.editorTable.VVFDhD(VVJpUa)
 def VVHqTV(self, cmd):
  tCons = CC9YTZ()
  tCons.ePopen(cmd, self.VVrDX7)
  self.fileChanged = True
  self.editorTable.VVEafy()
 def VVrDX7(self, result, retval):
  VVJpUa = self.VVZkGg()
  self.editorTable.VVFDhD(VVJpUa)
 def VVZkGg(self):
  if fileExists(self.tmpFile):
   lines = FF8p4l(self.tmpFile)
   VVJpUa = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVJpUa.append((str(ndx), line))
   if not VVJpUa:
    VVJpUa.append((str(1), ""))
   return VVJpUa
  else:
   FFJBL5(self.VVantF, self.tmpFile)
class CCiRFn():
 def __init__(self, callingSELF, VVmEJ8="#22003344", VVd8a3="#22002233"):
  self.callingSELF = callingSELF
  self.VVGuvj  = []
  self.satList  = []
  self.VVmEJ8  = VVmEJ8
  self.VVd8a3   = VVd8a3
 def VVi7C2(self, VVHoAX):
  self.VVGuvj = []
  VVGuvj, VVDi2l = CCiRFn.VVikVa(self.callingSELF, False, True)
  if VVGuvj:
   self.VVGuvj += VVGuvj
   self.VVkkxZ(VVHoAX, VVDi2l)
 def VV2trc(self, mode, VVgAw8, satCol, VVHoAX, inFilterFnc=None):
  VVgAw8.VV7K9Z("Loading Filters ...")
  self.VVGuvj = []
  self.VVGuvj.append(("All Services" , "all"))
  if mode == 1:
   self.VVGuvj.append(VVnek4)
   self.VVGuvj.append(("Parental Control", "parentalControl" ))
   self.VVGuvj.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVGuvj.append(VVnek4)
   self.VVGuvj.append(("Selected Transponder"   , "selectedTP" ))
   self.VVGuvj.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVcJzX(VVgAw8, satCol)
  VVGuvj, VVDi2l = CCiRFn.VVikVa(self.callingSELF, True, False)
  if VVGuvj:
   VVGuvj.insert(0, FFJ9Ko("Custom Words"))
   self.VVGuvj += VVGuvj
  VVgAw8.VVOvTL()
  self.VVkkxZ(VVHoAX, VVDi2l, inFilterFnc)
 def VVhJnM(self, VVGuvj, sats, VVHoAX, inFilterFnc=None):
  self.VVGuvj = VVGuvj
  VVGuvj, VVDi2l = CCiRFn.VVikVa(self.callingSELF, True, False)
  if VVGuvj:
   self.VVGuvj.append(FFJ9Ko("Custom Words"))
   self.VVGuvj += VVGuvj
  self.VVkkxZ(VVHoAX, VVDi2l, inFilterFnc)
 def VVkkxZ(self, VVHoAX, VVDi2l, inFilterFnc=None):
  VVIY0g  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVBLXn = ("Edit Filter"  , BF(self.VVflyV, VVDi2l))
  VVLIPG  = ("Filter Help"  , BF(self.VVQ7o0, VVDi2l))
  FFSiXW(self.callingSELF, BF(self.VV2GyZ, VVHoAX), VVGuvj=self.VVGuvj, title="Select Filter", VVIY0g=VVIY0g, VVBLXn=VVBLXn, VVLIPG=VVLIPG, VVvfDN=True, VVmEJ8=self.VVmEJ8, VVd8a3=self.VVd8a3)
 def VV2GyZ(self, VVHoAX, item):
  if item:
   VVHoAX(item)
 def VVflyV(self, VVDi2l, selectionObj, sel):
  if fileExists(VVDi2l) : CCrb0k(self.callingSELF, VVDi2l, VVHoAX=None)
  else       : FFJBL5(self.callingSELF, VVDi2l)
  selectionObj.cancel()
 def VVQ7o0(self, VVDi2l, selectionObj, sel):
  FF9ePp(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVcJzX(self, VVgAw8, satColNum):
  if not self.satList:
   satList = VVgAw8.VVzb09(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFFBpn(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFJ9Ko("Satellites"))
  if self.VVGuvj:
   self.VVGuvj += self.satList
 @staticmethod
 def VVikVa(SELF, addTag, VVhghQ):
  FFHWr6()
  fileName  = "ajpanel_services_filter"
  VVDi2l = VVmc3z + fileName
  VVGuvj  = []
  if not fileExists(VVDi2l):
   FF7Jdu("cp -f '%s' '%s'" % (VVqXR1 + fileName, VVDi2l))
  fileFound = False
  if fileExists(VVDi2l):
   fileFound = True
   lines = FF8p4l(VVDi2l)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVGuvj.append((line, "__w__" + line))
       else  : VVGuvj.append((line, line))
  if VVhghQ:
   if   not fileFound : FFJBL5(SELF, VVDi2l)
   elif not VVGuvj : FF5LOj(SELF, VVDi2l)
  return VVGuvj, VVDi2l
 @staticmethod
 def VVAtaF(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCwZHL():
 def __init__(self, callingSELF, VVgAw8, addSep=True):
  self.callingSELF = callingSELF
  self.VVgAw8 = VVgAw8
  self.VVGuvj = []
  iMulSel = self.VVgAw8.VVn6p1()
  if iMulSel : self.VVGuvj.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVGuvj.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVgAw8.VVeEeJ()
  self.VVGuvj.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVGuvj.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVGuvj.append(VVnek4)
 def VV71Gx(self, extraMenu, cbFncDict, okFnc=None, onMultiSelFnc=None, width=1000, height=850, VVmEJ8="#22003344", VVd8a3="#22002233"):
  self.VVgAw8.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVGuvj.extend(extraMenu)
  FFSiXW(self.callingSELF, BF(self.VVyYDw, cbFncDict, okFnc), width=width, height=height, title="Options", VVGuvj=self.VVGuvj, VVmEJ8=VVmEJ8, VVd8a3=VVd8a3)
 def VVyYDw(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVgAw8.VVIgTe(True)
   elif item == "MultSelDisab" : self.VVgAw8.VVIgTe(False)
   elif item == "selectAll" : self.VVgAw8.VV8h6J()
   elif item == "unselectAll" : self.VVgAw8.VV48U8()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCGxa6(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVmcEm, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFOUwv(self)
  FFtNax(self["keyRed"]  , "Exit")
  FFtNax(self["keyGreen"]  , "Save")
  FFtNax(self["keyYellow"] , "Refresh")
  FFtNax(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "red" : self.VVbQ6Y  ,
   "green" : self.VVAhXI ,
   "yellow": self.VVWwKn  ,
   "blue" : self.VVCM5V   ,
   "up" : self.VVrXee    ,
   "down" : self.VVraks   ,
   "left" : self.VVUT8S   ,
   "right" : self.VVeKbm   ,
   "cancel": self.VVbQ6Y
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.VVWwKn()
  self.VVmpdP()
  FFimE3(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9y6v)
  except:
   self.timer.callback.append(self.VV9y6v)
  self.timer.start(1000, False)
  self.VV9y6v()
 def onExit(self):
  self.timer.stop()
 def VVbQ6Y(self) : self.close(True)
 def VVaZOm(self) : self.close(False)
 def VVCM5V(self):
  self.session.openWithCallback(self.VVgRrC, BF(CCVL8S))
 def VVgRrC(self, closeAll):
  if closeAll:
   self.close()
 def VV9y6v(self):
  self["curTime"].setText(str(FFrH35(iTime())))
 def VVrXee(self):
  self.VV0TNg(1)
 def VVraks(self):
  self.VV0TNg(-1)
 def VVUT8S(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVmpdP()
 def VVeKbm(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVmpdP()
 def VV0TNg(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVhDjM(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVhDjM(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVhDjM(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVoPgQ(year)):
   days += 1
  return days
 def VVoPgQ(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVmpdP(self):
  for obj in self.list:
   FFBHn2(obj, "#11404040")
  FFBHn2(self.list[self.index], "#11ff8000")
 def VVWwKn(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVAhXI(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC9YTZ()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVamnW)
 def VVamnW(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFDx6X(self, "Nothing returned from the system!")
  else    : FFDx6X(self, str(result))
class CCVL8S(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VViGuf, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFOUwv(self, addLabel=True)
  FFtNax(self["keyRed"]  , "Exit")
  FFtNax(self["keyGreen"]  , "Sync")
  FFtNax(self["keyYellow"] , "Refresh")
  FFtNax(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "red" : self.VVbQ6Y   ,
   "green" : self.VVs9AM  ,
   "yellow": self.VVOoKX ,
   "blue" : self.VVvSTS  ,
   "cancel": self.VVbQ6Y
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVLMQ5()
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  FFimE3(self)
  FFJVhm(self.VVTws1)
 def VVTws1(self):
  self.VV48nv()
  self.VVrZOU(False)
 def VVbQ6Y(self)  : self.close(True)
 def VVvSTS(self) : self.close(False)
 def VVLMQ5(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV48nv(self):
  self.VVqwZ7()
  self.VVMsdJ()
  self.VVSZVr()
  self.VVNpq4()
 def VVOoKX(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVLMQ5()
   self.VV48nv()
   FFJVhm(self.VVTws1)
 def VVs9AM(self):
  if len(self["keyGreen"].getText()) > 0:
   FFZRvh(self, self.VV4wrm, "Synchronize with Internet Date/Time ?")
 def VV4wrm(self):
  self.VV48nv()
  FFJVhm(BF(self.VVrZOU, True))
 def VVqwZ7(self)  : self["keyRed"].show()
 def VVCDLY(self)  : self["keyGreen"].show()
 def VVnBbN(self) : self["keyYellow"].show()
 def VV47sk(self)  : self["keyBlue"].show()
 def VVMsdJ(self)  : self["keyGreen"].hide()
 def VVSZVr(self) : self["keyYellow"].hide()
 def VVNpq4(self)  : self["keyBlue"].hide()
 def VVrZOU(self, sync):
  localTime = FFfB6C()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVeDht(server)
   if epoch_time is not None:
    ntpTime = FFrH35(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC9YTZ()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVamnW, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVnBbN()
  self.VV47sk()
  if ok:
   self.VVCDLY()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVamnW(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVrZOU(False)
  except:
   pass
 def VVeDht(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCGRJR.VVeolD():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCRMph(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhwpa(VVrgIQ, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFOUwv(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFJVhm(self.VVhHpI)
 def VVhHpI(self):
  if CCGRJR.VVeolD() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFBHn2(self["myBody"], color)
   FFBHn2(self["myLabel"], color)
  except:
   pass
class CClCF8(Screen):
 VVDwZn = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFpkpy()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFhwpa(VVGno7, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCrIIr(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCrIIr(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCrIIr(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCFVx6()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFOUwv(self, title="Signal")
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.close      ,
   "up"  : self.VVrXee       ,
   "down"  : self.VVraks      ,
   "left"  : self.VVUT8S      ,
   "right"  : self.VVeKbm      ,
   "info"  : self.VVjb9j     ,
   "epg"  : self.VVjb9j     ,
   "menu"  : self.VVhe2i      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVcBvX, -1)  ,
   "next"  : BF(self.VVcBvX, 1)  ,
   "pageUp" : BF(self.VVJJQ2, True) ,
   "chanUp" : BF(self.VVJJQ2, True) ,
   "pageDown" : BF(self.VVJJQ2, False) ,
   "chanDown" : BF(self.VVJJQ2, False) ,
   "0"   : BF(self.VVcBvX, 0)  ,
   "1"   : BF(self.VVDZYz, pos=1) ,
   "2"   : BF(self.VVDZYz, pos=2) ,
   "3"   : BF(self.VVDZYz, pos=3) ,
   "4"   : BF(self.VVDZYz, pos=4) ,
   "5"   : BF(self.VVDZYz, pos=5) ,
   "6"   : BF(self.VVDZYz, pos=6) ,
   "7"   : BF(self.VVDZYz, pos=7) ,
   "8"   : BF(self.VVDZYz, pos=8) ,
   "9"   : BF(self.VVDZYz, pos=9) ,
  }, -1)
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  if not CClCF8.VVDwZn:
   CClCF8.VVDwZn = self
  self.sliderSNR.VVdlWO()
  self.sliderAGC.VVdlWO()
  self.sliderBER.VVdlWO(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVDZYz()
  self.VVpIyD()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVLSYa)
  except:
   self.timer.callback.append(self.VVLSYa)
  self.timer.start(500, False)
 def VVpIyD(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVUqwr(service)
  serviceName = self.tunerInfo.VVzgQf()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  tp = CCg0iP()
  tpTxt, satTxt = tp.VVuQOk(refCode)
  if tpTxt == "?" :
   tpTxt = FF4aCb("NO SIGNAL", VVT2Mp)
  self["myTPInfo"].setText(tpTxt + "  " + FF4aCb(satTxt, VV2Bne))
 def VVLSYa(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVUqwr(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVEpVd())
   self["mySNR"].setText(self.tunerInfo.VVFLNX())
   self["myAGC"].setText(self.tunerInfo.VVvcwD())
   self["myBER"].setText(self.tunerInfo.VVtIUx())
   self.sliderSNR.VVrX8t(self.tunerInfo.VVu6Sa())
   self.sliderAGC.VVrX8t(self.tunerInfo.VVoKj1())
   self.sliderBER.VVrX8t(self.tunerInfo.VVnD0Q())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVrX8t(0)
   self.sliderAGC.VVrX8t(0)
   self.sliderBER.VVrX8t(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
    if state and not state == "Tuned":
     FF1lLq(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVjb9j(self):
  FFw3XJ(self, fncMode=CCM3PM.VVAOjG)
 def VVhe2i(self):
  FF9ePp(self, "_help_signal", "Signal Monitor (Keys)")
 def VVrXee(self)  : self.VVDZYz(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVraks(self) : self.VVDZYz(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVUT8S(self) : self.VVDZYz(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVeKbm(self) : self.VVDZYz(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVDZYz(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFCRXL(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVcBvX(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFxrfM(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFCRXL(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CClCF8.VVDwZn = None
 def VVJJQ2(self, isUp):
  FF1lLq(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVpIyD()
  except:
   pass
class CCrIIr(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVdlWO(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFBHn2(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVqXR1 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFBHn2(self.covObj, self.covColor)
   else:
    FFBHn2(self.covObj, "#00006688")
    self.isColormode = True
  self.VVrX8t(0)
 def VVrX8t(self, val):
  val  = FFxrfM(val, self.minN, self.maxN)
  width = int(FFpwm6(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFxrfM(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCYPVd(Screen):
 VVCXsd    = 0
 VV3Im3 = 1
 VVo8wU = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVHoAX=None, barTheme=VVCXsd, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVqFOs(barTheme)
  self.skin, self.skinParam = FFhwpa(VVwl4G, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVHoAX = VVHoAX
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVoBtV = None
  self.timer   = eTimer()
  self.myThread  = None
  FFOUwv(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VV0Gk9, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.VVszQZ()
  self["myProgBarVal"].setText("0%")
  FFBHn2(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VV3etk()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV3etk)
  except:
   self.timer.callback.append(self.VV3etk)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVhaSh(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV78vS(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVoBtV), self.counter, self.maxValue, catName)
 def VViKgT(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVMLhu(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVDtzG(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVK5Aw(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VV89Ao(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVvANc(self, txt):
  self.newTitle = txt
 def VVzPku(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVoBtV), self.counter, self.maxValue)
  except:
   pass
 def VV5Fzx(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVr8MI(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVJR10(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF1lLq(self, "Cancelling ...")
  self.isCancelled = True
  self.VVmUE9(False)
 def VVmUE9(self, isDone):
  FFJVhm(BF(self.VV5gWp, isDone))
 def VV5gWp(self, isDone):
  if self.VVHoAX:
   self.VVHoAX(isDone, self.VVoBtV, self.counter, self.maxValue, self.isError)
  self.close()
 def VV3etk(self):
  val = FFxrfM(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFpwm6(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVmUE9(True)
 def VVszQZ(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV3Im3, self.VVo8wU):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVqFOs(self, barTheme):
  if   barTheme == self.VV3Im3 : return 0.7
  if   barTheme == self.VVo8wU : return 0.5
  else             : return 1
class CC9YTZ(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVHoAX = {}
  self.commandRunning = False
  self.VVB3L1  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVHoAX, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVHoAX[name] = VVHoAX
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVB3L1:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVLR88, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVLSbF , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVLR88, name))
    self.appContainers[name].appClosed.append(BF(self.VVLSbF , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVLSbF(name, retval)
  return True
 def VVLR88(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF4aCb("[UN-DECODED STRING]", VVT2Mp))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVLSbF(self, name, retval):
  if not self.VVB3L1:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVHoAX[name]:
   self.VVHoAX[name](self.appResults[name], retval)
  del self.VVHoAX[name]
 def VVfIQK(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCtRvx(Screen):
 def __init__(self, session, title="", VVGrGW=None, VVJxg1=False, VVKfF6=False, VVzqJs=False, VVm3Ly=False, VVeOjh=False, VV2mDz=False, VVXyQm=VVfWzW, VVdenE=None, VVxe5A=False, VVRc2Y=None, VVWeeE="", checkNetAccess=False, VVCppa=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFhwpa(VVhNmI, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVCppa, usefixedFont=consFont)
  self.session   = session
  self.VVWeeE = VVWeeE
  FFOUwv(self, addScrollLabel=True)
  self.VVJxg1   = VVJxg1
  self.VVKfF6   = VVKfF6
  self.VVzqJs   = VVzqJs
  self.VVm3Ly  = VVm3Ly
  self.VVeOjh = VVeOjh
  self.VV2mDz = VV2mDz
  self.VVXyQm   = VVXyQm
  self.VVdenE = VVdenE
  self.VVxe5A  = VVxe5A
  self.VVRc2Y  = VVRc2Y
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC9YTZ()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFVLF6()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVGrGW, str):
   self.VVGrGW = [VVGrGW]
  else:
   self.VVGrGW = VVGrGW
  if self.VVzqJs or self.VVm3Ly:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVGrGW.append("echo -e '\n%s\n' %s" % (restartNote, FFlTM0(restartNote, VVc1MO)))
   if self.VVzqJs:
    self.VVGrGW.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVGrGW.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVeOjh:
   FF1lLq(self, "Processing ...")
  self.onLayoutFinish.append(self.VVoF4h)
  self.onClose.append(self.VVH8iD)
 def VVoF4h(self):
  self["myLabel"].VVyzBh(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVWeeE or "Processing ..."))
  if self.VVJxg1:
   self["myLabel"].VV6qAa()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVC3fY()
  else:
   self.VVua9S()
 def VVC3fY(self):
  if CCGRJR.VVeolD():
   self["myLabel"].setText("Processing ...")
   self.VVua9S()
  else:
   self["myLabel"].setText(FF4aCb("\n   No connection to internet!", VVEkv6))
 def VVua9S(self):
  allOK = self.container.ePopen(self.VVGrGW[0], self.VVaJzv, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVaJzv("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV2mDz or self.VVzqJs or self.VVm3Ly:
    self["myLabel"].setText(FFeaY5("STARTED", VVc1MO) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVRc2Y:
   colorWhite = CC3JT1.VVKluA(VViU6E)
   color  = CC3JT1.VVKluA(self.VVRc2Y[0])
   words  = self.VVRc2Y[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVXyQm=self.VVXyQm)
 def VVaJzv(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVGrGW):
   allOK = self.container.ePopen(self.VVGrGW[self.cmdNum], self.VVaJzv, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVaJzv("Cannot connect to Console!", -1)
  else:
   if self.VVeOjh and FFfNhM(self):
    FF1lLq(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV2mDz:
    self["myLabel"].appendText("\n" + FFeaY5("FINISHED", VVc1MO), self.VVXyQm)
   if self.VVJxg1 or self.VVKfF6:
    self["myLabel"].VV6qAa()
   if self.VVdenE is not None:
    self.VVdenE()
   if not retval and self.VVxe5A:
    self.VVH8iD()
 def VVH8iD(self):
  if self.container.VVfIQK():
   self.container.killAll()
class CCiDWr(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVhNmI, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVmc3z + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFGRiq("pwd") or "/home/root"
  self.container   = CC9YTZ()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFOUwv(self, title="Terminal", addScrollLabel=True)
  FFtNax(self["keyRed"] , self.exitBtnText)
  FFtNax(self["keyGreen"] , "OK = History")
  FFtNax(self["keyYellow"], "Menu = Custom Cmds")
  FFtNax(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVwndF ,
   "cancel": self.VVzJPt  ,
   "menu" : self.VVeu5o ,
   "last" : self.VVPPw5  ,
   "next" : self.VVPPw5  ,
   "1"  : self.VVPPw5  ,
   "2"  : self.VVPPw5  ,
   "3"  : self.VVPPw5  ,
   "4"  : self.VVPPw5  ,
   "5"  : self.VVPPw5  ,
   "6"  : self.VVPPw5  ,
   "7"  : self.VVPPw5  ,
   "8"  : self.VVPPw5  ,
   "9"  : self.VVPPw5  ,
   "0"  : self.VVPPw5
  })
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.VV6p17)
 def VVy4Yl(self):
  self["myLabel"].VVyzBh(isResizable=False, outputFileToSave="terminal")
  FFeyAJ(self["keyRed"]  , "#00ff8000")
  FFBHn2(self["keyRed"]  , self.skinParam["titleColor"])
  FFBHn2(self["keyGreen"]  , self.skinParam["titleColor"])
  FFBHn2(self["keyYellow"] , self.skinParam["titleColor"])
  FFBHn2(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVtoRL(FFGRiq("date"), 5)
  result = FFGRiq("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVYlgZ()
  if pathExists(VVmc3z):
   self.VVhgoM()
  else:
   FFeF28(self, 'Cannot access the path:\n\n%s' % VVmc3z)
   self.close()
 def VVhgoM(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVmc3z + "LinuxCommands.lst"
  templPath = VVqXR1 + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FF7Jdu("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFbqSU("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VV6p17(self):
  if self.container.VVfIQK():
   self.container.killAll()
   self.VVtoRL("Process killed\n", 4)
   self.VVYlgZ()
 def VVzJPt(self):
  if self.container.VVfIQK():
   self.VV6p17()
  else:
   FFZRvh(self, self.close, "Exit ?", VV6nGE=False)
 def VVYlgZ(self):
  self.VVtoRL(self.prompt, 1)
  self["keyRed"].hide()
 def VVtoRL(self, txt, mode):
  if   mode == 1 : color = VVc1MO
  elif mode == 2 : color = VVrWwc
  elif mode == 3 : color = VViU6E
  elif mode == 4 : color = VVEkv6
  elif mode == 5 : color = VVE7tQ
  elif mode == 6 : color = VVTjYX
  else   : color = VViU6E
  try:
   self["myLabel"].appendText(FF4aCb(txt, color))
  except:
   pass
 def VVwndF(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVSpyW() == "":
   self.VVahcj("cd /tmp")
   self.VVahcj("ls")
  VVJpUa = []
  if fileExists(self.commandHistoryFile):
   lines  = FF8p4l(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVJpUa.append((str(c), line, str(lNum)))
   self.VV8rJm(VVJpUa, title, self.commandHistoryFile, isHistory=True)
  else:
   FFJBL5(self, self.commandHistoryFile, title=title)
 def VVSpyW(self):
  lastLine = FFGRiq("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVahcj(self, cmd):
  try:
   with open(self.commandHistoryFile, "a") as f:
    f.write("%s\n" % cmd)
  except Exception as e:
   FFeF28(self, str(e))
 def VVeu5o(self, VVgAw8=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF8p4l(self.customCommandsFile)
   VVJpUa = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVJpUa.append((str(c), line, str(lNum)))
   if VVgAw8:
    VVgAw8.VVFDhD(VVJpUa)
    VVgAw8.VVAGTP(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VV8rJm(VVJpUa, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFJBL5(self, self.customCommandsFile, title=title)
 def VV8rJm(self, VVJpUa, title, filePath=None, isHistory=False):
  if VVJpUa:
   VVh96o = "#05333333"
   if isHistory: VVmEJ8 = VVd8a3 = VVcGiE = "#11000020"
   else  : VVmEJ8 = VVd8a3 = VVcGiE = "#06002020"
   VVrjyr   = ("Send"   , BF(self.VVdFm2, isHistory)  , [])
   VVdyRp  = ("Modify & Send" , self.VVVHT2     , [])
   if isHistory:
    VVpxmm = ("Clear History" , self.VVOKdn     , [])
    VV1SrQ = None
    VVGySq = None
   elif filePath:
    VVpxmm = ("Options"  , self.VVT5Vp      , [])
    VV1SrQ = ("Edit File"  , BF(self.VVtk47, filePath) , [])
    VVGySq = (""    , self.VVSRj9     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVRYg6 = (CENTER , LEFT   , CENTER )
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ, VVGySq=VVGySq, lastFindConfigObj=CFG.lastFindTerminal, VVOisu=True, searchCol=1
         , VVmEJ8=VVmEJ8, VVd8a3=VVd8a3, VVcGiE=VVcGiE, VVh96o=VVh96o)
   if not isHistory:
    VVgAw8.VVAGTP(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFZRvh(self, BF(self.VVW4Va, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVSRj9(self, VVgAw8, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FF4aCb("Command:", VV2Bne), colList[1])
  txt += "%s\n%s\n\n" % (FF4aCb("Line %s in File:" % colList[2], VV2Bne), self.customCommandsFile)
  FFPaL6(self, txt, title=title)
 def VVT5Vp(self, VVgAw8, title, txt, colList):
  mSel = CCwZHL(self, VVgAw8)
  VVGuvj = []
  txt1 = "Change Custom Commands File"
  if VVgAw8.VVhXSW:
   VVGuvj.append((txt1, ))
   VVGuvj.append(VVnek4)
   totSel = VVgAw8.VVeEeJ()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FF4aCb(totTxt, VVc1MO) if totSel else totTxt, FFtCOg(totSel))
   VVGuvj.append((txt2, "send") if totSel else (txt2,))
  else:
   VVGuvj.append((txt1, "newFile"))
   VVGuvj.append(VVnek4)
   txt2 = "Send current line"
   VVGuvj.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVW4Va, VVgAw8, txt1)
     , "send" : BF(self.VVdFm2, False, VVgAw8, title, txt2, colList) }
  mSel.VV71Gx(VVGuvj, cbFncDict, okFnc=BF(self.VVfE2a, VVgAw8))
 def VVW4Va(self, VVgAw8, title):
  VVGuvj = []
  for fName in os.listdir(VVmc3z):
   path = os.path.join(VVmc3z, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVGuvj.append((fName, path))
  VVGuvj.sort(key=lambda x: x[0].lower())
  if VVGuvj : FFSiXW(self, BF(self.VVPgvR, VVgAw8, title), VVGuvj=VVGuvj, title=title, minRows=3, VVmEJ8="#11220000", VVd8a3="#11220000")
  else  : FFeF28(self, "No valid files found in:\n\n%s" % VVmc3z, title=title)
 def VVPgvR(self, VVgAw8, title, path=None):
  if path:
   if CCZHbk.VVdHnF(path):
    FFeF28(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF8p4l(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFCRXL(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFCRXL(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVeu5o(VVgAw8)
      break
    else:
     FFeF28(self, "File is empty:\n\n%s" % path, title=title)
 def VVfE2a(self, VVgAw8):
  if VVgAw8.VVhXSW : VVgAw8.VVxjoW()
  else        : VVgAw8.VVEafy()
 def VVdFm2(self, isHistory, VVgAw8, title, txt, colList):
  if VVgAw8.VVhXSW:
   lst = VVgAw8.VVqz25(1)
   curNdx = VVgAw8.VVRrCX()
  else:
   lst = [colList[1]]
   curNdx = VVgAw8.VVmG96()
  if not isHistory:
   FFCRXL(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVgAw8.cancel()
  FFJVhm(self.VVF8ko)
 def VVF8ko(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVtoRL("\n%s\n" % cmd, 6)
    self.VVtoRL(self.prompt, 1)
    self.VVF8ko()
   else:
    self.VV2sNE(cmd)
 def VV2sNE(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVtoRL(cmd, 2)
   self.VVtoRL("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVtoRL(ch, 0)
   self.VVtoRL("\nor\n", 4)
   self.VVtoRL("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVYlgZ()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF4aCb(parts[0].strip(), VVrWwc)
    right = FF4aCb("#" + parts[1].strip(), VVTjYX)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVtoRL(txt, 2)
   lastLine = self.VVSpyW()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVahcj(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVaJzv, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFeF28(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVtoRL(data, 3)
 def VVaJzv(self, data, retval):
  if not retval == 0:
   self.VVtoRL("Exit Code : %d\n" % retval, 4)
  self.VVYlgZ()
  if self.commandsList:
   self.VVF8ko()
 def VVVHT2(self, VVgAw8, title, txt, colList):
  if VVgAw8.VVaqZ9():
   cmd = colList[1]
   self.VVyDlj(VVgAw8, cmd)
 def VVOKdn(self, VVgAw8, title, txt, colList):
  FFZRvh(self, BF(self.VVuEiu, VVgAw8), "Reset History File ?", title="Command History")
 def VVuEiu(self, VVgAw8):
  FFbqSU("> '%s'" % self.commandHistoryFile)
  VVgAw8.cancel()
 def VVtk47(self, filePath, VVgAw8, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCrb0k(self, filePath, VVHoAX=BF(self.VVmcUY, VVgAw8), curRowNum=rowNum)
  else     : FFJBL5(self, filePath)
 def VVmcUY(self, VVgAw8, fileChanged):
  if fileChanged:
   VVgAw8.cancel()
   FFJVhm(self.VVeu5o)
 def VVPPw5(self):
  self.VVyDlj(None, self.lastCommand)
 def VVyDlj(self, VVgAw8, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFrwu2(self, BF(self.VVAO0s, VVgAw8), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVAO0s(self, VVgAw8, cmd):
  if cmd and len(cmd) > 0:
   self.VV2sNE(cmd)
   if VVgAw8:
    VVgAw8.cancel()
class CCjeSO(Screen):
 def __init__(self, session, title="", message="", VVXyQm=VVfWzW, width=1400, height=900, VVtq78=False, titleBg="#22002020", VVcGiE="#22001122", VVCppa=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFhwpa(VVhNmI, width, height, titleFontSize, 30, 20, titleBg, VVcGiE, VVCppa)
  self.session   = session
  FFOUwv(self, title, addScrollLabel=True)
  self.VVXyQm   = VVXyQm
  self.VVtq78   = VVtq78
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self["myLabel"].VVyzBh(VVtq78=self.VVtq78, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVXyQm)
  self["myLabel"].VV6qAa()
class CCOTJy(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFhwpa(VVHLad, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFOUwv(self, " ", addCloser=True)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  CCJ2zH.VVwfPO(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCpY0X(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFhwpa(VVFK3X, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFOUwv(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFc3Lk(self["errPic"], "err")
class CCWtTA(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFhwpa(VVHLad, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFOUwv(self, " ", addCloser=True)
class CCJ2zH():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCJ2zH.VVaSqo(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VV7Ska)
  except: self.timer.callback.append(self.VV7Ska)
  self.timer.start(timeout, True)
 def VV7Ska(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVaSqo(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCWtTA, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFlS3X(win["myWinTitle"], shadColor, shadW)
  CCJ2zH.VVwfPO(win, txt)
  return win
 @staticmethod
 def VVwfPO(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCATpC():
 VVXt7U    = 0
 VVmmtZ  = 1
 VVhRMq   = ""
 VVvyHy    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVgAw8   = None
  self.timer     = eTimer()
  self.VVpibK   = 0
  self.VVIgil  = 1
  self.VVIhxr  = 2
  self.VVJzsS   = 3
  self.VVd3Md   = 4
  VVJpUa = self.VVRF9T()
  if VVJpUa:
   self.VVgAw8 = self.VVRM9V(VVJpUa)
  if not VVJpUa and mode == self.VVXt7U:
   self.VVRGGb("Download list is empty !")
   self.cancel()
  if mode == self.VVmmtZ:
   FF4idw(self.VVgAw8 or self.SELF, BF(self.VV2tpP, startDnld, decodedUrl), title="Checking Server ...")
  self.VVWn6H(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVWn6H)
  except:
   self.timer.callback.append(self.VVWn6H)
  self.timer.start(1000, False)
 def VVRM9V(self, VVJpUa):
  VVJpUa.sort(key=lambda x: int(x[0]))
  VVJlHN = self.VVCZcU
  VVrjyr  = ("Play"  , self.VVv2Tb , [])
  VVGySq = (""   , self.VVVXug  , [])
  VVFkw1 = ("Stop"  , self.VVZvZK  , [])
  VVdyRp = ("Resume"  , self.VVAZb4 , [])
  VVpxmm = ("Options" , self.VVE023  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVRYg6  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFBxNx(self.SELF, None, title=self.Title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVrjyr=VVrjyr, VVGySq=VVGySq, VVJlHN=VVJlHN, VVFkw1=VVFkw1, VVdyRp=VVdyRp, VVpxmm=VVpxmm, lastFindConfigObj=CFG.lastFindIptv, VVmEJ8="#11220022", VVd8a3="#11110011", VVcGiE="#11110011", VVh96o="#00223025", VV5t00="#0a333333", VVO2zv="#0a400040", VVOisu=True, searchCol=1)
 def VVRF9T(self):
  lines = CCATpC.VVpEk3()
  VVJpUa = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VViVCP(decodedUrl)
      if fName:
       if   FFIC9i(decodedUrl) : sType = "Movie"
       elif FFLnfq(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVA0G5(decodedUrl, fName)
       if size > -1: sizeTxt = CCZHbk.VVi3go(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVJpUa.append((str(len(VVJpUa) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVJpUa
 def VVZFuK(self):
  VVJpUa = self.VVRF9T()
  if VVJpUa:
   if self.VVgAw8 : self.VVgAw8.VVFDhD(VVJpUa, VVLMQ5Msg=False)
   else     : self.VVgAw8 = self.VVRM9V(VVJpUa)
  else:
   self.cancel()
 def VVWn6H(self, force=False):
  if self.VVgAw8:
   thrListUrls = self.VV8HOG()
   VVJpUa = []
   changed = False
   for ndx, row in enumerate(self.VVgAw8.VVYgJy()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVpibK
    if m3u8Log:
     percent = CCATpC.VVO1eC(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVJzsS , "%.2f %%" % percent
      else   : flag, progr = self.VVd3Md , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFgx6P(mPath)
     if curSize > -1:
      fSize = CCZHbk.VVi3go(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCZHbk.VVi3go(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFgx6P(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVJzsS , "%.2f %%" % percent
       else   : flag, progr = self.VVd3Md , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCZHbk.VVi3go(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVIhxr
     if m3u8Log :
      if not speed and not force : flag = self.VVIgil
      elif curSize == -1   : self.VVk4To(False)
    elif flag == self.VVpibK  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVpibK  : color2 = "#f#00555555#"
    elif flag == self.VVIgil : color2 = "#f#0000FFFF#"
    elif flag == self.VVIhxr : color2 = "#f#0000FFFF#"
    elif flag == self.VVJzsS  : color2 = "#f#00FF8000#"
    elif flag == self.VVd3Md  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVRR8r(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVJpUa.append(row)
   if changed or force:
    self.VVgAw8.VVFDhD(VVJpUa, VVLMQ5Msg=False)
 def VVRR8r(self, flag):
  tDict = self.VVg2NG()
  return tDict.get(flag, "?")
 def VVUTPw(self, state):
  for flag, txt in self.VVg2NG().items():
   if txt == state:
    return flag
  return -1
 def VVg2NG(self):
  return { self.VVpibK: "Not started", self.VVIgil: "Connecting", self.VVIhxr: "Downloading", self.VVJzsS: "Stopped", self.VVd3Md: "Completed" }
 def VVdIrS(self, title):
  colList = self.VVgAw8.VVi9QZ()
  path = colList[6]
  url  = colList[8]
  if self.VVbuh7() : self.VVRGGb("Cannot delete !\n\nFile is downloading.")
  else      : FFZRvh(self.SELF, BF(self.VVQNvz, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVQNvz(self, path, url):
  m3u8Log = self.VVgAw8.VVi9QZ()[12]
  if m3u8Log : FF7Jdu("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FF7Jdu("rm -rf '%s'" % path)
  self.VVWPYh(False)
  self.VVZFuK()
 def VVWPYh(self, VVhghQ=True):
  if self.VVbuh7():
   FF1lLq(self.VVgAw8, self.VVRR8r(self.VVIhxr), 500)
  else:
   colList  = self.VVgAw8.VVi9QZ()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVUTPw(state) in (self.VVpibK, self.VVd3Md, self.VVJzsS):
    lines = CCATpC.VVpEk3()
    newLines = []
    found = False
    for line in lines:
     if CCATpC.VVpiW8(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVvKHu(newLines)
     self.VVZFuK()
     FF1lLq(self.VVgAw8, "Removed.", 1000)
    else:
     FF1lLq(self.VVgAw8, "Not found.", 1000)
   elif VVhghQ:
    self.VVRGGb("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVHqSq(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFZRvh(self.SELF, BF(self.VV3kqn, flag), ques, title=title)
 def VV3kqn(self, flag):
  list = []
  for ndx, row in enumerate(self.VVgAw8.VVYgJy()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVUTPw(state)
   if   flag == flagVal == self.VVd3Md: list.append(decodedUrl)
   elif flag == flagVal == self.VVpibK : list.append(decodedUrl)
  lines = CCATpC.VVpEk3()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVvKHu(newLines)
   self.VVZFuK()
   FF1lLq(self.VVgAw8, "%d removed." % totRem, 1000)
  else:
   FF1lLq(self.VVgAw8, "Not found.", 1000)
 def VVP2UR(self):
  colList  = self.VVgAw8.VVi9QZ()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF1lLq(self.VVgAw8, "Poster exists", 1500)
  else    : FF4idw(self.VVgAw8, BF(self.VVw32K, decodedUrl, path, png), title="Checking Server ...")
 def VVw32K(self, decodedUrl, path, png):
  err = self.VVUDGz(decodedUrl, path, png)
  if err:
   FFeF28(self.SELF, err, title="Poster Download")
 def VVUDGz(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCqssj.VVHmzS(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCW9K.VVxp5A(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCCW9K.VVoNAp(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFl4UT(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FF7Jdu("mv -f '%s' '%s'" % (tPath, png))
   CCKpZj.VVAgYH(self.SELF, VVPWSw=png, showGrnMsg="Downloaded")
   return ""
 def VVVXug(self, VVgAw8, title, txt, colList):
  def VV5Sg6(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV1pWY(key, val) : return "\n%s:\n%s\n" % (FF4aCb(key, VV2Bne), val.strip())
  heads  = self.VVgAw8.VVXWkC()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV5Sg6(heads[i]  , CCZHbk.VVi3go(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV5Sg6("Downloaded" , CCZHbk.VVi3go(int(curSize), mode=0))
   else:
    txt += VV5Sg6(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV1pWY(heads[i], colList[i])
  FFPaL6(self.SELF, txt, title=title)
 def VVv2Tb(self, VVgAw8, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCZHbk.VVrMz7(self.SELF, path)
  else    : FF1lLq(self.VVgAw8, "File not found", 1000)
 def VVCZcU(self, VVgAw8):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVgAw8:
   self.VVgAw8.cancel()
  del self
 def VVE023(self, VVgAw8, title, txt, colList):
  c1, c2, c3 = VVwWfr, VVEkv6, VV2Bne
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVGuvj = []
  VVGuvj.append((c1 + "Remove current row"       , "VVWPYh" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVGuvj.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Delete the file (and remove from list)"  , "VVdIrS"))
  VVGuvj.append(VVnek4)
  VVGuvj.append((resumeTxt + " Auto Resume"       , "VVEFXK" ))
  VVGuvj.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVGuvj.append(VVnek4)
  cond = FFIC9i(decodedUrl)
  VVGuvj.append(FFUHeM("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVP2UR", cond, c3))
  VVGuvj.append(FFUHeM("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFSiXW(self.SELF, BF(self.VV30ps, VVgAw8), VVGuvj=VVGuvj, title=self.Title, VVYJYo=True, width=800, VVvfDN=True, VVmEJ8="#1a001122", VVd8a3="#1a001122")
 def VV30ps(self, VVgAw8, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVWPYh"  : self.VVWPYh()
   elif ref == "remFinished"   : self.VVHqSq(self.VVd3Md, txt)
   elif ref == "remPending"   : self.VVHqSq(self.VVpibK, txt)
   elif ref == "VVdIrS" : self.VVdIrS(txt)
   elif ref == "VVP2UR"  : self.VVP2UR()
   elif ref == "VVEFXK"  : FFCRXL(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFCRXL(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCZHbk, mode=CCZHbk.VV2MPO, jumpToFile=path)
    else    : FF1lLq(VVgAw8, "Path not found !", 1500)
 def VV2tpP(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCqssj.VVHmzS(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVRGGb("Could not get download link !\n\nTry again later.")
     return
  for line in CCATpC.VVpEk3():
   if CCATpC.VVpiW8(decodedUrl, line):
    if self.VVgAw8:
     self.VV2SaW(decodedUrl)
     FFJVhm(BF(FF1lLq, self.VVgAw8, "Already listed !", 2000))
    break
  else:
   params = self.VVimmQ(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVRGGb(params[0])
   elif len(params) == 2:
    FFZRvh(self.SELF, BF(self.VVtTvF, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCZHbk.VVi3go(fSize)
    FFZRvh(self.SELF, BF(self.VV3gyl, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV3gyl(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCATpC.VViodH(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVZFuK()
  if self.VVgAw8:
   self.VVgAw8.VV0X92()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCATpC.VVvyHy, path, decodedUrl)
   self.VVaLlX(threadName, url, decodedUrl, path, resp)
 def VV2SaW(self, decodedUrl):
  if self.VVgAw8:
   for ndx, row in enumerate(self.VVgAw8.VVYgJy()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVgAw8:
     self.VVgAw8.VVAGTP(ndx)
     break
 def VVimmQ(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VViVCP(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVA0G5(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCqssj.VVHmzS(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCqssj.VVrEVj()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCATpC.VVd9Yv(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCATpC.VVe4Jn(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVtTvF(self, resp, decodedUrl):
  if not FFGbNH("ffmpeg"):
   FFZRvh(self.SELF, BF(CCCW9K.VVuecr, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VViVCP(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVsQRm(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFZRvh(self.SELF, BF(self.VVO2xe, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVO2xe(rTxt, rUrl)
  else:
   self.VVRGGb("Cannot process m3u8 file !")
 def VVsQRm(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVGuvj = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCCW9K.VV0BUk(rUrl, fPath)
   VVGuvj.append((resol, fullUrl))
  if VVGuvj:
   FFSiXW(self.SELF, self.VVQfHs, VVGuvj=VVGuvj, title="Resolution", VVYJYo=True, VVvfDN=True)
  else:
   self.VVRGGb("Cannot get Resolutions list from server !")
 def VVQfHs(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFZRvh(self.SELF, BF(FFJVhm, BF(self.VVxsfR, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFJVhm(BF(self.VVxsfR, resolUrl))
 def VVxsfR(self, resolUrl):
  txt, err = CCqssj.VVeU64(resolUrl)
  if err : self.VVRGGb(err)
  else : self.VVO2xe(txt, resolUrl)
 def VV4834(self, logF, decodedUrl):
  found = False
  lines = CCATpC.VVpEk3()
  with open(CCATpC.VViodH(), "w") as f:
   for line in lines:
    if CCATpC.VVpiW8(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCATpC.VViodH(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVZFuK()
  if self.VVgAw8:
   self.VVgAw8.VV0X92()
 def VVO2xe(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCCW9K.VV0BUk(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVRGGb("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV4834(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFTMeZ("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCATpC.VVvyHy, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVO1eC(dnldLog):
  if fileExists(dnldLog):
   dur = CCATpC.VV5B8p(dnldLog)
   if dur > -1:
    tim = CCATpC.VVIQQ5(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VV5B8p(dnldLog):
  lines = FFkrzQ("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVIQQ5(dnldLog):
  lines = FFkrzQ("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVA0G5(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFLnfq(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FF7Jdu("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVaLlX(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVgAw8.VVi9QZ()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVhNHc, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVhNHc(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVhRMq == path:
       break
     else:
      break
  except:
   return
  if CCATpC.VVhRMq:
   CCATpC.VVhRMq = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFgx6P(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVimmQ(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVhNHc(url, decodedUrl, path, resp, totFileSize, True)
 def VVZvZK(self, VVgAw8, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVnfbL() : FF1lLq(self.VVgAw8, self.VVRR8r(self.VVd3Md), 500)
  elif not self.VVbuh7() : FF1lLq(self.VVgAw8, self.VVRR8r(self.VVJzsS), 500)
  elif m3u8Log      : FFZRvh(self.SELF, self.VVk4To, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VV8HOG():
    CCATpC.VVhRMq = colList[6]
    FF1lLq(self.VVgAw8, "Stopping ...", 1000)
   else:
    FF1lLq(self.VVgAw8, "Stopped", 500)
 def VVk4To(self, withMsg=True):
  if withMsg:
   FF1lLq(self.VVgAw8, "Stopping ...", 1000)
  FF7Jdu("killall -INT ffmpeg")
 def VVAZb4(self, *args):
  if   self.VVnfbL() : FF1lLq(self.VVgAw8, self.VVRR8r(self.VVd3Md) , 500)
  elif self.VVbuh7() : FF1lLq(self.VVgAw8, self.VVRR8r(self.VVIhxr), 500)
  else:
   resume = False
   m3u8Log = self.VVgAw8.VVi9QZ()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFZRvh(self.SELF, BF(self.VVimez, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVBz3o():
    resume = True
   if resume: FF4idw(self.VVgAw8, BF(self.VVKJuS), title="Checking Server ...")
   else  : FF1lLq(self.VVgAw8, "Cannot resume !", 500)
 def VVimez(self, m3u8Log):
  FF7Jdu("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FF4idw(self.VVgAw8, BF(self.VVKJuS), title="Checking Server ...")
 def VVKJuS(self):
  colList  = self.VVgAw8.VVi9QZ()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCqssj.VVHmzS(decodedUrl)
   if url:
    decodedUrl = self.VVGEvQ(decodedUrl, url)
   else:
    self.VVRGGb("Could not get download link !\n\nTry again later.")
    return
  curSize = FFgx6P(path)
  params = self.VVimmQ(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVRGGb(params[0])
   return
  elif len(params) == 2:
   self.VVtTvF(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVGEvQ(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCATpC.VVvyHy, path, decodedUrl)
  if resumable: self.VVaLlX(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVRGGb("Cannot resume from server !")
 def VViVCP(self, decodedUrl):
  fileExt = CCCW9K.VVvImY(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFoDQS(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVRGGb(self, txt):
  FFeF28(self.SELF, txt, title=self.Title)
 def VV8HOG(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCATpC.VVvyHy, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVbuh7(self):
  decodedUrl = self.VVgAw8.VVi9QZ()[9]
  return decodedUrl in self.VV8HOG()
 def VVnfbL(self):
  colList = self.VVgAw8.VVi9QZ()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFgx6P(path)) == size
 def VVBz3o(self):
  colList = self.VVgAw8.VVi9QZ()
  path = colList[6]
  size = int(colList[7])
  curSize = FFgx6P(path)
  if curSize > -1:
   size -= curSize
  err = CCATpC.VVe4Jn(size)
  if err:
   FFeF28(self.SELF, err, title=self.Title)
   return False
  return True
 def VVvKHu(self, list):
  with open(CCATpC.VViodH(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVGEvQ(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCATpC.VVpEk3()
  url = decodedUrl
  with open(CCATpC.VViodH(), "w") as f:
   for line in lines:
    if CCATpC.VVpiW8(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVZFuK()
  return url
 @staticmethod
 def VVpEk3():
  list = []
  if fileExists(CCATpC.VViodH()):
   for line in FF8p4l(CCATpC.VViodH()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVpiW8(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVe4Jn(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCZHbk.VV0ZbU(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCZHbk.VVi3go(size), CCZHbk.VVi3go(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVj0mm(SELF):
  tot = CCATpC.VVpx3A()
  if tot:
   FFeF28(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVpx3A():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCATpC.VVvyHy):
    c += 1
  return c
 @staticmethod
 def VVdL1g():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCATpC.VVvyHy, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVbPjj():
  return len(CCATpC.VVpEk3()) == 0
 @staticmethod
 def VV7mqE():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVkBht():
  mPoints = CCATpC.VV7mqE()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FF7Jdu("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VViodH():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVjqqb(SELF, waitMsgObj=None):
  FF4idw(waitMsgObj or SELF, BF(CCATpC.VVitgG, SELF, CCATpC.VVXt7U))
 @staticmethod
 def VVxoVU(SELF):
  CCATpC.VVitgG(SELF, CCATpC.VVmmtZ, startDnld=True)
 @staticmethod
 def VV8QKh(SELF, url):
  CCATpC.VVitgG(SELF, CCATpC.VVmmtZ, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVJdBa(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF)
  added, skipped = CCATpC.VVeTCV([decodedUrl])
  FF1lLq(SELF, "Added", 1000)
 @staticmethod
 def VVeTCV(list):
  added = skipped = 0
  for line in CCATpC.VVpEk3():
   for ndx, url in enumerate(list):
    if url and CCATpC.VVpiW8(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCATpC.VViodH(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVitgG(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCYF5X.VVXK5R(SELF):
   return
  if mode == CCATpC.VVXt7U and CCATpC.VVbPjj():
   FFeF28(SELF, "Download list is empty !", title=title)
  else:
   inst = CCATpC(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVd9Yv(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCP76G(Screen, CCtvHX):
 VVOb7V = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFhwpa(VV7USz, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCtvHX.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFOUwv(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVdsdY())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.VVTQe0       ,
   "info"  : self.VVjb9j      ,
   "epg"  : self.VVjb9j      ,
   "menu"  : self.VVjuF8     ,
   "cancel" : self.cancel       ,
   "red"  : self.VV84iM   ,
   "green"  : self.VV7zr7  ,
   "blue"  : self.VV7XtA      ,
   "yellow" : self.VVI2gt ,
   "left"  : BF(self.VV4K0N, -1)    ,
   "right"  : BF(self.VV4K0N,  1)    ,
   "play"  : self.VV7mbG      ,
   "pause"  : self.VV7mbG      ,
   "playPause" : self.VV7mbG      ,
   "stop"  : self.VV7mbG      ,
   "rewind" : self.VVCPRH      ,
   "forward" : self.VVrwny      ,
   "rewindDm" : self.VVCPRH      ,
   "forwardDm" : self.VVrwny      ,
   "last"  : self.VVjax2      ,
   "next"  : self.VVWviq      ,
   "pageUp" : BF(self.VV61Ea, True)  ,
   "pageDown" : BF(self.VV61Ea, False)  ,
   "chanUp" : BF(self.VV61Ea, True)  ,
   "chanDown" : BF(self.VV61Ea, False)  ,
   "up"  : BF(self.VV61Ea, True)  ,
   "down"  : BF(self.VV61Ea, False)  ,
   "audio"  : BF(self.VVg9Z8, True)  ,
   "subtitle" : BF(self.VVg9Z8, False)  ,
   "text"  : self.VVKzwc  ,
   "0"   : BF(self.VVf9B5 , 10)   ,
   "1"   : BF(self.VVf9B5 , 1)   ,
   "2"   : BF(self.VVf9B5 , 2)   ,
   "3"   : BF(self.VVf9B5 , 3)   ,
   "4"   : BF(self.VVf9B5 , 4)   ,
   "5"   : BF(self.VVf9B5 , 5)   ,
   "6"   : BF(self.VVf9B5 , 6)   ,
   "7"   : BF(self.VVf9B5 , 7)   ,
   "8"   : BF(self.VVf9B5 , 8)   ,
   "9"   : BF(self.VVf9B5 , 9)
  }, -1)
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  if not CCP76G.VVOb7V:
   CCP76G.VVOb7V = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFc3Lk(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFc3Lk(self["myPlayRpt"], "rpt")
  self.VV4uH2()
  self.instance.move(ePoint(40, 40))
  self.VVNQuN(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV7ALG)
  except:
   self.timer.callback.append(self.VV7ALG)
  self.timer.start(250, False)
  self.VV7ALG("Checking ...")
  if not bool(self.iptvTableParams):
   self.VV6Z8l()
 def VV7zr7(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  self.lastSubtitle = CCHdbR.VVcnDx()
  if "chCode" in iptvRef:
   if CCYF5X.VVXK5R(self):
    self.VV6Z8l(True)
  else:
   self.VV7ALG("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VV4uH2(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVX4Rc()
  chName = FFWkM4(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVT2Mp + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFBHn2(self["myTitle"], tColor)
  FFBHn2(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFBHn2(self["myPlay%s" % item], tColor)
  picFile = ""
  if not iMatch("^\d*:(0:){9}\/.+", refCode):
   picFile = CCM3PM.VVWDNI(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCM3PM.VVnRhL(self)
  cl = CCAJ4M.VVh183(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VV7ALG(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCATpC.VVpx3A()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVX4Rc()
  if evName:
   evName = "    %s    " % FF4aCb(evName, VVE7tQ)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVRqA5():
   FFeyAJ(self["myPlayBlu"], "#00FFFFFF")
   FFBHn2(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFeyAJ(self["myPlayBlu"], "#00FFFF88")
   FFBHn2(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCCW9K.VVtDTH(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVTjYX + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFBHn2(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFxrfM(percVal, 0, 100)
   width = int(FFpwm6(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFBHn2(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFeyAJ(self["myPlayMsg"], "#0000ffff")
   else  : FFeyAJ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFeyAJ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFeyAJ(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV6Me5()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VViauu(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCHdbR.VVj1jR(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVjax2()
  state = self.VVeHtf()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFeyAJ(self["myPlayMsg"], "#0000ff00")
  else     : FFeyAJ(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVX4Rc(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFwQYn(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCM3PM.VVFrTq(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCg0iP()
   tpTxt, satTxt = tp.VVuQOk(refCode)
   self.satInfo_TP = tpTxt + "  " + FF4aCb(satTxt, VVXSg2)
  evName = evNameNext = ""
  evLst = CCTnwS.VV0Kq4(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFhH2c(info, iServiceInformation.sVideoWidth) or -1
   h = FFhH2c(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFhH2c(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCM3PM.VVwRIi(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVj3jD(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFZ4gz(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFZ4gz(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFZ4gz(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVjuF8(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVX4Rc()
  FFIC9iSeries = FFoDQS(decodedUrl)
  VVGuvj = []
  if not "VV7rTR" in globals() and not "VVs06X" in globals():
   VVGuvj.append((VVXSg2 + "IPTV Menu", "iptv"))
   VVGuvj.append(VVnek4)
  if isIptv and not "&end=" in decodedUrl and not FFIC9iSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVGuvj.append((VVXSg2 + "Catchup Programs", "catchup" ))
    VVGuvj.append(VVnek4)
  if refCode:
   c = VVT2Mp
   VVGuvj.append((c + "Stop Current Service"  , "stop"  ))
   VVGuvj.append((c + "Restart Current Service" , "restart"  ))
   VVGuvj.append(FFUHeM("Replay with ..." , "replayWith", not isDvb, c))
   VVGuvj.append(VVnek4)
  if FFIC9iSeries:
   VVGuvj.append((VVXSg2 + "File Size (on server)", "fileSize" ))
   VVGuvj.append(VVnek4)
  if self.enableDownloadMenu:
   c = VVXSg2
   addSep = False
   if isIptv and FFIC9iSeries:
    VVGuvj.append((c + "Start Download"  , "dload_cur" ))
    VVGuvj.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCATpC.VVbPjj():
    VVGuvj.append((VVXSg2 + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVGuvj.append(VVnek4)
  fPath, fDir, fName = CCZHbk.VVuryx(self)
  if fPath:
   c = VVE7n3
   if not "VVdbLU" in globals():
    VVGuvj.append((c + "Open path in File Manager", "VVv1HM"))
   VVGuvj.append((c + "Add to Bouquet"             , "VV2pA3" ))
   VVGuvj.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVdD56"  ))
   VVGuvj.append(VVnek4)
  elif isFtp:
   VVGuvj.append((VV2Bne + "Add FTP Media to Bouquet"     , "VVjdVb"))
  if isDvb:
   VVGuvj.append((VVXSg2 + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVGuvj.append((VV2Bne + "Start Subtitle", "VVJxEb"))
   VVGuvj.append(VVnek4)
  if CFG.playerPos.getValue() : VVGuvj.append(("Move Bar to Bottom" , "botm"))
  else      : VVGuvj.append(("Move Bar to Top" , "top" ))
  VVGuvj.append(("Help", "help"))
  FFSiXW(self, self.VVomqu, VVGuvj=VVGuvj, width=600, title="Options")
 def VVomqu(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVI2gt()
   elif item == "stop"     : self.VVo0Wd(0)
   elif item == "restart"    : self.VVo0Wd(1)
   elif item == "replayWith"   : self.VVWZ82()
   elif item == "fileSize"    : FF4idw(self, BF(CCM3PM.VVxjNe, self), title="Checking Server")
   elif item == "dload_cur"   : CCATpC.VVxoVU(self)
   elif item == "addToDload"   : CCATpC.VVJdBa(self)
   elif item == "dload_stat"   : CCATpC.VVjqqb(self)
   elif item == "VVv1HM" : self.close("close_openInFileMan")
   elif item == "VV2pA3" : self.VV2pA3()
   elif item == "VVjdVb" : self.VVjdVb()
   elif item == "VVJxEb"  : self.VVGRg3()
   elif item == "VVdD56"  : self.VVdD56()
   elif item == "botm"     : self.VVNQuN(0)
   elif item == "top"     : self.VVNQuN(1)
   elif item == "sigMon"    : self.VV84iM()
   elif item == "help"     : FF9ePp(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCP76G.VVOb7V = None
 def VVo0Wd(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VV4uH2()
   elif typ == 1:
    self.VV7ALG("Restarting Service ...")
    FFJVhm(BF(self.VVodIh, serv))
 def VVodIh(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if "&end=" in decodedUrl: BF(self.VV6Z8l, True)
  else     : self.session.nav.playService(serv)
 def VVWZ82(self):
  FFSiXW(self, self.VVWfMB, VVGuvj=CCCW9K.VVUruy(), width=650, title="Select Player", VVmEJ8="#11220000", VVd8a3="#11220000")
 def VVWfMB(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFR64J(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VV7ALG("No active service !")
 def VV2pA3(self):
  fPath, fDir, fName = CCZHbk.VVuryx(self)
  if fPath: picker = CCQrUI(self, self, "Add Current Movie to a Bouquet", BF(self.VVnhYQ, [fPath]))
  else : FF1lLq(self, "Path not found !", 1500)
 def VVnhYQ(self, pathLst):
  return CCQrUI.VVwQPo(pathLst)
 def VVjdVb(self):
  picker = CCQrUI(self, self, "Add FTP Media to Bouquet", self.VVZwCc)
 def VVZwCc(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  return CCQrUI.VVwQPo([origUrl], rType=refCode.split(":", 1)[0])
 def VVdD56(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VV7ALG(txt, highlight=ok)
 def VVNQuN(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFCRXL(CFG.playerPos, pos)
 def VV84iM(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCM3PM.VVFrTq(serv)
   if isDvb: self.close("close_sig")
   else : self.VV7ALG("No Signal for Current Service")
 def VVGRg3(self):
  self.session.openWithCallback(self.VVZp8j, BF(CCHdbR))
 def VVKzwc(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVX4Rc()
   if posTxt and durTxt: self.VVGRg3()
   else    : self.VV7ALG("No duration Info. !")
 def VVZp8j(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VV61Ea(True)
  elif reason == "subtZapDn" : self.VV61Ea(False)
  elif reason == "pause"  : self.VV7mbG()
  elif reason == "audio"  : self.VVg9Z8(True)
  elif reason == "subtitle" : self.VVg9Z8(False)
  elif reason == "rewind"     : self.VVCPRH()
  elif reason == "forward" : self.VVrwny()
  elif reason == "rewindDm" : self.VVCPRH()
  elif reason == "forwardDm" : self.VVrwny()
  else      : txt = reason
  if txt:
   FF1lLq(self, txt, 2000)
 def VVTQe0(self):
  if self.isManualSeek:
   self.VVJE5U()
   self.VViauu(self.manualSeekPts)
  elif self.shown:
   if CCHdbR.VVH99P(self): self.VVGRg3()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVJE5U()
  else    : self.close()
 def VVjb9j(self):
  FFw3XJ(self, fncMode=CCM3PM.VVcWUD)
 def VV7mbG(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VV7ALG("Toggling Play/Pause ...")
 def VVJE5U(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV4K0N(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVRAlF()
   else:
    self.manualSeekSec += direc * self.VVRAlF()
    self.manualSeekSec = FFxrfM(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFpwm6(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFZ4gz(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVf9B5(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVdsdY())
   FFCRXL(CFG.playerJumpMin, self.jumpMinutes)
  self.VV7ALG("Changed Seek Time to : %d%s" % (val, self.VVUwXT()))
 def VVdsdY(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVUwXT())
 def VVUwXT(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVXnlp(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVRAlF(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV6Me5(self):
  if "VVyONK" in globals():
   global VVyONK
   if VVyONK:
    VVyONK = VVyONK[1:-1]
    if len(VVyONK) == 3: VVyONK = ""
    else     : return VVyONK
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV7XtA(self):
  cList = self.VVRqA5()
  if cList:
   VVGuvj = []
   for pts, what in cList:
    txt = FFZ4gz(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVGuvj.append((txt, pts))
   FFSiXW(self, self.VV0RLM, VVGuvj=VVGuvj, title="Cut List")
  else:
   self.VV7ALG("No Cut-List for this channel !")
 def VV0RLM(self, item=None):
  if item:
   self.VViauu(item)
 def VVRqA5(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVrwny(self) : self.VV8QzO(1)
 def VVCPRH(self) : self.VV8QzO(-1)
 def VV8QzO(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVRAlF() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVXnlp())
    self.VV7ALG(txt)
  except:
   self.VV7ALG("Cannot jump")
 def VViauu(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VV7ALG("Changing Time ...")
 def VVjax2(self):
  self.VVo0Wd(1)
  self.VV7ALG("Replaying ...")
  self.VVJE5U()
 def VVWviq(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VV7ALG("Jumping to end ...")
  except:
   pass
 def VVeHtf(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV61Ea(self, isUp):
  if self.enableZapping:
   self.VV7ALG("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVJE5U()
   if self.iptvTableParams:
    FFJVhm(BF(self.VVuDQl, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
    if "/timeshift/" in decodedUrl:
     self.VV7ALG("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVzFA8()
  else:
   self.VV7ALG("Zap Disabled !")
 def VVzFA8(self):
  self.lastPlayPos = 0
  self.VV4uH2()
  self.VV6Z8l()
 def VVuDQl(self, isUp):
  CCCW9K_inatance, VVgAw8, mode = self.iptvTableParams
  if isUp : VVgAw8.VVBi3D()
  else : VVgAw8.VVkbMx()
  colList = VVgAw8.VVi9QZ()
  if mode == "localIptv":
   chName, chUrl = CCCW9K_inatance.VVmmgY(VVgAw8, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCCW9K_inatance.VVuAZs(VVgAw8, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCCW9K_inatance.VVHDBn(mode, VVgAw8, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCCW9K_inatance.VV1haT(mode, VVgAw8, colList)
  else:
   self.VV7ALG("Cannot Zap")
   return
  FF5kbK(self, chUrl, VVCqYJ=False)
  self.VVzFA8()
 def VV6Z8l(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
   if not self.VV3U8u(refCode, chName, decodedUrl, iptvRef):
    return
   self.VV7ALG("Refreshing Portal")
   FFJVhm(self.VVV2FN)
  except:
   pass
 def VVV2FN(self):
  self.restoreLastPlayPos = self.VVGYvI()
 def VVI2gt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
  if not decodedUrl or FFoDQS(decodedUrl):
   self.VV7ALG("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCCW9K.VVIysy(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VV7ALG("Reading Program List ...")
   ok_fnc = BF(self.VVLCZM, refCode, chName, streamId, uHost, uUser, uPass)
   FFJVhm(BF(CCCW9K.VVocf4, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VV7ALG("Cannot process this channel")
 def VVLCZM(self, refCode, chName, streamId, uHost, uUser, uPass, VVgAw8, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVgAw8.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VV7ALG("Changing Program ...")
   FFJVhm(BF(self.VVR2SW, chUrl))
  else:
   self.VV7ALG("Incorrect Timestamp !")
 def VVR2SW(self, chUrl):
  FF5kbK(self, chUrl, VVCqYJ=False)
  self.lastPlayPos = 0
  self.VV4uH2()
 def VVg9Z8(self, isAudio):
  try:
   VVZuLk = InfoBar.instance
   if VVZuLk:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVZuLk)
    else  : self.session.open(SubtitleSelection, VVZuLk)
  except:
   pass
 @staticmethod
 def VVYsSf(session, mode=None):
  if   mode == "close_sig"   : FFF0Cd(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCCW9K)
  elif mode == "close_openInFileMan" : session.open(CCZHbk, gotoMovie=True)
 @staticmethod
 def VVBpiW(session, **kwargs):
  session.openWithCallback(BF(CCP76G.VVYsSf, session), CCP76G, **kwargs)
class CCSI3y(Screen):
 def __init__(self, session, title="", VVrAp2="Continue?", VV6nGE=True, VVnBJJ=False):
  self.skin, self.skinParam = FFhwpa(VVuXUK, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVrAp2 = VVrAp2
  self.VVnBJJ = VVnBJJ
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV6nGE : VVGuvj = [no , yes]
  else   : VVGuvj = [yes, no ]
  FFOUwv(self, title, VVGuvj=VVGuvj, addLabel=True)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok" : self.VVTQe0 ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVrAp2)
  if self.VVnBJJ:
   self["myLabel"].instance.setHAlign(0)
  self.VV5wLy()
  FFMOVh(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFe65p(self["myMenu"])
  FF2oUX(self, self["myMenu"])
 def VVTQe0(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV5wLy(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC0qOq(Screen):
 def __init__(self, session, title="", VVGuvj=None, width=1000, height=850, VVCppa=30, barText="", minRows=1, VVwpVu=None, VVrN3L=None, VV91zg=None, VVIY0g=None, VVBLXn=None, VVLIPG=None, VVYJYo=False, VVvfDN=False, VV51Jr=None, VVTN4d=True, VVmEJ8="#22003344", VVd8a3="#22002233"):
  self.skin, self.skinParam = FFhwpa(VVwa4P, width, height, 50, 40, 30, VVmEJ8, VVd8a3, VVCppa, barHeight=40, topRightBtns=3 if VVrN3L else 0)
  self.session   = session
  self.VVGuvj   = VVGuvj
  self.barText   = barText
  self.minRows   = minRows
  self.VVwpVu   = VVwpVu
  self.VVrN3L   = VVrN3L
  self.VV91zg   = VV91zg
  self.VVIY0g  = VVIY0g
  self.VVBLXn  = ("Delete File", BF(self.VVTAip, VV51Jr)) if not VV51Jr is None else VVBLXn
  self.VVLIPG   = VVLIPG
  self.VVYJYo  = VVYJYo
  self.VVvfDN  = VVvfDN
  self.Title    = title
  FFOUwv(self, title, VVGuvj=VVGuvj)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.VVTQe0    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVrE2g   ,
   "red"  : self.VVXbwO   ,
   "green"  : self.VVfN6X   ,
   "yellow" : self.VVPDgV   ,
   "blue"  : self.VV46BQ   ,
   "pageUp" : self.VVJ5Bs ,
   "chanUp" : self.VVJ5Bs ,
   "pageDown" : self.VVHo0X  ,
   "chanDown" : self.VVHo0X  ,
   "0"   : BF(self.VVnSm0, 0) ,
   "1"   : BF(self.VVnSm0, 1) ,
   "2"   : BF(self.VVnSm0, 2) ,
   "3"   : BF(self.VVnSm0, 3) ,
   "4"   : BF(self.VVnSm0, 4) ,
   "5"   : BF(self.VVnSm0, 5) ,
   "6"   : BF(self.VVnSm0, 6) ,
   "7"   : BF(self.VVnSm0, 7) ,
   "8"   : BF(self.VVnSm0, 8) ,
   "9"   : BF(self.VVnSm0, 9)
  }, -1)
  if VVTN4d:
   FFvOiZ(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFMOVh(self["myMenu"])
  FFMHNW(self, minRows=self.minRows)
  FFRBDi(self)
  self.VVNGvA(self["keyRed"]  , self.VV91zg )
  self.VVNGvA(self["keyGreen"] , self.VVIY0g )
  self.VVNGvA(self["keyYellow"] , self.VVBLXn )
  self.VVNGvA(self["keyBlue"]  , self.VVLIPG )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFimE3(self)
 def VVNGvA(self, btnObj, btnFnc):
  if btnFnc:
   FFtNax(btnObj, btnFnc[0])
 def VVtCZu(self, fnc=None):
  self.VVIY0g = fnc
  if fnc : self.VVNGvA(self["keyGreen"], self.VVIY0g)
  else : self["keyGreen"].hide()
 def VVnSm0(self, digit):
  digit = str(digit)
  VVGuvj = self["myMenu"].list
  for ndx, item in enumerate(VVGuvj):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFWkM4(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVn6An(ndx)
     self.VVTQe0()
     break
 def VVTQe0(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVwpVu:
    self.VVwpVu((self, txt, ref, ndx))
   else:
    if self.VVYJYo: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVrE2g(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVrN3L and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVrN3L(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVXbwO(self)  : self.VVK90L(self.VV91zg)
 def VVfN6X(self) : self.VVK90L(self.VVIY0g)
 def VVPDgV(self) : self.VVK90L(self.VVBLXn)
 def VV46BQ(self) : self.VVK90L(self.VVLIPG)
 def VVK90L(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVvfDN:
    self.cancel()
 def VVTTLJ(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVGuvj = self["myMenu"].list
  VVGuvj.pop(ndx)
  if len(VVGuvj) > 0: self["myMenu"].setList(VVGuvj)
  else    : self.close()
 def VVTAip(self, basePath, menuObj, fName):
  FFZRvh(self, BF(self.VVoDEv, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVoDEv(self, path):
  FFOHeU(path)
  if fileExists(path) : FF1lLq(self, "Not deleted", 1000)
  else    : self.VVTTLJ()
 def VVY1oo(self, VVGuvj):
  if len(VVGuvj) > 0:
   newList = []
   for item in VVGuvj:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFMHNW(self, minRows=self.minRows)
  else:
   self.close("")
 def VVxPHN(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFMHNW(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VV0BTN(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVn6An(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVA9Pf(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVn6An(ndx)
    break
 def VVgve4(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVn6An(ndx)
    break
 def VVJ5Bs(self) : self["myMenu"].moveToIndex(0)
 def VVHo0X(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCaEfF(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVWhjq=None, VVRYg6=None, VVmQwL=None, VVCppa=26, isEditor=False, addSort=True, VVOisu=False, VVAAbT=0, picParams=None, VVrjyr=None, VVGySq=None, menuButtonFnc=None, VVFkw1=None, VVdyRp=None, VVpxmm=None, VV1SrQ=None, VV9B40=None, VViila=None, VVJlHN=None, VVwpP6=-1, VV9SwC=0, searchCol=0, lastFindConfigObj=None, VVmEJ8="#22003344", VVd8a3="#22002233", VVbF3B="#00dddddd", VVcGiE="#11002233", VVSaWg=None, VVh96o="#11111111", borderWidth=1, VV5t00="#0a555555", VVqbj9="#0affffff", VVO2zv="#11552200", VVOZmj="#0055ff55", VVOZmjRev="#0000bbff"):
  self.skin, self.skinParam = FFhwpa(VVmwjm, width, height, 50, 10, vMargin, VVmEJ8, VVd8a3, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFOUwv(self, title)
  self.Title     = title
  self.header     = header
  self.VVWhjq     = VVWhjq
  self.totalCols    = len(VVWhjq[0])
  self.VVAAbT   = VVAAbT
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVOisu   = VVOisu
  self.VVRfsE   = 0.01
  self.VVxAno   = 0.02
  self.VVYDqa = 0.03
  self.VV6uxT  = 1
  self.VVmQwL = VVmQwL
  self.colWidthPixels   = []
  self.VVrjyr   = VVrjyr
  self.OKButtonObj   = None
  self.VVGySq   = VVGySq
  self.VVFkw1   = VVFkw1
  self.VVdyRp   = VVdyRp
  self.VVpxmm  = VVpxmm
  self.VV1SrQ   = VV1SrQ
  self.VV9B40    = VV9B40
  self.VViila   = VViila
  self.tableRefreshCB   = None
  self.VVJlHN  = VVJlHN
  self.menuButtonFnc   = menuButtonFnc
  self.VVwpP6    = VVwpP6
  self.VV9SwC   = VV9SwC
  self.searchCol    = searchCol
  self.VVRYg6    = VVRYg6
  self.keyPressed    = -1
  self.VVCppa    = FFbjGD(VVCppa)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVQSWB    = FFCRJG(self.VVCppa, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVmEJ8    = VVmEJ8
  self.VVd8a3      = VVd8a3
  self.VVbF3B    = FFrS08(VVbF3B)
  self.VVcGiE    = FFrS08(VVcGiE)
  self.VVSaWg    = VVSaWg
  self.VVh96o    = FFrS08(VVh96o)
  self.borderWidth   = borderWidth
  self.VV5t00   = FFrS08(VV5t00)
  self.VVqbj9    = FFrS08(VVqbj9)
  self.VVO2zv    = FFrS08(VVO2zv)
  self.VVOZmj   = FFrS08(VVOZmj)
  self.VVOZmjRev  = FFrS08(VVOZmjRev)
  self.VVhXSW  = False
  self.selectedItems   = 0
  self.VVS3Vy   = FFrS08("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VV9SwC:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VV9SwC == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.VVZuIc  ,
   "red"  : self.VV1rWp  ,
   "green"  : self.VVu0RG ,
   "yellow" : self.VVzT2i ,
   "blue"  : self.VVjBpO  ,
   "menu"  : self.VViesi ,
   "info"  : self.VVIMAf  ,
   "cancel" : self.VVGqhS  ,
   "up"  : self.VVkbMx    ,
   "down"  : self.VVBi3D  ,
   "left"  : self.VVgc5l   ,
   "right"  : self.VVoamW  ,
   "next"  : self.VVJeKm  ,
   "last"  : self.VVfVc9  ,
   "home"  : self.VVt7UP  ,
   "pageUp" : self.VVt7UP  ,
   "chanUp" : self.VVt7UP  ,
   "end"  : self.VV0X92  ,
   "pageDown" : self.VV0X92  ,
   "chanDown" : self.VV0X92
  }, -1)
  FFvOiZ(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  try:
   self.VVVmu9()
  except Exception as e:
   FFeF28(self, str(e), title=self.Title)
   self.close(None)
 def VVVmu9(self):
  FFimE3(self)
  self.VVNGvA(self.VVFkw1 , self["keyRed"])
  self.VVNGvA(self.VVdyRp , self["keyGreen"])
  self.VVNGvA(self.VVpxmm, self["keyYellow"])
  self.VVNGvA(self.VV1SrQ , self["keyBlue"])
  if self.VVrjyr:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVrjyr[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVrjyr[0])
    FFBHn2(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVQSWB)
  self["myTableH"].l.setFont(0, gFont(VVIXst, self.VVCppa))
  self["myTable"].l.setItemHeight(self.VVQSWB)
  self["myTable"].l.setFont(0, gFont(VVIXst, self.VVCppa))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVQSWB)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVQSWB))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVQSWB)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVQSWB
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVQSWB * len(self.VVWhjq) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVmQwL:
   self.VVmQwL = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVmQwL)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVRYg6:
   self.VVRYg6 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVRYg6
   self.VVRYg6 = []
   for item in tmpList:
    self.VVRYg6.append(item | RT_VALIGN_CENTER)
  self.VVLXUn()
  if self.VV9B40:
   self.VV9B40(self)
 def VVNGvA(self, btnFnc, btn):
  if btnFnc : FFtNax(btn, btnFnc[0])
  else  : FFtNax(btn, "")
 def VVkbuJ(self, waitTxt):
  FF4idw(self, self.VVLXUn, title=waitTxt)
 def VVLXUn(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVOZmjRev if self.lastSortModeIsReverese else self.VVOZmj
    self["myTableH"].setList([self.VVboaM(0, self.header, self.VVqbj9, self.VVO2zv, None, self.VVO2zv, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVWhjq):
    self["myTable"].list.append(self.VVboaM(c, row, self.VVbF3B, self.VVcGiE, self.VVSaWg, self.VVh96o, None))
   self.VVWhjq = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVwpP6 > -1:
    self["myTable"].moveToIndex(self.VVwpP6 )
   self.VVVpK7()
   if self.VV9SwC:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVQSWB * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFgPni(self, width, newH)
   if self.VViila:
    self.VVK90L(self.VViila, None)
   if self.tableRefreshCB:
    self.VVK90L(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFeF28(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVboaM(self, keyIndex, columns, VVbF3B, VVcGiE, VVSaWg, VVh96o, VVOZmj):
  row = [keyIndex]
  if VVSaWg:
   VVSaWg = FFrS08(VVSaWg)
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVOZmj and ndx == self.VVAAbT : textColor = VVOZmj
   else           : textColor = VVbF3B
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFrS08(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVcGiE = c
    entry = span.group(3)
   if not self.isEditor and self.VVRYg6[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVQSWB)
           , font   = 0
           , flags   = self.VVRYg6[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVcGiE
           , color_sel  = VVSaWg or textColor
           , backcolor_sel = VVh96o
           , border_width = self.borderWidth
           , border_color = self.VV5t00
           ))
   posX += self.colWidthPixels[ndx]
  if not VVOZmj and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCaEfF.VVVu2y(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVQSWB-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVIMAf(self):
  rowData = self.VVoKRv()
  if rowData:
   title, txt, colList = rowData
   if self.VVGySq:
    fnc  = self.VVGySq[1]
    params = self.VVGySq[2]
    fnc(self, title, txt, colList)
   else:
    FFPaL6(self, txt, title)
 def VVZuIc(self):
  if   self.VVhXSW : self.VVwMVi(self.VVmG96(), mode=2)
  elif self.VVrjyr  : self.VVK90L(self.VVrjyr, None)
  else      : self.VVIMAf()
 def VV1rWp(self) : self.VVK90L(self.VVFkw1 , self["keyRed"])
 def VVu0RG(self) : self.VVK90L(self.VVdyRp , self["keyGreen"])
 def VVzT2i(self): self.VVK90L(self.VVpxmm , self["keyYellow"])
 def VVjBpO(self) : self.VVK90L(self.VV1SrQ , self["keyBlue"])
 def VVK90L(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF1lLq(self, buttonFnc[3])
    FFJVhm(BF(self.VVlUXq, buttonFnc))
   else:
    self.VVlUXq(buttonFnc)
 def VVlUXq(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVoKRv()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVwMVi(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVS3Vy
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVcGiE
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVS3Vy
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVmG96() < len(self["myTable"].list) - 1 : self.VVBi3D()
   else              : self.VVVpK7()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VV8h6J(self)  : FF4idw(self, BF(self.VVHhMB, True ), title="Selecting all ..."  )
 def VV48U8(self) : FF4idw(self, BF(self.VVHhMB, False), title="Unselecting all ...")
 def VVHhMB(self, isSel=True):
  if isSel:
   bg = self.VVS3Vy
   self.selectedItems = len(self["myTable"].list)
   self.VVIgTe(True)
  else:
   bg = self.VVcGiE
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVS3Vy
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVoKRv(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVmQwL[i] > 1 or self.VVmQwL[i] == self.VVRfsE or self.VVmQwL[i] == self.VVYDqa:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVGqhS(self):
  self["myTable"].onSelectionChanged = []
  if self.VVJlHN : self.VVJlHN(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVgH9X(self):
  return self["myTitle"].getText().strip()
 def VVXWkC(self):
  return self.header
 def VVtnNY(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVl1vA(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFeyAJ(self["myBar"], color)
 def VV7K9Z(self, txt):
  FF1lLq(self, txt)
 def VVmaQr(self, txt, Time=1000):
  FF1lLq(self, txt, Time)
 def VVEafy(self): self["keyGreen"].show()
 def VVxjoW(self): self["keyGreen"].hide()
 def VVaqZ9(self): return self["keyGreen"].visible
 def VVOvTL(self):
  FF1lLq(self)
 def VVbjQL(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVKzij(self):
  return len(self["myTable"].list)
 def VVmG96(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVPGr2(self):
  return len(self["myTable"].list)
 def VVIgTe(self, isOn):
  self.VVhXSW = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VV1SrQ: self["keyBlue"].hide()
   if self.VVrjyr and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVmEJ8
   self["keyMenu"].show()
   if self.VV1SrQ: self["keyBlue"].show()
   if self.VVrjyr and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVrjyr[0])
   self.VV48U8()
  FFBHn2(self["myTitle"], color)
  FFBHn2(self["myBar"]  , color)
 def VVn6p1(self):
  return self.VVhXSW
 def VVeEeJ(self):
  return self.selectedItems
 def VV0qHy(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVVpK7()
 def VVLnaC(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVAqiV(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVKzij()
  txt += FFeaY5("Total Unique Items", VVEkv6)
  for i in range(self.totalCols):
   if self.VVmQwL[i - 1] > 1 or self.VVmQwL[i - 1] == self.VVRfsE or self.VVmQwL[i - 1] == self.VVYDqa:
    name, tot = self.VVLnaC(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFPaL6(self, txt)
 def VVhkzh(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVi9QZ(self):
  return self.VVxnif(self["myTable"].l.getCurrentSelectionIndex())
 def VVxnif(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVFDhD(self, newList, newTitle="", VVLMQ5Msg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVtnNY(newTitle)
  if newList:
   self.VVWhjq = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVOisu and self.VVAAbT == 0:
    isNum = True
   else:
    for cols in self.VVWhjq:
     if not FFYFiP(cols[self.VVAAbT]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVWhjq.sort(key=lambda x: int(x[self.VVAAbT])  , reverse=self.lastSortModeIsReverese)
    else : self.VVWhjq.sort(key=lambda x: x[self.VVAAbT].lower() , reverse=self.lastSortModeIsReverese)
   if VVLMQ5Msg : self.VVkbuJ("Refreshing ...")
   else   : self.VVLXUn()
  else:
   FFeF28(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVFU6P(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVboaM(self.VVPGr2(), row, self.VVbF3B, self.VVcGiE, self.VVSaWg, self.VVh96o, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VV0X92()
 def VVGSM2(self):
  self["myTable"].list.pop(self.VVmG96())
  self["myTable"].l.setList(self["myTable"].list)
 def VVtGmM(self, data):
  ndx = self.VVmG96()
  newRow = self.VVboaM(ndx, data, self.VVbF3B, self.VVcGiE, self.VVSaWg, self.VVh96o, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVVpK7()
   return True
  else:
   return False
 def VVzPbQ(self, tDict):
  ndx = self.VVmG96()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVRYg6[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVbrvM()
 def VV9eWy(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVboaM(ndx, data, self.VVbF3B, self.VVcGiE, self.VVSaWg, self.VVh96o, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVbrvM()
 def VVbrvM(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVVpK7()
 def VVzOTd(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVIvlb(self, colNum, textToFind, VVhghQ=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVVpK7()
    break
  else:
   if VVhghQ:
    FF1lLq(self, "Not found", 1000)
 def VVAyL9(self, colDict, VVhghQ=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVVpK7()
    return
  if VVhghQ:
   FF1lLq(self, "Not found", 1000)
  return False
 def VVzb09(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVJMiF(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFYFiP(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVqz25(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVS3Vy:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVRrCX(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVS3Vy:
     return ndx
  return -1
 def VVXyrA(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVS3Vy:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVOTHx(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVS3Vy : return True
  else        : return False
 def VVYgJy(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VViesi(self):
  if self.menuButtonFnc:
   self.VVlUXq(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VV9SwC:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVmG96()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVGuvj1, VVDi2l = CCiRFn.VVikVa(self, False, False)
  VVGuvj = []
  VVGuvj.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVGuvj.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVGuvj.append(("Find ...\t\t%s" % (FF4aCb(txt, VVrWwc) if txt else ""), "findNew"   ))
  VVGuvj.append(itemOf(bool(VVGuvj1)    , "Find (from Filter) ..."   , "filter"   ))
  if self.header:
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Table Statistcis"            , "tableStat"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((FF4aCb("Export Table to .html"     , VVEkv6) , "VVbI6q" ))
  VVGuvj.append((FF4aCb("Export Table to .csv"     , VVEkv6) , "VVBa0Q" ))
  VVGuvj.append((FF4aCb("Export Table to .txt (Tab Separated)", VVEkv6) , "VVPmlJ" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVmQwL[i] > 1 or self.VVmQwL[i] == self.VVxAno:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVGuvj.append(VVnek4)
    if tot == 1 : VVGuvj.append(("Sort", sList[0][1]))
    else  : VVGuvj += sList
  VVLIPG = ("Keys Help", self.FFBxNxHelp)
  FFSiXW(self, self.VVDj0X, VVGuvj=VVGuvj, title=self.VVgH9X(), VVLIPG=VVLIPG)
 def VVDj0X(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVc4b0()
   elif item == "findPrev"  : self.VVc4b0(isPrev=True)
   elif item == "findNew"  : self.VVRZen()
   elif item == "filter"  : self.VVwG38()
   elif item == "tableStat" : self.VVAqiV()
   elif item == "VVbI6q": FF4idw(self, self.VVbI6q, title=title)
   elif item == "VVBa0Q" : FF4idw(self, self.VVBa0Q , title=title)
   elif item == "VVPmlJ" : FF4idw(self, self.VVPmlJ , title=title)
   else:
    if self.VVAAbT == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVAAbT, self.lastSortModeIsReverese = item, False
    if self.VVOisu and self.VVAAbT == 0 or self.VVJMiF(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVLXUn(onlyHeader=True)
 def FFBxNxHelp(self, VVUD8b, path):
  FF9ePp(self, "_help_table", "Table (Keys Help)")
 def VVkbMx(self):
  self["myTable"].up()
  self.VVVpK7()
 def VVBi3D(self):
  self["myTable"].down()
  self.VVVpK7()
 def VVgc5l(self):
  self["myTable"].pageUp()
  self.VVVpK7()
 def VVoamW(self):
  self["myTable"].pageDown()
  self.VVVpK7()
 def VVt7UP(self):
  self["myTable"].moveToIndex(0)
  self.VVVpK7()
 def VV0X92(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVVpK7()
 def VVAGTP(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVVpK7()
 def VVJeKm(self):
  if self.lastFindConfigObj.getValue():
   if self.VVmG96() == len(self["myTable"].list) - 1 : FF1lLq(self, "End reached", 1000)
   else              : self.VVc4b0()
  else:
   FF1lLq(self, 'Set "Find" in Menu', 1500)
 def VVfVc9(self):
  if self.lastFindConfigObj.getValue():
   if self.VVmG96() == 0 : FF1lLq(self, "Top reached", 1000)
   else       : self.VVc4b0(isPrev=True)
  else:
   FF1lLq(self, 'Set "Find" in Menu', 1500)
 def VVHvHP(self, txt):
  FFCRXL(self.lastFindConfigObj, txt)
 def VVRZen(self):
  FFrwu2(self, self.VV0jRh, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VV0jRh(self, VVNyo5):
  if not VVNyo5 is None:
   txt = VVNyo5.strip()
   self.VVHvHP(txt)
   if VVNyo5: self.VVc4b0(reset=True)
   else  : FF1lLq(self, "Nothing to find !", 1500)
 def VVwG38(self):
  VVGuvj, VVDi2l = CCiRFn.VVikVa(self, False, False)
  VVBLXn = ("Edit Filter", BF(self.VVPahc, VVDi2l))
  if VVGuvj : FFSiXW(self, self.VVvkoc, VVGuvj=VVGuvj, VVBLXn=VVBLXn, title="Find from Filter")
  else  : FF1lLq(self, "Filter Error !", 1500)
 def VVvkoc(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVHvHP(txt)
    self.VVc4b0(reset=True)
   else:
    FF1lLq(self, "No entry !", 1500)
 def VVPahc(self, VVDi2l, selectionObj, sel):
  if fileExists(VVDi2l) : CCrb0k(self, VVDi2l, VVHoAX=None)
  else       : FFJBL5(self, VVDi2l)
  selectionObj.cancel()
 def VVc4b0(self, reset=False, isPrev=False):
  curRow = self.VVmG96()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCiRFn.VVAtaF(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVAGTP(i)
      break
    elif any(x in line for x in tupl):
     self.VVAGTP(i)
     break
   else:
    FF1lLq(self, "Not found", 1000)
  else:
   FF1lLq(self, "Check your query", 1500)
 def VVPmlJ(self):
  expFile = self.VVpu3b() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVE5hH()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVxnif(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVmQwL[ndx] > self.VV6uxT or self.VVmQwL[ndx] == self.VVYDqa:
      col = self.VVrx9j(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVhRSE(expFile)
 def VVBa0Q(self):
  expFile = self.VVpu3b() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVE5hH()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVxnif(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVmQwL[ndx] > self.VV6uxT or self.VVmQwL[ndx] == self.VVYDqa:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVrx9j(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVhRSE(expFile)
 def VVbI6q(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVgH9X(), PLUGIN_NAME, VV64TL)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVgH9X()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVE5hH()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVmQwL:
   colgroup += '   <colgroup>'
   for w in self.VVmQwL:
    if w > self.VV6uxT or w == self.VVYDqa:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVpu3b() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVxnif(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVmQwL[ndx] > self.VV6uxT or self.VVmQwL[ndx] == self.VVYDqa:
      col = self.VVrx9j(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVhRSE(expFile)
 def VVE5hH(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVmQwL[ndx] > self.VV6uxT or self.VVmQwL[ndx] == self.VVYDqa:
     newRow.append(col.strip())
  return newRow
 def VVrx9j(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFWkM4(col)
 def VVpu3b(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVgH9X())
  fileName = fileName.replace("__", "_")
  path  = FFvBW5(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFguCY()
  return expFile
 def VVhRSE(self, expFile):
  FFDx6X(self, "File exported to:\n\n%s" % expFile, title=self.VVgH9X())
 def VVVpK7(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVVu2y(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VV0OnN: return (typ, x, y, w, h, png, bg, bgSel, VV0OnN | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCAJ4M():
 def __init__(self, pixmapObj, picPath, VVcGiE=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVcGiE  = VVcGiE or "#2200002a"
 def VVSFMU(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVqQBL)
    except:
     self.picLoad.PictureData.get().append(self.VVqQBL)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVcGiE])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVqQBL(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVgNN3(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVh183(pixmapObj, path, VVcGiE=None):
  cl = CCAJ4M(pixmapObj, path, VVcGiE)
  ok = cl.VVSFMU()
  if ok: return cl
  else : return None
class CCKpZj(Screen):
 def __init__(self, session, VVPWSw, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFpkpy()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFhwpa(VVXX1u, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVPWSw = VVPWSw
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFOUwv(self)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVnsYv  ,
   "up" : BF(self.VV9bND, -1),
   "down" : BF(self.VV9bND,  1),
   "left" : BF(self.VV9bND, -1),
   "right" : BF(self.VV9bND,  1)
  }, -1)
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  self.VV6zyz()
  self.picViewer = CCAJ4M.VVh183(self["myPic"], self.VVPWSw)
  if self.picViewer:
   if self.showGrnMsg:
    FF1lLq(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFeF28(self, "Cannot view picture file:\n\n%s" % self.VVPWSw)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVgNN3()
  if self.cbFnc  : self.cbFnc(self.VVPWSw)
 def VV9bND(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVPWSw = FFvBW5(os.path.dirname(self.VVPWSw)) + fName
    self.picViewer.picPath = self.VVPWSw
    self.picViewer.VVSFMU()
    self.VV6zyz()
 def VVnsYv(self):
  txt = "%s:\n  %s" % (FF4aCb("Path", VV2Bne), self.fakePath or self.VVPWSw)
  size, sizeTxt, resTxt, form, mode = CCzLkW.VVPpnu(self.VVPWSw)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF4aCb("Properties", VV2Bne)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFPaL6(self, txt, title="File Information")
 def VV6zyz(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVPWSw)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVAgYH(SELF, VVPWSw, **kwargs):
  SELF.session.open(CCKpZj, VVPWSw, **kwargs)
class CCZ6Jn(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFhwpa(VVgWTf, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFOUwv(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.onExit)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FF7Jdu("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVB7yA(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCZ6Jn.VVxclq, SELF), CCZ6Jn, mviFile)
 @staticmethod
 def VVxclq(SELF, reason=None):
  if reason == -1: FFeF28(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCE4DO(Screen, ConfigListScreen):
 VVygWF = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVRmyC, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFOUwv(self, title=self.Title)
  FFtNax(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVWpMz()
  self.onShown.append(self.VVy4Yl)
 def VVWpMz(self):
  kList = {
    "ok" : self.VVTQe0   ,
    "green" : self.VV5eZA ,
    "menu" : self.VVl2FE ,
    "cancel": self.VVje1S ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVAiES, 0)
     kList["chanDown"] = BF(self["config"].VVAiES, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VV0Gk9, kList, -1)
  else:
   self["actions"] = ActionMap(VV0Gk9, kList, -1)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFRBDi(self)
  FFMOVh(self["config"])
  FFMHNW(self, self["config"])
  FFimE3(self)
  self["config"].onSelectionChanged.append(self.VVa9CP)
  self.VVa9CP()
  FFBHn2(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVa9CP(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVTQe0(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVUVEF()
   elif item == CFG.MovieDownloadPath   : self.VVndpj(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVpnRf()
   elif isinstance(item, ConfigDirectory) : self.VVmogD(item)
   else         : CCE4DO.VV4APY(self, item, title)
 @staticmethod
 def VV4APY(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber):
    lst = confItem.choices.choices
    if not isinstance(lst[0], tuple)  : lst = [(x, x) for x in lst]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVGuvj = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVrWwc + txt
    elif val == confItem.default: defNdx, txt = ndx, VVc1MO + txt
   VVGuvj.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVLIPG  = ("Current", BF(CCE4DO.VVgicV, curNdx))
  VVBLXn = ("Default", BF(CCE4DO.VVgicV, defNdx))
  VVUD8b = FFSiXW(SELF, BF(CCE4DO.VVEiHF, confItem, cbFnc, isSave), VVGuvj=VVGuvj, width=1200, VVBLXn=VVBLXn, VVLIPG=VVLIPG, title=title, VVmEJ8="#33221111", VVd8a3="#33110011")
  VVUD8b.VVn6An(curNdx)
 @staticmethod
 def VVEiHF(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFCRXL(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVgicV(ndx, selectionObj, item):
  selectionObj.VVn6An(ndx)
 @staticmethod
 def VVUUj2(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVndpj(self, item, title):
  tot = CCATpC.VVpx3A()
  if tot : FFeF28(self, "Cannot change while downloading.", title=title)
  else : self.VVmogD(item)
 def VVpnRf(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CC7ZOW.VVeFhn(self, "", curEnc)
  if lst:
   VVBLXn = ("Default", self.VV3rGC)
   VVLIPG  = ("Current", self.VVw5By)
   VVUD8b = FFSiXW(self, self.VVXx0m, title="Select Priority Encoding", VVGuvj=lst, width=1000, height=1000, VVLIPG=VVLIPG, VVBLXn=VVBLXn, VVmEJ8="#22220000", VVd8a3="#22220000", VVYJYo=True)
   VVUD8b.VVA9Pf(curEnc)
 def VVXx0m(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VV3rGC(self, VVUD8b, item): VVUD8b.VVA9Pf(VVl8Ad)
 def VVw5By(self, VVUD8b, item): VVUD8b.VVA9Pf(CFG.subtDefaultEnc.getValue())
 def VVUVEF(self):
  VVGuvj = []
  VVGuvj.append(("Auto Find" , "auto"))
  VVGuvj.append(("Custom Path" , "cust"))
  FFSiXW(self, self.VVSgd6, VVGuvj=VVGuvj, title="IPTV Hosts Files Path")
 def VVSgd6(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVYMuP)
   elif item == "cust":
    VVJpUa = self.VVsfcn()
    if VVJpUa : self.VVCozN(VVJpUa)
    else  : self.session.openWithCallback(self.VV0gLX, BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf="/"))
 def VVCozN(self, VVJpUa):
  VVJlHN = self.VVQRUa
  VVFkw1 = ("Remove"  , self.VV9S4d , [])
  VVpxmm = ("Add "  , self.VV6Q7g, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVRYg6  = (LEFT   , LEFT  )
  FFBxNx(self, None, title="IPTV Hosts Search Paths", header=header, VVWhjq=VVJpUa, width=1200, height=700, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=26, VVJlHN=VVJlHN, VVFkw1=VVFkw1, VVpxmm=VVpxmm
    , VVmEJ8="#22220000", VVd8a3="#22110000", VVcGiE="#22110011", VVh96o="#11223025", VV5t00="#0a333333", VVO2zv="#11400040")
 def VVQRUa(self, VVgAw8):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVTBvr)
  VVgAw8.cancel()
 def VV0gLX(self, path):
  if path:
   FFCRXL(CFG.iptvHostsDirs, FFvBW5(path.strip()))
   VVJpUa = self.VVsfcn()
   if VVJpUa : self.VVCozN(VVJpUa)
   else  : FF1lLq(self, "Cannot add dir", 1500)
 def VVVwPx(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVYMuP:
   return []
  return lst
 def VVsfcn(self):
  lst = self.VVVwPx()
  if lst:
   VVJpUa = []
   for Dir in lst:
    VVJpUa.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVJpUa.sort(key=lambda x: x[0].lower())
   return VVJpUa
  else:
   return []
 def VV6Q7g(self, VVgAw8, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVuqIa, VVgAw8)
         , BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=sDir))
 def VVuqIa(self, VVgAw8, path):
  if path:
   path = FFvBW5(path.strip())
   if self.VVTNJX(VVgAw8, path):
    FF1lLq(VVgAw8, "Already added", 1500)
   else:
    lst = self.VVVwPx()
    lst.append(path)
    FFCRXL(CFG.iptvHostsDirs, ",".join(lst))
    VVJpUa = self.VVsfcn()
    VVgAw8.VVFDhD(VVJpUa, tableRefreshCB=BF(self.VVt69O, path))
 def VVt69O(self, path, VVgAw8, title, txt, colList):
  self.VVTNJX(VVgAw8, path)
 def VVTNJX(self, VVgAw8, path):
  for ndx, row in enumerate(VVgAw8.VVYgJy()):
   if row[0].strip() == path.strip():
    VVgAw8.VVAGTP(ndx)
    return True
  return False
 def VV9S4d(self, VVgAw8, title, txt, colList):
  path = colList[0]
  FFZRvh(self, BF(self.VVSAx3, VVgAw8), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVSAx3(self, VVgAw8):
  row = VVgAw8.VVi9QZ()
  path, rem = row[0], row[1]
  VVJpUa = []
  lst = []
  for ndx, row in enumerate(VVgAw8.VVYgJy()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVJpUa.append((tPath, tRem))
  if len(VVJpUa) > 0:
   FFCRXL(CFG.iptvHostsDirs, ",".join(lst))
   VVgAw8.VVFDhD(VVJpUa)
   FF1lLq(VVgAw8, "Deleted", 1500)
  else:
   FFCRXL(CFG.iptvHostsMode, VVYMuP)
   FFCRXL(CFG.iptvHostsDirs, "")
   VVgAw8.cancel()
   FFJVhm(BF(FF1lLq, self, "Changed to Auto-Find", 1500))
 def VVmogD(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VV4zMv, configObj)
         , BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=sDir))
 def VV4zMv(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVje1S(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFZRvh(self, self.VV5eZA, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VV5eZA(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVCunB()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVl2FE(self):
  VVGuvj = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVGuvj.append((txt    , "VVLtjN"   ))
  else        : VVGuvj.append((txt    ,       ))
  VVGuvj.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Reset %s Settings" % PLUGIN_NAME      , "VVwJuq"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Backup %s Settings" % PLUGIN_NAME      , "VVRovp"  ))
  VVGuvj.append(("Restore %s Settings" % PLUGIN_NAME     , "VVMwT2"  ))
  if fileExists(VVmc3z + CCE4DO.VVygWF):
   VVGuvj.append(VVnek4)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVGuvj.append(('%s Checking for Update' % txt1     , txt2     ))
   VVGuvj.append(("Reinstall %s" % PLUGIN_NAME      , "VVsEX0"  ))
   VVGuvj.append(("Update %s" % PLUGIN_NAME      , "VV0wTA"   ))
  FFSiXW(self, self.VVuMJ3, VVGuvj=VVGuvj, title="Config. Options")
 def VVuMJ3(self, item=None):
  if item:
   if   item == "VVLtjN"  : FFZRvh(self, self.VVLtjN , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CC3JT1)
   elif item == "VVwJuq"  : FFZRvh(self, BF(self.VVwJuq, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVRovp" : self.VVRovp()
   elif item == "VVMwT2" : FF4idw(self, self.VVMwT2, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFCRXL(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFCRXL(CFG.checkForUpdateAtStartup, False)
   elif item == "VVsEX0" : FF4idw(self, BF(self.VVHiEH, True ), "Checking Server ...")
   elif item == "VV0wTA"  : FF4idw(self, BF(self.VVHiEH, False), "Checking Server ...")
 def VVRovp(self):
  path = "%sajpanel_settings_%s" % (VVmc3z, FFguCY())
  FFbqSU("grep .%s. %s > %s" % (PLUGIN_NAME, VVOAlS, path))
  FFDx6X(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVMwT2(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFkrzQ("find / %s -iname '%s*' | grep %s" % (FFOG94(1), name, name))
  if files:
   err = CCZHbk.VVdoWo(files)
   if err:
    FFZRvh(self, BF(self.VVHop3, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVGuvj = []
    for line in files:
     VVGuvj.append((line, line))
    FFSiXW(self, BF(self.VVqwlH, title), title=title, VVGuvj=VVGuvj, width=1200, VV51Jr="")
  else:
   FFeF28(self, "No settings files found !", title=title)
 def VVHop3(self, title, path=None):
  sDir = "/"
  for path in (VVmc3z, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVqwlH, title), BF(CCZHbk, patternMode="ajpSet", VVYYtf=sDir))
 def VVqwlH(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF8p4l(path)
    self.VVwJuq()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVCunB()
    FFHWr6()
    FF1lLq(self, "Apllied", 1500, isGrn=True)
   else:
    FFJBL5(self, path, title=title)
 def VVLtjN(self):
  newPath = FFvBW5(VVmc3z)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVCunB()
 @staticmethod
 def VVgNWJ():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVwJuq(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVCunB()
  if exit:
   self.close()
 def VVCunB(self):
  configfile.save()
  global VVmc3z
  VVmc3z = CFG.backupPath.getValue()
  FFOIVI()
 def VVHiEH(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCE4DO.VVUYTh()
  if   err    : FFeF28(self, err, title)
  elif isHigher or force : FFZRvh(self, BF(FF4idw, self, BF(self.VVahUe, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFDx6X(self, FF4aCb("No update required.", VV1udq) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVahUe(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FF9QPZ() == "dpkg" else "ipk")
  path, err = FFl4UT(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFNCOV(VVUhs4, path)
   else : cmd = FFNCOV(VVnGKI, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FF1NOx(self, cmd, title=title)
   else:
    FFDayU(self, title=title)
  else:
   FFeF28(self, err, title=title)
 @staticmethod
 def VVUYTh():
  span = iSearch(r"v*(\d.\d.\d)", VV64TL, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVmc3z + CCE4DO.VVygWF
  if fileExists(path):
   span = iSearch(r"(http.+)", FFhqv7(path), IGNORECASE)
   if span : url = FFvBW5(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFl4UT(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFhqv7(path).strip().replace(" ", "")
   FFOHeU(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CC3JT1(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVImHJ, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VV7zN3
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFOUwv(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVRqyI("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVRqyI("\c00888888", i) + sp + "GREY\n"
   txt += self.VVRqyI("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVRqyI("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVRqyI("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVRqyI("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVRqyI("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVRqyI("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVRqyI("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVRqyI("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVRqyI("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVRqyI("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok" : self.VVTQe0 ,
   "green" : self.VVTQe0 ,
   "left" : self.VVUT8S ,
   "right" : self.VVeKbm ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  self.VV7iu5()
 def VVTQe0(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFZRvh(self, self.VVwqpw, "Change to : %s" % txt, title=self.Title)
 def VVwqpw(self):
  FFCRXL(CFG.mixedColorScheme, self.cursorPos)
  global VV7zN3
  VV7zN3 = self.cursorPos
  self.VVQENi()
  self.close()
 def VVUT8S(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV7iu5()
 def VVeKbm(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV7iu5()
 def VV7iu5(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVRqyI(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVKluA(color):
  if VVc1MO: return "\\" + color
  else    : return ""
 @staticmethod
 def VVQENi():
  global VVTjYX, VVE7tQ, VVs795, VVT2Mp, VVEkv6, VVwWfr, VV5Hia, VVstwU, VV1udq, VVE7n3, VVc1MO, VV2Bne, VVrWwc, VVXSg2, VVHksW, VViU6E
  VViU6E   = CC3JT1.VVRqyI("\c00FFFFFF", VV7zN3)
  VVE7tQ    = CC3JT1.VVRqyI("\c00888888", VV7zN3)
  VVTjYX  = CC3JT1.VVRqyI("\c005A5A5A", VV7zN3)
  VVstwU    = CC3JT1.VVRqyI("\c00FF0000", VV7zN3)
  VVs795   = CC3JT1.VVRqyI("\c00FF5000", VV7zN3)
  VVT2Mp   = CC3JT1.VVRqyI("\c00FFBB66", VV7zN3)
  VVc1MO   = CC3JT1.VVRqyI("\c00FFFF00", VV7zN3)
  VV2Bne = CC3JT1.VVRqyI("\c00FFFFAA", VV7zN3)
  VV1udq   = CC3JT1.VVRqyI("\c0000FF00", VV7zN3)
  VVE7n3  = CC3JT1.VVRqyI("\c00AAFFAA", VV7zN3)
  VV5Hia    = CC3JT1.VVRqyI("\c000066FF", VV7zN3)
  VVrWwc    = CC3JT1.VVRqyI("\c0000FFFF", VV7zN3)
  VVXSg2  = CC3JT1.VVRqyI("\c00AAFFFF", VV7zN3)  #
  VVHksW   = CC3JT1.VVRqyI("\c00FA55E7", VV7zN3)
  VVEkv6    = CC3JT1.VVRqyI("\c00FF8F5F", VV7zN3)
  VVwWfr  = CC3JT1.VVRqyI("\c00FFC0C0", VV7zN3)
CC3JT1.VVQENi()
class CC5LSv(Screen):
 def __init__(self, session, path, VVB3L1):
  self.skin, self.skinParam = FFhwpa(VViGuf, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVQfNg   = path
  self.VV09qX   = ""
  self.VVDHA6   = ""
  self.VVB3L1    = VVB3L1
  self.VVnkpO    = ""
  self.VV0Ajk  = ""
  self.VVslXs    = False
  self.VVZnBM  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVAMIh  = "enigma2-plugin-extensions-"
  self.VVPiAy  = "enigma2-plugin-systemplugins-"
  self.VVbHmj = "enigma2-"
  self.VVlBwc  = 0
  self.VVnFdz  = 1
  self.VVnRcy  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVToy6 = "DEBIAN"
  else        : self.VVToy6 = "CONTROL"
  self.controlPath = self.Path + self.VVToy6
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVB3L1:
   self.packageExt  = ".deb"
   self.VVcGiE  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVcGiE  = "#11001020"
  FFOUwv(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFtNax(self["keyRed"] , "Create")
  FFtNax(self["keyGreen"] , "Post Install")
  FFtNax(self["keyYellow"], "Installation Path")
  FFtNax(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "red"   : self.VVzb4B  ,
   "green"   : self.VVFeSe ,
   "yellow"  : self.VVL40o  ,
   "blue"   : self.VVvgdC  ,
   "cancel"  : self.VVbQ6Y
  }, -1)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFimE3(self)
  if self.VVcGiE:
   FFBHn2(self["myBody"], self.VVcGiE)
   FFBHn2(self["myLabel"], self.VVcGiE)
  self.VVATT4(True)
  self.VVBaLw(True)
 def VVBaLw(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVSngi()
  if isFirstTime:
   if   package.startswith(self.VVAMIh) : self.VVQfNg = VV4i8I + self.VVnkpO + "/"
   elif package.startswith(self.VVPiAy) : self.VVQfNg = VVzDIh + self.VVnkpO + "/"
   else            : self.VVQfNg = self.Path
  if self.VVslXs : myColor = VVEkv6
  else    : myColor = VViU6E
  txt  = ""
  txt += "Source Path\t: %s\n" % FF4aCb(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF4aCb(self.VVQfNg, VVc1MO)
  if self.VVDHA6 : txt += "Package File\t: %s\n" % FF4aCb(self.VVDHA6, VVE7tQ)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF4aCb("Check Control File fields : %s" % errTxt, VVs795)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF4aCb("Restart GUI", VVEkv6)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF4aCb("Reboot Device", VVEkv6)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF4aCb("Post Install", VV1udq), act)
  if not errTxt and VVs795 in controlInfo:
   txt += "Warning\t: %s\n" % FF4aCb("Errors in control file may affect the result package.", VVs795)
  txt += "\nControl File\t: %s\n" % FF4aCb(self.controlFile, VVE7tQ)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVFeSe(self):
  if self["keyGreen"].getVisible():
   VVGuvj = []
   VVGuvj.append(("No Action"    , "noAction"  ))
   VVGuvj.append(("Restart GUI"    , "VVzqJs"  ))
   VVGuvj.append(("Reboot Device"   , "rebootDev"  ))
   FFSiXW(self, self.VVfDkn, title="Package Installation Option (after completing installation)", VVGuvj=VVGuvj)
 def VVfDkn(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVzqJs"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVATT4(False)
   self.VVBaLw()
 def VVL40o(self):
  rootPath = FF4aCb("/%s/" % self.VVnkpO, VV2Bne)
  VVGuvj = []
  VVGuvj.append(("Current Path"        , "toCurrent"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Extension Path"       , "toExtensions" ))
  VVGuvj.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVGuvj.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFSiXW(self, self.VVa124, title="Installation Path", VVGuvj=VVGuvj)
 def VVa124(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVIe0G(FF78Uj(self.Path, True))
   elif item == "toExtensions"  : self.VVIe0G(VV4i8I)
   elif item == "toSystemPlugins" : self.VVIe0G(VVzDIh)
   elif item == "toRootPath"  : self.VVIe0G("/")
   elif item == "toRoot"   : self.VVIe0G("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVgstF, BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=VVmc3z))
 def VVgstF(self, path):
  if len(path) > 0:
   self.VVIe0G(path)
 def VVIe0G(self, parent, withPackageName=True):
  if withPackageName : self.VVQfNg = parent + self.VVnkpO + "/"
  else    : self.VVQfNg = "/"
  mode = self.VVx8LV()
  FF7Jdu("sed -i '/Package/c\Package: %s' %s" % (self.VVJj5E(mode), self.controlFile))
  self.VVBaLw()
 def VVvgdC(self):
  if fileExists(self.controlFile):
   lines = FF8p4l(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFrwu2(self, self.VVUz0A, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFeF28(self, "Version not found or incorrectly set !")
  else:
   FFJBL5(self, self.controlFile)
 def VVUz0A(self, VVNyo5):
  if VVNyo5:
   version, color = self.VVsUnq(VVNyo5, False)
   if color == VVrWwc:
    FF7Jdu("sed -i '/Version:/c\Version: %s' %s" % (VVNyo5, self.controlFile))
    self.VVBaLw()
   else:
    FFeF28(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVbQ6Y(self):
  if self.newControlPath:
   if self.VVslXs:
    self.VVH730()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF4aCb(self.newControlPath, VVE7tQ)
    txt += FF4aCb("Do you want to keep these files ?", VVc1MO)
    FFZRvh(self, self.close, txt, callBack_No=self.VVH730, title="Create Package", VVnBJJ=True)
  else:
   self.close()
 def VVH730(self):
  FF7Jdu("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVJj5E(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VV0Ajk
  if package.startswith(self.VVbHmj):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVbHmj, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVnFdz : prefix = self.VVAMIh
  elif mode == self.VVnRcy : prefix = self.VVPiAy
  return (prefix + name).lower()
 def VVx8LV(self):
  if   self.VVQfNg.startswith(VV4i8I) : return self.VVnFdz
  elif self.VVQfNg.startswith(VVzDIh) : return self.VVnRcy
  else            : return self.VVlBwc
 def VVATT4(self, isFirstTime):
  self.VVnkpO   = FFc02K(self.Path)
  self.VVnkpO   = "_".join(self.VVnkpO.split())
  self.VV0Ajk = self.VVnkpO.lower()
  self.VVslXs = self.VV0Ajk == VVVBEw.lower()
  if self.VVslXs and self.VV0Ajk.endswith(VVVBEw.lower()):
   self.VV0Ajk += "el"
  if self.VVslXs : self.VV09qX = VVmc3z
  else    : self.VV09qX = CFG.packageOutputPath.getValue()
  self.VV09qX = FFvBW5(self.VV09qX)
  if not pathExists(self.controlPath):
   FF7Jdu("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVx8LV()
  if fileExists(self.controlFile):
   lines = FF8p4l(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVslXs : version, descripton, maintainer = VV64TL , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVnkpO , self.VVnkpO
   txt = ""
   txt += "Package: %s\n"  % self.VVJj5E(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: \n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVslXs : t = PLUGIN_NAME
  else    : t = self.VVnkpO
  self.VVETIB(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVETIB(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVslXs : self.VVETIB(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV64TL))
  else    : self.VVETIB(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVnkpO)
  if isFirstTime and not mode == self.VVlBwc:
   self.postInstAcion = 1
  txt = self.VVhZLr(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFhqv7(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVhZLr(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FF7Jdu("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVETIB(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVhZLr(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVSngi(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF8p4l(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF4aCb(line, VVs795)
     elif not line.startswith(" ")    : line = FF4aCb(line, VVs795)
     else          : line = FF4aCb(line, VVrWwc)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVrWwc
   else   : color = VVs795
   descr = FF4aCb(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVs795
     elif line.startswith((" ", "\t")) : color = VVs795
     elif line.startswith("#")   : color = VVE7tQ
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVsUnq(val, True)
      elif key == "Version"  : version, color = self.VVsUnq(val, False)
      elif key == "Maintainer" : maint  , color = val, VVrWwc
      elif key == "Architecture" : arch  , color = val, VVrWwc
      else:
       color = VVrWwc
      if not key == "OE" and not key.istitle():
       color = VVs795
     else:
      color = VVEkv6
     txt += FF4aCb(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVDHA6 = self.VV09qX + packageName
   self.VVZnBM = True
   errTxt = ""
  else:
   self.VVDHA6  = ""
   self.VVZnBM = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVsUnq(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVrWwc
  else          : return val, VVs795
 def VVzb4B(self):
  if not self.VVZnBM:
   FFeF28(self, "Please fix Control File errors first.")
   return
  if self.VVB3L1: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF78Uj(self.VVQfNg, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVnkpO
  symlinkTo  = FFaYmq(self.Path)
  dataDir   = self.VVQfNg.rstrip("/")
  removePorjDir = FFTMeZ("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFTMeZ("rm -f '%s'" % self.VVDHA6)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF6BOQ()
  if self.VVB3L1:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFf1mi("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVslXs:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVQfNg == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVToy6)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVDHA6, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVDHA6
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVDHA6, FFlTM0(result  , VV1udq))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVQfNg, FFlTM0(instPath, VVrWwc))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFlTM0(failed, VVs795))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF1NOx(self, cmd)
class CCQrUI():
 VVOYk6  = "666"
 VVgGXY   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVUD8b   = None
  self.VVAesO()
 def VVAesO(self):
  VVGuvj = CCQrUI.VVbmna()
  if VVGuvj:
   VVBLXn = ("Create New", self.VVc5in)
   self.VVUD8b = FFSiXW(self.SELF, self.VVbbEJ, VVGuvj=VVGuvj, title=self.Title, VVBLXn=VVBLXn, VVYJYo=True, VVmEJ8="#22222233", VVd8a3="#22222233")
  else:
   self.VVc5in()
 def VVbbEJ(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV8ElZ(bName, bRef)
  else:
   CCQrUI.VVwbZx(self)
 def VVc5in(self, selectionObj=None, item=None):
  FFrwu2(self.SELF, BF(self.VVh4ua), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVh4ua(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVUD8b:
     self.VVUD8b.cancel()
    self.VV8ElZ(bName, "")
   else:
    FF1lLq(self.VVUD8b, "Incorrect Bouquet Name !", 2000)
    CCQrUI.VVwbZx(self)
 def VV8ElZ(self, bName, bRef):
  FF4idw(self.waitMsgSELF, BF(self.VVnD99, bName, bRef), title="Adding Services ...")
 def VVnD99(self, bName, bRef):
  CCQrUI.VVMfMj(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVwbZx(classObj):
  del classObj
 @staticmethod
 def VVMfMj(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFeF28(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVgBUe + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFJBL5(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCQrUI.VVFdHs(bRef)
   bPath = VVgBUe + bFile
  else:
   fName = CCCW9K.VV8jRk(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVgBUe + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVgBUe + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FF5wJY(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FF5wJY(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCnBmO.VVYQsq()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FF7Jdu("cp -f '%s' '%s'" % (poster, picon))
       FF7Jdu(CCM3PM.VVuDvo(picon))
       break
  FF9bFs()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFPaL6(SELF, txt, title=title)
 @staticmethod
 def VVdei8(bName):
  mode = CC7xD6.VVNbTy(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCCW9K.VV8jRk(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVgBUe + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVgBUe + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVgBUe, modeTxt)
  if fileExists(mainBFile):
   FF5wJY(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VVIf9f(ref, bName):
  bFile = CCQrUI.VVFdHs(ref)
  ok = False
  if bFile:
   bFile = VVgBUe + bFile
   if fileExists(bFile):
    lines = FF8p4l(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVbmna(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVGuvj = []
  if mode in (0, 2): VVGuvj.extend(CCQrUI.VV8OHf(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVGuvj.extend(CCQrUI.VV8OHf(1, showTitle, prefix, onlyIptv))
  return VVGuvj
 @staticmethod
 def VV8OHf(mode, showTitle, prefix, onlyIptv):
  VVGuvj = []
  lst = CCQrUI.VVi6Fz(mode)
  if onlyIptv:
   lst = CCQrUI.VVBcp3(lst)
  if lst:
   if showTitle:
    VVGuvj.append(FFJ9Ko("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVGuvj.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVGuvj.append((item[0], item[1].toString()))
  return VVGuvj
 @staticmethod
 def VVBcp3(lst):
  fLst = CCCW9K.VVEC3O(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVnAje():
  lst = CCQrUI.VVi6Fz(0)
  lst.extend(CCQrUI.VVi6Fz(1))
  return lst
 @staticmethod
 def VVi6Fz(mode=0):
  bList = []
  VVZuLk = InfoBar.instance
  VV83rW = VVZuLk and VVZuLk.servicelist
  if VV83rW:
   curMode = VV83rW.mode
   CCQrUI.VVCXAA(VV83rW, mode)
   bList.extend(VV83rW.getBouquetList() or [])
   CCQrUI.VVCXAA(VV83rW, curMode)
  return bList
 @staticmethod
 def VVCXAA(VV83rW, mode):
  if not mode == VV83rW.mode:
   if   mode == 0: VV83rW.setModeTv()
   elif mode == 1: VV83rW.setModeRadio()
 @staticmethod
 def VV5xN1(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVlOe7 = eServiceCenter.getInstance()
    if onlyMain:
     info = VVlOe7.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVlOe7 and VVlOe7.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVlOe7.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVFdHs(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VVUBPJ(ref, dstFile):
  dstFile = VVgBUe + dstFile
  if fileExists(dstFile):
   FF5wJY(dstFile)
   bLine = ""
   srcFile = CCQrUI.VVFdHs(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVgBUe + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVgBUe + newName
     FF7Jdu("cp -f '%s%s' '%s'" % (VVgBUe, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVtUCc():
  try:
   fName = CCQrUI.VVFdHs(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVgBUe, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VV3Lcf():
  path = CCQrUI.VVtUCc()
  if path:
   txt = FFhqv7(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVAp70():
  return FF7SJo(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVvnbE():
  lst = []
  for b in CCQrUI.VVnAje():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVgBUe + CCQrUI.VVFdHs(bRef)
   if fileExists(path):
    lines = FF8p4l(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VV9Uqm(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VV5NMM(SID="", stripRType=False):
  if SID : patt = CCQrUI.VV9Uqm(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCQrUI.VVnAje():
   for service in FF7SJo(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVnGLs():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCQrUI.VVnAje():
   for service in FF7SJo(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVOzvp(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVwQPo(pathLst, rType=""):
  refLst = CCQrUI.VV5NMM(CCQrUI.VVOYk6, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCQrUI.VVOzvp(rType, CCQrUI.VVOYk6, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCZHbk(Screen):
 VV2MPO   = 0
 VV74nh  = 1
 VVms2N  = 2
 VV13fu = 3
 VVPVAk    = 20
 VVwl9G   = 0
 VV9aXu   = 1
 VViSvu   = 2
 def __init__(self, session, VVYYtf="/", mode=VV2MPO, VVdjsL="Select", width=1400, height=920, VVCppa=30, VVmEJ8="#22001111", VVd8a3="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFhwpa(VVwa4P, width, height, 30, 40, 20, VVmEJ8, VVd8a3, VVCppa, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVmEJ8   = VVmEJ8
  self.VVd8a3    = VVd8a3
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFOUwv(self)
  FFtNax(self["keyRed"] , "Exit")
  FFtNax(self["keyYellow"], "More Options")
  FFtNax(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVdjsL = VVdjsL
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVcmVL = None
  if patternMode:
   self.mode = self.VV13fu
   if   patternMode == "srt"  : VVcmVL = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVcmVL = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVcmVL = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVcmVL = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVcmVL = ("^.*\.(%s)$" % "|".join(CCw3cf.VV81Gw()["mov"]), IGNORECASE)
   else       : VVcmVL = None
  if self.mode in (self.VVms2N, self.VV13fu):
   FFtNax(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVFnJB, self.VVYYtf = True , FF78Uj(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVFnJB, self.VVYYtf = True , CCZHbk.VVuryx(self)[1] or "/"
  elif self.mode == self.VV2MPO  : VVFnJB, self.VVYYtf = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVms2N : VVFnJB, self.VVYYtf = False, VVYYtf
  elif self.mode == self.VV13fu : VVFnJB, self.VVYYtf = True , VVYYtf
  else           : VVFnJB, self.VVYYtf = True , VVYYtf
  self.VVYYtf = FFvBW5(self.VVYYtf)
  self["myMenu"] = CCw3cf(  directory   = None
         , VVcmVL = VVcmVL
         , VVFnJB   = VVFnJB
         , VV8rNN = True
         , VV3ElW = True
         , VVXvTn   = self.skinParam["width"]
         , VVCppa   = self.skinParam["bodyFontSize"]
         , VVQSWB  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VV0Gk9,
  {
   "ok" : self.VVTQe0    ,
   "red" : self.VVF2tP   ,
   "green" : self.VVmJyl,
   "yellow": self.VVuYTl  ,
   "blue" : self.VVOnxg ,
   "menu" : self.VVzehQ  ,
   "info" : self.VVQAxd  ,
   "cancel": self.VVTU4s    ,
   "pageUp": self.VVUBJp   ,
   "chanUp": self.VVUBJp
  }, -1)
  FFvOiZ(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVmpdP)
  global VVdbLU
  VVdbLU = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VV2MPO:
   FF5GKV("VVdbLU")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVmpdP)
  FFRBDi(self)
  FFMOVh(self["myMenu"], bg=self.cursorBG)
  FFimE3(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVms2N, self.VV13fu):
   FFtNax(self["keyGreen"], self.VVdjsL)
   self.VVSIvK(self.VV9aXu)
  self.VVmpdP()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVDH9l(self.VVYYtf) > self.bigDirSize: FF4idw(self, self.VV2wjD, title="Changing directory...")
  else              : self.VV2wjD()
 def VV2wjD(self):
  if self.jumpToFile : self.VVdTwK(self.jumpToFile)
  elif self.gotoMovie : self.VV9Qrf(chDir=False)
  else    : self["myMenu"].VVcIXR(self.VVYYtf)
 def VVAGTP(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVibYx(self):
  FF4idw(self, self.VVSi2L, title="Refreshing list ...")
 def VVSi2L(self):
  isSel = self["myMenu"].VVfX0C()
  if not isSel:
   self.VVZFOs(False)
  FFWolN()
 def VVPofr(self, saved):
  if saved: self.VVibYx()
 def VVDH9l(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVTQe0(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVPdHm()
   if ok : self["keyBlue"].setText(self.VV16oY())
   else : FF1lLq(self, "Cannot select item", 500)
  elif self["myMenu"].VVsdLP(): self.VVVGoU()
  else       : self.VVioRi()
 def VVUBJp(self):
  if self.multiSelectState:
   FF1lLq(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVNDF8():
    self.VVVGoU()
 def VVVGoU(self, isDirUp=False):
  if self["myMenu"].VVsdLP():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVuhe5(self.VV1uLK())
   if self.VVDH9l(path) > self.bigDirSize : FF4idw(self, self.VVIEit, title="Changing directory...")
   else           : self.VVIEit()
 def VVIEit(self):
  self["myMenu"].descent()
  self.VVmpdP()
 def VVTU4s(self):
  if   self.multiSelectState     : self.VVZFOs(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVF2tP()
  else          : self.VVUBJp()
 def VVF2tP(self):
  if not FFfNhM(self):
   self.close("")
 def VVmJyl(self):
  path = self.VVuhe5(self.VV1uLK())
  if self.mode == self.VVms2N:
   self.close(path)
  elif self.mode == self.VV13fu:
   if os.path.isfile(path) : self.close(path)
   else     : FF1lLq(self, "Cannot access this file", 1000)
 def VVQAxd(self):
  FF4idw(self, self.VVaURp, title="Calculating size ...")
 def VVaURp(self):
  path = self.VVuhe5(self.VV1uLK())
  param = self.VVC8a3(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFGRiq("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCZHbk.VVGOxo(path)
     freeSize = CCZHbk.VV0ZbU(path)
     size = totSize - freeSize
     totSize  = CCZHbk.VVi3go(totSize)
     freeSize = CCZHbk.VVi3go(freeSize)
    else:
     size = FFicDa(path)
   usedSize = CCZHbk.VVi3go(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF4aCb(pathTxt, VVEkv6) + "\n"
   if slBroken : fileTime = self.VVn01Z(path)
   else  : fileTime = self.VVRHAh(path)
   def VV5Sg6(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV5Sg6("Path"    , pathTxt)
   txt += VV5Sg6("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV5Sg6("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV5Sg6("Total Size"   , "%s" % totSize)
    txt += VV5Sg6("Used Size"   , "%s" % usedSize)
    txt += VV5Sg6("Free Size"   , "%s" % freeSize)
   else:
    txt += VV5Sg6("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV5Sg6("Owner"    , owner)
   txt += VV5Sg6("Group"    , group)
   txt += VV5Sg6("Perm. (User)"  , permUser)
   txt += VV5Sg6("Perm. (Group)"  , permGroup)
   txt += VV5Sg6("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV5Sg6("Perm. (Ext.)" , permExtra)
   txt += VV5Sg6("iNode"    , iNode)
   txt += VV5Sg6("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVzLqB(path)
  else:
   FFeF28(self, "Cannot access information !")
  if len(txt) > 0:
   FFPaL6(self, txt)
 def VVC8a3(self, path):
  path = path.strip()
  path = FFaYmq(path)
  result = FFGRiq("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVf0tl(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVf0tl(perm, 1, 4)
   permGroup = VVf0tl(perm, 4, 7)
   permOther = VVf0tl(perm, 7, 10)
   permExtra = VVf0tl(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFMNhK("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVzLqB(self, path):
  txt  = ""
  res  = FFGRiq("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF4aCb("File Attributes:", VVHksW), txt)
  return txt
 def VVRHAh(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFrH35(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFrH35(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFrH35(os.path.getctime(path))
  return txt
 def VVn01Z(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFGRiq("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFGRiq("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFGRiq("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVuhe5(self, currentSel):
  currentDir  = self["myMenu"].VVpbUC()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVsdLP():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VV1uLK(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVmpdP(self):
  path = self.VVuhe5(self.VV1uLK())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVVhu4()
  if self.mode == self.VV2MPO:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VV13fu:
   path = self.VVuhe5(self.VV1uLK())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVzehQ(self):
  color1 = VVwWfr
  color2 = VV2Bne
  color3 = VVXSg2
  totSel = 0
  menuW = 1000
  title = "Options"
  VVGuvj= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVlcZR()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFtCOg(totSel))
     VVGuvj.append((color1 + txt1     , "VVUQe81" ))
     VVGuvj.append((color1 + txt1 + txt2   , "VVUQe82" ))
     VVGuvj.append(VVnek4)
    VVGuvj.append(("[6] Copy"       , "copyBulk" ))
    VVGuvj.append(("[7] Move"       , "moveBulk" ))
    VVGuvj.append(("[8] %sDELETE" % VVEkv6 , "VVnnGn" ))
   else:
    FF1lLq(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVms2N, self.VV13fu):
   VVGuvj.append(("Properties"           , "properties" ))
   VVGuvj.append(VVnek4)
   VVGuvj.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVuhe5(self.VV1uLK())
   isEditable = self["myMenu"].VVbuAc()
   VVGuvj.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVGuvj.append(VVnek4)
     VVGuvj.append((color1 + "Archiving / Packaging", "VV9iIj_dir"))
   elif os.path.isfile(path):
    selFile = self.VV1uLK()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar", ".7z"))
    if not isArch:
     VVGuvj.append((color1 + "Archive ...", "VV9iIj_file"))
    isText = False
    txt = ""
    if   isArch            : VVGuvj.extend(self.VVfUka(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVGuvj.extend(self.VVL5fO(True))
    elif selFile.endswith(".sh"):
     VVGuvj.extend(self.VVIWOx(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCZHbk.VVdHnF(path):
     VVGuvj.append(VVnek4)
     VVGuvj.append((color2 + "View"     , "textView_def"))
     VVGuvj.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVGuvj.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVd5ri(path) == "pic":
     VVGuvj.append(VVnek4)
     VVGuvj.append((color2 + "Set as PIcon for current channel" , "VV0ta0" ))
     if FFGbNH("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVGuvj.append(VVnek4)
      VVGuvj.append((color2 + "Convert to MVI (1280 x 720 )" , "VVmYvLHd"   ))
      VVGuvj.append((color2 + "Convert to MVI (1920 x 1080)" , "VVmYvLFhd"   ))
    elif selFile.endswith(CCZHbk.VV95Jc()):
     if selFile.endswith(".mvi"):
      if FFGbNH("showiframe"):
       VVGuvj.append(VVnek4)
       VVGuvj.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVGuvj.append(VVnek4)
      VVGuvj.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVGuvj.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVGuvj.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVGuvj.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVGuvj.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVGuvj.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV0CqO" ))
    if len(txt) > 0:
     VVGuvj.append(VVnek4)
     VVGuvj.append((color1 + txt, "VVioRi"))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("[4] Create SymLink", "VVWBsB"))
   if isEditable:
    VVGuvj.append(("[5] Rename"      , "VVh06l" ))
    VVGuvj.append(("[6] Copy"       , "copyFileOrDir" ))
    VVGuvj.append(("[7] Move"       , "moveFileOrDir" ))
    VVGuvj.append(("[8] %sDELETE" % VVEkv6 , "VVCL4A" ))
    if fileExists(path):
     VVGuvj.append(VVnek4)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVGuvj.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVGuvj.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVGuvj.append((chmodTxt + "777)", "chmod777"))
   VVGuvj.append(VVnek4)
   VVGuvj.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVGuvj.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCZHbk.VVuryx(self)
   if fPath:
    VVGuvj.append(VVnek4)
    VVGuvj.append((color2 + "Go to Current Movie Dir", "VV9Qrf"))
  FFSiXW(self, self.VVt4DS, width=menuW, height=1050, title=title, VVGuvj=VVGuvj, VVTN4d=False, VVmEJ8="#00101020", VVd8a3="#00101A2A")
 def VVt4DS(self, item=None):
  if item is not None:
   path = self.VVuhe5(self.VV1uLK())
   selFile = self.VV1uLK()
   if   item == "VVUQe81"    : self.VVUQe8(False)
   if   item == "VVUQe82"    : self.VVUQe8(True)
   elif item == "copyBulk"     : self.VVsbWm(False)
   elif item == "moveBulk"     : self.VVsbWm(True)
   elif item == "VVnnGn"    : self.VVnnGn()
   elif item == "properties"    : self.VVQAxd()
   elif item == "VV9iIj_dir" : self.VV9iIj(path, True)
   elif item == "VV9iIj_file" : self.VV9iIj(path, False)
   elif item == "VVHebP"  : self.VVHebP(path)
   elif item == "VVk1n6"  : self.VVk1n6(path)
   elif item.startswith("extract_")  : self.VVym96(path, selFile, item)
   elif item.startswith("script_")   : self.VVDrDK(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVVhb2(path, selFile, item)
   elif item.startswith("textView_def") : FFXpyW(self, path)
   elif item.startswith("textView_enc") : self.VVpnWI(path)
   elif item.startswith("text_Edit")  : CCrb0k(self, path, VVHoAX=self.VVPofr)
   elif item.startswith("textSave_encUtf8"): self.VVGxTR(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVGxTR(path, "Save as Other Encoding", False)
   elif item.startswith("VV0CqO") : self.VV0CqO(path)
   elif item == "viewAsBootlogo"   : self.VVIAq9(path, True)
   elif item == "addMovieToBouquet"  : self.VVwIUv(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVwIUv(path, True)
   elif item == "playWith"     : self.VVRlmo(path)
   elif item == "VV0ta0" : self.VV0ta0(path)
   elif item == "VVmYvLHd"   : FF4idw(self, BF(self.VVmYvL, path, False))
   elif item == "VVmYvLFhd"   : FF4idw(self, BF(self.VVmYvL, path, True))
   elif item == "VVWBsB"   : self.VVWBsB(path, selFile)
   elif item == "VVh06l"   : self.VVh06l(path, selFile)
   elif item == "copyFileOrDir"   : self.VVhoWz(path, False)
   elif item == "moveFileOrDir"   : self.VVhoWz(path, True)
   elif item == "VVCL4A"   : self.VVCL4A(path, selFile)
   elif item == "chmod644"     : self.VV4rP0(path, selFile, "644")
   elif item == "chmod755"     : self.VV4rP0(path, selFile, "755")
   elif item == "chmod777"     : self.VV4rP0(path, selFile, "777")
   elif item == "createNewFile"   : self.VVpqAo(path, True)
   elif item == "createNewDir"    : self.VVpqAo(path, False)
   elif item == "VV9Qrf"   : self.VV9Qrf()
   elif item == "VVioRi"    : self.VVioRi()
 def VVioRi(self):
  if self.mode == self.VV13fu and not self.patternMode == "poster":
   return
  selFile = self.VV1uLK()
  path  = self.VVuhe5(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVd5ri(path)
   if   cat == "pic"       : self.VVlOdD(path)
   elif cat == "txt"       : FFXpyW(self, path)
   elif cat in ("tar", "rar", "zip", "p7z") : self.VVBSHt(path, selFile)
   elif cat == "scr"       : self.VVZXgO(path, selFile)
   elif cat == "m3u"       : self.VV3uDl(path, selFile)
   elif cat in ("ipk", "deb")     : self.VV1qYn(path, selFile)
   elif cat in ("mov", "mus")     : self.VVIAq9(path)
   elif not CCZHbk.VVdHnF(path) : FFXpyW(self, path)
 def VVlOdD(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVd5ri(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCKpZj.VVAgYH(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVCotc)
 def VVCotc(self, path):
  self.VVdTwK(path)
 def VVIAq9(self, path, asLogo=False):
  if asLogo : CCZ6Jn.VVB7yA(self, path)
  else  : FF4idw(self, BF(self.VVrMz7, self, path), title="Playing Media ...")
 def VVOnxg(self):
  if self["keyBlue"].getVisible():
   VVWhjq = self.VVHYIy()
   if VVWhjq:
    path = self.VVuhe5(self.VV1uLK())
    enableGreenBtn = False if path in self.VVHYIy() else True
    newList = []
    for line in VVWhjq:
     newList.append((line, line))
    VV91zg  = ("Delete"    , self.VV3sFU    )
    VVIY0g  = ("Add Current Dir"   , BF(self.VVG3Pd, path) ) if enableGreenBtn else None
    VVBLXn = ("Move Up"     , self.VVKyoH    )
    VVLIPG  = ("Move Down"   , self.VVswAY    )
    self.bookmarkMenu = FFSiXW(self, self.VVW6CX, width=1200, title="Bookmarks", VVGuvj=newList, minRows=10 ,VV91zg=VV91zg, VVIY0g=VVIY0g, VVBLXn=VVBLXn, VVLIPG=VVLIPG, VVmEJ8="#00000022", VVd8a3="#00000022")
 def VV3sFU(self, VVUD8b=None, path=None):
  VVWhjq = self.VVHYIy()
  if VVWhjq:
   while path in VVWhjq:
    VVWhjq.remove(path)
   self.VVsa02(VVWhjq)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVY1oo(VVWhjq)
   self.bookmarkMenu.VVtCZu(("Add Current Dir", BF(self.VVG3Pd, path)))
  else:
   FF1lLq(self, "Removed", 800)
  self.VVVhu4()
 def VVG3Pd(self, path, VVUD8b=None, item=None):
  VVWhjq = self.VVHYIy()
  if len(VVWhjq) >= self.VVPVAk:
   FFeF28(SELF, "Max bookmarks reached (max=%d)." % self.VVPVAk)
  elif not path in VVWhjq:
   if not os.path.isdir(path):
    path = FF78Uj(path, True)
   newList = [path] + VVWhjq
   self.VVsa02(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVY1oo(newList)
    self.bookmarkMenu.VVtCZu()
   else:
    FF1lLq(self, "Added", 800)
  self.VVVhu4()
 def VVKyoH(self, selectionObj, path):
  if self.bookmarkMenu:
   VVWhjq = self.bookmarkMenu.VV0BTN(True)
   if VVWhjq:
    self.VVsa02(VVWhjq)
 def VVswAY(self, selectionObj, path):
  if self.bookmarkMenu:
   VVWhjq = self.bookmarkMenu.VV0BTN(False)
   if VVWhjq:
    self.VVsa02(VVWhjq)
 def VVW6CX(self, folder=None):
  if folder:
   folder = FFvBW5(folder)
   self["myMenu"].VVcIXR(folder)
   self["myMenu"].moveToIndex(0)
  self.VVmpdP()
 def VVHYIy(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVQPDV(self):
  return True if VVHYIy() else False
 def VVsa02(self, VVWhjq):
  line = ",".join(VVWhjq)
  FFCRXL(CFG.browserBookmarks, line)
 def VVdTwK(self, path):
  if fileExists(path):
   fDir  = FFvBW5(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVcIXR(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF1lLq(self, "Not found", 1000)
 def VV9Qrf(self, chDir=True):
  fPath, fDir, fName = CCZHbk.VVuryx(self)
  self.VVdTwK(fPath)
 def VVuYTl(self):
  path = self.VVuhe5(self.VV1uLK())
  isAdd = False if path in self.VVHYIy() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVrWwc, VVE7n3, VV2Bne
  VVGuvj = []
  VVGuvj.append(("Find Files ..." , "find"))
  VVGuvj.append(("Sort ..."   , "sort"))
  VVGuvj.append(VVnek4)
  if isAdd: VVGuvj.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVGuvj.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VV2MPO:
   VVGuvj.append(VVnek4)
   if self.multiSelectState: VVGuvj.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVGuvj.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVGuvj.append(       (c3 + "Select all"    , "selAll"  ))
  FFSiXW(self, BF(self.VVDgQe, path), width=750, title="More Options", VVGuvj=VVGuvj, VVmEJ8="#00221111", VVd8a3="#00221111")
 def VVDgQe(self, path, item):
  if item:
   if   item == "find"  : self.VVgNEH(path)
   elif item == "sort"  : self.VVXweD()
   elif item == "addBM" : self.VVG3Pd(path)
   elif item == "remBM" : self.VV3sFU(None, path)
   elif item == "start" : self.VV2agI(path)
   elif item == "multiOn" : self.VVZFOs(True)
   elif item == "multiOff" : self.VVZFOs(False)
   elif item == "selAll" : self.VVZFOs(True, True)
 def VVZFOs(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FF4idw(self, BF(self["myMenu"].VVBMXJ, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVSIvK(self.VViSvu if isOn else self.VVwl9G)
 def VVSIvK(self, mode=0):
  if   mode == self.VV9aXu : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VViSvu: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVmEJ8, self.VVd8a3
  FFBHn2(self["myTitle"], titBg)
  FFBHn2(self["myBar"], titBg)
  FFBHn2(self["myBody"], bodBg)
  FFBHn2(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VV16oY()
  else     : bg, txt = VVX8yS[3], "Bookmarks"
  FFtNax(self["keyBlue"], txt)
  FFBHn2(self["keyBlue"], bg)
  self.VVVhu4()
 def VV16oY(self):
  return "Selected Items = %d" % self["myMenu"].VVlcZR()
 def VVVhu4(self):
  if self.VVHYIy() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVgNEH(self, path):
  VVGuvj = []
  VVGuvj.append(("Find in Current Directory"    , "findCur"  ))
  VVGuvj.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVGuvj.append(("Find in all Storage Systems"    , "findAll"  ))
  FFSiXW(self, BF(self.VV8j7D, path), width=700, title="Find File/Pattern", VVGuvj=VVGuvj, VVYJYo=True, VVvfDN=True, VVmEJ8="#00221111", VVd8a3="#00221111")
 def VV8j7D(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVmFra(0, path, title)
   elif item == "findCurR" : self.VVmFra(1, path, title)
   elif item == "findAll" : self.VVmFra(2, path, title)
 def VVmFra(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFrwu2(self, BF(self.VVCdGX, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVCdGX(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFCRXL(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FF1lLq(self, "No entery", 1500)
   elif badLst  : FF1lLq(self, "Too many file !", 1500)
   else   : FF4idw(self, BF(self.VV55PG, mode, path, title, filePatt), title="Searching ...")
 def VV55PG(self, mode, path, title, filePatt):
  lst = FFkrzQ(FFSgeq("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCZHbk.VVdoWo(lst)
   if err:
    FFeF28(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVGySq = (""     , self.VViBmB , [])
    VVdyRp = ("Go to File Location", self.VVCeVL  , [])
    FFBxNx(self, None, title="%s : %s" % (title, filePatt), header=header, VVWhjq=lst, VVmQwL=widths, VVCppa=26, VVGySq=VVGySq, VVdyRp=VVdyRp)
  else:
   FFFSea(self, "Not found !", 2000)
 def VVCeVL(self, VVgAw8, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVgAw8.cancel()
   self.VVdTwK(path)
  else:
   FF1lLq(VVgAw8, "Path not found !", 1000)
 def VViBmB(self, VVgAw8, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF4aCb("File:"  , VV2Bne), colList[0])
  txt += "%s\n%s"  % (FF4aCb("Directory:", VV2Bne), FFvBW5(colList[1]))
  FFPaL6(VVgAw8, txt, title=title)
 def VVXweD(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVCGw9()
  VVGuvj = []
  VVGuvj.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVGuvj.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVGuvj.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVGuvj.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVLIPG = ("Mix", BF(self.VVLTB6, True))
  FFSiXW(self, BF(self.VVgnoS, False), barText=txt, width=650, title="Sort Options", VVGuvj=VVGuvj, VVLIPG=VVLIPG, VVvfDN=True, VVmEJ8="#00221111", VVd8a3="#00221111")
 def VVLTB6(self, isMix, VVUD8b, item):
  self.VVgnoS(True, item)
 def VVgnoS(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVCGw9()
   title = "Sorting ... "
   if   item == "nameAlp": FF4idw(self, BF(self["myMenu"].VVAfSE, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF4idw(self, BF(self["myMenu"].VVAfSE, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF4idw(self, BF(self["myMenu"].VVAfSE, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF4idw(self, BF(self["myMenu"].VVAfSE, typeMode , isMix, False), title=title)
 def VV2agI(self, path):
  if not os.path.isdir(path):
   path = FF78Uj(path, True)
  FFCRXL(CFG.browserStartPath, path)
  FF1lLq(self, "Done", 500)
 def VV7M2c(self, selFile, VVrAp2, command):
  FFZRvh(self, BF(FF1NOx, self, command, consFont=True, VVdenE=self.VVibYx), "%s\n\n%s" % (VVrAp2, selFile))
 def VVfUka(self, path, calledFromMenu):
  destPath = self.VVq6Nk(path)
  lastPart = FFc02K(destPath)
  color = VV2Bne if calledFromMenu else ""
  VVGuvj = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVGuvj.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVGuvj.append(VVnek4)
   VVGuvj.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVGuvj.append(VVnek4)
   VVGuvj.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVGuvj.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVGuvj.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVGuvj.append(VVnek4)
     VVGuvj.append((color + "Convert .zip to .tar.gz"       , "VVHebP" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVGuvj.append(VVnek4)
     VVGuvj.append((color + "Convert .tar.gz to .zip"       , "VVk1n6" ))
  return VVGuvj
 def VVBSHt(self, path, selFile):
  FFSiXW(self, BF(self.VVym96, path, selFile), title="Compressed File Options", VVGuvj=self.VVfUka(path, False))
 def VVym96(self, path, selFile, item=None):
  if item is not None:
   parent  = FF78Uj(path, False)
   destPath = self.VVq6Nk(path)
   lastPart = FFc02K(destPath)
   cmd   = ""
   ques  = "Extract file ?\n\n%s" % selFile
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFf1mi("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFf1mi("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unrar l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".7z"):
     cmd += FFf1mi("7za", "p7zip", "P7Zip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; 7za l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FFbHAT(self, cmd, consFont=True)
   elif path.endswith(".rar"):
    self.VVNz0A(item, path, parent, destPath, ques)
   elif path.endswith(".7z"):
    self.VVvRV9(item, path, parent, destPath, ques)
   elif path.endswith(".zip"):
    if item == "VVHebP" : self.VVHebP(path)
    else       : self.VVz541(item, path, parent, destPath, ques)
   elif item == "VVk1n6" and path.endswith(".tar.gz"):
    self.VVk1n6(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFGRiq("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFDx6X(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVibYx()
    else:
     FFeF28(self, "Error:\n\n%s" % res, title=title)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFTMeZ("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV7M2c(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV7M2c(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FF78Uj(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV7M2c(selFile, "Extract Here ?"      , cmd)
 def VVq6Nk(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  elif path.endswith(".7z")  : extLen = 3
  elif path.endswith(".gz")  : extLen = 3
  else       : extLen = 0
  return path[:-extLen]
 def VVz541(self, item, path, parent, destPath, VVrAp2):
  FFZRvh(self, BF(self.VVe3Pj, item, path, parent, destPath), VVrAp2)
 def VVe3Pj(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFf1mi("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFlTM0(destPath, VV1udq))
  cmd +=   sep
  cmd += "fi;"
  FFSSlA(self, cmd, VVdenE=self.VVibYx, consFont=True)
 def VVNz0A(self, item, path, parent, destPath, VVrAp2):
  FFZRvh(self, BF(self.VVIxNe, item, path, parent, destPath), VVrAp2)
 def VVIxNe(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFvBW5(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFf1mi("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFlTM0(destPath, VV1udq))
  cmd +=   sep
  cmd += "fi;"
  FFSSlA(self, cmd, VVdenE=self.VVibYx, consFont=True)
 def VVvRV9(self, item, path, parent, destPath, VVrAp2):
  FFZRvh(self, BF(self.VVuzE2, item, path, parent, destPath), VVrAp2)
 def VVuzE2(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = destPath
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += "7za x '%s' -o'%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFf1mi("7za", "p7zip", "P7Zip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFlTM0(destPath, VV1udq))
  cmd +=   sep
  cmd += "fi;"
  FFSSlA(self, cmd, VVdenE=self.VVibYx, consFont=True)
 def VVIWOx(self, addSep=False):
  VVGuvj = []
  if addSep:
   VVGuvj.append(VVnek4)
  VVGuvj.append((VV2Bne + "View Script File"  , "script_View"  ))
  VVGuvj.append((VV2Bne + "Execute Script File" , "script_Execute" ))
  VVGuvj.append((VV2Bne + "Edit"     , "script_Edit"  ))
  return VVGuvj
 def VVZXgO(self, path, selFile):
  FFSiXW(self, BF(self.VVDrDK, path, selFile), title="Script File Options", VVGuvj=self.VVIWOx())
 def VVDrDK(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFXpyW(self, path)
   elif item == "script_Execute" : self.VV7M2c(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCrb0k(self, path, VVHoAX=self.VVPofr)
 def VVL5fO(self, addSep=False):
  VVGuvj = []
  if addSep:
   VVGuvj.append(VVnek4)
  VVGuvj.append((VV2Bne + "Browse IPTV Channels" , "m3u_Browse" ))
  VVGuvj.append((VV2Bne + "Edit"     , "m3u_Edit" ))
  VVGuvj.append((VV2Bne + "View"     , "m3u_View" ))
  return VVGuvj
 def VV3uDl(self, path, selFile):
  FFSiXW(self, BF(self.VVVhb2, path, selFile), title="M3U/M3U8 File Options", VVGuvj=self.VVL5fO())
 def VVVhb2(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF4idw(self, BF(self.session.open, CCCW9K, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCrb0k(self, path, VVHoAX=self.VVPofr)
   elif item == "m3u_View"  : FFXpyW(self, path)
 def VVpnWI(self, path):
  if fileExists(path) : FF4idw(self, BF(CC7ZOW.VVdRlj, self, path, BF(self.VVCfhS, path)), title="Loading Codecs ...")
  else    : FFJBL5(self, path)
 def VVCfhS(self, path, item=None):
  if item:
   FFXpyW(self, path, encLst=item)
 def VVGxTR(self, path, title, asUtf8):
  if fileExists(path) : FF4idw(self, BF(CC7ZOW.VVdRlj, self, path, BF(self.VVMLdV, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFJBL5(self, path)
 def VVMLdV(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVn1m1(path, title, fromEnc, "UTF-8")
   else  : CC7ZOW.VV28g2(self, BF(self.VVn1m1, path, title, fromEnc), title="Convert to Encoding")
 def VVn1m1(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF4aCb("Successful\n\n", VV1udq)
      txt += FF4aCb("From Encoding (%s):\n" % fromEnc, VVc1MO)
      txt += "%s\n\n" % path
      txt += FF4aCb("To Encoding (%s):\n" % toEnc, VVc1MO)
      txt += "%s\n\n" % outFile
      FFPaL6(self, txt, title=title)
    except:
     FFeF28(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FF1lLq(self, "Cannot open file", 2000)
   self.VVibYx()
 def VV0CqO(self, path):
  title = "File Line-Break Conversion"
  FFZRvh(self, BF(self.VVkOEI, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVkOEI(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF4aCb("File converted:", VV1udq), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFDx6X(self, txt, title=title)
  else:
   FFJBL5(self, path, title=title)
 def VV4rP0(self, path, selFile, newChmod):
  FFZRvh(self, BF(self.VVcBwi, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVcBwi(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVH8C3)
  result = FFGRiq(cmd)
  if result == "Successful" : FFDx6X(self, result)
  else      : FFeF28(self, result)
 def VVWBsB(self, path, selFile):
  parent = FF78Uj(path, False)
  self.session.openWithCallback(self.VVlsvb, BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=parent, VVdjsL="Create Symlink here"))
 def VVlsvb(self, newPath):
  if len(newPath) > 0:
   target = self.VVuhe5(self.VV1uLK())
   target = FFaYmq(target)
   linkName = FFc02K(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFvBW5(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFeF28(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFZRvh(self, BF(self.VVGErq, target, link), "Create Soft Link ?\n\n%s" % txt, VVnBJJ=True)
 def VVGErq(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVH8C3)
  result = FFGRiq(cmd)
  if result == "Successful" : FFDx6X(self, result)
  else      : FFeF28(self, result)
 def VVh06l(self, path, selFile):
  lastPart = FFc02K(path)
  FFrwu2(self, BF(self.VVP7go, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVP7go(self, path, selFile, VVNyo5):
  if VVNyo5:
   parent = FF78Uj(path, True)
   if os.path.isdir(path):
    path = FFaYmq(path)
   newName = parent + VVNyo5
   cmd = "mv '%s' '%s' %s" % (path, newName, VVH8C3)
   if VVNyo5:
    if selFile != VVNyo5:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFZRvh(self, BF(self.VVIpyA, cmd), message, title="Rename file?")
    else:
     FFeF28(self, "Cannot use same name!", title="Rename")
 def VVIpyA(self, cmd):
  result = FFGRiq(cmd)
  if "Fail" in result:
   FFeF28(self, result)
  self.VVibYx()
 def VVUQe8(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVZxS9, title, preserve)
      , VVHoAX = BF(self.VVBYHd, title))
 def VVZxS9(self, title, preserve, VVXuS2):
  totSel = self["myMenu"].VVlcZR()
  totOk = totFail = 0
  VVXuS2.VVhaSh(totSel)
  VVXuS2.VVoBtV = ["", totSel, totOk, totFail, ""]
  VVXuS2.VVvANc("Prepareing targz file")
  curDir = self["myMenu"].VVpbUC()
  lastPart = FFc02K(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVXuS2 or VVXuS2.isCancelled:
      return
     if row[2][6]:
      VVXuS2.VVzPku(1)
      name  = FFaYmq(row[0][0])
      lastPath = FFc02K(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVXuS2:
       VVXuS2.VVoBtV = [outF, totSel, totOk, totFail, path]
       VVXuS2.VV89Ao(totOk, lastPath)
  except:
   totFail += 1
   if VVXuS2:
    VVXuS2.VVoBtV = [outF, totSel, totOk, totFail, path]
 def VVBYHd(self, title, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVoBtV
  txt  = "%s:\n%s\n\n"   % (FF4aCb("Output File", VV1udq), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF4aCb("Failed\t: %d\n" % totFail, VVEkv6)
  if not VV2c9g: txt += "%s\n%s" % (FF4aCb("\nCancelled while copying:", VVEkv6), path)
  FFPaL6(self, txt, title=title)
  self.VVibYx()
 def VVsbWm(self, isMove):
  self.session.openWithCallback(BF(self.VV1Jm7, isMove), BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=self["myMenu"].VVpbUC(), VVdjsL="Move to here" if isMove else "Paste here"))
 def VV1Jm7(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVMip3, title, action, isMove, newPath)
       , VVHoAX = BF(self.VVYYT5, title, action, isMove, newPath))
 def VVMip3(self, title, action, isMove, newPath, VVXuS2):
  curDir = self["myMenu"].VVpbUC()
  totOk = totFail = 0
  totSel = self["myMenu"].VVlcZR()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVXuS2.VVhaSh(totSel)
  VVXuS2.VVoBtV = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVXuS2 or VVXuS2.isCancelled:
    return
   if row[2][6]:
    VVXuS2.VVzPku(1)
    VVXuS2.VVK5Aw(action, totOk, FFc02K(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFc02K(path)
    if os.path.isdir(path): path = FFaYmq(path)
    dest = os.path.join(newPath, lastPart)
    if FF7Jdu("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVXuS2:
     VVXuS2.VVoBtV = [totSel, totOk, totFail, path]
     VVXuS2.VVK5Aw(action, totOk, FFc02K(row[0][0]))
 def VVYYT5(self, title, action, isMove, newPath, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVoBtV
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF4aCb("Failed\t: %d\n" % totFail, VVEkv6)
  if not VV2c9g: txt += "%s\n%s" % (FF4aCb("\nCancelled while copying:", VVEkv6), path)
  FFPaL6(self, txt, title=title)
  self.VVibYx()
 def VVnnGn(self):
  tot = self["myMenu"].VVlcZR()
  FFZRvh(self, BF(FF4idw, self, self.VV2oRj, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFtCOg(tot)), title="Delete Selection")
 def VV2oRj(self):
  path = self["myMenu"].VVpbUC()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFjcWV(os.path.join(path, row[0][0]))
  FF1lLq(self)
  self.VVibYx()
 def VVhoWz(self, path, isMove):
  self.session.openWithCallback(BF(self.VVcH2H, isMove, path), BF(CCZHbk, mode=CCZHbk.VVms2N, VVYYtf=FF78Uj(path, False), VVdjsL="Move to here" if isMove else "Paste here"))
 def VVcH2H(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFaYmq(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFaYmq(src)
  dst = os.path.join(dst, FFc02K(src))
  if src == dst:
   FFeF28(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFZRvh(self, BF(self.VVs4Ed, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFZRvh(self, BF(self.VVs4Ed, prams), "Overwrite Destination Files", title=title)
  else         : self.VVs4Ed(prams)
 def VVs4Ed(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCZHbk.VVfWtD(src) == CCZHbk.VVfWtD(dst):
   FF4idw(self, BF(self.VVP1qV, prams), title="Moving %s ..." % srcSubj)
  else:
   FF4idw(self, BF(self.VVZWqS, prams), title="Calculating Size ...")
 def VVP1qV(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFGRiq("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVibYx()
  else:
   FFeF28(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVZWqS(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFgx6P(src)
  else  : size = FFicDa(src)
  if size > -1:
   self.session.open(CCYPVd, barTheme=CCYPVd.VV3Im3, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVLGTA, prams, size)
       , VVHoAX = BF(self.VVykHk, prams))
  else:
   FFeF28(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVLGTA(self, prams, size, VVXuS2):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVXuS2.VVhaSh(size)
  VVXuS2.VVoBtV = ("", "", False)
  def VV7OJR(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFOHeU(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVXuS2 or VVXuS2.isCancelled:
        VVXuS2.VVoBtV = (srcFile, "", True)
        FFOHeU(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVXuS2.VVzPku(len(data))
       except Exception as e:
        VVXuS2.VVoBtV = (srcFile, str(e), False)
        FFOHeU(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFOHeU(srcFile)
   return True
  if isFile:
   tot = 1
   VV7OJR(src, dst)
  else:
   VVXuS2.VVvANc("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFQkyh(src)
   if not VVXuS2 or VVXuS2.isCancelled:
    VVXuS2.VVoBtV = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVXuS2.VVoBtV = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVXuS2.VVvANc("File: %d/%d >> %s" % (fCount, tot, f))
      if not VV7OJR(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FF7Jdu("rm -fr '%s'" % Dir)
   if isMove:
    FF7Jdu("rm -fr '%s'" % src)
 def VVykHk(self, prams, VV2c9g, VVoBtV, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVoBtV
  if err:
   FFeF28(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FF1lLq(self, "Canelled", 1000)
   else  : FFeF28(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FF1lLq(self, "Done", 1500, isGrn=True)
  if VV2c9g and isMove:
   self.VVibYx()
 def VVCL4A(self, path, fileName):
  path = FFaYmq(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFZRvh(self, BF(FF4idw, self, BF(self.VVeQhd, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVeQhd(self, path):
  FFjcWV(path)
  FF1lLq(self)
  self.VVibYx()
 def VVpqAo(self, path, isFile):
  dirName = FFvBW5(os.path.dirname(path))
  if isFile : objName, VVNyo5 = "File"  , self.edited_newFile
  else  : objName, VVNyo5 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFrwu2(self, BF(self.VVQThc, dirName, isFile, title), title=title, defaultText=VVNyo5, message="Enter %s Name:" % objName)
 def VVQThc(self, dirName, isFile, title, VVNyo5):
  if VVNyo5:
   if isFile : self.edited_newFile = VVNyo5
   else  : self.edited_newDir  = VVNyo5
   path = dirName + VVNyo5
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVH8C3)
    else  : cmd = "mkdir '%s' %s" % (path, VVH8C3)
    result = FFGRiq(cmd)
    if "Fail" in result:
     FFeF28(self, result)
    self.VVibYx()
   else:
    FFeF28(self, "Name already exists !\n\n%s" % path, title)
 def VV1qYn(self, path, selFile):
  c1, c2, c3 = VVE7n3, VV2Bne, VVwWfr
  VVGuvj = []
  VVGuvj.append((c1 + "List Package Files"         , "VVLo4Z"     ))
  VVGuvj.append((c1 + "Package Information"         , "VVIIYk"     ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Install Package"          , "VVP9hZ_CheckVersion" ))
  VVGuvj.append((c2 + "Install Package (force reinstall)"     , "VVP9hZ_ForceReinstall" ))
  VVGuvj.append((c2 + "Install Package (force overwrite)"     , "VVP9hZ_ForceOverwrite" ))
  VVGuvj.append((c2 + "Install Package (force downgrade)"     , "VVP9hZ_ForceDowngrade" ))
  VVGuvj.append((c2 + "Install Package (ignore failed dependencies)"  , "VVP9hZ_IgnoreDepends" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c3 + "Remove Related Package"        , "VVlFdj_ExistingPackage" ))
  VVGuvj.append((c3 + "Remove Related Package (force remove)"    , "VVlFdj_ForceRemove"  ))
  VVGuvj.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVlFdj_IgnoreDepends" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Extract Files"           , "VVINUP"     ))
  VVGuvj.append(("Unbuild Package"           , "VVS5qY"     ))
  FFSiXW(self, BF(self.VVgJ7A, path, selFile), VVGuvj=VVGuvj)
 def VVgJ7A(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVLo4Z"      : self.VVLo4Z(path, selFile)
   elif item == "VVIIYk"      : self.VVIIYk(path)
   elif item == "VVP9hZ_CheckVersion"  : self.VVP9hZ(path, selFile, VVy8Lf     )
   elif item == "VVP9hZ_ForceReinstall" : self.VVP9hZ(path, selFile, VVUhs4 )
   elif item == "VVP9hZ_ForceOverwrite" : self.VVP9hZ(path, selFile, VVnGKI )
   elif item == "VVP9hZ_ForceDowngrade" : self.VVP9hZ(path, selFile, VVZvdb )
   elif item == "VVP9hZ_IgnoreDepends" : self.VVP9hZ(path, selFile, VVvSBf )
   elif item == "VVlFdj_ExistingPackage" : self.VVlFdj(path, selFile, VVK3Uz     )
   elif item == "VVlFdj_ForceRemove"  : self.VVlFdj(path, selFile, VV3cr8  )
   elif item == "VVlFdj_IgnoreDepends"  : self.VVlFdj(path, selFile, VVphKS )
   elif item == "VVINUP"     : self.VVINUP(path, selFile)
   elif item == "VVS5qY"     : self.VVS5qY(path, selFile)
 def VVLo4Z(self, path, selFile):
  if FFGbNH("ar") : cmd = "allOK='1';"
  else    : cmd  = FF6BOQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF9aYq(self, cmd, VVdenE=self.VVibYx)
 def VVINUP(self, path, selFile):
  lastPart = FFc02K(path)
  dest  = FF78Uj(path, True) + selFile[:-4]
  cmd  =  FF6BOQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFTMeZ("mkdir '%s'" % dest)
  cmd +=    FFTMeZ("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFlTM0(dest, VV1udq))
  cmd += "fi;"
  FF1NOx(self, cmd, VVdenE=self.VVibYx)
 def VVS5qY(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVl3lL = os.path.splitext(path)[0]
  else        : VVl3lL = path + "_"
  if path.endswith(".deb")   : VVToy6 = "DEBIAN"
  else        : VVToy6 = "CONTROL"
  cmd  = FF6BOQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVl3lL
  cmd += "  mkdir '%s';"      % VVl3lL
  cmd += "  CONTPATH='%s/%s';"    % (VVl3lL, VVToy6)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVl3lL
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVl3lL, VVl3lL)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVl3lL
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVl3lL, VVl3lL)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVl3lL
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVl3lL
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVl3lL, FFlTM0(VVl3lL, VV1udq))
  cmd += "fi;"
  FF1NOx(self, cmd, VVdenE=self.VVibYx)
 def VVIIYk(self, path):
  listCmd  = FFnws9(VVNP8B, "")
  infoCmd  = FFNCOV(VVSyHw , "")
  filesCmd = FFNCOV(VVpsdf, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFl8Lk(VVc1MO)
   notInst = "Package not installed."
   cmd  = FFCIAK("File Info", VVc1MO)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFCIAK("System Info", VVc1MO)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFlTM0(notInst, VVEkv6))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFCIAK("Related Files", VVc1MO)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFbHAT(self, cmd)
  else:
   FFDayU(self)
 def VVP9hZ(self, path, selFile, cmdOpt):
  cmd = FFNCOV(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFZRvh(self, BF(FF1NOx, self, cmd, VVdenE=FFWolN), "Install Package ?\n\n%s" % selFile)
  else:
   FFDayU(self)
 def VVlFdj(self, path, selFile, cmdOpt):
  listCmd  = FFnws9(VVNP8B, "")
  infoCmd  = FFNCOV(VVSyHw, "")
  instRemCmd = FFNCOV(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFlTM0(errTxt, VVEkv6))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFlTM0(cannotTxt, VVEkv6))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFlTM0(tryTxt, VVEkv6))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFZRvh(self, BF(FF1NOx, self, cmd, VVdenE=FFWolN), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFDayU(self)
 def VVdVOr(self, path):
  hostName = FFGRiq("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV9iIj(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVGuvj = []
  VVGuvj.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVGuvj.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVGuvj.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVGuvj.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVGuvj.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVGuvj.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVGuvj.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVGuvj.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVGuvj.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVGuvj.append(VVnek4)
   VVGuvj.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVGuvj.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFSiXW(self, BF(self.VVZHA5, path, isDir, title), VVGuvj=VVGuvj, title=title, VVmEJ8=c1, VVd8a3=c2)
 def VVZHA5(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVER5E(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVER5E(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVER5E(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVER5E(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVER5E(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVER5E(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVER5E(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVER5E(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVER5E(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVER5E(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVKTxv(path, False)
   elif item == "convertDirToDeb" : self.VVKTxv(path, True)
 def VVKTxv(self, path, VVB3L1):
  self.session.openWithCallback(self.VVibYx, BF(CC5LSv, path=path, VVB3L1=VVB3L1))
 def VVER5E(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FF78Uj(path, True)
  lastPart = FFc02K(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFf1mi("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFf1mi("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFf1mi("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFTMeZ("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFlTM0(failed, VVT2Mp))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFlTM0(srcTxt, VVrWwc))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFlTM0("Output", VV1udq))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFlTM0(failed, VVs795))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF9aYq(self, cmd, VVdenE=self.VVibYx, title=title)
 def VVwIUv(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCZHbk.VVmHPC(FF78Uj(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCQrUI(self, self, title, BF(self.VVnhYQ, pathLst))
 def VVnhYQ(self, pathLst):
  return CCQrUI.VVwQPo(pathLst)
 def VVHebP(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVM604, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZRvh(self, BF(FF4idw, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF4idw(self, fnc, title=txt)
  else:
   FFeF28(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVM604(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFPaL6(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVibYx()
  else:
   FFOHeU(tarPath)
   FFeF28(self, "Error while converting.", title=title)
 def VVk1n6(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVKp4X, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZRvh(self, BF(FF4idw, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF4idw(self, fnc, title=txt)
  else:
   FFeF28(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVKp4X(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFPaL6(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVibYx()
  else:
   FFOHeU(zipPath)
   FFeF28(self, "Error while converting.", title=title)
 def VVmYvL(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFvBW5(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FF7Jdu("rm -f '%s' '%s'" % (m1v, mvi))
  if FF7Jdu("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FF7Jdu("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVibYx()
   FFDx6X(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFeF28(self, "Cannot convert this file !", title=title)
 def VV0ta0(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCnBmO.VVYQsq()
  if pathExists(pPath):
   if CCzLkW.VVcpMs(self, title, False, cbFnc=BF(self.VV0ta0, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVGuvj = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVGuvj.append(("%d x %d" % (item), item))
    VVrN3L = self.VVMmv6
    VVLIPG = ("Stretch", BF(self.VVYrs4, title, path, picon))
    VVUD8b = FFSiXW(self, BF(self.VV8VOJ, title, path, picon, False), VVGuvj=VVGuvj, width=700, title='PIcon Max. Size', VVrN3L=VVrN3L, VVLIPG=VVLIPG, barText="OK = Fit within size")
    VVUD8b.VVn6An(3)
  else:
   FFeF28(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVYrs4(self, title, path, picon, selectionObj, item):
  self.VV8VOJ(title, path, picon, True, item)
  selectionObj.cancel()
 def VV8VOJ(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFw3XJ(self, fncMode=CCM3PM.VVyGH2)
   except Exception as e:
    FFeF28(self, "Image Processing error:\n\n%s" % e)
 def VVMmv6(self, VVUD8b, txt, ref, ndx):
  FF9ePp(self, "_help_resize", "Picture File Resizing")
 def VVRlmo(self, path):
  FFSiXW(self, BF(self.VVfv72, path), VVGuvj=CCCW9K.VVUruy(), width=650, title="Select Player", VVmEJ8="#11220000", VVd8a3="#11220000")
 def VVfv72(self, path, rType=None):
  if rType:
   FF4idw(self, BF(self.VVrMz7, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVrMz7(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCP76G.VVBpiW(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVuryx(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFvBW5(fDir), fName
  return "", "", ""
 @staticmethod
 def VVGOxo(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV0ZbU(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVi3go(size, mode=0):
  txt = CCZHbk.VVJwfV(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVJwfV(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVdHnF(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVWzKq(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFeF28(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV95Jc():
  tDict = CCw3cf.VV81Gw()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVmHPC(path):
  lst = []
  for ext in CCZHbk.VV95Jc():
   lst.extend(FF2oot(path, "*.%s" % ext))
  return sorted(lst, key=FFUUI3(FF0T2Q))
 @staticmethod
 def VVFwUk(path):
  return FF7Jdu("tar -tzf '%s'" % path)
 @staticmethod
 def VVfWtD(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVdoWo(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVUY2M:
   return VVUY2M
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCw3cf(MenuList):
 VVAxM4   = 0
 VVd26T   = 1
 VVlCOY   = 2
 VVye2v   = 3
 VVxjyb   = 4
 VVXQiX   = 5
 VVC8bh   = 6
 VVhpcf   = 7
 VVp2ov   = "<List of Storage Devices>"
 VVjFjK  = "<Parent Directory>"
 VVfISv   = 0
 VVieC6   = 1
 VVMV0X = 2
 VVIIOO  = 3
 VV1Hj5   = 4
 VVS1yZ   = 5
 FILE_TYPE_LINK   = 6
 VVWzYj  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VV3ElW=False, directory="/", VVEqvN=True, VVFnJB=True, VV8rNN=True, VVcmVL=None, VVODDu=False, VV0XsX=False, VVU2Zj=False, isTop=False, VVH88Q=None, VVXvTn=1000, VVCppa=30, VVQSWB=30):
  MenuList.__init__(self, list, VV3ElW, eListboxPythonMultiContent)
  self.VVEqvN  = VVEqvN
  self.VVFnJB    = VVFnJB
  self.VV8rNN  = VV8rNN
  self.VVcmVL  = VVcmVL
  self.VVODDu   = VVODDu
  self.VV0XsX   = VV0XsX or []
  self.VVU2Zj   = VVU2Zj or []
  self.isTop     = isTop
  self.additional_extensions = VVH88Q
  self.VVXvTn    = VVXvTn
  self.VVCppa    = VVCppa
  self.VVQSWB    = VVQSWB
  self.EXTENSIONS    = CCw3cf.VV81Gw()
  self.VVlOe7   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFrS08("#11ff4444")
  self.l.setFont(0, gFont(VVIXst, self.VVCppa))
  self.l.setItemHeight(self.VVQSWB)
  self.png_mem   = CCw3cf.VVtvNC("mem")
  self.png_usb   = CCw3cf.VVtvNC("usb")
  self.png_fil   = CCw3cf.VVtvNC("fil")
  self.png_dir   = CCw3cf.VVtvNC("dir")
  self.png_dirup   = CCw3cf.VVtvNC("dirup")
  self.png_srv   = CCw3cf.VVtvNC("srv")
  self.png_slwfil   = CCw3cf.VVtvNC("slwfil")
  self.png_slbfil   = CCw3cf.VVtvNC("slbfil")
  self.png_slwdir   = CCw3cf.VVtvNC("slwdir")
  self.VVDjwH()
  self.VVcIXR(directory)
 @staticmethod
 def VVtvNC(category):
  return LoadPixmap("%s%s.png" % (VVqXR1, category), getDesktop(0))
 @staticmethod
 def VV81Gw():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"p7z":("7z"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVcoDZ(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFaYmq(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF4aCb(" -> " , VVc1MO) + FF4aCb(os.readlink(path), VV1udq)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVQSWB + 10, 0, self.VVXvTn, self.VVQSWB, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCaEfF.VVVu2y(0, 2, self.VVQSWB-4, self.VVQSWB-4, png))
  return tableRow
 def VVd5ri(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVDjwH(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVKJ5j(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVbf69(self, file):
  if os.path.realpath(file) == file:
   return self.VVKJ5j(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVKJ5j(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVKJ5j(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVPdHm(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VV3IKF(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVBMXJ(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VV3IKF(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VV3IKF(self, row, bg):
  if self.VVG4fL(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVG4fL(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVS1yZ, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VV1Hj5:
    if   VVTypc           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVbuAc(self):
  return self.VVG4fL(self.list[self.l.getCurrentSelectionIndex()])
 def VVlcZR(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVN7I9(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVcIXR(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV8rNN:
    self.current_mountpoint = self.VVbf69(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV8rNN:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVU2Zj and not self.VVN7I9(path, self.VV0XsX):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVcoDZ(name=p.description, absolute=path, isDir=True, typ=self.VVfISv, png=png))
    path = "/"
    if path not in self.VVU2Zj and not self.VVN7I9(path, self.VV0XsX):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVcoDZ(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVieC6, png=self.png_mem))
  elif self.VVODDu:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVlOe7 = eServiceCenter.getInstance()
   list = VVlOe7.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVEqvN and not self.isTop:
   if directory == self.current_mountpoint and self.VV8rNN:
    self.list.append(self.VVcoDZ(name=self.VVp2ov, absolute=None, isDir=True, typ=self.VVMV0X, png=self.png_dirup))
   elif (directory != "/") and not (self.VVU2Zj and self.VVKJ5j(directory) in self.VVU2Zj):
    self.list.append(self.VVcoDZ(name=self.VVjFjK, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVIIOO, png=self.png_dirup))
  if self.VVEqvN:
   for x in directories:
    if not (self.VVU2Zj and self.VVKJ5j(x) in self.VVU2Zj) and not self.VVN7I9(x, self.VV0XsX):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVcoDZ(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFaYmq(x)) else self.VV1Hj5, png=png))
  if self.VVFnJB:
   for x in files:
    if self.VVODDu:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FF4aCb(" -> " , VVc1MO) + FF4aCb(target, VV1udq)
       else:
        png = self.png_slbfil
        name += FF4aCb(" -> " , VVc1MO) + FF4aCb(target, VVs795)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVd5ri(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVqXR1, category))
    if (self.VVcmVL is None) or iCompile(self.VVcmVL[0], flags=self.VVcmVL[1]).search(path):
     self.list.append(self.VVcoDZ(name=name, absolute=x , isDir=False, typ=self.VVS1yZ, png=png))
  if self.VV8rNN and len(self.list) == 0:
   self.list.append(self.VVcoDZ(name=FF4aCb("No USB connected", VVE7tQ), absolute=None, isDir=False, typ=self.VVWzYj, png=self.png_usb))
  self.l.setList(self.list)
  self.VVAfSE()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVpbUC(self):
  return self.current_directory
 def VVsdLP(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVNDF8(self):
  return self.VVWt1S() and self.VVpbUC()
 def VVWt1S(self):
  return self.list[0][1][7] in (self.VVp2ov, self.VVjFjK)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVcIXR(self.getSelection()[0], self.current_directory)
 def VVnfR9(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVHCr6)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVHCr6)
 def VVHCr6(self, action, device):
  self.VVDjwH()
  if self.current_directory is None:
   self.VVfX0C()
 def VVfX0C(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVcIXR(self.current_directory, self.VVnfR9())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVCGw9(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVAxM4 : nameAlpMode, nameAlpTxt = self.VVd26T, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVAxM4, sAZ
  if mode == self.VVlCOY : nameNumMode, nameNumTxt = self.VVye2v, s90
  else       : nameNumMode, nameNumTxt = self.VVlCOY, s09
  if mode == self.VVxjyb : dateMode, dateTxt = self.VVXQiX, sON
  else       : dateMode, dateTxt = self.VVxjyb, sNO
  if mode == self.VVC8bh : typeMode, typeTxt = self.VVhpcf, sZA
  else       : typeMode, typeTxt = self.VVC8bh, sAZ
  if   mode in (self.VVAxM4, self.VVd26T): txt = "Name (%s)" % (sAZ if mode == self.VVAxM4 else sZA)
  elif mode in (self.VVlCOY, self.VVye2v): txt = "Name (%s)" % (s09 if mode == self.VVAxM4 else s90)
  elif mode in (self.VVxjyb, self.VVXQiX): txt = "Date (%s)" % (sNO if mode == self.VVxjyb else sON)
  elif mode in (self.VVC8bh, self.VVhpcf): txt = "Type (%s)" % (sAZ if mode == self.VVC8bh else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVAfSE(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFCRXL(CFG.browserSortMode, mode)
   FFCRXL(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVWt1S() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVAxM4, self.VVd26T):
    rev = True if mode == self.VVd26T else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVlCOY, self.VVye2v):
    rev = True if mode == self.VVye2v else False
    self.list = sorted(self.list[item0:], key=FFUUI3(BF(self.VVjM2H, isMix, rev)), reverse=rev)
   elif mode in (self.VVxjyb, self.VVXQiX):
    rev = True if mode == self.VVXQiX else False
    self.list = sorted(self.list[item0:], key=FFUUI3(BF(self.VVhOaF, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVhpcf else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVjM2H(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FF0T2Q(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFR4NJ(dir2, dir1) or FF0T2Q(name1, name2)
 def VVhOaF(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFR4NJ(stat2.st_ctime, stat1.st_ctime)
    else : return FFR4NJ(dir2, dir1) or FFR4NJ(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCx0wY(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFhwpa(VVEGmB, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVWhjq   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VV2erv(defFG, "#00FFFFFF")
  self.defBG   = self.VV2erv(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFOUwv(self, self.Title)
  self["keyRed"].show()
  FFtNax(self["keyGreen"] , "< > Transp.")
  FFtNax(self["keyYellow"], "Foreground")
  FFtNax(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "ok"   : self.VViNHE     ,
   "green"   : self.VViNHE     ,
   "yellow"  : BF(self.VV8OuO, False)  ,
   "blue"   : BF(self.VV8OuO, True)  ,
   "up"   : self.VVrXee       ,
   "down"   : self.VVraks      ,
   "left"   : self.VVUT8S      ,
   "right"   : self.VVeKbm      ,
   "last"   : BF(self.VVQCf7, -5) ,
   "next"   : BF(self.VVQCf7, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVy4Yl)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFBHn2(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFBHn2(self["keyRed"] , c)
  FFBHn2(self["keyGreen"] , c)
  self.VV3c5E()
  self.VVKeIM()
  FFeyAJ(self["myColorTst"], self.defFG)
  FFBHn2(self["myColorTst"], self.defBG)
 def VV2erv(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVKeIM(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV9aPa(0, 0)
     return
 def VViNHE(self):
  self.close(self.defFG, self.defBG)
 def VVrXee(self): self.VV9aPa(-1, 0)
 def VVraks(self): self.VV9aPa(1, 0)
 def VVUT8S(self): self.VV9aPa(0, -1)
 def VVeKbm(self): self.VV9aPa(0, 1)
 def VV9aPa(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVEyJY()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVQNp3()
 def VV3c5E(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVQNp3(self):
  color = self.VVEyJY()
  if self.isBgMode: FFBHn2(self["myColorTst"], color)
  else   : FFeyAJ(self["myColorTst"], color)
 def VV8OuO(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VV3c5E()
   self.VVKeIM()
 def VVQCf7(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV9aPa(0, 0)
 def VVYCw9(self):
  return hex(self.transp)[2:].zfill(2)
 def VVEyJY(self):
  return ("#%s%s" % (self.VVYCw9(), self.colors[self.curRow][self.curCol])).upper()
class CCHdbR(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhwpa(VVeieW, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFOUwv(self, title="%s%s%s" % (self.Title, " " * 10, FF4aCb("Change values with Up , Down, < , 0 , >", VVE7tQ)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VV0Gk9,
  {
   "ok"  : self.VVTQe0      ,
   "cancel" : self.VV7Dit      ,
   "info"  : self.VVzDHp    ,
   "red"  : self.VVYV62  ,
   "green"  : self.VVRG40   ,
   "yellow" : BF(self.VVKH8j, 0)  ,
   "blue"  : self.VVJWBB    ,
   "menu"  : self.VVMYtJ      ,
   "left"  : self.VVUT8S      ,
   "right"  : self.VVeKbm      ,
   "last"  : self.VVHo42     ,
   "next"  : self.VVQvmE     ,
   "0"   : self.VVnX06    ,
   "up"  : self.VVrXee       ,
   "down"  : self.VVraks      ,
   "pageUp" : BF(self.VVSgof, True) ,
   "pageDown" : BF(self.VVSgof, False) ,
   "chanUp" : BF(self.VVSgof, True) ,
   "chanDown" : BF(self.VVSgof, False) ,
   "play"  : BF(self.VV1V5G, "pause")  ,
   "pause"  : BF(self.VV1V5G, "pause")  ,
   "playPause" : BF(self.VV1V5G, "pause")  ,
   "stop"  : BF(self.VV1V5G, "pause")  ,
   "audio"  : BF(self.VV1V5G, "audio")  ,
   "subtitle" : BF(self.VV1V5G, "subtitle") ,
   "rewind" : BF(self.VV1V5G, "rewind" ) ,
   "forward" : BF(self.VV1V5G, "forward" ) ,
   "rewindDm" : BF(self.VV1V5G, "rewindDm") ,
   "forwardDm" : BF(self.VV1V5G, "forwardDm")
  }, -1)
  self.VVHyqf()
  self.onShown.append(self.VVy4Yl)
  self.onClose.append(self.VV1eu7)
 def VVHyqf(self):
  lst = []
  for fil in FF2oot(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVgRwY:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVy4Yl(self):
  self.onShown.remove(self.VVy4Yl)
  FFimE3(self)
  FFRBDi(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVNQnK()
  self.VVyOXa()
  self.VVJxEb()
 def VV1eu7(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VV6SKA(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFBHn2(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVHKwo()
 def VVNQnK(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFBHn2(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVTQe0(self):
  if self.settingShown:
   confItem = self.VVwhEC()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVGuvj = []
   if isinstance(lst[0], tuple): VVGuvj = [(x[1], x[0]) for x in lst]
   else      : VVGuvj = [(x, x) for x in lst]
   VVUD8b = FFSiXW(self, self.VVD2jN, VVGuvj=VVGuvj, width=700, title=title, VVmEJ8="#33221111", VVd8a3="#33110011")
   VVUD8b.VVgve4(confItem.getText())
  else:
   self.close("subtExit")
 def VVD2jN(self, item=None):
  if item:
   self.VVwhEC()[self.CursorPos].setValue(item)
   self.VVHKwo()
   self.VVyOXa()
   self.VVRiUg(True)
 def VV7Dit(self):
  for confItem in self.VVwhEC():
   if confItem.isChanged():
    FFZRvh(self, BF(self.VV1H4d, cbFnc=self.VVWCAv), "Save Changes ?", callBack_No=self.VVDLyk, title=self.Title)
    break
  else:
   self.VVWCAv()
 def VVWCAv(self):
   if self.settingShown: self.VVNQnK()
   else    : self.close("subtExit")
 def VVMYtJ(self):
  if self.settingShown: self.VV5q7h()
  else    : self.VV6SKA()
 def VVUT8S(self): self.VVDfN9(-1)
 def VVeKbm(self): self.VVDfN9(1)
 def VVDfN9(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVOwkr()
   if pos == -1: ndx = self.VV5kcV(posVal)
   else  : ndx = self.VV5y6Y(posVal)
   if   ndx < 0      : FF1lLq(self, "Not found" , 500)
   elif ndx == 0      : FF1lLq(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FF1lLq(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVxbBQ(frmSec)
    if allow:
     self.VVKH8j(delay, True)
     self.VVRiUg(force=True)
     CCJ2zH(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FF1lLq(self, "Delay out of range", 800)
 def VVSgof(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV1V5G(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVHo42(self) : self.VVWJox(5)
 def VVQvmE(self) : self.VVWJox(6)
 def VVnX06(self) : self.VVWJox(-1)
 def VVrXee(self):
  if self.settingShown: self.VVWJox(1)
  else    : self.VVSgof(True)
 def VVraks(self):
  if self.settingShown: self.VVWJox(0)
  else    : self.VVSgof(False)
 def VVWJox(self, direction):
  if self.settingShown:
   confItem = self.VVwhEC()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVHKwo()
   self.VVyOXa()
   self.VVRiUg(True)
 def VVwhEC(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVDLyk(self):
  for confItem in self.VVwhEC(): confItem.cancel()
  self.VVHKwo()
  self.VVyOXa()
  self.VVNQnK()
 def VVYV62(self):
  if self.settingShown:
   FFZRvh(self, self.VV8kEC, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV8kEC(self):
  for confItem in self.VVwhEC(): confItem.setValue(confItem.default)
  self.VV1H4d()
  self.VVHKwo()
  self.VVyOXa()
 def VVKH8j(self, delay, force=False):
  if self.settingShown or force:
   FFCRXL(CFG.subtDelaySec, delay)
   self.VVbz6C()
   self.VVHKwo()
   self.VVyOXa()
   if self.settingShown:
    FF1lLq(self, 'Reset to "0"', 800, isGrn=True)
 def VVRG40(self):
  if self.settingShown:
   self.VV1H4d()
   self.VVNQnK()
 def VV1H4d(self, cbFnc=None):
  for confItem in self.VVwhEC(): confItem.save()
  configfile.save()
  self.VVbz6C()
  FF1lLq(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVHKwo(self):
  cfgLst = self.VVwhEC()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVyOXa(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFrEiv(path, fnt, isRepl=1)
  else:
   fnt = VVIXst
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFpwm6(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFeyAJ(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFBHn2(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFCRJG(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFpwm6(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFpkpy()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFgPni(self, winW, winH)
 def VVzDHp(self):
  sp = "    "
  txt  = "%s\n"   % FF4aCb("Subtitle File:", VV2Bne)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF4aCb("Subtitle Settings:", VV2Bne)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVOwkr()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFZ4gz(frmSec1)
   time2 = FFZ4gz(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF4aCb("Timing:", VV2Bne)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFZ4gz(durVal)
   txt += sp + "Progress\t: %s\n" % FFZ4gz(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF4aCb("Subtitle end reached.", VVT2Mp)
  FFPaL6(self, txt, title="Current Subtitle")
 def VVJxEb(self, path="", delay=0, enc=""):
  FF4idw(self, BF(self.VVgmBm, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVgmBm(self, path="", delay=0, enc=""):
  FF1lLq(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVNBk0(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVHKwo()
     self.VV6FVG()
   else:
    path, delay, enc = CCHdbR.VVtd23(self)
    if path:
     self.VVJxEb(path=path, delay=delay, enc=enc)
    else:
     self.VV5q7h()
  except:
   pass
 def VV6FVG(self):
  posVal, durVal = self.VVOwkr()
  if self.VV8vOu(posVal):
   return
  CCHdbR.VVj1jR(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVRiUg)
  except:
   self.timerUpdate.callback.append(self.VVRiUg)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVWJqf)
  except:
   self.timerEndText.callback.append(self.VVWJqf)
  FF1lLq(self, "Subtitle started", 700, isGrn=True)
 def VV8vOu(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCHdbR.VVUz8Y(self)
   FFOHeU(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV5q7h(self):
  c1, c2, c3, c4, c5 = "", VV2Bne, VVXSg2, VVwWfr, VVT2Mp
  VVGuvj = []
  VVGuvj.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVGuvj.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVGuvj.append(VVnek4)
  VVGuvj.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVGuvj.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVGuvj.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVGuvj.append(VVnek4)
   VVGuvj.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVGuvj.append(VVnek4)
   VVGuvj.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVGuvj.append(VVnek4)
   VVGuvj.append(("Help (Keys)"        , "help"  ))
  FFSiXW(self, self.VVlhHa, VVGuvj=VVGuvj, width=700, title='Find Subtitle ".srt" File', VVmEJ8="#33221111", VVd8a3="#33110011")
 def VVlhHa(self, item=None):
  if item:
   if   item == "allSrt"   : self.VV0htq(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VV0htq(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VV8sX8, BF(CCZHbk, patternMode="srt", VVYYtf=sDir))
   elif item.startswith("sugSrt") : self.VV0htq(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF4idw(self, BF(CC7ZOW.VVdRlj, self, self.lastSubtFile, self.VVhq4T, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FF1lLq(self, "SRT File error", 1000)
   elif item == "disab":
    FFOHeU(CCHdbR.VVUz8Y(self))
    self.close("subtExit")
   elif item == "help"    : FF9ePp(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVhq4T(self, item=None):
  if item:
   FF4idw(self, BF(self.VVJxEb, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VV8sX8(self, path):
  if path:
   FFCRXL(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVJxEb(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VV0htq(self, defSrt="", mode=0, coeff=0.25):
  FF4idw(self, BF(self.VVlJyY, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVlJyY(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCHdbR.VVvmbc(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFkrzQ('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFOG94(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVZyue(srtList, coeff)
     if err:
      if self.settingShown: FFFSea(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVJpUa = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFvBW5(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVJpUa.append((fName, Dir))
   VVrjyr  = ("Select"    , self.VV24f7     , [])
   VVJlHN = self.VVX4Vi
   VVGySq = (""     , self.VVuNev       , [])
   VViila = (""     , BF(self.VVeMbb, defSrt, False) , [])
   VVdyRp = ("Find Current File" , BF(self.VVeMbb, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVmQwL=widths, VVCppa=28, VVrjyr=VVrjyr, VVJlHN=VVJlHN, VVGySq=VVGySq, VViila=VViila, VVdyRp=VVdyRp, lastFindConfigObj=CFG.lastFindSubtitle
     , VVmEJ8="#11002222", VVd8a3="#33001111", VVcGiE="#33001111", VVSaWg="#11ffff00", VVh96o="#11445544", VV5t00="#22222222", VVO2zv="#11002233")
  elif self.settingShown : FFFSea(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVX4Vi(self, VVgAw8):
  VVgAw8.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVuNev(self, VVgAw8, title, txt, colList):
  fName, Dir = colList
  FFPaL6(VVgAw8, "%s\n\n%s%s" % (FF4aCb("Path:", VV2Bne), Dir, fName), title=title)
 def VVeMbb(self, path, VVhghQ, VVgAw8, title, txt, colList):
  for ndx, row in enumerate(VVgAw8.VVYgJy()):
   if path == row[1].strip() + row[0].strip():
    VVgAw8.VVAGTP(ndx)
    break
  else:
   if VVhghQ:
    FF1lLq(VVgAw8, "Not in list !", 1000)
 def VV24f7(self, VVgAw8, title, txt, colList):
  VVgAw8.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVJxEb(path=path)
 def VVZyue(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTnwS.VVO3yi(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCTnwS.VVyOnl(evName, "en")[0] or evName
   lst, err = CCHdbR.VVfbNc(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVNBk0(self, path, enc=None):
  if enc and CC7ZOW.VVJ3oI(path, enc)      : enc = enc
  elif CC7ZOW.VVJ3oI(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFgx6P(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF8p4l(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVWtYd(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVT1yq(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVbz6C()
  return subtList, ""
 def VVT1yq(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVWtYd(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVbz6C(self):
  path = CCHdbR.VVUz8Y(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVRiUg(self, force=False):
  posVal, durVal = self.VVOwkr()
  if self.VV8vOu(posVal):
   return
  curIndex = self.VVn7Ca(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVWJqf()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFeyAJ(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVOwkr(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCP76G.VVj3jD(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTnwS.VVO3yi(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVn7Ca(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VV5kcV(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV5y6Y(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVWJqf(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFeyAJ(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVJWBB(self):
  FF4idw(self, self.VVKHRK, title="Loading Lines ...")
 def VVKHRK(self):
  VVJpUa = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVJpUa.append((cap, FFZ4gz(frm), str(frm), firstLine))
  if VVJpUa:
   title = "Select Current Subtitle Line"
   VV9B40  = self.VV7UHG
   VVJlHN = self.VVGxzs
   VVrjyr  = ("Select"   , self.VVM2pQ , [title])
   VVdyRp = ("Current Line" , self.VVk2sR , [True])
   VVpxmm = ("Reset Delay" , self.VVUcN9 , [])
   VV1SrQ = ("New Delay"  , self.VVrwZK   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVRYg6  = (CENTER , CENTER, CENTER , LEFT    )
   VVgAw8 = FFBxNx(self, None, title=title, header=header, VVWhjq=VVJpUa, VVRYg6=VVRYg6, VVmQwL=widths, VVCppa=28, VV9B40=VV9B40, VVJlHN=VVJlHN, VVrjyr=VVrjyr, VVdyRp=VVdyRp, VVpxmm=VVpxmm, VV1SrQ=VV1SrQ
          , VVmEJ8="#33002222", VVd8a3="#33001111", VVcGiE="#33110011", VVSaWg="#11ffff00", VVh96o="#0a334455", VV5t00="#22222222", VVO2zv="#33002233")
  else:
   FFFSea(self, "Cannot read lines !", 2000)
 def VV7UHG(self, VVgAw8):
  self.subtLinesTable = VVgAw8
  if CFG.subtDelaySec.getValue():
   VVgAw8["keyYellow"].show()
   VVgAw8["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVgAw8["keyYellow"].hide()
  VVgAw8["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFBHn2(VVgAw8["keyBlue"], "#22222222")
  VVgAw8.VVbjQL(BF(self.VVGkP2, VVgAw8))
  self.VVk2sR(VVgAw8, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVgjvn)
  except:
   self.timerSubtLines.callback.append(self.VVgjvn)
  self.timerSubtLines.start(1000, False)
 def VVGxzs(self, VVgAw8):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVgAw8.cancel()
 def VVgjvn(self):
  if self.subtLinesTable:
   VVgAw8 = self.subtLinesTable
   posVal, durVal = self.VVOwkr()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVn7Ca(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVgAw8.VVxnif(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVgAw8.VV9eWy(self.subtLinesTableNdx, row)
     row = VVgAw8.VVxnif(curIndex)
     row[0] = color + row[0]
     VVgAw8.VV9eWy(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVM2pQ(self, VVgAw8, Title):
  delay, color, allow = self.VVIB7R(VVgAw8)
  if allow:
   self.VVGxzs(VVgAw8)
   self.VVKH8j(delay, True)
  else:
   FF1lLq(VVgAw8, "Delay out of range", 1500)
 def VVk2sR(self, VVgAw8, VVhghQ, onlyColor=False):
  if VVgAw8:
   posVal, durVal = self.VVOwkr()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVn7Ca(posVal)
    if curIndex > -1:
     VVgAw8.VVAGTP(curIndex)
    else:
     ndx = self.VV5kcV(posVal)
     if ndx > -1:
      VVgAw8.VVAGTP(ndx)
 def VVUcN9(self, VVgAw8, title, txt, colList):
  if VVgAw8["keyYellow"].getVisible():
   self.VVKH8j(0, True)
   VVgAw8["keyYellow"].hide()
   self.VVk2sR(VVgAw8, False)
 def VVGkP2(self, VVgAw8):
  delay, color, allow = self.VVIB7R(VVgAw8)
  VVgAw8["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVIB7R(self, VVgAw8):
  lineTime = float(VVgAw8.VVi9QZ()[2].strip())
  return self.VVxbBQ(lineTime)
 def VVxbBQ(self, lineTime):
  posVal, durVal = self.VVOwkr()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVE7n3
   else     : allow, color = False, VVT2Mp
   delay = FFxrfM(val, -600, 600)
  return delay, color, allow
 def VVrwZK(self, VVgAw8, title, txt, colList):
  pass
 @staticmethod
 def VVH99P(SELF):
  path, delay, enc = CCHdbR.VVtd23(SELF)
  return True if path else False
 @staticmethod
 def VVtd23(SELF):
  path, delay, enc = CCHdbR.VV5AH7(SELF)
  if not path:
   path = CCHdbR.VVuAuU(SELF)
  return path, delay, enc
 @staticmethod
 def VV5AH7(SELF):
  srtCfgPath = CCHdbR.VVUz8Y(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF8p4l(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVUz8Y(SELF):
  fPath, fDir, fName = CCZHbk.VVuryx(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTnwS.VVO3yi(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFwQYn(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVuAuU(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCZHbk.VVuryx(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCHdbR.VVvmbc(SELF)
    bLst, err = CCHdbR.VVfbNc(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVvmbc(SELF):
  fPath, fDir, fName = CCZHbk.VVuryx(SELF)
  if pathExists(fDir):
   files = FF2oot(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVfbNc(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVcnDx():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVj1jR(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCHdbR.VVSp0B()
 @staticmethod
 def VVSp0B():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCtpCB(ScrollLabel):
 def __init__(self, parentSELF, text="", VVxGfl=True):
  ScrollLabel.__init__(self, text)
  self.VVxGfl   = VVxGfl
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVp72Y  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVCppa    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VV0Gk9,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVbh2J ,
   "green"   : self.VVOkC9 ,
   "yellow"  : self.VVY6gS ,
   "blue"   : self.VVX4NI ,
   "up"   : self.VVgc5l   ,
   "down"   : self.VVoamW  ,
   "left"   : self.VVgc5l   ,
   "right"   : self.VVoamW  ,
   "last"   : BF(self.VVH8cJ, 0) ,
   "0"    : BF(self.VVH8cJ, 1) ,
   "next"   : BF(self.VVH8cJ, 2) ,
   "pageUp"  : self.VVhJtq   ,
   "chanUp"  : self.VVhJtq   ,
   "pageDown"  : self.VVkClb   ,
   "chanDown"  : self.VVkClb
  }, -1)
 def VVyzBh(self, isResizable=True, VVtq78=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFeyAJ(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFBHn2(self.parentSELF["keyRedTop"], "#113A5365")
  FFimE3(self.parentSELF, True)
  self.isResizable = isResizable
  if VVtq78:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVCppa  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFBHn2(self, color)
 def VV5YbJ(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVQSWB  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVQSWB)
  margin   = int(VVQSWB / 6)
  self.pageHeight = int(self.pageLines * VVQSWB)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVp72Y - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVcHjR()
 def VVgc5l(self):
  if self.VVp72Y > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVoamW(self):
  if self.VVp72Y > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVhJtq(self):
  self.setPos(0)
 def VVkClb(self):
  self.setPos(self.VVp72Y-self.pageHeight)
 def VVpWWv(self):
  return self.VVp72Y <= self.pageHeight or self.curPos == self.VVp72Y - self.pageHeight
 def getText(self):
  return self.message
 def VVcHjR(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVp72Y, 3))
   start = int((100 - vis) * self.curPos / (self.VVp72Y - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVXyQm=VVfWzW):
  old_VVpWWv = self.VVpWWv()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVp72Y = self.long_text.calculateSize().height()
   if self.VVxGfl and self.VVp72Y > self.pageHeight:
    self.scrollbar.show()
    self.VVcHjR()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVp72Y))
    self.VVp72Y = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVp72Y))
   else:
    self.scrollbar.hide()
   if   VVXyQm == VVwuXs: self.setPos(0)
   elif VVXyQm == VVy0vq : self.VVkClb()
   elif old_VVpWWv    : self.VVkClb()
 def appendText(self, text, VVXyQm=VVy0vq):
  self.setText(self.message + str(text), VVXyQm=VVXyQm)
 def VVY6gS(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVW42F(size)
 def VVX4NI(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVW42F(size)
 def VVOkC9(self):
  self.VVW42F(self.VVCppa)
 def VVW42F(self, VVCppa):
  self.long_text.setFont(gFont(self.fontFamily, VVCppa))
  self.setText(self.message, VVXyQm=VVfWzW)
  self.VV6qAa()
 def VVH8cJ(self, align):
  self.long_text.setHAlign(align)
 def VVbh2J(self):
  VVGuvj = []
  VVGuvj.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Align Left" , "left" ))
  VVGuvj.append(("Align Center" , "center" ))
  VVGuvj.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVGuvj.append(VVnek4)
   VVGuvj.append((FF4aCb("Save to File", VV2Bne), "save"))
  VVGuvj.append(VVnek4)
  VVGuvj.append(("Keys (Shortcuts)", "help"))
  FFSiXW(self.parentSELF, self.VVzbIP, VVGuvj=VVGuvj, title="Text Option", width=500)
 def VVzbIP(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVH8cJ(0)
   elif item == "center" : self.VVH8cJ(1)
   elif item == "right" : self.VVH8cJ(2)
   elif item == "save"  : self.VV75ch()
   elif item == "help"  : FF9ePp(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VV75ch(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFvBW5(expPath), self.outputFileToSave, FFguCY())
   with open(outF, "w") as f:
    f.write(FFWkM4(self.message))
   FFDx6X(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFeF28(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV6qAa(self, minHeight=0):
  if self.isResizable:
   VVQSWB = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVQSWB * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVp72Y < self.pageHeight:
    textH = max(textH, self.VVp72Y)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
