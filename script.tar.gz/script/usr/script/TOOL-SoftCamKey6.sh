wget -O /etc/tuxbox/config/SoftCam.Key http://novaler.homelinux.com/SoftCam.Key


