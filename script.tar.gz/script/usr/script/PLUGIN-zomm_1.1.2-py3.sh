wget https://dreambox4u.com/emilnabil237/plugins/zoom/installer.sh -O - | /bin/sh


