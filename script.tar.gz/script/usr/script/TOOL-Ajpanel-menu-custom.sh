wget http://dreambox4u.com/emilnabil237/plugins/ajpanel/Ajpanel-menu.sh -O - | /bin/sh

