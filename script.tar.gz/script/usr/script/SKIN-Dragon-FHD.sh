wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/Dragon.sh -qO - | /bin/sh




