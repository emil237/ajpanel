wget http://dreambox4u.com/emilnabil237/script/xtraevent-5.3.sh -O - | /bin/sh









