wget https://dreambox4u.com/emilnabil237/enigma-update/installer.sh -O - | /bin/sh


