wget https://dreambox4u.com/emilnabil237/emu/installer-gosatplus.sh -O - | /bin/sh



