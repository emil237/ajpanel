#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/Belfagor2005/oroscopo_radioitalia/main/installer.sh -O - | /bin/sh