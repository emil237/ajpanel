wget https://dreambox4u.com/emilnabil237/emu/installer-oscamicam.sh -O - | /bin/sh






