cd /tmp
set -e
wget "https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/astra-arm.tar.gz"
wait
tar -xzf astra-arm.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/astra-arm.tar.gz
wait
opkg install https://github.com/emilnabil/channel-emil-nabil/raw/main/astra-sm.ipk
wait
clear
chmod 755 /etc/astra/astra.conf
chmod 755 /etc/astra/abertis
chmod 755 /etc/astra/sysctl.conf
chmod 755 /etc/astra/scripts/abertis
chmod 755 /etc/astra/scripts/astra
chmod 755 /etc/init.d/astra-sm
chmod 755 /usr/bin/bbc_pmt_v6.py
chmod 755 /usr/bin/bbc_pmt_starter.sh
chmod 755 /usr/bin/enigma2_pre_start.sh
echo "   UPLOADED BY  >>>>   EMIL_NABIL "
sleep 4;
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
