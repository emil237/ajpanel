#!/bin/sh

wget -q "--no-check-certificate" http://dreambox4u.com/dreamarabia/Transmission_e2/MoviesManager.sh -O - | /bin/sh