wget https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh -O - | /bin/sh



