wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/novacampro/novacampro.sh -O - | /bin/sh

