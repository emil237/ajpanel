wget https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh -O - | /bin/sh
