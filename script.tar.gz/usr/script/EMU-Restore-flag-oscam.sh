opkg flag user enigma2-plugin-softcams-oscam



