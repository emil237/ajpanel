curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-EUR02020-FHD-N-By-Muaath.sh|sh
