#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/ip2sat/main/installer.sh -O - | /bin/sh