#!/bin/sh
##DESCRIPTION=Activity
top -n1
