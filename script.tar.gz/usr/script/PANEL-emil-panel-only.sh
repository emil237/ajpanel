wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/ajpanel/main/panel-emil-only.sh -O - | /bin/sh
