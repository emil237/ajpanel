wget https://raw.githubusercontent.com/emil237/plugins/jediepgextream/main/installer.sh -O - | /bin/sh
