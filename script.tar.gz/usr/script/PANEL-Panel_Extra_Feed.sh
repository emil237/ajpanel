opkg update

opkg install curl

curl -kLs https://dreambox4u.com/emilnabil237/plugins/panel-extra-feed/installer.sh|sh
