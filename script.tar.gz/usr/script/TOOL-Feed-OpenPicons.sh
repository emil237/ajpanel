wget https://dreambox4u.com/emilnabil237/script/openpicons-feed.sh -O - | /bin/sh


