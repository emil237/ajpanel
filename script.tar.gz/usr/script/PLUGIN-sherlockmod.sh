wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/sherlockmod/main/installer.sh -O - | /bin/sh

