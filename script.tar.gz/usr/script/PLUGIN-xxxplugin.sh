wget http://dreambox4u.com/emilnabil237/plugins/xxxplugin/installer.sh -O - | /bin/sh
