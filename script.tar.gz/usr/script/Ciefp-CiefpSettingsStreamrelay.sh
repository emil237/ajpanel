#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/ciefp/CiefpSettingsStreamrelay/main/installer.sh -O - | /bin/sh