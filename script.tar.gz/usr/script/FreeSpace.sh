#!/bin/sh
##DESCRIPTION=FREE FLASH
df -h
