#!/bin/sh
##DESCRIPTION=Mount Points
mount
echo ""
exit 0
