#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/ciefp/CiefpWhitelistStreamrelay/main/installer.sh -O - | /bin/sh