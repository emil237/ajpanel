wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/satdreamgr.sh -O - | /bin/sh
exit 0
