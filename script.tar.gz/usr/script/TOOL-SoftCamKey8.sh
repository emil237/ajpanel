wget -O /etc/tuxbox/config/SoftCam.Key https://github.com/MOHAMED19OS/SoftCam_Emu/raw/main/SoftCam.Key


