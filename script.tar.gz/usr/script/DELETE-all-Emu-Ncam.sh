opkg remove enigma2-plugin-softcams-ncam*



