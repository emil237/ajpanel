#!/bin/sh
##DESCRIPTION=Connection List
netstat -net
