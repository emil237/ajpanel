wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/multistalker/installer.sh -O - | /bin/sh
