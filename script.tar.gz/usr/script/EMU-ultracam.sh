wget https://dreambox4u.com/emilnabil237/emu/installer-ultracam.sh -O - | /bin/sh






