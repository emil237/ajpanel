wget https://dreambox4u.com/emilnabil237/plugins/YouTube/installer.sh -qO - | /bin/sh
