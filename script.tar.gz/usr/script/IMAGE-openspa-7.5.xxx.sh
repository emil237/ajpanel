wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openspa-7.5.xxx.sh -O - | /bin/sh
exit 0
