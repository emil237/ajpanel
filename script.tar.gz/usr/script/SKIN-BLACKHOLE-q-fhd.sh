opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-q-fhd.sh|sh
