wget https://raw.githubusercontent.com/biko-73/zelda77/main/installerR.sh -qO - | /bin/sh




