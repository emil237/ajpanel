wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openatv-7.3.sh -O - | /bin/sh
exit 0
