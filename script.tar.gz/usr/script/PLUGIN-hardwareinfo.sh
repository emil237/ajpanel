curl -kLs https://dreambox4u.com/emilnabil237/plugins/hardwareinfo/installer.sh|sh
