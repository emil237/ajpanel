wget https://dreambox4u.com/emilnabil237/plugins/PlutoTV/installer.sh -qO - | /bin/sh
