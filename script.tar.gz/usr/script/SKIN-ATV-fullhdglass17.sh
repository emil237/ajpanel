wget https://dreambox4u.com/emilnabil237/skins/openatv/skin-fullhdglass17.sh -O - | /bin/sh



