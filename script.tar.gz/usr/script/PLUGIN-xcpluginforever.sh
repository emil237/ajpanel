wget https://dreambox4u.com/emilnabil237/plugins/xcplugin/installer.sh -qO - | /bin/sh
