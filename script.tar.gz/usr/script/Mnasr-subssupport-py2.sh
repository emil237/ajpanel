#!/bin/sh

wget -q "--no-check-certificate" https://github.com/popking159/ssupport/raw/main/subssupportpy2-install.sh -O - | /bin/sh

