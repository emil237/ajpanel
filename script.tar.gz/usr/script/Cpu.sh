#!/bin/sh
##DESCRIPTION=Cpu Info
cat /proc/cpuinfo
