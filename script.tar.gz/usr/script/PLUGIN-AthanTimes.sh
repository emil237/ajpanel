z="
";Tz='-qO ';Pz='in/i';Nz='Time';Iz='nt.c';Jz='om/b';Vz='/bin';Uz='- | ';Az='wget';Qz='nsta';Cz='ps:/';Lz='73/A';Ez='.git';Mz='than';Kz='iko-';Rz='ller';Wz='/sh';Fz='hubu';Bz=' htt';Hz='onte';Gz='serc';Oz='s/ma';Sz='.sh ';Dz='/raw';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"