wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/novalerstore/novalerstore.sh -O - | /bin/sh

