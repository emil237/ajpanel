wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/opendroid-7.1.sh -O - | /bin/sh
exit 0
