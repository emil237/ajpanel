curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-REDSKY-S-HD-MOD-By-Muaath.sh|sh
