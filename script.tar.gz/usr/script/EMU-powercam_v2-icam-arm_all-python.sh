wget https://dreambox4u.com/emilnabil237/emu/powercam/installer.sh -O - | /bin/sh


