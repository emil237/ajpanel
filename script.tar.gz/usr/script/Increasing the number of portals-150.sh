wget https://dreambox4u.com/emilnabil237/script/Increasing-the-number-of-portals-150.sh -O - | /bin/sh



