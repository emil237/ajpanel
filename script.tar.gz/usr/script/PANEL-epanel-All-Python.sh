wget https://dreambox4u.com/emilnabil237/plugins/epanel/installer.sh -O - | /bin/sh


