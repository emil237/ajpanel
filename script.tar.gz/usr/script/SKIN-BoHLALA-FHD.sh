wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerB.sh -qO - | /bin/sh




