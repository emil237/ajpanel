wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/update-package+one-hour.sh -O - | /bin/sh







