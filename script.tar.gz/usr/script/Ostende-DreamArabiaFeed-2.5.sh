#!/bin/sh

apt update && wget -O /tmp/dreamarabia-addons-feed.deb http://dreambox4u.com/dreamarabia/2.5/DreamArabia-Addons/dreamarabia-addons-feed.deb && dpkg -i /tmp/dreamarabia-addons-feed.deb