wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/ipsat/ipsat.sh -O - | /bin/sh

