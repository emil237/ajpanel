systemctl stop enigma2
apt-get -f install; apt-get autoremove
apt update; apt upgrade
systemctl start 
