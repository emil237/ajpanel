curl -kLs https://dreambox4u.com/emilnabil237/script/update-abertis-astra.sh|sh

