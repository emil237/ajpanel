wget https://dreambox4u.com/emilnabil237/plugins/freeserver/installer.sh -qO - | /bin/sh
