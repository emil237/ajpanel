wget https://dreambox4u.com/emilnabil237/plugins/novalertv/installer.sh -qO - | /bin/sh
