#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/eliesat/eliesatpanel/main/installer.sh -O - | /bin/sh