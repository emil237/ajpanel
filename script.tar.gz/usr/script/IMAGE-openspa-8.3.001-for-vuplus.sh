wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openspa-8.3.001.sh -O - | /bin/sh
exit 0
