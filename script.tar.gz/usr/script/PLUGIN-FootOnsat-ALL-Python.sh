wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh


