opkg update && opkg install gstreamer1.0-plugins-base



