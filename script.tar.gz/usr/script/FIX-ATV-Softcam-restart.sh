wget -O - -q http://updates.mynonpublic.com/oea/feed | bash



