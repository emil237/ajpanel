
#!/bin/sh
#

wget -O /etc/tuxbox/config/SoftCam.Key "https://raw.githubusercontent.com/smcam/s/main/SoftCam.Key"
wait
sleep 2;
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;
	echo '========================================================================================================================='
###########################################                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0












