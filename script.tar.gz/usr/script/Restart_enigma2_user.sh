#!/bin/sh
##DESCRIPTION=This script will restart Enigma2.\nIt will not ask you before!
killall -9 enigma2
