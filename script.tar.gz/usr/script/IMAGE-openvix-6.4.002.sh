wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openvix-6.4.002.sh -O - | /bin/sh
exit 0
