#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglarepli/installer.sh -O - | /bin/sh