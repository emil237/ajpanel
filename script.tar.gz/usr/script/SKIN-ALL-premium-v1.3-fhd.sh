wget http://dreambox4u.com/emilnabil237/script/SKIN-ALL-premium-fhd.sh -qO - | /bin/sh




