curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-OSN-BLUE-FHD-By-Muaath.sh|sh
