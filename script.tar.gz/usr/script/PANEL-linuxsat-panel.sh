wget https://dreambox4u.com/emilnabil237/plugins/linuxsat-panel/installer.sh -qO - | /bin/sh


