#!/bin/sh

wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/ajpanel/new/emil-panel-lite.sh -O - | /bin/sh
