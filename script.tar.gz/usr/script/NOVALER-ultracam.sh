wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/ultracam/ultracam.sh -O - | /bin/sh

