wget https://raw.githubusercontent.com/emilnabil/3GModemManager/main/installer.sh -O - | /bin/sh

