#!/bin/sh
##DESCRIPTION=Hdd Status
hdparm -Tt /dev/ide/host0/bus0/target0/lun0/disc
