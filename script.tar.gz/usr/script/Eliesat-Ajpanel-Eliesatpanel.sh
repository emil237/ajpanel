#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/eliesatpanel/-/raw/main/eliesatpanel.sh -O - | /bin/sh