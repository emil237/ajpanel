wget http://dreambox4u.com/emilnabil237/plugins/ajpanel/emil-panel.sh -O - | /bin/sh



