#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/neoboot/main/iNB.sh -O - | /bin/sh