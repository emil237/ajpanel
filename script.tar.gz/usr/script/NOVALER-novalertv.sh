wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/novalertv/novalertv.sh -O - | /bin/sh

