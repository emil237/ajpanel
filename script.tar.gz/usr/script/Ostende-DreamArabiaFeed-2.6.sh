#!/bin/sh

wget -q "--no-check-certificate" http://dreambox4u.com/dreamarabia/scripts/installer.sh -O - | /bin/sh