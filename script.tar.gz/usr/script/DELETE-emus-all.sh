wget https://dreambox4u.com/emilnabil237/script/delete-emus-all.sh -O - | /bin/sh


