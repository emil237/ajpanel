#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel/MagicPanel-install.sh -O - | /bin/sh