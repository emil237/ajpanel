wget https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh -O - | /bin/sh



