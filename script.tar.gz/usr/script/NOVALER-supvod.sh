wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/supvod/supvod.sh -O - | /bin/sh

