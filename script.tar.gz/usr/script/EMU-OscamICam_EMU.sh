wget https://raw.githubusercontent.com/biko-73/OsCam_EMU/main/installericam.sh -O - | /bin/sh





