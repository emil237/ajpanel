#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh -O - | /bin/sh