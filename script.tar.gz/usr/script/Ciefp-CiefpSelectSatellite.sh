#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/ciefp/CiefpSelectSatellite/main/installer.sh -O - | /bin/sh