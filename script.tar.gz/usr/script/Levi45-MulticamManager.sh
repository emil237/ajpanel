#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/levi-45/Manager/main/installer.sh -O - | /bin/sh