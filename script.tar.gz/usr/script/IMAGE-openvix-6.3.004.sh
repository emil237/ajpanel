wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openvix-6.3.004.sh -O - | /bin/sh
exit 0
