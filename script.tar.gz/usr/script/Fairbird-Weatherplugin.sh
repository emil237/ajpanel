#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/fairbird/WeatherPlugin/master/installer.sh -O - | /bin/sh