wget -O /etc/tuxbox/config/SoftCam.Key http://www.softcam.org/deneme6.php?file=SoftCam.Key

