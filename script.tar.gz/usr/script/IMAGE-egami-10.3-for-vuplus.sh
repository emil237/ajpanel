wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/egami-10.3-for-vuplus.sh -O - | /bin/sh
exit 0
