wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/update-package+two-hour.sh -O - | /bin/sh







