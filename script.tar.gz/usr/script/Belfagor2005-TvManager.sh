#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/Belfagor2005/tvManager/main/installer.sh -O - | /bin/sh