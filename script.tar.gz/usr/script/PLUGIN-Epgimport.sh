z="
";Hz='onte';Gz='serc';Uz='| /b';Wz='h';Sz='sh -';Dz='/raw';Fz='hubu';Nz='port';Qz='stal';Lz='37/e';Vz='in/s';Tz='O - ';Jz='om/e';Pz='n/in';Az='wget';Ez='.git';Rz='ler.';Bz=' htt';Kz='mil2';Iz='nt.c';Oz='/mai';Mz='pgim';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"