wget -O /etc/tuxbox/config/SoftCam.Key https://dreambox4u.com/emilnabil237/softcam/SoftCam.Key


