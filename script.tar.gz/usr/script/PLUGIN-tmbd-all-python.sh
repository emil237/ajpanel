wget -q "--no-check-certificate" http://dreambox4u.com/emilnabil237/plugins/TMBD/installer.sh -O - | /bin/sh
