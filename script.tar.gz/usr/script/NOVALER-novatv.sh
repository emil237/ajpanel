wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/novatv/novatv.sh -O - | /bin/sh

