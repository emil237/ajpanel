opkg update

opkg install curl

curl -kLs https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent_6.2.sh|sh




