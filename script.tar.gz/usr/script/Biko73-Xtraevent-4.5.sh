#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/Xtraevent/main/installer-v_4.5.sh -O - | /bin/sh