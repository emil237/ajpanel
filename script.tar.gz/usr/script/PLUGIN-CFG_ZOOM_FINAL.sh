wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/cfg_Zoom_Final/installer.sh  -O - | /bin/sh


