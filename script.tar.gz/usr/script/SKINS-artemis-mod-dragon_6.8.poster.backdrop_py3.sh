#!/bin/sh
sleep 1
echo "Install skins-artemis-mod-dragon_6.8"
echo ""
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://dreambox4u.com/emilnabil237/skins/enigma2-plugin-skins-artemis-mod-dragon_6.8.poster.backdrop_py3_all.ipk" > /tmp/enigma2-plugin-skins-artemis-mod-dragon_6.8.poster.backdrop_py3_all.ipk
sleep 1
echo "installing ...."
cd /tmp
opkg install /tmp/enigma2-plugin-skins-artemis-mod-dragon_6.8.poster.backdrop_py3_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-skins-artemis-mod-dragon_6.8.poster.backdrop_py3_all.ipk
echo "OK"
killall -9 enigma2
exit
