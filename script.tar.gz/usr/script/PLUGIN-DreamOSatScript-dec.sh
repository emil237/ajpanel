wget http://dreambox4u.com/emilnabil237/plugins/DreamOSatScript/installer.sh -O - | /bin/sh


