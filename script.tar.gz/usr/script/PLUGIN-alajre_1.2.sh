wget https://dreambox4u.com/emilnabil237/plugins/alajre/installer.sh -qO - | /bin/sh







