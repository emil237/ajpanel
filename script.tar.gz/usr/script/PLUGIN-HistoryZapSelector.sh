wget https://dreambox4u.com/emilnabil237/plugins/historyzap/installer.sh -O - | /bin/sh
