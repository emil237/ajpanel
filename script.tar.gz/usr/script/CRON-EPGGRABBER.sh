#!/bin/sh

#
echo 1 > /proc/sys/vm/drop_caches
echo 2 > /proc/sys/vm/drop_caches
echo 3 > /proc/sys/vm/drop_caches

scripts=(
    "bebawy6.py"
    "beincin.py"
    "beinConnect.py"
    "elcin.py"
    "elcinEN.py"
    "elcinmaiet5.py"
    "jawwyenOS.py"
    "sportiet5.py"
    "beinsportiet5.py"
    "elcinmaiet5.py"
    "nilesatiet5.py"
    "sportiet5.py"
    "uaeariet5.py"
    "uaeeniet5.py"
)

for script in "${scripts[@]}"; do
    python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/"$script"
    wait
done

exit 0
