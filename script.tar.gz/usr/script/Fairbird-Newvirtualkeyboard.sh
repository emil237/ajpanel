#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/installer.sh -O - | /bin/sh