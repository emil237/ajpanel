wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/beengo/beengo.sh -O - | /bin/sh

