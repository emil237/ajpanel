#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/Bahaa-E2/CH.Logo.Changer/main/ChLogoChanger_By_Bahaa.sh -O - | /bin/sh



