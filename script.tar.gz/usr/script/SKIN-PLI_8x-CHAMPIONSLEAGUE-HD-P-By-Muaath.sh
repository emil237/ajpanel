curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-CHAMPIONSLEAGUE-HD-P-By-Muaath.sh|sh
