wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openblackhole-5.4.sh -O - | /bin/sh
exit 0
