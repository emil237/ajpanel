#!/bin/sh
echo "install curl"
opkg update
opkg install curl
exit 0
