wget https://dreambox4u.com/emilnabil237/script/audio-ipaudio.sh -O - | /bin/sh

