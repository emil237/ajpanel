#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/Belfagor2005/Horoscope/main/installer.sh -O - | /bin/sh