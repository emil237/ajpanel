z="
";Mz='icon';Dz='/raw';Bz=' htt';Ez='.git';Gz='serc';Wz='n/sh';Vz=' /bi';Kz='mil2';Tz=' -qO';Rz='alle';Fz='hubu';Sz='r.sh';Hz='onte';Qz='inst';Pz='ain/';Az='wget';Jz='om/e';Oz='er/m';Lz='37/p';Iz='nt.c';Uz=' - |';Nz='-oth';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"