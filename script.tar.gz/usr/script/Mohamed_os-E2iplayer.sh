#!/bin/sh

wget -qO- --no-check-certificate https://mohamed_os.gitlab.io/e2iplayer/online-setup | bash