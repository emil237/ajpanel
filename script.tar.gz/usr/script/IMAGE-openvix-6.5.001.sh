wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openvix-6.5.001.sh -O - | /bin/sh
exit 0



