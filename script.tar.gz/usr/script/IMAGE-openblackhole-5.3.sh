wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openblackhole-5.3.sh -O - | /bin/sh
exit 0
