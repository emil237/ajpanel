#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/kiddac-skin-e2sentials/main/installer.sh -O - | /bin/sh