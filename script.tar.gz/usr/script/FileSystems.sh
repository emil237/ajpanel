#!/bin/sh
##DESCRIPTION=File Systems
cat /proc/filesystems
