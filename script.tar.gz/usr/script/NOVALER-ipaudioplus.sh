wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/ipaudioplus/ipaudioplus.sh -O - | /bin/sh

