opkg flag hold enigma2-plugin-softcams-oscam


