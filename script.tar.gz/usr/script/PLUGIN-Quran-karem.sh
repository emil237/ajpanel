wget https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh -qO - | /bin/sh
