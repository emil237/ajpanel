curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-ROBOCOP2-HD-MOD-By-Muaath.sh|sh
