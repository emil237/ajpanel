wget http://dreambox4u.com/emilnabil237/script/Restore-My-backup-shannels.sh -qO - | /bin/sh





