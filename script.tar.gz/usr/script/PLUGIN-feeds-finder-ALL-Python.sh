wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh -O - | /bin/sh



