wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/novacam-supreme/novacam-supreme.sh -O - | /bin/sh

