wget https://dreambox4u.com/emilnabil237/script/Super_Script.sh -O - | /bin/sh


