#!/bin/sh

wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh