wget -q "--no-check-certificate" http://dreambox4u.com/emilnabil237/script/FEED-emil-feed.sh -O - | /bin/sh



