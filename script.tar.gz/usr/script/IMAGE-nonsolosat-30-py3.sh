wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/nonsolosat-30-py3.sh -O - | /bin/sh
exit 0






