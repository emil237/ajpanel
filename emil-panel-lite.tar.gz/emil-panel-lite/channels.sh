<submenu fg="#CCFB5D" font_size="50" height="950" mode="grid_4x3" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Channels" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
		<submenu fg="#CCFB5D" font_size="50" height="950" mode="grid_4x3" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Channels Other" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
			<item ask="Install Plugin Elsafty-Tv-Radio-Steaming ?" icon="menu.png" name="Elsafty-Tv-Radio-Steaming">wget https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh -O - | /bin/sh</item>
		<item ask="Install Khaled Ali ?" icon="menux.png" name="Khaled Ali">curl -kLs https://raw.githubusercontent.com/emilnabil/channel-khaled/main/installer.sh|sh</item>		
			<item ask="Install Mohamed Goda ?" icon="menux.png" name="Mohamed Goda">wget https://raw.githubusercontent.com/emilnabil/channel-mohamed-goda/main/installer.sh -O - | /bin/sh</item>
			<item ask="Install Emil Nabil ?" icon="menux.png" name="Emil Nabil">wget https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh -O - | /bin/sh</item>
			<item ask="Install Mohamed Nasr ?" icon="menux.png" name="Mohamed Nasr">wget https://raw.githubusercontent.com/emilnabil/channel-mnasr/main/installer.sh -O - | /bin/sh</item>
			<item ask="Install Tarek Ashry ?" icon="menux.png" name="Tarek Ashry">wget https://raw.githubusercontent.com/emilnabil/channel-tarek-ashry/main/installer.sh -O - | /bin/sh</item>
		</submenu>

		<submenu fg="#CCFB5D" font_size="50" height="950" mode="grid" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Skins Atv" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
		<item ask="Install Skin Al Ayam ?" icon="menux.png" name="Al Ayam FHD skin">curl -kLs https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh|sh</item>	
			<item ask="Install Skin Aglare-FHD ?" icon="menux.png" name="Aglare-FHD">curl -kLs https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh|sh</item>
			<item ask="Install Skin Maxy-FHD ?" icon="menux.png" name="Maxy-FHD">curl -kLs https://dreambox4u.com/emilnabil237/skins/script/skins-Maxy-FHD.sh|sh</item>
			<item ask="Install Full HD Glass17 ?" icon="menux.png" name="Full HD Glass17">wget -q "--no-check-certificate" http://dreambox4u.com/emilnabil237/skins/skin-fullhdglass17/installer.sh -O - | /bin/sh</item>
			<item ask="Install Metrixfhd-neo_V.7s_v2_mod-by-biko_X_py3.12 ?" icon="menux.png" name="Metrixfhd-neo_V.7s_v2_mod-by-biko_X_py3.12">curl -kLs https://dreambox4u.com/emilnabil237/skins/openatv/metrixfhd-neo_V.7s_v2_mod-by-biko_X_py3.12.sh|sh</item>
			<item ask="Install MX-GravityAir_xtraevent_py3.12 ?" icon="menux.png" name="MX-GravityAir_xtraevent_py3.12">curl -kLs https://dreambox4u.com/emilnabil237/skins/openatv/MX-GravityAir-Atv_xtraevent_py3.12.sh|sh</item>
			<item ask="Install MyMetrixLiteBackup ?" icon="menux.png" name="MyMetrixLiteBackup-by-Mohd">wget -O /etc/enigma2/MyMetrixLiteBackup.dat "https://raw.githubusercontent.com/emil237/skins-enigma2/main/ATV/MyMetrixLiteBackup.dat"</item>
			<item ask="Install MyMetrixLiteBackup ?" icon="menux.png" name="MyMetrixLiteBackup">wget -O /etc/enigma2/MyMetrixLiteBackup.dat "https://raw.githubusercontent.com/emil237/plugins/main/MyMetrixLiteBackup.dat"</item>
			<item ask="Install Skin MetrixFHD-OpenATV-Extraevent-PosterX ?" icon="menux.png" name="MetrixFHD-OpenATV-Extraevent-PosterX">curl -kLs https://dreambox4u.com/emilnabil237/skins/openatv/SKIN-MetrixFHD-OpenATV-Extraevent-PosterX.sh|sh</item>
			<item ask="Install Skin Malek-FHD ?" icon="menux.png" name="skins-malek-fhd_2.2_py3.11.2-py3.12.1">curl -kLs https://raw.githubusercontent.com/emil237/skins-enigma2/main/ATV/skins-malek-fhd_2.2_py3.11.2-py3.12.1.sh|sh</item>
			<item ask="Install Skin Nacht_1.7.3 ?" icon="menux.png" name="Nacht_1.7.3">wget http://dreambox4u.com/emilnabil237/script/SKIN-ATV-nacht_1.7.3.sh -O - | /bin/sh</item>
			<item ask="Install Skin Novaler-s-fhd-indianred ?" icon="menux.png" name="Novaler-s-fhd-indianred_3.4">wget https://dreambox4u.com/emilnabil237/skins/openatv/SKIN-novaler-s-fhd-indianred_3.4.sh -O - | /bin/sh</item>
			<item ask="Install Skin oDreamy-FHD ?" icon="menux.png" info="Modded By Inspiron" name="oDreamy-FHD">wget https://dreambox4u.com/emilnabil237/skins/openatv/skins-oDreamy-FHD.sh -O - | /bin/sh</item>
			<item ask="Install Skin Ozeta Xtra ?" icon="menux.png" name="Ozeta-Xtra">wget http://dreambox4u.com/emilnabil237/script/SKIN-ATV-ozeta-xtra.sh -O - | /bin/sh</item>
			<item ask="Install Skin XDreamy-FHD ?" icon="menux.png" name="XDreamy-FHD">wget -q "--no-check-certificate" https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh</item>
		</submenu>

		<submenu fg="#E9AB17" font_size="50" height="950" mode="grid_4x3" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Skins BlackHole" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
			<item ask="Install Skin q-purple ?" icon="menu.png" name="q-purple">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE--q-purple.sh|sh
</item>
			<item ask="Install Skin Alienaware-Obh4 ?" icon="menu.png" name="Alienaware-Obh4">wget https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-alienaware-obh4.sh -O - | /bin/sh</item>
			<item ask="Install Skin Ekselancen ?" icon="menu.png" name="Ekselancen">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-ekselancen.sh|sh</item>
			<item ask="Install Skin Mx-Sline ?" icon="menu.png" name="Mx-Sline">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-mx-sline.sh|sh</item>
			<item ask="Install Skin Mxgraphite ?" icon="menu.png" name="Mxgraphite skin">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-mxgraphite.sh|sh</item>
			<item ask="Install Skin Q-Darkblue ?" icon="menu.png" name="Q-Darkblue">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-q-darkblue.sh|sh</item>
			<item ask="Install Skin Q-Fhd ?" icon="menu.png" name="Q-Fhd skin">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE--q-purple.sh|sh</item>
			<item ask="Install Skin Waves4 ?" icon="menu.png" name="Waves4">opkg update
opkg install curl
curl -kLs https://dreambox4u.com/emilnabil237/skins/blackhole/SKIN-BLACKHOLE-waves4.sh|sh</item>
		</submenu>

		<submenu fg="#F9B7FF" font_size="50" height="950" mode="grid_4x3" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Skins Egami" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
		<item ask="Install Skin Al Ayam ?" icon="menux.png" name="Al Ayam FHD skin">curl -kLs https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh|sh</item>	
			<item ask="Install Skin Aglare-FHD ?" icon="menu.png" name="Aglare-FHD">curl -kLs https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh|sh</item>
			<item ask="" icon="menu.png" name="Premium-Fhd_3.0">wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium-fhd-py3.sh -O - | /bin/sh</item>
			<item ask="" icon="menu.png" name="Premium-Black-Fhd_3.0">wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium--black-fhd-py3.sh -O - | /bin/sh</item>
			<item ask="" icon="menu.png" name="Premium-Blue-Fhd_3.0">wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium--blue-fhd-py3.sh -O - | /bin/sh</item>
			<item ask="Install Skin XDreamy-FHD ?" icon="menux.png" name="XDreamy-FHD">wget -q "--no-check-certificate" https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh</item>
		</submenu>

		<submenu fg="#CCFB5D" font_size="50" height="950" mode="grid_4x3" num_bg="#000000" num_fg="#FCFCFC" shade="yes" title="Skins Open Black Hole" title1_bg="#000000" title1_fg="#FFFF00" title2_bg="#000000" title2_fg="#FCFCFC" title_bg="#11332233" width="1600">
			<item ask="" icon="menu.png" name="Aglare-fhd">curl -kLs https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglarepli/installer.sh|sh</item>
		<item ask="Install Skin Al Ayam ?" icon="menux.png" name="Al Ayam FHD skin">curl -kLs https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh|sh</item>		
			<item ask="" icon="menu.png" info="5.4.xx py3.12.x" name="MX_BlackSea">curl -kLs https://dreambox4u.com/emilnabil237/skins/obh/skins-MX_BlackSea.sh|sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.4" name="MX-Sline-Black-Red-Gradient_py3.12">curl -kLs https://dreambox4u.com/emilnabil237/skins/obh/mx-sline-black-red-gradient_py3.12.sh|sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.4" name="MX_Sline-Blue_OBH_5.4_py3.12">curl -kLs https://dreambox4u.com/emilnabil237/skins/obh/MX_Sline-Blue_OBH_5.4_py3.12_py3.12.sh|sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.4" name="MX_Sline-Red_X2_py3.12">curl -kLs https://dreambox4u.com/emilnabil237/skins/obh/MX_Sline-Red_X2_py3.12.sh|sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.4_py3.12" name="MX_LiveFHD_posterX-Mod-HA">curl -kLs https://dreambox4u.com/emilnabil237/skins/obh/MX-LiveFHD-posterX_mod-HAhmed-py3.12.sh|sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.3" name="MX_GrayDots_vip-xtra_mod-HA">wget https://dreambox4u.com/emilnabil237/skins/obh/MX_GrayDots_vip-xtra_mod-HA.sh  -O - | /bin/sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.3" name="mx-hq9w_2.0-mod3-FHD">wget https://dreambox4u.com/emilnabil237/skins/obh/mx-hq9w_2.0-mod3fhd.sh  -O - | /bin/sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.3" name="MX-MaesteraBPR-FHD_MOD-HAhmed">wget https://dreambox4u.com/emilnabil237/skins/obh/MX-MaesteraBPR-FHD_MOD-HAhmed.sh  -O - | /bin/sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.3" name="Mx-PrioFHD-xtra_mod-HAhmed">wget https://dreambox4u.com/emilnabil237/skins/obh/Mx-PrioFHD-xtra_mod-HAhmed.sh  -O - | /bin/sh</item>
			<item ask="Install Skin ?" icon="menux.png" info="FOR OPEN-BH_5.3" name="mx-sline-posterx_2.0-mod2ha">wget https://dreambox4u.com/emilnabil237/skins/obh/mx-sline-posterx_2.0-mod2ha.sh  -O - | /bin/sh</item>
			<item ask="Install Skin XDreamy-FHD ?" icon="menux.png" name="XDreamy-FHD">wget -q "--no-check-certificate" https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh</item>
		</submenu>
		</submenu>



